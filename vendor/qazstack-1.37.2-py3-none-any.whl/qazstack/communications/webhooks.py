"""Signed metadata-only webhook envelope for communications adapters."""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Mapping

from pydantic import BaseModel, ConfigDict, Field, field_validator
from qazstack.databus.webhooks import ReplayStore, WebhookVerification, sign_webhook, verify_webhook

from qazstack.communications.models import _OPAQUE_REF_RE, CommunicationEvent

WEBHOOK_SCHEMA_VERSION = "qazstack-communications-webhook-v1"
WEBHOOK_TIMESTAMP_HEADER = "x-qazstack-timestamp"
WEBHOOK_SIGNATURE_HEADER = "x-qazstack-signature"


class CommunicationWebhookEnvelope(BaseModel):
    """Webhook body containing only an opaque delivery reference and safe event."""

    model_config = ConfigDict(extra="forbid")

    schema_version: str = WEBHOOK_SCHEMA_VERSION
    delivery_ref: str = Field(pattern=r"^sha256:[a-f0-9]{64}$")
    event: CommunicationEvent

    @field_validator("schema_version")
    @classmethod
    def validate_schema_version(cls, value: str) -> str:
        if value != WEBHOOK_SCHEMA_VERSION:
            raise ValueError(f"schema_version must be {WEBHOOK_SCHEMA_VERSION}")
        return value

    @field_validator("delivery_ref")
    @classmethod
    def validate_delivery_reference(cls, value: str) -> str:
        if not _OPAQUE_REF_RE.fullmatch(value):
            raise ValueError("delivery_ref must be a sha256 opaque reference")
        return value

    def canonical_bytes(self) -> bytes:
        """Serialize stable bytes for transport signing and verification."""
        return json.dumps(
            self.model_dump(mode="json"),
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode()


@dataclass(frozen=True, slots=True)
class CommunicationWebhookResult:
    """Signature result plus a validated envelope when the bytes are safe."""

    verification: WebhookVerification
    envelope: CommunicationWebhookEnvelope | None = None
    reason: str = ""


def sign_communication_webhook(envelope: CommunicationWebhookEnvelope, *, timestamp: int, secret: str) -> str:
    """Sign canonical envelope bytes through the shared QazStack HMAC contract."""
    return sign_webhook(envelope.canonical_bytes(), timestamp=timestamp, secret=secret)


def verify_communication_webhook(
    payload: bytes,
    *,
    timestamp: int,
    signature: str,
    secrets: tuple[str, ...],
    replay_store: ReplayStore | None = None,
    now: int | None = None,
) -> CommunicationWebhookResult:
    """Verify HMAC/replay protection before decoding the metadata-only body."""
    verification = verify_webhook(
        payload,
        timestamp=timestamp,
        signature=signature,
        secrets=secrets,
        replay_store=replay_store,
        now=now,
    )
    if not verification.valid:
        return CommunicationWebhookResult(verification=verification, reason=verification.reason)
    try:
        envelope = CommunicationWebhookEnvelope.model_validate_json(payload)
    except ValueError as exc:
        return CommunicationWebhookResult(verification=verification, reason=f"invalid_envelope: {exc}")
    return CommunicationWebhookResult(verification=verification, envelope=envelope, reason="verified")


def communication_webhook_headers(*, timestamp: int, signature: str) -> dict[str, str]:
    """Return normalized headers for a caller that posts a signed envelope."""
    if not signature.startswith("v1="):
        raise ValueError("signature must use v1 format")
    return {
        "Content-Type": "application/json",
        WEBHOOK_TIMESTAMP_HEADER: str(timestamp),
        WEBHOOK_SIGNATURE_HEADER: signature,
    }


def parse_communication_webhook_headers(headers: Mapping[str, str]) -> tuple[int, str]:
    """Read case-insensitive signature headers without accepting arbitrary names."""
    normalized = {key.lower(): value for key, value in headers.items()}
    try:
        timestamp = int(normalized[WEBHOOK_TIMESTAMP_HEADER])
    except (KeyError, ValueError) as exc:
        raise ValueError("missing or invalid x-qazstack-timestamp") from exc
    signature = normalized.get(WEBHOOK_SIGNATURE_HEADER, "")
    if not signature:
        raise ValueError("missing x-qazstack-signature")
    return timestamp, signature
