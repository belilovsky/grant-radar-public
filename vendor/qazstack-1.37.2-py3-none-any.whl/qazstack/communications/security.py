"""Provider-neutral evidence for public mail-domain security posture.

This module deliberately accepts an injected DNS resolver. QazStack validates
the public evidence but does not own DNS credentials, mailboxes or providers.
"""

from __future__ import annotations

import re
from datetime import datetime, timezone
from typing import Any, Literal, Protocol

from pydantic import BaseModel, ConfigDict, Field, field_validator

from qazstack.communications.models import _DOMAIN_RE

MailSecurityCheckStatus = Literal["present", "missing", "malformed", "not_configured", "unavailable"]
MailSecurityPosture = Literal["ok", "warning", "error"]
_DNS_HOSTNAME_RE = re.compile(r"^(?:_?[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$")


class MailDnsResolver(Protocol):
    """Minimal DNS adapter needed to inspect public mail-security records."""

    def resolve_txt(self, hostname: str) -> list[str]: ...

    def resolve_mx(self, hostname: str) -> list[str]: ...


class DnsPythonMailResolver:
    """`dnspython` adapter for real public DNS checks, installed on demand."""

    def __init__(self, resolver: Any | None = None) -> None:
        if resolver is None:
            try:
                import dns.resolver
            except ImportError as exc:  # Keep the base communications extra dependency-free.
                raise RuntimeError("DnsPythonMailResolver requires qazstack[communications-dns]") from exc
            resolver = dns.resolver.Resolver()
        self._resolver = resolver

    def resolve_txt(self, hostname: str) -> list[str]:
        """Return joined TXT fragments; never expose them in evidence models."""
        records = self._resolver.resolve(hostname, "TXT")
        values: list[str] = []
        for record in records:
            chunks = getattr(record, "strings", None)
            if chunks is not None:
                values.append(b"".join(chunks).decode("utf-8", errors="replace"))
            else:
                values.append(str(record).strip('"'))
        return values

    def resolve_mx(self, hostname: str) -> list[str]:
        """Return public MX hostnames without their preferences."""
        return [str(record.exchange).rstrip(".") for record in self._resolver.resolve(hostname, "MX")]


class MailSecurityCheck(BaseModel):
    """One non-sensitive configuration result without publishing DNS values."""

    model_config = ConfigDict(extra="forbid")

    status: MailSecurityCheckStatus
    hostname: str = Field(min_length=3, max_length=253)

    @field_validator("hostname")
    @classmethod
    def validate_hostname(cls, value: str) -> str:
        normalized = value.strip().lower().rstrip(".")
        if not _DNS_HOSTNAME_RE.fullmatch(normalized):
            raise ValueError("hostname must be a valid public DNS hostname")
        return normalized


class MailDomainSecurityEvidence(BaseModel):
    """A timestamped, public-safe inspection of one domain's mail posture."""

    model_config = ConfigDict(extra="forbid")

    schema_version: Literal["qazstack-mail-security-v1"] = "qazstack-mail-security-v1"
    domain: str = Field(min_length=3, max_length=253)
    checked_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    posture: MailSecurityPosture
    mx: MailSecurityCheck
    spf: MailSecurityCheck
    dmarc: MailSecurityCheck
    dkim: MailSecurityCheck
    mta_sts: MailSecurityCheck
    tls_rpt: MailSecurityCheck

    @field_validator("domain")
    @classmethod
    def validate_domain(cls, value: str) -> str:
        normalized = value.strip().lower().rstrip(".")
        if not _DOMAIN_RE.fullmatch(normalized):
            raise ValueError("domain must be a valid public DNS name")
        return normalized

    @field_validator("checked_at")
    @classmethod
    def validate_checked_at(cls, value: datetime) -> datetime:
        if value.tzinfo is None or value.utcoffset() is None:
            raise ValueError("checked_at must be timezone-aware")
        return value


def inspect_mail_domain_security(
    domain: str,
    resolver: MailDnsResolver,
    *,
    dkim_selectors: tuple[str, ...] = (),
    checked_at: datetime | None = None,
) -> MailDomainSecurityEvidence:
    """Inspect public mail records with a consumer-provided DNS resolver.

    A DKIM selector cannot be discovered reliably from DNS alone, so callers
    provide the selectors their mail service publishes. Missing optional
    transport records create a warning; missing MX/SPF/DMARC creates an error.
    """
    normalized = _normalize_domain(domain)
    selectors = tuple(_normalize_selector(selector) for selector in dkim_selectors)
    if len(set(selectors)) != len(selectors):
        raise ValueError("dkim_selectors must not contain duplicates")

    mx = _inspect_mx(normalized, resolver)
    spf = _inspect_txt(normalized, resolver, "v=spf1")
    dmarc = _inspect_txt(f"_dmarc.{normalized}", resolver, "v=dmarc1")
    dkim = _inspect_dkim(normalized, resolver, selectors)
    mta_sts = _inspect_txt(f"_mta-sts.{normalized}", resolver, "v=stsv1")
    tls_rpt = _inspect_txt(f"_smtp._tls.{normalized}", resolver, "v=tlsrptv1")
    core = (mx, spf, dmarc)
    posture: MailSecurityPosture
    if any(check.status in {"missing", "malformed", "unavailable"} for check in core):
        posture = "error"
    elif any(
        check.status in {"missing", "malformed", "not_configured", "unavailable"} for check in (dkim, mta_sts, tls_rpt)
    ):
        posture = "warning"
    else:
        posture = "ok"
    return MailDomainSecurityEvidence(
        domain=normalized,
        checked_at=checked_at or datetime.now(timezone.utc),
        posture=posture,
        mx=mx,
        spf=spf,
        dmarc=dmarc,
        dkim=dkim,
        mta_sts=mta_sts,
        tls_rpt=tls_rpt,
    )


def _normalize_domain(value: str) -> str:
    normalized = value.strip().lower().rstrip(".")
    if not _DOMAIN_RE.fullmatch(normalized):
        raise ValueError("domain must be a valid public DNS name")
    return normalized


def _normalize_selector(value: str) -> str:
    normalized = value.strip().lower()
    if not re.fullmatch(r"[a-z0-9][a-z0-9-]{0,62}", normalized):
        raise ValueError("DKIM selectors must use lowercase letters, digits and hyphens")
    return normalized


def _inspect_mx(domain: str, resolver: MailDnsResolver) -> MailSecurityCheck:
    try:
        records = resolver.resolve_mx(domain)
    except Exception:  # DNS provider failures must become evidence, not crashes.
        return MailSecurityCheck(status="unavailable", hostname=domain)
    status: MailSecurityCheckStatus = "present" if any(record.strip() for record in records) else "missing"
    return MailSecurityCheck(status=status, hostname=domain)


def _inspect_txt(hostname: str, resolver: MailDnsResolver, version: str) -> MailSecurityCheck:
    try:
        records = resolver.resolve_txt(hostname)
    except Exception:
        return MailSecurityCheck(status="unavailable", hostname=hostname)
    normalized = [record.strip().lower() for record in records if record.strip()]
    if any(record.startswith(version) for record in normalized):
        return MailSecurityCheck(status="present", hostname=hostname)
    if normalized:
        return MailSecurityCheck(status="malformed", hostname=hostname)
    return MailSecurityCheck(status="missing", hostname=hostname)


def _inspect_dkim(domain: str, resolver: MailDnsResolver, selectors: tuple[str, ...]) -> MailSecurityCheck:
    hostname = f"_domainkey.{domain}" if not selectors else f"{selectors[0]}._domainkey.{domain}"
    if not selectors:
        return MailSecurityCheck(status="not_configured", hostname=hostname)
    statuses = [_inspect_txt(f"{selector}._domainkey.{domain}", resolver, "v=dkim1").status for selector in selectors]
    if any(status == "present" for status in statuses):
        return MailSecurityCheck(status="present", hostname=hostname)
    if any(status == "unavailable" for status in statuses):
        return MailSecurityCheck(status="unavailable", hostname=hostname)
    if any(status == "malformed" for status in statuses):
        return MailSecurityCheck(status="malformed", hostname=hostname)
    return MailSecurityCheck(status="missing", hostname=hostname)
