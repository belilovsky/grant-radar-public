"""Pure helpers for canonical public source URLs and bounded link candidates."""

from __future__ import annotations

import hashlib
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from urllib.parse import parse_qsl, urlencode, urljoin, urlparse, urlunparse

_TRACKING_PARAMS = frozenset({"fbclid", "gclid", "mc_cid", "mc_eid", "yclid", "ysclid"})
_GENERIC_LINK_TEXT = frozenset({"article", "link", "more", "read", "source", "статья", "ссылка", "источник", "читать"})
_SOCIAL_HOST_SUFFIXES = ("facebook.com", "instagram.com", "t.me", "telegram.me", "twitter.com", "x.com")
_VIDEO_HOST_SUFFIXES = ("vimeo.com", "youtu.be", "youtube.com")
_GOVERNMENT_HOST_SUFFIXES = ("adilet.zan.kz", "gov.kz", "sud.gov.kz")


@dataclass(frozen=True, slots=True)
class SourceCandidate:
    """A normalized public link that a product may attach to its own record."""

    url: str
    url_hash: str
    title: str
    publisher: str
    source_type: str


def canonicalize_source_url(value: object, *, base_url: str = "") -> str:
    """Return an absolute HTTP(S) URL without tracking parameters or fragments."""
    absolute = urljoin(base_url, str(value or "").strip())
    parsed = urlparse(absolute)
    if parsed.scheme.lower() not in {"http", "https"} or not parsed.hostname:
        return ""
    if parsed.hostname.casefold() == "l.facebook.com":
        redirect_target = dict(parse_qsl(parsed.query)).get("u")
        if redirect_target:
            return canonicalize_source_url(redirect_target)
    try:
        port = parsed.port
    except ValueError:
        return ""
    host = parsed.hostname.casefold().rstrip(".")
    netloc = host if port is None else f"{host}:{port}"
    query = [
        (key, item)
        for key, item in parse_qsl(parsed.query, keep_blank_values=True)
        if key.casefold() not in _TRACKING_PARAMS and not key.casefold().startswith("utm_")
    ]
    normalized = parsed._replace(
        scheme=parsed.scheme.casefold(),
        netloc=netloc,
        path=parsed.path or "/",
        query=urlencode(query, doseq=True),
        fragment="",
    )
    return urlunparse(normalized)


def publisher_from_url(url: object) -> str:
    """Return a normalized publisher host without a ``www.`` prefix."""
    return (urlparse(str(url or "")).hostname or "").casefold().removeprefix("www.")


def source_type_from_url(url: object) -> str:
    """Classify only broad transport categories, leaving editorial judgement to products."""
    host = publisher_from_url(url)
    if host.endswith(_VIDEO_HOST_SUFFIXES):
        return "video"
    if host.endswith(_SOCIAL_HOST_SUFFIXES):
        return "social"
    if host.endswith(_GOVERNMENT_HOST_SUFFIXES):
        return "gov_doc"
    return "article"


def extract_source_candidates_from_links(
    links: Iterable[Mapping[str, object]],
    *,
    base_url: str = "",
    excluded_hosts: Iterable[str] = (),
    generic_link_text: Iterable[str] = _GENERIC_LINK_TEXT,
    title_limit: int = 500,
) -> list[SourceCandidate]:
    """Create deduplicated candidates from neutral ``href``/``text`` link mappings.

    Product-specific exclusions and publication decisions stay with the caller.
    """
    if title_limit < 1:
        raise ValueError("title_limit must be positive")
    excluded = {str(host).casefold().removeprefix("www.") for host in excluded_hosts if str(host).strip()}
    generic = {str(value).casefold().strip() for value in generic_link_text if str(value).strip()}
    candidates: list[SourceCandidate] = []
    seen: set[str] = set()
    for link in links:
        url = canonicalize_source_url(link.get("href", ""), base_url=base_url)
        text = " ".join(str(link.get("text", "")).split())
        if not url or not text or url in seen:
            continue
        publisher = publisher_from_url(url)
        if not publisher or publisher in excluded:
            continue
        seen.add(url)
        candidates.append(
            SourceCandidate(
                url=url,
                url_hash=hashlib.sha256(url.encode("utf-8")).hexdigest(),
                title=publisher if text.casefold() in generic else text[:title_limit],
                publisher=publisher,
                source_type=source_type_from_url(url),
            )
        )
    return candidates
