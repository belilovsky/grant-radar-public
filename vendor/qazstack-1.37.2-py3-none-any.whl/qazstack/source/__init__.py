"""Portable source normalization and link-candidate primitives."""

from qazstack.source.links import (
    SourceCandidate,
    canonicalize_source_url,
    extract_source_candidates_from_links,
    publisher_from_url,
    source_type_from_url,
)

__all__ = [
    "SourceCandidate",
    "canonicalize_source_url",
    "extract_source_candidates_from_links",
    "publisher_from_url",
    "source_type_from_url",
]
