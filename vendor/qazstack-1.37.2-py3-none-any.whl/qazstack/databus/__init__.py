"""qazstack.databus – Cross-project data synchronization.

Provides sync pipelines between project databases:
- Echo Sounder → QazLake (articles, NLP, entities)
- QazLake → PSSR (signals feed)
- QazLake → Editorial (research bank)
- Entity Enricher: links entities across all projects to canonical_entities
"""

from importlib import import_module
from typing import Any

from qazstack.databus.contracts import (
    DataRunLedgerEntry,
    EntityMentionCandidate,
    EntityReviewRecord,
    EvidenceRecord,
    PrivacySafeEvidenceEnvelope,
    QualityScorecard,
    SourceWatermark,
)
from qazstack.databus.source_health import SourceHealthRecord, source_health_from_registry_row
from qazstack.databus.sync import SyncPipeline, SyncResult
from qazstack.databus.webhooks import (
    InMemoryReplayStore,
    ReplayStore,
    WebhookVerification,
    sign_webhook,
    verify_webhook,
)

__all__ = [
    "SyncPipeline",
    "SyncResult",
    "DataRunLedgerEntry",
    "EntityMentionCandidate",
    "EntityReviewRecord",
    "EvidenceRecord",
    "PrivacySafeEvidenceEnvelope",
    "QualityScorecard",
    "SourceWatermark",
    "EchoToLakeSync",
    "LakeToEditorialSync",
    "EntityEnricher",
    "SourceHealthRecord",
    "source_health_from_registry_row",
    "InMemoryReplayStore",
    "ReplayStore",
    "WebhookVerification",
    "sign_webhook",
    "verify_webhook",
]

# Optional: QazLakeSource requires pssr-regime-engine context

_LAZY_ADAPTERS = {
    "EchoToLakeSync": ("qazstack.databus.echo_to_lake", "EchoToLakeSync"),
    "EntityEnricher": ("qazstack.databus.entity_enricher", "EntityEnricher"),
    "LakeToEditorialSync": ("qazstack.databus.lake_to_editorial", "LakeToEditorialSync"),
}


def __getattr__(name: str) -> Any:
    """Load database adapters only when a consumer explicitly requests one."""
    target = _LAZY_ADAPTERS.get(name)
    if target is None:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
    module_name, attribute = target
    value = getattr(import_module(module_name), attribute)
    globals()[name] = value
    return value
