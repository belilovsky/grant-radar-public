"""Portable governance workflow contracts.

The platform has several products that need to report the same small set of
operational facts: what is being improved, which evidence was checked and what
needs a human decision.  This module models that boundary without assuming a
database, web framework or a particular product catalogue.

It intentionally does not schedule work, assign people or invent timestamps.
Consumers own those policies and can serialise the resulting snapshot into a
file, an API response or an audit record.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Literal

WORKFLOW_SCHEMA_VERSION = "qazstack-governance-workflow-v1"
_IDENTIFIER_PATTERN = re.compile(r"^[a-z0-9][a-z0-9._-]*$")
_SCORECARD_STATUSES = {"pass", "warning", "failure", "unknown"}
_ACTION_PRIORITIES = {"critical", "high", "medium", "low"}


def _require_identifier(value: str, field_name: str) -> str:
    cleaned = value.strip()
    if not _IDENTIFIER_PATTERN.fullmatch(cleaned):
        raise ValueError(f"{field_name} must be a lowercase identifier")
    return cleaned


def _require_text(value: str, field_name: str) -> str:
    cleaned = value.strip()
    if not cleaned:
        raise ValueError(f"{field_name} must not be blank")
    return cleaned


def _unique_text(values: tuple[str, ...], field_name: str) -> tuple[str, ...]:
    cleaned = tuple(_require_text(value, field_name) for value in values)
    if len(set(cleaned)) != len(cleaned):
        raise ValueError(f"{field_name} must not contain duplicates")
    return cleaned


@dataclass(frozen=True, slots=True)
class Initiative:
    """A bounded programme of improvement owned by a product.

    The completion criterion is deliberately mandatory: an initiative is not a
    decorative roadmap card if nobody can tell when it has been completed.
    """

    initiative_id: str
    title: str
    goal: str
    completion_criterion: str
    owner: str
    review_cadence: str
    evidence_refs: tuple[str, ...] = ()
    state: Literal["active", "ready", "paused", "complete"] = "active"

    def __post_init__(self) -> None:
        object.__setattr__(self, "initiative_id", _require_identifier(self.initiative_id, "initiative_id"))
        for field_name in ("title", "goal", "completion_criterion", "owner", "review_cadence"):
            object.__setattr__(self, field_name, _require_text(getattr(self, field_name), field_name))
        object.__setattr__(self, "evidence_refs", _unique_text(self.evidence_refs, "evidence_refs"))

    def as_dict(self) -> dict[str, Any]:
        return {
            "id": self.initiative_id,
            "title": self.title,
            "goal": self.goal,
            "completion_criterion": self.completion_criterion,
            "owner": self.owner,
            "review_cadence": self.review_cadence,
            "evidence_refs": list(self.evidence_refs),
            "state": self.state,
        }


@dataclass(frozen=True, slots=True)
class ScorecardResult:
    """One evidence-bound assessment, independent of a specific checker."""

    check_id: str
    title: str
    status: Literal["pass", "warning", "failure", "unknown"]
    summary: str
    evidence_refs: tuple[str, ...]
    owner: str | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "check_id", _require_identifier(self.check_id, "check_id"))
        object.__setattr__(self, "title", _require_text(self.title, "title"))
        if self.status not in _SCORECARD_STATUSES:
            raise ValueError(f"unsupported scorecard status: {self.status}")
        object.__setattr__(self, "summary", _require_text(self.summary, "summary"))
        refs = _unique_text(self.evidence_refs, "evidence_refs")
        if not refs:
            raise ValueError("evidence_refs must name at least one source")
        object.__setattr__(self, "evidence_refs", refs)
        if self.owner is not None:
            object.__setattr__(self, "owner", _require_text(self.owner, "owner"))

    @property
    def needs_action(self) -> bool:
        return self.status in {"warning", "failure"}

    def as_dict(self) -> dict[str, Any]:
        return {
            "id": self.check_id,
            "title": self.title,
            "status": self.status,
            "summary": self.summary,
            "evidence_refs": list(self.evidence_refs),
            "owner": self.owner,
        }


@dataclass(frozen=True, slots=True)
class ActionItem:
    """A traceable next step derived from an assessment or recorded manually."""

    action_id: str
    title: str
    priority: Literal["critical", "high", "medium", "low"]
    source_check_id: str | None = None
    owner: str | None = None
    evidence_refs: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        object.__setattr__(self, "action_id", _require_identifier(self.action_id, "action_id"))
        object.__setattr__(self, "title", _require_text(self.title, "title"))
        if self.priority not in _ACTION_PRIORITIES:
            raise ValueError(f"unsupported action priority: {self.priority}")
        if self.source_check_id is not None:
            object.__setattr__(self, "source_check_id", _require_identifier(self.source_check_id, "source_check_id"))
        if self.owner is not None:
            object.__setattr__(self, "owner", _require_text(self.owner, "owner"))
        object.__setattr__(self, "evidence_refs", _unique_text(self.evidence_refs, "evidence_refs"))

    def as_dict(self) -> dict[str, Any]:
        return {
            "id": self.action_id,
            "title": self.title,
            "priority": self.priority,
            "source_check_id": self.source_check_id,
            "owner": self.owner,
            "evidence_refs": list(self.evidence_refs),
        }


def action_from_scorecard(result: ScorecardResult, *, action_id: str, priority: str | None = None) -> ActionItem | None:
    """Derive one conservative action from a non-passing scorecard result.

    ``unknown`` is not turned into a task automatically: it means the consumer
    has not supplied enough evidence yet.  A product may choose to surface it
    separately, but it must not be silently promoted to a failure.
    """

    if not result.needs_action:
        return None
    resolved_priority = priority or ("high" if result.status == "failure" else "medium")
    return ActionItem(
        action_id=action_id,
        title=result.title,
        priority=resolved_priority,  # type: ignore[arg-type]
        source_check_id=result.check_id,
        owner=result.owner,
        evidence_refs=result.evidence_refs,
    )


@dataclass(frozen=True, slots=True)
class GovernanceSnapshot:
    """A deterministic, portable snapshot for a product or a delivery unit."""

    subject_id: str
    initiatives: tuple[Initiative, ...] = ()
    scorecards: tuple[ScorecardResult, ...] = ()
    actions: tuple[ActionItem, ...] = ()
    schema_version: str = WORKFLOW_SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        object.__setattr__(self, "subject_id", _require_identifier(self.subject_id, "subject_id"))
        for items, label, attr in (
            (self.initiatives, "initiative", "initiative_id"),
            (self.scorecards, "scorecard", "check_id"),
            (self.actions, "action", "action_id"),
        ):
            identifiers = [getattr(item, attr) for item in items]
            if len(set(identifiers)) != len(identifiers):
                raise ValueError(f"{label} identifiers must be unique")
        known_checks = {result.check_id for result in self.scorecards}
        for action in self.actions:
            if action.source_check_id and action.source_check_id not in known_checks:
                raise ValueError("action source_check_id must exist in scorecards")

    def as_dict(self) -> dict[str, Any]:
        ordered_initiatives = sorted(self.initiatives, key=lambda item: item.initiative_id)
        ordered_scorecards = sorted(self.scorecards, key=lambda item: item.check_id)
        ordered_actions = sorted(self.actions, key=lambda item: item.action_id)
        return {
            "schema_version": self.schema_version,
            "subject_id": self.subject_id,
            "summary": {
                "initiatives": len(ordered_initiatives),
                "scorecards": {
                    status: sum(item.status == status for item in ordered_scorecards)
                    for status in ("pass", "warning", "failure", "unknown")
                },
                "actions": len(ordered_actions),
            },
            "initiatives": [item.as_dict() for item in ordered_initiatives],
            "scorecards": [item.as_dict() for item in ordered_scorecards],
            "actions": [item.as_dict() for item in ordered_actions],
            "metadata": dict(sorted(self.metadata.items())),
        }
