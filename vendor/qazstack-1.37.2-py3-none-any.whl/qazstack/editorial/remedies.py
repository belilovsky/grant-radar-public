"""Correction, takedown and propagation contracts shared across products."""

from __future__ import annotations

from dataclasses import dataclass, replace
from datetime import datetime
from enum import Enum
from typing import Any, Mapping

from qazstack.contracts._validation import (
    require_aware,
    require_http_url,
    require_identifier,
    require_positive,
    require_sha256,
    require_text,
)

from .contracts import ContractValidationError, _optional_datetime, _references


class RemedyType(str, Enum):
    CORRECTION = "correction"
    CLARIFICATION = "clarification"
    RETRACTION = "retraction"
    UPDATE = "update"
    RESTRICTION = "restriction"
    RIGHT_OF_REPLY = "right-of-reply"
    TAKEDOWN = "takedown"


class RemedyStatus(str, Enum):
    REQUESTED = "requested"
    ACCEPTED = "accepted"
    IN_PROGRESS = "in-progress"
    PUBLISHED = "published"
    PROPAGATING = "propagating"
    COMPLETED = "completed"
    REJECTED = "rejected"
    CANCELLED = "cancelled"


class PropagationStatus(str, Enum):
    QUEUED = "queued"
    DELIVERED = "delivered"
    FAILED = "failed"
    NOT_APPLICABLE = "not-applicable"


REMEDY_TRANSITIONS: Mapping[RemedyStatus, frozenset[RemedyStatus]] = {
    RemedyStatus.REQUESTED: frozenset({RemedyStatus.ACCEPTED, RemedyStatus.REJECTED, RemedyStatus.CANCELLED}),
    RemedyStatus.ACCEPTED: frozenset({RemedyStatus.IN_PROGRESS, RemedyStatus.CANCELLED}),
    RemedyStatus.IN_PROGRESS: frozenset({RemedyStatus.PUBLISHED, RemedyStatus.CANCELLED}),
    RemedyStatus.PUBLISHED: frozenset({RemedyStatus.PROPAGATING, RemedyStatus.COMPLETED}),
    RemedyStatus.PROPAGATING: frozenset({RemedyStatus.COMPLETED}),
    RemedyStatus.COMPLETED: frozenset(),
    RemedyStatus.REJECTED: frozenset(),
    RemedyStatus.CANCELLED: frozenset(),
}


@dataclass(frozen=True, slots=True)
class EditorialRemedy:
    """Product-owned remedy state for one immutable article revision."""

    remedy_id: str
    article_id: str
    project_id: str
    policy_version: str
    content_fingerprint: str
    remedy_type: RemedyType
    status: RemedyStatus
    summary: str
    target_channels: tuple[str, ...]
    created_at: datetime
    updated_at: datetime
    version: int = 1
    source_decision_ref: str = ""
    public_record_url: str = ""
    last_reason: str = ""

    def __post_init__(self) -> None:
        try:
            require_identifier(self.remedy_id, "remedy_id")
            require_text(self.article_id, "article_id")
            require_identifier(self.project_id, "project_id")
            require_text(self.policy_version, "policy_version")
            object.__setattr__(
                self, "content_fingerprint", require_sha256(self.content_fingerprint, "content_fingerprint")
            )
            require_text(self.summary, "summary")
            require_aware(self.created_at, "created_at")
            require_aware(self.updated_at, "updated_at")
            require_positive(self.version, "version")
        except ValueError as exc:
            raise ContractValidationError(str(exc)) from exc
        if self.updated_at < self.created_at:
            raise ContractValidationError("updated_at must not precede created_at")
        if len(self.target_channels) != len(set(self.target_channels)):
            raise ContractValidationError("target_channels must not contain duplicates")
        for channel in self.target_channels:
            try:
                require_identifier(channel, "target_channels")
            except ValueError as exc:
                raise ContractValidationError(str(exc)) from exc
        if self.public_record_url:
            try:
                object.__setattr__(
                    self, "public_record_url", require_http_url(self.public_record_url, "public_record_url")
                )
            except ValueError as exc:
                raise ContractValidationError(str(exc)) from exc
        if self.status in {RemedyStatus.PUBLISHED, RemedyStatus.PROPAGATING, RemedyStatus.COMPLETED}:
            if self.remedy_type not in {RemedyType.RESTRICTION, RemedyType.TAKEDOWN} and not self.public_record_url:
                raise ContractValidationError("published remedies require a public record URL")

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "EditorialRemedy":
        required = (
            "remedyId",
            "articleId",
            "projectId",
            "policyVersion",
            "contentFingerprint",
            "type",
            "status",
            "summary",
            "createdAt",
            "updatedAt",
        )
        missing = [name for name in required if value.get(name) in (None, "")]
        if missing:
            raise ContractValidationError(f"missing remedy fields: {', '.join(missing)}")
        try:
            remedy_type = RemedyType(str(value["type"]))
            status = RemedyStatus(str(value["status"]))
        except ValueError as exc:
            raise ContractValidationError("remedy type or status is invalid") from exc
        return cls(
            remedy_id=str(value["remedyId"]),
            article_id=str(value["articleId"]),
            project_id=str(value["projectId"]),
            policy_version=str(value["policyVersion"]),
            content_fingerprint=str(value["contentFingerprint"]),
            remedy_type=remedy_type,
            status=status,
            summary=str(value["summary"]),
            target_channels=_references(value.get("targetChannels"), "targetChannels", 100),
            created_at=_optional_datetime(value["createdAt"], "createdAt") or datetime.min,
            updated_at=_optional_datetime(value["updatedAt"], "updatedAt") or datetime.min,
            version=int(value.get("version") or 1),
            source_decision_ref=str(value.get("sourceDecisionRef") or ""),
            public_record_url=str(value.get("publicRecordUrl") or ""),
            last_reason=str(value.get("lastReason") or ""),
        )

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "remedyId": self.remedy_id,
            "articleId": self.article_id,
            "projectId": self.project_id,
            "policyVersion": self.policy_version,
            "contentFingerprint": self.content_fingerprint,
            "type": self.remedy_type.value,
            "status": self.status.value,
            "summary": self.summary,
            "targetChannels": list(self.target_channels),
            "createdAt": self.created_at.isoformat(),
            "updatedAt": self.updated_at.isoformat(),
            "version": self.version,
        }
        optional = {
            "sourceDecisionRef": self.source_decision_ref,
            "publicRecordUrl": self.public_record_url,
            "lastReason": self.last_reason,
        }
        payload.update({key: value for key, value in optional.items() if value})
        return payload


@dataclass(frozen=True, slots=True)
class PropagationReceipt:
    """Qposter or channel-owned receipt without message bodies or credentials."""

    remedy_id: str
    channel: str
    status: PropagationStatus
    attempted_at: datetime
    completed_at: datetime | None = None
    external_ref: str = ""
    error_code: str = ""

    def __post_init__(self) -> None:
        try:
            require_identifier(self.remedy_id, "remedy_id")
            require_identifier(self.channel, "channel")
            require_aware(self.attempted_at, "attempted_at")
        except ValueError as exc:
            raise ContractValidationError(str(exc)) from exc
        if self.completed_at is not None:
            try:
                require_aware(self.completed_at, "completed_at")
            except ValueError as exc:
                raise ContractValidationError(str(exc)) from exc
            if self.completed_at < self.attempted_at:
                raise ContractValidationError("completed_at must not precede attempted_at")
        if self.status in {PropagationStatus.DELIVERED, PropagationStatus.NOT_APPLICABLE}:
            if self.completed_at is None:
                raise ContractValidationError("terminal propagation status requires completed_at")
            if self.error_code:
                raise ContractValidationError("successful propagation must not include error_code")
        if self.status is PropagationStatus.FAILED and not self.error_code:
            raise ContractValidationError("failed propagation requires error_code")

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "PropagationReceipt":
        try:
            status = PropagationStatus(str(value.get("status") or ""))
        except ValueError as exc:
            raise ContractValidationError("propagation status is invalid") from exc
        attempted = _optional_datetime(value.get("attemptedAt"), "attemptedAt")
        if attempted is None:
            raise ContractValidationError("attemptedAt is required")
        return cls(
            remedy_id=str(value.get("remedyId") or ""),
            channel=str(value.get("channel") or ""),
            status=status,
            attempted_at=attempted,
            completed_at=_optional_datetime(value.get("completedAt"), "completedAt"),
            external_ref=str(value.get("externalRef") or ""),
            error_code=str(value.get("errorCode") or ""),
        )


@dataclass(frozen=True, slots=True)
class RemedyEvaluation:
    complete: bool
    findings: tuple[str, ...]


def evaluate_remedy(
    remedy: EditorialRemedy,
    receipts: tuple[PropagationReceipt, ...] = (),
) -> RemedyEvaluation:
    """Check publication and channel obligations without sending anything."""
    findings: list[str] = []
    receipt_by_channel: dict[str, PropagationReceipt] = {}
    for receipt in receipts:
        if receipt.remedy_id != remedy.remedy_id:
            findings.append("receipt-remedy-mismatch")
            continue
        if receipt.channel in receipt_by_channel:
            findings.append(f"duplicate-receipt:{receipt.channel}")
        receipt_by_channel[receipt.channel] = receipt
    for channel in remedy.target_channels:
        receipt = receipt_by_channel.get(channel)
        if receipt is None:
            findings.append(f"propagation-missing:{channel}")
        elif receipt.status not in {PropagationStatus.DELIVERED, PropagationStatus.NOT_APPLICABLE}:
            findings.append(f"propagation-incomplete:{channel}")
    if remedy.status is RemedyStatus.COMPLETED and findings:
        findings.insert(0, "completed-remedy-has-open-obligations")
    return RemedyEvaluation(not findings, tuple(findings))


def apply_remedy_transition(
    remedy: EditorialRemedy,
    target: RemedyStatus,
    *,
    expected_version: int,
    updated_at: datetime,
    reason: str,
    public_record_url: str | None = None,
) -> EditorialRemedy:
    """Apply an optimistic, storage-neutral remedy lifecycle transition."""
    if expected_version != remedy.version:
        raise ContractValidationError("remedy version conflict")
    if target not in REMEDY_TRANSITIONS[remedy.status]:
        raise ContractValidationError(f"invalid remedy transition: {remedy.status.value} -> {target.value}")
    try:
        require_aware(updated_at, "updated_at")
        require_text(reason, "reason")
    except ValueError as exc:
        raise ContractValidationError(str(exc)) from exc
    if updated_at < remedy.updated_at:
        raise ContractValidationError("updated_at must not move backwards")
    if public_record_url is not None and target is not RemedyStatus.PUBLISHED:
        raise ContractValidationError("public_record_url can only be set when publishing a remedy")
    return replace(
        remedy,
        status=target,
        updated_at=updated_at,
        version=remedy.version + 1,
        last_reason=reason,
        public_record_url=public_record_url if public_record_url is not None else remedy.public_record_url,
    )


def public_correction_record(
    remedy: EditorialRemedy,
    *,
    article_url: str,
    published_at: datetime,
    receipts: tuple[PropagationReceipt, ...] = (),
    visibility: str = "article-and-log",
) -> dict[str, Any]:
    """Build the reader-facing subset used by public correction logs."""
    if remedy.status not in {RemedyStatus.PUBLISHED, RemedyStatus.PROPAGATING, RemedyStatus.COMPLETED}:
        raise ContractValidationError("public correction record requires a published remedy")
    if visibility not in {"article-and-log", "article-only-safety-exception"}:
        raise ContractValidationError("visibility is invalid")
    try:
        article_url = require_http_url(article_url, "article_url")
        require_aware(published_at, "published_at")
    except ValueError as exc:
        raise ContractValidationError(str(exc)) from exc
    delivered = sorted(receipt.channel for receipt in receipts if receipt.status is PropagationStatus.DELIVERED)
    return {
        "id": remedy.remedy_id,
        "publishedAt": published_at.isoformat(),
        "articleUrl": article_url,
        "type": remedy.remedy_type.value,
        "summary": remedy.summary,
        "visibility": visibility,
        "distribution": delivered,
        "sourceDecisionRef": remedy.source_decision_ref,
    }
