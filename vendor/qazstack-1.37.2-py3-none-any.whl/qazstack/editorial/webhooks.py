"""Replay-safe signed webhook profile for metadata-only editorial events."""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Mapping

from qazstack.databus import ReplayStore, WebhookVerification, sign_webhook, verify_webhook

from .contracts import ContractValidationError, EditorialEvent

EDITORIAL_WEBHOOK_SCHEMA_VERSION = "qazstack-editorial-webhook-v1"
EDITORIAL_TIMESTAMP_HEADER = "x-qazstack-timestamp"
EDITORIAL_SIGNATURE_HEADER = "x-qazstack-signature"
EDITORIAL_EVENT_ID_HEADER = "x-qazstack-event-id"
EDITORIAL_IDEMPOTENCY_HEADER = "idempotency-key"


@dataclass(frozen=True, slots=True)
class EditorialWebhookEnvelope:
    """Canonical wrapper around one transport-neutral editorial event."""

    event: EditorialEvent
    schema_version: str = EDITORIAL_WEBHOOK_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.schema_version != EDITORIAL_WEBHOOK_SCHEMA_VERSION:
            raise ContractValidationError(f"schema_version must be {EDITORIAL_WEBHOOK_SCHEMA_VERSION}")

    @classmethod
    def from_dict(
        cls,
        value: Mapping[str, Any],
        *,
        allowed_types: set[str] | None = None,
    ) -> "EditorialWebhookEnvelope":
        if set(value) - {"schema_version", "event"}:
            raise ContractValidationError("editorial webhook contains unknown fields")
        raw_event = value.get("event")
        if not isinstance(raw_event, Mapping):
            raise ContractValidationError("editorial webhook event must be an object")
        return cls(
            schema_version=str(value.get("schema_version") or ""),
            event=EditorialEvent.from_dict(raw_event, allowed_types=allowed_types),
        )

    def to_dict(self) -> dict[str, Any]:
        event: dict[str, Any] = {
            "eventId": self.event.event_id,
            "type": self.event.type,
            "occurredAt": self.event.occurred_at.isoformat(),
            "projectId": self.event.project_id,
            "producer": self.event.producer,
            "data": dict(self.event.data),
        }
        if self.event.correlation_id:
            event["correlationId"] = self.event.correlation_id
        return {"schema_version": self.schema_version, "event": event}

    def canonical_bytes(self) -> bytes:
        return json.dumps(self.to_dict(), ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()


@dataclass(frozen=True, slots=True)
class EditorialWebhookResult:
    verification: WebhookVerification
    envelope: EditorialWebhookEnvelope | None = None
    reason: str = ""


def sign_editorial_webhook(
    envelope: EditorialWebhookEnvelope,
    *,
    timestamp: int,
    secret: str,
) -> str:
    return sign_webhook(envelope.canonical_bytes(), timestamp=timestamp, secret=secret)


def verify_editorial_webhook(
    payload: bytes,
    *,
    timestamp: int,
    signature: str,
    secrets: tuple[str, ...],
    replay_store: ReplayStore | None = None,
    now: int | None = None,
    allowed_types: set[str] | None = None,
) -> EditorialWebhookResult:
    """Verify signature and replay state before decoding an event body."""
    verification = verify_webhook(
        payload,
        timestamp=timestamp,
        signature=signature,
        secrets=secrets,
        replay_store=replay_store,
        now=now,
    )
    if not verification.valid:
        return EditorialWebhookResult(verification=verification, reason=verification.reason)
    try:
        decoded = json.loads(payload)
        if not isinstance(decoded, Mapping):
            raise ContractValidationError("editorial webhook must be an object")
        envelope = EditorialWebhookEnvelope.from_dict(decoded, allowed_types=allowed_types)
    except (json.JSONDecodeError, ContractValidationError) as exc:
        return EditorialWebhookResult(
            verification=verification,
            reason=f"invalid_envelope: {exc}",
        )
    return EditorialWebhookResult(verification=verification, envelope=envelope, reason="verified")


def editorial_webhook_headers(
    envelope: EditorialWebhookEnvelope,
    *,
    timestamp: int,
    signature: str,
) -> dict[str, str]:
    if not signature.startswith("v1="):
        raise ValueError("signature must use v1 format")
    return {
        "Content-Type": "application/json",
        EDITORIAL_TIMESTAMP_HEADER: str(timestamp),
        EDITORIAL_SIGNATURE_HEADER: signature,
        EDITORIAL_EVENT_ID_HEADER: envelope.event.event_id,
        EDITORIAL_IDEMPOTENCY_HEADER: envelope.event.event_id,
    }


def parse_editorial_webhook_headers(headers: Mapping[str, str]) -> tuple[int, str, str]:
    """Return timestamp, signature and event id from case-insensitive headers."""
    normalized = {key.lower(): value for key, value in headers.items()}
    try:
        timestamp = int(normalized[EDITORIAL_TIMESTAMP_HEADER])
    except (KeyError, ValueError) as exc:
        raise ValueError("missing or invalid x-qazstack-timestamp") from exc
    signature = normalized.get(EDITORIAL_SIGNATURE_HEADER, "")
    event_id = normalized.get(EDITORIAL_EVENT_ID_HEADER, "")
    idempotency_key = normalized.get(EDITORIAL_IDEMPOTENCY_HEADER, "")
    if not signature:
        raise ValueError("missing x-qazstack-signature")
    if not event_id or idempotency_key != event_id:
        raise ValueError("event id and idempotency key must match")
    return timestamp, signature, event_id
