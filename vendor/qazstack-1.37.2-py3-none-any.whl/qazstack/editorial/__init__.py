"""
qazstack.editorial
==================
Модуль AI-авторов: генерация редакционных материалов с контролем стиля.

Пример использования:
    from editorial import EditorialOrchestrator, ResearchBank
    from editorial import AuthorProfile, GenerationTask, GenerationResult
    from editorial import StyleAnalyzer, AuthorManager

    manager = AuthorManager(session_factory)
    bank = ResearchBank(qazlake_session_factory, compute_client)

    orchestrator = EditorialOrchestrator(
        research_bank=bank,
        prompt_builder=PromptBuilder(),
        llm_router=OpenAIClient(api_key=settings.openai_api_key),
        scoring_loop=ScoringLoop(),
        author_manager=manager,
        db_session_factory=editorial_session_factory,
    )

    result = await orchestrator.generate(GenerationTask(
        author_id="analyst_daurenov_01",
        brief="Анализ итогов бюджетного года 2025",
        task_type="analysis",
        lang="ru",
        target_word_count=800,
    ))
    print(result.status, result.overall_score)
"""

from __future__ import annotations

from .casework import EditorialCase, EditorialChecks, evaluate_editorial_case
from .clustering import (
    ArticleCandidate,
    ClusterDecision,
    ClusterPolicy,
    StoryCandidate,
    evaluate_story_attachment,
    story_tokens,
)
from .contracts import (
    AiDisclosure,
    ContractValidationError,
    EditorialDecision,
    EditorialDecisionState,
    EditorialEvent,
    LanguageParity,
    verify_hmac_sha256,
)
from .policy import EditorialPipeline, EditorialPolicyBundle, PipelineStage
from .quality_gate import GateEvaluation, GateFinding, evaluate_quality_gate
from .remedies import (
    EditorialRemedy,
    PropagationReceipt,
    PropagationStatus,
    RemedyEvaluation,
    RemedyStatus,
    RemedyType,
    apply_remedy_transition,
    evaluate_remedy,
    public_correction_record,
)
from .review import ReviewDecision, ReviewItem
from .rules import DecisionFacts, GatePredicate, GateRule, QualityGatePolicy
from .scorecard import (
    EditorialScorecard,
    EditorialScorePolicy,
    QualityDimension,
    QualityFinding,
    score_editorial_item,
)
from .trust import ArticleTrustMetadata
from .webhooks import (
    EDITORIAL_WEBHOOK_SCHEMA_VERSION,
    EditorialWebhookEnvelope,
    EditorialWebhookResult,
    editorial_webhook_headers,
    parse_editorial_webhook_headers,
    sign_editorial_webhook,
    verify_editorial_webhook,
)

# The policy contracts are dependency-free.  Keep the generative editorial
# runtime optional so CMS adapters can import this package without SQLAlchemy,
# LLM clients, or NLP extras installed.
AuthorProfile = GenerationResult = GenerationTask = ScoringResult = StyleProfile = None
EditorialOrchestrator = ResearchBank = ResearchDocument = None
StyleAnalyzer = AuthorManager = None

try:
    from .models import (
        AuthorProfile,
        GenerationResult,
        GenerationTask,
        ScoringResult,
        StyleProfile,
    )
except (ImportError, TypeError):
    pass

try:
    from .orchestrator import EditorialOrchestrator
    from .research_bank import ResearchBank, ResearchDocument
except (ImportError, TypeError):
    pass

try:
    from .style_analyzer import StyleAnalyzer
except (ImportError, TypeError):
    pass

try:
    from .author_manager import AuthorManager
except (ImportError, TypeError):
    pass

__all__ = [
    # Pydantic модели
    "AuthorProfile",
    "GenerationTask",
    "GenerationResult",
    "ScoringResult",
    "StyleProfile",
    # Ключевые классы
    "EditorialOrchestrator",
    "ResearchBank",
    "ResearchDocument",
    "StyleAnalyzer",
    "AuthorManager",
    # Cross-project policy and quality-gate contracts
    "AiDisclosure",
    "ContractValidationError",
    "EditorialDecision",
    "EditorialDecisionState",
    "EditorialEvent",
    "EditorialCase",
    "EditorialChecks",
    "EditorialPipeline",
    "EditorialPolicyBundle",
    "PipelineStage",
    "LanguageParity",
    "GateEvaluation",
    "GateFinding",
    "DecisionFacts",
    "GatePredicate",
    "GateRule",
    "QualityGatePolicy",
    "evaluate_quality_gate",
    "evaluate_editorial_case",
    "verify_hmac_sha256",
    "EditorialRemedy",
    "PropagationReceipt",
    "PropagationStatus",
    "RemedyEvaluation",
    "RemedyStatus",
    "RemedyType",
    "apply_remedy_transition",
    "evaluate_remedy",
    "public_correction_record",
    "ArticleTrustMetadata",
    "EDITORIAL_WEBHOOK_SCHEMA_VERSION",
    "EditorialWebhookEnvelope",
    "EditorialWebhookResult",
    "editorial_webhook_headers",
    "parse_editorial_webhook_headers",
    "sign_editorial_webhook",
    "verify_editorial_webhook",
    "ReviewDecision",
    "ReviewItem",
    "ArticleCandidate",
    "ClusterDecision",
    "ClusterPolicy",
    "StoryCandidate",
    "evaluate_story_attachment",
    "story_tokens",
    "EditorialScorePolicy",
    "EditorialScorecard",
    "QualityDimension",
    "QualityFinding",
    "score_editorial_item",
]

__version__ = "0.3.2"
