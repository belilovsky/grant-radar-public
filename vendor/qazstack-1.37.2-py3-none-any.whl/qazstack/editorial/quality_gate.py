"""Deterministic quality-gate evaluator for CMS integrations.

This module evaluates only metadata supplied by a CMS.  It is intentionally
not an AI fact checker and it never dereferences evidence links.
"""

from __future__ import annotations

from dataclasses import dataclass

from .contracts import EditorialDecision, EditorialDecisionState
from .rules import DEFAULT_EDITORIAL_RULES, DecisionFacts, GateRule, QualityGatePolicy


@dataclass(frozen=True)
class GateFinding:
    code: str
    state: EditorialDecisionState
    message: str


@dataclass(frozen=True)
class GateEvaluation:
    computed_state: EditorialDecisionState
    findings: tuple[GateFinding, ...]

    @property
    def is_ready(self) -> bool:
        return self.computed_state is EditorialDecisionState.READY


def evaluate_quality_gate(
    decision: EditorialDecision,
    *,
    policy: QualityGatePolicy | None = None,
    rules: tuple[GateRule, ...] | None = None,
) -> GateEvaluation:
    """Calculate the safest next state from explicit editorial metadata.

    ``blocked`` and ``draft`` are deliberate operator states and are preserved;
    otherwise missing evidence precedes missing review in the resulting state.
    """
    if decision.decision is EditorialDecisionState.BLOCKED:
        return GateEvaluation(EditorialDecisionState.BLOCKED, ())
    if decision.decision is EditorialDecisionState.DRAFT:
        return GateEvaluation(EditorialDecisionState.DRAFT, ())

    findings: list[GateFinding] = []
    if policy is not None:
        if policy.project_id != decision.project_id or policy.policy_version != decision.policy_version:
            return GateEvaluation(
                EditorialDecisionState.BLOCKED,
                (
                    GateFinding(
                        "policy-mismatch",
                        EditorialDecisionState.BLOCKED,
                        "The decision project and policy version must match the selected quality gate.",
                    ),
                ),
            )
        selected_rules = policy.rules
    else:
        selected_rules = rules or DEFAULT_EDITORIAL_RULES

    facts = DecisionFacts.from_decision(decision)
    for rule in selected_rules:
        if rule.matches(facts):
            findings.append(GateFinding(rule.rule_id, rule.state, rule.message))

    if any(item.state is EditorialDecisionState.BLOCKED for item in findings):
        state = EditorialDecisionState.BLOCKED
    elif any(item.state is EditorialDecisionState.NEEDS_EVIDENCE for item in findings):
        state = EditorialDecisionState.NEEDS_EVIDENCE
    elif findings:
        state = EditorialDecisionState.NEEDS_REVIEW
    else:
        state = EditorialDecisionState.READY
    return GateEvaluation(state, tuple(findings))
