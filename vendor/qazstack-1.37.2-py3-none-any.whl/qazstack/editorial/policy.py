"""Versioned, provider-neutral editorial policy and pipeline contracts."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Mapping

from qazstack.contracts._validation import (
    require_aware,
    require_http_url,
    require_identifier,
    require_positive,
    require_text,
)

from .contracts import ContractValidationError

PIPELINE_STAGE_STATUSES = frozenset({"active", "requires-input", "disabled"})


def _aware_datetime(value: Any, field_name: str) -> datetime:
    if not isinstance(value, str):
        raise ContractValidationError(f"{field_name} must be ISO-8601")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ContractValidationError(f"{field_name} must be ISO-8601") from exc
    try:
        require_aware(parsed, field_name)
    except ValueError as exc:
        raise ContractValidationError(str(exc)) from exc
    return parsed


def _unique_texts(value: Any, field_name: str, maximum: int) -> tuple[str, ...]:
    if value is None:
        return ()
    if not isinstance(value, list) or len(value) > maximum:
        raise ContractValidationError(f"{field_name} must be an array of at most {maximum} values")
    result = tuple(str(item) for item in value)
    if len(result) != len(set(result)) or any(not item.strip() for item in result):
        raise ContractValidationError(f"{field_name} must contain unique non-empty strings")
    return result


@dataclass(frozen=True, slots=True)
class PipelineStage:
    """One product-owned workflow stage described by a shared policy."""

    stage_id: str
    name: str
    owner: str
    sla_hours: float
    status: str = "active"
    artifacts: tuple[str, ...] = ()
    depends_on: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        try:
            require_identifier(self.stage_id, "stage_id")
            require_text(self.name, "name")
            require_identifier(self.owner, "owner")
            require_positive(self.sla_hours, "sla_hours")
        except ValueError as exc:
            raise ContractValidationError(str(exc)) from exc
        if self.status not in PIPELINE_STAGE_STATUSES:
            raise ContractValidationError("stage status is invalid")
        if len(self.artifacts) != len(set(self.artifacts)):
            raise ContractValidationError("stage artifacts must not contain duplicates")
        if len(self.depends_on) != len(set(self.depends_on)) or self.stage_id in self.depends_on:
            raise ContractValidationError("stage dependencies are invalid")
        for artifact in self.artifacts:
            try:
                require_identifier(artifact, "artifact")
            except ValueError as exc:
                raise ContractValidationError(str(exc)) from exc
        for dependency in self.depends_on:
            try:
                require_identifier(dependency, "depends_on")
            except ValueError as exc:
                raise ContractValidationError(str(exc)) from exc

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "PipelineStage":
        try:
            stage_id = str(value["id"])
            name = str(value["name"])
            owner = str(value["owner"])
            sla_hours = float(value["sla_hours"])
        except (KeyError, TypeError, ValueError) as exc:
            raise ContractValidationError("pipeline stage requires id, name, owner and sla_hours") from exc
        return cls(
            stage_id=stage_id,
            name=name,
            owner=owner,
            sla_hours=sla_hours,
            status=str(value.get("status") or "active"),
            artifacts=_unique_texts(value.get("artifacts"), "artifacts", 100),
            depends_on=_unique_texts(value.get("depends_on"), "depends_on", 50),
        )

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "id": self.stage_id,
            "name": self.name,
            "owner": self.owner,
            "sla_hours": self.sla_hours,
            "status": self.status,
            "artifacts": list(self.artifacts),
        }
        if self.depends_on:
            payload["depends_on"] = list(self.depends_on)
        return payload


@dataclass(frozen=True, slots=True)
class EditorialPipeline:
    """Acyclic workflow definition with product-owned SLAs and artifacts."""

    schema_version: str
    project_id: str
    updated_at: datetime
    stages: tuple[PipelineStage, ...]
    sla_minutes: tuple[tuple[str, int], ...] = ()

    def __post_init__(self) -> None:
        try:
            require_text(self.schema_version, "schema_version")
            require_identifier(self.project_id, "project_id")
            require_aware(self.updated_at, "updated_at")
        except ValueError as exc:
            raise ContractValidationError(str(exc)) from exc
        if not self.stages:
            raise ContractValidationError("pipeline requires at least one stage")
        stage_ids = tuple(stage.stage_id for stage in self.stages)
        if len(stage_ids) != len(set(stage_ids)):
            raise ContractValidationError("pipeline stage ids must be unique")
        known = set(stage_ids)
        if any(dependency not in known for stage in self.stages for dependency in stage.depends_on):
            raise ContractValidationError("pipeline dependency references an unknown stage")
        if len(self.sla_minutes) != len(dict(self.sla_minutes)):
            raise ContractValidationError("sla_minutes keys must be unique")
        for key, minutes in self.sla_minutes:
            try:
                require_identifier(key, "sla_minutes key")
                require_positive(minutes, "sla_minutes")
            except ValueError as exc:
                raise ContractValidationError(str(exc)) from exc
        self.ordered_stage_ids()

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "EditorialPipeline":
        raw_stages = value.get("stages")
        if not isinstance(raw_stages, list):
            raise ContractValidationError("stages must be an array")
        raw_sla = value.get("sla_minutes") or {}
        if not isinstance(raw_sla, Mapping):
            raise ContractValidationError("sla_minutes must be an object")
        try:
            sla_minutes = tuple(sorted((str(key), int(minutes)) for key, minutes in raw_sla.items()))
        except (TypeError, ValueError) as exc:
            raise ContractValidationError("sla_minutes values must be integers") from exc
        updated = value.get("updated_iso") or value.get("updatedAt")
        if not updated:
            updated = f"{value.get('updated', '')}T00:00:00Z"
        return cls(
            schema_version=str(value.get("schema_version") or ""),
            project_id=str(value.get("project_id") or ""),
            updated_at=_aware_datetime(updated, "updated_at"),
            stages=tuple(PipelineStage.from_dict(item) for item in raw_stages if isinstance(item, Mapping)),
            sla_minutes=sla_minutes,
        )

    def ordered_stage_ids(self) -> tuple[str, ...]:
        """Return a stable topological order or reject a cyclic pipeline."""
        dependencies = {stage.stage_id: set(stage.depends_on) for stage in self.stages}
        order: list[str] = []
        while dependencies:
            ready = sorted(stage_id for stage_id, required in dependencies.items() if not required)
            if not ready:
                raise ContractValidationError("pipeline dependencies must be acyclic")
            order.extend(ready)
            for stage_id in ready:
                dependencies.pop(stage_id)
            for required in dependencies.values():
                required.difference_update(ready)
        return tuple(order)

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "project_id": self.project_id,
            "updated_iso": self.updated_at.isoformat(),
            "sla_minutes": dict(self.sla_minutes),
            "stages": [stage.to_dict() for stage in self.stages],
        }


@dataclass(frozen=True, slots=True)
class EditorialPolicyBundle:
    """Discovery metadata for one immutable editorial policy version."""

    schema_version: str
    project_id: str
    project_name: str
    policy_version: str
    policy_status: str
    updated_at: datetime
    site_url: str
    endpoints: tuple[tuple[str, str], ...]
    critical_section_ids: tuple[str, ...] = ()
    public_section_ids: tuple[str, ...] = ()
    effective_at: datetime | None = None
    supersedes: str | None = None

    def __post_init__(self) -> None:
        try:
            require_text(self.schema_version, "schema_version")
            require_identifier(self.project_id, "project_id")
            require_text(self.project_name, "project_name")
            require_text(self.policy_version, "policy_version")
            require_identifier(self.policy_status, "policy_status")
            require_aware(self.updated_at, "updated_at")
            object.__setattr__(self, "site_url", require_http_url(self.site_url, "site_url"))
        except ValueError as exc:
            raise ContractValidationError(str(exc)) from exc
        if self.effective_at is not None:
            try:
                require_aware(self.effective_at, "effective_at")
            except ValueError as exc:
                raise ContractValidationError(str(exc)) from exc
        if len(self.endpoints) != len(dict(self.endpoints)) or not self.endpoints:
            raise ContractValidationError("endpoints must have unique names and may not be empty")
        for key, url in self.endpoints:
            try:
                require_identifier(key, "endpoint name")
                require_http_url(url, f"endpoint {key}")
            except ValueError as exc:
                raise ContractValidationError(str(exc)) from exc
        for field_name, values in (
            ("critical_section_ids", self.critical_section_ids),
            ("public_section_ids", self.public_section_ids),
        ):
            if len(values) != len(set(values)):
                raise ContractValidationError(f"{field_name} must not contain duplicates")
            for section_id in values:
                try:
                    require_identifier(section_id, field_name)
                except ValueError as exc:
                    raise ContractValidationError(str(exc)) from exc

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "EditorialPolicyBundle":
        endpoints = value.get("endpoints")
        if not isinstance(endpoints, Mapping):
            raise ContractValidationError("endpoints must be an object")
        sections = value.get("sections") or {}
        if not isinstance(sections, Mapping):
            raise ContractValidationError("sections must be an object")
        updated = value.get("updated_iso") or value.get("updatedAt")
        if not updated:
            updated = f"{value.get('updated', '')}T00:00:00Z"
        effective = value.get("effective_at") or value.get("effectiveAt")
        return cls(
            schema_version=str(value.get("schema_version") or ""),
            project_id=str(value.get("project_id") or ""),
            project_name=str(value.get("project_name") or ""),
            policy_version=str(value.get("policy_version") or ""),
            policy_status=str(value.get("policy_status") or ""),
            updated_at=_aware_datetime(updated, "updated_at"),
            site_url=str(value.get("site_url") or ""),
            endpoints=tuple(sorted((str(key), str(url)) for key, url in endpoints.items())),
            critical_section_ids=_unique_texts(sections.get("critical_ids"), "critical_ids", 500),
            public_section_ids=_unique_texts(sections.get("public_sections"), "public_sections", 500),
            effective_at=_aware_datetime(effective, "effective_at") if effective else None,
            supersedes=str(value["supersedes"]) if value.get("supersedes") else None,
        )

    def applies_to(self, project_id: str, policy_version: str) -> bool:
        return self.project_id == project_id and self.policy_version == policy_version

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "schema_version": self.schema_version,
            "project_id": self.project_id,
            "project_name": self.project_name,
            "policy_version": self.policy_version,
            "policy_status": self.policy_status,
            "updated_iso": self.updated_at.isoformat(),
            "site_url": self.site_url,
            "endpoints": dict(self.endpoints),
            "sections": {
                "critical_ids": list(self.critical_section_ids),
                "public_sections": list(self.public_section_ids),
            },
        }
        if self.effective_at is not None:
            payload["effective_at"] = self.effective_at.isoformat()
        if self.supersedes:
            payload["supersedes"] = self.supersedes
        return payload

    @property
    def digest(self) -> str:
        canonical = json.dumps(self.to_dict(), ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
        return f"sha256:{hashlib.sha256(canonical).hexdigest()}"
