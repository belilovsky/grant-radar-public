"""Closed declarative rule vocabulary for editorial quality gates."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

from qazstack.contracts._validation import require_identifier, require_one_of, require_text

from .contracts import ContractValidationError, EditorialDecision, EditorialDecisionState

RULE_FIELDS = frozenset(
    {
        "ai_disclosure",
        "completed_capture_count",
        "evidence_count",
        "language_parity",
        "legacy_evidence_count",
        "reviewer_count",
        "risk_level",
        "stale_evidence_count",
        "typed_evidence_count",
    }
)
RULE_OPERATORS = frozenset({"eq", "neq", "in", "not-in", "gt", "gte", "lt", "lte"})
RULE_MATCH_MODES = frozenset({"all", "any"})
RULE_SEVERITIES = frozenset({"block", "review", "advisory"})


@dataclass(frozen=True, slots=True)
class DecisionFacts:
    """Bounded facts available to the rule engine; no article text is exposed."""

    evidence_count: int
    typed_evidence_count: int
    legacy_evidence_count: int
    completed_capture_count: int
    stale_evidence_count: int
    reviewer_count: int
    ai_disclosure: str | None
    risk_level: str | None
    language_parity: str | None

    @classmethod
    def from_decision(cls, decision: EditorialDecision) -> "DecisionFacts":
        return cls(
            evidence_count=len(decision.evidence) + len(decision.evidence_refs),
            typed_evidence_count=len(decision.evidence),
            legacy_evidence_count=len(decision.evidence_refs),
            completed_capture_count=sum(item.capture_status == "completed" for item in decision.evidence),
            stale_evidence_count=sum(item.freshness_status == "stale" for item in decision.evidence),
            reviewer_count=len(decision.reviewer_ids),
            ai_disclosure=decision.ai_disclosure.value if decision.ai_disclosure else None,
            risk_level=decision.risk_level,
            language_parity=decision.language_parity.value if decision.language_parity else None,
        )

    def value(self, field_name: str) -> Any:
        if field_name not in RULE_FIELDS:
            raise ContractValidationError(f"unsupported rule field: {field_name}")
        return getattr(self, field_name)


@dataclass(frozen=True, slots=True)
class GatePredicate:
    """One comparison from the closed editorial metadata vocabulary."""

    field: str
    operator: str
    value: Any

    def __post_init__(self) -> None:
        if self.field not in RULE_FIELDS:
            raise ContractValidationError(f"unsupported rule field: {self.field}")
        if self.operator not in RULE_OPERATORS:
            raise ContractValidationError(f"unsupported rule operator: {self.operator}")
        if self.operator in {"in", "not-in"}:
            if not isinstance(self.value, (list, tuple)) or not self.value:
                raise ContractValidationError(f"operator {self.operator} requires a non-empty array")
        elif isinstance(self.value, (dict, list, tuple, set)):
            raise ContractValidationError(f"operator {self.operator} requires a scalar value")
        if self.operator in {"gt", "gte", "lt", "lte"} and not isinstance(self.value, (int, float)):
            raise ContractValidationError(f"operator {self.operator} requires a numeric value")

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "GatePredicate":
        return cls(
            field=str(value.get("field") or ""),
            operator=str(value.get("operator") or ""),
            value=value.get("value"),
        )

    def matches(self, facts: DecisionFacts) -> bool:
        actual = facts.value(self.field)
        if self.operator == "eq":
            return actual == self.value
        if self.operator == "neq":
            return actual != self.value
        if self.operator == "in":
            return actual in self.value
        if self.operator == "not-in":
            return actual not in self.value
        if not isinstance(actual, (int, float)):
            return False
        if self.operator == "gt":
            return actual > self.value
        if self.operator == "gte":
            return actual >= self.value
        if self.operator == "lt":
            return actual < self.value
        return actual <= self.value

    def to_dict(self) -> dict[str, Any]:
        value = list(self.value) if isinstance(self.value, tuple) else self.value
        return {"field": self.field, "operator": self.operator, "value": value}


@dataclass(frozen=True, slots=True)
class GateRule:
    """A finding emitted when its bounded predicates match."""

    rule_id: str
    state: EditorialDecisionState
    message: str
    predicates: tuple[GatePredicate, ...]
    match: str = "all"
    severity: str = "review"
    stage: str = "factcheck"
    owner: str = "editorial-checker"

    def __post_init__(self) -> None:
        try:
            require_identifier(self.rule_id, "rule_id")
            require_text(self.message, "message")
            require_one_of(self.match, RULE_MATCH_MODES, "match")
            require_one_of(self.severity, RULE_SEVERITIES, "severity")
            require_identifier(self.stage, "stage")
            require_identifier(self.owner, "owner")
        except ValueError as exc:
            raise ContractValidationError(str(exc)) from exc
        if not self.predicates:
            raise ContractValidationError("rule requires at least one predicate")
        if self.state not in {
            EditorialDecisionState.NEEDS_EVIDENCE,
            EditorialDecisionState.NEEDS_REVIEW,
            EditorialDecisionState.BLOCKED,
        }:
            raise ContractValidationError("rule state must be needs-evidence, needs-review or blocked")

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "GateRule":
        raw_predicates = value.get("predicates")
        if not isinstance(raw_predicates, list):
            raise ContractValidationError("rule predicates must be an array")
        try:
            state = EditorialDecisionState(str(value.get("state") or ""))
        except ValueError as exc:
            raise ContractValidationError("rule state is invalid") from exc
        return cls(
            rule_id=str(value.get("id") or ""),
            state=state,
            message=str(value.get("message") or ""),
            predicates=tuple(GatePredicate.from_dict(item) for item in raw_predicates if isinstance(item, Mapping)),
            match=str(value.get("match") or "all"),
            severity=str(value.get("severity") or "review"),
            stage=str(value.get("stage") or "factcheck"),
            owner=str(value.get("owner") or "editorial-checker"),
        )

    def matches(self, facts: DecisionFacts) -> bool:
        results = tuple(predicate.matches(facts) for predicate in self.predicates)
        return all(results) if self.match == "all" else any(results)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.rule_id,
            "state": self.state.value,
            "message": self.message,
            "match": self.match,
            "severity": self.severity,
            "stage": self.stage,
            "owner": self.owner,
            "predicates": [predicate.to_dict() for predicate in self.predicates],
        }


@dataclass(frozen=True, slots=True)
class QualityGatePolicy:
    """Project policy compiled into the closed quality-gate vocabulary."""

    contract: str
    project_id: str
    policy_version: str
    rules: tuple[GateRule, ...]

    def __post_init__(self) -> None:
        try:
            require_identifier(self.contract, "contract")
            require_identifier(self.project_id, "project_id")
            require_text(self.policy_version, "policy_version")
        except ValueError as exc:
            raise ContractValidationError(str(exc)) from exc
        if not self.rules:
            raise ContractValidationError("quality gate requires at least one machine rule")
        rule_ids = tuple(rule.rule_id for rule in self.rules)
        if len(rule_ids) != len(set(rule_ids)):
            raise ContractValidationError("quality gate rule ids must be unique")

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "QualityGatePolicy":
        raw_rules = value.get("machineRules") or value.get("machine_rules")
        if not isinstance(raw_rules, list):
            raise ContractValidationError("machineRules must be an array")
        return cls(
            contract=str(value.get("contract") or ""),
            project_id=str(value.get("projectId") or value.get("project_id") or ""),
            policy_version=str(value.get("policyVersion") or value.get("policy_version") or ""),
            rules=tuple(GateRule.from_dict(item) for item in raw_rules if isinstance(item, Mapping)),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "contract": self.contract,
            "projectId": self.project_id,
            "policyVersion": self.policy_version,
            "machineRules": [rule.to_dict() for rule in self.rules],
        }


DEFAULT_EDITORIAL_RULES = (
    GateRule(
        "source-evidence-missing",
        EditorialDecisionState.NEEDS_EVIDENCE,
        "At least one traceable evidence reference is required.",
        (GatePredicate("evidence_count", "eq", 0),),
        severity="block",
        stage="source-check",
        owner="editor-reporter",
    ),
    GateRule(
        "evidence-capture-pending",
        EditorialDecisionState.NEEDS_REVIEW,
        "Typed evidence requires at least one completed capture manifest.",
        (
            GatePredicate("typed_evidence_count", "gt", 0),
            GatePredicate("completed_capture_count", "eq", 0),
        ),
        stage="source-check",
    ),
    GateRule(
        "evidence-stale",
        EditorialDecisionState.NEEDS_REVIEW,
        "Stale evidence requires an explicit reviewer decision.",
        (GatePredicate("stale_evidence_count", "gt", 0),),
        stage="source-check",
    ),
    GateRule(
        "ai-disclosure-missing",
        EditorialDecisionState.NEEDS_REVIEW,
        "AI disclosure state must be explicit.",
        (GatePredicate("ai_disclosure", "eq", None),),
        severity="block",
        stage="ai-disclosure",
        owner="editorial-director",
    ),
    GateRule(
        "ai-disclosure-review",
        EditorialDecisionState.NEEDS_REVIEW,
        "AI-assisted material still requires editorial review.",
        (GatePredicate("ai_disclosure", "eq", "review-required"),),
        severity="block",
        stage="ai-disclosure",
        owner="editorial-director",
    ),
    GateRule(
        "p0-review-missing",
        EditorialDecisionState.NEEDS_REVIEW,
        "P0 material requires a recorded senior or legal reviewer.",
        (
            GatePredicate("risk_level", "eq", "P0"),
            GatePredicate("reviewer_count", "eq", 0),
        ),
        severity="block",
        stage="legal-review",
        owner="legal",
    ),
    GateRule(
        "language-parity-pending",
        EditorialDecisionState.NEEDS_REVIEW,
        "Paired language material requires verified parity.",
        (GatePredicate("language_parity", "eq", "pending"),),
        stage="language-review",
    ),
)
