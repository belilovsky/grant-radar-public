"""Metadata-only editorial case dossier and deterministic readiness checks."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Mapping

from qazstack.contracts._validation import require_aware, require_identifier, require_sha256, require_text
from qazstack.factcheck import AtomicClaim, EvidenceReference

from .contracts import (
    AiDisclosure,
    ContractValidationError,
    EditorialDecisionState,
    _evidence,
    _optional_datetime,
    _references,
    _risk_level,
)
from .quality_gate import GateEvaluation, GateFinding

SOURCE_REVIEW_STATES = frozenset({"pending", "verified", "blocked"})
RIGHT_OF_REPLY_STATES = frozenset({"not-applicable", "pending", "requested", "received", "declined", "blocked"})
REVIEW_STATES = frozenset({"not-applicable", "pending", "approved", "blocked"})
LANGUAGE_PARITY_STATES = frozenset({"not-applicable", "pending", "verified", "blocked"})
CLAIM_LANGUAGES = frozenset({"ru", "kk", "en", "other"})


def _check_state(value: Any, allowed: frozenset[str], field_name: str) -> str:
    state = str(value or "")
    if state not in allowed:
        raise ContractValidationError(f"{field_name} is invalid")
    return state


@dataclass(frozen=True, slots=True)
class EditorialChecks:
    """Explicit human-review states attached to one article revision."""

    source_review: str
    right_of_reply: str
    legal_review: str
    privacy_review: str
    rights_review: str
    language_parity: str
    ai_disclosure: AiDisclosure

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "EditorialChecks":
        try:
            ai_disclosure = AiDisclosure(str(value.get("aiDisclosure") or ""))
        except ValueError as exc:
            raise ContractValidationError("checks.aiDisclosure is invalid") from exc
        return cls(
            source_review=_check_state(value.get("sourceReview"), SOURCE_REVIEW_STATES, "checks.sourceReview"),
            right_of_reply=_check_state(value.get("rightOfReply"), RIGHT_OF_REPLY_STATES, "checks.rightOfReply"),
            legal_review=_check_state(value.get("legalReview"), REVIEW_STATES, "checks.legalReview"),
            privacy_review=_check_state(value.get("privacyReview"), REVIEW_STATES, "checks.privacyReview"),
            rights_review=_check_state(value.get("rightsReview"), REVIEW_STATES, "checks.rightsReview"),
            language_parity=_check_state(value.get("languageParity"), LANGUAGE_PARITY_STATES, "checks.languageParity"),
            ai_disclosure=ai_disclosure,
        )

    def to_dict(self) -> dict[str, str]:
        return {
            "sourceReview": self.source_review,
            "rightOfReply": self.right_of_reply,
            "legalReview": self.legal_review,
            "privacyReview": self.privacy_review,
            "rightsReview": self.rights_review,
            "languageParity": self.language_parity,
            "aiDisclosure": self.ai_disclosure.value,
        }

    @property
    def blocked_fields(self) -> tuple[str, ...]:
        return tuple(
            name
            for name, value in (
                ("source-review", self.source_review),
                ("right-of-reply", self.right_of_reply),
                ("legal-review", self.legal_review),
                ("privacy-review", self.privacy_review),
                ("rights-review", self.rights_review),
                ("language-parity", self.language_parity),
            )
            if value == "blocked"
        )


@dataclass(frozen=True, slots=True)
class EditorialCase:
    """CMS-owned dossier for one immutable article revision."""

    case_id: str
    article_id: str
    project_id: str
    policy_version: str
    content_fingerprint: str
    risk_level: str
    claims: tuple[AtomicClaim, ...]
    evidence: tuple[EvidenceReference, ...]
    checks: EditorialChecks
    decision: EditorialDecisionState
    updated_at: datetime
    analysis: str = ""
    limitations: str = ""
    reviewer_ids: tuple[str, ...] = ()
    reason_codes: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        try:
            require_identifier(self.case_id, "case_id")
            require_text(self.article_id, "article_id")
            require_identifier(self.project_id, "project_id")
            require_text(self.policy_version, "policy_version")
            object.__setattr__(
                self, "content_fingerprint", require_sha256(self.content_fingerprint, "content_fingerprint")
            )
            require_aware(self.updated_at, "updated_at")
        except ValueError as exc:
            raise ContractValidationError(str(exc)) from exc
        _risk_level(self.risk_level)
        if not self.claims or len(self.claims) > 100:
            raise ContractValidationError("claims must contain 1-100 items")
        claim_ids = tuple(claim.claim_id for claim in self.claims)
        if len(claim_ids) != len(set(claim_ids)):
            raise ContractValidationError("claim ids must be unique")
        if len(self.evidence) > 200:
            raise ContractValidationError("evidence must contain at most 200 items")
        evidence_ids = tuple(item.evidence_id for item in self.evidence)
        if len(evidence_ids) != len(set(evidence_ids)):
            raise ContractValidationError("evidence ids must be unique")
        unknown_claims = {
            claim_id for item in self.evidence for claim_id in item.claim_ids if claim_id not in set(claim_ids)
        }
        if unknown_claims:
            raise ContractValidationError("evidence references an unknown claim")

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "EditorialCase":
        required = (
            "caseId",
            "articleId",
            "projectId",
            "policyVersion",
            "contentFingerprint",
            "riskLevel",
            "claims",
            "checks",
            "decision",
            "updatedAt",
        )
        missing = [name for name in required if value.get(name) in (None, "")]
        if missing:
            raise ContractValidationError(f"missing case fields: {', '.join(missing)}")
        raw_claims = value.get("claims")
        if not isinstance(raw_claims, list):
            raise ContractValidationError("claims must be an array")
        claims: list[AtomicClaim] = []
        for index, item in enumerate(raw_claims):
            if not isinstance(item, Mapping):
                raise ContractValidationError(f"claims[{index}] must be an object")
            language = str(item.get("language") or "")
            if language not in CLAIM_LANGUAGES:
                raise ContractValidationError(f"claims[{index}].language is invalid")
            try:
                claims.append(
                    AtomicClaim(
                        claim_id=str(item.get("claimId") or ""),
                        text=str(item.get("text") or ""),
                        language=language,
                        source_locator=str(item.get("sourceLocator") or ""),
                    )
                )
            except ValueError as exc:
                raise ContractValidationError(f"invalid claims[{index}]: {exc}") from exc
        raw_checks = value.get("checks")
        if not isinstance(raw_checks, Mapping):
            raise ContractValidationError("checks must be an object")
        try:
            decision = EditorialDecisionState(str(value["decision"]))
        except ValueError as exc:
            raise ContractValidationError("decision is invalid") from exc
        return cls(
            case_id=str(value["caseId"]),
            article_id=str(value["articleId"]),
            project_id=str(value["projectId"]),
            policy_version=str(value["policyVersion"]),
            content_fingerprint=str(value["contentFingerprint"]),
            risk_level=str(value["riskLevel"]),
            claims=tuple(claims),
            evidence=_evidence(value.get("evidence")),
            checks=EditorialChecks.from_dict(raw_checks),
            decision=decision,
            updated_at=_optional_datetime(value["updatedAt"], "updatedAt") or datetime.min,
            analysis=str(value.get("analysis") or ""),
            limitations=str(value.get("limitations") or ""),
            reviewer_ids=_references(value.get("reviewerIds"), "reviewerIds", 50),
            reason_codes=_references(value.get("reasonCodes"), "reasonCodes", 50),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "caseId": self.case_id,
            "articleId": self.article_id,
            "projectId": self.project_id,
            "policyVersion": self.policy_version,
            "contentFingerprint": self.content_fingerprint,
            "riskLevel": self.risk_level,
            "claims": [
                {
                    "claimId": claim.claim_id,
                    "text": claim.text,
                    "language": claim.language,
                    **({"sourceLocator": claim.source_locator} if claim.source_locator else {}),
                }
                for claim in self.claims
            ],
            "evidence": [_evidence_to_dict(item) for item in self.evidence],
            "analysis": self.analysis,
            "limitations": self.limitations,
            "reviewerIds": list(self.reviewer_ids),
            "checks": self.checks.to_dict(),
            "decision": self.decision.value,
            "reasonCodes": list(self.reason_codes),
            "updatedAt": self.updated_at.isoformat(),
        }


def _evidence_to_dict(item: EvidenceReference) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "evidenceId": item.evidence_id,
        "claimIds": list(item.claim_ids),
        "title": item.title,
        "url": item.url,
        "sourceType": item.source_type,
        "relation": item.relation,
        "captureStatus": item.capture_status,
        "freshnessStatus": item.freshness_status,
    }
    optional = {
        "note": item.note,
        "digest": item.digest,
        "archiveRef": item.archive_ref,
        "retentionClass": item.retention_class,
        "provider": item.provider,
    }
    payload.update({key: value for key, value in optional.items() if value})
    if item.published_at:
        payload["publishedAt"] = item.published_at.isoformat()
    if item.captured_at:
        payload["capturedAt"] = item.captured_at.isoformat()
    return payload


def evaluate_editorial_case(case: EditorialCase) -> GateEvaluation:
    """Compute the safest case state from explicit evidence and review metadata."""
    findings: list[GateFinding] = []
    for field_name in case.checks.blocked_fields:
        findings.append(
            GateFinding(
                f"{field_name}-blocked",
                EditorialDecisionState.BLOCKED,
                f"The {field_name} check is blocked.",
            )
        )
    if findings:
        return GateEvaluation(EditorialDecisionState.BLOCKED, tuple(findings))

    if not case.evidence:
        findings.append(
            GateFinding(
                "source-evidence-missing",
                EditorialDecisionState.NEEDS_EVIDENCE,
                "At least one traceable evidence record is required.",
            )
        )
    if case.evidence and not any(item.capture_status == "completed" for item in case.evidence):
        findings.append(
            GateFinding(
                "evidence-capture-pending",
                EditorialDecisionState.NEEDS_REVIEW,
                "At least one evidence record requires a completed capture manifest.",
            )
        )
    if any(item.freshness_status == "stale" for item in case.evidence):
        findings.append(
            GateFinding(
                "evidence-stale",
                EditorialDecisionState.NEEDS_REVIEW,
                "Stale evidence requires an explicit reviewer decision.",
            )
        )
    if case.checks.source_review != "verified":
        findings.append(
            GateFinding(
                "source-review-required",
                EditorialDecisionState.NEEDS_REVIEW,
                "Source review must be verified.",
            )
        )
    if not case.reviewer_ids:
        findings.append(
            GateFinding(
                "reviewer-missing",
                EditorialDecisionState.NEEDS_REVIEW,
                "A stable reviewer reference is required.",
            )
        )
    if not case.analysis.strip():
        findings.append(
            GateFinding(
                "analysis-missing",
                EditorialDecisionState.NEEDS_REVIEW,
                "The editorial analysis must be recorded.",
            )
        )
    if not case.limitations.strip():
        findings.append(
            GateFinding(
                "limitations-missing",
                EditorialDecisionState.NEEDS_REVIEW,
                "Evidence limitations must be recorded.",
            )
        )
    if case.risk_level == "P0" and case.checks.legal_review != "approved":
        findings.append(
            GateFinding(
                "legal-review-required",
                EditorialDecisionState.NEEDS_REVIEW,
                "P0 material requires approved legal review.",
            )
        )
    pending = {
        "right-of-reply": case.checks.right_of_reply in {"pending", "requested"},
        "legal-review": case.checks.legal_review == "pending",
        "privacy-review": case.checks.privacy_review == "pending",
        "rights-review": case.checks.rights_review == "pending",
        "language-parity": case.checks.language_parity == "pending",
    }
    for field_name, is_pending in pending.items():
        if is_pending:
            findings.append(
                GateFinding(
                    f"{field_name}-pending",
                    EditorialDecisionState.NEEDS_REVIEW,
                    f"The {field_name} check is still pending.",
                )
            )
    if case.checks.ai_disclosure is AiDisclosure.REVIEW_REQUIRED:
        findings.append(
            GateFinding(
                "ai-disclosure-review",
                EditorialDecisionState.NEEDS_REVIEW,
                "AI-assisted material still requires editorial review.",
            )
        )

    if any(item.state is EditorialDecisionState.NEEDS_EVIDENCE for item in findings):
        state = EditorialDecisionState.NEEDS_EVIDENCE
    elif findings:
        state = EditorialDecisionState.NEEDS_REVIEW
    else:
        state = EditorialDecisionState.READY
    return GateEvaluation(state, tuple(findings))
