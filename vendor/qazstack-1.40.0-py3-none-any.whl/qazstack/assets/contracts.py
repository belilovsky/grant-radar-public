"""Versioned evidence, resolution, timeline and quality contracts for assets.

The contracts deliberately stop before persistence and product policy. Compute
services may propose evidence and candidates; only a consumer-owned operator may
create a resolution decision.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from qazstack.contracts._validation import (
    require_aware,
    require_identifier,
    require_one_of,
    require_positive,
    require_ratio,
    require_sha256,
    require_text,
)
from qazstack.entities import TimelineEvent

ASSET_EVIDENCE_SCHEMA = "qazstack-asset-evidence-v1"
ASSET_RESOLUTION_SCHEMA = "qazstack-asset-resolution-v1"
ASSET_TIMELINE_SCHEMA = "qazstack-asset-timeline-v1"
ASSET_QUALITY_SCHEMA = "qazstack-asset-quality-v1"
ASSET_RECONCILIATION_SCHEMA = "qazstack-asset-reconciliation-v1"
ASSET_QUALITY_PROFILE_SCHEMA = "qazstack-asset-quality-profile-v1"

EVIDENCE_KINDS = frozenset({"media", "document", "catalog", "operator", "compute"})
PROVENANCE_STATUSES = frozenset({"unknown", "candidate", "verified", "rejected"})
RIGHTS_STATUSES = frozenset({"unknown", "allow", "deny", "review"})
RESOLUTION_DECISIONS = frozenset({"separate", "link", "merge", "review"})
STANDARD_RESOLUTION_SIGNAL_KEYS = frozenset(
    {
        "catalog-identifier",
        "exact-identifier",
        "perceptual-hash",
        "embedding-similarity",
        "operator-observation",
    }
)
ASSET_EVENT_TYPES = frozenset(
    {"acquired", "valued", "moved", "lent", "returned", "maintenance", "sold", "disposed", "note"}
)
QUALITY_STATUSES = frozenset({"pass", "fail", "unknown"})
RECONCILIATION_STATUSES = frozenset({"missing", "different"})


def _iso(value: datetime) -> str:
    return value.isoformat().replace("+00:00", "Z")


def _require_refs(values: tuple[str, ...], field_name: str) -> None:
    if not values:
        raise ValueError(f"{field_name} must contain at least one reference")
    if len(values) != len(set(values)):
        raise ValueError(f"{field_name} must not contain duplicates")
    for value in values:
        require_identifier(value, field_name)


def _metadata_payload(values: tuple[tuple[str, str], ...]) -> list[dict[str, str]]:
    return [{"key": key, "value": value} for key, value in values]


@dataclass(frozen=True, slots=True)
class AssetEvidence:
    evidence_id: str
    asset_id: str
    kind: str
    source_ref: str
    observed_at: datetime
    provenance_status: str
    rights_status: str = "unknown"
    checksum: str = ""
    content_type: str = ""
    provider: str = ""
    model: str = ""
    model_version: str = ""
    metadata: tuple[tuple[str, str], ...] = ()
    schema_version: str = field(default=ASSET_EVIDENCE_SCHEMA, init=False)

    def __post_init__(self) -> None:
        require_identifier(self.evidence_id, "evidence_id")
        require_identifier(self.asset_id, "asset_id")
        require_one_of(self.kind, EVIDENCE_KINDS, "kind")
        require_text(self.source_ref, "source_ref")
        require_aware(self.observed_at, "observed_at")
        require_one_of(self.provenance_status, PROVENANCE_STATUSES, "provenance_status")
        require_one_of(self.rights_status, RIGHTS_STATUSES, "rights_status")
        if self.checksum:
            object.__setattr__(self, "checksum", require_sha256(self.checksum, "checksum"))
        if self.content_type:
            require_text(self.content_type, "content_type")
        if any((self.model, self.model_version)) and not self.provider:
            raise ValueError("model evidence requires provider")
        keys: set[str] = set()
        for key, value in self.metadata:
            require_identifier(key, "metadata key")
            require_text(value, "metadata value")
            if key in keys:
                raise ValueError("metadata keys must be unique")
            keys.add(key)

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "evidence_id": self.evidence_id,
            "asset_id": self.asset_id,
            "kind": self.kind,
            "source_ref": self.source_ref,
            "observed_at": _iso(self.observed_at),
            "provenance_status": self.provenance_status,
            "rights_status": self.rights_status,
            "checksum": self.checksum or None,
            "content_type": self.content_type or None,
            "provider": self.provider or None,
            "model": self.model or None,
            "model_version": self.model_version or None,
            "metadata": _metadata_payload(self.metadata),
        }


@dataclass(frozen=True, slots=True)
class AssetResolutionSignal:
    key: str
    score: float
    evidence_ids: tuple[str, ...]

    def __post_init__(self) -> None:
        require_identifier(self.key, "key")
        require_ratio(self.score, "score")
        _require_refs(self.evidence_ids, "evidence_ids")

    def to_dict(self) -> dict[str, Any]:
        return {"key": self.key, "score": self.score, "evidence_ids": list(self.evidence_ids)}


@dataclass(frozen=True, slots=True)
class AssetResolutionCandidate:
    candidate_id: str
    label: str
    confidence: float
    evidence_ids: tuple[str, ...]
    signals: tuple[AssetResolutionSignal, ...] = ()

    def __post_init__(self) -> None:
        require_identifier(self.candidate_id, "candidate_id")
        require_text(self.label, "label")
        require_ratio(self.confidence, "confidence")
        _require_refs(self.evidence_ids, "evidence_ids")
        signal_keys = [signal.key for signal in self.signals]
        if len(signal_keys) != len(set(signal_keys)):
            raise ValueError("resolution signal keys must be unique")

    def to_dict(self) -> dict[str, Any]:
        return {
            "candidate_id": self.candidate_id,
            "label": self.label,
            "confidence": self.confidence,
            "evidence_ids": list(self.evidence_ids),
            "signals": [signal.to_dict() for signal in self.signals],
        }


@dataclass(frozen=True, slots=True)
class AssetResolutionDecision:
    asset_id: str
    decision: str
    candidates: tuple[AssetResolutionCandidate, ...]
    decided_by: str
    decided_at: datetime
    reason: str
    chosen_candidate_id: str | None = None
    schema_version: str = field(default=ASSET_RESOLUTION_SCHEMA, init=False)

    def __post_init__(self) -> None:
        require_identifier(self.asset_id, "asset_id")
        require_one_of(self.decision, RESOLUTION_DECISIONS, "decision")
        require_identifier(self.decided_by, "decided_by")
        require_aware(self.decided_at, "decided_at")
        require_text(self.reason, "reason")
        candidate_ids = [candidate.candidate_id for candidate in self.candidates]
        if len(candidate_ids) != len(set(candidate_ids)):
            raise ValueError("candidate ids must be unique")
        if self.decision in {"link", "merge"}:
            if not self.chosen_candidate_id or self.chosen_candidate_id not in candidate_ids:
                raise ValueError("link and merge decisions require a chosen candidate")
        elif self.chosen_candidate_id is not None:
            raise ValueError("separate and review decisions cannot choose a candidate")
        if self.decision == "review" and not self.candidates:
            raise ValueError("review decisions require candidates")

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "asset_id": self.asset_id,
            "decision": self.decision,
            "candidates": [candidate.to_dict() for candidate in self.candidates],
            "chosen_candidate_id": self.chosen_candidate_id,
            "decided_by": self.decided_by,
            "decided_at": _iso(self.decided_at),
            "reason": self.reason,
        }


@dataclass(frozen=True, slots=True)
class AssetTimelineEvent:
    event_id: str
    asset_id: str
    event_type: str
    title: str
    occurred_at: datetime
    evidence_ids: tuple[str, ...]
    location: str = ""
    counterparty: str = ""
    note: str = ""
    schema_version: str = field(default=ASSET_TIMELINE_SCHEMA, init=False)

    def __post_init__(self) -> None:
        require_identifier(self.event_id, "event_id")
        require_identifier(self.asset_id, "asset_id")
        require_one_of(self.event_type, ASSET_EVENT_TYPES, "event_type")
        require_text(self.title, "title")
        require_aware(self.occurred_at, "occurred_at")
        _require_refs(self.evidence_ids, "evidence_ids")

    def as_timeline_event(self) -> TimelineEvent:
        return TimelineEvent(
            event_id=self.event_id,
            title=self.title,
            starts_at=self.occurred_at,
            ends_at=None,
            entity_ids=(self.asset_id,),
            source_refs=self.evidence_ids,
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "event_id": self.event_id,
            "asset_id": self.asset_id,
            "event_type": self.event_type,
            "title": self.title,
            "occurred_at": _iso(self.occurred_at),
            "evidence_ids": list(self.evidence_ids),
            "location": self.location or None,
            "counterparty": self.counterparty or None,
            "note": self.note or None,
        }


@dataclass(frozen=True, slots=True)
class AssetQualityCheck:
    key: str
    status: str
    reason: str
    observed_at: datetime
    evidence_updated_at: datetime | None
    stale_after_seconds: int
    evidence_ids: tuple[str, ...]

    def __post_init__(self) -> None:
        require_identifier(self.key, "key")
        require_one_of(self.status, QUALITY_STATUSES, "status")
        require_aware(self.observed_at, "observed_at")
        require_positive(self.stale_after_seconds, "stale_after_seconds")
        _require_refs(self.evidence_ids, "evidence_ids")
        if self.evidence_updated_at is not None:
            require_aware(self.evidence_updated_at, "evidence_updated_at")
            if self.evidence_updated_at > self.observed_at:
                raise ValueError("evidence_updated_at cannot be after observed_at")
        if self.status != "pass":
            require_text(self.reason, "reason")

    @property
    def freshness(self) -> str:
        if self.evidence_updated_at is None:
            return "unknown"
        age = (self.observed_at - self.evidence_updated_at).total_seconds()
        return "stale" if age > self.stale_after_seconds else "fresh"

    def to_dict(self) -> dict[str, Any]:
        return {
            "key": self.key,
            "status": self.status,
            "reason": self.reason,
            "observed_at": _iso(self.observed_at),
            "evidence_updated_at": _iso(self.evidence_updated_at) if self.evidence_updated_at else None,
            "stale_after_seconds": self.stale_after_seconds,
            "freshness": self.freshness,
            "evidence_ids": list(self.evidence_ids),
        }


@dataclass(frozen=True, slots=True)
class AssetQualitySummary:
    asset_id: str
    checks: tuple[AssetQualityCheck, ...]
    schema_version: str = field(default=ASSET_QUALITY_SCHEMA, init=False)

    def __post_init__(self) -> None:
        require_identifier(self.asset_id, "asset_id")
        if not self.checks:
            raise ValueError("quality summaries require checks")
        keys = [check.key for check in self.checks]
        if len(keys) != len(set(keys)):
            raise ValueError("quality check keys must be unique")

    @property
    def score(self) -> float:
        passed = sum(check.status == "pass" and check.freshness == "fresh" for check in self.checks)
        return passed / len(self.checks)

    @property
    def status(self) -> str:
        if all(check.status == "unknown" for check in self.checks):
            return "unknown"
        return "complete" if self.score == 1.0 else "degraded"

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "asset_id": self.asset_id,
            "status": self.status,
            "score": self.score,
            "checks": [check.to_dict() for check in self.checks],
        }


@dataclass(frozen=True, slots=True)
class AssetFieldDelta:
    """One actionable source-versus-record difference.

    The values deliberately remain JSON scalars. Products keep their own field
    schemas, normalization and rules for applying a reviewed change.
    """

    key: str
    current_value: str | int | float | bool | None
    proposed_value: str | int | float | bool | None
    status: str

    def __post_init__(self) -> None:
        require_identifier(self.key, "key")
        require_one_of(self.status, RECONCILIATION_STATUSES, "status")
        for value, field_name in ((self.current_value, "current_value"), (self.proposed_value, "proposed_value")):
            if value is not None and not isinstance(value, (str, int, float, bool)):
                raise ValueError(f"{field_name} must be a JSON scalar or null")
        if self.status == "missing":
            if self.current_value is not None or self.proposed_value in (None, ""):
                raise ValueError("missing deltas require an empty current value and a proposed value")
        elif self.current_value is None or self.proposed_value is None or self.current_value == self.proposed_value:
            raise ValueError("different deltas require two distinct values")

    def to_dict(self) -> dict[str, Any]:
        return {
            "key": self.key,
            "current_value": self.current_value,
            "proposed_value": self.proposed_value,
            "status": self.status,
        }


@dataclass(frozen=True, slots=True)
class AssetReconciliationProposal:
    """Storage-neutral, reviewable field deltas from an external source.

    This is intentionally a proposal, not a mutation command. A consumer owns
    source trust, reviewer assignment, persistence and the eventual apply step.
    """

    asset_id: str
    source_id: str
    source_ref: str
    observed_at: datetime
    evidence_ids: tuple[str, ...]
    deltas: tuple[AssetFieldDelta, ...]
    schema_version: str = field(default=ASSET_RECONCILIATION_SCHEMA, init=False)

    def __post_init__(self) -> None:
        require_identifier(self.asset_id, "asset_id")
        require_identifier(self.source_id, "source_id")
        require_text(self.source_ref, "source_ref")
        require_aware(self.observed_at, "observed_at")
        _require_refs(self.evidence_ids, "evidence_ids")
        if not self.deltas:
            raise ValueError("reconciliation proposals require at least one actionable delta")
        keys = [delta.key for delta in self.deltas]
        if len(keys) != len(set(keys)):
            raise ValueError("reconciliation delta keys must be unique")

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "asset_id": self.asset_id,
            "source_id": self.source_id,
            "source_ref": self.source_ref,
            "observed_at": _iso(self.observed_at),
            "evidence_ids": list(self.evidence_ids),
            "deltas": [delta.to_dict() for delta in self.deltas],
        }


@dataclass(frozen=True, slots=True)
class AssetQualityRequirement:
    """A consumer-declared evidence expectation with no product score weight."""

    key: str
    required: bool
    stale_after_seconds: int
    description: str = ""

    def __post_init__(self) -> None:
        require_identifier(self.key, "key")
        require_positive(self.stale_after_seconds, "stale_after_seconds")
        if self.description:
            require_text(self.description, "description")

    def to_dict(self) -> dict[str, Any]:
        return {
            "key": self.key,
            "required": self.required,
            "stale_after_seconds": self.stale_after_seconds,
            "description": self.description or None,
        }


@dataclass(frozen=True, slots=True)
class AssetQualityProfile:
    """Portable quality requirements that products map to their own checks."""

    profile_id: str
    requirements: tuple[AssetQualityRequirement, ...]
    schema_version: str = field(default=ASSET_QUALITY_PROFILE_SCHEMA, init=False)

    def __post_init__(self) -> None:
        require_identifier(self.profile_id, "profile_id")
        if not self.requirements:
            raise ValueError("quality profiles require at least one requirement")
        keys = [requirement.key for requirement in self.requirements]
        if len(keys) != len(set(keys)):
            raise ValueError("quality requirement keys must be unique")

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "profile_id": self.profile_id,
            "requirements": [requirement.to_dict() for requirement in self.requirements],
        }
