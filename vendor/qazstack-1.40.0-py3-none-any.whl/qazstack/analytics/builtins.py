"""Built-in analytical engines – PSSR-compatible implementations.

These engines implement the core PSSR analytical functions as BaseEngine
subclasses, making them available through the unified QazStack analytics
pipeline. Each engine is self-contained and stateless.

Engine catalog (14 engines from PSSR):
- sss: System Stability Score
- ssi: Stress Intensity Index
- fds: Factor Divergence Score
- lci: Liquidity Compression Index
- vrc: Volatility Regime Classifier
- prs: Probability of Regime Shift
- nl: Nonlinearity Detector
- sss_eff: Effective Stability
- cai: Cascade Attack Index
- di: Dissonance Index
- ni: Novelty Index
- ews: Early Warning System
- regime: Regime State Machine
- snapshot: Full calculation (aggregate of all above)
"""

from __future__ import annotations

import math
from typing import Any

from .engine import BaseEngine, EngineCategory, EngineResult


def _sigmoid(z: float) -> float:
    if z < -500:
        return 0.0
    if z > 500:
        return 1.0
    return 1.0 / (1.0 + math.exp(-z))


# ── SSS ───────────────────────────────────────────────────────────


class SSSEngine(BaseEngine):
    name = "sss"
    version = "10.0"
    category = EngineCategory.INDEX
    description = "System Stability Score – composite stability metric (0-100)"

    @property
    def required_inputs(self) -> list[str]:
        return ["d_core", "v_norm", "l_norm"]

    def default_config(self) -> dict[str, Any]:
        return {"w_D": 0.4, "w_V": 0.35, "w_L": 0.25}

    async def run(self, inputs: dict[str, Any], cfg: dict[str, Any]) -> EngineResult:
        d = inputs["d_core"]
        v = inputs["v_norm"]
        l_val = inputs["l_norm"]
        sss = 100.0 * (cfg["w_D"] * (1 - d) + cfg["w_V"] * (1 - v) + cfg["w_L"] * (1 - l_val))
        sss = max(0.0, min(100.0, sss))
        return EngineResult(
            engine=self.name,
            value=round(sss, 2),
            signals={"sss": round(sss, 2)},
        )


# ── SSI ───────────────────────────────────────────────────────────


class SSIEngine(BaseEngine):
    name = "ssi"
    version = "9.3"
    category = EngineCategory.INDEX
    description = "Stress Intensity Index – aggregated stress level (0-1)"

    @property
    def required_inputs(self) -> list[str]:
        return ["delta_sss", "sigma_shocks", "cluster_stress"]

    def default_config(self) -> dict[str, Any]:
        return {"w_delta": 0.4, "w_sigma": 0.35, "w_cluster": 0.25}

    async def run(self, inputs: dict[str, Any], cfg: dict[str, Any]) -> EngineResult:
        ssi = (
            cfg["w_delta"] * abs(inputs["delta_sss"])
            + cfg["w_sigma"] * inputs["sigma_shocks"]
            + cfg["w_cluster"] * inputs["cluster_stress"]
        )
        ssi = max(0.0, min(1.0, ssi))
        return EngineResult(
            engine=self.name,
            value=round(ssi, 4),
            signals={"ssi": round(ssi, 4)},
        )


# ── FDS ───────────────────────────────────────────────────────────


class FDSEngine(BaseEngine):
    name = "fds"
    version = "9.3"
    category = EngineCategory.INDEX
    description = "Factor Divergence Score – z-score based divergence"

    @property
    def required_inputs(self) -> list[str]:
        return ["factor_pairs"]

    async def run(self, inputs: dict[str, Any], cfg: dict[str, Any]) -> EngineResult:
        pairs = inputs["factor_pairs"]
        if not pairs:
            return EngineResult(engine=self.name, value=0.0, signals={"fds": 0.0})

        z_scores = []
        for p in pairs:
            sigma = max(p.get("sigma", 1e-9), 1e-9)
            z = abs((p["observed"] - p["mu"]) / sigma)
            z_scores.append(z)

        fds = sum(z_scores) / len(z_scores)
        return EngineResult(
            engine=self.name,
            value=round(fds, 4),
            signals={"fds": round(fds, 4)},
            metadata={"pair_count": len(pairs)},
        )


# ── LCI ───────────────────────────────────────────────────────────


class LCIEngine(BaseEngine):
    name = "lci"
    version = "9.3"
    category = EngineCategory.INDEX
    description = "Liquidity Compression Index – tier classification (0-3)"

    @property
    def required_inputs(self) -> list[str]:
        return ["l_norm"]

    def default_config(self) -> dict[str, Any]:
        return {"theta_1": 0.3, "theta_2": 0.6, "theta_3": 0.85}

    async def run(self, inputs: dict[str, Any], cfg: dict[str, Any]) -> EngineResult:
        l_val = inputs["l_norm"]
        if l_val >= cfg["theta_3"]:
            lci = 3
        elif l_val >= cfg["theta_2"]:
            lci = 2
        elif l_val >= cfg["theta_1"]:
            lci = 1
        else:
            lci = 0
        return EngineResult(
            engine=self.name,
            value=float(lci),
            signals={"lci": float(lci)},
        )


# ── VRC ───────────────────────────────────────────────────────────


class VRCEngine(BaseEngine):
    name = "vrc"
    version = "9.3"
    category = EngineCategory.INDEX
    description = "Volatility Regime Classifier – regime tier (0-3)"

    @property
    def required_inputs(self) -> list[str]:
        return ["real_vol", "impl_vol", "skew", "cross_asset_corr"]

    def default_config(self) -> dict[str, Any]:
        return {
            "a1": 0.2,
            "a2": 0.3,
            "a3": 0.7,
            "a4": 1.5,
            "a5": 0.5,
            "a6": 0.6,
            "a7": 0.8,
        }

    async def run(self, inputs: dict[str, Any], cfg: dict[str, Any]) -> EngineResult:
        rv = inputs["real_vol"]
        iv = inputs["impl_vol"]
        sk = inputs["skew"]
        cac = inputs["cross_asset_corr"]

        if rv >= cfg["a5"] or (iv >= cfg["a6"] and cac >= cfg["a7"]):
            vrc = 3
        elif cfg["a1"] <= rv < cfg["a5"] and iv < cfg["a6"]:
            vrc = 2
        elif rv < cfg["a1"] and (iv >= cfg["a2"] or cac >= cfg["a3"] or abs(sk) >= cfg["a4"]):
            vrc = 1
        else:
            vrc = 0

        return EngineResult(
            engine=self.name,
            value=float(vrc),
            signals={"vrc": float(vrc)},
        )


# ── PRS ───────────────────────────────────────────────────────────


class PRSEngine(BaseEngine):
    name = "prs"
    version = "9.3"
    category = EngineCategory.INDEX
    description = "Probability of Regime Shift – logistic-regression based (0-100)"

    @property
    def required_inputs(self) -> list[str]:
        return ["ssi", "lci", "fds", "vrc"]

    def default_config(self) -> dict[str, Any]:
        return {
            "beta_0": -2.0,
            "beta_1": 3.0,
            "beta_2": 0.8,
            "beta_3": 0.5,
            "beta_4": 1.0,
            "beta_5": 0.3,
            "beta_6": 0.2,
        }

    async def run(self, inputs: dict[str, Any], cfg: dict[str, Any]) -> EngineResult:
        pos_stress = inputs.get("positioning_stress", 0.0)
        credit_spread = inputs.get("credit_spread_delta", 0.0)

        z = (
            cfg["beta_0"]
            + cfg["beta_1"] * inputs["ssi"]
            + cfg["beta_2"] * inputs["lci"]
            + cfg["beta_3"] * inputs["fds"]
            + cfg["beta_4"] * inputs["vrc"]
            + cfg["beta_5"] * pos_stress
            + cfg["beta_6"] * credit_spread
        )
        prs = 100.0 * _sigmoid(z)

        return EngineResult(
            engine=self.name,
            value=round(prs, 2),
            signals={"prs": round(prs, 2)},
        )


# ── NL ────────────────────────────────────────────────────────────


class NLEngine(BaseEngine):
    name = "nl"
    version = "10.0"
    category = EngineCategory.INDEX
    description = "Nonlinearity Detector – quadratic sensitivity measure"

    @property
    def required_inputs(self) -> list[str]:
        return ["ssi"]

    def default_config(self) -> dict[str, Any]:
        return {"t_nl": 0.6, "coefficient": 5.0}

    async def run(self, inputs: dict[str, Any], cfg: dict[str, Any]) -> EngineResult:
        ssi = inputs["ssi"]
        if ssi > cfg["t_nl"]:
            nl = cfg["coefficient"] * (ssi - cfg["t_nl"]) ** 2
        else:
            nl = 0.0
        return EngineResult(
            engine=self.name,
            value=round(nl, 4),
            signals={"nl": round(nl, 4)},
        )


# ── SSS_eff ───────────────────────────────────────────────────────


class SSSEffEngine(BaseEngine):
    name = "sss_eff"
    version = "10.0"
    category = EngineCategory.INDEX
    description = "Effective Stability – SSS with nonlinearity and fragility penalties"

    @property
    def required_inputs(self) -> list[str]:
        return ["sss", "nl", "vrc"]

    def default_config(self) -> dict[str, Any]:
        return {"gamma": 10.0, "delta_fragile": 5.0}

    async def run(self, inputs: dict[str, Any], cfg: dict[str, Any]) -> EngineResult:
        penalty = cfg["gamma"] * inputs["nl"]
        fragile = cfg["delta_fragile"] if inputs["vrc"] == 1 else 0.0
        sss_eff = max(0.0, inputs["sss"] - penalty - fragile)
        return EngineResult(
            engine=self.name,
            value=round(sss_eff, 2),
            signals={"sss_eff": round(sss_eff, 2)},
        )


# ── CAI ───────────────────────────────────────────────────────────


class CAIEngine(BaseEngine):
    name = "cai"
    version = "10.1"
    category = EngineCategory.INDEX
    description = "Cascade Attack Index – node-weighted cascade potential"

    @property
    def required_inputs(self) -> list[str]:
        return ["nodes"]

    async def run(self, inputs: dict[str, Any], cfg: dict[str, Any]) -> EngineResult:
        nodes = inputs["nodes"]
        if not nodes:
            return EngineResult(engine=self.name, value=0.0, signals={"cai": 0.0})

        k_max = max(n.get("connectivity", 1) for n in nodes)
        if k_max == 0:
            return EngineResult(engine=self.name, value=0.0, signals={"cai": 0.0})

        total = 0.0
        for n in nodes:
            nl_i = n.get("pressure", 0.0) / max(n.get("capacity", 1.0), 1e-9)
            cascade = nl_i * (n.get("connectivity", 1) / k_max)
            total += cascade

        return EngineResult(
            engine=self.name,
            value=round(total, 4),
            signals={"cai": round(total, 4)},
            metadata={"node_count": len(nodes)},
        )


# ── DI ────────────────────────────────────────────────────────────


class DIEngine(BaseEngine):
    name = "di"
    version = "10.1"
    category = EngineCategory.INDEX
    description = "Dissonance Index – variance across analytical layers"

    @property
    def required_inputs(self) -> list[str]:
        return ["layer_scores"]

    async def run(self, inputs: dict[str, Any], cfg: dict[str, Any]) -> EngineResult:
        scores = inputs["layer_scores"]
        if len(scores) < 2:
            return EngineResult(engine=self.name, value=0.0, signals={"di": 0.0})
        mean_val = sum(scores) / len(scores)
        variance = sum((s - mean_val) ** 2 for s in scores) / len(scores)
        return EngineResult(
            engine=self.name,
            value=round(variance, 4),
            signals={"di": round(variance, 4)},
            metadata={"layer_count": len(scores)},
        )


# ── NI ────────────────────────────────────────────────────────────


class NIEngine(BaseEngine):
    name = "ni"
    version = "10.1"
    category = EngineCategory.INDEX
    description = "Novelty Index – cosine-distance from historical state"

    @property
    def required_inputs(self) -> list[str]:
        return ["state_now", "state_history"]

    async def run(self, inputs: dict[str, Any], cfg: dict[str, Any]) -> EngineResult:
        state_now = inputs["state_now"]
        state_hist = inputs["state_history"]

        if not state_now or not state_hist or len(state_now) != len(state_hist):
            return EngineResult(engine=self.name, value=0.0, signals={"ni": 0.0})

        dot = sum(a * b for a, b in zip(state_now, state_hist))
        mag_a = math.sqrt(sum(a * a for a in state_now))
        mag_b = math.sqrt(sum(b * b for b in state_hist))

        if mag_a < 1e-9 or mag_b < 1e-9:
            ni = 1.0
        else:
            ni = max(0.0, min(1.0, 1.0 - dot / (mag_a * mag_b)))

        return EngineResult(
            engine=self.name,
            value=round(ni, 4),
            signals={"ni": round(ni, 4)},
        )


# ── EWS ───────────────────────────────────────────────────────────


class EWSEngine(BaseEngine):
    name = "ews"
    version = "10.0"
    category = EngineCategory.INDEX
    description = "Early Warning System – variance and sigma spike detection"

    @property
    def required_inputs(self) -> list[str]:
        return ["ews_history"]

    def default_config(self) -> dict[str, Any]:
        return {
            "baseline_variance": 0.01,
            "baseline_sigma": 0.1,
            "variance_multiplier": 3.0,
            "sigma_multiplier": 2.5,
        }

    async def run(self, inputs: dict[str, Any], cfg: dict[str, Any]) -> EngineResult:
        history = inputs["ews_history"]
        if len(history) < 3:
            return EngineResult(
                engine=self.name,
                value=0.0,
                signals={"ews_alert": 0.0, "variance_ratio": 0.0, "sigma_ratio": 0.0},
            )

        mean_val = sum(history) / len(history)
        variance = sum((h - mean_val) ** 2 for h in history) / len(history)
        sigma = math.sqrt(variance) if variance > 0 else 0.0

        var_ratio = variance / max(cfg["baseline_variance"], 1e-9)
        sig_ratio = sigma / max(cfg["baseline_sigma"], 1e-9)

        var_alert = var_ratio > cfg["variance_multiplier"]
        sig_alert = sig_ratio > cfg["sigma_multiplier"]
        alert = 1.0 if (var_alert or sig_alert) else 0.0

        return EngineResult(
            engine=self.name,
            value=alert,
            signals={
                "ews_alert": alert,
                "variance_ratio": round(var_ratio, 4),
                "sigma_ratio": round(sig_ratio, 4),
            },
        )


# ── Regime ────────────────────────────────────────────────────────


class RegimeEngine(BaseEngine):
    name = "regime"
    version = "10.0"
    category = EngineCategory.REGIME
    description = "Regime classifier – stability/transition/crisis detection"

    @property
    def required_inputs(self) -> list[str]:
        return ["prs"]

    def default_config(self) -> dict[str, Any]:
        return {
            "threshold_stable": 25.0,
            "threshold_warning": 50.0,
            "threshold_critical": 75.0,
        }

    async def run(self, inputs: dict[str, Any], cfg: dict[str, Any]) -> EngineResult:
        prs = inputs["prs"]
        ssi = inputs.get("ssi", 0.0)

        if prs >= cfg["threshold_critical"]:
            regime = "crisis"
        elif prs >= cfg["threshold_warning"]:
            regime = "transition"
        elif prs >= cfg["threshold_stable"]:
            regime = "warning"
        else:
            regime = "stable"

        return EngineResult(
            engine=self.name,
            value=prs,
            signals={"regime": {"stable": 0, "warning": 1, "transition": 2, "crisis": 3}[regime]},
            metadata={"regime": regime, "ssi": ssi},
        )


# ── Factory ───────────────────────────────────────────────────────


def get_builtin_engines() -> list[BaseEngine]:
    """Return all built-in analytical engines."""
    return [
        SSSEngine(),
        SSIEngine(),
        FDSEngine(),
        LCIEngine(),
        VRCEngine(),
        PRSEngine(),
        NLEngine(),
        SSSEffEngine(),
        CAIEngine(),
        DIEngine(),
        NIEngine(),
        EWSEngine(),
        RegimeEngine(),
    ]
