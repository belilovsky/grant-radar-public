"""Spectral stability analysis – Jacobian eigenvalue decomposition.

Provides tools for linear stability analysis of dynamical systems via
the Jacobian matrix.  The *spectral stability margin* (rho) is the
negative of the largest real part of the Jacobian eigenvalues:

* ``rho > 0``: stable – all perturbations decay.
* ``rho = 0``: bifurcation boundary.
* ``rho < 0``: unstable – perturbations grow.

**NumPy is required** for this sub-module.  Install it via::

    pip install "qazstack[analytics]"
"""

from __future__ import annotations

from dataclasses import dataclass, field

try:
    import numpy as np
except ImportError as exc:  # pragma: no cover
    raise ImportError("spectral analysis requires numpy. Install it with: pip install 'qazstack[analytics]'") from exc


# ---------------------------------------------------------------------------
# Result
# ---------------------------------------------------------------------------


@dataclass
class StabilityResult:
    """Result of a spectral stability analysis.

    Attributes:
        rho: Spectral stability margin – ``-max(Re(λ))``.  Positive
            means stable.
        eigenvalues: Full list of Jacobian eigenvalues (complex numbers).
        stable: ``True`` when all eigenvalues have strictly negative real
            parts (i.e. ``rho > 0``).
        cai: Cascade Amplification Index – spectral radius of
            ``W · diag(σ'(states))``.  Values >= 1 indicate
            self-sustaining cascades.
    """

    rho: float
    eigenvalues: list[complex] = field(default_factory=list)
    stable: bool = False
    cai: float = 0.0


# ---------------------------------------------------------------------------
# Internal sigmoid helpers
# ---------------------------------------------------------------------------


def _sigma(x: np.ndarray, k: float = 10.0) -> np.ndarray:
    """Sigmoid transfer function σ(x) = 1 / (1 + exp(-k(x - 1)))."""
    return 1.0 / (1.0 + np.exp(-k * (x - 1.0)))


def _sigma_prime(x: np.ndarray, k: float = 10.0) -> np.ndarray:
    """Derivative σ'(x) = k · σ(x) · (1 - σ(x))."""
    s = _sigma(x, k)
    return k * s * (1.0 - s)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def build_jacobian(
    weights: np.ndarray,
    states: np.ndarray,
    k: float = 10.0,
    damping: np.ndarray | None = None,
) -> np.ndarray:
    """Build the system Jacobian matrix.

    Implements the linearised Jacobian:

    .. code-block:: text

        J = W · diag(σ'(states)) - diag(damping)

    where σ' is the derivative of the sigmoid transfer function.

    Args:
        weights: Square weight matrix ``(N, N)`` representing the
            coupling strengths between system nodes.
        states: State vector ``(N,)`` – current activation levels of
            each node.
        k: Sigmoid steepness parameter.  Higher values make the sigmoid
            more step-like.
        damping: Damping / self-decay vector ``(N,)``.  Defaults to a
            vector of ones (unit damping on each node).

    Returns:
        Jacobian matrix ``(N, N)`` as a NumPy array.
    """
    states = np.asarray(states, dtype=float)
    weights = np.asarray(weights, dtype=float)
    N = len(states)
    if damping is None:
        damping = np.ones(N)
    else:
        damping = np.asarray(damping, dtype=float)

    sp = _sigma_prime(states, k)
    J = weights @ np.diag(sp) - np.diag(damping)
    return J


def analyze_stability(jacobian: np.ndarray) -> StabilityResult:
    """Analyse the spectral stability of a system from its Jacobian.

    Args:
        jacobian: Square Jacobian matrix ``(N, N)``.

    Returns:
        A :class:`StabilityResult` containing the stability margin,
        eigenvalues, stability flag, and CAI.

    Example::

        import numpy as np
        from qazstack.analytics.spectral import build_jacobian, analyze_stability

        W = np.array([[-1.0, 0.5], [0.5, -1.0]])
        states = np.array([1.0, 1.0])
        J = build_jacobian(W, states)
        result = analyze_stability(J)
        print(result.stable, result.rho)
    """
    jacobian = np.asarray(jacobian, dtype=float)
    eigenvalues = np.linalg.eigvals(jacobian)
    max_re = float(np.max(np.real(eigenvalues)))
    rho = -max_re

    # Cascade amplification index – spectral radius of the Jacobian
    # (absolute values of eigenvalues)
    cai = float(np.max(np.abs(eigenvalues)))

    return StabilityResult(
        rho=rho,
        eigenvalues=[complex(e) for e in eigenvalues],
        stable=rho > 0,
        cai=cai,
    )


def calc_rho(jacobian: np.ndarray) -> float:
    """Compute the spectral stability margin from a Jacobian.

    This is a convenience wrapper around :func:`analyze_stability` that
    returns only the scalar margin ``rho = -max(Re(eigenvalues))``.

    Args:
        jacobian: Square Jacobian matrix ``(N, N)``.

    Returns:
        Spectral stability margin.  Positive → stable, negative →
        unstable.
    """
    jacobian = np.asarray(jacobian, dtype=float)
    eigenvalues = np.linalg.eigvals(jacobian)
    max_re = float(np.max(np.real(eigenvalues)))
    return -max_re
