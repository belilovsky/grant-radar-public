"""Drift detection – composite drift index from three components.

Combines data drift, model drift, and regime drift into a single
weighted index and classifies the result into actionable severity
levels.  All three component scores must be normalised to ``[0, 1]``
by the caller.
"""

from __future__ import annotations

from dataclasses import dataclass

# ---------------------------------------------------------------------------
# Result
# ---------------------------------------------------------------------------


@dataclass
class DriftResult:
    """Result of a drift index calculation.

    Attributes:
        index: Weighted composite drift index in ``[0, 1]``.
        data_drift: Raw data-drift component (caller-supplied).
        model_drift: Raw model-drift component (caller-supplied).
        regime_drift: Raw regime-drift component (caller-supplied).
        status: Severity string – ``"normal"``, ``"review"``, or
            ``"critical"``.
    """

    index: float
    data_drift: float
    model_drift: float
    regime_drift: float
    status: str  # "normal" | "review" | "critical"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def calc_drift_index(
    predicted: list[float] | None = None,
    actual: list[float] | None = None,
    regime_history: list[str] | None = None,
    weights: tuple[float, float, float] = (0.4, 0.3, 0.3),
    # Alternative: supply pre-computed component scores directly
    data_drift: float | None = None,
    model_drift: float | None = None,
    regime_drift: float | None = None,
    review_threshold: float = 0.4,
    critical_threshold: float = 0.7,
) -> DriftResult:
    """Calculate a composite drift index.

    You can supply either:

    * **Pre-computed components** – pass ``data_drift``, ``model_drift``,
      and ``regime_drift`` directly (each in ``[0, 1]``).
    * **Raw sequences** – pass ``predicted`` and ``actual`` for model
      drift; ``regime_history`` for regime drift.  Data drift is
      computed from ``actual`` vs a rolling mean.

    ``weights`` must sum to 1.0 (not enforced – they are normalised
    internally if they do not).

    Args:
        predicted: Model predictions (same length as *actual*).
        actual: Ground-truth observations.
        regime_history: Sequence of state labels; drift is measured as
            the fraction of consecutive pairs that changed state.
        weights: ``(w_data, w_model, w_regime)`` weight tuple.
        data_drift: Pre-computed data-drift score in ``[0, 1]``.
        model_drift: Pre-computed model-drift score in ``[0, 1]``.
        regime_drift: Pre-computed regime-drift score in ``[0, 1]``.
        review_threshold: Index >= this value → ``"review"``.
        critical_threshold: Index >= this value → ``"critical"``.

    Returns:
        A :class:`DriftResult` with the composite index and per-component
        scores.

    Example::

        from qazstack.analytics.drift import calc_drift_index

        result = calc_drift_index(
            predicted=[1.0, 2.0, 3.0],
            actual=[1.1, 2.3, 2.8],
            regime_history=["normal", "normal", "heightened"],
        )
        print(result.index, result.status)
    """
    w_data, w_model, w_regime = weights
    total_w = w_data + w_model + w_regime
    if total_w < 1e-12:
        raise ValueError("weights must not all be zero")
    # Normalise weights
    w_data /= total_w
    w_model /= total_w
    w_regime /= total_w

    # --- Resolve data drift ---
    if data_drift is None:
        if actual and len(actual) >= 2:
            mean_actual = sum(actual) / len(actual)
            if mean_actual > 1e-12:
                deviations = [abs(v - mean_actual) / mean_actual for v in actual]
                data_drift = min(1.0, sum(deviations) / len(deviations))
            else:
                data_drift = 0.0
        else:
            data_drift = 0.0

    # --- Resolve model drift ---
    if model_drift is None:
        if predicted and actual and len(predicted) == len(actual) and len(predicted) > 0:
            denom = max(abs(v) for v in actual) if actual else 1.0
            denom = denom if denom > 1e-12 else 1.0
            errors = [abs(p - a) / denom for p, a in zip(predicted, actual)]
            model_drift = min(1.0, sum(errors) / len(errors))
        else:
            model_drift = 0.0

    # --- Resolve regime drift ---
    if regime_drift is None:
        if regime_history and len(regime_history) >= 2:
            changes = sum(1 for i in range(1, len(regime_history)) if regime_history[i] != regime_history[i - 1])
            regime_drift = changes / (len(regime_history) - 1)
        else:
            regime_drift = 0.0

    # --- Composite index ---
    index = w_data * data_drift + w_model * model_drift + w_regime * regime_drift
    index = min(1.0, max(0.0, index))

    # --- Status ---
    if index >= critical_threshold:
        status = "critical"
    elif index >= review_threshold:
        status = "review"
    else:
        status = "normal"

    return DriftResult(
        index=round(index, 6),
        data_drift=round(data_drift, 6),
        model_drift=round(model_drift, 6),
        regime_drift=round(regime_drift, 6),
        status=status,
    )
