"""Early Warning System (EWS) – 4 statistical indicators.

Detects critical transitions in time series using classical EWS
indicators derived from dynamical systems theory:

1. **Variance** – rising variance signals loss of resilience.
2. **Lag-1 autocorrelation (ACF1)** – critical slowing down near tipping points.
3. **Kurtosis** – heavy-tailed increments indicate distributional change.
4. **Noise sensitivity** – increasing sensitivity to small perturbations.

All functions are pure Python with no third-party dependencies.
"""

from __future__ import annotations

from dataclasses import dataclass

# ---------------------------------------------------------------------------
# Result
# ---------------------------------------------------------------------------


@dataclass
class EWSResult:
    """Result of an EWS evaluation pass.

    Attributes:
        active: ``True`` when at least *min_triggers* indicators fired.
        variance: ``True`` when variance exceeds the baseline by
            *var_threshold* factor.
        acf: ``True`` when lag-1 autocorrelation exceeds *acf_threshold*.
        kurtosis: ``True`` when kurtosis of increments exceeds
            *kurt_threshold*.
        sensitivity: ``True`` when mean noise sensitivity exceeds
            *sens_threshold* times the baseline level.
        score: Count of indicators that fired (0–4).
    """

    active: bool
    variance: bool
    acf: bool
    kurtosis: bool
    sensitivity: bool
    score: int


# ---------------------------------------------------------------------------
# Statistical primitives – pure math, no external deps
# ---------------------------------------------------------------------------


def _variance(data: list[float]) -> float:
    """Population variance of *data*.

    Returns ``0.0`` for sequences shorter than 2 elements.
    """
    if len(data) < 2:
        return 0.0
    mean = sum(data) / len(data)
    return sum((x - mean) ** 2 for x in data) / len(data)


def _acf1(data: list[float]) -> float:
    """Lag-1 autocorrelation coefficient.

    Returns ``0.0`` for sequences shorter than 3 elements or with zero
    variance (constant series).
    """
    n = len(data)
    if n < 3:
        return 0.0
    mean = sum(data) / n
    var = sum((x - mean) ** 2 for x in data)
    if var < 1e-12:
        return 0.0
    cov = sum((data[i] - mean) * (data[i + 1] - mean) for i in range(n - 1))
    return cov / var


def _kurtosis(data: list[float]) -> float:
    """Population kurtosis (not excess kurtosis).

    Returns ``0.0`` for sequences shorter than 4 elements or with zero
    variance.
    """
    n = len(data)
    if n < 4:
        return 0.0
    mean = sum(data) / n
    var = sum((x - mean) ** 2 for x in data) / n
    if var < 1e-12:
        return 0.0
    m4 = sum((x - mean) ** 4 for x in data) / n
    return m4 / (var**2)


def _noise_sensitivity(data: list[float], baseline_sigma: float) -> float:
    """Mean of ``|Δx| / σ_baseline`` over consecutive pairs.

    Measures how large each step is relative to the expected noise
    level.  Returns ``0.0`` when the series is too short or
    *baseline_sigma* is effectively zero.
    """
    if len(data) < 2 or baseline_sigma < 1e-12:
        return 0.0
    deltas = [abs(data[i + 1] - data[i]) for i in range(len(data) - 1)]
    return sum(d / baseline_sigma for d in deltas) / len(deltas)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def evaluate_ews(
    time_series: list[float],
    window: int = 20,
    baseline_sigma: float = 1.0,
    var_threshold: float = 1.5,
    acf_threshold: float = 0.6,
    kurt_threshold: float = 3.5,
    sens_threshold: float = 2.0,
    min_triggers: int = 2,
) -> EWSResult:
    """Detect early warning signals in a time series.

    Uses a rolling window (the last *window* observations) to evaluate
    four statistical indicators.  An alert fires when at least
    *min_triggers* of the four indicators exceed their respective
    thresholds.

    Args:
        time_series: Observed values in chronological order.  At least
            *window* observations are needed for a meaningful result.
        window: Number of most-recent observations to use.
        baseline_sigma: Expected standard deviation of the series under
            normal conditions.  Used to normalise noise sensitivity.
        var_threshold: Variance trigger multiplier.  The indicator fires
            when ``current_variance > var_threshold * baseline_variance``,
            where ``baseline_variance = baseline_sigma ** 2``.
        acf_threshold: Lag-1 ACF trigger.  Fires when ``acf1 > threshold``.
        kurt_threshold: Kurtosis trigger for first-differences.  Fires
            when ``kurt(Δx) > threshold``.
        sens_threshold: Noise sensitivity trigger.  Fires when
            ``mean_sensitivity > threshold``.
        min_triggers: Minimum number of indicators that must fire for
            :attr:`EWSResult.active` to be ``True``.

    Returns:
        An :class:`EWSResult` with per-indicator flags and an overall
        activity flag.

    Example::

        from qazstack.analytics.ews import evaluate_ews

        series = [0.1, 0.2, 0.5, 0.8, 1.2, 2.1, 3.5]
        result = evaluate_ews(series, window=6, baseline_sigma=0.5)
        if result.active:
            print(f"EWS alert! {result.score}/4 indicators firing.")
    """
    # Work on the most recent *window* observations
    windowed = time_series[-window:] if len(time_series) >= window else time_series[:]

    # Need at least 4 points for kurtosis
    if len(windowed) < 4:
        return EWSResult(
            active=False,
            variance=False,
            acf=False,
            kurtosis=False,
            sensitivity=False,
            score=0,
        )

    baseline_variance = baseline_sigma**2

    # EWS-1: Variance growth
    current_var = _variance(windowed)
    variance_flag = current_var > var_threshold * baseline_variance

    # EWS-2: Critical slowing down – lag-1 ACF
    acf_flag = _acf1(windowed) > acf_threshold

    # EWS-3: Heavy tails – kurtosis of first differences
    deltas = [windowed[i + 1] - windowed[i] for i in range(len(windowed) - 1)]
    kurtosis_flag = _kurtosis(deltas) > kurt_threshold

    # EWS-4: Noise sensitivity
    sensitivity_flag = _noise_sensitivity(windowed, baseline_sigma) > sens_threshold

    score = sum([variance_flag, acf_flag, kurtosis_flag, sensitivity_flag])
    active = score >= min_triggers

    return EWSResult(
        active=active,
        variance=variance_flag,
        acf=acf_flag,
        kurtosis=kurtosis_flag,
        sensitivity=sensitivity_flag,
        score=score,
    )
