"""Pydantic response schemas for the headless content API."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field

# ── Article schemas ──────────────────────────────


class EntityBrief(BaseModel):
    """Entity reference inside an article response."""

    id: int
    name: str
    short_name: str | None = None
    entity_type: str
    mention_count: int = 0


class ArticleSummary(BaseModel):
    """Compact article for list/search results (no body)."""

    id: int
    url: str
    slug: str = ""
    pub_date: datetime | None = None
    category: str | None = Field(None, description="sub_category slug")
    category_label: str | None = None
    title: str | None = None
    author: str | None = None
    excerpt: str | None = None
    thumbnail: str | None = None
    main_image: str | None = None
    reading_time: int | None = Field(None, description="Estimated minutes")


class ArticleDetail(BaseModel):
    """Full article with body and entities."""

    id: int
    url: str
    slug: str = ""
    pub_date: datetime | None = None
    category: str | None = Field(None, description="sub_category slug")
    category_label: str | None = None
    title: str | None = None
    author: str | None = None
    excerpt: str | None = None
    body_text: str | None = None
    body_html: str | None = None
    main_image: str | None = None
    image_credit: str | None = None
    thumbnail: str | None = None
    tags: list[str] = Field(default_factory=list)
    inline_images: list[str] = Field(default_factory=list)
    entities: list[EntityBrief] = Field(default_factory=list)
    reading_time: int | None = Field(None, description="Estimated minutes")
    imported_at: datetime | None = None
    extras: dict[str, Any] = Field(default_factory=dict)


class ArticleListResponse(BaseModel):
    """Paginated article list."""

    articles: list[ArticleSummary]
    total: int
    page: int = 1
    per_page: int = 20
    pages: int = 1


# ── Category / Tag / Entity schemas ─────────────


class CategoryCount(BaseModel):
    """Category with article count."""

    slug: str
    label: str | None = None
    count: int = 0


class TagCount(BaseModel):
    """Tag with usage count."""

    tag: str
    count: int = 0


class EntityDetail(BaseModel):
    """Entity with metadata and article count."""

    id: int
    name: str
    short_name: str | None = None
    entity_type: str
    normalized: str | None = None
    article_count: int = 0


class EntityListResponse(BaseModel):
    """List of entities."""

    entities: list[EntityDetail]
    total: int = 0
