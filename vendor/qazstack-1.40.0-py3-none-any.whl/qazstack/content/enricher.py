"""Article full-text extraction via newspaper4k.

Downloads an article page and extracts: full text, authors, publish date,
keywords (NLP), summary, language, and top image.

Usage::

    from qazstack.content import extract_fulltext, EnrichResult

    result = extract_fulltext("https://example.com/article")
    if result.ok:
        print(result.text, result.word_count, result.language)

    # With custom timeout and user-agent:
    result = extract_fulltext(url, timeout=20, user_agent="MyBot/1.0")

Requires: ``pip install newspaper4k lxml_html_clean``
or: ``pip install qazstack[enricher]``
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

logger = logging.getLogger("qazstack.content.enricher")

# Domains that block bots or don't contain article text
SKIP_DOMAINS: frozenset[str] = frozenset(
    {
        "youtube.com",
        "youtu.be",
        "twitter.com",
        "x.com",
        "facebook.com",
        "instagram.com",
        "tiktok.com",
        "t.me",
        "reddit.com",
        "linkedin.com",
        "vk.com",
        "drive.google.com",
        "docs.google.com",
    }
)

DEFAULT_USER_AGENT = "Mozilla/5.0 (X11; Linux x86_64; rv:130.0) Gecko/20100101 Firefox/130.0"

MIN_WORD_COUNT = 30


@dataclass(frozen=True)
class EnrichResult:
    """Result of article full-text extraction."""

    text: str = ""
    authors: list[str] = field(default_factory=list)
    publish_date: str | None = None  # ISO format
    keywords: list[str] = field(default_factory=list)
    summary: str = ""
    language: str = ""
    top_image: str = ""
    meta_description: str = ""
    word_count: int = 0
    ok: bool = False
    error: str | None = None


_EMPTY = EnrichResult()


def should_skip_domain(domain: str) -> bool:
    """Check if a domain should be skipped (social media, video platforms)."""
    d = (domain or "").lower().strip()
    return any(skip in d for skip in SKIP_DOMAINS)


def extract_fulltext(
    url: str,
    *,
    timeout: int = 15,
    user_agent: str = DEFAULT_USER_AGENT,
    fetch_images: bool = False,
    min_words: int = MIN_WORD_COUNT,
) -> EnrichResult:
    """Download and parse an article, extracting full text and metadata.

    Args:
        url: Article URL.
        timeout: Request timeout in seconds.
        user_agent: HTTP User-Agent header.
        fetch_images: Whether to download images.
        min_words: Minimum word count for ``ok=True``.

    Returns:
        EnrichResult with extracted data. ``ok=True`` if enough text found.

    Raises:
        ImportError: if newspaper4k is not installed.
    """
    if not url or not url.strip():
        return _EMPTY

    try:
        from newspaper import Article as NpArticle  # noqa: F811
        from newspaper import Config
    except ImportError:
        raise ImportError(
            "newspaper4k not installed. "
            "Install with: pip install qazstack[enricher] "
            "or: pip install newspaper4k lxml_html_clean"
        )

    config = Config()
    config.browser_user_agent = user_agent
    config.request_timeout = timeout
    config.fetch_images = fetch_images
    config.memoize_articles = False

    try:
        article = NpArticle(url, config=config)
        article.download()
        article.parse()

        text = (article.text or "").strip()
        authors = article.authors or []
        top_image = article.top_image or ""
        meta_description = (article.meta_description or "").strip()

        # Publish date
        publish_date = None
        if article.publish_date:
            try:
                publish_date = article.publish_date.isoformat()
            except (AttributeError, ValueError):
                pass

        # NLP: keywords and summary (may fail on some languages)
        keywords: list[str] = []
        summary = ""
        try:
            article.nlp()
            keywords = article.keywords or []
            summary = (article.summary or "").strip()
        except Exception:
            pass

        # Language from meta tag
        language = ""
        if hasattr(article, "meta_lang") and article.meta_lang:
            language = article.meta_lang.strip()[:2].lower()

        word_count = len(text.split()) if text else 0
        ok = word_count >= min_words

        return EnrichResult(
            text=text,
            authors=authors[:10],
            publish_date=publish_date,
            keywords=keywords[:20],
            summary=summary[:1000],
            language=language,
            top_image=top_image[:500] if top_image else "",
            meta_description=meta_description[:500],
            word_count=word_count,
            ok=ok,
            error=None,
        )

    except Exception as e:
        return EnrichResult(error=str(e)[:300])
