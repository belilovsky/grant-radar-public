"""Content loaders: JSONL, JSONL.gz, split archives."""

from __future__ import annotations

import gzip
import io
import json
import logging
from pathlib import Path
from typing import IO, Iterator

from .models import Article
from .utils import parse_ru_date

logger = logging.getLogger("qazstack.content")


def _open_jsonl(path: Path) -> IO[str]:
    """Open a JSONL file, auto-detecting gzip compression."""
    if path.suffix == ".gz" or path.name.endswith(".jsonl.gz"):
        return io.TextIOWrapper(gzip.open(path, "rb"), encoding="utf-8")
    return open(path, "r", encoding="utf-8")


def iter_jsonl(path: str | Path, *, fix_dates: bool = True) -> Iterator[Article]:
    """Iterate over articles from a JSONL or JSONL.gz file.

    Args:
        path: Path to .jsonl or .jsonl.gz file.
        fix_dates: If True, attempt to parse Russian date_text when pub_date is missing.

    Yields:
        Article instances.
    """
    p = Path(path)
    with _open_jsonl(p) as f:
        for lineno, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                data = json.loads(line)
            except json.JSONDecodeError:
                logger.warning("Skipping invalid JSON at %s:%d", p.name, lineno)
                continue

            # Fix missing pub_date from date_text (Russian format)
            if fix_dates and not data.get("pub_date") and data.get("date_text"):
                dt = parse_ru_date(data["date_text"])
                if dt:
                    data["pub_date"] = dt.isoformat()

            try:
                yield Article.model_validate(data)
            except Exception:
                logger.warning("Skipping invalid article at %s:%d", p.name, lineno)


def load_jsonl(path: str | Path, *, fix_dates: bool = True) -> list[Article]:
    """Load all articles from a JSONL or JSONL.gz file into a list."""
    return list(iter_jsonl(path, fix_dates=fix_dates))


class ArchiveReader:
    """Read articles from split JSONL.gz archives (e.g., articles.jsonl.gz.part_aa, part_ab, ...).

    Handles the pattern where large JSONL.gz files are split with `split -b 10M`.

    Usage:
        reader = ArchiveReader("/path/to/data")
        for article in reader.iter_articles():
            process(article)

        # Or load all:
        articles = reader.load_all()
    """

    def __init__(self, data_dir: str | Path, pattern: str = "*.jsonl.gz.part_*"):
        self.data_dir = Path(data_dir)
        self.pattern = pattern

    def _find_parts(self) -> list[Path]:
        """Find and sort split archive parts."""
        parts = sorted(self.data_dir.glob(self.pattern))
        if not parts:
            # Try single .jsonl.gz file
            gz_files = sorted(self.data_dir.glob("*.jsonl.gz"))
            if gz_files:
                return gz_files
            # Try plain .jsonl
            jsonl_files = sorted(self.data_dir.glob("*.jsonl"))
            return jsonl_files
        return parts

    def _combined_stream(self) -> IO[bytes]:
        """Combine split parts into a single byte stream."""
        parts = self._find_parts()
        if not parts:
            raise FileNotFoundError(f"No JSONL archive files found in {self.data_dir}")

        # If single file (not split parts), just open it
        if len(parts) == 1 and not parts[0].name.endswith((".part_aa", ".part_ab")):
            return open(parts[0], "rb")

        # Check if these are split gz parts (need concatenation before decompression)
        if parts[0].name.endswith(tuple(f".part_{chr(97 + i)}{chr(97 + j)}" for i in range(26) for j in range(26))):
            # Concatenate split parts into a single stream
            combined = io.BytesIO()
            for part in parts:
                combined.write(part.read_bytes())
            combined.seek(0)
            return combined

        # Return first file (fallback)
        return open(parts[0], "rb")

    def iter_articles(self, *, fix_dates: bool = True) -> Iterator[Article]:
        """Iterate over all articles in the archive.

        Handles:
        - Single .jsonl file
        - Single .jsonl.gz file
        - Split .jsonl.gz.part_* files (concatenated before decompression)
        """
        parts = self._find_parts()
        if not parts:
            logger.warning("No archive files found in %s", self.data_dir)
            return

        is_split_gz = any(
            p.name.endswith(tuple(f".part_{chr(97 + i)}{chr(97 + j)}" for i in range(26) for j in range(26)))
            for p in parts
        )

        if is_split_gz:
            # Concatenate all parts, then decompress as one stream
            raw_stream = self._combined_stream()
            text_stream = io.TextIOWrapper(gzip.GzipFile(fileobj=raw_stream), encoding="utf-8")
            yield from self._parse_stream(text_stream, fix_dates=fix_dates, source="archive")
            raw_stream.close()
        else:
            # Process each file individually
            for p in parts:
                yield from iter_jsonl(p, fix_dates=fix_dates)

    def _parse_stream(
        self,
        stream: IO[str],
        *,
        fix_dates: bool = True,
        source: str = "stream",
    ) -> Iterator[Article]:
        """Parse a text stream of JSONL lines into Articles."""
        for lineno, line in enumerate(stream, 1):
            line = line.strip()
            if not line:
                continue
            try:
                data = json.loads(line)
            except json.JSONDecodeError:
                logger.warning("Skipping invalid JSON at %s:%d", source, lineno)
                continue

            if fix_dates and not data.get("pub_date") and data.get("date_text"):
                dt = parse_ru_date(data["date_text"])
                if dt:
                    data["pub_date"] = dt.isoformat()

            try:
                yield Article.model_validate(data)
            except Exception:
                logger.warning("Skipping invalid article at %s:%d", source, lineno)

    def load_all(self, *, fix_dates: bool = True) -> list[Article]:
        """Load all articles from the archive into a list."""
        return list(self.iter_articles(fix_dates=fix_dates))

    def count(self) -> int:
        """Count articles in the archive (reads entire archive)."""
        return sum(1 for _ in self.iter_articles(fix_dates=False))

    @property
    def has_data(self) -> bool:
        """Check if any archive files exist."""
        return len(self._find_parts()) > 0
