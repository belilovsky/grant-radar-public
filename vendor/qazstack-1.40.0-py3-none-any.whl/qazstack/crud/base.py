"""Generic async CRUD operations for SQLAlchemy 2.0 models.

Works with any SQLAlchemy model class. Supports:
- Single record get/create/update/delete
- Multi-record listing with filtering, ordering, pagination
- Soft delete (if model has is_deleted/deleted_at field)
- Bulk operations

All methods accept an AsyncSession and return model instances or Page objects.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Generic, Sequence, Type, TypeVar

from pydantic import BaseModel
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from qazstack.pagination.page import Page, Params

ModelType = TypeVar("ModelType")
CreateSchemaType = TypeVar("CreateSchemaType", bound=BaseModel)
UpdateSchemaType = TypeVar("UpdateSchemaType", bound=BaseModel)


class CRUDBase(Generic[ModelType, CreateSchemaType, UpdateSchemaType]):
    """Generic CRUD operations.

    Subclass for model-specific behavior:

        class ArticleCRUD(CRUDBase[Article, ArticleCreate, ArticleUpdate]):
            async def get_by_slug(self, session, slug: str):
                return await self.get_by(session, slug=slug)

        articles = ArticleCRUD(Article)
    """

    def __init__(self, model: Type[ModelType]):
        self.model = model

    # --- Read ---

    async def get(self, session: AsyncSession, id: Any) -> ModelType | None:
        """Get a single record by primary key."""
        result = await session.execute(select(self.model).where(self.model.id == id))
        return result.scalars().first()

    async def get_by(self, session: AsyncSession, **kwargs: Any) -> ModelType | None:
        """Get a single record by arbitrary column filters.

        Usage: await crud.get_by(session, slug="my-article", lang="ru")
        """
        query = select(self.model)
        for key, value in kwargs.items():
            if hasattr(self.model, key):
                query = query.where(getattr(self.model, key) == value)
        result = await session.execute(query)
        return result.scalars().first()

    async def get_multi(
        self,
        session: AsyncSession,
        *,
        params: Params | None = None,
        order_by: Any = None,
        filters: dict[str, Any] | None = None,
    ) -> Page[ModelType]:
        """Get paginated list of records with optional filters.

        Args:
            session: AsyncSession.
            params: Pagination params (defaults to page=1, per_page=20).
            order_by: SQLAlchemy column expression (e.g., Article.id.desc()).
            filters: Dict of column_name: value filters.

        Returns:
            Page[ModelType] with items, total, page info.
        """
        if params is None:
            params = Params()

        query = select(self.model)

        # Apply filters
        if filters:
            for key, value in filters.items():
                if hasattr(self.model, key) and value is not None:
                    if isinstance(value, (list, tuple)):
                        query = query.where(getattr(self.model, key).in_(value))
                    else:
                        query = query.where(getattr(self.model, key) == value)

        # Count
        count_query = select(func.count()).select_from(query.subquery())
        total_result = await session.execute(count_query)
        total = total_result.scalar_one()

        # Order
        if order_by is not None:
            query = query.order_by(order_by)

        # Paginate
        query = query.offset(params.offset).limit(params.limit)
        result = await session.execute(query)
        items = result.scalars().all()

        return Page.create(items=items, total=total, params=params)

    async def get_all(
        self,
        session: AsyncSession,
        *,
        order_by: Any = None,
        filters: dict[str, Any] | None = None,
    ) -> list[ModelType]:
        """Get all records (no pagination). Use with caution on large tables."""
        query = select(self.model)

        if filters:
            for key, value in filters.items():
                if hasattr(self.model, key) and value is not None:
                    query = query.where(getattr(self.model, key) == value)

        if order_by is not None:
            query = query.order_by(order_by)

        result = await session.execute(query)
        return list(result.scalars().all())

    async def count(self, session: AsyncSession, **filters: Any) -> int:
        """Count records with optional filters."""
        query = select(func.count()).select_from(self.model)
        for key, value in filters.items():
            if hasattr(self.model, key) and value is not None:
                query = query.where(getattr(self.model, key) == value)
        result = await session.execute(query)
        return result.scalar_one()

    # --- Create ---

    async def create(self, session: AsyncSession, *, obj_in: CreateSchemaType | dict[str, Any]) -> ModelType:
        """Create a new record.

        Args:
            session: AsyncSession.
            obj_in: Pydantic schema or dict with field values.

        Returns:
            Created model instance.
        """
        if isinstance(obj_in, dict):
            data = obj_in
        else:
            data = obj_in.model_dump(exclude_unset=True)

        instance = self.model(**data)
        session.add(instance)
        await session.flush()
        await session.refresh(instance)
        return instance

    async def create_many(
        self, session: AsyncSession, *, objects: Sequence[CreateSchemaType | dict[str, Any]]
    ) -> list[ModelType]:
        """Bulk create records."""
        instances = []
        for obj_in in objects:
            data = obj_in if isinstance(obj_in, dict) else obj_in.model_dump(exclude_unset=True)
            instance = self.model(**data)
            session.add(instance)
            instances.append(instance)
        await session.flush()
        for inst in instances:
            await session.refresh(inst)
        return instances

    # --- Update ---

    async def update(
        self,
        session: AsyncSession,
        *,
        id: Any,
        obj_in: UpdateSchemaType | dict[str, Any],
    ) -> ModelType | None:
        """Update a record by primary key.

        Args:
            session: AsyncSession.
            id: Primary key value.
            obj_in: Pydantic schema or dict with updated fields.

        Returns:
            Updated model instance, or None if not found.
        """
        instance = await self.get(session, id=id)
        if not instance:
            return None

        if isinstance(obj_in, dict):
            data = obj_in
        else:
            data = obj_in.model_dump(exclude_unset=True)

        for key, value in data.items():
            if hasattr(instance, key):
                setattr(instance, key, value)

        session.add(instance)
        await session.flush()
        await session.refresh(instance)
        return instance

    # --- Delete ---

    async def delete(self, session: AsyncSession, *, id: Any) -> bool:
        """Hard delete a record by primary key.

        Returns True if deleted, False if not found.
        """
        instance = await self.get(session, id=id)
        if not instance:
            return False
        await session.delete(instance)
        await session.flush()
        return True

    async def soft_delete(self, session: AsyncSession, *, id: Any) -> ModelType | None:
        """Soft delete: set is_deleted=True and deleted_at timestamp.

        Only works if model has `is_deleted` and/or `deleted_at` columns.
        Falls back to hard delete if columns don't exist.
        """
        instance = await self.get(session, id=id)
        if not instance:
            return None

        if hasattr(instance, "is_deleted"):
            instance.is_deleted = True
        if hasattr(instance, "deleted_at"):
            instance.deleted_at = datetime.now(timezone.utc)

        if not hasattr(instance, "is_deleted") and not hasattr(instance, "deleted_at"):
            # No soft delete columns – fall back to hard delete
            await session.delete(instance)
            await session.flush()
            return instance

        session.add(instance)
        await session.flush()
        await session.refresh(instance)
        return instance

    # --- Search ---

    async def search(
        self,
        session: AsyncSession,
        *,
        field: str,
        query: str,
        params: Params | None = None,
    ) -> Page[ModelType]:
        """Simple ILIKE search on a text field.

        Usage: await crud.search(session, field="title", query="конституция")
        """
        if params is None:
            params = Params()

        col = getattr(self.model, field)
        stmt = select(self.model).where(col.ilike(f"%{query}%"))

        count_stmt = select(func.count()).select_from(stmt.subquery())
        total = (await session.execute(count_stmt)).scalar_one()

        stmt = stmt.offset(params.offset).limit(params.limit)
        result = await session.execute(stmt)
        items = result.scalars().all()

        return Page.create(items=items, total=total, params=params)
