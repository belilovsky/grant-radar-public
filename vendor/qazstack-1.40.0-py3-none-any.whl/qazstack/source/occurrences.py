"""Portable records for one observed appearance of a source item."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone

from qazstack.contracts._validation import (
    require_aware,
    require_http_url,
    require_identifier,
    require_one_of,
    require_sha256,
    require_text,
)

SOURCE_OCCURRENCE_SCHEMA_VERSION = "qazstack-source-occurrence-v1"
SOURCE_CHANNELS = frozenset({"web", "social", "messaging", "broadcast", "document", "dataset", "other"})


def _utc_iso(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


@dataclass(frozen=True, slots=True)
class SourceOccurrence:
    """One traceable appearance of a claim, media artifact or content item.

    The contract separates a publisher/source identity from the place where an
    item was observed. It intentionally carries no source-trust score or
    editorial interpretation.
    """

    occurrence_id: str
    source_id: str
    subject_refs: tuple[str, ...]
    channel: str
    observed_at: datetime
    source_url: str = ""
    source_locator: str = ""
    published_at: datetime | None = None
    author: str = ""
    language: str = ""
    content_digest: str = ""
    capture_id: str = ""
    schema_version: str = SOURCE_OCCURRENCE_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.schema_version != SOURCE_OCCURRENCE_SCHEMA_VERSION:
            raise ValueError(f"schema_version must be {SOURCE_OCCURRENCE_SCHEMA_VERSION}")
        require_identifier(self.occurrence_id, "occurrence_id")
        require_identifier(self.source_id, "source_id")
        require_one_of(self.channel, SOURCE_CHANNELS, "channel")
        require_aware(self.observed_at, "observed_at")
        if not self.subject_refs:
            raise ValueError("subject_refs must not be empty")
        if len(set(self.subject_refs)) != len(self.subject_refs):
            raise ValueError("subject_refs must not contain duplicates")
        for subject_ref in self.subject_refs:
            require_identifier(subject_ref, "subject_refs")
        if not self.source_url and not self.source_locator.strip():
            raise ValueError("source_url or source_locator is required")
        if self.source_url:
            object.__setattr__(self, "source_url", require_http_url(self.source_url, "source_url"))
        if self.source_locator:
            object.__setattr__(self, "source_locator", require_text(self.source_locator, "source_locator"))
        if self.published_at is not None:
            require_aware(self.published_at, "published_at")
        if self.language:
            object.__setattr__(self, "language", require_identifier(self.language, "language"))
        if self.content_digest:
            object.__setattr__(self, "content_digest", require_sha256(self.content_digest, "content_digest"))
        if self.capture_id:
            require_identifier(self.capture_id, "capture_id")

    def as_dict(self) -> dict[str, object]:
        """Return a stable JSON-compatible projection for buses and exports."""
        return {
            "schema_version": self.schema_version,
            "occurrence_id": self.occurrence_id,
            "source_id": self.source_id,
            "subject_refs": list(self.subject_refs),
            "channel": self.channel,
            "observed_at": _utc_iso(self.observed_at),
            "source_url": self.source_url or None,
            "source_locator": self.source_locator or None,
            "published_at": _utc_iso(self.published_at) if self.published_at else None,
            "author": self.author or None,
            "language": self.language or None,
            "content_digest": self.content_digest or None,
            "capture_id": self.capture_id or None,
        }
