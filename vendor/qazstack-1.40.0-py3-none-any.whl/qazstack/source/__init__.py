"""Portable source normalization and link-candidate primitives."""

from qazstack.source.links import (
    SourceCandidate,
    canonicalize_source_url,
    extract_source_candidates_from_links,
    publisher_from_url,
    source_type_from_url,
)
from qazstack.source.occurrences import SOURCE_CHANNELS, SOURCE_OCCURRENCE_SCHEMA_VERSION, SourceOccurrence

__all__ = [
    "SourceCandidate",
    "SourceOccurrence",
    "SOURCE_CHANNELS",
    "SOURCE_OCCURRENCE_SCHEMA_VERSION",
    "canonicalize_source_url",
    "extract_source_candidates_from_links",
    "publisher_from_url",
    "source_type_from_url",
]
