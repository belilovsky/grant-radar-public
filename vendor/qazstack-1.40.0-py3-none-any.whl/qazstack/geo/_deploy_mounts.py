"""Add qazstack bind-mount to docker-compose files where missing."""

import os

MOUNT_LINE = "      - /opt/qazstack/src/qazstack:/usr/local/lib/python3.12/site-packages/qazstack:ro\n"

PROJECTS = {
    "/opt/shelter-kz": "app:",
    "/opt/pssr-regime-engine": "app:",
    "/opt/npa-collector": "npa-api:",
}

for project_dir, service_name in PROJECTS.items():
    dc = os.path.join(project_dir, "docker-compose.yml")
    if not os.path.exists(dc):
        print(f"  {project_dir}: docker-compose.yml not found")
        continue

    with open(dc) as f:
        content = f.read()

    if "/opt/qazstack" in content:
        print(f"  {os.path.basename(project_dir)}: already has mount")
        continue

    lines = content.split("\n")
    new_lines = []
    in_service = False
    found_volumes = False
    inserted = False
    needs_volumes_section = True

    for i, line in enumerate(lines):
        stripped = line.strip()

        if stripped == service_name or stripped == f"{service_name}":
            in_service = True

        if in_service and stripped == "volumes:" and not inserted:
            found_volumes = True
            needs_volumes_section = False
            new_lines.append(line)
            continue

        if found_volumes and stripped.startswith("-") and not inserted:
            new_lines.append(line)
            new_lines.append(MOUNT_LINE.rstrip())
            inserted = True
            found_volumes = False
            continue

        # For npa-collector which may not have volumes section
        if in_service and needs_volumes_section and stripped.startswith("environment:") and not inserted:
            new_lines.append("    volumes:")
            new_lines.append(MOUNT_LINE.rstrip())
            inserted = True
            needs_volumes_section = False

        new_lines.append(line)

    if inserted:
        with open(dc, "w") as f:
            f.write("\n".join(new_lines))
        print(f"  {os.path.basename(project_dir)}: bind-mount added")
    else:
        print(f"  {os.path.basename(project_dir)}: could not find insertion point")
