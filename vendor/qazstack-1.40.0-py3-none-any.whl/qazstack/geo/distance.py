"""Geographic distance calculations – pure math, no DB dependencies."""

from __future__ import annotations

import math
from dataclasses import dataclass


def haversine(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Calculate great-circle distance in kilometers between two points.

    Uses the Haversine formula. Accurate for most practical purposes
    (error < 0.5% vs Vincenty for Kazakhstan-sized distances).

    Args:
        lat1, lon1: First point (degrees).
        lat2, lon2: Second point (degrees).

    Returns:
        Distance in kilometers.
    """
    R = 6371.0  # Earth radius in km
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda / 2) ** 2
    return 2 * R * math.atan2(math.sqrt(a), math.sqrt(1 - a))


def haversine_batch(
    origin: tuple[float, float],
    points: list[tuple[float, float]],
) -> list[float]:
    """Calculate distances from origin to multiple points.

    Args:
        origin: (lat, lon) of the reference point.
        points: List of (lat, lon) tuples.

    Returns:
        List of distances in km, same order as points.
    """
    lat1, lon1 = origin
    return [haversine(lat1, lon1, lat2, lon2) for lat2, lon2 in points]


@dataclass
class BBox:
    """Bounding box (min_lat, min_lon, max_lat, max_lon)."""

    min_lat: float
    min_lon: float
    max_lat: float
    max_lon: float

    def contains(self, lat: float, lon: float) -> bool:
        """Check if a point is inside the bounding box."""
        return self.min_lat <= lat <= self.max_lat and self.min_lon <= lon <= self.max_lon

    def expand(self, km: float) -> "BBox":
        """Return a new BBox expanded by approximately `km` kilometers."""
        # ~111 km per degree latitude, longitude varies by cos(lat)
        dlat = km / 111.0
        mid_lat = (self.min_lat + self.max_lat) / 2
        dlon = km / (111.0 * math.cos(math.radians(mid_lat))) if mid_lat != 90 else km / 111.0
        return BBox(
            min_lat=self.min_lat - dlat,
            min_lon=self.min_lon - dlon,
            max_lat=self.max_lat + dlat,
            max_lon=self.max_lon + dlon,
        )


def bounding_box(
    lat: float,
    lon: float,
    radius_km: float,
) -> BBox:
    """Calculate a bounding box around a point.

    Useful for pre-filtering DB queries before exact distance calculation.

    Args:
        lat, lon: Center point (degrees).
        radius_km: Radius in kilometers.

    Returns:
        BBox with approximate bounds.
    """
    dlat = radius_km / 111.0
    dlon = radius_km / (111.0 * math.cos(math.radians(lat))) if abs(lat) != 90 else radius_km / 111.0
    return BBox(
        min_lat=lat - dlat,
        min_lon=lon - dlon,
        max_lat=lat + dlat,
        max_lon=lon + dlon,
    )


# ── Kazakhstan-specific constants ──────────────────────────────────────────

# Approximate bounding box of Kazakhstan
KZ_BBOX = BBox(min_lat=40.56, min_lon=46.49, max_lat=55.44, max_lon=87.31)

# Center of Kazakhstan (approximate)
KZ_CENTER = (48.0196, 66.9237)
