"""GeoJSON helpers – pure Python, no DB or external dependencies.

Build and manipulate GeoJSON FeatureCollections for choropleth maps,
point clusters, and metric overlays.  Extracted from QazGeo's
``services/choropleth.py`` but stripped of all SQLAlchemy / PostGIS
coupling so any project can use it with any data source.

Examples
--------
Merge a metric onto pre-loaded features::

    fc = feature_collection(features)
    merged = merge_metric(fc, "population", {"KZ-ALA": 2.1e6, "KZ-AST": 1.4e6})
    stats = compute_stats([f["properties"]["population"] for f in merged["features"]
                           if f["properties"].get("population") is not None])

Create a feature from scratch::

    f = feature(
        geometry={"type": "Point", "coordinates": [71.43, 51.13]},
        properties={"name": "Астана"},
        feature_id="KZ-AST",
    )
"""

from __future__ import annotations

from typing import Any

# ---------------------------------------------------------------------------
# Feature builders
# ---------------------------------------------------------------------------


def feature(
    geometry: dict[str, Any] | None,
    properties: dict[str, Any] | None = None,
    feature_id: str | None = None,
) -> dict[str, Any]:
    """Build a single GeoJSON Feature dict.

    Args:
        geometry: GeoJSON geometry object (Point, Polygon, etc.) or ``None``.
        properties: Arbitrary key-value properties.
        feature_id: Optional stable identifier (written to ``"id"`` key).

    Returns:
        A valid GeoJSON Feature dict.
    """
    f: dict[str, Any] = {
        "type": "Feature",
        "geometry": geometry,
        "properties": properties or {},
    }
    if feature_id is not None:
        f["id"] = feature_id
    return f


def feature_collection(
    features: list[dict[str, Any]],
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build a GeoJSON FeatureCollection dict.

    Args:
        features: List of GeoJSON Feature dicts.
        metadata: Extra metadata attached at the collection level.

    Returns:
        A valid GeoJSON FeatureCollection dict with optional ``metadata``
        key (non-standard but widely used by Leaflet / Mapbox helpers).
    """
    fc: dict[str, Any] = {
        "type": "FeatureCollection",
        "features": features,
    }
    if metadata:
        fc["metadata"] = metadata
    return fc


# ---------------------------------------------------------------------------
# Metric helpers
# ---------------------------------------------------------------------------


def merge_metric(
    fc: dict[str, Any],
    metric_name: str,
    data: dict[str, float | int | None],
    *,
    id_key: str = "id",
    case_insensitive: bool = True,
) -> dict[str, Any]:
    """Merge external metric values into a FeatureCollection.

    Each feature is looked up by its ``id`` (or ``properties[id_key]``) and
    the metric value is injected into ``properties[metric_name]``.
    Features not found in *data* get ``None``.

    Mutates a **copy** of the input collection – the original is not modified.

    Args:
        fc: GeoJSON FeatureCollection.
        metric_name: Property name for the metric (e.g. ``"population"``).
        data: Mapping of feature-id → value.
        id_key: Where to find the feature identifier (``"id"`` top-level
            or a property name).
        case_insensitive: Normalise lookup keys to uppercase.

    Returns:
        New FeatureCollection with metric values merged in and a
        ``metadata`` block containing stats and coverage info.
    """
    if case_insensitive:
        norm: dict[str, float | int | None] = {str(k).upper(): v for k, v in data.items()}
    else:
        norm = {str(k): v for k, v in data.items()}

    out_features: list[dict[str, Any]] = []
    missing_ids: list[str] = []

    for f in fc.get("features", []):
        # Resolve feature id
        fid = f.get("id") if id_key == "id" else f.get("properties", {}).get(id_key)
        fid_str = str(fid).upper() if (fid is not None and case_insensitive) else str(fid) if fid is not None else ""

        # Deep-copy props
        new_props = dict(f.get("properties", {}))
        value = norm.get(fid_str)
        new_props[metric_name] = value
        if value is None:
            missing_ids.append(fid_str)

        new_f = dict(f)
        new_f["properties"] = new_props
        out_features.append(new_f)

    provided = [v for v in norm.values() if v is not None]

    return {
        "type": "FeatureCollection",
        "features": out_features,
        "metadata": {
            "metric": metric_name,
            "stats": compute_stats(provided),
            "total_features": len(out_features),
            "features_with_data": len(provided),
            "features_missing": missing_ids,
        },
    }


def compute_stats(values: list[float | int]) -> dict[str, float | None]:
    """Compute min / max / mean / median for a list of numeric values.

    Args:
        values: Numeric values (``None`` values should be filtered out
            by the caller).

    Returns:
        Dict with ``min``, ``max``, ``mean``, ``median`` keys.
        All ``None`` if the input list is empty.
    """
    if not values:
        return {"min": None, "max": None, "mean": None, "median": None}

    sorted_v = sorted(values)
    n = len(sorted_v)
    mid = n // 2
    median = (sorted_v[mid] + sorted_v[mid - 1]) / 2 if n % 2 == 0 else sorted_v[mid]

    return {
        "min": float(min(sorted_v)),
        "max": float(max(sorted_v)),
        "mean": float(sum(sorted_v) / n),
        "median": float(median),
    }


# ---------------------------------------------------------------------------
# Point helpers
# ---------------------------------------------------------------------------


def point_feature(
    lat: float,
    lon: float,
    properties: dict[str, Any] | None = None,
    feature_id: str | None = None,
) -> dict[str, Any]:
    """Shortcut for creating a GeoJSON Point feature.

    Args:
        lat: Latitude (degrees).
        lon: Longitude (degrees).
        properties: Arbitrary properties.
        feature_id: Optional feature id.

    Returns:
        GeoJSON Feature with Point geometry.
    """
    return feature(
        geometry={"type": "Point", "coordinates": [lon, lat]},
        properties=properties,
        feature_id=feature_id,
    )


def points_collection(
    points: list[tuple[float, float, dict[str, Any] | None]],
) -> dict[str, Any]:
    """Build a FeatureCollection from a list of ``(lat, lon, props)`` tuples.

    Args:
        points: Each element is ``(lat, lon, properties_or_None)``.

    Returns:
        GeoJSON FeatureCollection.
    """
    features = [point_feature(lat, lon, props, feature_id=str(i)) for i, (lat, lon, props) in enumerate(points)]
    return feature_collection(features)
