"""SEO meta tag generation for Jinja2 templates.

Usage:
    from qazstack.seo import Meta, meta_tags

    meta = Meta(
        title="Конституция Казахстана",
        description="Полный текст Конституции",
        url="https://constitution.my/",
        image="https://constitution.my/static/og.png",
    )

    # In Jinja2: {{ meta_tags(meta) | safe }}
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Meta:
    """SEO metadata for a page."""

    title: str = ""
    description: str = ""
    url: str = ""
    image: str = ""
    site_name: str = ""
    type: str = "website"
    locale: str = "ru_RU"
    twitter_card: str = "summary_large_image"
    canonical: str = ""
    keywords: list[str] = field(default_factory=list)
    author: str = ""
    extra: dict[str, str] = field(default_factory=dict)

    @property
    def canonical_url(self) -> str:
        return self.canonical or self.url


def meta_tags(meta: Meta) -> str:
    """Generate HTML meta tags string."""
    parts: list[str] = []

    if meta.title:
        parts.append(f"<title>{_esc(meta.title)}</title>")
        parts.append(f'<meta property="og:title" content="{_esc(meta.title)}">')
        parts.append(f'<meta name="twitter:title" content="{_esc(meta.title)}">')

    if meta.description:
        parts.append(f'<meta name="description" content="{_esc(meta.description)}">')
        parts.append(f'<meta property="og:description" content="{_esc(meta.description)}">')
        parts.append(f'<meta name="twitter:description" content="{_esc(meta.description)}">')

    if meta.canonical_url:
        parts.append(f'<link rel="canonical" href="{meta.canonical_url}">')
        parts.append(f'<meta property="og:url" content="{meta.canonical_url}">')

    if meta.image:
        parts.append(f'<meta property="og:image" content="{meta.image}">')
        parts.append(f'<meta name="twitter:image" content="{meta.image}">')

    if meta.site_name:
        parts.append(f'<meta property="og:site_name" content="{_esc(meta.site_name)}">')

    parts.append(f'<meta property="og:type" content="{meta.type}">')
    parts.append(f'<meta property="og:locale" content="{meta.locale}">')
    parts.append(f'<meta name="twitter:card" content="{meta.twitter_card}">')

    if meta.keywords:
        parts.append(f'<meta name="keywords" content="{_esc(", ".join(meta.keywords))}">')

    if meta.author:
        parts.append(f'<meta name="author" content="{_esc(meta.author)}">')

    for name, content in meta.extra.items():
        parts.append(f'<meta name="{_esc(name)}" content="{_esc(content)}">')

    return "\n    ".join(parts)


def _esc(s: str) -> str:
    """Escape HTML entities in attribute values."""
    return s.replace("&", "&amp;").replace('"', "&quot;").replace("<", "&lt;").replace(">", "&gt;")
