"""Sitemap and robots.txt generation.

Usage:
    from qazstack.seo import sitemap_router

    # With static URLs
    router = sitemap_router(
        base_url="https://qazpolit.kz",
        static_urls=["/", "/about", "/contacts"],
    )
    app.include_router(router)

    # With dynamic URL callback
    async def get_urls():
        return ["/entity/1", "/entity/2", "/category/politics"]

    router = sitemap_router(
        base_url="https://qazpolit.kz",
        static_urls=["/", "/about"],
        dynamic_urls_fn=get_urls,
    )
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Awaitable, Callable, Mapping, Sequence

from fastapi import APIRouter
from fastapi.responses import PlainTextResponse, Response


def render_sitemap_xml(
    items: Sequence[Mapping[str, str]],
    *,
    base_url: str | None = None,
) -> str:
    """Render sitemap XML while preserving each entry's freshness metadata."""
    base = (base_url or "").rstrip("/")
    lines = ['<?xml version="1.0" encoding="UTF-8"?>']
    lines.append('<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">')
    for item in items:
        raw_location = str(item["loc"])
        location = f"{base}{raw_location}" if base and raw_location.startswith("/") else raw_location
        lines.append("  <url>")
        lines.append(f"    <loc>{location}</loc>")
        for key in ("lastmod", "changefreq", "priority"):
            value = item.get(key)
            if value:
                lines.append(f"    <{key}>{value}</{key}>")
        lines.append("  </url>")
    lines.append("</urlset>")
    return "\n".join(lines)


def sitemap_router(
    base_url: str,
    *,
    static_urls: Sequence[str] | None = None,
    dynamic_urls_fn: Callable[[], Awaitable[list[str]]] | None = None,
    changefreq: str = "weekly",
    priority: str = "0.8",
) -> APIRouter:
    """Create a router with /sitemap.xml and /robots.txt endpoints."""
    router = APIRouter(tags=["seo"])
    base = base_url.rstrip("/")

    async def _sitemap_response() -> Response:
        urls = list(static_urls or [])
        if dynamic_urls_fn:
            urls.extend(await dynamic_urls_fn())

        now = datetime.now(timezone.utc).date().isoformat()
        entries = [
            {"loc": url_path, "lastmod": now, "changefreq": changefreq, "priority": priority} for url_path in urls
        ]
        return Response(content=render_sitemap_xml(entries, base_url=base), media_type="application/xml")

    def _robots_response() -> PlainTextResponse:
        return f"User-agent: *\nAllow: /\n\nSitemap: {base}/sitemap.xml\n"

    @router.get("/sitemap.xml", response_class=Response)
    async def sitemap() -> Response:
        return await _sitemap_response()

    @router.head("/sitemap.xml", response_class=Response)
    async def sitemap_head() -> Response:
        return await _sitemap_response()

    @router.get("/robots.txt", response_class=PlainTextResponse)
    async def robots() -> PlainTextResponse:
        return _robots_response()

    @router.head("/robots.txt", response_class=PlainTextResponse)
    async def robots_head() -> PlainTextResponse:
        return _robots_response()

    return router
