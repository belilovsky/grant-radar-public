"""ProxyManager – central entry point for proxy usage.

v0.2.0 adds: StealthClient factory, FreePool integration, ProxyChain factory,
SGEO tool factories.
"""

from __future__ import annotations

import logging
from typing import Optional

import httpx

from qazstack.proxy.config import Provider, ProxyConfig, ProxyType, RotationPolicy
from qazstack.proxy.health import HealthChecker
from qazstack.proxy.models import Proxy, ProxyHealth, ProxyStats
from qazstack.proxy.providers.base import BaseProvider
from qazstack.proxy.providers.brightdata import BrightDataProvider
from qazstack.proxy.providers.decodo import DecodoProvider
from qazstack.proxy.providers.generic import GenericProvider
from qazstack.proxy.providers.iproyal import IPRoyalProvider
from qazstack.proxy.transport import ProxyTransport

logger = logging.getLogger("qazstack.proxy")

_PROVIDER_MAP = {
    Provider.IPROYAL: IPRoyalProvider,
    Provider.DECODO: DecodoProvider,
    Provider.BRIGHTDATA: BrightDataProvider,
    Provider.GENERIC: GenericProvider,
}


class ProxyManager:
    """Unified proxy manager for all qazstack projects.

    Usage:
        # From env vars
        pm = ProxyManager.from_env()
        async with pm:
            proxy = await pm.get_proxy(country="KZ")
            # Use proxy.url with httpx, aiohttp, etc.

        # Or get a ready-to-use httpx client
        async with pm:
            client = pm.httpx_client(country="US")
            resp = await client.get("https://example.com")

        # Stealth client (TLS fingerprint bypass via curl_cffi)
        async with pm:
            stealth = pm.stealth_client(country="US")
            resp = await stealth.get("https://protected-site.com")

        # Full cascade chain (paid → free → direct)
        async with pm:
            chain = pm.chain(enable_free=True)
            result = await chain.get("https://target.com", country="KZ")

        # SGEO tools
        async with pm:
            serp = pm.geo_serp()
            fetcher = pm.geo_fetcher()
            verifier = pm.site_verifier()
    """

    def __init__(self, config: ProxyConfig, provider: Optional[BaseProvider] = None) -> None:
        self.config = config
        self.stats = ProxyStats()
        self._health = HealthChecker(
            check_url=config.health_check_url,
            timeout=config.timeout,
        )

        if provider:
            self._provider = provider
        else:
            provider_cls = _PROVIDER_MAP.get(config.provider, GenericProvider)
            self._provider = provider_cls(config)

        self._freepool = None  # Lazy init

    @classmethod
    def from_env(cls, prefix: str = "PROXY_") -> "ProxyManager":
        """Create manager from environment variables."""
        config = ProxyConfig.from_env(prefix)
        return cls(config)

    @classmethod
    def from_dict(cls, data: dict) -> "ProxyManager":
        """Create manager from a dict (e.g., from YAML/JSON config)."""
        if "provider" in data and isinstance(data["provider"], str):
            data["provider"] = Provider(data["provider"])
        if "default_type" in data and isinstance(data["default_type"], str):
            data["default_type"] = ProxyType(data["default_type"])
        if "rotation" in data and isinstance(data["rotation"], str):
            data["rotation"] = RotationPolicy(data["rotation"])
        config = ProxyConfig(**data)
        return cls(config)

    @property
    def provider(self) -> BaseProvider:
        """Access the underlying provider (e.g., for IPRoyal API calls)."""
        return self._provider

    async def get_proxy(
        self,
        *,
        country: str = "",
        city: str = "",
        proxy_type: Optional[ProxyType] = None,
        rotation: Optional[RotationPolicy] = None,
        session_id: str = "",
    ) -> Proxy:
        """Get a proxy from the configured provider."""
        return await self._provider.get_proxy(
            country=country,
            city=city,
            proxy_type=proxy_type,
            rotation=rotation,
            session_id=session_id,
        )

    async def check_health(self, proxy: Optional[Proxy] = None) -> ProxyHealth:
        """Check health of a specific proxy or get a new one and check it."""
        if proxy is None:
            proxy = await self.get_proxy()
        return await self._health.check(proxy)

    def httpx_client(
        self,
        *,
        country: str = "",
        city: str = "",
        proxy_type: Optional[ProxyType] = None,
        rotation: Optional[RotationPolicy] = None,
        session_id: str = "",
        **kwargs,
    ) -> httpx.AsyncClient:
        """Create an httpx.AsyncClient with proxy transport.

        The client auto-rotates proxies and retries on failure.
        """
        transport = ProxyTransport(
            self,
            country=country,
            city=city,
            proxy_type=proxy_type,
            rotation=rotation,
            session_id=session_id,
        )
        return httpx.AsyncClient(
            transport=transport,
            timeout=self.config.timeout,
            follow_redirects=True,
            **kwargs,
        )

    def stealth_client(
        self,
        *,
        country: str = "",
        city: str = "",
        proxy_type: Optional[ProxyType] = None,
        rotation: Optional[RotationPolicy] = None,
        session_id: str = "",
        impersonate: str = "",
        timeout: float = 30.0,
    ):
        """Create a StealthClient with TLS fingerprint bypass.

        Requires: pip install curl_cffi
        """
        from qazstack.proxy.stealth import StealthClient

        return StealthClient(
            self,
            country=country,
            city=city,
            proxy_type=proxy_type,
            rotation=rotation,
            session_id=session_id,
            impersonate=impersonate,
            timeout=timeout,
        )

    def chain(
        self,
        *,
        enable_free: bool = True,
        enable_direct: bool = True,
        paid_retries: int = 2,
        free_retries: int = 3,
        timeout: float = 30.0,
    ):
        """Create a ProxyChain for cascading proxy strategy.

        paid → free → direct fallback chain.
        """
        from qazstack.proxy.chain import ProxyChain
        from qazstack.proxy.freepool import FreePool

        if enable_free and self._freepool is None:
            self._freepool = FreePool()

        return ProxyChain(
            self,
            self._freepool if enable_free else None,
            paid_retries=paid_retries,
            free_retries=free_retries,
            enable_free=enable_free,
            enable_direct=enable_direct,
            timeout=timeout,
        )

    def geo_serp(self, *, timeout: float = 30.0):
        """Create a GeoSERP instance for geo-localized SERP monitoring."""
        from qazstack.proxy.sgeo.serp import GeoSERP

        return GeoSERP(self, timeout=timeout)

    def geo_fetcher(self, *, timeout: float = 30.0):
        """Create a GeoFetcher for geo-localized content collection."""
        from qazstack.proxy.sgeo.fetcher import GeoFetcher

        return GeoFetcher(self, timeout=timeout)

    def site_verifier(self, *, timeout: float = 20.0):
        """Create a SiteVerifier for geo accessibility testing."""
        from qazstack.proxy.sgeo.verifier import SiteVerifier

        return SiteVerifier(self, timeout=timeout)

    def get_stats(self) -> ProxyStats:
        """Get usage statistics."""
        return self.stats

    async def __aenter__(self) -> "ProxyManager":
        return self

    async def __aexit__(self, *args) -> None:
        await self._provider.close()
        self._health.clear_cache()
