"""FreePool – aggregator of free proxy lists for fallback usage.

Inspired by swiftshadow. Fetches free proxy lists from multiple public
sources, validates them, and maintains a pool of working proxies.

Use as a fallback layer in ProxyChain when paid proxies are unavailable
or for non-critical tasks where speed/reliability is less important.
"""

from __future__ import annotations

import asyncio
import logging
import random
import re
import time
from dataclasses import dataclass, field
from typing import Optional

import httpx

from qazstack.proxy.config import ProxyType
from qazstack.proxy.models import Proxy

logger = logging.getLogger("qazstack.proxy.freepool")

# Public free proxy list sources
_SOURCES = [
    {
        "name": "proxyscrape_http",
        "url": "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all",
        "format": "plain",  # ip:port per line
    },
    {
        "name": "proxyscrape_socks5",
        "url": "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks5&timeout=10000&country=all",
        "format": "plain",
    },
    {
        "name": "geonode",
        "url": "https://proxylist.geonode.com/api/proxy-list?limit=200&page=1&sort_by=lastChecked&sort_type=desc",
        "format": "geonode_json",
    },
    {
        "name": "free_proxy_list",
        "url": "https://www.free-proxy-list.net/",
        "format": "html_table",
    },
    {
        "name": "spys_txt",
        "url": "https://spys.me/proxy.txt",
        "format": "spys_txt",
    },
]


@dataclass
class FreeProxy:
    """A free proxy with metadata."""

    ip: str
    port: int
    protocol: str = "http"  # http, https, socks5
    country: str = ""
    anonymity: str = ""  # transparent, anonymous, elite
    last_check: float = field(default_factory=time.time)
    latency_ms: float = 0.0
    is_alive: bool = True
    source: str = ""

    @property
    def url(self) -> str:
        return f"{self.protocol}://{self.ip}:{self.port}"


class FreePool:
    """Aggregator and validator of free proxies.

    Usage:
        pool = FreePool()
        await pool.refresh()  # Fetch from all sources

        proxy = pool.get_proxy(country="US")
        # Use proxy.url with httpx

        # Or get multiple
        proxies = pool.get_proxies(count=5, country="RU")

    Configuration via extra dict:
        {
            "refresh_interval": 600,   # Seconds between auto-refreshes
            "validate_on_fetch": True, # Validate proxies during refresh
            "max_pool_size": 500,      # Max proxies to keep
            "min_alive": 20,           # Min alive proxies before auto-refresh
            "validate_timeout": 10,    # Timeout for validation requests
            "validate_url": "http://httpbin.org/ip",
        }
    """

    def __init__(
        self,
        *,
        refresh_interval: int = 600,
        validate_on_fetch: bool = True,
        max_pool_size: int = 500,
        min_alive: int = 20,
        validate_timeout: float = 10.0,
        validate_url: str = "http://httpbin.org/ip",
        sources: Optional[list[dict]] = None,
    ) -> None:
        self._refresh_interval = refresh_interval
        self._validate_on_fetch = validate_on_fetch
        self._max_pool_size = max_pool_size
        self._min_alive = min_alive
        self._validate_timeout = validate_timeout
        self._validate_url = validate_url
        self._sources = sources or _SOURCES

        self._pool: list[FreeProxy] = []
        self._last_refresh: float = 0
        self._lock = asyncio.Lock()

    @property
    def pool_size(self) -> int:
        return len(self._pool)

    @property
    def alive_count(self) -> int:
        return sum(1 for p in self._pool if p.is_alive)

    @property
    def needs_refresh(self) -> bool:
        if not self._pool:
            return True
        if time.time() - self._last_refresh > self._refresh_interval:
            return True
        if self.alive_count < self._min_alive:
            return True
        return False

    async def refresh(self, validate: Optional[bool] = None) -> int:
        """Fetch proxies from all sources and optionally validate them.

        Returns number of proxies added to pool.
        """
        async with self._lock:
            should_validate = validate if validate is not None else self._validate_on_fetch
            raw_proxies: list[FreeProxy] = []

            # Fetch from all sources in parallel
            tasks = [self._fetch_source(src) for src in self._sources]
            results = await asyncio.gather(*tasks, return_exceptions=True)

            for result in results:
                if isinstance(result, Exception):
                    logger.warning("Source fetch failed: %s", result)
                    continue
                raw_proxies.extend(result)

            logger.info("Fetched %d raw proxies from %d sources", len(raw_proxies), len(self._sources))

            # Deduplicate
            seen: set[str] = set()
            unique: list[FreeProxy] = []
            for p in raw_proxies:
                key = f"{p.ip}:{p.port}"
                if key not in seen:
                    seen.add(key)
                    unique.append(p)

            # Validate if requested
            if should_validate and unique:
                unique = await self._validate_batch(unique[: self._max_pool_size])

            # Merge with existing pool (keep validated old ones)
            old_alive = [p for p in self._pool if p.is_alive]
            new_keys = {f"{p.ip}:{p.port}" for p in unique}
            kept = [p for p in old_alive if f"{p.ip}:{p.port}" not in new_keys]

            self._pool = (unique + kept)[: self._max_pool_size]
            self._last_refresh = time.time()

            logger.info("Pool now has %d proxies (%d alive)", self.pool_size, self.alive_count)
            return len(unique)

    def get_proxy(
        self,
        *,
        country: str = "",
        protocol: str = "",
        anonymity: str = "",
    ) -> Optional[Proxy]:
        """Get a random alive proxy matching criteria.

        Returns Proxy object compatible with ProxyManager, or None.
        """
        candidates = [p for p in self._pool if p.is_alive]

        if country:
            cc = country.upper()
            filtered = [p for p in candidates if p.country.upper() == cc]
            if filtered:
                candidates = filtered

        if protocol:
            filtered = [p for p in candidates if p.protocol == protocol]
            if filtered:
                candidates = filtered

        if anonymity:
            filtered = [p for p in candidates if p.anonymity == anonymity]
            if filtered:
                candidates = filtered

        if not candidates:
            return None

        fp = random.choice(candidates)
        return Proxy(
            url=fp.url,
            country=fp.country,
            proxy_type=ProxyType.DATACENTER,  # Free proxies are typically DC
            provider="freepool",
            session_id="",
        )

    def get_proxies(
        self,
        count: int = 5,
        *,
        country: str = "",
        protocol: str = "",
    ) -> list[Proxy]:
        """Get multiple distinct proxies."""
        results: list[Proxy] = []
        seen: set[str] = set()

        candidates = [p for p in self._pool if p.is_alive]
        if country:
            cc = country.upper()
            candidates = [p for p in candidates if p.country.upper() == cc] or candidates
        if protocol:
            candidates = [p for p in candidates if p.protocol == protocol] or candidates

        random.shuffle(candidates)
        for fp in candidates:
            if len(results) >= count:
                break
            if fp.url not in seen:
                seen.add(fp.url)
                results.append(
                    Proxy(
                        url=fp.url,
                        country=fp.country,
                        proxy_type=ProxyType.DATACENTER,
                        provider="freepool",
                    )
                )

        return results

    def mark_dead(self, proxy_url: str) -> None:
        """Mark a proxy as dead after failure."""
        for p in self._pool:
            if p.url == proxy_url:
                p.is_alive = False
                break

    # ------------------------------------------------------------------
    # Internal: source fetchers
    # ------------------------------------------------------------------

    async def _fetch_source(self, source: dict) -> list[FreeProxy]:
        """Fetch proxies from a single source."""
        name = source["name"]
        url = source["url"]
        fmt = source["format"]

        try:
            async with httpx.AsyncClient(timeout=15, follow_redirects=True) as client:
                resp = await client.get(url)
                resp.raise_for_status()

            if fmt == "plain":
                return self._parse_plain(resp.text, name)
            elif fmt == "geonode_json":
                return self._parse_geonode(resp.json(), name)
            elif fmt == "html_table":
                return self._parse_html_table(resp.text, name)
            elif fmt == "spys_txt":
                return self._parse_spys(resp.text, name)
            else:
                logger.warning("Unknown format '%s' for source %s", fmt, name)
                return []

        except Exception as e:
            logger.warning("Failed to fetch %s: %s", name, e)
            return []

    @staticmethod
    def _parse_plain(text: str, source: str) -> list[FreeProxy]:
        """Parse ip:port per line format."""
        proxies: list[FreeProxy] = []
        for line in text.strip().split("\n"):
            line = line.strip()
            if not line or ":" not in line:
                continue
            parts = line.split(":")
            if len(parts) == 2:
                try:
                    ip, port = parts[0].strip(), int(parts[1].strip())
                    proxies.append(FreeProxy(ip=ip, port=port, source=source))
                except (ValueError, IndexError):
                    pass
        return proxies

    @staticmethod
    def _parse_geonode(data: dict, source: str) -> list[FreeProxy]:
        """Parse GeoNode JSON API response."""
        proxies: list[FreeProxy] = []
        for entry in data.get("data", []):
            try:
                protocols = entry.get("protocols", ["http"])
                protocol = protocols[0] if protocols else "http"
                proxies.append(
                    FreeProxy(
                        ip=entry["ip"],
                        port=int(entry["port"]),
                        protocol=protocol,
                        country=entry.get("country", ""),
                        anonymity=entry.get("anonymityLevel", ""),
                        source=source,
                    )
                )
            except (KeyError, ValueError):
                pass
        return proxies

    @staticmethod
    def _parse_html_table(html: str, source: str) -> list[FreeProxy]:
        """Parse HTML table from free-proxy-list.net style sites."""
        proxies: list[FreeProxy] = []
        # Simple regex to extract IP:Port pairs from table rows
        pattern = re.compile(
            r"<td>(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})</td>\s*<td>(\d{2,5})</td>\s*<td>([^<]*)</td>\s*<td[^>]*>([^<]*)</td>",
        )
        for match in pattern.finditer(html):
            try:
                ip = match.group(1)
                port = int(match.group(2))
                country = match.group(3).strip()[:2].upper()
                anonymity = match.group(4).strip().lower()
                proxies.append(
                    FreeProxy(
                        ip=ip,
                        port=port,
                        country=country,
                        anonymity=anonymity,
                        source=source,
                    )
                )
            except (ValueError, IndexError):
                pass
        return proxies

    @staticmethod
    def _parse_spys(text: str, source: str) -> list[FreeProxy]:
        """Parse spys.me proxy.txt format."""
        proxies: list[FreeProxy] = []
        for line in text.strip().split("\n"):
            line = line.strip()
            # Format: IP:PORT CC-ANON-S/H
            match = re.match(r"(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}):(\d+)\s+(\w{2})", line)
            if match:
                try:
                    proxies.append(
                        FreeProxy(
                            ip=match.group(1),
                            port=int(match.group(2)),
                            country=match.group(3).upper(),
                            source=source,
                        )
                    )
                except ValueError:
                    pass
        return proxies

    # ------------------------------------------------------------------
    # Internal: validation
    # ------------------------------------------------------------------

    async def _validate_batch(
        self,
        proxies: list[FreeProxy],
        concurrency: int = 50,
    ) -> list[FreeProxy]:
        """Validate proxies by making test requests through them."""
        semaphore = asyncio.Semaphore(concurrency)
        alive: list[FreeProxy] = []

        async def _check_one(fp: FreeProxy) -> Optional[FreeProxy]:
            async with semaphore:
                try:
                    start = time.monotonic()
                    async with httpx.AsyncClient(
                        proxy=fp.url,
                        timeout=self._validate_timeout,
                    ) as client:
                        resp = await client.get(self._validate_url)
                        if resp.status_code == 200:
                            fp.latency_ms = (time.monotonic() - start) * 1000
                            fp.is_alive = True
                            fp.last_check = time.time()
                            return fp
                except Exception:
                    pass
                fp.is_alive = False
                return None

        tasks = [_check_one(fp) for fp in proxies]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        for r in results:
            if isinstance(r, FreeProxy) and r.is_alive:
                alive.append(r)

        logger.info("Validated %d/%d proxies alive", len(alive), len(proxies))
        return alive
