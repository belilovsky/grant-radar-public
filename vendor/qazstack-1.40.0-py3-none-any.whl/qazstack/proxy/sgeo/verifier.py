"""SiteVerifier – verify site accessibility and behavior from different geolocations."""

from __future__ import annotations

import asyncio
import logging
import ssl
import time
from dataclasses import dataclass, field

import httpx

from qazstack.proxy.config import ProxyType
from qazstack.proxy.manager import ProxyManager

logger = logging.getLogger("qazstack.proxy.sgeo.verifier")


@dataclass
class VerifyResult:
    """Result of a site verification from one geolocation."""

    url: str
    country: str
    is_accessible: bool = False
    status_code: int = 0
    final_url: str = ""
    redirect_chain: list[str] = field(default_factory=list)
    latency_ms: float = 0.0
    server_header: str = ""
    content_length: int = 0
    proxy_ip: str = ""
    error: str = ""
    error_type: str = ""
    checked_at: float = field(default_factory=time.time)

    @property
    def is_redirected(self) -> bool:
        return self.final_url != self.url and self.final_url != ""

    @property
    def is_geo_blocked(self) -> bool:
        return self.error_type == "geo_block"


@dataclass
class SiteReport:
    """Aggregated verification report for one site across geolocations."""

    url: str
    results: list[VerifyResult] = field(default_factory=list)

    @property
    def accessible_countries(self) -> list[str]:
        return [r.country for r in self.results if r.is_accessible]

    @property
    def blocked_countries(self) -> list[str]:
        return [r.country for r in self.results if not r.is_accessible]

    @property
    def avg_latency_ms(self) -> float:
        ok = [r for r in self.results if r.is_accessible]
        if not ok:
            return 0.0
        return sum(r.latency_ms for r in ok) / len(ok)

    @property
    def redirect_variants(self) -> dict[str, str]:
        return {r.country: r.final_url for r in self.results if r.is_redirected}

    @property
    def is_globally_accessible(self) -> bool:
        return all(r.is_accessible for r in self.results)

    def summary(self) -> str:
        total = len(self.results)
        ok = len(self.accessible_countries)
        blocked = self.blocked_countries
        lines = [f"Site: {self.url}", f"Accessible: {ok}/{total} countries"]
        if blocked:
            lines.append(f"Blocked in: {', '.join(blocked)}")
        if self.redirect_variants:
            for cc, final in self.redirect_variants.items():
                lines.append(f"  {cc}: redirects to {final}")
        lines.append(f"Avg latency: {self.avg_latency_ms:.0f}ms")
        return "\n".join(lines)


_GEO_BLOCK_INDICATORS = [
    "access denied",
    "not available in your region",
    "not available in your country",
    "geo-restricted",
    "403 forbidden",
    "451 unavailable for legal reasons",
    "this content is not available",
    "\u0431\u043b\u043e\u043a\u0438\u0440\u043e\u0432\u043a\u0430",
    "\u0434\u043e\u0441\u0442\u0443\u043f \u0437\u0430\u043f\u0440\u0435\u0449\u0451\u043d",
    "\u0434\u043e\u0441\u0442\u0443\u043f \u043e\u0433\u0440\u0430\u043d\u0438\u0447\u0435\u043d",
]


class SiteVerifier:
    """Verify site accessibility from multiple geolocations."""

    _HEADERS = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/124.0.0.0 Safari/537.36"
        ),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    }

    def __init__(self, manager: ProxyManager, *, timeout: float = 20.0, follow_redirects: bool = True) -> None:
        self._manager = manager
        self._timeout = timeout
        self._follow_redirects = follow_redirects

    async def verify(self, url: str, countries: list[str]) -> SiteReport:
        tasks = [self._verify_one(url, cc) for cc in countries]
        results = await asyncio.gather(*tasks)
        return SiteReport(url=url, results=list(results))

    async def verify_batch(self, urls: list[str], countries: list[str]) -> list[SiteReport]:
        tasks = [self.verify(url, countries) for url in urls]
        return await asyncio.gather(*tasks)

    async def is_accessible(self, url: str, *, country: str) -> bool:
        result = await self._verify_one(url, country)
        return result.is_accessible

    async def _verify_one(self, url: str, country: str) -> VerifyResult:
        start = time.monotonic()
        try:
            proxy = await self._manager.get_proxy(country=country, proxy_type=ProxyType.RESIDENTIAL)
            async with httpx.AsyncClient(
                proxy=proxy.url,
                timeout=self._timeout,
                follow_redirects=self._follow_redirects,
                headers=self._HEADERS,
                max_redirects=10,
            ) as client:
                resp = await client.get(url)
                redirect_chain = [str(r.url) for r in resp.history] if resp.history else []
                elapsed_ms = (time.monotonic() - start) * 1000
                body_preview = resp.text[:2000].lower() if resp.text else ""
                error_type = ""
                is_accessible = True
                if resp.status_code == 403:
                    error_type = "http_4xx"
                    if any(ind in body_preview for ind in _GEO_BLOCK_INDICATORS):
                        error_type = "geo_block"
                    is_accessible = False
                elif resp.status_code == 451:
                    error_type = "geo_block"
                    is_accessible = False
                elif resp.status_code >= 500:
                    error_type = "http_5xx"
                    is_accessible = False
                elif resp.status_code >= 400:
                    error_type = "http_4xx"
                    is_accessible = False
                else:
                    if any(ind in body_preview for ind in _GEO_BLOCK_INDICATORS):
                        error_type = "geo_block"
                        is_accessible = False
                return VerifyResult(
                    url=url,
                    country=country,
                    is_accessible=is_accessible,
                    status_code=resp.status_code,
                    final_url=str(resp.url),
                    redirect_chain=redirect_chain,
                    latency_ms=elapsed_ms,
                    server_header=resp.headers.get("server", ""),
                    content_length=len(resp.content),
                    proxy_ip=proxy.host,
                    error_type=error_type,
                    error="" if is_accessible else f"{error_type}: {resp.status_code}",
                )
        except httpx.TimeoutException as e:
            return VerifyResult(
                url=url,
                country=country,
                latency_ms=(time.monotonic() - start) * 1000,
                error=str(e),
                error_type="timeout",
            )
        except ssl.SSLError as e:
            return VerifyResult(
                url=url, country=country, latency_ms=(time.monotonic() - start) * 1000, error=str(e), error_type="ssl"
            )
        except Exception as e:
            return VerifyResult(
                url=url,
                country=country,
                latency_ms=(time.monotonic() - start) * 1000,
                error=str(e),
                error_type="connection",
            )
