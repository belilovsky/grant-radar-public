"""GeoSERP – monitor search engine results from different geolocations.

Use cases:
- Check how our sites (total.kz, qaz.report, qazpolit.kz) rank from KZ vs RU vs US
- Monitor competitor positions in different countries
- Track geo-specific search snippets and featured snippets
"""

from __future__ import annotations

import asyncio
import logging
import re
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional
from urllib.parse import urlencode

import httpx

from qazstack.proxy.config import ProxyType
from qazstack.proxy.manager import ProxyManager

logger = logging.getLogger("qazstack.proxy.sgeo.serp")


class SearchEngine(str, Enum):
    GOOGLE = "google"
    YANDEX = "yandex"


# Google domain per country
_GOOGLE_DOMAINS = {
    "KZ": "google.kz",
    "RU": "google.ru",
    "US": "google.com",
    "GB": "google.co.uk",
    "DE": "google.de",
    "TR": "google.com.tr",
    "UZ": "google.co.uz",
    "KG": "google.kg",
    "UA": "google.com.ua",
    "BY": "google.by",
}

# Google hl (interface language) per country
_GOOGLE_HL = {
    "KZ": "ru",
    "RU": "ru",
    "US": "en",
    "GB": "en",
    "DE": "de",
    "TR": "tr",
    "UZ": "uz",
    "KG": "ru",
    "UA": "uk",
    "BY": "ru",
}

# Yandex tld per country
_YANDEX_DOMAINS = {
    "KZ": "yandex.kz",
    "RU": "yandex.ru",
    "BY": "yandex.by",
    "UZ": "yandex.uz",
    "COM": "yandex.com",
}


@dataclass
class SERPQuery:
    """Search query configuration."""

    query: str
    countries: list[str]  # ISO alpha-2 codes
    engine: SearchEngine = SearchEngine.GOOGLE
    num_results: int = 10  # results per page
    language: str = ""  # override auto-detected language


@dataclass
class SERPItem:
    """Single search result."""

    position: int
    title: str
    url: str
    snippet: str = ""
    is_featured: bool = False


@dataclass
class SERPResult:
    """Search results for one query from one country."""

    query: str
    country: str
    engine: str
    items: list[SERPItem] = field(default_factory=list)
    total_results: str = ""  # e.g. "About 1,230,000 results"
    fetched_at: float = field(default_factory=time.time)
    proxy_ip: str = ""
    latency_ms: float = 0.0
    error: str = ""

    @property
    def is_ok(self) -> bool:
        return not self.error and len(self.items) > 0

    def find_domain(self, domain: str) -> Optional[SERPItem]:
        """Find a result by domain (e.g. 'total.kz')."""
        for item in self.items:
            if domain in item.url:
                return item
        return None

    def domain_position(self, domain: str) -> int:
        """Get position of a domain, 0 if not found."""
        item = self.find_domain(domain)
        return item.position if item else 0


class GeoSERP:
    """Monitor search engine results from different geolocations.

    Uses ProxyManager to make search requests from country-specific IPs.

    Usage:
        serp = GeoSERP(proxy_manager)
        results = await serp.search(
            SERPQuery(query="total.kz новости", countries=["KZ", "RU", "US"])
        )
        for r in results:
            pos = r.domain_position("total.kz")
            print(f"{r.country}: total.kz at position {pos}")
    """

    # Headers to mimic real browser
    _HEADERS = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/124.0.0.0 Safari/537.36"
        ),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    }

    def __init__(self, manager: ProxyManager, *, timeout: float = 30.0) -> None:
        self._manager = manager
        self._timeout = timeout

    async def search(self, query: SERPQuery) -> list[SERPResult]:
        """Run search from all specified countries in parallel."""
        tasks = [self._search_country(query, country) for country in query.countries]
        return await asyncio.gather(*tasks)

    async def search_multi(self, queries: list[SERPQuery]) -> list[list[SERPResult]]:
        """Run multiple queries, each from their countries, in parallel."""
        tasks = [self.search(q) for q in queries]
        return await asyncio.gather(*tasks)

    async def track_domain(
        self,
        domain: str,
        queries: list[str],
        countries: list[str],
        engine: SearchEngine = SearchEngine.GOOGLE,
    ) -> dict[str, dict[str, int]]:
        """Track domain positions across queries and countries.

        Returns: {query: {country: position}} where 0 = not found.
        """
        results: dict[str, dict[str, int]] = {}
        serp_queries = [SERPQuery(query=q, countries=countries, engine=engine) for q in queries]
        all_results = await self.search_multi(serp_queries)

        for query_obj, serp_results in zip(serp_queries, all_results):
            results[query_obj.query] = {}
            for sr in serp_results:
                results[query_obj.query][sr.country] = sr.domain_position(domain)

        return results

    async def _search_country(self, query: SERPQuery, country: str) -> SERPResult:
        """Execute search from a specific country."""
        start = time.monotonic()

        try:
            proxy = await self._manager.get_proxy(
                country=country,
                proxy_type=ProxyType.RESIDENTIAL,
            )

            if query.engine == SearchEngine.GOOGLE:
                url = self._build_google_url(query, country)
            else:
                url = self._build_yandex_url(query, country)

            async with httpx.AsyncClient(
                proxy=proxy.url,
                timeout=self._timeout,
                follow_redirects=True,
                headers=self._HEADERS,
            ) as client:
                resp = await client.get(url)
                resp.raise_for_status()
                html = resp.text

            elapsed_ms = (time.monotonic() - start) * 1000

            # Parse results
            if query.engine == SearchEngine.GOOGLE:
                items = self._parse_google(html)
            else:
                items = self._parse_yandex(html)

            # Record stats
            self._manager.stats.record(
                success=True,
                latency_ms=elapsed_ms,
                bytes_count=len(html),
                country=country,
                provider=proxy.provider,
            )

            return SERPResult(
                query=query.query,
                country=country,
                engine=query.engine.value,
                items=items,
                proxy_ip=proxy.host,
                latency_ms=elapsed_ms,
            )

        except Exception as e:
            elapsed_ms = (time.monotonic() - start) * 1000
            logger.warning("GeoSERP failed for %s from %s: %s", query.query, country, e)
            return SERPResult(
                query=query.query,
                country=country,
                engine=query.engine.value,
                latency_ms=elapsed_ms,
                error=str(e),
            )

    def _build_google_url(self, query: SERPQuery, country: str) -> str:
        domain = _GOOGLE_DOMAINS.get(country, "google.com")
        hl = query.language or _GOOGLE_HL.get(country, "en")
        params = {
            "q": query.query,
            "num": query.num_results,
            "hl": hl,
            "gl": country.lower(),
        }
        return f"https://www.{domain}/search?{urlencode(params)}"

    def _build_yandex_url(self, query: SERPQuery, country: str) -> str:
        domain = _YANDEX_DOMAINS.get(country, "yandex.com")
        params = {
            "text": query.query,
            "numdoc": query.num_results,
            "lr": self._yandex_lr(country),
        }
        return f"https://{domain}/search/?{urlencode(params)}"

    @staticmethod
    def _yandex_lr(country: str) -> int:
        """Yandex region code."""
        return {
            "KZ": 163,  # Казахстан
            "RU": 225,  # Россия
            "BY": 149,  # Беларусь
            "UZ": 171,  # Узбекистан
            "UA": 187,  # Украина
            "US": 84,  # США
        }.get(country, 0)

    @staticmethod
    def _parse_google(html: str) -> list[SERPItem]:
        """Parse Google SERP HTML into items.

        Basic regex parser – works for organic results.
        For production, consider using a SERP API (SerpApi, DataForSEO)
        or enhance with BeautifulSoup.
        """
        items: list[SERPItem] = []
        # Match <a href="/url?q=..." patterns from Google results
        # This is a simplified parser – real Google HTML is complex
        pattern = re.compile(
            r'<a[^>]+href="/url\?q=([^"&]+)[^"]*"[^>]*>.*?<h3[^>]*>(.*?)</h3>',
            re.DOTALL,
        )
        for i, match in enumerate(pattern.finditer(html), 1):
            url = match.group(1)
            title = re.sub(r"<[^>]+>", "", match.group(2)).strip()
            if url and title:
                items.append(SERPItem(position=i, title=title, url=url))

        # Fallback: try data-href pattern (newer Google)
        if not items:
            pattern2 = re.compile(
                r'<a[^>]+data-href="(https?://[^"]+)"[^>]*>.*?<h3[^>]*>(.*?)</h3>',
                re.DOTALL,
            )
            for i, match in enumerate(pattern2.finditer(html), 1):
                url = match.group(1)
                title = re.sub(r"<[^>]+>", "", match.group(2)).strip()
                if url and title:
                    items.append(SERPItem(position=i, title=title, url=url))

        return items

    @staticmethod
    def _parse_yandex(html: str) -> list[SERPItem]:
        """Parse Yandex SERP HTML into items."""
        items: list[SERPItem] = []
        # Yandex organic results are in <li class="serp-item">
        pattern = re.compile(
            r'<a[^>]+class="[^"]*OrganicTitle-Link[^"]*"[^>]+href="([^"]+)"[^>]*>'
            r".*?<span[^>]*>(.*?)</span>",
            re.DOTALL,
        )
        for i, match in enumerate(pattern.finditer(html), 1):
            url = match.group(1)
            title = re.sub(r"<[^>]+>", "", match.group(2)).strip()
            if url and title:
                items.append(SERPItem(position=i, title=title, url=url))

        return items
