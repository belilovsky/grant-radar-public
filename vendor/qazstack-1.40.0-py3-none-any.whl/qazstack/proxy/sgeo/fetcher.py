"""GeoFetcher – fetch web content from specific geolocations.

Use cases:
- Check how a site looks from KZ vs US (geo-blocked content)
- Collect localized pricing/content from e-commerce sites
- Verify CDN routing and geo-targeted responses
- Gather news content as seen from different countries
"""

from __future__ import annotations

import asyncio
import hashlib
import logging
import time
from dataclasses import dataclass, field
from typing import Optional

import httpx

from qazstack.proxy.config import ProxyType
from qazstack.proxy.manager import ProxyManager

logger = logging.getLogger("qazstack.proxy.sgeo.fetcher")


@dataclass
class GeoResponse:
    """Response from a geo-localized fetch."""

    url: str
    country: str
    status_code: int = 0
    headers: dict = field(default_factory=dict)
    body: str = ""
    body_bytes: bytes = field(default_factory=bytes, repr=False)
    content_hash: str = ""
    proxy_ip: str = ""
    latency_ms: float = 0.0
    error: str = ""
    fetched_at: float = field(default_factory=time.time)

    @property
    def ok(self) -> bool:
        return not self.error and 200 <= self.status_code < 400

    @property
    def content_type(self) -> str:
        return self.headers.get("content-type", "")

    @property
    def is_html(self) -> bool:
        return "text/html" in self.content_type


@dataclass
class GeoDiff:
    """Comparison of responses from different geolocations."""

    url: str
    responses: list[GeoResponse]
    is_identical: bool = False
    diff_countries: list[str] = field(default_factory=list)
    blocked_countries: list[str] = field(default_factory=list)

    @property
    def successful_countries(self) -> list[str]:
        return [r.country for r in self.responses if r.ok]


class GeoFetcher:
    """Fetch web content from specific geolocations via proxies."""

    _HEADERS = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/124.0.0.0 Safari/537.36"
        ),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9,ru;q=0.8,kk;q=0.7",
        "Accept-Encoding": "gzip, deflate, br",
    }

    def __init__(
        self,
        manager: ProxyManager,
        *,
        timeout: float = 30.0,
        max_body_size: int = 5 * 1024 * 1024,
    ) -> None:
        self._manager = manager
        self._timeout = timeout
        self._max_body_size = max_body_size

    async def fetch(
        self,
        url: str,
        *,
        country: str = "",
        headers: Optional[dict] = None,
        method: str = "GET",
        **kwargs,
    ) -> GeoResponse:
        """Fetch a URL from a specific geolocation."""
        start = time.monotonic()

        try:
            proxy = await self._manager.get_proxy(
                country=country,
                proxy_type=ProxyType.RESIDENTIAL,
            )

            merged_headers = {**self._HEADERS, **(headers or {})}

            async with httpx.AsyncClient(
                proxy=proxy.url,
                timeout=self._timeout,
                follow_redirects=True,
                headers=merged_headers,
                max_redirects=10,
            ) as client:
                resp = await client.request(method, url, **kwargs)
                body_bytes = resp.content[: self._max_body_size]
                body = resp.text

            elapsed_ms = (time.monotonic() - start) * 1000
            content_hash = hashlib.sha256(body_bytes).hexdigest()

            self._manager.stats.record(
                success=True,
                latency_ms=elapsed_ms,
                bytes_count=len(body_bytes),
                country=country,
                provider=proxy.provider,
            )

            return GeoResponse(
                url=url,
                country=country,
                status_code=resp.status_code,
                headers=dict(resp.headers),
                body=body,
                body_bytes=body_bytes,
                content_hash=content_hash,
                proxy_ip=proxy.host,
                latency_ms=elapsed_ms,
            )

        except Exception as e:
            elapsed_ms = (time.monotonic() - start) * 1000
            logger.warning("GeoFetch failed for %s from %s: %s", url[:60], country, e)
            return GeoResponse(
                url=url,
                country=country,
                latency_ms=elapsed_ms,
                error=str(e),
            )

    async def fetch_multi(
        self,
        url: str,
        countries: list[str],
        **kwargs,
    ) -> GeoDiff:
        """Fetch a URL from multiple countries and compare results."""
        tasks = [self.fetch(url, country=cc, **kwargs) for cc in countries]
        responses = await asyncio.gather(*tasks)

        hashes: set[str] = set()
        diff_countries: list[str] = []
        blocked_countries: list[str] = []
        first_hash: Optional[str] = None

        for resp in responses:
            if not resp.ok:
                blocked_countries.append(resp.country)
                continue
            if first_hash is None:
                first_hash = resp.content_hash
            elif resp.content_hash != first_hash:
                diff_countries.append(resp.country)
            hashes.add(resp.content_hash)

        is_identical = len(hashes) <= 1 and not blocked_countries

        return GeoDiff(
            url=url,
            responses=list(responses),
            is_identical=is_identical,
            diff_countries=diff_countries,
            blocked_countries=blocked_countries,
        )

    async def batch_fetch(
        self,
        urls: list[str],
        countries: list[str],
        **kwargs,
    ) -> list[GeoDiff]:
        """Fetch multiple URLs from multiple countries."""
        tasks = [self.fetch_multi(url, countries, **kwargs) for url in urls]
        return await asyncio.gather(*tasks)
