"""IPRoyal provider – affordable, non-expiring traffic, good for pilot.

Supports both gateway auth (username:password) and API key for account management.

Gateway geo-targeting: password suffix approach
  http://{user}:{pass}_country-{cc}_session-{sid}_streaming-1@geo.iproyal.com:12321
"""

from __future__ import annotations

import logging
import uuid
from typing import Optional
from urllib.parse import quote

import httpx

from qazstack.proxy.config import ProxyType, RotationPolicy
from qazstack.proxy.models import Proxy
from qazstack.proxy.providers.base import BaseProvider

logger = logging.getLogger("qazstack.proxy.providers.iproyal")


class IPRoyalProvider(BaseProvider):
    """IPRoyal residential/datacenter proxy integration.

    IPRoyal gateway format (password suffix):
        Residential: http://{user}:{pass}_country-{cc}_session-{sid}_streaming-1@geo.iproyal.com:12321
        Datacenter:  http://{user}:{pass}@proxy-dc.iproyal.com:{port}

    API (optional): https://resi-api.iproyal.com/v1/
        Used for: balance check, sub-user management, usage stats.

    Env vars:
        PROXY_USERNAME = your_iproyal_username
        PROXY_PASSWORD = your_iproyal_password
        PROXY_API_KEY  = your_iproyal_api_key (optional, for API calls)
    """

    RESIDENTIAL_HOST = "geo.iproyal.com"
    RESIDENTIAL_PORT = 12321
    DATACENTER_HOST = "proxy-dc.iproyal.com"
    DATACENTER_PORT = 8080
    API_BASE = "https://resi-api.iproyal.com/v1"

    def _build_residential_url(
        self,
        country: str,
        city: str,
        session_id: str,
        rotation: RotationPolicy,
    ) -> str:
        user = self.config.username
        password = self.config.password

        # Build password suffix with targeting params
        params: list[str] = []
        if country:
            params.append(f"country-{country.lower()}")
        if city:
            params.append(f"city-{city.lower()}")

        # Session/rotation
        if rotation == RotationPolicy.STICKY and session_id:
            params.append(f"session-{session_id}")
            params.append(f"sessionTime-{self.config.sticky_ttl}")
        elif rotation == RotationPolicy.TIMED:
            sid = session_id or uuid.uuid4().hex[:12]
            params.append(f"session-{sid}")
            params.append(f"sessionTime-{self.config.sticky_ttl}")
        # PER_REQUEST – no session params, each request gets new IP

        params.append("streaming-1")

        suffix = "_".join(params)
        full_pass = f"{password}_{suffix}" if params else password

        # URL-encode password (may contain special chars like =, +, etc.)
        encoded_user = quote(user, safe="")
        encoded_pass = quote(full_pass, safe="")

        return f"http://{encoded_user}:{encoded_pass}@{self.RESIDENTIAL_HOST}:{self.RESIDENTIAL_PORT}"

    def _build_datacenter_url(self, country: str) -> str:
        user = self.config.username
        password = self.config.password
        encoded_user = quote(user, safe="")
        encoded_pass = quote(password, safe="")
        return f"http://{encoded_user}:{encoded_pass}@{self.DATACENTER_HOST}:{self.DATACENTER_PORT}"

    async def get_proxy(
        self,
        *,
        country: str = "",
        city: str = "",
        proxy_type: Optional[ProxyType] = None,
        rotation: Optional[RotationPolicy] = None,
        session_id: str = "",
    ) -> Proxy:
        effective_country = country or self.config.default_country
        effective_type = proxy_type or self.config.default_type
        effective_rotation = rotation or self.config.rotation

        if effective_type == ProxyType.DATACENTER:
            url = self._build_datacenter_url(effective_country)
        else:
            url = self._build_residential_url(
                effective_country,
                city,
                session_id,
                effective_rotation,
            )

        return Proxy(
            url=url,
            country=effective_country,
            city=city,
            proxy_type=effective_type,
            provider=self.name,
            session_id=session_id,
        )

    # ------------------------------------------------------------------
    # API methods (require api_key in config)
    # ------------------------------------------------------------------

    def _auth_headers(self) -> dict:
        """Authorization headers for IPRoyal REST API."""
        api_key = self.config.api_key
        if not api_key:
            raise ValueError("PROXY_API_KEY required for IPRoyal API calls")
        return {"Authorization": f"Bearer {api_key}"}

    async def get_me(self) -> dict:
        """Get account info: available_traffic (GB), subusers_count, residential_user_hash.

        Returns dict like: {"available_traffic": 32.6, "subusers_count": 13, "residential_user_hash": "..."}
        """
        headers = self._auth_headers()
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.get(f"{self.API_BASE}/me", headers=headers)
            resp.raise_for_status()
            data = resp.json()
            logger.info("IPRoyal /me: %s", data)
            return data

    async def get_balance(self) -> float:
        """Get available traffic in GB."""
        data = await self.get_me()
        return float(data.get("available_traffic", 0))

    async def list_sub_users(self, page: int = 1, per_page: int = 50) -> dict:
        """List sub-users with pagination."""
        headers = self._auth_headers()
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.get(
                f"{self.API_BASE}/residential-subusers",
                headers=headers,
                params={"page": page, "per_page": per_page},
            )
            resp.raise_for_status()
            return resp.json()

    async def create_sub_user(self, username: str, password: str, traffic_gb: float = 1.0) -> dict:
        """Create a sub-user with allocated traffic (deducted from main account)."""
        headers = self._auth_headers()
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.post(
                f"{self.API_BASE}/residential-subusers",
                headers={**headers, "Content-Type": "application/json"},
                json={
                    "username": username,
                    "password": password,
                    "traffic": traffic_gb,
                },
            )
            resp.raise_for_status()
            return resp.json()

    async def get_sub_user(self, hash: str) -> dict:
        """Get sub-user by hash."""
        headers = self._auth_headers()
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.get(
                f"{self.API_BASE}/residential-subusers/{hash}",
                headers=headers,
            )
            resp.raise_for_status()
            return resp.json()
