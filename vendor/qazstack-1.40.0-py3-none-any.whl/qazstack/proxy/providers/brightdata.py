"""Bright Data provider – enterprise-grade, 400M+ residential IPs."""

from __future__ import annotations

import uuid
from typing import Optional

from qazstack.proxy.config import ProxyType, RotationPolicy
from qazstack.proxy.models import Proxy
from qazstack.proxy.providers.base import BaseProvider


class BrightDataProvider(BaseProvider):
    """Bright Data (ex-Luminati) proxy integration.

    Gateway format:
        http://brd-customer-{customer_id}-zone-{zone}-country-{cc}:{pass}@brd.superproxy.io:33335

    Env vars:
        PROXY_USERNAME = brd-customer-XXXXXX-zone-residential
        PROXY_PASSWORD = your_brightdata_password
        # Or use PROXY_EXTRA for customer_id and zone:
        PROXY_EXTRA = {"customer_id": "XXXXXX", "zone": "residential"}
    """

    HOST = "brd.superproxy.io"
    RESIDENTIAL_PORT = 33335
    DATACENTER_PORT = 33335  # Same host, different zone

    def _build_url(
        self,
        country: str,
        city: str,
        session_id: str,
        rotation: RotationPolicy,
        proxy_type: ProxyType,
    ) -> str:
        user = self.config.username

        # Bright Data uses username for all targeting
        params = []
        if country:
            params.append(f"country-{country.lower()}")
        if city:
            params.append(f"city-{city.lower()}")

        if rotation == RotationPolicy.STICKY:
            sid = session_id or uuid.uuid4().hex[:12]
            params.append(f"session-{sid}")
        elif rotation == RotationPolicy.TIMED:
            sid = session_id or uuid.uuid4().hex[:12]
            params.append(f"session-{sid}")

        full_user = user + ("-" + "-".join(params) if params else "")
        password = self.config.password
        port = self.RESIDENTIAL_PORT

        return f"http://{full_user}:{password}@{self.HOST}:{port}"

    async def get_proxy(
        self,
        *,
        country: str = "",
        city: str = "",
        proxy_type: Optional[ProxyType] = None,
        rotation: Optional[RotationPolicy] = None,
        session_id: str = "",
    ) -> Proxy:
        effective_country = country or self.config.default_country
        effective_type = proxy_type or self.config.default_type
        effective_rotation = rotation or self.config.rotation

        url = self._build_url(
            effective_country,
            city,
            session_id,
            effective_rotation,
            effective_type,
        )

        return Proxy(
            url=url,
            country=effective_country,
            city=city,
            proxy_type=effective_type,
            provider=self.name,
            session_id=session_id,
        )
