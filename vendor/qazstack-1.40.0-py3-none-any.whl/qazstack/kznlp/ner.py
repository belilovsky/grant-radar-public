"""Named Entity Recognition for Russian and Kazakh texts.

Uses Natasha for Russian NER (lightweight, no GPU needed).
For Kazakh NER, can optionally use HuggingFace transformers
with ``KazakhNLP/xlm-roberta-large-kaznerd`` model.

The extract_entities() function auto-detects language and uses
the appropriate NER backend.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Optional

from qazstack.kznlp.lang_detect import detect_lang

logger = logging.getLogger(__name__)

# Entity label normalization: various NER models use different labels
_LABEL_MAP = {
    # Natasha labels
    "PER": "PER",
    "ORG": "ORG",
    "LOC": "LOC",
    # HuggingFace / KazNERD labels
    "PERSON": "PER",
    "ORGANIZATION": "ORG",
    "LOCATION": "LOC",
    "GPE": "LOC",
    "FACILITY": "LOC",
    "EVENT": "EVENT",
    "PRODUCT": "PRODUCT",
    "LANGUAGE": "MISC",
    "NATIONALITY": "MISC",
    "DATE": "DATE",
    "MONEY": "MONEY",
    "QUANTITY": "QUANTITY",
    "CARDINAL": "QUANTITY",
    "ORDINAL": "QUANTITY",
    # Generic
    "MISC": "MISC",
    "O": "O",
}


@dataclass
class Entity:
    """A named entity extracted from text."""

    text: str
    label: str  # Normalized: PER, ORG, LOC, EVENT, MISC, etc.
    start: int = 0
    end: int = 0
    score: float = 1.0
    raw_label: str = ""  # Original label from the NER model

    def __post_init__(self):
        if not self.raw_label:
            self.raw_label = self.label
        self.label = _LABEL_MAP.get(self.label, self.label)


# ── Natasha-based Russian NER ──────────────────────────────────────

_natasha_loaded = False
_natasha_segmenter = None
_natasha_emb = None
_natasha_morph_tagger = None
_natasha_ner_tagger = None
_natasha_morph_vocab = None


def _load_natasha() -> bool:
    """Lazy-load Natasha NER components. Returns True on success."""
    global _natasha_loaded, _natasha_segmenter, _natasha_emb
    global _natasha_morph_tagger, _natasha_ner_tagger, _natasha_morph_vocab

    if _natasha_loaded:
        return True

    try:
        # pymorphy3 compat shim (pymorphy2 is broken on Python 3.12+)
        import sys

        try:
            import pymorphy3

            if "pymorphy2" not in sys.modules:
                sys.modules["pymorphy2"] = pymorphy3
                sys.modules["pymorphy2.analyzer"] = pymorphy3.analyzer
                sys.modules["pymorphy2.tagset"] = pymorphy3.tagset
                sys.modules["pymorphy2.shapes"] = pymorphy3.shapes
        except ImportError:
            pass

        from natasha import (
            MorphVocab,
            NewsEmbedding,
            NewsMorphTagger,
            NewsNERTagger,
            Segmenter,
        )

        _natasha_segmenter = Segmenter()
        _natasha_morph_vocab = MorphVocab()
        _natasha_emb = NewsEmbedding()
        _natasha_morph_tagger = NewsMorphTagger(_natasha_emb)
        _natasha_ner_tagger = NewsNERTagger(_natasha_emb)
        _natasha_loaded = True
        logger.debug("Natasha NER loaded successfully")
        return True
    except ImportError:
        logger.warning("Natasha not installed. Install with: pip install qazstack[nlp]")
        return False
    except Exception as exc:
        logger.error("Failed to load Natasha: %s", exc)
        return False


def _extract_natasha(text: str) -> list[Entity]:
    """Extract entities using Natasha (Russian NER)."""
    if not _load_natasha():
        return []

    from natasha import Doc

    doc = Doc(text)
    doc.segment(_natasha_segmenter)
    doc.tag_morph(_natasha_morph_tagger)
    doc.tag_ner(_natasha_ner_tagger)

    for span in doc.spans:
        span.normalize(_natasha_morph_vocab)

    entities = []
    for span in doc.spans:
        entities.append(
            Entity(
                text=span.normal or span.text,
                label=span.type,
                start=span.start,
                end=span.stop,
                score=1.0,
                raw_label=span.type,
            )
        )

    return entities


# ── HuggingFace-based Kazakh NER ──────────────────────────────────

_hf_ner_pipeline = None
_hf_ner_loaded = False


def _load_hf_ner() -> bool:
    """Lazy-load HuggingFace NER pipeline for Kazakh."""
    global _hf_ner_pipeline, _hf_ner_loaded

    if _hf_ner_loaded:
        return _hf_ner_pipeline is not None

    _hf_ner_loaded = True
    try:
        from transformers import pipeline as hf_pipeline

        _hf_ner_pipeline = hf_pipeline(
            "ner",
            model="KazakhNLP/xlm-roberta-large-kaznerd",
            aggregation_strategy="simple",
        )
        logger.debug("HuggingFace KazNERD model loaded")
        return True
    except ImportError:
        logger.info("transformers not installed. Kazakh NER unavailable.")
        return False
    except Exception as exc:
        logger.warning("Failed to load KazNERD model: %s", exc)
        return False


def _extract_hf(text: str) -> list[Entity]:
    """Extract entities using HuggingFace KazNERD model."""
    if not _load_hf_ner() or _hf_ner_pipeline is None:
        # Fallback to Natasha (still catches some Kazakh entities)
        logger.debug("Falling back to Natasha for Kazakh NER")
        return _extract_natasha(text)

    try:
        results = _hf_ner_pipeline(text[:5000])
        return [
            Entity(
                text=r.get("word", ""),
                label=r.get("entity_group", "MISC"),
                start=r.get("start", 0),
                end=r.get("end", 0),
                score=r.get("score", 0.0),
                raw_label=r.get("entity_group", ""),
            )
            for r in results
        ]
    except Exception as exc:
        logger.error("HuggingFace NER failed: %s", exc)
        return _extract_natasha(text)


def extract_entities(
    text: str,
    *,
    lang: Optional[str] = None,
    min_score: float = 0.0,
) -> list[Entity]:
    """Extract named entities from text.

    Auto-detects language and uses the appropriate NER backend:
    - Russian → Natasha (lightweight, no GPU)
    - Kazakh → HuggingFace KazNERD (if transformers installed), else Natasha fallback

    Args:
        text: Input text.
        lang: Force language (``"ru"``, ``"kk"``). Auto-detected if None.
        min_score: Minimum confidence score to include (default 0.0 = all).

    Returns:
        List of Entity objects with normalized labels.
    """
    if not text or len(text.strip()) < 3:
        return []

    if lang is None:
        lang = detect_lang(text)

    if lang == "kk":
        entities = _extract_hf(text)
    else:
        entities = _extract_natasha(text)

    if min_score > 0:
        entities = [e for e in entities if e.score >= min_score]

    return entities
