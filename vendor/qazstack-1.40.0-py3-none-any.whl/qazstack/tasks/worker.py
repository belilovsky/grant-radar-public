"""ARQ worker factory – standardized async task processing.

Usage:
    # worker.py
    from qazstack.tasks import create_worker_settings, create_scheduler

    async def process_data(ctx, data_id: int):
        # do work
        pass

    async def daily_cleanup(ctx):
        # scheduled task
        pass

    WorkerSettings = create_worker_settings(
        redis_url="redis://redis:6379",
        functions=[process_data],
        cron_jobs=[
            create_scheduler(daily_cleanup, hour=3, minute=0),
        ],
    )

    # Run: arq worker.WorkerSettings
"""

from __future__ import annotations

import logging
from typing import Any, Callable, Sequence

logger = logging.getLogger("qazstack.tasks")


def create_worker_settings(
    redis_url: str,
    *,
    functions: Sequence[Callable] | None = None,
    cron_jobs: Sequence[Any] | None = None,
    on_startup: Callable | None = None,
    on_shutdown: Callable | None = None,
    max_jobs: int = 10,
    job_timeout: int = 300,
    queue_name: str = "arq:queue",
) -> type:
    """Create ARQ WorkerSettings class.

    Requires arq: pip install qazstack[redis]
    """
    try:
        from arq import cron as arq_cron  # noqa: F401
    except ImportError:
        raise ImportError("arq is required for task processing. Install with: pip install qazstack[redis]")

    # Parse Redis URL
    redis_settings = _parse_redis_url(redis_url)

    class WorkerSettings:
        redis_settings = None  # set below
        functions_list = list(functions or [])
        cron_jobs_list = list(cron_jobs or [])
        on_startup_fn = staticmethod(on_startup) if on_startup else None
        on_shutdown_fn = staticmethod(on_shutdown) if on_shutdown else None
        max_jobs_val = max_jobs
        job_timeout_val = job_timeout
        queue_name_val = queue_name

    # Build the actual class with arq's expected attributes
    attrs: dict[str, Any] = {
        "redis_settings": redis_settings,
        "functions": list(functions or []),
        "max_jobs": max_jobs,
        "job_timeout": job_timeout,
        "queue_name": queue_name,
    }
    if cron_jobs:
        attrs["cron_jobs"] = list(cron_jobs)
    if on_startup:
        attrs["on_startup"] = staticmethod(on_startup)
    if on_shutdown:
        attrs["on_shutdown"] = staticmethod(on_shutdown)

    return type("WorkerSettings", (), attrs)


def create_scheduler(
    func: Callable,
    *,
    hour: int | set[int] | None = None,
    minute: int | set[int] | None = None,
    second: int | set[int] | None = None,
    weekday: int | set[int] | None = None,
    month: int | set[int] | None = None,
    unique: bool = True,
    timeout: int | None = None,
    run_at_startup: bool = False,
) -> Any:
    """Create an ARQ cron job definition.

    Args:
        func: Async function to schedule.
        hour: Hour(s) to run (0-23).
        minute: Minute(s) to run (0-59).
        second: Second(s) to run (0-59).
        weekday: Day(s) of week (0=Mon, 6=Sun).
        month: Month(s) to run (1-12).
        unique: Whether to prevent overlapping runs.
        timeout: Job timeout in seconds.
        run_at_startup: Run immediately on worker start.
    """
    try:
        from arq import cron
    except ImportError:
        raise ImportError("arq is required for scheduling. Install with: pip install qazstack[redis]")

    kwargs: dict[str, Any] = {"unique": unique}
    if hour is not None:
        kwargs["hour"] = hour
    if minute is not None:
        kwargs["minute"] = minute
    if second is not None:
        kwargs["second"] = second
    if weekday is not None:
        kwargs["weekday"] = weekday
    if month is not None:
        kwargs["month"] = month
    if timeout is not None:
        kwargs["timeout"] = timeout
    if run_at_startup:
        kwargs["run_at_startup"] = True

    return cron(func, **kwargs)


def _parse_redis_url(url: str):
    """Parse Redis URL into arq RedisSettings."""
    from urllib.parse import urlparse

    from arq.connections import RedisSettings

    parsed = urlparse(url)
    return RedisSettings(
        host=parsed.hostname or "localhost",
        port=parsed.port or 6379,
        database=int(parsed.path.lstrip("/") or 0),
        password=parsed.password,
    )
