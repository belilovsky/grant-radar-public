"""Typed, privacy-preserving contracts for shared public contact routes."""

from __future__ import annotations

import re
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, Literal
from urllib.parse import urlencode

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

if TYPE_CHECKING:
    from qazstack.bus import Event

DeliveryMode = Literal["managed", "external", "review"]
CommunicationEventType = Literal["received", "assigned", "replied", "closed"]
SafeMetric = int | float | bool | None

_DOMAIN_RE = re.compile(r"^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$")
_ROUTE_ID_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,127}$")
_OPAQUE_REF_RE = re.compile(r"^sha256:[a-f0-9]{64}$")
_PRIVATE_EVENT_KEYS = {
    "address",
    "body",
    "content",
    "email",
    "from",
    "message",
    "name",
    "phone",
    "recipient",
    "sender",
    "subject",
    "to",
}


def utc_now() -> datetime:
    """Return a timezone-aware UTC timestamp."""
    return datetime.now(timezone.utc)


class ContactRoute(BaseModel):
    """One public feedback route owned by a product or a shared service."""

    model_config = ConfigDict(extra="forbid")

    route_id: str = Field(min_length=1, max_length=128)
    domain: str = Field(min_length=3, max_length=253)
    contact_email: str = Field(min_length=6, max_length=320)
    aliases: list[str] = Field(default_factory=list, max_length=20)
    delivery: DeliveryMode = "managed"

    @field_validator("route_id")
    @classmethod
    def validate_route_id(cls, value: str) -> str:
        normalized = value.strip().lower()
        if not _ROUTE_ID_RE.fullmatch(normalized):
            raise ValueError("route_id must use lowercase letters, digits and hyphens")
        return normalized

    @field_validator("domain")
    @classmethod
    def validate_domain(cls, value: str) -> str:
        normalized = value.strip().lower().rstrip(".")
        if not _DOMAIN_RE.fullmatch(normalized):
            raise ValueError("domain must be a valid public DNS name")
        return normalized

    @field_validator("contact_email", "aliases", mode="before")
    @classmethod
    def normalize_email_values(cls, value: str | list[str]) -> str | list[str]:
        if isinstance(value, list):
            return [item.strip().lower() for item in value]
        return value.strip().lower()

    @model_validator(mode="after")
    def validate_addresses(self) -> ContactRoute:
        canonical = f"contact@{self.domain}"
        if self.delivery == "managed" and self.contact_email != canonical:
            raise ValueError(f"contact_email must be {canonical}")
        contact_local_part, contact_separator, contact_domain = self.contact_email.partition("@")
        if not contact_separator or not contact_local_part or contact_domain != self.domain:
            raise ValueError("contact_email must be an email address on the route domain")
        if len(set(self.aliases)) != len(self.aliases):
            raise ValueError("aliases must not contain duplicates")
        for alias in self.aliases:
            local_part, separator, alias_domain = alias.partition("@")
            if not separator or not local_part or alias_domain != self.domain:
                raise ValueError("aliases must be email addresses on the route domain")
        return self

    def mailto_url(self, *, subject: str | None = None) -> str:
        """Return the canonical feedback URL without exposing delivery internals."""
        query = urlencode({"subject": subject}) if subject else ""
        return f"mailto:{self.contact_email}{'?' + query if query else ''}"


class CommunicationDirectory(BaseModel):
    """Versioned public route directory that can be fetched by any consumer."""

    model_config = ConfigDict(extra="forbid")

    schema_version: Literal["qazstack-communications-v1"] = "qazstack-communications-v1"
    routes: list[ContactRoute] = Field(default_factory=list, max_length=500)

    @model_validator(mode="after")
    def validate_unique_routes(self) -> CommunicationDirectory:
        domains = [route.domain for route in self.routes]
        route_ids = [route.route_id for route in self.routes]
        if len(set(domains)) != len(domains):
            raise ValueError("routes must not repeat domains")
        if len(set(route_ids)) != len(route_ids):
            raise ValueError("routes must not repeat route_id values")
        return self

    def resolve(self, domain: str) -> ContactRoute | None:
        """Resolve a public contact route by canonical domain."""
        normalized = domain.strip().lower().rstrip(".")
        return next((route for route in self.routes if route.domain == normalized), None)


class CommunicationEvent(BaseModel):
    """Metadata-only event for operational telemetry, never message transport."""

    model_config = ConfigDict(extra="forbid")

    event_type: CommunicationEventType
    route_id: str = Field(min_length=1, max_length=128)
    conversation_ref: str = Field(pattern=r"^sha256:[a-f0-9]{64}$")
    occurred_at: datetime = Field(default_factory=utc_now)
    metrics: dict[str, SafeMetric] = Field(default_factory=dict, max_length=20)

    @field_validator("route_id")
    @classmethod
    def validate_event_route_id(cls, value: str) -> str:
        normalized = value.strip().lower()
        if not _ROUTE_ID_RE.fullmatch(normalized):
            raise ValueError("route_id must use lowercase letters, digits and hyphens")
        return normalized

    @field_validator("conversation_ref")
    @classmethod
    def validate_opaque_reference(cls, value: str) -> str:
        if not _OPAQUE_REF_RE.fullmatch(value):
            raise ValueError("conversation_ref must be a sha256 opaque reference")
        return value

    @field_validator("metrics", mode="before")
    @classmethod
    def validate_metrics(cls, value: dict[str, Any]) -> dict[str, SafeMetric]:
        if not isinstance(value, dict):
            raise ValueError("communication metrics must be an object")
        for key, item in value.items():
            normalized_key = key.strip().lower().replace("-", "_")
            if not normalized_key or normalized_key in _PRIVATE_EVENT_KEYS:
                raise ValueError(f"unsafe communication metric: {key}")
            if isinstance(item, str):
                raise ValueError(f"communication metrics must not contain text: {key}")
        return value

    def to_bus_event(self, *, source: str = "unknown") -> "Event":
        """Map the safe subset into an optional in-memory QazStack bus event."""
        from qazstack.bus import Event, EventPriority

        return Event(
            topic=f"communications.{self.event_type}",
            source=source,
            priority=EventPriority.NORMAL,
            correlation_id=self.conversation_ref,
            payload={
                "event_type": self.event_type,
                "route_id": self.route_id,
                "conversation_ref": self.conversation_ref,
                "occurred_at": self.occurred_at.isoformat(),
                "metrics": self.metrics,
            },
        )
