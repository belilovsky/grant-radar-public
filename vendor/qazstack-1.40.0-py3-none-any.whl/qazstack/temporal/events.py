"""Dependency-free event identity and near-duplicate helpers."""

from __future__ import annotations

import hashlib
import re
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from datetime import date
from typing import Any
from urllib.parse import urlsplit, urlunsplit

from qazstack.evidence.states import EvidenceState, is_http_source_url, resolve_public_evidence_state
from qazstack.temporal.contracts import EventBatchQuality, TemporalEvent, TemporalEventBatch

_SPACE_RE = re.compile(r"\s+")
_TOKEN_RE = re.compile(r"[\w]+", re.UNICODE)
_TRACKING_KEYS = frozenset({"fbclid", "gclid", "yclid"})
SENSITIVE_EVENT_TYPES = frozenset(
    {
        "arrest",
        "conviction",
        "court",
        "criminal_case",
        "detention",
        "legal",
        "wanted",
        "задержание",
        "осуждение",
        "розыск",
        "суд",
        "юридические",
    }
)


@dataclass(frozen=True, slots=True)
class PublicEventProvenance:
    """Source projection for one event; it contains no editorial assertion text."""

    evidence_state: EvidenceState
    source_url: str | None
    publishable: bool


def resolve_public_event_provenance(
    *,
    event_type: object,
    direct_source_url: object = "",
    reviewed_source_urls: Iterable[object] = (),
    sensitive_event_types: Iterable[str] = SENSITIVE_EVENT_TYPES,
) -> PublicEventProvenance:
    """Resolve an event source label and hide sensitive unsourced events."""
    reviewed = [str(url).strip() for url in reviewed_source_urls if is_http_source_url(url)]
    direct = str(direct_source_url or "").strip()
    state = resolve_public_evidence_state(
        direct_source_url=direct,
        reviewed_source_urls=reviewed,
    )
    source_url = reviewed[0] if reviewed else direct if is_http_source_url(direct) else None
    normalized_type = str(event_type or "").strip().casefold()
    sensitive = {str(value).strip().casefold() for value in sensitive_event_types}
    return PublicEventProvenance(
        evidence_state=state,
        source_url=source_url,
        publishable=normalized_type not in sensitive or state is not EvidenceState.UNLINKED,
    )


def normalize_event_title(value: object) -> str:
    """Normalize display whitespace while preserving the original language."""
    return _SPACE_RE.sub(" ", str(value or "").strip())


def normalize_event_url(value: object) -> str:
    """Remove fragments and common tracking parameters from an event URL."""
    raw = str(value or "").strip()
    if not raw:
        return ""
    parts = urlsplit(raw)
    if parts.scheme not in {"http", "https"} or not parts.netloc:
        return raw
    pairs = []
    for pair in parts.query.split("&") if parts.query else []:
        key = pair.partition("=")[0].lower()
        if not key.startswith("utm_") and key not in _TRACKING_KEYS:
            pairs.append(pair)
    path = parts.path.rstrip("/") or "/"
    return urlunsplit((parts.scheme.lower(), parts.netloc.lower(), path, "&".join(pairs), ""))


def event_identity(*, title: object, event_date: object, source_url: object = "", source: object = "") -> str:
    """Return a stable, non-secret public event id."""
    normalized_title = normalize_event_title(title).casefold()
    normalized_url = normalize_event_url(source_url)
    day = str(event_date or "")[:10]
    material = normalized_url or f"{str(source or '').casefold()}|{day}|{normalized_title}"
    digest = hashlib.sha256(material.encode("utf-8")).hexdigest()[:24]
    return f"event:{digest}"


def event_content_hash(event: Mapping[str, Any] | TemporalEvent) -> str:
    """Hash the normalized public event identity fields for lineage checks."""
    payload = event.model_dump(mode="json") if isinstance(event, TemporalEvent) else event
    material = "|".join(
        (
            normalize_event_title(payload.get("title")).casefold(),
            str(payload.get("event_date") or "")[:19],
            str(payload.get("source") or "").casefold(),
            normalize_event_url(payload.get("source_url") or payload.get("url")),
        )
    )
    return f"sha256:{hashlib.sha256(material.encode('utf-8')).hexdigest()}"


def _tokens(value: object) -> set[str]:
    return {token for token in _TOKEN_RE.findall(normalize_event_title(value).casefold()) if len(token) >= 3}


def titles_are_near_duplicates(
    left: object,
    right: object,
    *,
    similarity_threshold: float = 0.72,
    minimum_shared_tokens: int = 3,
) -> bool:
    """Use a transparent overlap score for headline near-duplicates."""
    left_tokens = _tokens(left)
    right_tokens = _tokens(right)
    if not left_tokens or not right_tokens:
        return False
    shared = len(left_tokens & right_tokens)
    return shared >= minimum_shared_tokens and shared / min(len(left_tokens), len(right_tokens)) >= similarity_threshold


def deduplicate_events(
    events: Iterable[TemporalEvent],
    *,
    similarity_threshold: float = 0.72,
    minimum_shared_tokens: int = 3,
) -> tuple[list[TemporalEvent], int]:
    """Preserve first occurrence and remove exact or headline-near duplicates."""
    kept: list[TemporalEvent] = []
    seen_ids: set[str] = set()
    seen_urls: set[str] = set()
    duplicates = 0
    for event in events:
        normalized_url = normalize_event_url(event.source_url)
        exact_duplicate = event.event_id in seen_ids or bool(normalized_url and normalized_url in seen_urls)
        near_duplicate = any(
            candidate.event_date.date() == event.event_date.date()
            and titles_are_near_duplicates(
                candidate.title,
                event.title,
                similarity_threshold=similarity_threshold,
                minimum_shared_tokens=minimum_shared_tokens,
            )
            for candidate in kept
        )
        if exact_duplicate or near_duplicate:
            duplicates += 1
            continue
        kept.append(event)
        seen_ids.add(event.event_id)
        if normalized_url:
            seen_urls.add(normalized_url)
    return kept, duplicates


def build_event_batch(
    events: Iterable[TemporalEvent | Mapping[str, Any]],
    *,
    effective_date: date,
    source_revision: str,
    rejected: int = 0,
    similarity_threshold: float = 0.72,
    minimum_shared_tokens: int = 3,
) -> TemporalEventBatch:
    """Validate events, derive missing identity fields and build a release envelope."""
    normalized: list[TemporalEvent] = []
    for record in events:
        payload = record.model_dump() if isinstance(record, TemporalEvent) else dict(record)
        payload["title"] = normalize_event_title(payload.get("title"))
        if "source_url" not in payload and "url" in payload:
            payload["source_url"] = payload.pop("url")
        payload["source_url"] = normalize_event_url(payload.get("source_url")) or None
        if not payload.get("event_id"):
            payload["event_id"] = event_identity(
                title=payload.get("title"),
                event_date=payload.get("event_date"),
                source_url=payload.get("source_url"),
                source=payload.get("source"),
            )
        if not payload.get("content_hash"):
            payload["content_hash"] = event_content_hash(payload)
        normalized.append(TemporalEvent.model_validate(payload))
    kept, duplicates = deduplicate_events(
        normalized,
        similarity_threshold=similarity_threshold,
        minimum_shared_tokens=minimum_shared_tokens,
    )
    raw = len(normalized) + rejected
    return TemporalEventBatch(
        effective_date=effective_date,
        source_revision=source_revision,
        events=kept,
        quality=EventBatchQuality(raw=raw, kept=len(kept), duplicates=duplicates, rejected=rejected),
    )
