"""Security checkers: hardcoded secrets, open ports, docs_url, debug mode."""

from __future__ import annotations

import re
from pathlib import Path

from qazstack.audit.base import BaseChecker, is_excluded
from qazstack.audit.models import Severity


class HardcodedSecretsChecker(BaseChecker):
    """Scan Python files for hardcoded secrets and API keys."""

    category = "security"
    name = "hardcoded-secrets"

    _SECRET_PATTERNS: list[tuple[str, str]] = [
        (r'(?:password|passwd|pwd)\s*=\s*["\'][^"\']+["\']', "hardcoded password"),
        (r'SECRET_KEY\s*=\s*["\'][^"\']+["\']', "hardcoded SECRET_KEY"),
        (r'(?:api_key|apikey|API_KEY)\s*=\s*["\'][^"\']+["\']', "hardcoded API key"),
        (r'(?:token|TOKEN)\s*=\s*["\'][a-zA-Z0-9_\-]{20,}["\']', "hardcoded token"),
        (r"(?:sk-|pk_live_|sk_live_|AKIA)[A-Za-z0-9]{10,}", "possible API key/secret"),
    ]

    # Files/patterns to exclude (test files, examples, env templates).
    _EXCLUDE_PATTERNS = {"test_", "conftest", ".env.example", "example", "fixture"}

    def run(self, project_path: Path) -> list:
        issues: list[str] = []

        for py_file in project_path.rglob("*.py"):
            if is_excluded(py_file, project_path):
                continue
            rel = str(py_file.relative_to(project_path))
            # Skip test and example files.
            if any(p in rel.lower() for p in self._EXCLUDE_PATTERNS):
                continue

            try:
                content = py_file.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue

            for pattern, desc in self._SECRET_PATTERNS:
                matches = re.findall(pattern, content, re.IGNORECASE)
                for m in matches:
                    # Skip obvious non-secrets.
                    val = m.split("=", 1)[-1].strip().strip("\"'") if "=" in m else m
                    if val.lower() in {
                        "",
                        "none",
                        "null",
                        "changeme",
                        "change-me",
                        "change-me-in-production",
                        "xxx",
                        "test",
                        "example",
                    }:
                        continue
                    issues.append(f"{rel}: {desc}")
                    break  # One per file per pattern is enough.

        if issues:
            return [
                self._make_result(
                    "hardcoded-secrets",
                    False,
                    message=f"{len(issues)} potential hardcoded secret(s)",
                    details=issues[:10],
                    severity=Severity.ERROR,
                )
            ]
        return [self._make_result("hardcoded-secrets", True, message="No hardcoded secrets detected")]


class OpenPortsChecker(BaseChecker):
    """Check docker-compose for ports exposed on 0.0.0.0."""

    category = "security"
    name = "open-ports"

    def run(self, project_path: Path) -> list:
        dc = project_path / "docker-compose.yml"
        if not dc.exists():
            dc = project_path / "docker-compose.yaml"
        if not dc.exists():
            return [self._make_result("open-ports", True, message="No docker-compose found", skipped=True)]

        content = dc.read_text(encoding="utf-8", errors="ignore")
        issues: list[str] = []

        # Find port mappings that expose on 0.0.0.0 (i.e. no 127.0.0.1 prefix).
        # Match patterns like:  - "5432:5432" or - 5432:5432  (without 127.0.0.1)
        for match in re.finditer(r'^\s+-\s+"?(\d+):(\d+)"?\s*$', content, re.MULTILINE):
            host_port = match.group(1)
            container_port = match.group(2)
            # Check if this line has 127.0.0.1 prefix (look at preceding context).
            line = match.group(0)
            if "127.0.0.1" not in line:
                # Check if it's a DB port.
                if container_port in ("5432", "3306", "6379", "27017"):
                    issues.append(f"Port {host_port}:{container_port} exposed on 0.0.0.0 (DB should be 127.0.0.1 only)")

        if issues:
            return [
                self._make_result(
                    "open-ports",
                    False,
                    message=f"{len(issues)} database port(s) exposed publicly",
                    details=issues,
                    severity=Severity.ERROR,
                )
            ]
        return [self._make_result("open-ports", True, message="No database ports exposed publicly")]


class DocsUrlChecker(BaseChecker):
    """Check if FastAPI docs_url is exposed in production config."""

    category = "security"
    name = "docs-url"

    def run(self, project_path: Path) -> list:
        for py_file in project_path.rglob("*.py"):
            if is_excluded(py_file, project_path):
                continue
            try:
                content = py_file.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue

            # Check for FastAPI app creation with docs_url enabled.
            if "FastAPI(" in content or "create_app(" in content:
                # Good: docs_url=None
                if "docs_url=None" in content or "docs_url = None" in content:
                    continue
                # Check if docs_url is conditionally set based on DEBUG.
                if re.search(r"docs_url.*DEBUG|DEBUG.*docs_url", content, re.IGNORECASE):
                    continue
                # If FastAPI is created without disabling docs, warn.
                if "FastAPI(" in content:
                    rel = py_file.relative_to(project_path)
                    return [
                        self._make_result(
                            "docs-url",
                            False,
                            message=f"FastAPI docs_url may be exposed in production ({rel})",
                            severity=Severity.WARNING,
                            fixable=True,
                            fix_hint="Set docs_url=None in production or gate behind DEBUG",
                        )
                    ]

        return [self._make_result("docs-url", True, message="docs_url not exposed or properly gated")]

    def fix(self, project_path: Path) -> list[str]:
        """Add docs_url=None to FastAPI() calls."""
        fixed: list[str] = []
        for py_file in project_path.rglob("*.py"):
            if is_excluded(py_file, project_path):
                continue
            try:
                content = py_file.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue

            if "FastAPI(" not in content:
                continue
            if "docs_url=None" in content or "docs_url = None" in content:
                continue
            if re.search(r"docs_url.*DEBUG|DEBUG.*docs_url", content, re.IGNORECASE):
                continue

            # Patch: FastAPI() → FastAPI(docs_url=None)
            # Handle FastAPI() with no args and FastAPI(...) with args
            new_content = re.sub(
                r"FastAPI\(\)",
                "FastAPI(docs_url=None)",
                content,
            )
            if new_content == content:
                # Has args: FastAPI(title=...) → FastAPI(docs_url=None, title=...)
                new_content = re.sub(
                    r"FastAPI\(",
                    "FastAPI(docs_url=None, ",
                    content,
                    count=1,
                )
            if new_content != content:
                py_file.write_text(new_content, encoding="utf-8")
                rel = py_file.relative_to(project_path)
                fixed.append(f"Added docs_url=None to FastAPI() in {rel}")

        return fixed


class DebugModeChecker(BaseChecker):
    """Check for DEBUG=True that might leak to production."""

    category = "security"
    name = "debug-mode"

    def run(self, project_path: Path) -> list:
        issues: list[str] = []

        for py_file in project_path.rglob("*.py"):
            if is_excluded(py_file, project_path):
                continue
            rel = str(py_file.relative_to(project_path))
            # Skip test files.
            if "test" in rel.lower() or "conftest" in rel.lower():
                continue
            try:
                content = py_file.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue

            # Check for DEBUG = True (not from env).
            if re.search(r"\bDEBUG\s*[:=]\s*True\b", content):
                # Make sure it's not a type annotation or default in BaseSettings.
                if not re.search(r"DEBUG\s*:\s*bool\s*=\s*True", content):
                    issues.append(f"{rel}: DEBUG = True (hardcoded)")
                else:
                    # Even as default, it's risky.
                    issues.append(f"{rel}: DEBUG defaults to True – ensure .env overrides in production")

        # Check .env.example for DEBUG=true.
        env_example = project_path / ".env.example"
        if env_example.exists():
            try:
                content = env_example.read_text(encoding="utf-8", errors="ignore")
                for line in content.splitlines():
                    if re.match(r"^\s*DEBUG\s*=\s*true\s*$", line, re.IGNORECASE):
                        issues.append(".env.example: DEBUG=true – should default to false")
            except Exception:
                pass

        if issues:
            return [
                self._make_result(
                    "debug-mode",
                    False,
                    message=f"{len(issues)} debug-mode concern(s)",
                    details=issues,
                    severity=Severity.WARNING,
                )
            ]
        return [self._make_result("debug-mode", True, message="No debug-mode concerns")]
