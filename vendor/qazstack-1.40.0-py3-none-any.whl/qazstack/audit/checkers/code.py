"""Code quality checkers: ruff lint, dead imports, platform standard, vendored code."""

from __future__ import annotations

import re
import shutil
import subprocess
from pathlib import Path

from qazstack.audit.base import BaseChecker, is_excluded
from qazstack.audit.models import CheckResult, Severity


class RuffLintChecker(BaseChecker):
    """Run ruff linter on project Python files.

    Note: dead-imports checker is intentionally separate – it gives a focused
    count of F401 issues and supports targeted --fix.  The ruff-lint checker
    reports overall lint health excluding F401 to avoid double-counting.
    """

    category = "code"
    name = "ruff-lint"

    def run(self, project_path: Path) -> list[CheckResult]:
        if not shutil.which("ruff"):
            return [
                self._make_result(
                    "ruff-lint",
                    False,
                    message="ruff is not installed",
                    severity=Severity.WARNING,
                    skipped=True,
                )
            ]

        src_dirs = _find_src_dirs(project_path)
        if not src_dirs:
            return [self._make_result("ruff-lint", True, message="No Python files found", skipped=True)]

        try:
            proc = subprocess.run(
                ["ruff", "check", "--select=E,W,I,F", "--ignore=F401", "--output-format=concise", "--no-fix"]
                + src_dirs,
                capture_output=True,
                text=True,
                timeout=60,
                cwd=str(project_path),
            )
            issues = [ln.strip() for ln in proc.stdout.strip().split("\n") if ln.strip()]
            if proc.returncode == 0 or not issues:
                return [self._make_result("ruff-lint", True, message="No lint issues")]

            errors = [i for i in issues if re.search(r":\s*[EF]\d", i)]
            return [
                self._make_result(
                    "ruff-lint",
                    False,
                    message=f"{len(issues)} lint issues ({len(errors)} errors, {len(issues) - len(errors)} style)",
                    details=issues[:20],
                    severity=Severity.WARNING if not errors else Severity.ERROR,
                    fixable=True,
                    fix_hint="Run: ruff check --fix . && ruff format --line-length=120 .",
                )
            ]
        except subprocess.TimeoutExpired:
            return [self._make_result("ruff-lint", False, message="ruff timed out", severity=Severity.WARNING)]
        except Exception as exc:
            return [self._make_result("ruff-lint", False, message=f"ruff failed: {exc}", severity=Severity.WARNING)]

    def fix(self, project_path: Path) -> list[str]:
        if not shutil.which("ruff"):
            return []
        fixes: list[str] = []
        try:
            subprocess.run(
                ["ruff", "check", "--fix", "."],
                capture_output=True,
                text=True,
                timeout=60,
                cwd=str(project_path),
            )
            fixes.append("ruff check --fix applied")
        except Exception:
            pass
        try:
            subprocess.run(
                ["ruff", "format", "--line-length=120", "."],
                capture_output=True,
                text=True,
                timeout=60,
                cwd=str(project_path),
            )
            fixes.append("ruff format --line-length=120 applied")
        except Exception:
            pass
        return fixes


class DeadImportsChecker(BaseChecker):
    """Detect unused imports (F401 only).

    Separated from RuffLintChecker so the score counts them once and the
    user gets a focused metric on import hygiene.
    """

    category = "code"
    name = "dead-imports"

    def run(self, project_path: Path) -> list[CheckResult]:
        if not shutil.which("ruff"):
            return [self._make_result("dead-imports", True, message="ruff not available", skipped=True)]

        src_dirs = _find_src_dirs(project_path)
        if not src_dirs:
            return [self._make_result("dead-imports", True, message="No Python files", skipped=True)]

        try:
            proc = subprocess.run(
                ["ruff", "check", "--select=F401", "--output-format=concise", "--no-fix"] + src_dirs,
                capture_output=True,
                text=True,
                timeout=60,
                cwd=str(project_path),
            )
            issues = [ln.strip() for ln in proc.stdout.strip().split("\n") if ln.strip()]
            if proc.returncode == 0 or not issues:
                return [self._make_result("dead-imports", True, message="No unused imports")]
            return [
                self._make_result(
                    "dead-imports",
                    False,
                    message=f"{len(issues)} unused imports",
                    details=issues[:15],
                    severity=Severity.WARNING,
                    fixable=True,
                )
            ]
        except Exception as exc:
            return [self._make_result("dead-imports", False, message=f"Check failed: {exc}", severity=Severity.WARNING)]

    def fix(self, project_path: Path) -> list[str]:
        if not shutil.which("ruff"):
            return []
        try:
            subprocess.run(
                ["ruff", "check", "--select=F401", "--fix", "."],
                capture_output=True,
                text=True,
                timeout=60,
                cwd=str(project_path),
            )
            return ["Removed unused imports via ruff --select=F401 --fix"]
        except Exception:
            return []


class PlatformStandardChecker(BaseChecker):
    """Check compliance with Belilovsky Platform Standard."""

    category = "code"
    name = "platform-standard"

    ANTI_PATTERNS = [
        (r"@app\.on_event\(", "Use lifespan instead of @app.on_event (deprecated)"),
    ]

    def run(self, project_path: Path) -> list[CheckResult]:
        results: list[CheckResult] = []

        # ── Anti-patterns ──
        anti_issues: list[str] = []
        for py_file in project_path.rglob("*.py"):
            if is_excluded(py_file, project_path):
                continue
            try:
                content = py_file.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue
            rel = py_file.relative_to(project_path)
            for pattern, desc in self.ANTI_PATTERNS:
                if re.search(pattern, content):
                    anti_issues.append(f"{rel}: {desc}")

        results.append(
            self._make_result(
                "anti-patterns",
                not anti_issues,
                message=f"{len(anti_issues)} anti-pattern(s) detected" if anti_issues else "No anti-patterns detected",
                details=anti_issues[:10],
                severity=Severity.WARNING if anti_issues else Severity.INFO,
            )
        )

        # ── Health endpoint ──
        has_health = False
        for py_file in project_path.rglob("*.py"):
            if is_excluded(py_file, project_path):
                continue
            try:
                content = py_file.read_text(encoding="utf-8", errors="ignore")
                if "/health" in content:
                    has_health = True
                    break
            except Exception:
                continue

        results.append(
            self._make_result(
                "health-endpoint",
                has_health,
                message="Health endpoint found" if has_health else "Missing /health endpoint",
                severity=Severity.ERROR if not has_health else Severity.INFO,
                fix_hint="Add @app.get('/health') returning {'status': 'ok'}" if not has_health else None,
            )
        )

        # ── Project structure ──
        # Accept templates/static either in root or inside app/
        expected = {"app_or_src": False, "templates": False, "static": False, "tests": False}
        expected["app_or_src"] = (project_path / "app").is_dir() or (project_path / "src").is_dir()
        expected["templates"] = (project_path / "templates").is_dir() or (project_path / "app" / "templates").is_dir()
        expected["static"] = (project_path / "static").is_dir() or (project_path / "app" / "static").is_dir()
        expected["tests"] = (project_path / "tests").is_dir()

        missing = [k for k, v in expected.items() if not v]
        results.append(
            self._make_result(
                "project-structure",
                not missing,
                message=f"Missing: {', '.join(missing)}" if missing else "Standard structure OK",
                details=[f"Missing: {d}/" for d in missing],
                severity=Severity.WARNING if missing else Severity.INFO,
            )
        )

        return results


class VendoredCodeChecker(BaseChecker):
    """Detect local copies of code that is now available in qazstack."""

    category = "code"
    name = "vendored-code"

    _JS_VENDORED: dict[str, str] = {
        "infinite_scroll": "qazstack.ui (QS.InfiniteScroll)",
        "nlp_widget": "qazstack.ui (QS.NLPWidget)",
    }

    _PY_VENDORED_CLASSES: dict[str, str] = {
        "class BaseConfig": "qazstack.core.BaseConfig",
    }

    _MODULE_OVERLAP: list[tuple[str, str]] = [
        ("governance", "qazstack.governance"),
        ("roles", "qazstack.governance"),
    ]

    def run(self, project_path: Path) -> list[CheckResult]:
        issues: list[str] = []

        for js_file in project_path.rglob("*.js"):
            if is_excluded(js_file, project_path):
                continue
            stem = js_file.stem.lower()
            for pattern, suggestion in self._JS_VENDORED.items():
                if pattern in stem:
                    rel = js_file.relative_to(project_path)
                    issues.append(f"{rel} \u2192 use {suggestion}")

        for py_file in project_path.rglob("*.py"):
            if is_excluded(py_file, project_path):
                continue
            try:
                content = py_file.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue
            rel = py_file.relative_to(project_path)
            for pattern, suggestion in self._PY_VENDORED_CLASSES.items():
                if pattern in content and "qazstack" not in str(rel):
                    issues.append(f"{rel}: local '{pattern}' \u2192 use {suggestion}")

        for dirname, suggestion in self._MODULE_OVERLAP:
            local_dir = project_path / "app" / dirname
            if local_dir.is_dir() and list(local_dir.glob("*.py")):
                issues.append(f"app/{dirname}/ \u2192 consider {suggestion}")

        if issues:
            return [
                self._make_result(
                    "vendored-code",
                    False,
                    message=f"{len(issues)} vendored/duplicated file(s)",
                    details=issues[:15],
                    severity=Severity.WARNING,
                    fix_hint="Replace local copies with qazstack imports",
                )
            ]
        return [self._make_result("vendored-code", True, message="No vendored code detected")]


# ── Shared helpers ──────────────────────────────────────────────────────────


def _find_src_dirs(project_path: Path) -> list[str]:
    """Return the first Python source directory found (relative to project_path)."""
    for candidate in ["app", "src", "."]:
        p = project_path / candidate
        if p.is_dir() and list(p.glob("**/*.py")):
            return [candidate]
    return []
