"""Dependency checkers: qazstack version, usage opportunities, Python version, unused deps."""

from __future__ import annotations

import re
import sys
from pathlib import Path

from qazstack.audit.base import BaseChecker, is_excluded
from qazstack.audit.models import Severity

if sys.version_info >= (3, 11):
    import tomllib
else:
    tomllib = None  # type: ignore[assignment]


def _read_toml(path: Path) -> dict | None:
    """Read a TOML file, return None on failure."""
    if tomllib is None:
        return None
    try:
        with open(path, "rb") as f:
            return tomllib.load(f)
    except Exception:
        return None


class QazStackVersionChecker(BaseChecker):
    """Check that qazstack dependency is present and >= 1.3.0."""

    category = "deps"
    name = "qazstack-version"

    def run(self, project_path: Path) -> list:
        pyproject = project_path / "pyproject.toml"
        if pyproject.exists():
            data = _read_toml(pyproject)
            if data:
                deps = data.get("project", {}).get("dependencies", [])
                for dep in deps:
                    if "qazstack" in dep.lower():
                        match = re.search(r">=\s*(\d+\.\d+\.?\d*)", dep)
                        if match:
                            ver = match.group(1)
                            parts = [int(x) for x in ver.split(".")]
                            if len(parts) >= 2 and (parts[0], parts[1]) >= (1, 3):
                                return [
                                    self._make_result(
                                        "qazstack-version", True, message=f"qazstack>={ver} in pyproject.toml"
                                    )
                                ]
                            return [
                                self._make_result(
                                    "qazstack-version",
                                    False,
                                    message=f"qazstack>={ver} – update to >=1.3.0",
                                    severity=Severity.WARNING,
                                    fix_hint="Update qazstack dependency to >=1.3.0 in pyproject.toml",
                                )
                            ]
                        return [
                            self._make_result(
                                "qazstack-version", True, message="qazstack in pyproject.toml (no version pin)"
                            )
                        ]

        req = project_path / "requirements.txt"
        if req.exists():
            for line in req.read_text(encoding="utf-8", errors="ignore").splitlines():
                if "qazstack" in line.lower():
                    match = re.search(r">=\s*(\d+\.\d+\.?\d*)", line)
                    if match:
                        ver = match.group(1)
                        parts = [int(x) for x in ver.split(".")]
                        if len(parts) >= 2 and (parts[0], parts[1]) >= (1, 3):
                            return [self._make_result("qazstack-version", True, message=f"qazstack>={ver}")]
                        return [
                            self._make_result(
                                "qazstack-version",
                                False,
                                message=f"qazstack>={ver} – update to >=1.3.0",
                                severity=Severity.WARNING,
                            )
                        ]
                    return [self._make_result("qazstack-version", True, message="qazstack in requirements.txt")]

        return [
            self._make_result(
                "qazstack-version",
                False,
                message="qazstack not found in dependencies",
                severity=Severity.ERROR,
            )
        ]


class QazStackUsageChecker(BaseChecker):
    """Detect missed opportunities to use qazstack modules."""

    category = "deps"
    name = "qazstack-usage"

    _OPPORTUNITIES: list[tuple[str, str, str]] = [
        (r'["\'/]health["\']', "qazstack.core", "Use qazstack.core.health_router instead of custom /health"),
        (
            r"class\s+\w+\(BaseSettings\)",
            "qazstack.core",
            "Use qazstack.core.BaseConfig instead of raw Pydantic Settings",
        ),
        (r"templates/|TemplateResponse", "qazstack.ui", "Use qazstack.ui.setup_ui for template setup"),
        (r"ner|NER|named.entity|spacy", "qazstack.kznlp", "Use qazstack.kznlp for NLP/NER processing"),
        (r"RateLimi|rate.limit|slowapi", "qazstack.limiter", "Use qazstack.limiter for rate limiting"),
        (r"page.*=|per_page|offset.*limit|paginate", "qazstack.pagination", "Use qazstack.pagination for pagination"),
    ]

    def run(self, project_path: Path) -> list:
        suggestions: list[str] = []
        all_py_content = ""
        for py_file in project_path.rglob("*.py"):
            if is_excluded(py_file, project_path):
                continue
            try:
                all_py_content += py_file.read_text(encoding="utf-8", errors="ignore") + "\n"
            except Exception:
                continue

        for pattern, module_import, suggestion in self._OPPORTUNITIES:
            if re.search(pattern, all_py_content) and module_import not in all_py_content:
                suggestions.append(suggestion)

        if suggestions:
            return [
                self._make_result(
                    "qazstack-usage",
                    False,
                    message=f"{len(suggestions)} unused qazstack module opportunity(ies)",
                    details=suggestions,
                    severity=Severity.INFO,
                )
            ]
        return [self._make_result("qazstack-usage", True, message="Good qazstack module coverage")]


class PythonVersionChecker(BaseChecker):
    """Check Python version in Dockerfile."""

    category = "deps"
    name = "python-version"

    def run(self, project_path: Path) -> list:
        df = project_path / "Dockerfile"
        if not df.exists():
            return [self._make_result("python-version", True, message="No Dockerfile to check", skipped=True)]

        content = df.read_text(encoding="utf-8", errors="ignore")
        match = re.search(r"python:(\d+)\.(\d+)", content)
        if not match:
            return [self._make_result("python-version", True, message="No Python version in Dockerfile", skipped=True)]

        major, minor = int(match.group(1)), int(match.group(2))
        if major == 3 and minor >= 12:
            return [self._make_result("python-version", True, message=f"Python {major}.{minor} in Dockerfile")]

        return [
            self._make_result(
                "python-version",
                False,
                message=f"Python {major}.{minor} in Dockerfile – recommend 3.12+",
                severity=Severity.WARNING,
            )
        ]


class UnusedDepsChecker(BaseChecker):
    """Check for potentially unused dependencies in pyproject.toml."""

    category = "deps"
    name = "unused-deps"

    # PyPI name → Python import name
    _NAME_MAP: dict[str, str] = {
        "pydantic-settings": "pydantic_settings",
        "python-multipart": "multipart",
        "uvicorn[standard]": "uvicorn",
        "python-telegram-bot": "telegram",
        "beautifulsoup4": "bs4",
        "pillow": "PIL",
        "scikit-learn": "sklearn",
        "lxml": "lxml",
        "lxml-html-clean": "lxml_html_clean",
        "newspaper4k": "newspaper",
        "sentry-sdk": "sentry_sdk",
        "sentry-sdk[fastapi]": "sentry_sdk",
        "python-dotenv": "dotenv",
        "pyyaml": "yaml",
        "pyjwt": "jwt",
        "python-docx": "docx",
        "python-jose": "jose",
        "python-jose[cryptography]": "jose",
        "fpdf2": "fpdf",
        "flask-admin": "flask_admin",
        "flask-moment": "flask_moment",
        "flask-session": "flask_session",
        "flask-redis": "flask_redis",
        "flask-httpauth": "flask_httpauth",
        "flask-login": "flask_login",
        "flask-cors": "flask_cors",
        "flask-wtf": "flask_wtf",
        "flask-sqlalchemy": "flask_sqlalchemy",
        "flask-migrate": "flask_migrate",
    }

    # Deps that are typically used at runtime without direct import.
    # These are either CLI tools, database drivers, or implicit deps of frameworks.
    _RUNTIME_DEPS: frozenset[str] = frozenset(
        {
            # ASGI/WSGI servers and CLI tools
            "uvicorn",
            "gunicorn",
            "alembic",
            "ruff",
            "mypy",
            "black",
            "pytest",
            "pytest-asyncio",
            "pytest-cov",
            "httpx",
            # Database drivers (used via connection string, not import)
            "aiosqlite",
            "asyncpg",
            "psycopg2",
            "psycopg2-binary",
            "psycopg",
            # Pymorphy dictionaries (data packages, not imported)
            "pymorphy3-dicts-ru",
            "pymorphy3-dicts-uk",
            # Implicit framework deps
            "python-multipart",  # Required by FastAPI for form/upload
            "email-validator",  # Required by Pydantic for email validation
            "itsdangerous",  # Required by Flask/Starlette sessions
            "orjson",  # Optional fast JSON for FastAPI/Pydantic
            "ujson",  # Optional fast JSON
        }
    )

    def run(self, project_path: Path) -> list:
        pyproject = project_path / "pyproject.toml"
        if not pyproject.exists():
            return [self._make_result("unused-deps", True, message="No pyproject.toml", skipped=True)]

        data = _read_toml(pyproject)
        if not data:
            return [self._make_result("unused-deps", True, message="Could not parse pyproject.toml", skipped=True)]

        deps = data.get("project", {}).get("dependencies", [])
        if not deps:
            return [self._make_result("unused-deps", True, message="No dependencies listed")]

        # Gather all imports
        imports: set[str] = set()
        for py_file in project_path.rglob("*.py"):
            if is_excluded(py_file, project_path):
                continue
            try:
                for line in py_file.read_text(encoding="utf-8", errors="ignore").splitlines():
                    line = line.strip()
                    if line.startswith("import ") or line.startswith("from "):
                        parts = line.replace("import ", "").replace("from ", "").split(".")
                        if parts:
                            imports.add(parts[0].split()[0].strip())
            except Exception:
                continue

        # Also check HTML templates for Jinja2 usage (means jinja2 IS used)
        has_templates = bool(list(project_path.rglob("*.html")))
        if has_templates:
            imports.add("jinja2")

        possibly_unused: list[str] = []
        for dep in deps:
            dep_name = re.split(r"[>=<\[!~]", dep)[0].strip().lower()
            if dep_name in self._RUNTIME_DEPS:
                continue
            import_name = self._NAME_MAP.get(dep_name, dep_name.replace("-", "_"))
            if import_name not in imports and dep_name not in imports:
                possibly_unused.append(dep_name)

        if possibly_unused:
            return [
                self._make_result(
                    "unused-deps",
                    False,
                    message=f"{len(possibly_unused)} possibly unused dep(s)",
                    details=[f"{d} – not imported in project source" for d in possibly_unused[:10]],
                    severity=Severity.INFO,
                )
            ]
        return [self._make_result("unused-deps", True, message="All dependencies appear used")]
