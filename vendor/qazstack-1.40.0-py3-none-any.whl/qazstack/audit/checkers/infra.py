"""Infrastructure checkers: Dockerfile, docker-compose, .env, nginx, .gitignore."""

from __future__ import annotations

import re
from pathlib import Path

from qazstack.audit.base import BaseChecker
from qazstack.audit.models import Severity


class DockerfileChecker(BaseChecker):
    """Validate Dockerfile best practices."""

    category = "infra"
    name = "dockerfile"

    def run(self, project_path: Path) -> list:
        from qazstack.audit.models import CheckResult

        results: list[CheckResult] = []
        df = project_path / "Dockerfile"

        if not df.exists():
            return [
                self._make_result("dockerfile-exists", False, message="Dockerfile not found", severity=Severity.ERROR)
            ]

        results.append(self._make_result("dockerfile-exists", True, message="Dockerfile found"))
        content = df.read_text(encoding="utf-8", errors="ignore")

        # HEALTHCHECK
        has_healthcheck = "HEALTHCHECK" in content
        results.append(
            self._make_result(
                "dockerfile-healthcheck",
                has_healthcheck,
                message="HEALTHCHECK present" if has_healthcheck else "Missing HEALTHCHECK instruction",
                severity=Severity.WARNING if not has_healthcheck else Severity.INFO,
                fix_hint="Add: HEALTHCHECK --interval=30s CMD curl -f http://localhost:8000/health || exit 1"
                if not has_healthcheck
                else None,
            )
        )

        # python:3.12-slim base image
        uses_312 = bool(re.search(r"python:3\.1[2-9]", content))
        results.append(
            self._make_result(
                "dockerfile-python-version",
                uses_312,
                message="Uses Python 3.12+" if uses_312 else "Consider using python:3.12-slim",
                severity=Severity.WARNING if not uses_312 else Severity.INFO,
            )
        )

        # --no-cache-dir
        has_nocache = "--no-cache-dir" in content
        results.append(
            self._make_result(
                "dockerfile-pip-cache",
                has_nocache,
                message="pip --no-cache-dir used" if has_nocache else "Add --no-cache-dir to pip install",
                severity=Severity.INFO,
            )
        )

        return results


class DockerComposeChecker(BaseChecker):
    """Validate docker-compose.yml best practices."""

    category = "infra"
    name = "docker-compose"

    def run(self, project_path: Path) -> list:
        from qazstack.audit.models import CheckResult

        results: list[CheckResult] = []
        dc = project_path / "docker-compose.yml"
        if not dc.exists():
            dc = project_path / "docker-compose.yaml"
        if not dc.exists():
            return [
                self._make_result(
                    "compose-exists", False, message="docker-compose.yml not found", severity=Severity.WARNING
                )
            ]

        results.append(self._make_result("compose-exists", True, message="docker-compose.yml found"))
        content = dc.read_text(encoding="utf-8", errors="ignore")

        # No deprecated version: key
        has_version = bool(re.search(r"^version:", content, re.MULTILINE))
        results.append(
            self._make_result(
                "compose-no-version",
                not has_version,
                message="No deprecated 'version:' key" if not has_version else "Remove deprecated 'version:' key",
                severity=Severity.WARNING if has_version else Severity.INFO,
            )
        )

        # DB port only on 127.0.0.1
        db_port_exposed = bool(re.search(r'"?\d+:\d+"?', content)) and re.search(r"5432|3306|6379|27017", content)
        if db_port_exposed:
            db_port_safe = "127.0.0.1" in content
            results.append(
                self._make_result(
                    "compose-db-port",
                    db_port_safe,
                    message="DB port bound to 127.0.0.1"
                    if db_port_safe
                    else "DB port exposed on 0.0.0.0 – bind to 127.0.0.1",
                    severity=Severity.ERROR if not db_port_safe else Severity.INFO,
                )
            )

        # Has healthcheck for services
        has_healthcheck = "healthcheck:" in content
        results.append(
            self._make_result(
                "compose-healthcheck",
                has_healthcheck,
                message="Healthcheck configured" if has_healthcheck else "Add healthcheck for services",
                severity=Severity.WARNING if not has_healthcheck else Severity.INFO,
            )
        )

        # env_file used
        has_envfile = "env_file:" in content or "env_file" in content
        results.append(
            self._make_result(
                "compose-env-file",
                has_envfile,
                message="env_file configured" if has_envfile else "Use env_file instead of inline environment",
                severity=Severity.INFO,
            )
        )

        # container_name set
        has_container_name = "container_name:" in content
        results.append(
            self._make_result(
                "compose-container-name",
                has_container_name,
                message="container_name set" if has_container_name else "Set container_name for predictable naming",
                severity=Severity.INFO,
            )
        )

        return results


class EnvFileChecker(BaseChecker):
    """Check .env.example exists and has expected keys."""

    category = "infra"
    name = "env-file"

    def run(self, project_path: Path) -> list:
        from qazstack.audit.models import CheckResult

        results: list[CheckResult] = []
        env_example = project_path / ".env.example"

        if not env_example.exists():
            return [
                self._make_result(
                    "env-example",
                    False,
                    message=".env.example not found",
                    severity=Severity.WARNING,
                    fix_hint="Create .env.example with all required environment variables",
                )
            ]

        results.append(self._make_result("env-example", True, message=".env.example found"))

        # Parse keys
        env_keys: set[str] = set()
        for line in env_example.read_text(encoding="utf-8", errors="ignore").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                env_keys.add(line.split("=", 1)[0].strip())

        if not env_keys:
            results.append(
                self._make_result("env-keys", False, message=".env.example is empty", severity=Severity.WARNING)
            )
        else:
            results.append(
                self._make_result("env-keys", True, message=f"{len(env_keys)} environment variable(s) documented")
            )

        return results


class NginxChecker(BaseChecker):
    """Check nginx configuration."""

    category = "infra"
    name = "nginx"

    def run(self, project_path: Path) -> list:
        from qazstack.audit.models import CheckResult

        nginx_conf = None
        for candidate in [
            project_path / "nginx" / "default.conf",
            project_path / "nginx" / "nginx.conf",
            project_path / "nginx.conf",
        ]:
            if candidate.exists():
                nginx_conf = candidate
                break

        if nginx_conf is None:
            return [self._make_result("nginx-config", False, message="No nginx config found", severity=Severity.INFO)]

        results: list[CheckResult] = []
        results.append(self._make_result("nginx-config", True, message="nginx config found"))
        content = nginx_conf.read_text(encoding="utf-8", errors="ignore")

        # /static/ alias
        has_static = "/static/" in content
        results.append(
            self._make_result(
                "nginx-static",
                has_static,
                message="/static/ alias configured" if has_static else "Missing /static/ alias in nginx",
                severity=Severity.WARNING if not has_static else Severity.INFO,
            )
        )

        # proxy_pass
        has_proxy = "proxy_pass" in content
        results.append(
            self._make_result(
                "nginx-proxy",
                has_proxy,
                message="proxy_pass configured" if has_proxy else "Missing proxy_pass in nginx",
                severity=Severity.WARNING if not has_proxy else Severity.INFO,
            )
        )

        # health endpoint
        has_health = "/health" in content or "/nginx-health" in content
        results.append(
            self._make_result(
                "nginx-health",
                has_health,
                message="Health endpoint configured" if has_health else "Missing health endpoint in nginx",
                severity=Severity.INFO,
            )
        )

        return results


class GitignoreChecker(BaseChecker):
    """Check .gitignore exists and has essential entries."""

    category = "infra"
    name = "gitignore"

    _ESSENTIAL = ["__pycache__", ".env", "*.pyc", "node_modules"]

    def run(self, project_path: Path) -> list:
        gitignore = project_path / ".gitignore"
        if not gitignore.exists():
            return [
                self._make_result(
                    "gitignore",
                    False,
                    message=".gitignore not found",
                    severity=Severity.WARNING,
                    fixable=True,
                )
            ]

        content = gitignore.read_text(encoding="utf-8", errors="ignore")
        missing = [e for e in self._ESSENTIAL if e not in content]

        if missing:
            return [
                self._make_result(
                    "gitignore",
                    False,
                    message=f"Missing entries in .gitignore: {', '.join(missing)}",
                    details=[f"Add: {m}" for m in missing],
                    severity=Severity.WARNING,
                    fixable=True,
                )
            ]

        return [self._make_result("gitignore", True, message=".gitignore OK")]

    def fix(self, project_path: Path) -> list[str]:
        """Append missing essential entries to .gitignore."""
        gitignore = project_path / ".gitignore"
        if not gitignore.exists():
            gitignore.write_text("\n".join(self._ESSENTIAL) + "\n", encoding="utf-8")
            return ["Created .gitignore with essential entries"]

        content = gitignore.read_text(encoding="utf-8", errors="ignore")
        missing = [e for e in self._ESSENTIAL if e not in content]
        if not missing:
            return []

        suffix = "\n" if content.endswith("\n") else "\n"
        gitignore.write_text(content + suffix + "\n".join(missing) + "\n", encoding="utf-8")
        return [f"Added to .gitignore: {', '.join(missing)}"]
