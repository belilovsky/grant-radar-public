"""Multi-artifact manifests for product-owned private evidence captures."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone

from qazstack.contracts._validation import (
    require_aware,
    require_identifier,
    require_one_of,
    require_positive,
    require_sha256,
    require_text,
)
from qazstack.evidence.contracts import (
    CAPTURE_STATUSES,
    DEFAULT_RESPONSE_HEADERS,
    EvidenceCaptureRecord,
    normalize_evidence_url,
)

EVIDENCE_MANIFEST_SCHEMA_VERSION = "qazstack-evidence-manifest-v1"
EVIDENCE_ARTIFACT_ROLES = frozenset(
    {"payload", "screenshot", "warc", "wacz", "metadata", "thumbnail", "transcript", "other"}
)
EVIDENCE_ARTIFACT_AVAILABILITY = frozenset({"available", "purged", "missing"})


def _utc_iso(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


@dataclass(frozen=True, slots=True)
class EvidenceCaptureArtifact:
    """One integrity-bound file produced by an evidence capture."""

    artifact_id: str
    role: str
    content_type: str
    size_bytes: int
    digest: str
    archive_ref: str
    created_at: datetime
    availability: str = "available"
    purged_at: datetime | None = None

    def __post_init__(self) -> None:
        require_identifier(self.artifact_id, "artifact_id")
        require_one_of(self.role, EVIDENCE_ARTIFACT_ROLES, "role")
        object.__setattr__(self, "content_type", require_text(self.content_type, "content_type"))
        require_positive(self.size_bytes, "size_bytes")
        object.__setattr__(self, "digest", require_sha256(self.digest))
        object.__setattr__(self, "archive_ref", require_text(self.archive_ref, "archive_ref"))
        require_aware(self.created_at, "created_at")
        require_one_of(self.availability, EVIDENCE_ARTIFACT_AVAILABILITY, "availability")
        if self.purged_at is not None:
            require_aware(self.purged_at, "purged_at")
        if self.availability == "purged" and self.purged_at is None:
            raise ValueError("purged artifacts require purged_at")
        if self.availability != "purged" and self.purged_at is not None:
            raise ValueError("purged_at is only valid for purged artifacts")

    def as_dict(self) -> dict[str, object]:
        return {
            "artifact_id": self.artifact_id,
            "role": self.role,
            "content_type": self.content_type,
            "size_bytes": self.size_bytes,
            "digest": self.digest,
            "archive_ref": self.archive_ref,
            "created_at": _utc_iso(self.created_at),
            "availability": self.availability,
            "purged_at": _utc_iso(self.purged_at) if self.purged_at else None,
        }


@dataclass(frozen=True, slots=True)
class EvidenceCaptureManifest:
    """Lifecycle and integrity manifest for one private evidence capture.

    The manifest can describe raw payloads, screenshots and archival formats
    without prescribing a capture provider, storage backend or retention job.
    """

    capture_id: str
    source_url: str
    status: str
    provider: str
    requested_at: datetime
    retention_class: str
    artifacts: tuple[EvidenceCaptureArtifact, ...] = ()
    final_url: str = ""
    completed_at: datetime | None = None
    http_status: int | None = None
    response_headers: tuple[tuple[str, str], ...] = field(default_factory=tuple)
    retention_until: datetime | None = None
    legal_hold: bool = False
    error_code: str = ""
    schema_version: str = EVIDENCE_MANIFEST_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.schema_version != EVIDENCE_MANIFEST_SCHEMA_VERSION:
            raise ValueError(f"schema_version must be {EVIDENCE_MANIFEST_SCHEMA_VERSION}")
        require_identifier(self.capture_id, "capture_id")
        object.__setattr__(self, "source_url", normalize_evidence_url(self.source_url))
        require_one_of(self.status, CAPTURE_STATUSES, "status")
        object.__setattr__(self, "provider", require_identifier(self.provider, "provider"))
        require_aware(self.requested_at, "requested_at")
        object.__setattr__(self, "retention_class", require_text(self.retention_class, "retention_class"))
        if self.final_url:
            object.__setattr__(self, "final_url", normalize_evidence_url(self.final_url))
        if self.completed_at is not None:
            require_aware(self.completed_at, "completed_at")
            if self.completed_at < self.requested_at:
                raise ValueError("completed_at must not precede requested_at")
        if self.retention_until is not None:
            require_aware(self.retention_until, "retention_until")
        if self.legal_hold and self.retention_until is not None:
            raise ValueError("legal hold captures must not have retention_until")
        if any(not isinstance(artifact, EvidenceCaptureArtifact) for artifact in self.artifacts):
            raise ValueError("artifacts must contain EvidenceCaptureArtifact values")
        artifact_ids = [artifact.artifact_id for artifact in self.artifacts]
        if len(artifact_ids) != len(set(artifact_ids)):
            raise ValueError("artifacts must not contain duplicate artifact_id values")
        if len(dict(self.response_headers)) != len(self.response_headers):
            raise ValueError("response_headers must not contain duplicate keys")
        if any(key not in DEFAULT_RESPONSE_HEADERS for key, _value in self.response_headers):
            raise ValueError("response_headers contains a non-allowlisted key")
        if any(len(value) > 1000 for _key, value in self.response_headers):
            raise ValueError("response_headers contains an oversized value")

        if self.status == "pending":
            if any((self.artifacts, self.final_url, self.completed_at, self.http_status, self.error_code)):
                raise ValueError("pending manifest must not include terminal metadata")
        elif self.status == "completed":
            if self.completed_at is None or self.http_status != 200 or not self.artifacts:
                raise ValueError("completed manifest requires completed_at, HTTP 200 and artifacts")
            if self.error_code:
                raise ValueError("completed manifest must not include error_code")
        else:
            if self.completed_at is None or not self.error_code:
                raise ValueError("failed manifest requires completed_at and error_code")
            if self.artifacts:
                raise ValueError("failed manifest must not expose completed artifacts")

    @classmethod
    def from_record(cls, record: EvidenceCaptureRecord) -> EvidenceCaptureManifest:
        """Upgrade the original single-artifact record without losing provenance."""
        if not isinstance(record, EvidenceCaptureRecord):
            raise ValueError("record must be EvidenceCaptureRecord")
        artifacts: tuple[EvidenceCaptureArtifact, ...] = ()
        completed_at = None
        if record.status == "completed":
            completed_at = record.captured_at
            artifacts = (
                EvidenceCaptureArtifact(
                    artifact_id=f"{record.capture_id}:payload",
                    role="payload",
                    content_type=record.content_type,
                    size_bytes=record.size_bytes,
                    digest=record.digest,
                    archive_ref=record.archive_ref,
                    created_at=record.captured_at,
                ),
            )
        elif record.status == "failed":
            completed_at = record.captured_at
        return cls(
            capture_id=record.capture_id,
            source_url=record.source_url,
            status=record.status,
            provider=record.provider,
            requested_at=record.captured_at,
            retention_class=record.retention_class,
            artifacts=artifacts,
            final_url=record.final_url,
            completed_at=completed_at,
            http_status=record.http_status,
            response_headers=record.response_headers,
            error_code=record.error_code,
        )

    def as_dict(self) -> dict[str, object]:
        """Return a JSON-compatible manifest suitable for a private bus."""
        return {
            "schema_version": self.schema_version,
            "capture_id": self.capture_id,
            "source_url": self.source_url,
            "status": self.status,
            "provider": self.provider,
            "requested_at": _utc_iso(self.requested_at),
            "retention_class": self.retention_class,
            "artifacts": [artifact.as_dict() for artifact in self.artifacts],
            "final_url": self.final_url or None,
            "completed_at": _utc_iso(self.completed_at) if self.completed_at else None,
            "http_status": self.http_status,
            "response_headers": dict(self.response_headers),
            "retention_until": _utc_iso(self.retention_until) if self.retention_until else None,
            "legal_hold": self.legal_hold,
            "error_code": self.error_code or None,
        }
