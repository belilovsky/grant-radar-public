"""Public-safe evidence-state projection shared by knowledge products."""

from __future__ import annotations

from collections import Counter
from collections.abc import Iterable
from enum import StrEnum
from urllib.parse import urlparse


class EvidenceState(StrEnum):
    VERIFIED = "verified"
    SOURCED = "sourced"
    ARCHIVAL = "archival"
    COMPILED = "compiled"
    UNLINKED = "unlinked"


DECLARED_NON_VERIFIED_STATES = frozenset({EvidenceState.ARCHIVAL, EvidenceState.COMPILED})


def is_http_source_url(value: object) -> bool:
    """Return whether a value is an absolute HTTP(S) source URL."""
    parsed = urlparse(str(value or "").strip())
    return parsed.scheme.lower() in {"http", "https"} and bool(parsed.netloc)


def resolve_public_evidence_state(
    *,
    direct_source_url: object = "",
    reviewed_source_urls: Iterable[object] = (),
    declared_state: str | EvidenceState | None = None,
) -> EvidenceState:
    """Project provenance without elevating a plain link to reviewed evidence."""
    if any(is_http_source_url(url) for url in reviewed_source_urls):
        return EvidenceState.VERIFIED
    if declared_state:
        try:
            declared = EvidenceState(str(declared_state))
        except ValueError:
            declared = None
        if declared in DECLARED_NON_VERIFIED_STATES:
            return declared
    if is_http_source_url(direct_source_url):
        return EvidenceState.SOURCED
    return EvidenceState.UNLINKED


def count_evidence_states(states: Iterable[str | EvidenceState | None]) -> dict[str, int]:
    """Return stable public counters, including zero values for every state."""
    counts = Counter(
        state.value if isinstance(state, EvidenceState) else str(state or EvidenceState.UNLINKED) for state in states
    )
    return {state.value: counts[state.value] for state in EvidenceState}
