"""Explainable matching signals for finding previously checked claims."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Iterable

from qazstack.contracts._validation import require_ratio
from qazstack.factcheck.numbers import extract_numeric_mentions, numeric_similarity

_TOKEN_RE = re.compile(r"[0-9a-zа-яәғқңөұүһіё]+", re.IGNORECASE)
_KAZAKH_FOLDS = str.maketrans(
    {"ә": "а", "ғ": "г", "қ": "к", "ң": "н", "ө": "о", "ұ": "у", "ү": "у", "һ": "х", "і": "и", "ё": "е"}
)
_STOPWORDS = frozenset(
    {
        "and",
        "for",
        "the",
        "with",
        "без",
        "бұл",
        "для",
        "его",
        "как",
        "мен",
        "она",
        "они",
        "при",
        "что",
        "это",
        "және",
        "туралы",
    }
)


@dataclass(frozen=True, slots=True)
class ClaimMatchWeights:
    lexical: float = 0.45
    entities: float = 0.25
    numbers: float = 0.15
    embedding: float = 0.15

    def __post_init__(self) -> None:
        values = (self.lexical, self.entities, self.numbers, self.embedding)
        if any(value < 0 for value in values) or sum(values) <= 0:
            raise ValueError("match weights must be non-negative with a positive total")


@dataclass(frozen=True, slots=True)
class ClaimMatchResult:
    score: float
    lexical_score: float
    entity_score: float | None
    number_score: float | None
    embedding_score: float | None
    reasons: tuple[str, ...]


def _tokens(value: str) -> set[str]:
    normalized = value.lower().translate(_KAZAKH_FOLDS)
    return {
        token
        for token in _TOKEN_RE.findall(normalized)
        if len(token) >= 3 and token not in _STOPWORDS and not token.isdigit()
    }


def _normalized_values(values: Iterable[str]) -> set[str]:
    return {value.strip().lower().translate(_KAZAKH_FOLDS) for value in values if value.strip()}


def _jaccard(left: set[str], right: set[str]) -> float:
    union = left | right
    return len(left & right) / len(union) if union else 0.0


def score_claim_match(
    query: str,
    candidate: str,
    *,
    query_entities: Iterable[str] = (),
    candidate_entities: Iterable[str] = (),
    embedding_similarity: float | None = None,
    weights: ClaimMatchWeights | None = None,
) -> ClaimMatchResult:
    """Combine transparent lexical, entity, numeric and optional vector signals."""
    active_weights = weights or ClaimMatchWeights()
    lexical_score = _jaccard(_tokens(query), _tokens(candidate))

    query_entity_set = _normalized_values(query_entities)
    entity_score = _jaccard(query_entity_set, _normalized_values(candidate_entities)) if query_entity_set else None
    query_numbers = extract_numeric_mentions(query)
    candidate_numbers = extract_numeric_mentions(candidate)
    number_score = numeric_similarity(query, candidate)
    if embedding_similarity is not None:
        require_ratio(embedding_similarity, "embedding_similarity")

    signals = [
        (lexical_score, active_weights.lexical),
        (entity_score, active_weights.entities),
        (number_score, active_weights.numbers),
        (embedding_similarity, active_weights.embedding),
    ]
    denominator = sum(weight for value, weight in signals if value is not None and weight > 0)
    score = (
        sum(float(value) * weight for value, weight in signals if value is not None) / denominator
        if denominator
        else 0.0
    )

    reasons: list[str] = []
    if lexical_score >= 0.5:
        reasons.append("lexical-overlap")
    if entity_score is not None and entity_score > 0:
        reasons.append("entity-overlap")
    if number_score is not None and number_score > 0:
        reasons.append("number-overlap")
    if query_numbers and candidate_numbers and number_score == 0:
        reasons.append("number-conflict")
    if embedding_similarity is not None and embedding_similarity >= 0.75:
        reasons.append("semantic-similarity")
    return ClaimMatchResult(
        score=round(score, 6),
        lexical_score=round(lexical_score, 6),
        entity_score=None if entity_score is None else round(entity_score, 6),
        number_score=None if number_score is None else round(number_score, 6),
        embedding_score=embedding_similarity,
        reasons=tuple(reasons),
    )
