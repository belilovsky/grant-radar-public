"""Context-aware numeric signals for claim retrieval.

The helpers expose comparable mentions instead of deciding whether two claims
are equivalent. Products still own thresholds and editorial review.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation

_NUMBER_RE = re.compile(r"(?<![\w])[-+]?(?:\d{1,3}(?:[\s\u00a0\u202f]\d{3})+|\d+)(?:[.,]\d+)?(?![\w])")
_DATE_RE = re.compile(
    r"(?<!\d)(?:(?P<year>\d{4})[-/.](?P<month>\d{1,2})[-/.](?P<day>\d{1,2})|"
    r"(?P<day_alt>\d{1,2})[-/.](?P<month_alt>\d{1,2})[-/.](?P<year_alt>\d{4}))(?!\d)"
)
_PERCENT_RE = re.compile(r"%|процент\w*|пайыз\w*|percent\w*", re.IGNORECASE)
_YEAR_RE = re.compile(
    r"(?:\bгод(?:а|у|ом)?\b|\bг\.|\bжыл\w*\b|\byear\w*\b)",
    re.IGNORECASE,
)
_SCALES = (
    (re.compile(r"\b(?:млрд|миллиард\w*|billion\w*)\b", re.IGNORECASE), Decimal("1000000000")),
    (re.compile(r"\b(?:млн|миллион\w*|million\w*)\b", re.IGNORECASE), Decimal("1000000")),
    (re.compile(r"\b(?:тыс\.?|тысяч\w*|мың\w*|thousand\w*)\b", re.IGNORECASE), Decimal("1000")),
)
_CURRENCIES = (
    (re.compile(r"(?:₸|\b(?:kzt|тенге|теңге)\b)", re.IGNORECASE), "KZT"),
    (re.compile(r"(?:\$|\b(?:usd|доллар\w*)\b)", re.IGNORECASE), "USD"),
    (re.compile(r"(?:€|\b(?:eur|евро)\b)", re.IGNORECASE), "EUR"),
    (re.compile(r"(?:₽|\b(?:rub|руб(?:ль|ля|лей|\.)?)\b)", re.IGNORECASE), "RUB"),
)


@dataclass(frozen=True, slots=True, order=True)
class NumericMention:
    """One normalized numeric mention with a minimal semantic type."""

    kind: str
    value: str
    unit: str = ""

    @property
    def key(self) -> str:
        return f"{self.kind}:{self.unit}:{self.value}"


def _decimal(raw: str) -> Decimal | None:
    compact = re.sub(r"[\s\u00a0\u202f]", "", raw).replace(",", ".")
    try:
        return Decimal(compact)
    except InvalidOperation:
        return None


def _canonical_decimal(value: Decimal) -> str:
    rendered = format(value, "f")
    if "." in rendered:
        rendered = rendered.rstrip("0").rstrip(".")
    return "0" if rendered in {"-0", "+0", ""} else rendered


def _date_mentions(value: str) -> tuple[list[NumericMention], list[tuple[int, int]]]:
    mentions: list[NumericMention] = []
    spans: list[tuple[int, int]] = []
    for match in _DATE_RE.finditer(value):
        year = int(match.group("year") or match.group("year_alt"))
        month = int(match.group("month") or match.group("month_alt"))
        day = int(match.group("day") or match.group("day_alt"))
        if not (1900 <= year <= 2100 and 1 <= month <= 12 and 1 <= day <= 31):
            continue
        mentions.append(NumericMention("date", f"{year:04d}-{month:02d}-{day:02d}"))
        spans.append(match.span())
    return mentions, spans


def _overlaps(span: tuple[int, int], excluded: list[tuple[int, int]]) -> bool:
    return any(span[0] < item[1] and item[0] < span[1] for item in excluded)


def extract_numeric_mentions(value: str) -> tuple[NumericMention, ...]:
    """Extract dependency-free RU/KK/EN numeric mentions.

    Decimal separators, grouped thousands, common scales, percentages,
    currencies, years and numeric dates are normalized. Unrecognised numbers
    remain plain mentions so no evidence is invented from surrounding text.
    """
    mentions, excluded_spans = _date_mentions(value)
    for match in _NUMBER_RE.finditer(value):
        if _overlaps(match.span(), excluded_spans):
            continue
        number = _decimal(match.group(0))
        if number is None:
            continue

        before = value[max(0, match.start() - 12) : match.start()]
        after = value[match.end() : min(len(value), match.end() + 32)]
        next_number = _NUMBER_RE.search(after)
        if next_number:
            after = after[: next_number.start()]
        context = f"{before[-6:]} {after}"
        scale = Decimal(1)
        for pattern, multiplier in _SCALES:
            if pattern.search(after):
                scale = multiplier
                break

        currency = next(
            (code for pattern, code in _CURRENCIES if pattern.search(context)),
            "",
        )
        if _PERCENT_RE.search(after):
            mentions.append(NumericMention("percent", _canonical_decimal(number), "%"))
        elif currency:
            mentions.append(NumericMention("currency", _canonical_decimal(number * scale), currency))
        elif (
            scale == 1
            and number == number.to_integral_value()
            and Decimal(1900) <= number <= Decimal(2100)
            and _YEAR_RE.search(after)
        ):
            mentions.append(NumericMention("year", _canonical_decimal(number)))
        else:
            mentions.append(NumericMention("number", _canonical_decimal(number * scale)))
    return tuple(sorted(set(mentions)))


def numeric_similarity(left: str, right: str) -> float | None:
    """Return Jaccard similarity for context-aware numeric mentions."""
    left_keys = {item.key for item in extract_numeric_mentions(left)}
    if not left_keys:
        return None
    right_keys = {item.key for item in extract_numeric_mentions(right)}
    union = left_keys | right_keys
    return len(left_keys & right_keys) / len(union) if union else 0.0


def numeric_relation(left: str, right: str) -> str:
    """Classify numeric evidence without interpreting the claim itself."""
    left_keys = {item.key for item in extract_numeric_mentions(left)}
    right_keys = {item.key for item in extract_numeric_mentions(right)}
    if not left_keys or not right_keys:
        return "not_observed"
    if left_keys == right_keys:
        return "overlap"
    if left_keys & right_keys:
        return "partial_conflict"
    return "conflict"
