"""Retry with exponential backoff and jitter.

Consolidated from: qazposter/adapters/resilience.py, pssr-regime-engine/aggregator.py

Usage::

    from qazstack.resilience import retry_with_backoff

    result = await retry_with_backoff(fetch_data, url, max_retries=3)

    # With circuit breaker:
    from qazstack.resilience import retry_with_backoff, get_breaker

    breaker = get_breaker("api")
    result = await retry_with_backoff(
        fetch_data, url,
        max_retries=3,
        circuit_breaker=breaker,
    )
"""

from __future__ import annotations

import asyncio
import logging
import random
from typing import Any, Callable

import httpx

from qazstack.resilience.breaker import CircuitBreaker, CircuitOpenError

logger = logging.getLogger("qazstack.resilience")

# Default retryable exceptions
DEFAULT_RETRYABLE = (
    httpx.TransportError,
    httpx.TimeoutException,
    ConnectionError,
    TimeoutError,
    OSError,
)


async def retry_with_backoff(
    func: Callable,
    *args: Any,
    max_retries: int = 3,
    base_delay: float = 1.0,
    max_delay: float = 30.0,
    retryable_exceptions: tuple = DEFAULT_RETRYABLE,
    circuit_breaker: CircuitBreaker | None = None,
    on_retry: Callable | None = None,
    **kwargs: Any,
) -> Any:
    """Execute async func with exponential backoff retry.

    Args:
        func: Async callable to execute.
        max_retries: Maximum number of retry attempts.
        base_delay: Initial delay in seconds.
        max_delay: Maximum delay cap in seconds.
        retryable_exceptions: Tuple of exception types to retry on.
        circuit_breaker: Optional CircuitBreaker instance.
        on_retry: Optional callback(attempt, exception) called before each retry.

    Returns:
        Result of func.

    Raises:
        CircuitOpenError: If circuit breaker is open.
        Last exception if all retries exhausted.
    """
    last_exc: Exception | None = None

    for attempt in range(max_retries + 1):
        # Check circuit breaker
        if circuit_breaker and not circuit_breaker.allow_request:
            raise CircuitOpenError(circuit_breaker.name, circuit_breaker.time_until_recovery)

        try:
            result = await func(*args, **kwargs)
            if circuit_breaker:
                circuit_breaker.record_success()
            return result

        except retryable_exceptions as exc:
            last_exc = exc
            if circuit_breaker:
                circuit_breaker.record_failure()

            if attempt == max_retries:
                break

            # Exponential backoff with jitter
            delay = min(base_delay * (2**attempt), max_delay)
            delay = delay * (0.5 + random.random() * 0.5)

            if on_retry:
                try:
                    on_retry(attempt + 1, exc)
                except Exception:
                    pass

            logger.warning(
                "Retry %d/%d after %.1fs: %s",
                attempt + 1,
                max_retries,
                delay,
                exc,
            )
            await asyncio.sleep(delay)

    raise last_exc  # type: ignore[misc]
