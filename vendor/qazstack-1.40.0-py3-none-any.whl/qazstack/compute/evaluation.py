"""Provider-neutral retrieval evaluation primitives."""

from __future__ import annotations

import math
from collections.abc import Callable, Iterable, Mapping, Sequence
from dataclasses import dataclass
from typing import TypeVar

from qazstack.contracts._validation import require_identifier, require_positive

T = TypeVar("T")


def discounted_cumulative_gain(grades: Sequence[float], *, cutoff: int | None = None) -> float:
    """Return DCG with exponential gain for non-negative graded judgements."""

    if cutoff is not None and cutoff < 1:
        raise ValueError("cutoff must be positive")
    selected = grades if cutoff is None else grades[:cutoff]
    total = 0.0
    for index, grade in enumerate(selected):
        normalized = float(grade)
        if not math.isfinite(normalized) or normalized < 0:
            raise ValueError("grades must be finite and non-negative")
        total += (2**normalized - 1) / math.log2(index + 2)
    return total


def normalized_discounted_cumulative_gain(grades: Sequence[float], *, cutoff: int) -> float:
    """Return nDCG@K, failing closed to zero when no relevant item exists."""

    if cutoff < 1:
        raise ValueError("cutoff must be positive")
    normalized = tuple(float(grade) for grade in grades)
    ideal = discounted_cumulative_gain(sorted(normalized, reverse=True), cutoff=cutoff)
    if ideal == 0:
        return 0.0
    return discounted_cumulative_gain(normalized, cutoff=cutoff) / ideal


@dataclass(frozen=True, slots=True)
class RetrievalMetrics:
    total: int
    found: int
    mean_reciprocal_rank: float
    hit_rate_at: tuple[tuple[int, float], ...]

    @property
    def hit_rate(self) -> float:
        return self.found / self.total if self.total else 0.0

    def as_dict(self) -> dict[str, object]:
        return {
            "total": self.total,
            "found": self.found,
            "hit_rate": round(self.hit_rate, 4),
            "mrr": round(self.mean_reciprocal_rank, 4),
            "hit_rate_at": {str(k): round(value, 4) for k, value in self.hit_rate_at},
        }


def first_relevant_rank(items: Iterable[T], is_relevant: Callable[[T], bool]) -> int | None:
    """Return the one-based rank of the first relevant item."""
    for rank, item in enumerate(items, 1):
        if is_relevant(item):
            return rank
    return None


def retrieval_metrics(
    ranks: Sequence[int | None],
    *,
    cutoffs: Sequence[int] = (1, 3, 5),
) -> RetrievalMetrics:
    """Aggregate MRR and Hit@K from one-based relevant ranks."""
    if any(rank is not None and rank < 1 for rank in ranks):
        raise ValueError("ranks must be positive or None")
    normalized_cutoffs = tuple(dict.fromkeys(cutoffs))
    if any(cutoff < 1 for cutoff in normalized_cutoffs):
        raise ValueError("cutoffs must be positive")
    total = len(ranks)
    found = sum(rank is not None for rank in ranks)
    mrr = sum(1.0 / rank for rank in ranks if rank is not None) / total if total else 0.0
    hit_rate_at = tuple(
        (
            cutoff,
            sum(rank is not None and rank <= cutoff for rank in ranks) / total if total else 0.0,
        )
        for cutoff in normalized_cutoffs
    )
    return RetrievalMetrics(total, found, mrr, hit_rate_at)


def percentile(values: Sequence[float], fraction: float) -> float:
    """Return the nearest-rank value used by lightweight latency gates."""
    if not 0 <= fraction <= 1:
        raise ValueError("fraction must be between zero and one")
    if not values:
        return 0.0
    ordered = sorted(values)
    index = min(len(ordered) - 1, max(0, round((len(ordered) - 1) * fraction)))
    return ordered[index]


@dataclass(frozen=True, slots=True)
class MetricGate:
    """Release threshold for one named metric and optional baseline comparison."""

    metric: str
    direction: str
    threshold: float
    max_regression: float = 0.0

    def __post_init__(self) -> None:
        require_identifier(self.metric, "metric")
        if self.direction not in {"higher-better", "lower-better"}:
            raise ValueError("direction must be higher-better or lower-better")
        require_positive(self.max_regression, "max_regression", allow_zero=True)

    def passes(self, value: float, baseline: float | None = None) -> bool:
        if self.direction == "higher-better":
            threshold_pass = value >= self.threshold
            regression_pass = baseline is None or value >= baseline - self.max_regression
        else:
            threshold_pass = value <= self.threshold
            regression_pass = baseline is None or value <= baseline + self.max_regression
        return threshold_pass and regression_pass


@dataclass(frozen=True, slots=True)
class EvaluationTrack:
    """Required corpus slices and gates for one provider-neutral model task."""

    track_id: str
    minimum_cases: int
    required_languages: tuple[str, ...]
    required_domains: tuple[str, ...]
    metric_gates: tuple[MetricGate, ...]
    latency_budget_ms: float | None = None

    def __post_init__(self) -> None:
        require_identifier(self.track_id, "track_id")
        require_positive(self.minimum_cases, "minimum_cases")
        if not self.required_languages or not self.required_domains or not self.metric_gates:
            raise ValueError("evaluation track requires languages, domains and metric gates")
        for field_name, values in (
            ("required_languages", self.required_languages),
            ("required_domains", self.required_domains),
        ):
            if len(values) != len(set(values)):
                raise ValueError(f"{field_name} must not contain duplicates")
            for value in values:
                require_identifier(value, field_name)
        metric_names = tuple(gate.metric for gate in self.metric_gates)
        if len(metric_names) != len(set(metric_names)):
            raise ValueError("metric_gates must not contain duplicates")
        if self.latency_budget_ms is not None:
            require_positive(self.latency_budget_ms, "latency_budget_ms")


@dataclass(frozen=True, slots=True)
class EvaluationSlice:
    """Aggregate-only result for one language and domain slice."""

    track_id: str
    language: str
    domain: str
    case_count: int
    metrics: tuple[tuple[str, float], ...]
    baseline_metrics: tuple[tuple[str, float], ...] = ()
    p95_latency_ms: float | None = None

    def __post_init__(self) -> None:
        require_identifier(self.track_id, "track_id")
        require_identifier(self.language, "language")
        require_identifier(self.domain, "domain")
        require_positive(self.case_count, "case_count")
        if not self.metrics or len(self.metrics) != len(dict(self.metrics)):
            raise ValueError("metrics must have unique names and may not be empty")
        if len(self.baseline_metrics) != len(dict(self.baseline_metrics)):
            raise ValueError("baseline_metrics must have unique names")
        for metric, _value in (*self.metrics, *self.baseline_metrics):
            require_identifier(metric, "metric")
        if self.p95_latency_ms is not None:
            require_positive(self.p95_latency_ms, "p95_latency_ms")


@dataclass(frozen=True, slots=True)
class EvaluationReleaseDecision:
    release: bool
    findings: tuple[str, ...]


def evaluate_release_candidate(
    track: EvaluationTrack,
    slices: Sequence[EvaluationSlice],
) -> EvaluationReleaseDecision:
    """Fail closed when required corpus coverage, metrics or latency are missing."""
    findings: list[str] = []
    selected = tuple(item for item in slices if item.track_id == track.track_id)
    if sum(item.case_count for item in selected) < track.minimum_cases:
        findings.append("minimum-corpus-size-not-met")
    observed_languages = {item.language for item in selected}
    observed_domains = {item.domain for item in selected}
    findings.extend(
        f"language-slice-missing:{language}"
        for language in track.required_languages
        if language not in observed_languages
    )
    findings.extend(
        f"domain-slice-missing:{domain}" for domain in track.required_domains if domain not in observed_domains
    )
    for item in selected:
        values: Mapping[str, float] = dict(item.metrics)
        baselines: Mapping[str, float] = dict(item.baseline_metrics)
        for gate in track.metric_gates:
            if gate.metric not in values:
                findings.append(f"metric-missing:{item.language}:{item.domain}:{gate.metric}")
            elif not gate.passes(values[gate.metric], baselines.get(gate.metric)):
                findings.append(f"metric-gate-failed:{item.language}:{item.domain}:{gate.metric}")
        if track.latency_budget_ms is not None:
            if item.p95_latency_ms is None:
                findings.append(f"latency-missing:{item.language}:{item.domain}")
            elif item.p95_latency_ms > track.latency_budget_ms:
                findings.append(f"latency-budget-exceeded:{item.language}:{item.domain}")
    return EvaluationReleaseDecision(not findings, tuple(findings))


__all__ = [
    "EvaluationReleaseDecision",
    "EvaluationSlice",
    "EvaluationTrack",
    "MetricGate",
    "RetrievalMetrics",
    "discounted_cumulative_gain",
    "evaluate_release_candidate",
    "first_relevant_rank",
    "normalized_discounted_cumulative_gain",
    "percentile",
    "retrieval_metrics",
]
