"""Provider-neutral ranking composition and fusion primitives."""

from __future__ import annotations

import math
from collections.abc import Mapping, Sequence
from dataclasses import dataclass

from qazstack.contracts._validation import require_identifier, require_positive

RANK_TRACE_SCHEMA_VERSION = "qazstack-rank-trace-v1"


def _unit_interval(value: float, field_name: str) -> float:
    normalized = float(value)
    if not math.isfinite(normalized) or not 0.0 <= normalized <= 1.0:
        raise ValueError(f"{field_name} must be finite and between zero and one")
    return normalized


@dataclass(frozen=True, slots=True)
class WeightedRankSignal:
    """One normalized, explainable input to a product-owned ranker."""

    name: str
    value: float
    weight: float
    evidence: str | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "name", require_identifier(self.name, "name"))
        object.__setattr__(self, "value", _unit_interval(self.value, "value"))
        require_positive(self.weight, "weight", allow_zero=True)


@dataclass(frozen=True, slots=True)
class RankTrace:
    """Versioned score explanation without product-specific policy."""

    score: float
    signals: tuple[WeightedRankSignal, ...]
    contract: str
    schema_version: str = RANK_TRACE_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.schema_version != RANK_TRACE_SCHEMA_VERSION:
            raise ValueError(f"schema_version must be {RANK_TRACE_SCHEMA_VERSION}")
        object.__setattr__(self, "contract", require_identifier(self.contract, "contract"))
        object.__setattr__(self, "score", _unit_interval(self.score, "score"))
        if not self.signals:
            raise ValueError("signals may not be empty")
        names = tuple(signal.name for signal in self.signals)
        if len(names) != len(set(names)):
            raise ValueError("signals must have unique names")

    def as_dict(self) -> dict[str, object]:
        return {
            "schema_version": self.schema_version,
            "contract": self.contract,
            "score": round(self.score, 6),
            "signals": [
                {
                    "name": signal.name,
                    "value": round(signal.value, 6),
                    "weight": round(signal.weight, 6),
                    "evidence": signal.evidence,
                }
                for signal in self.signals
            ],
        }


def combine_rank_signals(
    signals: Sequence[WeightedRankSignal],
    *,
    contract: str,
) -> RankTrace:
    """Return a normalized weighted score and its complete input trace."""

    normalized = tuple(signals)
    total_weight = sum(signal.weight for signal in normalized)
    if not normalized or total_weight <= 0:
        raise ValueError("at least one positive-weight signal is required")
    score = sum(signal.value * signal.weight for signal in normalized) / total_weight
    return RankTrace(score=score, signals=normalized, contract=contract)


def reciprocal_rank_score(rank: int, *, rank_constant: int = 60) -> float:
    """Return an RRF contribution normalized so rank one scores 1.0."""

    require_positive(rank, "rank")
    require_positive(rank_constant, "rank_constant")
    return (rank_constant + 1) / (rank_constant + rank)


@dataclass(frozen=True, slots=True)
class FusedRankResult:
    item_id: str
    score: float
    ranks: tuple[tuple[str, int], ...]


def reciprocal_rank_fusion(
    rankings: Mapping[str, Sequence[str]],
    *,
    rank_constant: int = 60,
    provider_weights: Mapping[str, float] | None = None,
) -> tuple[FusedRankResult, ...]:
    """Fuse provider rankings deterministically while retaining provider ranks."""

    require_positive(rank_constant, "rank_constant")
    weights = provider_weights or {}
    scores: dict[str, float] = {}
    observed: dict[str, list[tuple[str, int]]] = {}
    first_seen: dict[str, int] = {}
    sequence = 0
    for provider, item_ids in rankings.items():
        provider_id = require_identifier(provider, "provider")
        weight = float(weights.get(provider, 1.0))
        if not math.isfinite(weight) or weight < 0:
            raise ValueError("provider weights must be finite and non-negative")
        seen: set[str] = set()
        for rank, item_id in enumerate(item_ids, 1):
            normalized_id = require_identifier(item_id, "item_id")
            if normalized_id in seen:
                raise ValueError(f"ranking for {provider_id} contains duplicate item ids")
            seen.add(normalized_id)
            if normalized_id not in first_seen:
                first_seen[normalized_id] = sequence
                sequence += 1
            scores[normalized_id] = scores.get(normalized_id, 0.0) + weight / (rank_constant + rank)
            observed.setdefault(normalized_id, []).append((provider_id, rank))
    fused = (FusedRankResult(item_id, score, tuple(observed[item_id])) for item_id, score in scores.items())
    return tuple(sorted(fused, key=lambda item: (-item.score, first_seen[item.item_id], item.item_id)))


__all__ = [
    "FusedRankResult",
    "RANK_TRACE_SCHEMA_VERSION",
    "RankTrace",
    "WeightedRankSignal",
    "combine_rank_signals",
    "reciprocal_rank_fusion",
    "reciprocal_rank_score",
]
