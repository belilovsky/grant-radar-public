"""HTTP client for QazCompute – centralized NLP/ML inference service.

Features:
    - Automatic retry with exponential backoff (3 attempts)
    - Circuit breaker: fast-fail when service is down
    - Request ID propagation for distributed tracing

Usage::

    from qazstack.compute import ComputeClient, ComputeError, CircuitOpenError

    client = ComputeClient()  # reads QAZCOMPUTE_URL, QAZCOMPUTE_API_KEY from env

    # Sentiment
    results = await client.sentiment(["Президент одобрил бюджет"])

    # NER
    entities = await client.ner(["Токаев встретился с Путиным в Астане"])

    # Embeddings
    vectors = await client.embeddings(["text"], prefix="query")

    # Similarity candidates (decisions remain product-owned)
    candidates = await client.corpus_similarity([
        {"id": "a", "vector": [1.0, 0.0]},
        {"id": "b", "vector": [0.99, 0.1]},
    ])

    # Translation (kk/ru/en/tr)
    translated = await client.translate(["Сәлем"], src_lang="kaz_Cyrl", tgt_lang="rus_Cyrl")

    # Morphology
    morph = await client.morphology(["Президент одобрил бюджет"], mode="morph")

    # KazBERT embeddings
    kz_vectors = await client.kazbert_embeddings(["Қазақстан"])

    # Combined pipeline
    result = await client.process(["text"], tasks=["sentiment", "ner", "language"])

    # Speech-to-text (Whisper)
    stt = await client.transcribe(audio_b64="...", language="ru")

    # Text-to-speech (Silero – Russian/English)
    tts = await client.synthesize(["Привет мир"], language="ru", speaker="xenia")

    # High-quality TTS (Kokoro – multilingual)
    kokoro = await client.kokoro_tts(["Hello world"], voice="af_heart", lang_code="a")

    # Image generation (SDXL Turbo)
    img = await client.generate_image("A sunset over the steppe", num_steps=1)

    # Vision: OCR, face detection, image/text embeddings
    ocr_result = await client.ocr([image_b64])
    faces = await client.detect_faces([image_b64], return_embeddings=True)
    img_vectors = await client.embed_images([image_b64])

    # Summarization
    summary = await client.summarize(["Long article text..."])

    # Stance detection
    stance = await client.stance([{"premise": "...", "hypothesis": "..."}])

    # Graceful degradation
    try:
        results = await client.sentiment(["text"])
    except CircuitOpenError:
        # Service is down, use fallback
        results = [{"text": "text", "label": "neutral", "score": 0.0}]
    except ComputeError:
        # Connection failed after retries
        results = [{"text": "text", "label": "neutral", "score": 0.0}]
"""

from qazstack.compute.artifacts import (
    ArtifactFile,
    ArtifactValidationError,
    VectorArtifactManifest,
    describe_artifact_file,
    load_vector_artifact_manifest,
    validate_vector_artifact,
    verify_artifact_files,
)
from qazstack.compute.client import CircuitOpenError, ComputeClient, ComputeError, SyncComputeClient
from qazstack.compute.contracts import (
    PROCESS_SCHEMA_VERSION,
    ComputeCapabilitiesSnapshot,
    ComputeCapabilityHealth,
    ComputeJobCapabilities,
    ComputeTaskExecution,
    input_text_digest,
    process_provenance,
    validate_process_provenance,
)
from qazstack.compute.embeddings import (
    EmbeddingsClient,
    LRUVectorCache,
    embed,
    embed_sync,
    get_default_embeddings_client,
    reset_default_embeddings_client,
)
from qazstack.compute.evaluation import (
    EvaluationReleaseDecision,
    EvaluationSlice,
    EvaluationTrack,
    MetricGate,
    RetrievalMetrics,
    discounted_cumulative_gain,
    evaluate_release_candidate,
    first_relevant_rank,
    normalized_discounted_cumulative_gain,
    percentile,
    retrieval_metrics,
)
from qazstack.compute.executor import run_cpu_bound
from qazstack.compute.pedigree import PEDIGREE_ANALYTICS_CONTRACT, PedigreeAnalyticsRequest, PedigreeNode
from qazstack.compute.providers import (
    DEFAULT_DEEPSEEK_CHAT_COMPLETIONS_URL,
    DEFAULT_OPENAI_CHAT_COMPLETIONS_URL,
    TextLLMProvider,
    detect_text_llm_provider,
    normalize_chat_url,
    resolve_llm_api_url,
    resolve_llm_model,
    resolve_openai_base_url,
    resolve_text_llm_api_key,
    resolve_text_llm_candidates,
    text_llm_fallback_enabled,
)
from qazstack.compute.qazshield import QazShieldClient, QazShieldError, QazShieldUnavailable
from qazstack.compute.ranking import (
    RANK_TRACE_SCHEMA_VERSION,
    FusedRankResult,
    RankTrace,
    WeightedRankSignal,
    combine_rank_signals,
    reciprocal_rank_fusion,
    reciprocal_rank_score,
)
from qazstack.compute.retrieval import RetrievalHit, RetrievalQuery, rank_retrieval_hits
from qazstack.compute.routing import LLMRoute, LLMRouteError, LLMRouteRequest, LLMRouteResult, LLMUsage

__all__ = [
    "CircuitOpenError",
    "ComputeClient",
    "ComputeError",
    "SyncComputeClient",
    "QazShieldClient",
    "QazShieldError",
    "QazShieldUnavailable",
    "ComputeCapabilitiesSnapshot",
    "ComputeCapabilityHealth",
    "ComputeJobCapabilities",
    "ComputeTaskExecution",
    "PROCESS_SCHEMA_VERSION",
    "ArtifactFile",
    "ArtifactValidationError",
    "VectorArtifactManifest",
    "describe_artifact_file",
    "load_vector_artifact_manifest",
    "validate_vector_artifact",
    "verify_artifact_files",
    "input_text_digest",
    "process_provenance",
    "validate_process_provenance",
    "EmbeddingsClient",
    "LRUVectorCache",
    "DEFAULT_DEEPSEEK_CHAT_COMPLETIONS_URL",
    "DEFAULT_OPENAI_CHAT_COMPLETIONS_URL",
    "TextLLMProvider",
    "detect_text_llm_provider",
    "embed",
    "embed_sync",
    "get_default_embeddings_client",
    "normalize_chat_url",
    "resolve_llm_api_url",
    "resolve_llm_model",
    "resolve_openai_base_url",
    "resolve_text_llm_api_key",
    "resolve_text_llm_candidates",
    "reset_default_embeddings_client",
    "run_cpu_bound",
    "RetrievalMetrics",
    "discounted_cumulative_gain",
    "normalized_discounted_cumulative_gain",
    "MetricGate",
    "EvaluationTrack",
    "EvaluationSlice",
    "EvaluationReleaseDecision",
    "evaluate_release_candidate",
    "first_relevant_rank",
    "percentile",
    "retrieval_metrics",
    "RANK_TRACE_SCHEMA_VERSION",
    "FusedRankResult",
    "RankTrace",
    "WeightedRankSignal",
    "combine_rank_signals",
    "reciprocal_rank_fusion",
    "reciprocal_rank_score",
    "text_llm_fallback_enabled",
    "LLMRoute",
    "LLMRouteError",
    "LLMRouteRequest",
    "LLMRouteResult",
    "LLMUsage",
    "RetrievalHit",
    "RetrievalQuery",
    "rank_retrieval_hits",
    "PEDIGREE_ANALYTICS_CONTRACT",
    "PedigreeAnalyticsRequest",
    "PedigreeNode",
]
