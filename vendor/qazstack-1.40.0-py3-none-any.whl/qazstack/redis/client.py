"""GracefulRedis – Redis client that never crashes the app.

All operations silently return None/False when Redis is unavailable.
Automatically reconnects when Redis comes back.

Consolidated from: qazposter/redis_client.py
"""

from __future__ import annotations

import json
import logging
from typing import Any

logger = logging.getLogger("qazstack.redis")


class GracefulRedis:
    """Redis wrapper with graceful degradation.

    Args:
        url: Redis connection URL (e.g. "redis://redis:6379/0").

    Example::

        redis = GracefulRedis("redis://redis:6379")
        await redis.set("key", "value", ex=300)
        val = await redis.get("key")  # returns None if Redis is down
        print(redis.available)
    """

    def __init__(self, url: str):
        self._url = url
        self._redis = None
        self._available = False

    async def _get_conn(self):
        if self._redis is None:
            try:
                import redis.asyncio as aioredis

                self._redis = aioredis.from_url(self._url, decode_responses=True, socket_connect_timeout=2)
                await self._redis.ping()
                self._available = True
            except Exception as exc:
                logger.warning("Redis connection failed: %s", exc)
                self._redis = None
                self._available = False
                return None
        return self._redis

    def _handle_error(self, op: str, key: str, exc: Exception) -> None:
        logger.warning("Redis %s failed for %s: %s", op, key, exc)
        self._available = False
        self._redis = None

    @property
    def available(self) -> bool:
        return self._available

    # --- Core operations ---

    async def get(self, key: str) -> str | None:
        conn = await self._get_conn()
        if conn is None:
            return None
        try:
            return await conn.get(key)
        except Exception as exc:
            self._handle_error("GET", key, exc)
            return None

    async def set(self, key: str, value: str, ex: int | None = None) -> bool:
        conn = await self._get_conn()
        if conn is None:
            return False
        try:
            await conn.set(key, value, ex=ex)
            return True
        except Exception as exc:
            self._handle_error("SET", key, exc)
            return False

    async def delete(self, key: str) -> bool:
        conn = await self._get_conn()
        if conn is None:
            return False
        try:
            await conn.delete(key)
            return True
        except Exception as exc:
            self._handle_error("DELETE", key, exc)
            return False

    async def incr(self, key: str) -> int | None:
        conn = await self._get_conn()
        if conn is None:
            return None
        try:
            return await conn.incr(key)
        except Exception as exc:
            self._handle_error("INCR", key, exc)
            return None

    async def expire(self, key: str, seconds: int) -> bool:
        conn = await self._get_conn()
        if conn is None:
            return False
        try:
            await conn.expire(key, seconds)
            return True
        except Exception as exc:
            self._handle_error("EXPIRE", key, exc)
            return False

    async def setex(self, key: str, seconds: int, value: str) -> bool:
        conn = await self._get_conn()
        if conn is None:
            return False
        try:
            await conn.setex(key, seconds, value)
            return True
        except Exception as exc:
            self._handle_error("SETEX", key, exc)
            return False

    # --- JSON helpers ---

    async def get_json(self, key: str) -> Any | None:
        """Get and deserialize JSON value."""
        raw = await self.get(key)
        if raw is None:
            return None
        try:
            return json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            return None

    async def set_json(self, key: str, value: Any, ex: int | None = None) -> bool:
        """Serialize value as JSON and store."""
        try:
            raw = json.dumps(value, ensure_ascii=False, default=str)
        except (TypeError, ValueError):
            return False
        return await self.set(key, raw, ex=ex)

    # --- Health ---

    async def ping(self) -> bool:
        conn = await self._get_conn()
        if conn is None:
            return False
        try:
            await conn.ping()
            self._available = True
            return True
        except Exception:
            self._available = False
            self._redis = None
            return False

    async def close(self) -> None:
        if self._redis:
            try:
                await self._redis.aclose()
            except Exception:
                pass
            self._redis = None
            self._available = False
