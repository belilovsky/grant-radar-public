"""Collector Registry – register, discover, and manage collector types.

Supports both qazstack.monitor.collectors (BaseCollector protocol)
and custom collectors from project code.

Usage::

    registry = CollectorRegistry()
    registry.register(RSSCollector())
    registry.register(HTTPChecker())

    # List all registered types
    registry.types()  # → ["rss", "http"]

    # Get a specific collector
    rss = registry.get("rss")

    # Auto-register all built-in collectors
    registry = CollectorRegistry.with_builtins()
"""

from __future__ import annotations

import logging
from typing import Any

from qazstack.monitor.collectors.base import BaseCollector

logger = logging.getLogger("qazstack.collectors.registry")


class CollectorRegistry:
    """Registry of available collector types."""

    def __init__(self) -> None:
        self._collectors: dict[str, BaseCollector] = {}

    def register(self, collector: BaseCollector) -> None:
        """Register a collector instance.

        Uses ``collector.source_type`` as the key.
        Overwrites if a collector with the same source_type already exists.
        """
        key = collector.source_type
        if key in self._collectors:
            logger.info("Overwriting collector for type '%s'", key)
        self._collectors[key] = collector
        logger.debug("Registered collector: %s", key)

    def get(self, source_type: str) -> BaseCollector | None:
        """Get a collector by source type."""
        return self._collectors.get(source_type)

    def types(self) -> list[str]:
        """List all registered collector types."""
        return sorted(self._collectors.keys())

    def __contains__(self, source_type: str) -> bool:
        return source_type in self._collectors

    def __len__(self) -> int:
        return len(self._collectors)

    @classmethod
    def with_builtins(cls, **kwargs: Any) -> CollectorRegistry:
        """Create a registry pre-loaded with all built-in collectors.

        Silently skips collectors whose dependencies aren't installed.

        Kwargs are forwarded to individual collector constructors:
            http_timeout (float): Timeout for HTTPChecker (default 10).
        """
        registry = cls()

        # HTTP – always available (httpx is a core dependency)
        from qazstack.monitor.collectors.http import HTTPChecker

        registry.register(HTTPChecker(timeout=kwargs.get("http_timeout", 10.0)))

        # RSS – requires feedparser
        try:
            from qazstack.monitor.collectors.rss import RSSCollector

            registry.register(RSSCollector())
        except ImportError:
            logger.debug("RSSCollector not available (feedparser not installed)")

        # Telegram – requires httpx (available)
        try:
            from qazstack.monitor.collectors.telegram import TelegramAdapter

            registry.register(TelegramAdapter())
        except ImportError:
            logger.debug("TelegramAdapter not available")

        return registry

    async def health_check_all(self, configs: dict[str, dict]) -> dict[str, bool]:
        """Run health checks on all collectors with their configs.

        Args:
            configs: Dict of source_type → config dict.

        Returns:
            Dict of source_type → is_healthy.
        """
        results: dict[str, bool] = {}
        for source_type, collector in self._collectors.items():
            config = configs.get(source_type, {})
            try:
                results[source_type] = await collector.health_check(config)
            except Exception:
                results[source_type] = False
        return results
