"""Shared financial and economic data contracts.

``qazstack.finance`` intentionally contains no database or provider code. It
keeps identifiers, provenance and deterministic calculations identical across
QazPipe collectors, QazLake persistence and consuming products.
"""

from .calculations import annualized_volatility, fx_cross_rate, log_returns, max_drawdown, simple_returns
from .evaluation import ClassificationReport, LabelMetrics, classification_report
from .forecasting import BacktestResult, ForecastResult, rolling_origin_backtest, seasonal_naive_forecast
from .models import (
    AccessTier,
    FinancialSource,
    Frequency,
    Instrument,
    Observation,
    Quote,
    ResearchEvidence,
    SeriesDefinition,
    SeriesKind,
)
from .quality import FinanceQualityIssue, FinanceQualityReport, assess_observations

__all__ = [
    "AccessTier",
    "FinancialSource",
    "Frequency",
    "Instrument",
    "Observation",
    "Quote",
    "ResearchEvidence",
    "SeriesDefinition",
    "SeriesKind",
    "FinanceQualityIssue",
    "FinanceQualityReport",
    "assess_observations",
    "annualized_volatility",
    "fx_cross_rate",
    "log_returns",
    "max_drawdown",
    "simple_returns",
    "BacktestResult",
    "ClassificationReport",
    "ForecastResult",
    "LabelMetrics",
    "classification_report",
    "rolling_origin_backtest",
    "seasonal_naive_forecast",
]
