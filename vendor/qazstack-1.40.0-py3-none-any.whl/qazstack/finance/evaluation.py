"""Model-agnostic quality metrics for multilingual finance NLP benchmarks."""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class LabelMetrics:
    precision: float
    recall: float
    f1: float
    support: int


@dataclass(frozen=True, slots=True)
class ClassificationReport:
    accuracy: float
    labels: dict[str, LabelMetrics]
    examples: int


def classification_report(pairs: Iterable[tuple[str, str]]) -> ClassificationReport:
    """Calculate exact-label metrics from ``(expected, predicted)`` pairs."""
    rows = tuple(pairs)
    if not rows:
        raise ValueError("pairs cannot be empty")
    labels = {label for pair in rows for label in pair}
    metrics: dict[str, LabelMetrics] = {}
    for label in sorted(labels):
        true_positive = sum(expected == label and predicted == label for expected, predicted in rows)
        false_positive = sum(expected != label and predicted == label for expected, predicted in rows)
        false_negative = sum(expected == label and predicted != label for expected, predicted in rows)
        support = sum(expected == label for expected, _ in rows)
        precision = true_positive / (true_positive + false_positive) if true_positive + false_positive else 0.0
        recall = true_positive / (true_positive + false_negative) if true_positive + false_negative else 0.0
        f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
        metrics[label] = LabelMetrics(precision, recall, f1, support)
    accuracy = sum(expected == predicted for expected, predicted in rows) / len(rows)
    return ClassificationReport(accuracy=accuracy, labels=metrics, examples=len(rows))
