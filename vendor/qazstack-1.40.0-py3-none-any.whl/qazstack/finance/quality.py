"""Portable quality checks for versioned financial observations."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from .models import Observation


@dataclass(frozen=True, slots=True)
class FinanceQualityIssue:
    code: str
    message: str
    observation_id: str | None = None


@dataclass(frozen=True, slots=True)
class FinanceQualityReport:
    checked: int
    issues: tuple[FinanceQualityIssue, ...]

    @property
    def valid(self) -> bool:
        return not self.issues


def assess_observations(observations: Iterable[Observation]) -> FinanceQualityReport:
    """Detect duplicate versions and publication dates after collection time."""
    checked = 0
    seen: set[str] = set()
    issues: list[FinanceQualityIssue] = []
    for observation in observations:
        checked += 1
        observation_id = observation.observation_id
        if observation_id in seen:
            issues.append(FinanceQualityIssue("duplicate_revision", "duplicate source revision", observation_id))
        seen.add(observation_id)
        if observation.published_at and observation.published_at > observation.collected_at:
            issues.append(
                FinanceQualityIssue(
                    "publication_after_collection",
                    "published_at cannot be later than collected_at",
                    observation_id,
                )
            )
    return FinanceQualityReport(checked=checked, issues=tuple(issues))
