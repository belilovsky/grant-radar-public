"""Transparent baseline forecasting and rolling-origin validation."""

from __future__ import annotations

import math
from collections.abc import Sequence
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class ForecastResult:
    method: str
    predictions: tuple[float, ...]
    training_size: int
    horizon: int


@dataclass(frozen=True, slots=True)
class BacktestResult:
    method: str
    folds: int
    mae: float
    rmse: float


def _series(values: Sequence[float | int]) -> tuple[float, ...]:
    normalized = tuple(float(value) for value in values)
    if not normalized or not all(math.isfinite(value) for value in normalized):
        raise ValueError("values must be a non-empty finite series")
    return normalized


def seasonal_naive_forecast(values: Sequence[float | int], *, horizon: int, season_length: int = 1) -> ForecastResult:
    """Repeat the last completed seasonal cycle as an auditable baseline."""
    series = _series(values)
    if horizon < 1:
        raise ValueError("horizon must be positive")
    if season_length < 1 or len(series) < season_length:
        raise ValueError("season_length must be positive and no longer than values")
    cycle = series[-season_length:]
    predictions = tuple(cycle[index % season_length] for index in range(horizon))
    return ForecastResult("seasonal_naive", predictions, len(series), horizon)


def rolling_origin_backtest(
    values: Sequence[float | int], *, min_train_size: int, season_length: int = 1
) -> BacktestResult:
    """Evaluate one-step seasonal-naive forecasts without leaking future data."""
    series = _series(values)
    if min_train_size < season_length or min_train_size >= len(series):
        raise ValueError("min_train_size must be at least season_length and below series length")
    errors: list[float] = []
    for cutoff in range(min_train_size, len(series)):
        prediction = seasonal_naive_forecast(series[:cutoff], horizon=1, season_length=season_length).predictions[0]
        errors.append(series[cutoff] - prediction)
    mae = sum(abs(error) for error in errors) / len(errors)
    rmse = math.sqrt(sum(error**2 for error in errors) / len(errors))
    return BacktestResult("seasonal_naive", len(errors), mae, rmse)
