"""Provider-neutral financial and economic data models."""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from enum import Enum
from typing import Any, Mapping

from qazstack.contracts._validation import require_aware, require_http_url, require_identifier, require_text

_FINANCE_IDENTIFIER_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]*$")
_CURRENCY_RE = re.compile(r"^[A-Z]{3}$")


def _require_finance_identifier(value: str, field_name: str) -> None:
    """Accept conventional market identifiers such as ``FX.USD.KZT``."""
    require_text(value, field_name)
    if not _FINANCE_IDENTIFIER_RE.fullmatch(value):
        raise ValueError(f"{field_name} must be a stable financial identifier")


def _require_currency(value: str) -> None:
    if not _CURRENCY_RE.fullmatch(value):
        raise ValueError("currency must be an uppercase ISO 4217 code")


class Frequency(str, Enum):
    INTRADAY = "intraday"
    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"
    QUARTERLY = "quarterly"
    ANNUAL = "annual"
    IRREGULAR = "irregular"


class SeriesKind(str, Enum):
    MARKET = "market"
    FX = "fx"
    MACRO = "macro"
    FISCAL = "fiscal"
    BANKING = "banking"
    COMMODITY = "commodity"
    FORECAST = "forecast"


class AccessTier(str, Enum):
    PUBLIC = "public"
    INTERNAL = "internal"
    RESTRICTED = "restricted"


def _finite_decimal(value: Decimal | int | float | str, name: str) -> Decimal:
    try:
        normalized = Decimal(str(value))
    except (InvalidOperation, ValueError) as exc:
        raise ValueError(f"{name} must be a finite decimal") from exc
    if not normalized.is_finite():
        raise ValueError(f"{name} must be a finite decimal")
    return normalized


@dataclass(frozen=True, slots=True)
class FinancialSource:
    """A registered financial source and its permitted use boundary."""

    source_id: str
    name: str
    canonical_url: str
    access_tier: AccessTier
    license_name: str
    refresh_sla_minutes: int

    def __post_init__(self) -> None:
        require_identifier(self.source_id, "source_id")
        require_text(self.name, "name")
        require_http_url(self.canonical_url, "canonical_url")
        require_text(self.license_name, "license_name")
        if self.refresh_sla_minutes < 1:
            raise ValueError("refresh_sla_minutes must be positive")


@dataclass(frozen=True, slots=True)
class Instrument:
    """An issuer-backed or synthetic tradable instrument."""

    instrument_id: str
    instrument_type: str
    name: str
    currency: str
    ticker: str | None = None
    isin: str | None = None
    venue: str | None = None

    def __post_init__(self) -> None:
        _require_finance_identifier(self.instrument_id, "instrument_id")
        require_identifier(self.instrument_type, "instrument_type")
        require_text(self.name, "name")
        _require_currency(self.currency)
        if self.ticker is not None:
            require_text(self.ticker, "ticker")
        if self.isin is not None:
            require_text(self.isin, "isin")
        if self.venue is not None:
            require_identifier(self.venue, "venue")


@dataclass(frozen=True, slots=True)
class SeriesDefinition:
    """Catalog entry for a uniquely identified financial or macro series."""

    series_id: str
    name: str
    kind: SeriesKind
    frequency: Frequency
    unit: str
    source_id: str
    instrument_id: str | None = None
    geography: str | None = None
    seasonal_adjustment: str | None = None

    def __post_init__(self) -> None:
        _require_finance_identifier(self.series_id, "series_id")
        require_text(self.name, "name")
        require_text(self.unit, "unit")
        require_identifier(self.source_id, "source_id")
        if self.instrument_id is not None:
            _require_finance_identifier(self.instrument_id, "instrument_id")
        if self.geography is not None:
            require_identifier(self.geography, "geography")
        if self.seasonal_adjustment is not None:
            require_identifier(self.seasonal_adjustment, "seasonal_adjustment")


@dataclass(frozen=True, slots=True)
class Observation:
    """A versioned numerical point with source-level provenance."""

    series_id: str
    period: date
    value: Decimal | int | float | str
    source_id: str
    collected_at: datetime
    published_at: datetime | None = None
    revision: int = 0
    raw_ingestion_id: int | None = None
    source_url: str | None = None
    metadata: Mapping[str, Any] | None = None

    def __post_init__(self) -> None:
        _require_finance_identifier(self.series_id, "series_id")
        if not isinstance(self.period, date):
            raise ValueError("period must be a date")
        require_identifier(self.source_id, "source_id")
        require_aware(self.collected_at, "collected_at")
        if self.published_at is not None:
            require_aware(self.published_at, "published_at")
        if self.revision < 0:
            raise ValueError("revision cannot be negative")
        if self.raw_ingestion_id is not None and self.raw_ingestion_id < 1:
            raise ValueError("raw_ingestion_id must be positive")
        if self.source_url is not None:
            require_http_url(self.source_url, "source_url")
        object.__setattr__(self, "value", _finite_decimal(self.value, "value"))
        object.__setattr__(self, "metadata", dict(self.metadata or {}))

    @property
    def observation_id(self) -> str:
        """Stable identity for one source revision, suitable for idempotency."""
        payload = f"{self.source_id}|{self.series_id}|{self.period.isoformat()}|{self.revision}"
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()


@dataclass(frozen=True, slots=True)
class Quote:
    """A market quote; all monetary fields are optional except close."""

    instrument_id: str
    observed_at: datetime
    close: Decimal | int | float | str
    source_id: str
    currency: str
    open: Decimal | int | float | str | None = None
    high: Decimal | int | float | str | None = None
    low: Decimal | int | float | str | None = None
    volume: Decimal | int | float | str | None = None
    turnover: Decimal | int | float | str | None = None
    raw_ingestion_id: int | None = None

    def __post_init__(self) -> None:
        _require_finance_identifier(self.instrument_id, "instrument_id")
        require_aware(self.observed_at, "observed_at")
        require_identifier(self.source_id, "source_id")
        _require_currency(self.currency)
        if self.raw_ingestion_id is not None and self.raw_ingestion_id < 1:
            raise ValueError("raw_ingestion_id must be positive")
        for field_name in ("close", "open", "high", "low", "volume", "turnover"):
            value = getattr(self, field_name)
            if value is not None:
                object.__setattr__(self, field_name, _finite_decimal(value, field_name))
        if self.high is not None and self.low is not None and self.high < self.low:
            raise ValueError("high cannot be below low")


@dataclass(frozen=True, slots=True)
class ResearchEvidence:
    """A citable fact or table cell extracted from a licensed document."""

    document_hash: str
    publisher: str
    access_tier: AccessTier
    page_number: int
    text: str
    collected_at: datetime
    table_index: int | None = None
    cell_reference: str | None = None
    source_url: str | None = None

    def __post_init__(self) -> None:
        require_text(self.document_hash, "document_hash")
        require_text(self.publisher, "publisher")
        if self.page_number < 1:
            raise ValueError("page_number must be positive")
        if self.table_index is not None and self.table_index < 0:
            raise ValueError("table_index cannot be negative")
        require_text(self.text, "text")
        require_aware(self.collected_at, "collected_at")
        if self.source_url is not None:
            require_http_url(self.source_url, "source_url")
