"""Deterministic calculations for financial series.

These functions deliberately do not issue forecasts or investment advice. They
produce reproducible descriptive metrics from an explicitly supplied series.
"""

from __future__ import annotations

import math
from collections.abc import Sequence


def _values(values: Sequence[float | int]) -> tuple[float, ...]:
    normalized = tuple(float(value) for value in values)
    if not normalized:
        raise ValueError("values cannot be empty")
    if not all(math.isfinite(value) for value in normalized):
        raise ValueError("values must be finite")
    return normalized


def simple_returns(values: Sequence[float | int]) -> tuple[float, ...]:
    """Return period-over-period percentage changes as decimal fractions."""
    series = _values(values)
    if len(series) < 2:
        return ()
    if any(value == 0 for value in series[:-1]):
        raise ValueError("cannot compute returns from a zero prior value")
    return tuple((current / previous) - 1.0 for previous, current in zip(series, series[1:]))


def log_returns(values: Sequence[float | int]) -> tuple[float, ...]:
    """Return log period changes; all values must be strictly positive."""
    series = _values(values)
    if any(value <= 0 for value in series):
        raise ValueError("log returns require positive values")
    return tuple(math.log(current / previous) for previous, current in zip(series, series[1:]))


def annualized_volatility(values: Sequence[float | int], periods_per_year: int = 252) -> float:
    """Sample standard deviation of simple returns, annualized."""
    if periods_per_year < 1:
        raise ValueError("periods_per_year must be positive")
    returns = simple_returns(values)
    if len(returns) < 2:
        raise ValueError("at least three observations are required")
    mean = sum(returns) / len(returns)
    variance = sum((value - mean) ** 2 for value in returns) / (len(returns) - 1)
    return math.sqrt(variance) * math.sqrt(periods_per_year)


def max_drawdown(values: Sequence[float | int]) -> float:
    """Return the worst peak-to-trough loss as a negative decimal fraction."""
    series = _values(values)
    if any(value <= 0 for value in series):
        raise ValueError("drawdown requires positive values")
    peak = series[0]
    worst = 0.0
    for value in series:
        peak = max(peak, value)
        worst = min(worst, (value / peak) - 1.0)
    return worst


def fx_cross_rate(base_to_pivot: float, quote_to_pivot: float) -> float:
    """Compute base/quote from two rates expressed against the same pivot."""
    numerator = float(base_to_pivot)
    denominator = float(quote_to_pivot)
    if not math.isfinite(numerator) or not math.isfinite(denominator) or denominator <= 0:
        raise ValueError("FX inputs must be finite and quote_to_pivot positive")
    return numerator / denominator
