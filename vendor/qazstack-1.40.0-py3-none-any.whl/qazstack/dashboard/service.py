"""Dashboard aggregation service.

Pulls data from Entity Store, Analytics Registry, and Data Bus
to produce a unified snapshot.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

from sqlalchemy.ext.asyncio import AsyncSession

from qazstack.entities.store import EntityStore


@dataclass
class ProjectSummary:
    """Per-project stats for the dashboard."""

    name: str
    entity_count: int = 0
    mention_count: int = 0
    top_entities: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class DashboardSnapshot:
    """Full dashboard state returned to the UI."""

    # Entity Store
    total_entities: int = 0
    total_mentions: int = 0
    total_relations: int = 0
    entities_by_type: dict[str, int] = field(default_factory=dict)
    top_entities: list[dict[str, Any]] = field(default_factory=list)
    projects: list[ProjectSummary] = field(default_factory=list)

    # Analytics
    registered_engines: list[dict[str, str]] = field(default_factory=list)
    engine_count: int = 0

    # Bus
    bus_topics: list[str] = field(default_factory=list)
    bus_event_count: int = 0
    bus_subscriber_count: int = 0
    recent_events: list[dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to plain dict."""
        return {
            "total_entities": self.total_entities,
            "total_mentions": self.total_mentions,
            "total_relations": self.total_relations,
            "entities_by_type": self.entities_by_type,
            "top_entities": self.top_entities,
            "projects": [
                {
                    "name": p.name,
                    "entity_count": p.entity_count,
                    "mention_count": p.mention_count,
                    "top_entities": p.top_entities,
                }
                for p in self.projects
            ],
            "registered_engines": self.registered_engines,
            "engine_count": self.engine_count,
            "bus_topics": self.bus_topics,
            "bus_event_count": self.bus_event_count,
            "bus_subscriber_count": self.bus_subscriber_count,
            "recent_events": self.recent_events,
        }


class DashboardService:
    """Aggregates cross-project data for the dashboard.

    Each component (entity_store, engine_registry, bus) is optional –
    the service gracefully returns partial data if a component is absent.
    """

    def __init__(
        self,
        *,
        entity_store: Optional[EntityStore] = None,
        engine_registry: Any = None,  # EngineRegistry
        bus: Any = None,  # EventBus
    ):
        self.entity_store = entity_store
        self.engine_registry = engine_registry
        self.bus = bus

    async def snapshot(
        self,
        session: Optional[AsyncSession] = None,
        *,
        top_limit: int = 10,
        event_limit: int = 20,
    ) -> DashboardSnapshot:
        """Build a full dashboard snapshot.

        Args:
            session: DB session (required for entity data)
            top_limit: How many top entities to return
            event_limit: How many recent bus events to include
        """
        snap = DashboardSnapshot()

        if self.entity_store and session:
            await self._fill_entity_data(snap, session, top_limit)

        if self.engine_registry:
            self._fill_analytics_data(snap)

        if self.bus:
            self._fill_bus_data(snap, event_limit)

        return snap

    # ------------------------------------------------------------------
    # Entity Store data
    # ------------------------------------------------------------------

    async def _fill_entity_data(
        self,
        snap: DashboardSnapshot,
        session: AsyncSession,
        top_limit: int,
    ) -> None:
        store = self.entity_store
        assert store is not None

        stats = await store.stats(session)
        snap.total_entities = stats["total_entities"]
        snap.total_mentions = stats["total_mentions"]
        snap.total_relations = stats["total_relations"]
        snap.entities_by_type = stats["by_type"]

        # Top entities overall
        top = await store.top_entities(session, limit=top_limit)
        snap.top_entities = [
            {
                "id": e.id,
                "name": e.name,
                "type": e.entity_type,
                "mentions": e.mention_count,
            }
            for e in top
        ]

        # Per-project breakdown
        mentions_by_project = stats.get("mentions_by_project", {})
        for project_name, mention_cnt in sorted(mentions_by_project.items(), key=lambda x: x[1], reverse=True):
            proj_top = await store.top_entities(session, project=project_name, limit=5)
            snap.projects.append(
                ProjectSummary(
                    name=project_name,
                    mention_count=mention_cnt,
                    entity_count=len(proj_top),
                    top_entities=[{"id": e.id, "name": e.name, "type": e.entity_type} for e in proj_top],
                )
            )

    # ------------------------------------------------------------------
    # Analytics data
    # ------------------------------------------------------------------

    def _fill_analytics_data(self, snap: DashboardSnapshot) -> None:
        registry = self.engine_registry
        if registry is None:
            return

        engines = registry.all_engines
        snap.engine_count = len(engines)
        snap.registered_engines = [
            {
                "name": e.name,
                "version": getattr(e, "version", ""),
                "description": getattr(e, "description", ""),
                "category": str(getattr(e, "category", "")),
            }
            for e in engines
        ]

    # ------------------------------------------------------------------
    # Bus data
    # ------------------------------------------------------------------

    def _fill_bus_data(self, snap: DashboardSnapshot, event_limit: int) -> None:
        bus = self.bus
        if bus is None:
            return

        snap.bus_topics = bus.topics
        stats = bus.stats()
        snap.bus_event_count = sum(stats.get("event_counts", {}).values())
        snap.bus_subscriber_count = stats.get("total_handlers", 0)

        events = bus.history(limit=event_limit)
        snap.recent_events = [e.to_dict() for e in events]
