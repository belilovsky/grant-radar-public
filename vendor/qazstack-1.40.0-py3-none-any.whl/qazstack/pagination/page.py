"""Page-based pagination with platform defaults.

Provides a lightweight pagination layer that works with:
- SQLAlchemy async sessions (PostgreSQL)
- Plain Python lists (SQLite, in-memory data)

Compatible with fastapi-pagination but doesn't require it as a hard dependency.
Falls back to a built-in implementation if fastapi-pagination is not installed.
"""

from __future__ import annotations

import math
from typing import Any, Generic, Sequence, TypeVar

from fastapi import FastAPI
from pydantic import BaseModel

T = TypeVar("T")

_DEFAULT_PAGE = 1
_DEFAULT_PER_PAGE = 20


class Params:
    """Standard pagination parameters.

    Works both as a FastAPI dependency (injected via query params)
    and as a plain object:

        # As dependency:
        async def route(params: Params = Depends()):
            ...

        # Direct usage:
        params = Params(page=2, per_page=10)
    """

    def __init__(self, page: int = _DEFAULT_PAGE, per_page: int = _DEFAULT_PER_PAGE):
        self.page = max(1, int(page))
        self.per_page = max(1, min(100, int(per_page)))

    @property
    def offset(self) -> int:
        return (self.page - 1) * self.per_page

    @property
    def limit(self) -> int:
        return self.per_page


class Page(BaseModel, Generic[T]):
    """Paginated response model.

    JSON output:
        {
            "items": [...],
            "total": 150,
            "page": 1,
            "per_page": 20,
            "pages": 8
        }
    """

    items: list[T]
    total: int
    page: int
    per_page: int
    pages: int

    @classmethod
    def create(cls, items: Sequence[T], total: int, params: Params) -> "Page[T]":
        """Create a Page from items, total count, and params."""
        return cls(
            items=list(items),
            total=total,
            page=params.page,
            per_page=params.per_page,
            pages=max(1, math.ceil(total / params.per_page)),
        )


async def paginate(session: Any, query: Any, params: Params) -> Page:
    """Paginate a SQLAlchemy select() query.

    Args:
        session: AsyncSession instance.
        query: SQLAlchemy select() statement.
        params: Pagination parameters.

    Returns:
        Page with items and total count.

    Usage:
        from sqlalchemy import select, func
        result = await paginate(session, select(Article), params)
    """
    from sqlalchemy import func
    from sqlalchemy import select as sa_select

    # Count total
    count_query = sa_select(func.count()).select_from(query.subquery())
    total_result = await session.execute(count_query)
    total = total_result.scalar_one()

    # Fetch page
    paginated_query = query.offset(params.offset).limit(params.limit)
    result = await session.execute(paginated_query)
    items = result.scalars().all()

    return Page.create(items=items, total=total, params=params)


def paginate_list(items: Sequence[T], params: Params) -> Page[T]:
    """Paginate a plain Python list.

    Useful for SQLite-backed projects (total-kz) or in-memory data.

    Args:
        items: Full list of items.
        params: Pagination parameters.

    Returns:
        Page with sliced items.
    """
    total = len(items)
    start = params.offset
    end = start + params.limit
    page_items = items[start:end]

    return Page.create(items=page_items, total=total, params=params)


def setup_pagination(app: FastAPI) -> None:
    """Register pagination utilities on the app.

    Currently a no-op, reserved for future middleware or hooks.
    Call in main.py for forward compatibility.
    """
    app.state.pagination_enabled = True
