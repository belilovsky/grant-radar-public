"""Simple dict-based translation system.

Usage:
    from qazstack.i18n import TranslationManager

    tm = TranslationManager(default_lang="ru")
    tm.load({
        "ru": {"home": "Главная", "search": "Поиск"},
        "kz": {"home": "Басты бет", "search": "Іздеу"},
        "en": {"home": "Home", "search": "Search"},
    })

    # Get a translation
    tm.t("home", lang="kz")  # → "Басты бет"

    # Module-level shortcut (after setup)
    from qazstack.i18n import t
    t("search")  # → "Поиск" (uses default lang)
"""

from __future__ import annotations

from typing import Any

# Global translation manager instance
_manager: TranslationManager | None = None


class TranslationManager:
    """Manages translations for multiple languages."""

    def __init__(
        self,
        default_lang: str = "ru",
        supported_langs: list[str] | None = None,
    ):
        self.default_lang = default_lang
        self.supported_langs = supported_langs or ["ru", "kz", "en"]
        self._translations: dict[str, dict[str, str]] = {}
        self._current_lang: str = default_lang

        # Set as global
        global _manager
        _manager = self

    def load(self, translations: dict[str, dict[str, str]]) -> None:
        """Load translations dict. Keys are lang codes, values are {key: text} dicts."""
        self._translations.update(translations)

    def load_from_yaml(self, path: str) -> None:
        """Load translations from a YAML file."""
        from pathlib import Path

        import yaml

        data = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
        self.load(data)

    def set_lang(self, lang: str) -> None:
        """Set current language for thread-local usage."""
        if lang in self.supported_langs:
            self._current_lang = lang

    @property
    def lang(self) -> str:
        return self._current_lang

    def t(self, key: str, lang: str | None = None, **kwargs: Any) -> str:
        """Translate a key.

        Falls back: requested lang → default lang → key itself.
        Supports format strings: t("greeting", name="World")
        """
        lang = lang or self._current_lang
        text = (
            self._translations.get(lang, {}).get(key) or self._translations.get(self.default_lang, {}).get(key) or key
        )
        if kwargs:
            try:
                return text.format(**kwargs)
            except (KeyError, IndexError):
                return text
        return text

    def get_all(self, lang: str | None = None) -> dict[str, str]:
        """Get all translations for a language."""
        lang = lang or self._current_lang
        return self._translations.get(lang, {})

    def jinja_globals(self) -> dict[str, Any]:
        """Return dict of globals to inject into Jinja2 templates.

        Usage:
            templates.env.globals.update(tm.jinja_globals())
        Then in templates:
            {{ t("home") }}
            {{ lang }}
            {{ languages }}
        """
        return {
            "t": self.t,
            "lang": self._current_lang,
            "languages": self.supported_langs,
        }


def t(key: str, lang: str | None = None, **kwargs: Any) -> str:
    """Module-level translation shortcut."""
    if _manager is None:
        return key
    return _manager.t(key, lang=lang, **kwargs)
