"""Processing pipeline for collected messages.

Integrates with ``qazstack.kznlp`` for language detection, normalization,
and NER. Works WITHOUT heavy ML dependencies by default – ML steps
(sentiment, embeddings) are optional and skipped if models are unavailable.

Usage::

    from qazstack.monitor.pipeline import MonitorPipeline

    # Lightweight – only kznlp basics
    pipeline = MonitorPipeline()

    # With NER (requires natasha / qazstack[nlp])
    pipeline = MonitorPipeline(steps=["lang_detect", "normalize", "ner"])

    results = await pipeline.process_text("Президент Токаев выступил с обращением")
    # → [AnalysisDict(analysis_type="lang_detect", result={"lang": "ru"}), ...]
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from typing import Callable, Sequence

logger = logging.getLogger("qazstack.monitor.pipeline")

# Available steps and their requirements
STEP_MODULES = {
    "lang_detect": "qazstack.kznlp.lang_detect",
    "normalize": "qazstack.kznlp.normalize",
    "ner": "qazstack.kznlp.ner",
    "sentiment": "qazstack.kznlp.sentiment",
}


@dataclass
class AnalysisDict:
    """Pipeline step output – maps directly to AnalysisResult model fields."""

    analysis_type: str
    model_name: str
    result: dict
    status: str = "success"
    duration_ms: int = 0


def _run_lang_detect(text: str) -> dict:
    """Run language detection via qazstack.kznlp."""
    from qazstack.kznlp import detect_lang

    lang = detect_lang(text)
    return {"lang": lang}


def _run_normalize(text: str) -> dict:
    """Run text normalization via qazstack.kznlp."""
    from qazstack.kznlp import normalize_text

    normalized = normalize_text(text)
    return {"normalized": normalized, "original_len": len(text), "normalized_len": len(normalized)}


def _run_ner(text: str) -> dict:
    """Run NER extraction via qazstack.kznlp."""
    from qazstack.kznlp import extract_entities

    entities = extract_entities(text)
    return {
        "entities": [{"text": e.text, "label": e.label, "start": e.start, "end": e.end} for e in entities],
        "count": len(entities),
    }


def _run_sentiment(text: str) -> dict:
    """Run sentiment analysis via qazstack.kznlp.sentiment."""
    from qazstack.kznlp.sentiment import classify_sentiment

    result = classify_sentiment(text)
    return {
        "label": result.label,
        "score": result.score,
        "tone": result.tone,
        "scores": result.scores,
    }


# Registry of step functions
_STEP_FUNCTIONS: dict[str, tuple[Callable[[str], dict], str]] = {
    "lang_detect": (_run_lang_detect, "qazstack.kznlp.lang_detect"),
    "normalize": (_run_normalize, "qazstack.kznlp.normalize"),
    "ner": (_run_ner, "qazstack.kznlp.ner"),
    "sentiment": (_run_sentiment, "qazstack.kznlp.sentiment"),
}


class MonitorPipeline:
    """Configurable processing pipeline for messages.

    Steps are run in order. Each step receives the original text
    and produces an ``AnalysisDict`` output.

    Args:
        steps: List of step names to run. Default: ``["lang_detect"]``.
            Available: ``"lang_detect"``, ``"normalize"``, ``"ner"``,
            ``"sentiment"`` (requires transformers + torch).
    """

    def __init__(self, steps: Sequence[str] | None = None):
        self.steps = list(steps) if steps else ["lang_detect"]
        self._validate_steps()

    def _validate_steps(self) -> None:
        """Check that requested steps have available implementations."""
        for step in self.steps:
            if step not in _STEP_FUNCTIONS:
                logger.warning("Unknown pipeline step %r – will be skipped", step)

    async def process_text(self, text: str) -> list[AnalysisDict]:
        """Run all pipeline steps on a text string.

        Args:
            text: Input text to analyze.

        Returns:
            List of AnalysisDict, one per step.
        """
        results: list[AnalysisDict] = []

        for step_name in self.steps:
            entry = _STEP_FUNCTIONS.get(step_name)
            if not entry:
                continue

            func, model_name = entry
            start = time.monotonic()
            try:
                result = func(text)
                duration = round((time.monotonic() - start) * 1000)
                results.append(
                    AnalysisDict(
                        analysis_type=step_name,
                        model_name=model_name,
                        result=result,
                        status="success",
                        duration_ms=duration,
                    )
                )
            except ImportError as e:
                logger.info("Skipping step %r – missing dependency: %s", step_name, e)
                results.append(
                    AnalysisDict(
                        analysis_type=step_name,
                        model_name=model_name,
                        result={"error": str(e)},
                        status="skipped",
                    )
                )
            except Exception as e:
                duration = round((time.monotonic() - start) * 1000)
                logger.error("Pipeline step %r failed: %s", step_name, e)
                results.append(
                    AnalysisDict(
                        analysis_type=step_name,
                        model_name=model_name,
                        result={"error": str(e)},
                        status="error",
                        duration_ms=duration,
                    )
                )

        return results

    async def process_batch(self, texts: Sequence[str]) -> list[list[AnalysisDict]]:
        """Run all pipeline steps on a batch of texts.

        Args:
            texts: Input texts to analyze.

        Returns:
            List of lists – one inner list per input text.
        """
        return [await self.process_text(text) for text in texts]
