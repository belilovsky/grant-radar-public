"""MonitorStore – async CRUD for all monitor models.

Wraps SQLAlchemy async sessions with convenient methods for
sources, messages, analysis results, alerts, and check results.

Usage::

    from qazstack.monitor.store import MonitorStore
    from qazstack.core import Database

    db = Database("postgresql+asyncpg://...")
    store = MonitorStore()

    async with db.session() as session:
        source = await store.add_source(session, name="My Feed", source_type="rss",
                                         project="echo-sounder", config={"url": "..."})
        msg = await store.add_message(session, source_id=source.id, result=result)
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Sequence

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from qazstack.monitor.collectors.base import CollectorResult
from qazstack.monitor.models import Alert, AnalysisResult, CheckResult, Message, Source

logger = logging.getLogger("qazstack.monitor.store")


class MonitorStore:
    """Async CRUD operations for monitor models."""

    # --- Sources ---

    async def add_source(
        self,
        session: AsyncSession,
        *,
        name: str,
        source_type: str,
        project: str,
        config: dict | None = None,
        enabled: bool = True,
        check_interval_s: int = 300,
    ) -> Source:
        """Create a new source."""
        source = Source(
            name=name,
            source_type=source_type,
            project=project,
            config=config or {},
            enabled=enabled,
            check_interval_s=check_interval_s,
        )
        session.add(source)
        await session.flush()
        await session.refresh(source)
        return source

    async def get_source(self, session: AsyncSession, source_id: int) -> Source | None:
        """Get source by ID."""
        result = await session.execute(select(Source).where(Source.id == source_id))
        return result.scalars().first()

    async def list_sources(
        self,
        session: AsyncSession,
        *,
        project: str | None = None,
        source_type: str | None = None,
        enabled_only: bool = True,
    ) -> list[Source]:
        """List sources with optional filters."""
        query = select(Source)
        if project:
            query = query.where(Source.project == project)
        if source_type:
            query = query.where(Source.source_type == source_type)
        if enabled_only:
            query = query.where(Source.enabled.is_(True))
        query = query.order_by(Source.id)
        result = await session.execute(query)
        return list(result.scalars().all())

    async def update_source_checked(self, session: AsyncSession, source_id: int) -> None:
        """Update last_checked_at timestamp for a source."""
        await session.execute(
            update(Source).where(Source.id == source_id).values(last_checked_at=datetime.now(timezone.utc))
        )

    # --- Messages ---

    async def add_message(
        self,
        session: AsyncSession,
        *,
        source_id: int,
        result: CollectorResult,
    ) -> Message:
        """Create a message from a CollectorResult."""
        msg = Message(
            source_id=source_id,
            external_id=result.external_id,
            title=result.title,
            text=result.text,
            url=result.url,
            author=result.author,
            published_at=result.published_at,
            metadata_=result.metadata,
            content_hash=Message.compute_hash(result.text),
        )
        session.add(msg)
        await session.flush()
        await session.refresh(msg)
        return msg

    async def add_messages_batch(
        self,
        session: AsyncSession,
        *,
        source_id: int,
        results: Sequence[CollectorResult],
    ) -> list[Message]:
        """Batch-create messages, skipping duplicates by content_hash."""
        if not results:
            return []

        hashes = [Message.compute_hash(r.text) for r in results]
        existing = await session.execute(
            select(Message.content_hash).where(
                Message.source_id == source_id,
                Message.content_hash.in_(hashes),
            )
        )
        existing_hashes = set(existing.scalars().all())

        messages: list[Message] = []
        for r, h in zip(results, hashes):
            if h in existing_hashes:
                continue
            msg = Message(
                source_id=source_id,
                external_id=r.external_id,
                title=r.title,
                text=r.text,
                url=r.url,
                author=r.author,
                published_at=r.published_at,
                metadata_=r.metadata,
                content_hash=h,
            )
            session.add(msg)
            messages.append(msg)
            existing_hashes.add(h)

        if messages:
            await session.flush()
            for msg in messages:
                await session.refresh(msg)
        return messages

    async def get_messages(
        self,
        session: AsyncSession,
        *,
        source_id: int | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[Message]:
        """Get messages with optional source filter."""
        query = select(Message)
        if source_id is not None:
            query = query.where(Message.source_id == source_id)
        query = query.order_by(Message.collected_at.desc()).offset(offset).limit(limit)
        result = await session.execute(query)
        return list(result.scalars().all())

    async def search_messages(
        self,
        session: AsyncSession,
        *,
        query_text: str,
        source_id: int | None = None,
        limit: int = 50,
    ) -> list[Message]:
        """Search messages by ILIKE on text field."""
        query = select(Message).where(Message.text.ilike(f"%{query_text}%"))
        if source_id is not None:
            query = query.where(Message.source_id == source_id)
        query = query.order_by(Message.collected_at.desc()).limit(limit)
        result = await session.execute(query)
        return list(result.scalars().all())

    async def get_unanalyzed_messages(
        self,
        session: AsyncSession,
        *,
        analysis_type: str,
        limit: int = 100,
    ) -> list[Message]:
        """Get messages that don't have a specific analysis type yet."""
        subq = select(AnalysisResult.message_id).where(AnalysisResult.analysis_type == analysis_type).scalar_subquery()
        query = select(Message).where(Message.id.not_in(subq)).order_by(Message.collected_at).limit(limit)
        result = await session.execute(query)
        return list(result.scalars().all())

    # --- Analysis Results ---

    async def add_analysis(
        self,
        session: AsyncSession,
        *,
        message_id: int,
        analysis_type: str,
        model_name: str,
        result: dict,
        status: str = "success",
        duration_ms: int | None = None,
    ) -> AnalysisResult:
        """Add an analysis result for a message."""
        analysis = AnalysisResult(
            message_id=message_id,
            analysis_type=analysis_type,
            model_name=model_name,
            result=result,
            status=status,
            duration_ms=duration_ms,
        )
        session.add(analysis)
        await session.flush()
        await session.refresh(analysis)
        return analysis

    async def get_analysis(
        self,
        session: AsyncSession,
        *,
        message_id: int,
        analysis_type: str | None = None,
    ) -> list[AnalysisResult]:
        """Get analysis results for a message."""
        query = select(AnalysisResult).where(AnalysisResult.message_id == message_id)
        if analysis_type:
            query = query.where(AnalysisResult.analysis_type == analysis_type)
        result = await session.execute(query)
        return list(result.scalars().all())

    # --- Alerts ---

    async def add_alert(
        self,
        session: AsyncSession,
        *,
        alert_type: str,
        severity: str,
        subject: str,
        message: str,
        source_id: int | None = None,
        details: dict | None = None,
        channels_notified: list[str] | None = None,
        cooldown_key: str | None = None,
    ) -> Alert:
        """Create an alert record."""
        alert = Alert(
            source_id=source_id,
            alert_type=alert_type,
            severity=severity,
            subject=subject,
            message=message,
            details=details or {},
            channels_notified=channels_notified or [],
            cooldown_key=cooldown_key,
        )
        session.add(alert)
        await session.flush()
        await session.refresh(alert)
        return alert

    async def get_active_alerts(
        self,
        session: AsyncSession,
        *,
        severity: str | None = None,
        limit: int = 50,
    ) -> list[Alert]:
        """Get unresolved alerts."""
        query = select(Alert).where(Alert.resolved_at.is_(None))
        if severity:
            query = query.where(Alert.severity == severity)
        query = query.order_by(Alert.created_at.desc()).limit(limit)
        result = await session.execute(query)
        return list(result.scalars().all())

    async def resolve_alert(self, session: AsyncSession, alert_id: int) -> Alert | None:
        """Mark an alert as resolved."""
        result = await session.execute(select(Alert).where(Alert.id == alert_id))
        alert = result.scalars().first()
        if alert:
            alert.resolved_at = datetime.now(timezone.utc)
            session.add(alert)
            await session.flush()
            await session.refresh(alert)
        return alert

    # --- Check Results ---

    async def add_check(
        self,
        session: AsyncSession,
        *,
        source_id: int,
        checker: str,
        status: str,
        message: str = "",
        details: dict | None = None,
        response_ms: float | None = None,
    ) -> CheckResult:
        """Record a check result."""
        check = CheckResult(
            source_id=source_id,
            checker=checker,
            status=status,
            message=message,
            details=details or {},
            response_ms=response_ms,
        )
        session.add(check)
        await session.flush()
        await session.refresh(check)
        return check

    async def get_latest_checks(
        self,
        session: AsyncSession,
        *,
        source_id: int | None = None,
        limit: int = 50,
    ) -> list[CheckResult]:
        """Get latest check results."""
        query = select(CheckResult)
        if source_id is not None:
            query = query.where(CheckResult.source_id == source_id)
        query = query.order_by(CheckResult.checked_at.desc()).limit(limit)
        result = await session.execute(query)
        return list(result.scalars().all())
