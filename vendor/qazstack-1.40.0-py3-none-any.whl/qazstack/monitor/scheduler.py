"""ARQ task definitions for monitoring cron jobs.

Factory function creates task functions wired to a specific
MonitorStore, MonitorPipeline, and AlertManager.

Usage::

    from qazstack.monitor.scheduler import create_monitor_tasks
    from qazstack.tasks import create_worker_settings, create_scheduler

    tasks = create_monitor_tasks(store=store, pipeline=pipeline, alert_manager=mgr)

    WorkerSettings = create_worker_settings(
        redis_url="redis://redis:6379",
        functions=[tasks["collect_sources"], tasks["process_unanalyzed"]],
        cron_jobs=[
            create_scheduler(tasks["collect_sources"], minute={0, 15, 30, 45}),
            create_scheduler(tasks["process_unanalyzed"], minute={5, 35}),
        ],
    )
"""

from __future__ import annotations

import logging
from typing import Any

from qazstack.monitor.alerts import AlertManager
from qazstack.monitor.collectors.base import BaseCollector, CollectorResult
from qazstack.monitor.pipeline import MonitorPipeline
from qazstack.monitor.store import MonitorStore

logger = logging.getLogger("qazstack.monitor.scheduler")


def create_monitor_tasks(
    *,
    store: MonitorStore,
    pipeline: MonitorPipeline | None = None,
    alert_manager: AlertManager | None = None,
    collectors: dict[str, BaseCollector] | None = None,
    get_session: Any = None,
) -> dict[str, Any]:
    """Create ARQ task functions wired to monitoring components.

    Args:
        store: MonitorStore instance for DB operations.
        pipeline: MonitorPipeline for NLP processing (optional).
        alert_manager: AlertManager for dispatching alerts (optional).
        collectors: Dict of source_type → collector instance (optional).
        get_session: Async context manager that yields an AsyncSession.
            Must be provided for tasks to function.

    Returns:
        Dict of task_name → async function, suitable for ARQ workers.
    """
    _pipeline = pipeline or MonitorPipeline()
    _collectors = collectors or {}

    async def collect_sources(ctx: dict) -> int:
        """Run all enabled collectors and store new messages.

        Returns the number of new messages collected.
        """
        if get_session is None:
            logger.error("collect_sources: no get_session provided")
            return 0

        total = 0
        async with get_session() as session:
            sources = await store.list_sources(session, enabled_only=True)
            for source in sources:
                collector = _collectors.get(source.source_type)
                if not collector:
                    continue

                results: list[CollectorResult] = []
                try:
                    async for item in collector.collect(source.config):
                        results.append(item)
                except Exception as e:
                    logger.error("Collector error for source %s: %s", source.name, e)
                    if alert_manager:
                        await alert_manager.fire(
                            alert_type="anomaly",
                            severity="warning",
                            subject=f"{source.project}:{source.name}",
                            message=f"Collection failed: {e}",
                        )
                    continue

                if results:
                    msgs = await store.add_messages_batch(session, source_id=source.id, results=results)
                    total += len(msgs)

                await store.update_source_checked(session, source.id)

            await session.commit()
        return total

    async def process_unanalyzed(ctx: dict) -> int:
        """Process messages without analysis results.

        Returns the number of messages processed.
        """
        if get_session is None:
            logger.error("process_unanalyzed: no get_session provided")
            return 0

        total = 0
        async with get_session() as session:
            for step_name in _pipeline.steps:
                messages = await store.get_unanalyzed_messages(session, analysis_type=step_name, limit=100)
                for msg in messages:
                    results = await _pipeline.process_text(msg.text)
                    for r in results:
                        if r.analysis_type == step_name:
                            await store.add_analysis(
                                session,
                                message_id=msg.id,
                                analysis_type=r.analysis_type,
                                model_name=r.model_name,
                                result=r.result,
                                status=r.status,
                                duration_ms=r.duration_ms,
                            )
                    total += 1
            await session.commit()
        return total

    return {
        "collect_sources": collect_sources,
        "process_unanalyzed": process_unanalyzed,
    }
