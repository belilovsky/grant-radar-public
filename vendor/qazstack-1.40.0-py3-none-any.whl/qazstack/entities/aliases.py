"""Safe, reviewable entity-alias candidates for Kazakh and Russian names.

The helpers deliberately do not merge entities or write aliases. Consumers may
show the candidates to an editor, then persist an approved alias through the
Entity Store. This keeps transliteration recall separate from identity proof.
"""

from __future__ import annotations

from dataclasses import dataclass

from .store import normalize_name

CYRILLIC_TO_LATIN = {
    "а": "a",
    "ә": "a",
    "б": "b",
    "в": "v",
    "г": "g",
    "ғ": "g",
    "д": "d",
    "е": "e",
    "ё": "e",
    "ж": "zh",
    "з": "z",
    "и": "i",
    "й": "i",
    "к": "k",
    "қ": "q",
    "л": "l",
    "м": "m",
    "н": "n",
    "ң": "ng",
    "о": "o",
    "ө": "o",
    "п": "p",
    "р": "r",
    "с": "s",
    "т": "t",
    "у": "u",
    "ұ": "u",
    "ү": "u",
    "ф": "f",
    "х": "h",
    "һ": "h",
    "ц": "ts",
    "ч": "ch",
    "ш": "sh",
    "щ": "sh",
    "ъ": "",
    "ы": "y",
    "і": "i",
    "ь": "",
    "э": "e",
    "ю": "yu",
    "я": "ya",
}


@dataclass(frozen=True)
class AliasCandidate:
    """A possible alternate surface form that still needs human approval."""

    alias: str
    normalized: str
    kind: str
    confidence: float
    review_required: bool = True


def transliterate_cyrillic(value: str) -> str:
    """Return a stable Latin rendering of a Kazakh/Russian Cyrillic string."""
    return "".join(CYRILLIC_TO_LATIN.get(character.lower(), character) for character in value)


def suggest_alias_candidates(name: str) -> list[AliasCandidate]:
    """Suggest non-authoritative aliases for cross-script entity lookup.

    Only a full-string Latin rendering is suggested. Short forms, surname-only
    aliases and reverse transliterations are intentionally excluded because they
    can create unsafe person collisions.
    """
    clean_name = " ".join(name.split())
    if not clean_name:
        return []

    latin = transliterate_cyrillic(clean_name)
    if latin == clean_name:
        return []

    normalized = normalize_name(latin)
    if normalized == normalize_name(clean_name):
        return []

    return [
        AliasCandidate(
            alias=latin,
            normalized=normalized,
            kind="latin-transliteration",
            confidence=0.8,
        )
    ]
