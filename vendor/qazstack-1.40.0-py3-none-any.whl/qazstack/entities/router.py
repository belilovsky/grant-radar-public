"""FastAPI router factory for the Entity Store REST API.

Usage::

    from qazstack.entities import entity_router
    from qazstack.core import Database

    db = Database(settings.database_url)
    app.include_router(entity_router(db), prefix="/api/entities")

Endpoints:

    GET    /                       – list / search entities
    POST   /                       – create entity
    GET    /{entity_id}            – get entity by ID
    PATCH  /{entity_id}            – update entity
    GET    /{entity_id}/aliases    – list aliases
    POST   /{entity_id}/aliases    – add alias
    GET    /{entity_id}/mentions   – list mentions
    POST   /{entity_id}/mentions   – add mention
    GET    /{entity_id}/relations  – list relations
    POST   /relations              – add relation
    POST   /merge                  – merge two entities
    GET    /resolve                – resolve by name
    GET    /alias-candidates       – reviewable cross-script alias suggestions
    GET    /top                    – top entities by mention count
    GET    /stats                  – summary statistics
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

from .aliases import AliasCandidate, suggest_alias_candidates
from .store import EntityStore, normalize_name

# ── Pydantic Schemas ──────────────────────────────────────────────


class EntityCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=500)
    entity_type: str = Field(..., pattern=r"^(PER|ORG|LOC|EVENT|MISC)$")
    description: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)
    project: str = "unknown"


class EntityUpdate(BaseModel):
    name: str | None = None
    description: str | None = None
    metadata: dict[str, Any] | None = None


class EntityOut(BaseModel):
    id: int
    name: str
    normalized: str
    entity_type: str
    description: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict, alias="metadata_")
    created_by: str
    mention_count: int
    first_seen_at: datetime
    updated_at: datetime
    merged_into_id: int | None = None

    model_config = {"from_attributes": True, "populate_by_name": True}


class AliasCreate(BaseModel):
    alias: str = Field(..., min_length=1, max_length=500)
    lang: str | None = None
    source: str = "manual"


class AliasOut(BaseModel):
    id: int
    entity_id: int
    alias: str
    normalized: str
    lang: str | None = None
    source: str

    model_config = {"from_attributes": True}


class MentionCreate(BaseModel):
    source_project: str = Field(..., min_length=1, max_length=100)
    source_table: str = Field(..., min_length=1, max_length=100)
    source_id: int
    context: str | None = None
    confidence: float = 1.0


class MentionOut(BaseModel):
    id: int
    entity_id: int
    source_project: str
    source_table: str
    source_id: int
    context: str | None = None
    confidence: float
    mentioned_at: datetime

    model_config = {"from_attributes": True}


class RelationCreate(BaseModel):
    from_id: int
    to_id: int
    relation_type: str = Field(..., min_length=1, max_length=100)
    metadata: dict[str, Any] = Field(default_factory=dict)
    source: str = "manual"


class RelationOut(BaseModel):
    id: int
    from_entity_id: int
    to_entity_id: int
    relation_type: str
    metadata: dict[str, Any] = Field(default_factory=dict, alias="metadata_")
    source: str
    created_at: datetime

    model_config = {"from_attributes": True, "populate_by_name": True}


class MergeRequest(BaseModel):
    keep_id: int
    merge_id: int


class StatsOut(BaseModel):
    total_entities: int
    by_type: dict[str, int]
    total_mentions: int
    total_aliases: int
    total_relations: int
    mentions_by_project: dict[str, int]


class AliasCandidateOut(BaseModel):
    alias: str
    normalized: str
    kind: str
    confidence: float
    review_required: bool

    model_config = {"from_attributes": True}


# ── Router Factory ────────────────────────────────────────────────


def entity_router(
    db,
    *,
    prefix: str = "",
    tags: list[str] | None = None,
) -> APIRouter:
    """Create a REST API router for the entity store.

    Args:
        db: A ``qazstack.core.Database`` instance (must have ``.get_session()``).
        prefix: Optional path prefix.
        tags: OpenAPI tags.

    Returns:
        A FastAPI APIRouter.

    Example::

        from qazstack.entities import entity_router
        app.include_router(entity_router(db), prefix="/api/entities")
    """
    router = APIRouter(prefix=prefix, tags=tags or ["entities"])
    store = EntityStore()

    async def get_session():
        async with db.get_session() as session:
            yield session

    # ── List / Search ─────────────────────────────

    @router.get("/", response_model=list[EntityOut])
    async def list_entities(
        q: str = "",
        entity_type: str = "",
        limit: int = Query(50, ge=1, le=500),
        session: AsyncSession = Depends(get_session),
    ):
        """List entities or search by name/alias."""
        if q:
            return await store.search(session, q, entity_type=entity_type or None, limit=limit)
        return await store.top_entities(session, entity_type=entity_type or None, limit=limit)

    # ── Create ────────────────────────────────────

    @router.post("/", response_model=EntityOut, status_code=201)
    async def create_entity(
        body: EntityCreate,
        session: AsyncSession = Depends(get_session),
    ):
        """Create a new entity (deduplicates by normalized name + type)."""
        entity = await store.add_entity(
            session,
            name=body.name,
            entity_type=body.entity_type,
            project=body.project,
            description=body.description,
            metadata=body.metadata,
        )
        await session.commit()
        return entity

    # ── Resolve by name (before /{entity_id} to avoid path conflict) ──

    @router.get("/alias-candidates", response_model=list[AliasCandidateOut])
    async def alias_candidates(
        name: str = Query(..., min_length=1, max_length=500),
    ) -> list[AliasCandidate]:
        """Return reviewable transliteration suggestions without writing data."""
        return suggest_alias_candidates(name)

    @router.get("/resolve", response_model=EntityOut)
    async def resolve_entity(
        name: str = Query(..., min_length=1),
        entity_type: str = "",
        session: AsyncSession = Depends(get_session),
    ):
        """Resolve entity by name or alias."""
        entity = await store.resolve_by_name(session, name, entity_type=entity_type or None)
        if not entity:
            raise HTTPException(404, "Entity not found")
        return entity

    # ── Top entities ──────────────────────────────

    @router.get("/top", response_model=list[EntityOut])
    async def top_entities(
        entity_type: str = "",
        project: str = "",
        limit: int = Query(50, ge=1, le=500),
        session: AsyncSession = Depends(get_session),
    ):
        """Get top entities by mention count."""
        return await store.top_entities(
            session,
            entity_type=entity_type or None,
            project=project or None,
            limit=limit,
        )

    # ── Stats ─────────────────────────────────────

    @router.get("/stats", response_model=StatsOut)
    async def get_stats(
        session: AsyncSession = Depends(get_session),
    ):
        """Get summary statistics."""
        return await store.stats(session)

    # ── Get by ID ─────────────────────────────────

    @router.get("/{entity_id}", response_model=EntityOut)
    async def get_entity(
        entity_id: int,
        session: AsyncSession = Depends(get_session),
    ):
        """Get entity by ID (follows merge chain)."""
        entity = await store.get_entity(session, entity_id)
        if not entity:
            raise HTTPException(404, "Entity not found")
        return entity

    # ── Update ────────────────────────────────────

    @router.patch("/{entity_id}", response_model=EntityOut)
    async def update_entity(
        entity_id: int,
        body: EntityUpdate,
        session: AsyncSession = Depends(get_session),
    ):
        """Update entity fields."""
        entity = await store.get_entity(session, entity_id)
        if not entity:
            raise HTTPException(404, "Entity not found")
        if body.name is not None:
            entity.name = body.name
            entity.normalized = normalize_name(body.name)
        if body.description is not None:
            entity.description = body.description
        if body.metadata is not None:
            entity.metadata_ = body.metadata
        await session.flush()
        await session.refresh(entity)
        await session.commit()
        return entity

    # ── Aliases ───────────────────────────────────

    @router.get("/{entity_id}/aliases", response_model=list[AliasOut])
    async def list_aliases(
        entity_id: int,
        session: AsyncSession = Depends(get_session),
    ):
        """Get all aliases for an entity."""
        entity = await store.get_entity(session, entity_id)
        if not entity:
            raise HTTPException(404, "Entity not found")
        return await store.get_aliases(session, entity_id)

    @router.post("/{entity_id}/aliases", response_model=AliasOut, status_code=201)
    async def add_alias(
        entity_id: int,
        body: AliasCreate,
        session: AsyncSession = Depends(get_session),
    ):
        """Add an alias for an entity."""
        entity = await store.get_entity(session, entity_id)
        if not entity:
            raise HTTPException(404, "Entity not found")
        alias = await store.add_alias(
            session,
            entity_id=entity_id,
            alias=body.alias,
            lang=body.lang,
            source=body.source,
        )
        await session.commit()
        return alias

    # ── Mentions ──────────────────────────────────

    @router.get("/{entity_id}/mentions", response_model=list[MentionOut])
    async def list_mentions(
        entity_id: int,
        project: str = "",
        limit: int = Query(50, ge=1, le=500),
        session: AsyncSession = Depends(get_session),
    ):
        """Get mentions for an entity."""
        entity = await store.get_entity(session, entity_id)
        if not entity:
            raise HTTPException(404, "Entity not found")
        return await store.get_mentions(session, entity_id, project=project or None, limit=limit)

    @router.post("/{entity_id}/mentions", response_model=MentionOut, status_code=201)
    async def add_mention(
        entity_id: int,
        body: MentionCreate,
        session: AsyncSession = Depends(get_session),
    ):
        """Record a mention of an entity from a source."""
        entity = await store.get_entity(session, entity_id)
        if not entity:
            raise HTTPException(404, "Entity not found")
        mention = await store.add_mention(
            session,
            entity_id=entity_id,
            source_project=body.source_project,
            source_table=body.source_table,
            source_id=body.source_id,
            context=body.context,
            confidence=body.confidence,
        )
        await session.commit()
        return mention

    # ── Relations ─────────────────────────────────

    @router.get("/{entity_id}/relations", response_model=list[RelationOut])
    async def list_relations(
        entity_id: int,
        session: AsyncSession = Depends(get_session),
    ):
        """Get all relations involving an entity."""
        entity = await store.get_entity(session, entity_id)
        if not entity:
            raise HTTPException(404, "Entity not found")
        return await store.get_relations(session, entity_id)

    @router.post("/relations", response_model=RelationOut, status_code=201)
    async def add_relation(
        body: RelationCreate,
        session: AsyncSession = Depends(get_session),
    ):
        """Add a directed relation between two entities."""
        rel = await store.add_relation(
            session,
            from_id=body.from_id,
            to_id=body.to_id,
            relation_type=body.relation_type,
            metadata=body.metadata,
            source=body.source,
        )
        await session.commit()
        return rel

    # ── Merge ─────────────────────────────────────

    @router.post("/merge", response_model=EntityOut)
    async def merge_entities(
        body: MergeRequest,
        session: AsyncSession = Depends(get_session),
    ):
        """Merge two entities (keep_id absorbs merge_id)."""
        try:
            result = await store.merge_entities(session, keep_id=body.keep_id, merge_id=body.merge_id)
        except ValueError as e:
            raise HTTPException(400, str(e))
        await session.refresh(result)
        await session.commit()
        return result

    return router
