"""Telegram alert system – send notifications to Telegram chats.

Uses httpx (no extra dependency) for simple alerts.
Falls back to python-telegram-bot for advanced features.

Usage:
    from qazstack.telegram import TelegramAlert

    alert = TelegramAlert(
        bot_token="123:ABC...",
        chat_id="-5029849512",
    )

    # Simple text
    await alert.send("Server restarted")

    # HTML formatted
    await alert.send("<b>Alert:</b> CPU > 90%", parse_mode="HTML")

    # Module-level shortcut
    from qazstack.telegram import send_alert
    await send_alert("Something happened")
"""

from __future__ import annotations

import logging
from typing import Literal

import httpx

logger = logging.getLogger("qazstack.telegram")

_default_alert: TelegramAlert | None = None


class TelegramAlert:
    """Simple Telegram alert sender using httpx.

    Lightweight – doesn't require python-telegram-bot.
    """

    API_URL = "https://api.telegram.org/bot{token}/sendMessage"

    def __init__(
        self,
        bot_token: str,
        chat_id: str | int,
        *,
        default_parse_mode: Literal["HTML", "Markdown", "MarkdownV2"] = "HTML",
        disable_notification: bool = False,
        timeout: float = 10.0,
    ):
        self.bot_token = bot_token
        self.chat_id = str(chat_id)
        self.default_parse_mode = default_parse_mode
        self.disable_notification = disable_notification
        self.timeout = timeout
        self._url = self.API_URL.format(token=bot_token)

        # Register as default
        global _default_alert
        if _default_alert is None:
            _default_alert = self

    async def send(
        self,
        text: str,
        *,
        chat_id: str | int | None = None,
        parse_mode: str | None = None,
        disable_notification: bool | None = None,
    ) -> bool:
        """Send a text message. Returns True on success."""
        payload = {
            "chat_id": str(chat_id) if chat_id else self.chat_id,
            "text": text,
            "parse_mode": parse_mode or self.default_parse_mode,
            "disable_notification": disable_notification
            if disable_notification is not None
            else self.disable_notification,
        }
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.post(self._url, json=payload)
                if resp.status_code == 200:
                    return True
                logger.warning("Telegram API error %s: %s", resp.status_code, resp.text)
                return False
        except Exception as e:
            logger.error("Failed to send Telegram alert: %s", e)
            return False

    async def send_error(self, project: str, error: str) -> bool:
        """Send a formatted error alert."""
        text = f"🔴 <b>{project}</b>\n\n{error}"
        return await self.send(text)

    async def send_warning(self, project: str, message: str) -> bool:
        """Send a formatted warning alert."""
        text = f"🟡 <b>{project}</b>\n\n{message}"
        return await self.send(text)

    async def send_info(self, project: str, message: str) -> bool:
        """Send a formatted info alert."""
        text = f"🟢 <b>{project}</b>\n\n{message}"
        return await self.send(text)


async def send_alert(text: str, **kwargs) -> bool:
    """Module-level shortcut using the default TelegramAlert instance."""
    if _default_alert is None:
        logger.warning("No TelegramAlert configured. Call TelegramAlert() first.")
        return False
    return await _default_alert.send(text, **kwargs)
