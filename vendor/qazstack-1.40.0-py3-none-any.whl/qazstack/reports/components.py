"""Reusable report components for PDF generation.

This module provides generic, domain-agnostic building blocks for composing
PDF reports: traffic-light classification, metric cards, styled tables,
hero blocks, and section headers.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    pass


# ===================== TRAFFIC LIGHT =====================


class TrafficLight:
    """Traffic-light zone constants.

    Each constant is a tuple of (name, hex_color, hex_bg_color).
    """

    GREEN: tuple[str, str, str] = ("green", "#059669", "#ecfdf5")
    YELLOW: tuple[str, str, str] = ("yellow", "#d97706", "#fffbeb")
    ORANGE: tuple[str, str, str] = ("orange", "#ea580c", "#fff7ed")
    RED: tuple[str, str, str] = ("red", "#dc2626", "#fef2f2")
    GRAY: tuple[str, str, str] = ("gray", "#6b7280", "#f8fafc")

    @classmethod
    def all_zones(cls) -> list[tuple[str, str, str]]:
        """Return all zone constants in severity order (low → critical)."""
        return [cls.GREEN, cls.YELLOW, cls.ORANGE, cls.RED, cls.GRAY]


# ===================== ZONE CLASSIFIER =====================


class ZoneClassifier:
    """Generic threshold-based zone classifier.

    Parameters
    ----------
    thresholds:
        List of ``(threshold_value, label, TrafficLight_zone)`` tuples,
        sorted by ascending threshold. The first matching threshold wins.
        For ``higher_is_better=True``, a value *below* each threshold maps to
        the corresponding zone. For ``higher_is_better=False``, a value
        *above* each threshold maps to the corresponding zone.
    higher_is_better:
        If ``True`` (default), high values are green; if ``False``, low values
        are green.
    default_label:
        Label returned when value is ``None``.

    Examples
    --------
    >>> clf = ZoneClassifier(
    ...     thresholds=[
    ...         (20.0, "Low", TrafficLight.GREEN),
    ...         (30.0, "Moderate", TrafficLight.YELLOW),
    ...         (40.0, "Elevated", TrafficLight.ORANGE),
    ...     ],
    ...     higher_is_better=False,
    ... )
    >>> clf.classify(15.0)
    ('Low', ('green', '#059669', '#ecfdf5'))
    """

    def __init__(
        self,
        thresholds: list[tuple[float, str, tuple[str, str, str]]],
        *,
        higher_is_better: bool = True,
        default_label: str = "–",
    ) -> None:
        # Sort thresholds ascending by threshold value so iteration order
        # is well-defined regardless of how the caller supplies them.
        self._thresholds = sorted(thresholds, key=lambda t: t[0])
        self._higher_is_better = higher_is_better
        self._default_label = default_label

    def classify(self, value: float | None) -> tuple[str, tuple[str, str, str]]:
        """Classify *value* and return ``(label, TrafficLight_zone)``.

        Returns ``(default_label, TrafficLight.GRAY)`` when value is ``None``.
        """
        if value is None:
            return (self._default_label, TrafficLight.GRAY)

        if not self._higher_is_better:
            # Lower value → greener zone; iterate ascending thresholds.
            # The first threshold the value falls *below* determines the zone.
            for threshold, label, zone in self._thresholds:
                if value < threshold:
                    return (label, zone)
            # Value exceeds all thresholds → last (worst) zone in list
            if self._thresholds:
                return (self._thresholds[-1][1], self._thresholds[-1][2])
        else:
            # Higher value → greener zone.
            # Thresholds are ordered ascending; iterate from the *highest*
            # threshold downward and return the zone of the first threshold
            # that the value exceeds (i.e., the best zone the value qualifies
            # for).
            for threshold, label, zone in reversed(self._thresholds):
                if value > threshold:
                    return (label, zone)
            # Value is below ALL thresholds → worst zone (first entry)
            if self._thresholds:
                return (self._thresholds[0][1], self._thresholds[0][2])

        return (self._default_label, TrafficLight.GRAY)


# ===================== METRIC CARD =====================


@dataclass
class MetricCard:
    """Represents a single KPI metric for display in a report.

    Attributes
    ----------
    name:
        Short metric identifier, e.g. ``"Revenue"``.
    value:
        Formatted metric value string, e.g. ``"$1.2M"``.
    description:
        Human-readable description of what the metric measures.
    zone_label:
        Short zone label, e.g. ``"Good"``, ``"Critical"``.
    zone:
        Traffic-light zone constant (one of ``TrafficLight.*``).
    """

    name: str
    value: str
    description: str
    zone_label: str
    zone: tuple[str, str, str]


# ===================== FORMATTING HELPERS =====================


def fmt(value: float | None, decimals: int = 2, suffix: str = "") -> str:
    """Format a numeric value to string with a fixed number of decimal places.

    Returns ``"–"`` for ``None`` values.

    Parameters
    ----------
    value:
        Numeric value to format, or ``None``.
    decimals:
        Number of decimal places.
    suffix:
        Optional suffix appended to the formatted number (e.g. ``"%"``).
    """
    if value is None:
        return "–"
    return f"{value:.{decimals}f}{suffix}"


# ===================== PDF COMPONENT BUILDERS =====================
# All functions below return lists of ReportLab flowable elements.
# They accept a *ctx* dict produced by PDFReport._build_ctx().


def report_header(ctx: dict[str, Any], title: str, subtitle: str = "") -> list[Any]:
    """Return flowable elements for the report title + subtitle + separator.

    Parameters
    ----------
    ctx:
        ReportLab context dict from ``PDFReport``.
    title:
        Main report title text.
    subtitle:
        Optional subtitle text rendered below the title.
    """
    s = ctx["styles"]
    Paragraph = ctx["Paragraph"]
    HRFlowable = ctx["HRFlowable"]
    HexColor = ctx["HexColor"]
    mm = ctx["mm"]

    elems: list[Any] = []
    elems.append(Paragraph(title, s["ReportTitle"]))
    if subtitle:
        elems.append(Paragraph(subtitle, s["ReportSubtitle"]))
    elems.append(HRFlowable(width="100%", thickness=1, color=HexColor("#e2e8f0"), spaceAfter=4 * mm))
    return elems


def report_footer(ctx: dict[str, Any], text: str) -> list[Any]:
    """Return flowable elements for a report footer with separator.

    Parameters
    ----------
    ctx:
        ReportLab context dict from ``PDFReport``.
    text:
        Footer text content.
    """
    s = ctx["styles"]
    Paragraph = ctx["Paragraph"]
    Spacer = ctx["Spacer"]
    HRFlowable = ctx["HRFlowable"]
    HexColor = ctx["HexColor"]
    mm = ctx["mm"]

    elems: list[Any] = []
    elems.append(Spacer(1, 6 * mm))
    elems.append(HRFlowable(width="100%", thickness=0.5, color=HexColor("#e2e8f0"), spaceAfter=3 * mm))
    elems.append(Paragraph(text, s["ReportFooter"]))
    return elems


def section_header(ctx: dict[str, Any], text: str) -> list[Any]:
    """Return flowable elements for a styled section header.

    Parameters
    ----------
    ctx:
        ReportLab context dict from ``PDFReport``.
    text:
        Section header text.
    """
    s = ctx["styles"]
    Paragraph = ctx["Paragraph"]
    return [Paragraph(text, s["ReportSection"])]


def hero_block(
    ctx: dict[str, Any],
    title: str,
    subtitle: str = "",
    color: tuple[str, str, str] = TrafficLight.GREEN,
) -> list[Any]:
    """Return flowable elements for a colored hero status block.

    The block renders as a bordered, background-colored box containing
    a large title and an optional subtitle – suitable for displaying a
    primary status or classification at the top of a report section.

    Parameters
    ----------
    ctx:
        ReportLab context dict from ``PDFReport``.
    title:
        Primary text displayed prominently inside the block.
    subtitle:
        Optional secondary text rendered below *title*.
    color:
        A ``TrafficLight`` zone tuple ``(name, hex_color, hex_bg_color)``.
    """
    from reportlab.lib.enums import TA_CENTER
    from reportlab.lib.styles import ParagraphStyle

    Paragraph = ctx["Paragraph"]
    Spacer = ctx["Spacer"]
    Table = ctx["Table"]
    TableStyle = ctx["TableStyle"]
    HexColor = ctx["HexColor"]
    mm = ctx["mm"]
    font_sb = ctx["font_sb"]
    font_md = ctx["font_md"]

    _name, hex_color, hex_bg = color

    title_style = ParagraphStyle(
        "heroTitle",
        fontName=font_sb,
        fontSize=18,
        alignment=TA_CENTER,
        textColor=HexColor(hex_color),
        leading=22,
    )
    sub_style = ParagraphStyle(
        "heroSub",
        fontName=font_md,
        fontSize=9,
        alignment=TA_CENTER,
        textColor=HexColor("#475569"),
        leading=14,
    )

    content: list[Any] = [Paragraph(title, title_style)]
    if subtitle:
        content.append(Spacer(1, 2 * mm))
        content.append(Paragraph(subtitle, sub_style))

    tbl = Table([[content]], colWidths=[170 * mm])
    tbl.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), HexColor(hex_bg)),
                ("BOX", (0, 0), (-1, -1), 2, HexColor(hex_color)),
                ("TOPPADDING", (0, 0), (-1, -1), 16),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 16),
                ("LEFTPADDING", (0, 0), (-1, -1), 18),
                ("RIGHTPADDING", (0, 0), (-1, -1), 18),
            ]
        )
    )
    return [tbl, Spacer(1, 5 * mm)]


def metrics_table(ctx: dict[str, Any], metrics: list[MetricCard]) -> list[Any]:
    """Return flowable elements for a 4-column KPI metric card table.

    Each card displays the metric name, value (colored by zone),
    zone label, and description.

    Parameters
    ----------
    ctx:
        ReportLab context dict from ``PDFReport``.
    metrics:
        List of ``MetricCard`` instances. Displayed 4 per row; extra cards
        wrap into additional rows.
    """
    from reportlab.lib.enums import TA_CENTER
    from reportlab.lib.styles import ParagraphStyle

    if not metrics:
        return []

    Table = ctx["Table"]
    TableStyle = ctx["TableStyle"]
    Paragraph = ctx["Paragraph"]
    Spacer = ctx["Spacer"]
    HexColor = ctx["HexColor"]
    mm = ctx["mm"]
    font = ctx["font"]
    font_bd = ctx["font_bd"]
    font_sb = ctx["font_sb"]
    font_md = ctx["font_md"]

    elems: list[Any] = []
    col_w = 43 * mm
    cols = 4

    # Chunk into groups of `cols`
    for chunk_start in range(0, len(metrics), cols):
        chunk = metrics[chunk_start : chunk_start + cols]

        header_row: list[Any] = []
        value_row: list[Any] = []
        zone_row: list[Any] = []
        label_row: list[Any] = []

        for card in chunk:
            _name, hex_color, _bg = card.zone
            header_row.append(
                Paragraph(
                    card.name,
                    ParagraphStyle(
                        "mh", fontName=font_sb, fontSize=9, alignment=TA_CENTER, textColor=HexColor("#1e293b")
                    ),
                )
            )
            value_row.append(
                Paragraph(
                    card.value,
                    ParagraphStyle(
                        "mv",
                        fontName=font_bd,
                        fontSize=16,
                        alignment=TA_CENTER,
                        textColor=HexColor(hex_color),
                        leading=20,
                    ),
                )
            )
            zone_row.append(
                Paragraph(
                    card.zone_label,
                    ParagraphStyle(
                        "mz", fontName=font_sb, fontSize=8, alignment=TA_CENTER, textColor=HexColor(hex_color)
                    ),
                )
            )
            label_row.append(
                Paragraph(
                    card.description,
                    ParagraphStyle(
                        "ml",
                        fontName=font_md,
                        fontSize=7.5,
                        alignment=TA_CENTER,
                        textColor=HexColor("#64748b"),
                        leading=10,
                    ),
                )
            )

        # Pad to full width if chunk is incomplete
        pad = cols - len(chunk)
        for _ in range(pad):
            empty = Paragraph("", ParagraphStyle("ep", fontName=font, fontSize=9))
            header_row.append(empty)
            value_row.append(empty)
            zone_row.append(empty)
            label_row.append(empty)

        tbl_data = [header_row, value_row, zone_row, label_row]
        tbl = Table(tbl_data, colWidths=[col_w] * cols)
        tbl.setStyle(
            TableStyle(
                [
                    ("ALIGN", (0, 0), (-1, -1), "CENTER"),
                    ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                    ("LINEBELOW", (0, 0), (-1, 0), 0.5, HexColor("#e2e8f0")),
                    ("LINEBELOW", (0, -1), (-1, -1), 0.5, HexColor("#e2e8f0")),
                    ("LINEBEFORE", (1, 0), (1, -1), 0.3, HexColor("#e2e8f0")),
                    ("LINEBEFORE", (2, 0), (2, -1), 0.3, HexColor("#e2e8f0")),
                    ("LINEBEFORE", (3, 0), (3, -1), 0.3, HexColor("#e2e8f0")),
                    ("TOPPADDING", (0, 0), (-1, -1), 8),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
                ]
            )
        )
        elems.append(tbl)
        elems.append(Spacer(1, 5 * mm))

    return elems


def data_table(
    ctx: dict[str, Any],
    headers: list[str],
    rows: list[list[str]],
    col_widths: list[float] | None = None,
) -> list[Any]:
    """Return flowable elements for a generic styled data table.

    The table has a dark header row and zebra-striped body rows.

    Parameters
    ----------
    ctx:
        ReportLab context dict from ``PDFReport``.
    headers:
        Column header strings.
    rows:
        Data rows; each row is a list of cell strings.
    col_widths:
        Optional list of column widths in points. If ``None``, columns
        are distributed evenly across the page width.
    """

    Table = ctx["Table"]
    TableStyle = ctx["TableStyle"]
    Spacer = ctx["Spacer"]
    HexColor = ctx["HexColor"]
    mm = ctx["mm"]
    white = ctx["white"]
    font = ctx["font"]
    font_sb = ctx["font_sb"]

    if not headers and not rows:
        return []

    n_cols = len(headers) or (len(rows[0]) if rows else 1)

    if col_widths is None:
        # Distribute evenly across usable page width (~170mm for A4 with 16mm margins each side)
        usable = 170 * mm
        col_widths = [usable / n_cols] * n_cols

    tbl_data: list[list[Any]] = [headers] + rows
    tbl = Table(tbl_data, colWidths=col_widths)
    tbl.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), HexColor("#1e293b")),
                ("TEXTCOLOR", (0, 0), (-1, 0), white),
                ("FONTNAME", (0, 0), (-1, -1), font),
                ("FONTNAME", (0, 0), (-1, 0), font_sb),
                ("FONTSIZE", (0, 0), (-1, 0), 8.5),
                ("FONTSIZE", (0, 1), (-1, -1), 9),
                ("ALIGN", (1, 0), (-1, -1), "CENTER"),
                ("GRID", (0, 0), (-1, -1), 0.3, HexColor("#e2e8f0")),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [white, HexColor("#f8fafc")]),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ]
        )
    )
    return [tbl, Spacer(1, 4 * mm)]
