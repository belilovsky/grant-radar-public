"""HTML report generator using Jinja2 templates.

Provides ``HTMLReport`` for rendering Jinja2 templates with report context,
including a built-in responsive base template suitable for web and print output.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

# Path to the built-in templates directory shipped with this package
_TEMPLATES_DIR = Path(__file__).parent / "templates"


class HTMLReport:
    """Jinja2-based HTML report renderer.

    Parameters
    ----------
    template_dir:
        Path to a custom directory containing Jinja2 templates.
        When ``None``, only the built-in templates from this package are
        available via ``render()``.  Custom directories take precedence
        over built-in templates when both exist.

    Examples
    --------
    >>> report = HTMLReport()
    >>> html = report.render("base_report.html", {"title": "Q1 Report"})

    >>> report = HTMLReport(template_dir="/path/to/my/templates")
    >>> html = report.render("custom.html", {"metrics": [...]})
    """

    def __init__(self, template_dir: str | Path | None = None) -> None:
        self._template_dir = Path(template_dir) if template_dir is not None else None
        self._env: Any = None  # Jinja2 Environment, created lazily

    def _get_env(self) -> Any:
        """Build and cache the Jinja2 ``Environment``."""
        if self._env is not None:
            return self._env

        try:
            from jinja2 import ChoiceLoader, Environment, FileSystemLoader, select_autoescape
        except ImportError as exc:
            raise ImportError(
                "jinja2 is required for HTMLReport. Install it with: pip install 'qazstack[reports]'"
            ) from exc

        loaders = []
        if self._template_dir is not None:
            loaders.append(FileSystemLoader(str(self._template_dir)))
        loaders.append(FileSystemLoader(str(_TEMPLATES_DIR)))

        self._env = Environment(
            loader=ChoiceLoader(loaders),
            autoescape=select_autoescape(["html", "xml"]),
        )
        return self._env

    def render(self, template_name: str, context: dict[str, Any]) -> str:
        """Render a named template file with *context*.

        Parameters
        ----------
        template_name:
            File name of the template, relative to *template_dir* or the
            built-in templates directory.
        context:
            Variables passed into the template rendering context.

        Returns
        -------
        str
            Rendered HTML string.
        """
        env = self._get_env()
        template = env.get_template(template_name)
        return template.render(**context)

    def render_string(self, template_str: str, context: dict[str, Any]) -> str:
        """Render a template from a string rather than a file.

        Parameters
        ----------
        template_str:
            Jinja2 template source code as a string.
        context:
            Variables passed into the template rendering context.

        Returns
        -------
        str
            Rendered HTML string.
        """
        try:
            from jinja2 import Environment, select_autoescape
        except ImportError as exc:
            raise ImportError(
                "jinja2 is required for HTMLReport. Install it with: pip install 'qazstack[reports]'"
            ) from exc

        env = Environment(autoescape=select_autoescape(["html", "xml"]))
        template = env.from_string(template_str)
        return template.render(**context)
