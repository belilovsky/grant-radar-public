"""QazLake DataSource – aggregated signals from the QazLake data lake.

Reads from QazLake's PostgreSQL (read-only via pssr_reader):
- articles – 497K+ articles with pub_date, lang, source_name
- article_nlp – sentiment analysis, importance scoring, topics
- crisis_events – crisis timeline with severity, status

Produces PSSR signals for 3 layers:
- l_narrative (media_volume): spike detection – articles per hour vs baseline
- l_toxicity (sentiment): negative sentiment ratio, weighted toxicity score
- crisis: active crisis events count, max severity, freshness

This replaces direct Echo Sounder queries with QazLake aggregated data,
providing a richer signal set from 497K articles + 48K NLP records.
"""

from __future__ import annotations

import logging
import os
from datetime import datetime, timedelta, timezone

try:
    from src.datasources.base import DataSource, SourceResult, SourceTier
except ImportError:
    try:
        from pssr_regime_engine.datasources.base import DataSource, SourceResult, SourceTier
    except ImportError:
        raise ImportError(
            "qazstack.databus.lake_to_pssr requires pssr-regime-engine's DataSource base class. "
            "This module is designed to be used within the pssr-regime-engine project context. "
            "Ensure 'src.datasources.base' or 'pssr_regime_engine.datasources.base' is importable."
        )

logger = logging.getLogger(__name__)

# DSN must be supplied by config or QAZLAKE_DSN. Do not ship credential fallbacks.
DEFAULT_DSN = os.getenv("QAZLAKE_DSN")

# Baseline: expected articles per hour (for spike detection)
BASELINE_ARTICLES_PER_HOUR = 12  # ~288/day is normal for KZ news


class QazLakeSource(DataSource):
    """QazLake data lake – aggregated media + NLP + crisis signals."""

    def __init__(self, config: dict | None = None):
        super().__init__(
            source_id="qazlake",
            name="QazLake (дата-озеро)",
            tier=SourceTier.INTERNAL,
            timeout_sec=15.0,
            config=config or {},
        )
        self._dsn = self.config.get("dsn") or DEFAULT_DSN
        self._window_hours = self.config.get("window_hours", 6)
        self._connector = None

    def _get_connector(self):
        if self._connector is None:
            if not self._dsn:
                raise RuntimeError("QAZLAKE_DSN or config['dsn'] is required for QazLakeSource")
            try:
                from src.datasources.sources.db_connector import ExternalDBConnector
            except ImportError:
                from pssr_regime_engine.datasources.sources.db_connector import ExternalDBConnector
            self._connector = ExternalDBConnector(dsn=self._dsn)
        return self._connector

    async def fetch_raw(self) -> dict:
        """Fetch aggregated data from QazLake's PostgreSQL."""
        conn = self._get_connector()
        cutoff = datetime.now(timezone.utc) - timedelta(hours=self._window_hours)
        cutoff_str = cutoff.isoformat()

        # 1. Article volume – total + hourly breakdown
        volume_stats = await conn.fetch_one(
            """
            SELECT
                count(*) as total,
                count(*) FILTER (WHERE pub_date > %s) as recent,
                count(DISTINCT source_name) as active_sources,
                count(*) FILTER (WHERE is_breaking = true AND pub_date > %s) as breaking
            FROM articles
            WHERE pub_date > %s
            """,
            (cutoff_str, cutoff_str, cutoff_str),
        )

        # 2. Hourly volume breakdown (for spike detection)
        hourly_volume = await conn.fetch_all(
            """
            SELECT
                date_trunc('hour', pub_date) as hour,
                count(*) as cnt
            FROM articles
            WHERE pub_date > %s
            GROUP BY 1
            ORDER BY 1 DESC
            """,
            (cutoff_str,),
        )

        # 3. Language distribution (media diversity indicator)
        lang_dist = await conn.fetch_all(
            """
            SELECT lang, count(*) as cnt
            FROM articles
            WHERE pub_date > %s
            GROUP BY lang
            ORDER BY cnt DESC
            """,
            (cutoff_str,),
        )

        # 4. Sentiment distribution from NLP
        sentiment_data = await conn.fetch_all(
            """
            SELECT
                n.sentiment,
                count(*) as cnt,
                avg(n.sentiment_score) as avg_score,
                avg(n.importance) as avg_importance
            FROM article_nlp n
            JOIN articles a ON a.id = n.article_id
            WHERE a.pub_date > %s
            GROUP BY n.sentiment
            """,
            (cutoff_str,),
        )

        # 5. High-toxicity articles (negative + low score)
        toxic_articles = await conn.fetch_all(
            """
            SELECT
                a.title,
                a.source_name,
                a.pub_date,
                n.sentiment_score,
                n.importance
            FROM article_nlp n
            JOIN articles a ON a.id = n.article_id
            WHERE a.pub_date > %s
              AND n.sentiment = 'negative'
              AND n.sentiment_score < 0.5
            ORDER BY n.sentiment_score ASC
            LIMIT 10
            """,
            (cutoff_str,),
        )

        # 6. Top topics from NLP
        top_topics = await conn.fetch_all(
            """
            SELECT
                topic,
                count(*) as cnt
            FROM (
                SELECT jsonb_array_elements_text(n.topics) as topic
                FROM article_nlp n
                JOIN articles a ON a.id = n.article_id
                WHERE a.pub_date > %s
                  AND n.topics IS NOT NULL
                  AND jsonb_array_length(n.topics) > 0
            ) sub
            GROUP BY topic
            ORDER BY cnt DESC
            LIMIT 15
            """,
            (cutoff_str,),
        )

        # 7. Active crisis events (recent, non-historical)
        crisis_events = await conn.fetch_all(
            """
            SELECT
                id, title, severity, status, location,
                reported_at, tags, pssr_risk_score
            FROM crisis_events
            WHERE reported_at > %s
              AND status NOT IN ('resolved', 'historical')
            ORDER BY reported_at DESC
            LIMIT 20
            """,
            (cutoff_str,),
        )

        # 8. Crisis severity summary
        crisis_summary = await conn.fetch_all(
            """
            SELECT
                severity,
                count(*) as cnt,
                avg(pssr_risk_score) as avg_risk
            FROM crisis_events
            WHERE reported_at > %s
              AND status NOT IN ('resolved', 'historical')
            GROUP BY severity
            """,
            (cutoff_str,),
        )

        return {
            "volume_stats": volume_stats or {"total": 0, "recent": 0, "active_sources": 0, "breaking": 0},
            "hourly_volume": hourly_volume,
            "lang_dist": lang_dist,
            "sentiment_data": sentiment_data,
            "toxic_articles": toxic_articles,
            "top_topics": top_topics,
            "crisis_events": crisis_events,
            "crisis_summary": crisis_summary,
            "window_hours": self._window_hours,
            "cutoff": cutoff_str,
        }

    def parse(self, raw_data: dict) -> SourceResult:
        """Transform QazLake data into PSSR signals."""
        now = datetime.now(timezone.utc).isoformat()
        window_h = raw_data.get("window_hours", 6)

        # ── Volume signals (l_narrative) ──
        vol = raw_data["volume_stats"]
        total_articles = int(vol.get("total", 0) or 0)
        active_sources = int(vol.get("active_sources", 0) or 0)
        breaking_count = int(vol.get("breaking", 0) or 0)

        # Spike detection: max hourly volume vs baseline
        hourly = raw_data.get("hourly_volume", [])
        max_hourly = max((int(h.get("cnt", 0) or 0) for h in hourly), default=0)
        spike_ratio = max_hourly / max(BASELINE_ARTICLES_PER_HOUR, 1)

        # Volume stress: 1.0 = double the expected total
        expected_total = BASELINE_ARTICLES_PER_HOUR * window_h
        volume_stress = min(1.0, total_articles / max(expected_total * 2, 1))

        # ── Sentiment signals (l_toxicity) ──
        sentiment_map: dict[str, dict] = {}
        for row in raw_data.get("sentiment_data", []):
            label = row.get("sentiment", "unknown")
            sentiment_map[label] = {
                "count": int(row.get("cnt", 0) or 0),
                "avg_score": float(row.get("avg_score", 0) or 0),
                "avg_importance": float(row.get("avg_importance", 0) or 0),
            }

        neg = sentiment_map.get("negative", {"count": 0, "avg_score": 0, "avg_importance": 0})
        pos = sentiment_map.get("positive", {"count": 0, "avg_score": 0, "avg_importance": 0})
        neu = sentiment_map.get("neutral", {"count": 0, "avg_score": 0, "avg_importance": 0})

        total_analyzed = neg["count"] + pos["count"] + neu["count"]
        neg_ratio = neg["count"] / max(total_analyzed, 1)

        # Weighted toxicity: importance-weighted negative ratio
        if total_analyzed > 0 and neg["avg_importance"] > 0:
            toxicity_weighted = neg_ratio * (neg["avg_importance"] / 5.0)
        else:
            toxicity_weighted = neg_ratio

        # Sentiment index: -1 (all negative) to +1 (all positive)
        if total_analyzed > 0:
            sentiment_index = (pos["count"] - neg["count"]) / total_analyzed
        else:
            sentiment_index = 0.0

        # ── Crisis signals ──
        crisis_events = raw_data.get("crisis_events", [])
        crisis_count = len(crisis_events)

        crisis_severity_map: dict[str, int] = {}
        for row in raw_data.get("crisis_summary", []):
            sev = row.get("severity", "unknown")
            crisis_severity_map[sev] = int(row.get("cnt", 0) or 0)

        critical_count = crisis_severity_map.get("critical", 0) + crisis_severity_map.get("high", 0)
        medium_count = crisis_severity_map.get("medium", 0)

        # Crisis stress: weighted by severity
        crisis_stress = min(1.0, (critical_count * 0.4 + medium_count * 0.15 + crisis_count * 0.05))

        # Max risk score from crisis events
        max_risk = 0.0
        for ev in crisis_events:
            risk = float(ev.get("pssr_risk_score", 0) or 0)
            if risk > max_risk:
                max_risk = risk

        # ── Language diversity (media pluralism indicator) ──
        lang_dist = raw_data.get("lang_dist", [])
        total_lang = sum(int(row.get("cnt", 0) or 0) for row in lang_dist)
        kz_ratio = 0.0
        ru_ratio = 0.0
        for row in lang_dist:
            lang = row.get("lang", "")
            cnt = int(row.get("cnt", 0) or 0)
            if lang == "kk":
                kz_ratio = cnt / max(total_lang, 1)
            elif lang == "ru":
                ru_ratio = cnt / max(total_lang, 1)

        # ── Composite media stress (0..1) ──
        media_stress = 0.30 * volume_stress + 0.35 * toxicity_weighted + 0.35 * crisis_stress

        # ── Confidence ──
        if total_articles == 0:
            confidence = 0.1
        elif total_articles < 10:
            confidence = 0.3
        elif total_analyzed < 5:
            confidence = 0.5
        else:
            confidence = min(0.92, 0.65 + total_articles * 0.0005)

        # ── Events ──
        events = []

        # Spike event
        if spike_ratio > 2.0:
            events.append(
                {
                    "type": "media_spike",
                    "text": f"Всплеск: {max_hourly} статей/час (норма ~{BASELINE_ARTICLES_PER_HOUR})",
                    "spike_ratio": round(spike_ratio, 2),
                }
            )

        # Breaking news
        if breaking_count > 0:
            events.append(
                {
                    "type": "breaking_news",
                    "text": f"{breaking_count} срочных новостей за {window_h}ч",
                    "count": breaking_count,
                }
            )

        # Toxic articles
        for art in raw_data.get("toxic_articles", [])[:5]:
            events.append(
                {
                    "type": "toxic_article",
                    "text": str(art.get("title", ""))[:200],
                    "source": str(art.get("source_name", "")),
                    "score": float(art.get("sentiment_score", 0) or 0),
                }
            )

        # Crisis events
        for ev in crisis_events[:5]:
            events.append(
                {
                    "type": "crisis",
                    "text": str(ev.get("title", ""))[:200],
                    "severity": str(ev.get("severity", "")),
                    "location": str(ev.get("location", "")),
                    "risk_score": float(ev.get("pssr_risk_score", 0) or 0),
                }
            )

        # Top topics
        topics = raw_data.get("top_topics", [])
        if topics:
            events.append(
                {
                    "type": "top_topics",
                    "topics": [{"topic": t.get("topic", ""), "count": int(t.get("cnt", 0) or 0)} for t in topics[:10]],
                }
            )

        return SourceResult(
            source_id=self.source_id,
            source_name=self.name,
            tier=self.tier,
            timestamp=now,
            confidence=round(confidence, 3),
            signals={
                # l_narrative signals
                "lake_article_volume": float(total_articles),
                "lake_article_hourly_max": float(max_hourly),
                "lake_spike_ratio": round(spike_ratio, 3),
                "lake_active_sources": float(active_sources),
                "lake_breaking_count": float(breaking_count),
                "lake_volume_stress": round(volume_stress, 4),
                # l_toxicity signals
                "lake_sentiment_index": round(sentiment_index, 4),
                "lake_neg_ratio": round(neg_ratio, 4),
                "lake_toxicity_weighted": round(toxicity_weighted, 4),
                "lake_nlp_analyzed": float(total_analyzed),
                # crisis signals
                "lake_crisis_count": float(crisis_count),
                "lake_crisis_critical": float(critical_count),
                "lake_crisis_max_risk": round(max_risk, 4),
                "lake_crisis_stress": round(crisis_stress, 4),
                # composite
                "lake_media_stress": round(media_stress, 4),
                # diversity
                "lake_kz_ratio": round(kz_ratio, 4),
                "lake_ru_ratio": round(ru_ratio, 4),
            },
            events=events[:20],
            raw_meta={
                "total_articles": total_articles,
                "total_analyzed": total_analyzed,
                "sentiment_map": {k: v["count"] for k, v in sentiment_map.items()},
                "crisis_severity_map": crisis_severity_map,
                "window_hours": window_h,
                "lang_dist": {row.get("lang", "?"): int(row.get("cnt", 0) or 0) for row in lang_dist},
            },
        )

    async def health_check(self) -> bool:
        """Check if QazLake DB is reachable."""
        try:
            conn = self._get_connector()
            return await conn.health_check()
        except Exception:
            return False
