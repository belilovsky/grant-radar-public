"""Unified Entity Enricher – Phase 4 of the Data Bus.

Links entities from Echo Sounder, Crisis Monitor, and Editorial
back to QazLake canonical_entities for unified entity resolution.

Pipelines:
  A) Echo Sounder nlp_entities → QazLake echo_entity_links
  B) Crisis entity_links → canonical_entity_id backfill
  C) Editorial research_bank → NER → QazLake editorial_entity_links

Usage:
    from qazstack.databus.entity_enricher import EntityEnricher

    enricher = EntityEnricher(
        lake_dsn="postgresql+asyncpg://qazlake:pass@127.0.0.1:5441/qazlake",
        echo_dsn="postgresql+asyncpg://echo:pass@127.0.0.1:5435/echo_sounder",
        editorial_dsn="postgresql+asyncpg://editorial:pass@127.0.0.1:5443/editorial",
    )
    result = await enricher.run()
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone

from sqlalchemy import text
from sqlalchemy.ext.asyncio import create_async_engine

from qazstack.databus.sync import SyncPipeline, SyncResult

logger = logging.getLogger(__name__)

# Echo labels that map to person-type canonical entities
PERSON_LABELS = {"PER", "LAST_NAME", "FIRST_NAME", "MIDDLE_NAME"}
ORG_LABELS = {"ORG"}
# Geo labels – skip for canonical matching (canonical has no geo)
GEO_LABELS = {"LOC", "CITY", "COUNTRY", "REGION", "DISTRICT", "STREET", "HOUSE"}

# Minimum trigram similarity for fuzzy matching
FUZZY_THRESHOLD = 0.6

# Schema DDL blocks – each one is executed as a complete statement
SCHEMA_DDL_BLOCKS = [
    # 1. Echo Sounder entity links table
    """
    CREATE TABLE IF NOT EXISTS echo_entity_links (
        id SERIAL PRIMARY KEY,
        echo_entity_id INTEGER NOT NULL,
        echo_entity_text VARCHAR NOT NULL,
        echo_entity_label VARCHAR NOT NULL,
        echo_source_table VARCHAR NOT NULL,
        echo_source_id INTEGER NOT NULL,
        canonical_entity_id INTEGER REFERENCES canonical_entities(id),
        match_type VARCHAR NOT NULL DEFAULT 'none',
        confidence FLOAT NOT NULL DEFAULT 0.0,
        created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_echo_el_canonical ON echo_entity_links(canonical_entity_id)",
    "CREATE INDEX IF NOT EXISTS idx_echo_el_echo_id ON echo_entity_links(echo_entity_id)",
    # 2. Editorial entity links table
    """
    CREATE TABLE IF NOT EXISTS editorial_entity_links (
        id SERIAL PRIMARY KEY,
        research_bank_id BIGINT NOT NULL,
        canonical_entity_id INTEGER REFERENCES canonical_entities(id),
        entity_text VARCHAR NOT NULL,
        entity_label VARCHAR NOT NULL DEFAULT 'PER',
        mention_count INTEGER NOT NULL DEFAULT 1,
        relevance FLOAT NOT NULL DEFAULT 0.0,
        created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_editorial_el_canonical ON editorial_entity_links(canonical_entity_id)",
    "CREATE INDEX IF NOT EXISTS idx_editorial_el_rb ON editorial_entity_links(research_bank_id)",
    # 3. Add canonical_entity_id to crisis_entity_links
    """
    DO $$
    BEGIN
        IF NOT EXISTS (
            SELECT 1 FROM information_schema.columns
            WHERE table_name = 'crisis_entity_links' AND column_name = 'canonical_entity_id'
        ) THEN
            ALTER TABLE crisis_entity_links ADD COLUMN canonical_entity_id INTEGER REFERENCES canonical_entities(id);
        END IF;
    END $$
    """,
    "CREATE INDEX IF NOT EXISTS idx_crisis_el_canonical ON crisis_entity_links(canonical_entity_id)",
]


@dataclass
class EnrichResult:
    """Result of entity enrichment."""

    pipeline: str = "entity_enricher"
    started_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    finished_at: datetime | None = None
    echo_matched: int = 0
    echo_unmatched: int = 0
    echo_skipped_geo: int = 0
    crisis_linked: int = 0
    editorial_extracted: int = 0
    editorial_matched: int = 0
    errors: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return len(self.errors) == 0

    def finish(self) -> EnrichResult:
        self.finished_at = datetime.now(timezone.utc)
        return self

    def to_dict(self) -> dict:
        return {
            "pipeline": self.pipeline,
            "ok": self.ok,
            "started_at": self.started_at.isoformat(),
            "finished_at": self.finished_at.isoformat() if self.finished_at else None,
            "echo_matched": self.echo_matched,
            "echo_unmatched": self.echo_unmatched,
            "echo_skipped_geo": self.echo_skipped_geo,
            "crisis_linked": self.crisis_linked,
            "editorial_extracted": self.editorial_extracted,
            "editorial_matched": self.editorial_matched,
            "errors": self.errors,
        }


class EntityEnricher(SyncPipeline):
    """Enriches entities across all projects with canonical entity links."""

    name = "entity_enricher"

    def __init__(
        self,
        lake_dsn: str,
        echo_dsn: str | None = None,
        editorial_dsn: str | None = None,
    ):
        self.lake_engine = create_async_engine(lake_dsn, pool_size=5, echo=False)
        self.echo_engine = create_async_engine(echo_dsn, pool_size=3, echo=False) if echo_dsn else None
        self.editorial_engine = create_async_engine(editorial_dsn, pool_size=3, echo=False) if editorial_dsn else None
        self._canonical_cache: dict[int, dict] = {}
        self._name_index: dict[str, int] = {}  # lowered name → canonical_id
        self._alias_index: dict[str, int] = {}  # lowered alias → canonical_id

    async def run(self, **kwargs) -> SyncResult:
        """Run all enrichment pipelines."""
        result = EnrichResult()
        try:
            await self._ensure_schema()
            await self._load_canonical_cache()
            logger.info(
                "Canonical cache loaded: %d entities, %d aliases", len(self._canonical_cache), len(self._alias_index)
            )

            # Phase A: Echo Sounder → canonical
            if self.echo_engine:
                await self._enrich_echo(result)

            # Phase B: Crisis → canonical backfill
            await self._enrich_crisis(result)

            # Phase C: Editorial → NER → canonical
            if self.editorial_engine:
                await self._enrich_editorial(result)

        except Exception as e:
            logger.exception("EntityEnricher failed: %s", e)
            result.errors.append(str(e))
        finally:
            result.finish()
            await self.lake_engine.dispose()
            if self.echo_engine:
                await self.echo_engine.dispose()
            if self.editorial_engine:
                await self.editorial_engine.dispose()

        logger.info("EntityEnricher done: %s", result.to_dict())

        # Convert to SyncResult for compatibility
        sr = SyncResult(pipeline=self.name)
        sr.entities_synced = result.echo_matched + result.crisis_linked + result.editorial_matched
        sr.errors = result.errors
        sr.finished_at = result.finished_at
        sr.started_at = result.started_at
        return sr

    async def _ensure_schema(self):
        """Create tables if not exist."""
        async with self.lake_engine.begin() as conn:
            for stmt in SCHEMA_DDL_BLOCKS:
                stmt = stmt.strip()
                if stmt:
                    await conn.execute(text(stmt))
        logger.info("Schema ensured (echo_entity_links, editorial_entity_links, crisis canonical_entity_id)")

    async def _load_canonical_cache(self):
        """Load all canonical entities into memory for fast matching."""
        async with self.lake_engine.connect() as conn:
            rows = await conn.execute(
                text("SELECT id, entity_type, name_ru, name_kz, name_en, aliases FROM canonical_entities")
            )
            for row in rows.mappings():
                ce = dict(row)
                self._canonical_cache[ce["id"]] = ce

                # Index by name_ru (lowered)
                if ce["name_ru"]:
                    self._name_index[ce["name_ru"].lower().strip()] = ce["id"]
                if ce["name_kz"]:
                    self._name_index[ce["name_kz"].lower().strip()] = ce["id"]
                if ce["name_en"]:
                    self._name_index[ce["name_en"].lower().strip()] = ce["id"]

                # Index all aliases
                aliases = ce.get("aliases") or []
                if isinstance(aliases, str):
                    import json

                    try:
                        aliases = json.loads(aliases)
                    except Exception:
                        aliases = []
                for alias in aliases:
                    if alias:
                        self._alias_index[alias.lower().strip()] = ce["id"]

    def _match_entity(self, entity_text: str) -> tuple[int | None, str, float]:
        """Match entity text to canonical. Returns (canonical_id, match_type, confidence)."""
        normalized = entity_text.strip()
        lowered = normalized.lower()

        # 1. Exact match on name
        if lowered in self._name_index:
            return self._name_index[lowered], "exact", 1.0

        # 2. Alias match
        if lowered in self._alias_index:
            return self._alias_index[lowered], "alias", 0.95

        return None, "none", 0.0

    async def _fuzzy_match(self, entity_text: str) -> tuple[int | None, str, float]:
        """Fuzzy match via pg_trgm in DB."""
        async with self.lake_engine.connect() as conn:
            row = await conn.execute(
                text("""
                SELECT id, similarity(LOWER(name_ru), LOWER(:txt)) as sim
                FROM canonical_entities
                WHERE similarity(LOWER(name_ru), LOWER(:txt)) > :threshold
                ORDER BY sim DESC LIMIT 1
            """),
                {"txt": entity_text.strip(), "threshold": FUZZY_THRESHOLD},
            )
            r = row.mappings().first()
            if r:
                return r["id"], "fuzzy", float(r["sim"])
        return None, "none", 0.0

    # ── Phase A: Echo Sounder ──────────────────────────────────────

    async def _enrich_echo(self, result: EnrichResult):
        """Link Echo Sounder nlp_entities to canonical_entities."""
        logger.info("Phase A: Echo Sounder entity enrichment")

        # Check which echo_entity_ids we already processed
        async with self.lake_engine.connect() as conn:
            existing = await conn.execute(text("SELECT COALESCE(MAX(echo_entity_id), 0) FROM echo_entity_links"))
            max_processed = existing.scalar() or 0
        logger.info("Echo: already processed up to echo_entity_id=%d", max_processed)

        # Read new Echo entities (PER/ORG only, skip geo)
        batch_size = 5000
        offset = 0
        total_matched = 0
        total_unmatched = 0
        total_geo = 0

        while True:
            async with self.echo_engine.connect() as conn:
                rows = await conn.execute(
                    text("""
                    SELECT id, source_table, source_id, entity_text, entity_label
                    FROM nlp_entities
                    WHERE id > :max_id
                    ORDER BY id
                    LIMIT :limit OFFSET :offset
                """),
                    {"max_id": max_processed, "limit": batch_size, "offset": offset},
                )
                batch = list(rows.mappings())

            if not batch:
                break

            inserts = []
            for ent in batch:
                label = ent["entity_label"]

                # Skip geo entities
                if label in GEO_LABELS:
                    total_geo += 1
                    continue

                entity_text = ent["entity_text"].strip()
                if not entity_text or entity_text == "-":
                    continue

                # Try in-memory match first
                canonical_id, match_type, confidence = self._match_entity(entity_text)

                # Fuzzy fallback for unmatched persons
                if canonical_id is None and label in PERSON_LABELS and len(entity_text) > 3:
                    canonical_id, match_type, confidence = await self._fuzzy_match(entity_text)

                if canonical_id:
                    total_matched += 1
                else:
                    total_unmatched += 1

                inserts.append(
                    {
                        "echo_entity_id": ent["id"],
                        "echo_entity_text": entity_text,
                        "echo_entity_label": label,
                        "echo_source_table": ent["source_table"],
                        "echo_source_id": ent["source_id"],
                        "canonical_entity_id": canonical_id,
                        "match_type": match_type,
                        "confidence": confidence,
                    }
                )

            # Batch insert
            if inserts:
                async with self.lake_engine.begin() as conn:
                    await conn.execute(
                        text("""
                        INSERT INTO echo_entity_links
                            (echo_entity_id, echo_entity_text, echo_entity_label,
                             echo_source_table, echo_source_id,
                             canonical_entity_id, match_type, confidence)
                        VALUES
                            (:echo_entity_id, :echo_entity_text, :echo_entity_label,
                             :echo_source_table, :echo_source_id,
                             :canonical_entity_id, :match_type, :confidence)
                    """),
                        inserts,
                    )

            offset += batch_size
            logger.info(
                "Echo batch %d: %d entities, %d matched so far", offset // batch_size, len(batch), total_matched
            )

            if len(batch) < batch_size:
                break

        result.echo_matched = total_matched
        result.echo_unmatched = total_unmatched
        result.echo_skipped_geo = total_geo
        logger.info("Phase A done: matched=%d, unmatched=%d, geo_skipped=%d", total_matched, total_unmatched, total_geo)

    # ── Phase B: Crisis Monitor ────────────────────────────────────

    async def _enrich_crisis(self, result: EnrichResult):
        """Backfill canonical_entity_id in crisis_entity_links."""
        logger.info("Phase B: Crisis Monitor canonical backfill")

        async with self.lake_engine.begin() as conn:
            # Update all crisis_entity_links where canonical_entity_id is NULL
            # by joining qazpolit_entity_id → canonical_entities.source_id
            r = await conn.execute(
                text("""
                UPDATE crisis_entity_links cel
                SET canonical_entity_id = ce.id
                FROM canonical_entities ce
                WHERE ce.source_project = 'qazpolit'
                  AND ce.source_id = cel.qazpolit_entity_id
                  AND cel.canonical_entity_id IS NULL
            """)
            )
            result.crisis_linked = r.rowcount
            logger.info("Phase B done: %d crisis links updated", r.rowcount)

    # ── Phase C: Editorial ─────────────────────────────────────────

    async def _enrich_editorial(self, result: EnrichResult):
        """Extract entities from Editorial research_bank and link to canonical."""
        logger.info("Phase C: Editorial entity enrichment")

        # Read research_bank content
        async with self.editorial_engine.connect() as conn:
            rows = await conn.execute(text("SELECT id, content FROM editorial.research_bank"))
            articles = list(rows.mappings())

        if not articles:
            logger.info("Phase C: no articles in research_bank")
            return

        # Check already processed
        async with self.lake_engine.connect() as conn:
            existing = await conn.execute(text("SELECT DISTINCT research_bank_id FROM editorial_entity_links"))
            processed_ids = {r[0] for r in existing}

        # Try to use kznlp for NER, fallback to simple matching
        try:
            from qazstack.kznlp import extract_entities

            use_ner = True
        except ImportError:
            logger.warning("kznlp not available, falling back to dictionary match")
            use_ner = False

        total_extracted = 0
        total_matched = 0

        for art in articles:
            if art["id"] in processed_ids:
                continue

            content = art["content"] or ""
            if not content.strip():
                continue

            content_lower = content.lower()

            # Extract entities
            if use_ner:
                ner_entities = extract_entities(content[:5000])  # limit text length
                entities_found = [(e.text, e.label) for e in ner_entities]
            else:
                # Fallback: match canonical names directly in text
                entities_found = []
                for ce_id, ce in self._canonical_cache.items():
                    name = ce.get("name_ru", "")
                    if name and name.lower() in content_lower:
                        entities_found.append((name, "PER"))

            total_extracted += len(entities_found)

            # Deduplicate and match to canonical
            seen = set()
            inserts = []
            for ent_text, ent_label in entities_found:
                key = ent_text.lower().strip()
                if key in seen or len(key) < 3:
                    continue
                seen.add(key)

                canonical_id, match_type, confidence = self._match_entity(ent_text)
                if canonical_id is None:
                    canonical_id, match_type, confidence = await self._fuzzy_match(ent_text)

                if canonical_id:
                    total_matched += 1
                    # Count mentions
                    mention_count = content_lower.count(ent_text.lower())
                    inserts.append(
                        {
                            "research_bank_id": art["id"],
                            "canonical_entity_id": canonical_id,
                            "entity_text": ent_text.strip(),
                            "entity_label": ent_label,
                            "mention_count": max(mention_count, 1),
                            "relevance": confidence,
                        }
                    )

            if inserts:
                async with self.lake_engine.begin() as conn:
                    await conn.execute(
                        text("""
                        INSERT INTO editorial_entity_links
                            (research_bank_id, canonical_entity_id, entity_text,
                             entity_label, mention_count, relevance)
                        VALUES
                            (:research_bank_id, :canonical_entity_id, :entity_text,
                             :entity_label, :mention_count, :relevance)
                    """),
                        inserts,
                    )

        result.editorial_extracted = total_extracted
        result.editorial_matched = total_matched
        logger.info("Phase C done: extracted=%d, matched=%d", total_extracted, total_matched)
