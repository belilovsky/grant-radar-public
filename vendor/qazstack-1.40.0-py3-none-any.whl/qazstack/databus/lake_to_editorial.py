"""QazLake → Editorial research_bank sync.

Periodically fills editorial.research_bank with recent high-quality articles
from QazLake, filtered by author domain scopes. Each article gets:
  - content (title + excerpt, max 2000 chars)
  - embedding from QazCompute (1024-dim multilingual-e5-large)
  - topic_tags extracted from NLP topics + categories
  - quality_score from NLP importance (1-5 → 0.2-1.0)

Designed to run as ARQ cron job inside editorial_worker every 6h.
Falls back gracefully: skips embedding if QazCompute is down, inserts without it.

Tables used:
  READ:  qazlake.articles, qazlake.article_nlp, qazlake.canonical_entities,
         qazlake.article_entities, editorial.authors
  WRITE: editorial.research_bank
"""

from __future__ import annotations

import logging
import os
from datetime import datetime, timedelta, timezone
from typing import Any

from sqlalchemy import text
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)

logger = logging.getLogger(__name__)

# ── Defaults ─────────────────────────────────────────────────────────────────

DEFAULT_QAZLAKE_DSN = os.environ.get("EDITORIAL_QAZLAKE_DB_URL")
DEFAULT_EDITORIAL_DSN = os.environ.get("EDITORIAL_DB_URL")
DEFAULT_QAZCOMPUTE_URL = os.environ.get("EDITORIAL_QAZCOMPUTE_URL", "http://qazcompute_app:8000")
DEFAULT_QAZCOMPUTE_KEY = os.environ.get("EDITORIAL_QAZCOMPUTE_KEY")

# How many hours back to look for articles
DEFAULT_WINDOW_HOURS = 24
# Max articles per sync cycle
MAX_ARTICLES_PER_SYNC = 200
# Min NLP importance to include (1-5 scale)
MIN_IMPORTANCE = 2
# Batch size for embedding requests
EMBEDDING_BATCH_SIZE = 10


class LakeToEditorialSync:
    """Sync QazLake articles → editorial.research_bank.

    Usage:
        sync = LakeToEditorialSync()
        result = await sync.run()
        print(result)  # {'synced': 45, 'skipped': 12, 'errors': 0}
    """

    def __init__(
        self,
        qazlake_dsn: str | None = None,
        editorial_dsn: str | None = None,
        qazcompute_url: str | None = None,
        qazcompute_key: str | None = None,
        window_hours: int = DEFAULT_WINDOW_HOURS,
        editorial_session_factory: async_sessionmaker | None = None,
        qazlake_session_factory: async_sessionmaker | None = None,
        compute_client: Any = None,
    ):
        self._qazlake_dsn = qazlake_dsn or DEFAULT_QAZLAKE_DSN
        self._editorial_dsn = editorial_dsn or DEFAULT_EDITORIAL_DSN
        self._qazcompute_url = qazcompute_url or DEFAULT_QAZCOMPUTE_URL
        self._qazcompute_key = qazcompute_key or DEFAULT_QAZCOMPUTE_KEY
        self._window_hours = window_hours

        # External session factories (injected from worker context)
        self._ext_editorial_factory = editorial_session_factory
        self._ext_qazlake_factory = qazlake_session_factory
        self._ext_compute_client = compute_client

        # Lazy-init engines
        self._qazlake_engine: AsyncEngine | None = None
        self._editorial_engine: AsyncEngine | None = None

    # ── Public API ────────────────────────────────────────────────────────

    async def run(self) -> dict:
        """Execute a full sync cycle.

        Returns:
            Dict with keys: synced, skipped, errors, duration_ms
        """
        import time

        t0 = time.monotonic()

        try:
            # 1. Get author domains for filtering
            author_domains = await self._get_author_domains()
            all_domains = set()
            for domains in author_domains.values():
                all_domains.update(domains)
            logger.info(
                "Sync starting: %d authors, %d unique domains, window=%dh",
                len(author_domains),
                len(all_domains),
                self._window_hours,
            )

            # 2. Fetch candidate articles from QazLake
            articles = await self._fetch_articles()
            logger.info("Fetched %d candidate articles from QazLake", len(articles))

            if not articles:
                return {"synced": 0, "skipped": 0, "errors": 0, "duration_ms": round((time.monotonic() - t0) * 1000)}

            # 3. Get existing URLs to avoid duplicates
            existing_urls = await self._get_existing_urls()

            # 4. Filter and tag articles
            to_insert = []
            skipped = 0
            for art in articles:
                url = art.get("url", "")
                if url in existing_urls:
                    skipped += 1
                    continue

                # Build content: title + excerpt/body (max 2000 chars)
                title = art.get("title", "")
                body = art.get("body_text", "") or art.get("excerpt", "") or ""
                content = f"{title}\n\n{body}".strip()[:2000]
                if len(content) < 50:
                    skipped += 1
                    continue

                # Extract topic tags from NLP topics + category
                tags = self._extract_tags(art)

                # Quality score: importance (1-5) → (0.2-1.0)
                importance = art.get("importance") or 3
                quality = min(1.0, max(0.2, importance / 5.0))

                to_insert.append(
                    {
                        "content": content,
                        "source_url": url,
                        "source_type": "article",
                        "topic_tags": tags,
                        "lang": art.get("lang", "ru"),
                        "quality_score": quality,
                        "pub_date": art.get("pub_date"),
                    }
                )

            logger.info(
                "After filtering: %d to insert, %d skipped (duplicates/short)",
                len(to_insert),
                skipped,
            )

            # 5. Get embeddings in batches
            to_insert = await self._add_embeddings(to_insert)

            # 6. Insert into research_bank
            synced, errors = await self._insert_batch(to_insert)

            duration = round((time.monotonic() - t0) * 1000)
            result = {
                "synced": synced,
                "skipped": skipped,
                "errors": errors,
                "duration_ms": duration,
                "total_candidates": len(articles),
            }
            logger.info(
                "Sync complete: %d synced, %d skipped, %d errors, %dms",
                synced,
                skipped,
                errors,
                duration,
            )
            return result

        except Exception as exc:
            duration = round((time.monotonic() - t0) * 1000)
            logger.exception("Sync failed: %s", exc)
            return {"synced": 0, "skipped": 0, "errors": 1, "error": str(exc), "duration_ms": duration}

    # ── Data fetching ─────────────────────────────────────────────────────

    async def _get_author_domains(self) -> dict[str, list[str]]:
        """Fetch author domains from editorial.authors."""
        async with self._get_editorial_session() as session:
            result = await session.execute(
                text("SELECT author_id, domain_scope FROM editorial.authors WHERE is_active = true")
            )
            return {
                row.author_id: (row.domain_scope if isinstance(row.domain_scope, list) else [])
                for row in result.fetchall()
            }

    async def _fetch_articles(self) -> list[dict]:
        """Fetch recent high-quality articles from QazLake + NLP data."""
        cutoff = datetime.now(timezone.utc) - timedelta(hours=self._window_hours)

        sql = text("""
            SELECT
                a.id,
                a.title,
                COALESCE(a.excerpt, LEFT(a.body_text, 1500)) AS body_text,
                a.url,
                a.pub_date::text,
                a.lang,
                a.source_name,
                a.category_id,
                a.sub_category,
                n.sentiment,
                n.sentiment_score,
                n.importance,
                n.topics,
                n.geo_focus
            FROM articles a
            LEFT JOIN article_nlp n ON n.article_id = a.id
            WHERE a.pub_date > :cutoff
              AND a.status = 'published'
              AND LENGTH(COALESCE(a.title, '')) > 10
            ORDER BY
                COALESCE(n.importance, 3) DESC,
                a.pub_date DESC
            LIMIT :limit
        """)

        async with self._get_qazlake_session() as session:
            result = await session.execute(sql, {"cutoff": cutoff, "limit": MAX_ARTICLES_PER_SYNC})
            return [dict(row._mapping) for row in result.fetchall()]

    async def _get_existing_urls(self) -> set[str]:
        """Get source_urls already in research_bank to avoid duplicates."""
        async with self._get_editorial_session() as session:
            result = await session.execute(
                text("SELECT source_url FROM editorial.research_bank WHERE source_url IS NOT NULL")
            )
            return {row.source_url for row in result.fetchall()}

    # ── Embedding ─────────────────────────────────────────────────────────

    async def _add_embeddings(self, articles: list[dict]) -> list[dict]:
        """Add embedding field to articles via QazCompute API.

        QazCompute expects: POST /api/v1/embeddings
            body: {"texts": ["text1", "text2", ...]}
            response: {"vectors": [[...], [...]], "dimension": 1024, "count": N}
        """
        import httpx

        client = self._ext_compute_client
        should_close = False
        if client is None:
            client = httpx.AsyncClient(timeout=60.0)
            should_close = True

        embedded = 0
        failed = 0

        try:
            for i in range(0, len(articles), EMBEDDING_BATCH_SIZE):
                batch = articles[i : i + EMBEDDING_BATCH_SIZE]
                texts = [art["content"][:500] for art in batch]  # Short text for embedding

                try:
                    response = await client.post(
                        f"{self._qazcompute_url}/api/v1/embeddings",
                        json={"texts": texts},
                        headers=self._embedding_headers(),
                    )
                    response.raise_for_status()
                    data = response.json()

                    # QazCompute response format: {"vectors": [[...], ...], "dimension": 1024}
                    vectors = data.get("vectors", [])
                    for j, vec in enumerate(vectors):
                        if j < len(batch):
                            batch[j]["embedding"] = vec
                            embedded += 1

                except Exception as exc:
                    logger.warning(
                        "Embedding batch %d failed (non-critical): %s",
                        i // EMBEDDING_BATCH_SIZE,
                        exc,
                    )
                    failed += len(batch)

        finally:
            if should_close:
                await client.aclose()

        logger.info("Embeddings: %d ok, %d failed (will insert without)", embedded, failed)
        return articles

    # ── Insertion ──────────────────────────────────────────────────────────

    async def _insert_batch(self, articles: list[dict]) -> tuple[int, int]:
        """Insert articles into editorial.research_bank. Returns (synced, errors).

        asyncpg requires native Python types:
        - text[] columns need Python list (not '{a,b}' string literal)
        - vector columns need string '[0.1,0.2,...]' cast to vector
        """
        synced = 0
        errors = 0

        sql_with_emb = text("""
            INSERT INTO editorial.research_bank
                (content, embedding, source_url, source_type, topic_tags, lang, quality_score)
            VALUES
                (:content, CAST(:emb AS vector), :url, :stype, :tags, :lang, :quality)
            ON CONFLICT DO NOTHING
        """)

        sql_no_emb = text("""
            INSERT INTO editorial.research_bank
                (content, source_url, source_type, topic_tags, lang, quality_score)
            VALUES
                (:content, :url, :stype, :tags, :lang, :quality)
            ON CONFLICT DO NOTHING
        """)

        async with self._get_editorial_session() as session:
            for art in articles:
                try:
                    # Use SAVEPOINT so one bad row doesn't abort the whole tx
                    nested = await session.begin_nested()
                    try:
                        embedding = art.get("embedding")
                        tags = art.get("topic_tags", [])
                        # asyncpg needs a real Python list for text[] columns
                        tags_list = [str(t) for t in tags] if tags else []

                        params = {
                            "content": art["content"],
                            "url": art.get("source_url", ""),
                            "stype": art.get("source_type", "article"),
                            "tags": tags_list,
                            "lang": art.get("lang", "ru"),
                            "quality": art.get("quality_score", 0.5),
                        }

                        if embedding:
                            emb_str = "[" + ",".join(map(str, embedding)) + "]"
                            params["emb"] = emb_str
                            await session.execute(sql_with_emb, params)
                        else:
                            await session.execute(sql_no_emb, params)

                        await nested.commit()
                        synced += 1

                    except Exception as exc:
                        await nested.rollback()
                        logger.warning("Insert failed for %s: %s", art.get("source_url", "?")[:60], exc)
                        errors += 1

                except Exception as exc:
                    logger.warning("Savepoint failed for %s: %s", art.get("source_url", "?")[:60], exc)
                    errors += 1

            await session.commit()

        return synced, errors

    # ── Tag extraction ────────────────────────────────────────────────────

    @staticmethod
    def _extract_tags(article: dict) -> list[str]:
        """Extract topic tags from NLP topics, category, geo_focus."""
        tags: list[str] = []

        # NLP topics (jsonb array)
        topics = article.get("topics")
        if isinstance(topics, list):
            for t in topics[:5]:
                if isinstance(t, str) and t.strip():
                    tags.append(t.strip().lower())

        # Sub-category
        sub_cat = article.get("sub_category")
        if sub_cat:
            tags.append(sub_cat.lower())

        # Geo focus
        geo = article.get("geo_focus")
        if geo:
            tags.append(f"geo:{geo.lower()}")

        # Sentiment as tag
        sentiment = article.get("sentiment")
        if sentiment:
            tags.append(f"sentiment:{sentiment}")

        # Deduplicate
        return list(dict.fromkeys(tags))[:10]

    # ── Session helpers ───────────────────────────────────────────────────

    def _get_qazlake_session(self) -> AsyncSession:
        if self._ext_qazlake_factory is not None:
            return self._ext_qazlake_factory()
        if self._qazlake_engine is None:
            if not self._qazlake_dsn:
                raise RuntimeError("qazlake_dsn or EDITORIAL_QAZLAKE_DB_URL is required for LakeToEditorialSync")
            self._qazlake_engine = create_async_engine(
                self._qazlake_dsn,
                pool_size=5,
                max_overflow=10,
                pool_pre_ping=True,
            )
            self._qazlake_factory = async_sessionmaker(
                self._qazlake_engine,
                expire_on_commit=False,
            )
        return self._qazlake_factory()

    def _get_editorial_session(self) -> AsyncSession:
        if self._ext_editorial_factory is not None:
            return self._ext_editorial_factory()
        if self._editorial_engine is None:
            if not self._editorial_dsn:
                raise RuntimeError("editorial_dsn or EDITORIAL_DB_URL is required for LakeToEditorialSync")
            self._editorial_engine = create_async_engine(
                self._editorial_dsn,
                pool_size=3,
                max_overflow=5,
                pool_pre_ping=True,
            )
            self._editorial_factory = async_sessionmaker(
                self._editorial_engine,
                expire_on_commit=False,
            )
        return self._editorial_factory()

    def _embedding_headers(self) -> dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if self._qazcompute_key:
            headers["X-API-Key"] = self._qazcompute_key
        return headers

    async def close(self) -> None:
        """Dispose engines if we created them."""
        if self._qazlake_engine:
            await self._qazlake_engine.dispose()
        if self._editorial_engine:
            await self._editorial_engine.dispose()
