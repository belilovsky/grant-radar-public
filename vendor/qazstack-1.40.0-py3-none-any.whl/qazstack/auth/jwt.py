"""JWT authentication backend for FastAPI.

Provides stateless token-based auth for API endpoints.
Works alongside SessionAuth (session for SSR, JWT for API).

Requires: pip install qazstack[auth]  (includes PyJWT)

Usage:
    from qazstack.auth.jwt import JWTAuth

    jwt_auth = JWTAuth(secret_key=settings.secret_key)

    # Create token after login:
    token = jwt_auth.create_token(user_id=user.id, extra={"role": "admin"})

    # Protect routes:
    @router.get("/api/me")
    async def me(payload: dict = Depends(jwt_auth.require)):
        return {"user_id": payload["sub"]}
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

try:
    import jwt as pyjwt

    HAS_JWT = True
except ImportError:
    pyjwt = None  # type: ignore
    HAS_JWT = False


_bearer_scheme = HTTPBearer(auto_error=False)


class JWTAuth:
    """Stateless JWT authentication backend."""

    def __init__(
        self,
        secret_key: str,
        *,
        algorithm: str = "HS256",
        access_token_expire_minutes: int = 60,
        refresh_token_expire_days: int = 30,
        issuer: str | None = None,
    ):
        if not HAS_JWT:
            raise ImportError("PyJWT is required: pip install PyJWT")
        self.secret_key = secret_key
        self.algorithm = algorithm
        self.access_expire = timedelta(minutes=access_token_expire_minutes)
        self.refresh_expire = timedelta(days=refresh_token_expire_days)
        self.issuer = issuer

    def create_token(
        self,
        user_id: int | str,
        *,
        extra: dict[str, Any] | None = None,
        token_type: str = "access",
    ) -> str:
        """Create a JWT token.

        Args:
            user_id: Subject claim (user ID).
            extra: Additional claims (role, permissions, etc.).
            token_type: "access" or "refresh".

        Returns:
            Encoded JWT string.
        """
        now = datetime.now(timezone.utc)
        expire = self.access_expire if token_type == "access" else self.refresh_expire

        payload: dict[str, Any] = {
            "sub": str(user_id),
            "type": token_type,
            "iat": now,
            "exp": now + expire,
        }
        if self.issuer:
            payload["iss"] = self.issuer
        if extra:
            payload.update(extra)

        return pyjwt.encode(payload, self.secret_key, algorithm=self.algorithm)

    def decode_token(self, token: str) -> dict[str, Any]:
        """Decode and validate a JWT token.

        Raises jwt.InvalidTokenError on invalid/expired tokens.
        """
        kwargs: dict[str, Any] = {"algorithms": [self.algorithm]}
        if self.issuer:
            kwargs["issuer"] = self.issuer
        return pyjwt.decode(token, self.secret_key, **kwargs)

    def create_token_pair(self, user_id: int | str, extra: dict[str, Any] | None = None) -> dict[str, str]:
        """Create access + refresh token pair.

        Returns:
            {"access_token": "...", "refresh_token": "...", "token_type": "bearer"}
        """
        return {
            "access_token": self.create_token(user_id, extra=extra, token_type="access"),
            "refresh_token": self.create_token(user_id, extra=extra, token_type="refresh"),
            "token_type": "bearer",
        }

    async def _get_payload(
        self,
        credentials: HTTPAuthorizationCredentials | None = Depends(_bearer_scheme),
    ) -> dict[str, Any] | None:
        """Extract and decode JWT from Authorization header."""
        if not credentials:
            return None
        try:
            return self.decode_token(credentials.credentials)
        except Exception:
            return None

    @property
    def require(self):
        """FastAPI dependency that requires a valid JWT.

        Usage:
            @router.get("/protected")
            async def route(payload: dict = Depends(jwt_auth.require)):
                user_id = payload["sub"]
        """

        async def _require(
            credentials: HTTPAuthorizationCredentials | None = Depends(_bearer_scheme),
        ) -> dict[str, Any]:
            if not credentials:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Missing authorization header",
                    headers={"WWW-Authenticate": "Bearer"},
                )
            try:
                payload = self.decode_token(credentials.credentials)
            except Exception as e:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail=f"Invalid token: {e}",
                    headers={"WWW-Authenticate": "Bearer"},
                )
            return payload

        return _require

    @property
    def optional(self):
        """FastAPI dependency that optionally decodes JWT (returns None if absent).

        Usage:
            @router.get("/public")
            async def route(payload: dict | None = Depends(jwt_auth.optional)):
                if payload: ...
        """

        async def _optional(
            credentials: HTTPAuthorizationCredentials | None = Depends(_bearer_scheme),
        ) -> dict[str, Any] | None:
            if not credentials:
                return None
            try:
                return self.decode_token(credentials.credentials)
            except Exception:
                return None

        return _optional
