"""Provider-neutral media metadata and rights contracts."""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime, timezone

from qazstack.contracts._validation import (
    require_aware,
    require_http_url,
    require_identifier,
    require_one_of,
    require_positive,
    require_sha256,
    require_text,
)

MEDIA_ARTIFACT_SCHEMA_VERSION = "qazstack-media-artifact-v1"
MEDIA_SEARCH_CANDIDATE_SCHEMA_VERSION = "qazstack-media-search-candidate-v1"
LICENSE_CLASSIFICATION_SCHEMA_VERSION = "qazstack-license-classification-v1"
MEDIA_ARTIFACT_KINDS = frozenset({"image", "video", "audio", "document", "other"})
MEDIA_FINGERPRINT_ALGORITHMS = frozenset({"ahash", "dhash", "phash", "sha1", "md5", "custom"})
LICENSE_CATEGORIES = frozenset({"open", "attribution", "restricted", "unknown"})
_HEX_RE = re.compile(r"^[a-f0-9]{8,256}$")


def _utc_iso(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


@dataclass(frozen=True, slots=True)
class MetadataValue:
    name: str
    value: str
    source: str
    unit: str | None = None

    def __post_init__(self) -> None:
        require_text(self.name, "name")
        require_text(self.value, "value")
        require_text(self.source, "source")


@dataclass(frozen=True, slots=True)
class MediaMetadata:
    mime_type: str
    size_bytes: int
    width: int | None = None
    height: int | None = None
    captured_at: datetime | None = None
    latitude: float | None = None
    longitude: float | None = None
    fields: tuple[MetadataValue, ...] = ()

    def __post_init__(self) -> None:
        require_text(self.mime_type, "mime_type")
        require_positive(self.size_bytes, "size_bytes")
        for name in ("width", "height"):
            value = getattr(self, name)
            if value is not None:
                require_positive(value, name)
        if (self.width is None) != (self.height is None):
            raise ValueError("width and height must be provided together")
        if self.captured_at is not None:
            require_aware(self.captured_at, "captured_at")
        if (self.latitude is None) != (self.longitude is None):
            raise ValueError("latitude and longitude must be provided together")
        if self.latitude is not None and not -90 <= self.latitude <= 90:
            raise ValueError("latitude is outside its valid range")
        if self.longitude is not None and not -180 <= self.longitude <= 180:
            raise ValueError("longitude is outside its valid range")


@dataclass(frozen=True, slots=True)
class LicenseTerms:
    normalized_license: str
    source_terms_url: str
    attribution_required: bool
    commercial_use_allowed: bool | None
    derivatives_allowed: bool | None
    attribution_text: str | None = None

    def __post_init__(self) -> None:
        require_text(self.normalized_license, "normalized_license")
        require_http_url(self.source_terms_url, "source_terms_url")
        if self.attribution_required and not (self.attribution_text or "").strip():
            raise ValueError("required attribution must include attribution_text")


@dataclass(frozen=True, slots=True)
class RightsDecision:
    decision: str
    reason: str
    policy_id: str
    decided_at: datetime

    def __post_init__(self) -> None:
        require_one_of(self.decision, frozenset({"allow", "deny", "review"}), "decision")
        require_text(self.reason, "reason")
        require_text(self.policy_id, "policy_id")
        require_aware(self.decided_at, "decided_at")


@dataclass(frozen=True, slots=True)
class LicenseClassification:
    """Syntactic license interpretation; final use policy remains product-owned."""

    category: str
    normalized_license: str
    attribution_required: bool | None
    commercial_use_allowed: bool | None
    derivatives_allowed: bool | None
    requires_review: bool
    schema_version: str = LICENSE_CLASSIFICATION_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.schema_version != LICENSE_CLASSIFICATION_SCHEMA_VERSION:
            raise ValueError(f"schema_version must be {LICENSE_CLASSIFICATION_SCHEMA_VERSION}")
        require_one_of(self.category, LICENSE_CATEGORIES, "category")
        require_text(self.normalized_license, "normalized_license")

    def as_dict(self) -> dict[str, object]:
        return {
            "schema_version": self.schema_version,
            "category": self.category,
            "normalized_license": self.normalized_license,
            "attribution_required": self.attribution_required,
            "commercial_use_allowed": self.commercial_use_allowed,
            "derivatives_allowed": self.derivatives_allowed,
            "requires_review": self.requires_review,
        }


def classify_license_label(label: str | None) -> LicenseClassification:
    """Normalize common open-media license labels without granting permission."""

    normalized = re.sub(r"[_-]+", " ", (label or "").strip().casefold())
    normalized = re.sub(r"\s+", " ", normalized)
    if not normalized or normalized in {"unknown", "n/a", "неизвестно"}:
        return LicenseClassification("unknown", "unknown", None, None, None, True)
    if any(token in normalized for token in ("public domain", "cc0", "pdm")):
        return LicenseClassification("open", "public-domain", False, True, True, False)
    if "creative commons" in normalized and "cc " not in normalized:
        normalized = normalized.replace("creative commons", "cc")
    if "cc" in normalized:
        non_commercial = bool(re.search(r"\bnc\b", normalized))
        no_derivatives = bool(re.search(r"\bnd\b", normalized))
        share_alike = bool(re.search(r"\bsa\b", normalized))
        tokens = ["cc-by"]
        if non_commercial:
            tokens.append("nc")
        if no_derivatives:
            tokens.append("nd")
        elif share_alike:
            tokens.append("sa")
        return LicenseClassification(
            "attribution",
            "-".join(tokens),
            True,
            not non_commercial,
            not no_derivatives,
            False,
        )
    if any(token in normalized for token in ("all rights reserved", "rights reserved", "editorial")):
        return LicenseClassification("restricted", "restricted", None, None, None, True)
    return LicenseClassification("unknown", normalized, None, None, None, True)


@dataclass(frozen=True, slots=True)
class MediaSearchCandidate:
    """Transient provider result that has not been ingested as a MediaArtifact."""

    candidate_id: str
    kind: str
    media_url: str
    source_id: str
    source_url: str
    thumbnail_url: str | None = None
    title: str | None = None
    author: str | None = None
    license_label: str | None = None
    width: int | None = None
    height: int | None = None
    provider_rank: int | None = None
    query_variant: str | None = None
    schema_version: str = MEDIA_SEARCH_CANDIDATE_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.schema_version != MEDIA_SEARCH_CANDIDATE_SCHEMA_VERSION:
            raise ValueError(f"schema_version must be {MEDIA_SEARCH_CANDIDATE_SCHEMA_VERSION}")
        object.__setattr__(self, "candidate_id", require_identifier(self.candidate_id, "candidate_id"))
        require_one_of(self.kind, MEDIA_ARTIFACT_KINDS, "kind")
        object.__setattr__(self, "media_url", require_http_url(self.media_url, "media_url"))
        object.__setattr__(self, "source_id", require_identifier(self.source_id, "source_id"))
        object.__setattr__(self, "source_url", require_http_url(self.source_url, "source_url"))
        if self.thumbnail_url is not None:
            object.__setattr__(self, "thumbnail_url", require_http_url(self.thumbnail_url, "thumbnail_url"))
        for field_name in ("title", "author", "license_label", "query_variant"):
            value = getattr(self, field_name)
            if value is not None:
                object.__setattr__(self, field_name, require_text(value, field_name))
        if (self.width is None) != (self.height is None):
            raise ValueError("width and height must be provided together")
        for field_name in ("width", "height", "provider_rank"):
            value = getattr(self, field_name)
            if value is not None:
                require_positive(value, field_name)

    def as_dict(self) -> dict[str, object]:
        return {
            "schema_version": self.schema_version,
            "candidate_id": self.candidate_id,
            "kind": self.kind,
            "media_url": self.media_url,
            "thumbnail_url": self.thumbnail_url,
            "source_id": self.source_id,
            "source_url": self.source_url,
            "title": self.title,
            "author": self.author,
            "license_label": self.license_label,
            "width": self.width,
            "height": self.height,
            "provider_rank": self.provider_rank,
            "query_variant": self.query_variant,
        }


@dataclass(frozen=True, slots=True)
class MediaFingerprint:
    """A non-authoritative technical fingerprint for media matching."""

    algorithm: str
    value: str
    provider: str

    def __post_init__(self) -> None:
        require_one_of(self.algorithm, MEDIA_FINGERPRINT_ALGORITHMS, "algorithm")
        normalized = require_text(self.value, "value").lower()
        if self.algorithm != "custom" and not _HEX_RE.fullmatch(normalized):
            raise ValueError("fingerprint value must be bounded lowercase hexadecimal")
        object.__setattr__(self, "value", normalized)
        object.__setattr__(self, "provider", require_identifier(self.provider, "provider"))


@dataclass(frozen=True, slots=True)
class MediaArtifact:
    """Immutable identity and provenance envelope for one media object.

    Storage, access control, forensic interpretation and editorial verdicts
    remain product-owned. ``content_ref`` may be a private object reference or
    a public URL and must never be dereferenced implicitly by this contract.
    """

    artifact_id: str
    kind: str
    content_ref: str
    digest: str
    metadata: MediaMetadata
    registered_at: datetime
    fingerprints: tuple[MediaFingerprint, ...] = ()
    occurrence_ids: tuple[str, ...] = ()
    schema_version: str = MEDIA_ARTIFACT_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.schema_version != MEDIA_ARTIFACT_SCHEMA_VERSION:
            raise ValueError(f"schema_version must be {MEDIA_ARTIFACT_SCHEMA_VERSION}")
        require_identifier(self.artifact_id, "artifact_id")
        require_one_of(self.kind, MEDIA_ARTIFACT_KINDS, "kind")
        object.__setattr__(self, "content_ref", require_text(self.content_ref, "content_ref"))
        object.__setattr__(self, "digest", require_sha256(self.digest))
        if not isinstance(self.metadata, MediaMetadata):
            raise ValueError("metadata must be MediaMetadata")
        require_aware(self.registered_at, "registered_at")
        if any(not isinstance(item, MediaFingerprint) for item in self.fingerprints):
            raise ValueError("fingerprints must contain MediaFingerprint values")
        algorithms = [item.algorithm for item in self.fingerprints]
        if len(algorithms) != len(set(algorithms)):
            raise ValueError("fingerprints must contain at most one value per algorithm")
        if len(self.occurrence_ids) != len(set(self.occurrence_ids)):
            raise ValueError("occurrence_ids must not contain duplicates")
        for occurrence_id in self.occurrence_ids:
            require_identifier(occurrence_id, "occurrence_ids")

    def as_dict(self) -> dict[str, object]:
        """Return the versioned transport representation without reading bytes."""
        metadata = {
            "mime_type": self.metadata.mime_type,
            "size_bytes": self.metadata.size_bytes,
            "width": self.metadata.width,
            "height": self.metadata.height,
            "captured_at": _utc_iso(self.metadata.captured_at) if self.metadata.captured_at else None,
            "latitude": self.metadata.latitude,
            "longitude": self.metadata.longitude,
            "fields": [
                {"name": item.name, "value": item.value, "source": item.source, "unit": item.unit}
                for item in self.metadata.fields
            ],
        }
        return {
            "schema_version": self.schema_version,
            "artifact_id": self.artifact_id,
            "kind": self.kind,
            "content_ref": self.content_ref,
            "digest": self.digest,
            "metadata": metadata,
            "registered_at": _utc_iso(self.registered_at),
            "fingerprints": [
                {"algorithm": item.algorithm, "value": item.value, "provider": item.provider}
                for item in self.fingerprints
            ],
            "occurrence_ids": list(self.occurrence_ids),
        }
