"""Portable image normalization and perceptual-deduplication helpers."""

from __future__ import annotations

import io
import re
from dataclasses import dataclass
from typing import Iterable, Mapping

_HASH_RE = re.compile(r"^[a-fA-F0-9]+$")


@dataclass(frozen=True, slots=True)
class ImageTransformSpec:
    max_dimension: int = 1600
    quality: int = 82
    output_format: str = "JPEG"
    max_input_bytes: int = 25 * 1024 * 1024
    max_pixels: int = 40_000_000

    def __post_init__(self) -> None:
        if self.max_dimension < 1:
            raise ValueError("max_dimension must be positive")
        if not 1 <= self.quality <= 100:
            raise ValueError("quality must be between 1 and 100")
        if self.output_format.upper() not in {"JPEG", "WEBP", "PNG"}:
            raise ValueError("output_format must be JPEG, WEBP or PNG")
        if self.max_input_bytes < 1 or self.max_pixels < 1:
            raise ValueError("input limits must be positive")


@dataclass(frozen=True, slots=True)
class ImageTransformResult:
    data: bytes
    width: int
    height: int
    mime_type: str
    extension: str
    perceptual_hash: str


def compute_dhash(image: object, *, hash_size: int = 8) -> str:
    """Compute a deterministic difference hash for a Pillow-compatible image."""

    if hash_size < 2 or hash_size > 32:
        raise ValueError("hash_size must be between 2 and 32")
    try:
        from PIL import Image
    except ImportError as exc:  # pragma: no cover - exercised by optional dependency environments
        raise RuntimeError("Pillow is required for image operations") from exc
    if not isinstance(image, Image.Image):
        raise TypeError("image must be a PIL.Image.Image")
    small = image.resize((hash_size + 1, hash_size), Image.Resampling.LANCZOS).convert("L")
    bits = []
    for row in range(hash_size):
        for column in range(hash_size):
            left = small.getpixel((column, row))
            right = small.getpixel((column + 1, row))
            if not isinstance(left, (int, float)) or not isinstance(right, (int, float)):
                raise TypeError("grayscale pixel values must be numeric")
            bits.append(1 if left < right else 0)
    value = 0
    for bit in bits:
        value = (value << 1) | bit
    width = max(1, (hash_size * hash_size + 3) // 4)
    return f"{value:0{width}x}"


def optimize_image_bytes(data: bytes, *, spec: ImageTransformSpec | None = None) -> ImageTransformResult:
    """Decode, orient, bound and re-encode an image without filesystem policy."""

    cfg = spec or ImageTransformSpec()
    if not data or len(data) > cfg.max_input_bytes:
        raise ValueError("image payload is empty or exceeds max_input_bytes")
    try:
        from PIL import Image, ImageOps
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError("Pillow is required for image operations") from exc
    with Image.open(io.BytesIO(data)) as source:
        if source.width * source.height > cfg.max_pixels:
            raise ValueError("decoded image exceeds max_pixels")
        source.load()
        image = ImageOps.exif_transpose(source)
        perceptual_hash = compute_dhash(image)
        if max(image.size) > cfg.max_dimension:
            image.thumbnail((cfg.max_dimension, cfg.max_dimension), Image.Resampling.LANCZOS)
        output_format = cfg.output_format.upper()
        if output_format == "JPEG":
            if image.mode in {"RGBA", "LA", "P"}:
                rgba = image.convert("RGBA")
                background = Image.new("RGB", rgba.size, "white")
                background.paste(rgba, mask=rgba.getchannel("A"))
                image = background
            elif image.mode != "RGB":
                image = image.convert("RGB")
        buffer = io.BytesIO()
        if output_format in {"JPEG", "WEBP"}:
            image.save(buffer, format=output_format, optimize=True, quality=cfg.quality)
        else:
            image.save(buffer, format=output_format, optimize=True)
        mime = {"JPEG": "image/jpeg", "WEBP": "image/webp", "PNG": "image/png"}[output_format]
        extension = {"JPEG": ".jpg", "WEBP": ".webp", "PNG": ".png"}[output_format]
        return ImageTransformResult(
            data=buffer.getvalue(),
            width=image.width,
            height=image.height,
            mime_type=mime,
            extension=extension,
            perceptual_hash=perceptual_hash,
        )


def duplicate_hash_groups(
    records: Iterable[Mapping[str, object]],
    *,
    hash_field: str = "perceptual_hash",
    id_field: str = "id",
) -> tuple[tuple[object, ...], ...]:
    """Return stable duplicate groups without deciding which record to delete."""

    grouped: dict[str, list[object]] = {}
    for record in records:
        value = record.get(hash_field)
        identifier = record.get(id_field)
        if value and identifier is not None:
            grouped.setdefault(str(value), []).append(identifier)
    return tuple(tuple(values) for _, values in sorted(grouped.items()) if len(values) > 1)


def perceptual_hash_distance(left: str, right: str) -> int:
    """Return Hamming distance between equal-width hexadecimal hashes."""

    if len(left) != len(right) or not left or not _HASH_RE.fullmatch(left) or not _HASH_RE.fullmatch(right):
        raise ValueError("perceptual hashes must be non-empty, equal-width hexadecimal strings")
    return (int(left, 16) ^ int(right, 16)).bit_count()


def complete_link_hash_groups(
    records: Iterable[Mapping[str, object]],
    *,
    threshold: int = 6,
    hash_field: str = "perceptual_hash",
    id_field: str = "id",
    include_singletons: bool = False,
) -> tuple[tuple[object, ...], ...]:
    """Cluster near-duplicates without transitive hash-chain over-merging."""

    if threshold < 0:
        raise ValueError("threshold must be non-negative")
    candidates: list[tuple[object, str]] = []
    for record in records:
        value = record.get(hash_field)
        identifier = record.get(id_field)
        if value and identifier is not None:
            candidates.append((identifier, str(value)))
    groups: list[list[tuple[object, str]]] = []
    for candidate in candidates:
        for group in groups:
            if all(perceptual_hash_distance(candidate[1], member[1]) <= threshold for member in group):
                group.append(candidate)
                break
        else:
            groups.append([candidate])
    return tuple(
        tuple(identifier for identifier, _hash in group) for group in groups if include_singletons or len(group) > 1
    )
