"""
qazstack.editorial.api
=======================
FastAPI роутер для модуля editorial.

Стандарт платформы: /api/editorial/...

Все эндпоинты используют dependency injection для DB сессий.
Фоновые задачи генерации запускаются через BackgroundTasks.

Импорт в app/main.py:
    from qazstack.editorial.api import editorial_router
    app.include_router(editorial_router)
"""

from __future__ import annotations

import difflib
import json
import logging
import uuid
from typing import Any, Optional

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

logger = logging.getLogger(__name__)

editorial_router = APIRouter(prefix="/api/editorial", tags=["editorial"])


# ─────────────────────────────────────────────────────────────────────────────
# Dependency: DB Session
# ─────────────────────────────────────────────────────────────────────────────


# Эта зависимость переопределяется в app/main.py через app.dependency_overrides
async def get_db() -> AsyncSession:  # type: ignore[return]
    """Placeholder – переопределяется в lifespan через dependency_overrides."""
    raise RuntimeError("DB session dependency not configured. Call setup_editorial_deps() in lifespan.")


# ─────────────────────────────────────────────────────────────────────────────
# Request / Response схемы
# ─────────────────────────────────────────────────────────────────────────────


class CreateAuthorRequest(BaseModel):
    """Запрос на создание автора."""

    author_id: str = Field(..., description="Уникальный ID автора, напр. analyst_daurenov_01")
    name: str = Field(..., description="Отображаемое имя")
    domain_scope: list[str] = Field(default_factory=list, description="Домены: politics, economics, ...")
    genre_scope: list[str] = Field(default_factory=list, description="Жанры: analysis, news, commentary, ...")
    languages: list[str] = Field(default=["ru"])
    profile_json: dict = Field(..., description="Полный AuthorProfile JSON (Pydantic-схема)")


class UpdateAuthorRequest(BaseModel):
    """Запрос на обновление профиля автора (частичный)."""

    name: Optional[str] = None
    domain_scope: Optional[list[str]] = None
    genre_scope: Optional[list[str]] = None
    languages: Optional[list[str]] = None
    is_active: Optional[bool] = None
    profile_json: Optional[dict] = None


class AuthorResponse(BaseModel):
    """Ответ с профилем автора."""

    author_id: str
    name: str
    domain_scope: list[str]
    genre_scope: list[str]
    languages: list[str]
    is_active: bool
    created_at: Any
    updated_at: Any


class CreateTaskRequest(BaseModel):
    """Запрос на создание задания генерации."""

    author_id: str = Field(..., description="ID автора")
    brief: str = Field(..., description="Задание для автора (тема, угол подачи)")
    task_type: str = Field(
        default="analysis", description="analysis | news | commentary | review | brief | data_to_text"
    )
    lang: str = Field(default="ru", description="Язык генерации: ru | kz | en")
    target_word_count: int = Field(default=600, ge=100, le=5000)
    research_query: Optional[str] = Field(default=None, description="Поисковый запрос (если отличается от brief)")
    research_date_from: Optional[str] = Field(default=None, description="Начало диапазона дат ISO")
    research_date_to: Optional[str] = Field(default=None, description="Конец диапазона дат ISO")
    input_data: Optional[dict] = Field(default=None, description="Данные для D2T пайплайна")
    priority: int = Field(default=5, ge=1, le=10, description="Приоритет 1-10 (1=наивысший)")


class TaskResponse(BaseModel):
    """Ответ со статусом задания."""

    task_id: str
    status: str
    author_id: str
    current_iteration: Optional[int] = None
    overall_score: Optional[float] = None
    error_message: Optional[str] = None
    message: str = ""


class HITLReviewAction(BaseModel):
    """Действие редактора над материалом в HITL очереди."""

    action: str = Field(..., description="approve | reject | revision_requested | in_review")
    reviewer_notes: Optional[str] = None
    final_content: Optional[str] = Field(default=None, description="Исправленная версия (опционально)")


class HITLItem(BaseModel):
    """Элемент HITL очереди."""

    id: str
    task_id: str
    author_id: str
    author_name: str
    title: Optional[str]
    word_count: Optional[int]
    overall_score: Optional[float]
    status: str
    priority: int
    hard_gate_reason: Optional[str]
    created_at: Any
    reviewed_at: Optional[Any]


class DraftResponse(BaseModel):
    """Черновик с оценками."""

    draft_id: str
    task_id: str
    iteration: int
    content: str
    word_count: Optional[int]
    overall_score: Optional[float]
    passes_threshold: Optional[bool]
    scores: Optional[dict]
    critic_feedback: Optional[str]
    style_metrics: Optional[dict]
    llm_model: Optional[str]
    llm_cost_usd: Optional[float]
    created_at: Any


class StatsResponse(BaseModel):
    """Сводная статистика editorial."""

    total_tasks: int
    total_publications: int
    total_hitl_pending: int
    avg_score: Optional[float]
    avg_iterations: Optional[float]
    avg_cost_usd: Optional[float]
    approval_rate: Optional[float]


# ─────────────────────────────────────────────────────────────────────────────
# Авторы
# ─────────────────────────────────────────────────────────────────────────────


@editorial_router.get("/authors", response_model=list[AuthorResponse], summary="Список активных авторов")
async def list_authors(
    domain: Optional[str] = Query(default=None, description="Фильтр по домену"),
    lang: Optional[str] = Query(default=None, description="Фильтр по языку"),
    genre: Optional[str] = Query(default=None, description="Фильтр по жанру"),
    include_inactive: bool = Query(default=False, description="Включить неактивных авторов"),
    session: AsyncSession = Depends(get_db),
) -> list[dict]:
    """Получить список авторов с опциональной фильтрацией."""
    conditions = []
    params: dict = {}

    if not include_inactive:
        conditions.append("is_active = true")

    if domain:
        conditions.append("domain_scope @> :domain_filter::jsonb")
        params["domain_filter"] = json.dumps([domain])

    if lang:
        conditions.append("languages @> :lang_filter::jsonb")
        params["lang_filter"] = json.dumps([lang])

    if genre:
        conditions.append("genre_scope @> :genre_filter::jsonb")
        params["genre_filter"] = json.dumps([genre])

    where = " AND ".join(conditions) if conditions else "1=1"
    result = await session.execute(
        text(f"""
            SELECT author_id, name, domain_scope, genre_scope, languages,
                   is_active, created_at, updated_at
            FROM editorial.authors
            WHERE {where}
            ORDER BY name
        """),
        params,
    )
    rows = result.fetchall()
    return [dict(row._mapping) for row in rows]


@editorial_router.get("/authors/{author_id}", response_model=dict, summary="Профиль автора")
async def get_author(
    author_id: str,
    session: AsyncSession = Depends(get_db),
) -> dict:
    """Получить полный профиль автора по ID."""
    result = await session.execute(
        text("""
            SELECT author_id, name, domain_scope, genre_scope, languages,
                   is_active, profile_json, created_at, updated_at
            FROM editorial.authors WHERE author_id = :aid
        """),
        {"aid": author_id},
    )
    row = result.fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail=f"Автор {author_id!r} не найден")
    return dict(row._mapping)


@editorial_router.post("/authors", status_code=201, summary="Создать автора")
async def create_author(
    req: CreateAuthorRequest,
    session: AsyncSession = Depends(get_db),
) -> dict:
    """Создать нового виртуального AI-автора."""
    # Проверяем дублирование
    exists = await session.execute(
        text("SELECT 1 FROM editorial.authors WHERE author_id = :aid"),
        {"aid": req.author_id},
    )
    if exists.fetchone():
        raise HTTPException(status_code=409, detail=f"Автор {req.author_id!r} уже существует")

    await session.execute(
        text("""
            INSERT INTO editorial.authors
                (author_id, name, domain_scope, genre_scope, languages, profile_json)
            VALUES
                (:aid, :name, :domain::jsonb, :genre::jsonb, :langs::jsonb, :profile::jsonb)
        """),
        {
            "aid": req.author_id,
            "name": req.name,
            "domain": json.dumps(req.domain_scope),
            "genre": json.dumps(req.genre_scope),
            "langs": json.dumps(req.languages),
            "profile": json.dumps(req.profile_json),
        },
    )
    await session.commit()
    return {"status": "created", "author_id": req.author_id}


@editorial_router.patch("/authors/{author_id}", summary="Обновить профиль автора")
async def update_author(
    author_id: str,
    req: UpdateAuthorRequest,
    session: AsyncSession = Depends(get_db),
) -> dict:
    """Частичное обновление профиля автора."""
    # Проверяем существование
    exists = await session.execute(
        text("SELECT 1 FROM editorial.authors WHERE author_id = :aid"),
        {"aid": author_id},
    )
    if not exists.fetchone():
        raise HTTPException(status_code=404, detail=f"Автор {author_id!r} не найден")

    # Собираем только непустые поля
    updates: list[str] = []
    params: dict = {"aid": author_id}

    if req.name is not None:
        updates.append("name = :name")
        params["name"] = req.name
    if req.domain_scope is not None:
        updates.append("domain_scope = :domain::jsonb")
        params["domain"] = json.dumps(req.domain_scope)
    if req.genre_scope is not None:
        updates.append("genre_scope = :genre::jsonb")
        params["genre"] = json.dumps(req.genre_scope)
    if req.languages is not None:
        updates.append("languages = :langs::jsonb")
        params["langs"] = json.dumps(req.languages)
    if req.is_active is not None:
        updates.append("is_active = :is_active")
        params["is_active"] = req.is_active
    if req.profile_json is not None:
        updates.append("profile_json = :profile::jsonb")
        params["profile"] = json.dumps(req.profile_json)

    if not updates:
        return {"status": "no_changes", "author_id": author_id}

    await session.execute(
        text(f"UPDATE editorial.authors SET {', '.join(updates)}, updated_at = NOW() WHERE author_id = :aid"),
        params,
    )
    await session.commit()
    return {"status": "updated", "author_id": author_id}


# ─────────────────────────────────────────────────────────────────────────────
# Задания
# ─────────────────────────────────────────────────────────────────────────────


@editorial_router.post("/tasks", response_model=TaskResponse, status_code=202, summary="Создать задание генерации")
async def create_task(
    req: CreateTaskRequest,
    background_tasks: BackgroundTasks,
    session: AsyncSession = Depends(get_db),
) -> dict:
    """
    Создать задание на генерацию и запустить пайплайн в фоне.

    Возвращает task_id для последующего опроса статуса через GET /tasks/{task_id}.
    """
    # Проверяем автора
    author_exists = await session.execute(
        text("SELECT 1 FROM editorial.authors WHERE author_id = :aid AND is_active = true"),
        {"aid": req.author_id},
    )
    if not author_exists.fetchone():
        raise HTTPException(status_code=404, detail=f"Автор {req.author_id!r} не найден или неактивен")

    task_id = str(uuid.uuid4())

    # Сохраняем задание сразу
    await session.execute(
        text("""
            INSERT INTO editorial.generation_tasks
                (task_id, author_id, brief, task_type, lang, target_word_count,
                 research_query, input_data, status, priority)
            VALUES
                (:tid, :aid, :brief, :ttype, :lang, :wc,
                 :rq, :idata::jsonb, 'pending', :priority)
        """),
        {
            "tid": task_id,
            "aid": req.author_id,
            "brief": req.brief,
            "ttype": req.task_type,
            "lang": req.lang,
            "wc": req.target_word_count,
            "rq": req.research_query,
            "idata": json.dumps(req.input_data or {}),
            "priority": req.priority,
        },
    )
    await session.commit()

    # Запускаем пайплайн в фоне
    background_tasks.add_task(_run_generation_background, task_id)

    return {
        "task_id": task_id,
        "status": "pending",
        "author_id": req.author_id,
        "message": "Задание принято в работу",
    }


async def _run_generation_background(task_id: str) -> None:
    """Фоновая задача: запуск оркестратора генерации.

    Импортирует Orchestrator лениво, чтобы избежать circular imports.
    Оркестратор создаёт свою сессию через session_factory из app state.
    """
    try:
        # Импорт в runtime – избегаем circular imports
        from qazstack.editorial.app.main import get_orchestrator  # type: ignore[import]

        orchestrator = await get_orchestrator()
        # Загружаем задание из БД
        from qazstack.editorial.app.main import get_session_factory  # type: ignore[import]
        from qazstack.editorial.models import GenerationTask

        session_factory = get_session_factory()
        async with session_factory() as session:
            result = await session.execute(
                text("SELECT * FROM editorial.generation_tasks WHERE task_id = :tid"),
                {"tid": task_id},
            )
            row = result.fetchone()
            if row is None:
                logger.error("Task %s not found for background generation", task_id)
                return

            task_data = dict(row._mapping)

        task = GenerationTask(
            task_id=task_data["task_id"],
            author_id=task_data["author_id"],
            brief=task_data["brief"],
            task_type=task_data["task_type"],
            lang=task_data["lang"],
            target_word_count=task_data["target_word_count"],
            research_query=task_data.get("research_query"),
            input_data=task_data.get("input_data"),
        )
        await orchestrator.generate(task)
        logger.info("Background generation completed for task %s", task_id)
    except Exception as exc:
        logger.exception("Background generation failed for task %s: %s", task_id, exc)


@editorial_router.get("/tasks/{task_id}", response_model=dict, summary="Статус задания")
async def get_task(
    task_id: str,
    session: AsyncSession = Depends(get_db),
) -> dict:
    """Получить текущий статус задания на генерацию."""
    result = await session.execute(
        text("""
            SELECT task_id, status, author_id, brief, task_type, lang,
                   target_word_count, current_iteration, error_message,
                   created_at, updated_at
            FROM editorial.generation_tasks WHERE task_id = :tid
        """),
        {"tid": task_id},
    )
    row = result.fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="Задание не найдено")
    return dict(row._mapping)


@editorial_router.get("/tasks", response_model=list[dict], summary="Список заданий")
async def list_tasks(
    author_id: Optional[str] = Query(default=None),
    status: Optional[str] = Query(
        default=None, description="pending | drafting | scoring | pending_review | published | error"
    ),
    page: int = Query(default=1, ge=1),
    per_page: int = Query(default=20, ge=1, le=100),
    session: AsyncSession = Depends(get_db),
) -> list[dict]:
    """Список заданий с пагинацией и фильтрацией."""
    conditions = ["1=1"]
    params: dict = {"limit": per_page, "offset": (page - 1) * per_page}

    if author_id:
        conditions.append("author_id = :author_id")
        params["author_id"] = author_id
    if status:
        conditions.append("status = :status")
        params["status"] = status

    where = " AND ".join(conditions)
    result = await session.execute(
        text(f"""
            SELECT task_id, author_id, brief, task_type, lang, status,
                   current_iteration, overall_score, created_at, updated_at
            FROM editorial.generation_tasks
            LEFT JOIN LATERAL (
                SELECT overall_score FROM editorial.hitl_queue h
                WHERE h.task_id = generation_tasks.task_id
                ORDER BY h.created_at DESC LIMIT 1
            ) latest_score ON true
            WHERE {where}
            ORDER BY created_at DESC
            LIMIT :limit OFFSET :offset
        """),
        params,
    )
    return [dict(row._mapping) for row in result.fetchall()]


@editorial_router.get("/tasks/{task_id}/result", summary="Результат генерации")
async def get_task_result(
    task_id: str,
    session: AsyncSession = Depends(get_db),
) -> dict:
    """Получить финальный черновик и scores для завершённого задания."""
    result = await session.execute(
        text("""
            SELECT h.id::text, h.title, h.content, h.overall_score, h.final_scores,
                   h.iterations_used, h.research_sources, h.status, h.word_count,
                   h.hard_gate_reason, h.created_at
            FROM editorial.hitl_queue h
            WHERE h.task_id = :tid
            ORDER BY h.created_at DESC
            LIMIT 1
        """),
        {"tid": task_id},
    )
    row = result.fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="Результат ещё не готов или задание не найдено")
    return dict(row._mapping)


@editorial_router.get("/tasks/{task_id}/diff", summary="Diff между итерациями")
async def get_task_diff(
    task_id: str,
    iter_from: int = Query(default=1, ge=1, description="Начальная итерация"),
    iter_to: Optional[int] = Query(default=None, description="Конечная итерация (по умолчанию – последняя)"),
    session: AsyncSession = Depends(get_db),
) -> dict:
    """Показывает unified diff между двумя итерациями черновика."""
    result = await session.execute(
        text("""
            SELECT iteration, content, scores, overall_score, critic_feedback
            FROM editorial.drafts
            WHERE task_id = :tid
            ORDER BY iteration
        """),
        {"tid": task_id},
    )
    rows = {r.iteration: r for r in result.fetchall()}

    if not rows:
        raise HTTPException(status_code=404, detail="Черновики для данного задания не найдены")

    if iter_from not in rows:
        raise HTTPException(status_code=404, detail=f"Итерация {iter_from} не найдена")

    actual_to = iter_to or max(rows.keys())
    if actual_to not in rows:
        raise HTTPException(status_code=404, detail=f"Итерация {actual_to} не найдена")

    from_lines = rows[iter_from].content.splitlines()
    to_lines = rows[actual_to].content.splitlines()

    diff = list(
        difflib.unified_diff(
            from_lines,
            to_lines,
            fromfile=f"v{iter_from}",
            tofile=f"v{actual_to}",
            lineterm="",
        )
    )

    return {
        "task_id": task_id,
        "from_iteration": iter_from,
        "to_iteration": actual_to,
        "diff": diff,
        "from_score": rows[iter_from].overall_score,
        "to_score": rows[actual_to].overall_score,
        "to_feedback": rows[actual_to].critic_feedback,
    }


# ─────────────────────────────────────────────────────────────────────────────
# HITL очередь
# ─────────────────────────────────────────────────────────────────────────────


@editorial_router.get("/hitl", response_model=list[HITLItem], summary="HITL очередь")
async def list_hitl(
    status: str = Query(default="pending", description="pending | in_review | approved | rejected"),
    author_id: Optional[str] = Query(default=None),
    priority_max: Optional[int] = Query(default=None, ge=1, le=10, description="Фильтр по максимальному приоритету"),
    page: int = Query(default=1, ge=1),
    per_page: int = Query(default=20, ge=1, le=100),
    session: AsyncSession = Depends(get_db),
) -> list[dict]:
    """Список материалов в HITL очереди с фильтрацией по статусу/автору/приоритету."""
    conditions = ["status = :status"]
    params: dict = {"status": status, "limit": per_page, "offset": (page - 1) * per_page}

    if author_id:
        conditions.append("author_id = :author_id")
        params["author_id"] = author_id
    if priority_max is not None:
        conditions.append("priority <= :priority_max")
        params["priority_max"] = priority_max

    where = " AND ".join(conditions)
    result = await session.execute(
        text(f"""
            SELECT id::text, task_id, author_id, author_name, title, word_count,
                   overall_score, status, priority, hard_gate_reason, created_at, reviewed_at
            FROM editorial.hitl_queue
            WHERE {where}
            ORDER BY priority ASC, overall_score DESC, created_at ASC
            LIMIT :limit OFFSET :offset
        """),
        params,
    )
    return [dict(row._mapping) for row in result.fetchall()]


@editorial_router.patch("/hitl/{item_id}", summary="Approve / reject материала")
async def review_hitl_item(
    item_id: str,
    action: HITLReviewAction,
    session: AsyncSession = Depends(get_db),
) -> dict:
    """Одобрить, отклонить или запросить доработку материала из HITL очереди."""
    allowed_actions = {"approve", "reject", "revision_requested", "in_review"}
    if action.action not in allowed_actions:
        raise HTTPException(
            status_code=400,
            detail=f"Допустимые действия: {', '.join(sorted(allowed_actions))}",
        )

    # Проверяем существование
    exists = await session.execute(
        text("SELECT task_id, status FROM editorial.hitl_queue WHERE id = :iid"),
        {"iid": item_id},
    )
    row = exists.fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="Элемент HITL очереди не найден")

    updates = ["status = :status", "reviewed_at = NOW()"]
    params: dict = {"iid": item_id, "status": action.action}

    if action.reviewer_notes is not None:
        updates.append("reviewer_notes = :notes")
        params["notes"] = action.reviewer_notes

    if action.final_content is not None:
        updates.append("final_content = :final_content")
        params["final_content"] = action.final_content

    await session.execute(
        text(f"UPDATE editorial.hitl_queue SET {', '.join(updates)} WHERE id = :iid"),
        params,
    )

    # Синхронизируем статус задания
    task_status_map = {
        "approve": "approved",
        "reject": "rejected",
        "revision_requested": "pending_review",
        "in_review": "scoring",
    }
    new_task_status = task_status_map.get(action.action)
    if new_task_status:
        await session.execute(
            text("UPDATE editorial.generation_tasks SET status = :s, updated_at = NOW() WHERE task_id = :tid"),
            {"s": new_task_status, "tid": row.task_id},
        )

    await session.commit()

    # При approve – сохраняем в publications
    if action.action == "approve":
        await _promote_to_publication(session, item_id, row.task_id, action.final_content)

    return {"status": "ok", "item_id": item_id, "action": action.action}


async def _promote_to_publication(
    session: AsyncSession, item_id: str, task_id: str, final_content: Optional[str]
) -> None:
    """Перевести одобренный HITL-элемент в публикации."""
    result = await session.execute(
        text("""
            SELECT h.author_id, h.author_name, h.title,
                   COALESCE(:fc, h.final_content, h.content) AS content,
                   h.lang, h.word_count, h.final_scores, h.overall_score,
                   h.research_sources
            FROM editorial.hitl_queue h
            WHERE h.id = :iid
        """),
        {"iid": item_id, "fc": final_content},
    )
    row = result.fetchone()
    if row is None:
        return

    await session.execute(
        text("""
            INSERT INTO editorial.publications
                (task_id, author_id, author_name, title, content, lang, word_count,
                 research_sources, final_scores, overall_score,
                 disclosure_metadata)
            VALUES
                (:tid, :aid, :aname, :title, :content, :lang, :wc,
                 :sources::jsonb, :scores::jsonb, :score,
                 :disclosure::jsonb)
            ON CONFLICT DO NOTHING
        """),
        {
            "tid": task_id,
            "aid": row.author_id,
            "aname": row.author_name,
            "title": row.title or "Без заголовка",
            "content": row.content,
            "lang": row.lang,
            "wc": row.word_count,
            "sources": json.dumps(row.research_sources or []),
            "scores": json.dumps(row.final_scores or {}),
            "score": row.overall_score,
            "disclosure": json.dumps({"ai_generated": True, "reviewed_by_human": True, "hitl_item_id": item_id}),
        },
    )
    await session.execute(
        text("UPDATE editorial.generation_tasks SET status = 'published', updated_at = NOW() WHERE task_id = :tid"),
        {"tid": task_id},
    )
    await session.commit()


# ─────────────────────────────────────────────────────────────────────────────
# Черновики
# ─────────────────────────────────────────────────────────────────────────────


@editorial_router.get("/drafts/{draft_id}", response_model=DraftResponse, summary="Черновик с оценками")
async def get_draft(
    draft_id: str,
    session: AsyncSession = Depends(get_db),
) -> dict:
    """Получить черновик со всеми score и метриками стиля."""
    result = await session.execute(
        text("""
            SELECT draft_id, task_id, iteration, content, word_count,
                   overall_score, passes_threshold, scores, critic_feedback,
                   style_metrics, llm_model, llm_cost_usd, created_at
            FROM editorial.drafts WHERE draft_id = :did
        """),
        {"did": draft_id},
    )
    row = result.fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="Черновик не найден")
    return dict(row._mapping)


@editorial_router.get("/tasks/{task_id}/drafts", summary="Все черновики задания")
async def list_task_drafts(
    task_id: str,
    session: AsyncSession = Depends(get_db),
) -> list[dict]:
    """Список всех итераций черновиков для задания."""
    result = await session.execute(
        text("""
            SELECT draft_id, task_id, iteration, word_count,
                   overall_score, passes_threshold, scores,
                   llm_model, llm_cost_usd, created_at
            FROM editorial.drafts WHERE task_id = :tid
            ORDER BY iteration
        """),
        {"tid": task_id},
    )
    return [dict(row._mapping) for row in result.fetchall()]


# ─────────────────────────────────────────────────────────────────────────────
# Статистика
# ─────────────────────────────────────────────────────────────────────────────


@editorial_router.get("/stats", response_model=StatsResponse, summary="Сводная статистика редакции")
async def get_stats(session: AsyncSession = Depends(get_db)) -> dict:
    """Сводная статистика: задания, публикации, средний score, стоимость."""
    tasks_result = await session.execute(text("SELECT COUNT(*) AS total FROM editorial.generation_tasks"))
    tasks_row = tasks_result.fetchone()

    pub_result = await session.execute(text("SELECT COUNT(*) AS total FROM editorial.publications"))
    pub_row = pub_result.fetchone()

    hitl_pending = await session.execute(
        text("SELECT COUNT(*) AS total FROM editorial.hitl_queue WHERE status = 'pending'")
    )
    hitl_row = hitl_pending.fetchone()

    metrics = await session.execute(
        text("""
            SELECT
                AVG(overall_score)        AS avg_score,
                AVG(iterations_used)      AS avg_iterations
            FROM editorial.hitl_queue
            WHERE status IN ('approved', 'published')
        """)
    )
    metrics_row = metrics.fetchone()

    cost_result = await session.execute(
        text("SELECT AVG(llm_cost_usd) AS avg_cost FROM editorial.drafts WHERE llm_cost_usd IS NOT NULL")
    )
    cost_row = cost_result.fetchone()

    # Approval rate = approved / (approved + rejected)
    approval = await session.execute(
        text("""
            SELECT
                COUNT(*) FILTER (WHERE status IN ('approved', 'published')) AS approved,
                COUNT(*) FILTER (WHERE status = 'rejected')                  AS rejected
            FROM editorial.hitl_queue
        """)
    )
    approval_row = approval.fetchone()
    total_reviewed = (approval_row.approved or 0) + (approval_row.rejected or 0)
    approval_rate = (approval_row.approved / total_reviewed) if total_reviewed > 0 else None

    return {
        "total_tasks": tasks_row.total if tasks_row else 0,
        "total_publications": pub_row.total if pub_row else 0,
        "total_hitl_pending": hitl_row.total if hitl_row else 0,
        "avg_score": float(metrics_row.avg_score) if metrics_row and metrics_row.avg_score else None,
        "avg_iterations": float(metrics_row.avg_iterations) if metrics_row and metrics_row.avg_iterations else None,
        "avg_cost_usd": float(cost_row.avg_cost) if cost_row and cost_row.avg_cost else None,
        "approval_rate": approval_rate,
    }


@editorial_router.get("/stats/authors", summary="Статистика по авторам")
async def get_author_stats(session: AsyncSession = Depends(get_db)) -> list[dict]:
    """Статистика из materialized view editorial.author_stats."""
    try:
        result = await session.execute(text("SELECT * FROM editorial.author_stats ORDER BY total_publications DESC"))
        return [dict(row._mapping) for row in result.fetchall()]
    except Exception:
        # Если view ещё не создан – возвращаем пустой список
        return []


@editorial_router.get("/stats/authors/{author_id}", summary="Детальная статистика автора")
async def get_single_author_stats(
    author_id: str,
    session: AsyncSession = Depends(get_db),
) -> dict:
    """Детальная статистика конкретного автора."""
    result = await session.execute(
        text("""
            SELECT
                COUNT(*) AS total_tasks,
                COUNT(*) FILTER (WHERE status = 'published') AS published,
                COUNT(*) FILTER (WHERE status = 'approved')  AS approved_pending,
                COUNT(*) FILTER (WHERE status = 'rejected')  AS rejected,
                COUNT(*) FILTER (WHERE status = 'pending')   AS pending
            FROM editorial.generation_tasks
            WHERE author_id = :aid
        """),
        {"aid": author_id},
    )
    task_row = result.fetchone()

    score_result = await session.execute(
        text("""
            SELECT
                AVG(overall_score)   AS avg_score,
                AVG(iterations_used) AS avg_iterations,
                AVG(word_count)      AS avg_word_count
            FROM editorial.hitl_queue
            WHERE author_id = :aid
        """),
        {"aid": author_id},
    )
    score_row = score_result.fetchone()

    return {
        "author_id": author_id,
        **(dict(task_row._mapping) if task_row else {}),
        "avg_score": float(score_row.avg_score) if score_row and score_row.avg_score else None,
        "avg_iterations": float(score_row.avg_iterations) if score_row and score_row.avg_iterations else None,
        "avg_word_count": float(score_row.avg_word_count) if score_row and score_row.avg_word_count else None,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Healthcheck
# ─────────────────────────────────────────────────────────────────────────────


@editorial_router.get("/health", summary="Healthcheck")
async def health(session: AsyncSession = Depends(get_db)) -> dict:
    """Healthcheck для editorial API – проверяет БД."""
    try:
        await session.execute(text("SELECT 1"))
        db_ok = True
    except Exception as exc:
        logger.error("DB health check failed: %s", exc)
        db_ok = False

    return {
        "status": "ok" if db_ok else "degraded",
        "module": "qazstack.editorial",
        "db": "ok" if db_ok else "error",
    }
