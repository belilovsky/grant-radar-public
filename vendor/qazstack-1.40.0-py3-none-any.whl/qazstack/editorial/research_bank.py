"""
qazstack.editorial.research_bank
=================================
Семантический поиск в QazLake для наполнения контекста генерации.

Использует гибридный подход:
  1. Keyword search (FTS via PostgreSQL to_tsvector / to_tsquery)
  2. Embedding search (QazCompute 1024-dim + pgvector HNSW cosine)
  3. Hybrid merge via Reciprocal Rank Fusion (RRF)

QazCompute: POST /api/v1/embeddings  (X-API-Key header)
QazLake:    raw_ingestion table (id, url, title, body_text, pub_date, lang, ...)
"""

from __future__ import annotations

import hashlib
import json
import logging
import re
from datetime import datetime, timedelta, timezone
from typing import Optional

import httpx
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession, async_sessionmaker, create_async_engine

from .config import settings

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Модели данных
# ─────────────────────────────────────────────────────────────────────────────


class ResearchDocument(BaseModel):
    """Документ из Research Bank, готовый к вставке в промпт."""

    id: str = Field(..., description="ID документа в источнике")
    title: str = Field(default="", description="Заголовок")
    text: str = Field(default="", description="Тело/резюме документа")
    source: str = Field(default="qazlake", description="Источник (qazlake / research_bank)")
    url: Optional[str] = Field(default=None, description="URL оригинала")
    similarity_score: float = Field(default=0.0, description="Cosine similarity (0–1)")
    pub_date: Optional[str] = Field(default=None, description="Дата публикации (ISO)")
    lang: Optional[str] = Field(default=None, description="Язык")


# ─────────────────────────────────────────────────────────────────────────────
# ResearchBank
# ─────────────────────────────────────────────────────────────────────────────


class ResearchBank:
    """
    Семантический поиск в QazLake для наполнения контекста генерации.

    Параметры:
        db_session_factory: async_sessionmaker для QazLake БД.
        compute_client:     httpx.AsyncClient для QazCompute API.
        qazcompute_url:     URL QazCompute (default из settings).
        qazcompute_key:     API-ключ QazCompute (default из settings).

    Пример:
        bank = ResearchBank(session_factory, compute_client)
        docs = await bank.search("ВВП Казахстана 2025", task, limit=10)
        context = await bank.format_context(docs, max_tokens=2000)
    """

    # Примерный коэффициент символов → токены (для русского текста)
    _CHARS_PER_TOKEN: float = 3.5

    def __init__(
        self,
        db_session_factory: async_sessionmaker | None = None,
        compute_client: httpx.AsyncClient | None = None,
        qazcompute_url: str | None = None,
        qazcompute_key: str | None = None,
    ) -> None:
        self._session_factory = db_session_factory
        self._compute_client = compute_client  # если None – создаём при каждом вызове
        self._qazcompute_url = qazcompute_url or settings.editorial_qazcompute_url
        self._qazcompute_key = qazcompute_key or settings.editorial_qazcompute_key

        # Lazy-init engine для QazLake (если session_factory не передан)
        self._qazlake_engine: AsyncEngine | None = None
        self._qazlake_factory: async_sessionmaker | None = None

    # ── Public API ────────────────────────────────────────────────────────────

    async def search(
        self,
        query: str,
        task: object | None = None,
        limit: int = 10,
        lang: str | None = None,
        domains: list[str] | None = None,
        date_from: str | None = None,
        date_to: str | None = None,
    ) -> list[ResearchDocument]:
        """
        Гибридный поиск (FTS + embedding) с RRF-слиянием.

        Args:
            query:     Поисковый запрос.
            task:      GenerationTask (опционально – для извлечения lang/domains).
            limit:     Максимальное число результатов.
            lang:      Фильтр по языку (переопределяет task.lang).
            domains:   Фильтр по категориям.
            date_from: Начало диапазона дат (ISO date string).
            date_to:   Конец диапазона дат (ISO date string).

        Returns:
            Список ResearchDocument, отсортированных по RRF-score (убывание).
        """
        # Извлекаем параметры из task, если переданы
        if task is not None:
            lang = lang or getattr(task, "lang", None)
            date_from = date_from or getattr(task, "research_date_from", None)
            date_to = date_to or getattr(task, "research_date_to", None)
            if domains is None:
                # Пробуем получить из автора, если author_id доступен
                pass

        # Проверяем кеш
        cache_key = self._make_cache_key(query, lang, domains, date_from, date_to, limit)
        cached = await self._check_cache(cache_key)
        if cached is not None:
            logger.debug("Research cache hit for query=%r", query[:50])
            return cached

        # 1. Получаем embedding
        try:
            embedding = await self._get_embedding(query)
        except Exception as exc:
            logger.warning("QazCompute embedding failed: %s – falling back to FTS only", exc)
            embedding = None

        # 2. Параллельные поиски
        fts_results = await self._fts_search(query, lang, domains, date_from, date_to, limit * 2)
        if embedding is not None:
            vec_results = await self._vector_search(embedding, lang, domains, date_from, date_to, limit * 2)
        else:
            vec_results = []

        # 3. RRF слияние
        merged = self._rrf_merge(fts_results, vec_results, limit=limit)

        # Кешируем результаты
        await self._store_cache(cache_key, query, merged, embedding)

        return merged

    async def format_context(
        self,
        docs: list[ResearchDocument],
        max_tokens: int = 2000,
    ) -> str:
        """
        Форматирует список документов в строку для вставки в LLM-промпт.

        Args:
            docs:       Список ResearchDocument.
            max_tokens: Приблизительный лимит токенов.

        Returns:
            Форматированная строка с источниками, разделёнными ``---``.
        """
        max_chars = int(max_tokens * self._CHARS_PER_TOKEN)
        parts: list[str] = []
        total_chars = 0

        for doc in docs:
            block_lines: list[str] = []
            if doc.title:
                date_str = f" ({doc.pub_date[:10]})" if doc.pub_date else ""
                block_lines.append(f"ИСТОЧНИК: {doc.title}{date_str}")
            if doc.url:
                block_lines.append(f"URL: {doc.url}")
            if doc.text:
                excerpt = doc.text[:600]
                block_lines.append(f"СОДЕРЖАНИЕ: {excerpt}")

            block = "\n".join(block_lines) + "\n---"
            if total_chars + len(block) > max_chars:
                break
            parts.append(block)
            total_chars += len(block)

        return "\n\n".join(parts) if parts else "(данные не найдены)"

    async def add_to_bank(
        self,
        content: str,
        source_url: str,
        source_type: str = "article",
        topic_tags: list[str] | None = None,
        lang: str = "ru",
        quality_score: float | None = None,
    ) -> None:
        """
        Добавить новый материал в editorial.research_bank.

        Args:
            content:       Текст фрагмента (до 2000 символов хранится).
            source_url:    URL оригинала.
            source_type:   Тип источника: article | data | example | analogy.
            topic_tags:    Список тегов для фильтрации.
            lang:          Язык текста.
            quality_score: Оценка качества (0.0–1.0).
        """
        embedding = await self._get_embedding(content)
        emb_str = self._vec_to_pgstr(embedding)
        tags = topic_tags or []

        async with self._get_editorial_session() as session:
            await session.execute(
                text("""
                    INSERT INTO editorial.research_bank
                        (content, embedding, source_url, source_type, topic_tags, lang, quality_score)
                    VALUES
                        (:content, :emb::vector, :url, :stype, :tags::text[], :lang, :quality)
                    ON CONFLICT DO NOTHING
                """),
                {
                    "content": content[:2000],
                    "emb": emb_str,
                    "url": source_url,
                    "stype": source_type,
                    "tags": "{" + ",".join(tags) + "}",
                    "lang": lang,
                    "quality": quality_score,
                },
            )
            await session.commit()

    # ── Embedding ─────────────────────────────────────────────────────────────

    async def _get_embedding(self, query_text: str) -> list[float]:
        """Получить 1024-dim embedding из QazCompute."""
        headers = {"X-API-Key": self._qazcompute_key, "Content-Type": "application/json"}
        payload = {"input": query_text, "model": "multilingual-e5-large"}

        if self._compute_client is not None:
            response = await self._compute_client.post(
                f"{self._qazcompute_url}/api/v1/embeddings",
                json=payload,
                headers=headers,
                timeout=30.0,
            )
            response.raise_for_status()
            data = response.json()
        else:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.post(
                    f"{self._qazcompute_url}/api/v1/embeddings",
                    json=payload,
                    headers=headers,
                )
                response.raise_for_status()
                data = response.json()

        # OpenAI-совместимый формат: {"data": [{"embedding": [...]}]}
        if "data" in data and data["data"]:
            return data["data"][0]["embedding"]
        # Прямой формат: {"embedding": [...]}
        if "embedding" in data:
            return data["embedding"]
        raise ValueError(f"Unexpected QazCompute response format: {list(data.keys())}")

    # ── FTS Search ────────────────────────────────────────────────────────────

    async def _fts_search(
        self,
        query: str,
        lang: str | None,
        domains: list[str] | None,
        date_from: str | None,
        date_to: str | None,
        limit: int,
    ) -> list[ResearchDocument]:
        """Полнотекстовый поиск в QazLake raw_ingestion."""
        conditions = ["1=1"]
        params: dict = {"limit": limit}

        # Строим tsquery: слова объединяем через &
        words = [w.strip() for w in re.split(r"\s+", query.strip()) if w.strip()]
        ts_query = " & ".join(words) if words else query
        params["ts_query"] = ts_query

        fts_lang = "russian" if lang == "ru" else "simple"
        conditions.append(
            f"to_tsvector('{fts_lang}', COALESCE(title, '') || ' ' || COALESCE(body_text, '')) "
            f"@@ plainto_tsquery('{fts_lang}', :ts_query)"
        )

        if lang:
            conditions.append("lang = :lang")
            params["lang"] = lang
        if date_from:
            conditions.append("pub_date >= :date_from")
            params["date_from"] = date_from
        if date_to:
            conditions.append("pub_date <= :date_to")
            params["date_to"] = date_to

        where = " AND ".join(conditions)
        sql = f"""
            SELECT
                id::text,
                COALESCE(title, '') AS title,
                COALESCE(body_text, excerpt, '') AS body_text,
                url,
                pub_date::text,
                lang,
                ts_rank(
                    to_tsvector('{fts_lang}', COALESCE(title, '') || ' ' || COALESCE(body_text, '')),
                    plainto_tsquery('{fts_lang}', :ts_query)
                ) AS fts_rank
            FROM raw_ingestion
            WHERE {where}
            ORDER BY fts_rank DESC
            LIMIT :limit
        """

        try:
            async with self._get_qazlake_session() as session:
                result = await session.execute(text(sql), params)
                rows = result.fetchall()
        except Exception as exc:
            logger.error("FTS search failed: %s", exc)
            return []

        return [
            ResearchDocument(
                id=str(row.id),
                title=row.title or "",
                text=(row.body_text or "")[:800],
                source="qazlake",
                url=row.url,
                similarity_score=float(row.fts_rank or 0.0),
                pub_date=row.pub_date,
                lang=row.lang,
            )
            for row in rows
        ]

    # ── Vector Search ─────────────────────────────────────────────────────────

    async def _vector_search(
        self,
        embedding: list[float],
        lang: str | None,
        domains: list[str] | None,
        date_from: str | None,
        date_to: str | None,
        limit: int,
    ) -> list[ResearchDocument]:
        """Поиск по векторному сходству в QazLake через pgvector."""
        emb_str = self._vec_to_pgstr(embedding)
        conditions = ["ae.embedding IS NOT NULL"]
        params: dict = {"emb": emb_str, "limit": limit}

        if lang:
            conditions.append("a.lang = :lang")
            params["lang"] = lang
        if date_from:
            conditions.append("a.pub_date >= :date_from")
            params["date_from"] = date_from
        if date_to:
            conditions.append("a.pub_date <= :date_to")
            params["date_to"] = date_to

        where = " AND ".join(conditions)
        sql = f"""
            SELECT
                a.id::text,
                COALESCE(a.title, '') AS title,
                COALESCE(a.body_text, a.excerpt, '') AS body_text,
                a.url,
                a.pub_date::text,
                a.lang,
                1 - (ae.embedding <=> :emb::vector) AS similarity
            FROM raw_ingestion a
            JOIN article_embeddings ae ON ae.article_id = a.id
            WHERE {where}
            ORDER BY ae.embedding <=> :emb::vector
            LIMIT :limit
        """

        try:
            async with self._get_qazlake_session() as session:
                result = await session.execute(text(sql), params)
                rows = result.fetchall()
        except Exception as exc:
            logger.error("Vector search failed: %s", exc)
            # Fallback: поиск в editorial.research_bank
            return await self._vector_search_bank(embedding, lang, limit)

        return [
            ResearchDocument(
                id=str(row.id),
                title=row.title or "",
                text=(row.body_text or "")[:800],
                source="qazlake",
                url=row.url,
                similarity_score=float(row.similarity or 0.0),
                pub_date=row.pub_date,
                lang=row.lang,
            )
            for row in rows
        ]

    async def _vector_search_bank(
        self,
        embedding: list[float],
        lang: str | None,
        limit: int,
    ) -> list[ResearchDocument]:
        """Fallback: поиск в editorial.research_bank (если QazLake недоступен)."""
        emb_str = self._vec_to_pgstr(embedding)
        conditions = ["embedding IS NOT NULL"]
        params: dict = {"emb": emb_str, "limit": limit}
        if lang:
            conditions.append("lang = :lang")
            params["lang"] = lang

        where = " AND ".join(conditions)
        sql = f"""
            SELECT
                id::text,
                '' AS title,
                content AS body_text,
                source_url AS url,
                NULL AS pub_date,
                lang,
                1 - (embedding <=> :emb::vector) AS similarity
            FROM editorial.research_bank
            WHERE {where}
            ORDER BY embedding <=> :emb::vector
            LIMIT :limit
        """
        try:
            async with self._get_editorial_session() as session:
                result = await session.execute(text(sql), params)
                rows = result.fetchall()
        except Exception as exc:
            logger.error("Bank vector search failed: %s", exc)
            return []

        return [
            ResearchDocument(
                id=str(row.id),
                title="",
                text=(row.body_text or "")[:800],
                source="research_bank",
                url=row.url,
                similarity_score=float(row.similarity or 0.0),
                pub_date=None,
                lang=row.lang,
            )
            for row in rows
        ]

    # ── RRF Merge ─────────────────────────────────────────────────────────────

    @staticmethod
    def _rrf_merge(
        fts_docs: list[ResearchDocument],
        vec_docs: list[ResearchDocument],
        limit: int,
        k: int = 60,
    ) -> list[ResearchDocument]:
        """
        Reciprocal Rank Fusion (Cormack et al., 2009).

        Score(d) = Σ_r  1 / (k + rank_r(d))
        k=60 – стандартное значение из оригинальной статьи.
        """
        scores: dict[str, float] = {}
        doc_map: dict[str, ResearchDocument] = {}

        for rank, doc in enumerate(fts_docs, start=1):
            scores[doc.id] = scores.get(doc.id, 0.0) + 1.0 / (k + rank)
            doc_map[doc.id] = doc

        for rank, doc in enumerate(vec_docs, start=1):
            scores[doc.id] = scores.get(doc.id, 0.0) + 1.0 / (k + rank)
            if doc.id not in doc_map:
                doc_map[doc.id] = doc

        # Обновляем similarity_score в документах финальным RRF-score
        sorted_ids = sorted(scores, key=lambda x: scores[x], reverse=True)[:limit]
        result: list[ResearchDocument] = []
        for doc_id in sorted_ids:
            doc = doc_map[doc_id].model_copy(update={"similarity_score": scores[doc_id]})
            result.append(doc)

        return result

    # ── Cache ─────────────────────────────────────────────────────────────────

    @staticmethod
    def _make_cache_key(
        query: str,
        lang: str | None,
        domains: list[str] | None,
        date_from: str | None,
        date_to: str | None,
        limit: int,
    ) -> str:
        """SHA-256 хеш параметров запроса."""
        raw = json.dumps(
            {"q": query, "lang": lang, "domains": sorted(domains or []), "df": date_from, "dt": date_to, "lim": limit},
            ensure_ascii=False,
            sort_keys=True,
        )
        return hashlib.sha256(raw.encode()).hexdigest()

    async def _check_cache(self, cache_key: str) -> list[ResearchDocument] | None:
        """Проверить кеш в editorial.research_cache. None – кеш промахнулся."""
        try:
            async with self._get_editorial_session() as session:
                result = await session.execute(
                    text(
                        "SELECT results FROM editorial.research_cache "
                        "WHERE query_hash = :h AND expires_at > NOW() "
                        "ORDER BY created_at DESC LIMIT 1"
                    ),
                    {"h": cache_key},
                )
                row = result.fetchone()
                if row and row.results:
                    raw: list[dict] = row.results if isinstance(row.results, list) else json.loads(row.results)
                    return [ResearchDocument(**d) for d in raw]
        except Exception as exc:
            logger.debug("Cache check failed (non-critical): %s", exc)
        return None

    async def _store_cache(
        self,
        cache_key: str,
        query_text: str,
        docs: list[ResearchDocument],
        embedding: list[float] | None,
    ) -> None:
        """Сохранить результаты в editorial.research_cache."""
        try:
            expires_at = datetime.now(timezone.utc) + timedelta(hours=settings.editorial_research_cache_ttl_hours)
            results_json = json.dumps([d.model_dump() for d in docs], ensure_ascii=False, default=str)
            emb_str = self._vec_to_pgstr(embedding) if embedding else None

            async with self._get_editorial_session() as session:
                if emb_str:
                    await session.execute(
                        text("""
                            INSERT INTO editorial.research_cache
                                (query_hash, query_text, results, embedding, expires_at)
                            VALUES (:h, :q, :r::jsonb, :emb::vector, :exp)
                            ON CONFLICT (query_hash) DO UPDATE
                                SET results = EXCLUDED.results,
                                    expires_at = EXCLUDED.expires_at,
                                    created_at = NOW()
                        """),
                        {"h": cache_key, "q": query_text[:500], "r": results_json, "emb": emb_str, "exp": expires_at},
                    )
                else:
                    await session.execute(
                        text("""
                            INSERT INTO editorial.research_cache
                                (query_hash, query_text, results, expires_at)
                            VALUES (:h, :q, :r::jsonb, :exp)
                            ON CONFLICT (query_hash) DO UPDATE
                                SET results = EXCLUDED.results,
                                    expires_at = EXCLUDED.expires_at,
                                    created_at = NOW()
                        """),
                        {"h": cache_key, "q": query_text[:500], "r": results_json, "exp": expires_at},
                    )
                await session.commit()
        except Exception as exc:
            logger.debug("Cache store failed (non-critical): %s", exc)

    # ── Session helpers ───────────────────────────────────────────────────────

    def _get_qazlake_session(self) -> AsyncSession:
        """Получить сессию для QazLake."""
        if self._session_factory is not None:
            return self._session_factory()
        # Lazy-init
        if self._qazlake_factory is None:
            engine = create_async_engine(
                settings.editorial_qazlake_db_url,
                pool_size=5,
                max_overflow=10,
                pool_pre_ping=True,
            )
            self._qazlake_engine = engine
            self._qazlake_factory = async_sessionmaker(engine, expire_on_commit=False)
        return self._qazlake_factory()

    def _get_editorial_session(self) -> AsyncSession:
        """Получить сессию для editorial БД (кеш, research_bank)."""
        # Используется отдельный engine, чтобы не смешивать с QazLake
        if not hasattr(self, "_editorial_engine") or self._editorial_engine is None:
            self._editorial_engine = create_async_engine(
                settings.editorial_db_url,
                pool_size=3,
                max_overflow=5,
                pool_pre_ping=True,
            )
            self._editorial_factory = async_sessionmaker(self._editorial_engine, expire_on_commit=False)
        return self._editorial_factory()

    # ── Utils ─────────────────────────────────────────────────────────────────

    @staticmethod
    def _vec_to_pgstr(vec: list[float]) -> str:
        """Конвертировать вектор в строку PostgreSQL vector literal."""
        return "[" + ",".join(map(str, vec)) + "]"
