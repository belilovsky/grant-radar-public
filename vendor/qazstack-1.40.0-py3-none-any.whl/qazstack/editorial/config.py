"""
qazstack.editorial.config
=========================
Pydantic Settings для модуля editorial.

Все параметры можно переопределить через переменные окружения
или .env файл (python-dotenv).
"""

from __future__ import annotations

from pydantic_settings import BaseSettings, SettingsConfigDict


class EditorialSettings(BaseSettings):
    """Конфигурация модуля editorial.

    Все значения читаются из переменных окружения (case-insensitive).
    При наличии .env-файла – из него (через python-dotenv).
    """

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ── Собственная БД editorial ─────────────────────────────────────────────
    editorial_db_url: str = ""

    # ── QazLake (187K статей, raw_ingestion) ─────────────────────────────────
    editorial_qazlake_db_url: str = ""

    # ── QazCompute (embeddings, 1024-dim multilingual-e5-large) ─────────────
    editorial_qazcompute_url: str = "http://localhost:8201"
    editorial_qazcompute_key: str = ""

    # ── LLM ─────────────────────────────────────────────────────────────────
    openai_api_key: str = ""
    editorial_llm_model: str = "gpt-4o"
    editorial_scoring_model: str = "gpt-4o-mini"

    # ── Pipeline limits ──────────────────────────────────────────────────────
    editorial_max_cost_per_task: float = 0.50
    """Максимально допустимый расход USD на одно задание (hard cap)."""

    editorial_max_iterations: int = 3
    """Максимальное число итераций scoring loop."""

    editorial_publish_threshold: float = 0.80
    """Минимальный overall_score для автоматического прохода через HITL."""

    # ── Hard Gate пороги ─────────────────────────────────────────────────────
    editorial_hard_gate_factual_min: float = 0.60
    """Минимально допустимый factual_accuracy (ниже → hard gate failed)."""

    editorial_hard_gate_hallucination_max: float = 0.15
    """Максимально допустимый hallucination_rate."""

    editorial_hard_gate_topic_drift_max: float = 0.40
    """Максимально допустимый topic_drift (доля, 0.0–1.0)."""

    # ── Research ─────────────────────────────────────────────────────────────
    editorial_research_top_k: int = 10
    """Количество документов для поиска по умолчанию."""

    editorial_research_max_tokens: int = 2000
    """Максимальный размер контекста (в токенах) для промпта."""

    editorial_research_cache_ttl_hours: int = 24
    """TTL кеша результатов поиска в research_cache (часов)."""

    # ── Redis ────────────────────────────────────────────────────────────────
    editorial_redis_url: str = "redis://localhost:6384/0"

    # ── App ─────────────────────────────────────────────────────────────────
    editorial_debug: bool = False
    editorial_secret_key: str = "change-me-in-production"


settings = EditorialSettings()
