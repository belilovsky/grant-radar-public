"""
Alembic env.py для qazstack.editorial.

Использует SQLAlchemy 2.0 async engine.
Для применения миграций:
    alembic upgrade head
"""

from __future__ import annotations

import asyncio
from logging.config import fileConfig

from alembic import context
from sqlalchemy.ext.asyncio import create_async_engine

from qazstack.editorial.config import settings

# Импортируем Base и settings
from qazstack.editorial.database import EditorialBase

# Alembic Config object
config = context.config

# Логирование из alembic.ini
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# Метаданные для автогенерации
target_metadata = EditorialBase.metadata


def get_url() -> str:
    """URL БД из settings или из alembic.ini."""
    return config.get_main_option("sqlalchemy.url") or settings.editorial_db_url


def run_migrations_offline() -> None:
    """Запуск миграций в offline-режиме (без реального подключения к БД)."""
    url = get_url()
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        include_schemas=True,
        version_table_schema="editorial",
    )
    with context.begin_transaction():
        context.run_migrations()


def do_run_migrations(connection) -> None:
    """Запуск миграций в online-режиме."""
    context.configure(
        connection=connection,
        target_metadata=target_metadata,
        include_schemas=True,
        version_table_schema="editorial",
        compare_type=True,
        compare_server_default=True,
    )
    with context.begin_transaction():
        context.run_migrations()


async def run_async_migrations() -> None:
    """Async entry point для Alembic."""
    connectable = create_async_engine(get_url(), echo=False)
    async with connectable.connect() as connection:
        await connection.run_sync(do_run_migrations)
    await connectable.dispose()


def run_migrations_online() -> None:
    """Точка входа для online-режима."""
    asyncio.run(run_async_migrations())


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
