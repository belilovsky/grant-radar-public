"""Dependency-free story-to-article relevance helpers."""

from __future__ import annotations

import re
from collections.abc import Mapping
from typing import Any

_STOPWORDS = {
    "без",
    "будет",
    "будут",
    "был",
    "была",
    "были",
    "было",
    "для",
    "или",
    "как",
    "над",
    "при",
    "про",
    "что",
    "это",
    "его",
    "ее",
    "еще",
    "уже",
    "год",
    "года",
    "году",
    "годы",
    "после",
    "перед",
    "через",
    "новый",
    "новая",
    "новые",
    "нового",
    "новости",
    "казахстан",
    "казахстана",
    "казахстане",
    "казахстанский",
    "казахстанская",
    "астана",
    "астане",
    "алматы",
    "алмате",
}
_SUFFIXES = (
    "иями",
    "ями",
    "ами",
    "ого",
    "его",
    "ому",
    "ему",
    "ыми",
    "ими",
    "ой",
    "ей",
    "ая",
    "яя",
    "ое",
    "ее",
    "ые",
    "ие",
    "ых",
    "их",
    "ам",
    "ям",
    "ах",
    "ях",
    "ов",
    "ев",
    "ом",
    "ем",
    "а",
    "я",
    "ы",
    "и",
    "е",
    "у",
)
_TOKEN_RE = re.compile(r"[a-zа-яё0-9]{3,}", re.IGNORECASE)


def _root(token: str) -> str:
    value = token.lower().replace("ё", "е").strip()
    if value.isdigit() or value in _STOPWORDS:
        return ""
    for suffix in _SUFFIXES:
        if value.endswith(suffix) and len(value) - len(suffix) >= 5:
            value = value[: -len(suffix)]
            break
    return value[:6] if len(value) >= 7 else value


def story_relevance_tokens(text: str | None) -> set[str]:
    """Return stable topic tokens used to compare stories and articles."""
    tokens: set[str] = set()
    for raw in _TOKEN_RE.findall(text or ""):
        root = _root(raw)
        if root and len(root) >= 4:
            tokens.add(root)
    return tokens


def story_article_text(article: Mapping[str, Any] | None) -> str:
    """Build a bounded relevance corpus from a normalized article mapping."""
    article = article or {}
    pieces: list[Any] = [
        article.get("title"),
        article.get("excerpt"),
        article.get("summary"),
        article.get("body_text"),
        article.get("sub_category"),
        article.get("category"),
    ]
    for tag in article.get("tags") or []:
        pieces.append(tag.get("name") or tag.get("tag") if isinstance(tag, Mapping) else str(tag))
    for entity in article.get("entities") or []:
        pieces.append(
            entity.get("short_name") or entity.get("name") or entity.get("normalized")
            if isinstance(entity, Mapping)
            else str(entity)
        )
    return " ".join(str(piece) for piece in pieces if piece)


def story_article_matches_title(article: Mapping[str, Any], story_title: str) -> bool:
    """Reject obvious cross-topic attachments while preserving broad topics."""
    story_tokens = story_relevance_tokens(story_title)
    if len(story_tokens) < 3:
        return True
    title_tokens = story_relevance_tokens(str(article.get("title") or ""))
    title_overlap = len(story_tokens & title_tokens)
    if title_overlap >= 2:
        return True
    if title_overlap == 0:
        return False
    return len(story_tokens & story_relevance_tokens(story_article_text(article))) >= 2


def story_summary_matches_title(summary: str | None, story_title: str | None) -> bool:
    """Require a story summary to carry at least two specific title signals."""
    if not summary:
        return False
    story_tokens = story_relevance_tokens(story_title)
    if len(story_tokens) < 3:
        return True
    return len(story_tokens & story_relevance_tokens(summary)) >= 2
