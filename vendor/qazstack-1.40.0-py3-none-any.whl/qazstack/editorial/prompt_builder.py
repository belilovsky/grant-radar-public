"""
qazstack.editorial.prompt_builder
==================================
Сборка системных и пользовательских промптов из профиля автора и задания на генерацию.

Архитектура:
- PromptBuilder – единственный публичный класс, без состояния (stateless).
- Все публичные методы возвращают либо str (системный промпт), либо list[dict]
  (массив messages для OpenAI-совместимого API).
- Промпты формируются на русском языке (язык редакционной системы).
- Информация о стиле не дублируется между system и user сообщениями.
"""

from __future__ import annotations

import json
import textwrap
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .models import AuthorProfile, GenerationTask

# ---------------------------------------------------------------------------
# Вспомогательные константы
# ---------------------------------------------------------------------------

_GENRE_INSTRUCTIONS: dict[str, str] = {
    "analysis": (
        "Жанр: АНАЛИТИКА. Структура: тезис → данные → анализ → вывод. "
        "Обязательны подзаголовки при объёме > 600 слов. "
        "Каждый тезис подкреплён числом или ссылкой на источник."
    ),
    "news": (
        "Жанр: НОВОСТЬ. Структура: перевёрнутая пирамида (главное → детали → контекст). "
        "Лид – один абзац, не более 40 слов. "
        "Нейтральный тон, активные глаголы, прямая речь при наличии цитат."
    ),
    "commentary": (
        "Жанр: КОММЕНТАРИЙ. Структура: тезис → аргументация → контраргумент → позиция автора. "
        "Допустимо авторское «я» в меру. "
        "Завершается однозначной позицией, а не открытым вопросом."
    ),
    "brief": (
        "Жанр: БРИФ. Максимальная плотность информации. "
        "Короткие предложения (10–15 слов). Маркированные списки при перечислении > 3 пунктов. "
        "Без вводных конструкций и риторических вопросов."
    ),
    "data_to_text": (
        "Жанр: DATA-TO-TEXT. Исходные данные – таблицы/числа. "
        "Задача: вербализовать ключевые паттерны, выбросы и тренды. "
        "Каждое утверждение привязано к конкретному числу из данных. "
        "Избегать интерпретаций, выходящих за пределы предоставленных данных."
    ),
    "review": (
        "Жанр: ОБЗОР. Охватывает период или тематический срез. "
        "Структура: вводный обзор → тематические блоки → итоговая оценка. "
        "Хронологический или тематический порядок – по смыслу."
    ),
}

_DEFAULT_GENRE_INSTRUCTION = "Тип материала: {task_type}. Придерживайся профессионального аналитического стиля."

_LANG_INSTRUCTIONS: dict[str, str] = {
    "ru": "Пиши строго на русском языке. Казахские термины и аббревиатуры допустимы без перевода.",
    "kk": (
        "Пиши строго на казахском языке (кириллица). "
        "Соблюдай нормы сингармонизма. "
        "Эвиденциальные маркеры («деректерге сәйкес», «анықталды») при ссылке на источники."
    ),
    "en": "Write strictly in English. Use formal academic register.",
}

_REINJECTION_TEMPLATE = """\
[НАПОМИНАНИЕ О СТИЛЕ – {name}]
Ты всё ещё пишешь как {name}. Проверь:
{anchor_phrases}
Продолжай в том же ключе.\
"""


# ---------------------------------------------------------------------------
# Основной класс
# ---------------------------------------------------------------------------


class PromptBuilder:
    """
    Собирает промпты для всех этапов генерации из профиля автора и задания.

    Класс не имеет внутреннего состояния – все методы pure functions.

    Пример::

        builder = PromptBuilder()
        system = builder.build_system_prompt(author, task)
        messages = builder.build_generation_prompt(task, research_context, author)
        scoring_msgs = builder.build_scoring_prompt(draft, author, task)
        rewrite_msgs = builder.build_rewrite_prompt(draft, feedback, author, task)
        reinjection = builder.build_reinjection_prompt(author)
    """

    # ------------------------------------------------------------------
    # 1. Системный промпт
    # ------------------------------------------------------------------

    def build_system_prompt(
        self,
        author: AuthorProfile,
        task: GenerationTask,
    ) -> str:
        """
        Собирает полный системный промпт из профиля автора и задания.

        Если профиль содержит заполненный ``system_prompt_template``
        (с плейсхолдерами ``{name}``, ``{biography}``, ``{task_description}``,
        ``{research_context}``), используется он.  В противном случае промпт
        строится из компонентов профиля.

        Research context передаётся только в user-сообщении, чтобы не
        дублировать токены.

        Args:
            author: профиль автора ``AuthorProfile``.
            task: задание на генерацию ``GenerationTask``.

        Returns:
            Строка системного промпта, готовая к передаче в поле ``system``.
        """
        task_description = f"{task.task_type.upper()}: {task.brief}"

        # Если шаблон уже задан – форматируем его
        if author.system_prompt_template and "{" in author.system_prompt_template:
            try:
                return author.system_prompt_template.format(
                    name=author.name,
                    biography=author.persona.biography,
                    task_description=task_description,
                    research_context="(см. контекст в user prompt)",
                )
            except KeyError:
                # Частично заполненный шаблон – продолжаем сборкой вручную
                pass

        # Сборка из компонентов
        parts: list[str] = []

        # Заголовок персоны
        parts.append(f"Ты {author.name}.\n")

        # Биография
        if author.persona.biography:
            parts.append(f"[БИОГРАФИЯ]\n{author.persona.biography.strip()}\n")

        # Мотивация и голос
        if author.persona.motivation:
            parts.append(f"[МОТИВАЦИЯ]\n{author.persona.motivation.strip()}\n")

        if author.persona.voice_description:
            parts.append(f"[ГОЛОС И СТИЛЬ]\n{author.persona.voice_description.strip()}\n")

        # Обязательные правила стиля
        rules = author.style_rules
        rule_lines: list[str] = []

        if rules.required:
            rule_lines.append("ВСЕГДА:")
            for r in rules.required:
                rule_lines.append(f"- {r}")

        if rules.forbidden:
            rule_lines.append("\nНИКОГДА:")
            for f in rules.forbidden:
                rule_lines.append(f"- {f}")

        if rules.sentence_starters:
            rule_lines.append("\nХАРАКТЕРНЫЕ ВЫРАЖЕНИЯ:")
            for s in rules.sentence_starters:
                rule_lines.append(f"- «{s}»")

        if rule_lines:
            parts.append("[ПРАВИЛА СТИЛЯ]\n" + "\n".join(rule_lines) + "\n")

        # Жанровый контракт
        genre_instr = _GENRE_INSTRUCTIONS.get(
            task.task_type,
            _DEFAULT_GENRE_INSTRUCTION.format(task_type=task.task_type),
        )
        parts.append(f"[ЖАНРОВЫЙ КОНТРАКТ]\n{genre_instr}\n")

        # Few-shot примеры
        if author.few_shot_examples:
            examples_block = ["[ПРИМЕРЫ ТВОИХ ТЕКСТОВ]"]
            for ex in author.few_shot_examples[:3]:  # не более 3 для экономии токенов
                examples_block.append(f"--- {ex.label} ---")
                examples_block.append(ex.text.strip())
            parts.append("\n".join(examples_block) + "\n")

        # Языковые инструкции
        lang_instr = _LANG_INSTRUCTIONS.get(task.lang, f"Пиши на языке: {task.lang}.")
        parts.append(f"[ЯЗЫК]\n{lang_instr}\n")

        # Задание
        parts.append(f"[ЗАДАНИЕ]\n{task_description}\n")

        # Контекст – placeholder (реальный контекст в user prompt)
        parts.append("[КОНТЕКСТ ИЗ RESEARCH BANK]\n(см. контекст в user prompt)\n")

        parts.append("Напиши материал строго в своём авторском стиле.")

        return "\n".join(parts)

    # ------------------------------------------------------------------
    # 2. Промпт генерации
    # ------------------------------------------------------------------

    def build_generation_prompt(
        self,
        task: GenerationTask,
        research_context: str,
        author: AuthorProfile,
        iteration: int = 1,
        previous_feedback: str | None = None,
    ) -> list[dict[str, str]]:
        """
        Формирует массив messages для вызова генерации черновика.

        Системный промпт передаётся отдельно (через ``build_system_prompt``).
        Этот метод возвращает только user-сообщение(я).

        Args:
            task: задание на генерацию.
            research_context: собранный контекст из ResearchBank.
            author: профиль автора (нужен для языковых и объёмных параметров).
            iteration: номер текущей итерации (1-based).
            previous_feedback: feedback предыдущей итерации (для переписей).

        Returns:
            Список словарей ``{"role": ..., "content": ...}``.
        """
        lines: list[str] = [
            f"Напиши материал типа «{task.task_type}».",
            f"Тема: {task.brief}",
            f"Язык: {task.lang}",
            f"Целевой объём: {task.target_word_count} слов.",
        ]

        # Входные данные (D2T)
        if task.input_data:
            formatted = json.dumps(task.input_data, ensure_ascii=False, indent=2)
            lines.append(f"\nИСПОЛЬЗУЙ ЭТИ ДАННЫЕ:\n{formatted}")

        # Research context
        if research_context:
            lines.append(f"\nКОНТЕКСТ ДЛЯ МАТЕРИАЛА:\n{research_context.strip()}")

        # Feedback предыдущей итерации
        if iteration > 1 and previous_feedback:
            lines.append(f"\n[ИТЕРАЦИЯ {iteration}] ИСПРАВЬ СЛЕДУЮЩИЕ ПРОБЛЕМЫ:\n{previous_feedback.strip()}")

        # Финальная инструкция
        lines.append(
            "\nНапиши полный материал. Не добавляй пояснений «вот мой текст» или «готово» – только сам материал."
        )

        user_content = "\n".join(lines)
        return [{"role": "user", "content": user_content}]

    # ------------------------------------------------------------------
    # 3. Промпт оценки (scoring)
    # ------------------------------------------------------------------

    def build_scoring_prompt(
        self,
        draft: str,
        author: AuthorProfile,
        task: GenerationTask,
    ) -> list[dict[str, str]]:
        """
        Формирует messages для LLM-evaluator (scoring).

        Запрашивает у модели JSON-ответ с оценками по 6 измерениям:
        - ``persona_consistency`` (0.0–1.0)
        - ``factual_accuracy`` (0.0–1.0)
        - ``hallucination_rate`` (0.0–1.0, меньше – лучше)
        - ``coherence`` (0.0–1.0)
        - ``topic_relevance`` (0.0–1.0)
        - ``fluency`` (0.0–1.0)
        - ``feedback`` – одна конкретная инструкция по улучшению

        Args:
            draft: текст черновика для оценки.
            author: профиль автора.
            task: задание на генерацию.

        Returns:
            Список messages для передачи в ``llm_client.generate_json()``.
        """
        voice_excerpt = author.persona.voice_description[:300].strip()
        required_rules = "; ".join(author.style_rules.required[:5]) if author.style_rules.required else "–"
        forbidden_rules = "; ".join(author.style_rules.forbidden[:5]) if author.style_rules.forbidden else "–"

        system = (
            "Ты – строгий литературный редактор и факт-чекер. "
            "Оцениваешь материал объективно по заданным критериям. "
            "Отвечаешь ТОЛЬКО валидным JSON, без комментариев вне JSON."
        )

        user = textwrap.dedent(f"""\
            Оцени следующий материал по 6 критериям (каждый от 0.0 до 1.0, кроме hallucination_rate).

            [ПРОФИЛЬ АВТОРА: {author.name}]
            Ожидаемый голос: {voice_excerpt}
            Обязательные правила: {required_rules}
            Запрещено: {forbidden_rules}

            [ЗАДАНИЕ]
            Тип: {task.task_type}
            Тема: {task.brief}
            Язык: {task.lang}

            [КРИТЕРИИ ОЦЕНКИ]
            1. persona_consistency (0.0–1.0): Насколько голос и стиль соответствуют профилю «{author.name}»?
               1.0 = текст неотличим от настоящего автора; 0.0 = полное несоответствие.

            2. factual_accuracy (0.0–1.0): Корректность фактов, чисел, дат, должностей.
               1.0 = все утверждения проверяемы и корректны; 0.0 = серьёзные ошибки.

            3. hallucination_rate (0.0–1.0): Доля непроверяемых/выдуманных утверждений.
               0.0 = нет галлюцинаций; 0.15+ = критический уровень.

            4. coherence (0.0–1.0): Логическая связность, переходы между абзацами, структура.

            5. topic_relevance (0.0–1.0): Соответствие материала теме «{task.brief}».
               1.0 = полное раскрытие; 0.6– = существенный drift.

            6. fluency (0.0–1.0): Читабельность, грамматическая корректность, отсутствие стилистических ошибок.

            7. feedback: ОДНА конкретная инструкция по улучшению (если всё хорошо – пустая строка).

            [МАТЕРИАЛ ДЛЯ ОЦЕНКИ]
            ---
            {draft[:4000]}
            ---

            Ответь строго в JSON:
            {{
              "persona_consistency": 0.0,
              "factual_accuracy": 0.0,
              "hallucination_rate": 0.0,
              "coherence": 0.0,
              "topic_relevance": 0.0,
              "fluency": 0.0,
              "feedback": ""
            }}
        """)

        return [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ]

    # ------------------------------------------------------------------
    # 4. Промпт переписи (rewrite)
    # ------------------------------------------------------------------

    def build_rewrite_prompt(
        self,
        draft: str,
        feedback: str,
        author: AuthorProfile,
        task: GenerationTask,
    ) -> list[dict[str, str]]:
        """
        Формирует messages для итеративной переписи черновика.

        В отличие от ``build_generation_prompt``, здесь акцент на
        конкретном feedback и сохранении уже хорошего содержания.

        Args:
            draft: текущий черновик (плохо прошедший scoring).
            feedback: конкретные проблемы из ScoringResult.feedback.
            author: профиль автора.
            task: задание на генерацию.

        Returns:
            Список messages.
        """
        genre_instr = _GENRE_INSTRUCTIONS.get(
            task.task_type,
            _DEFAULT_GENRE_INSTRUCTION.format(task_type=task.task_type),
        )

        system = (
            f"Ты {author.name}. Ты переписываешь свой же черновик, устраняя конкретные проблемы. "
            "Сохраняй фактологию и структуру исходного текста там, где они верны. "
            "Переписывай только то, на что указывает feedback."
        )

        user = textwrap.dedent(f"""\
            [ЗАДАНИЕ]
            Тема: {task.brief}
            Тип: {task.task_type}
            Язык: {task.lang}
            Целевой объём: {task.target_word_count} слов.
            {genre_instr}

            [КОНКРЕТНЫЕ ПРОБЛЕМЫ ДЛЯ ИСПРАВЛЕНИЯ]
            {feedback.strip()}

            [ИСХОДНЫЙ ЧЕРНОВИК]
            ---
            {draft.strip()}
            ---

            Перепиши материал, устранив все указанные проблемы. "
            "Выдай только готовый текст без пояснений.
        """)

        return [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ]

    # ------------------------------------------------------------------
    # 5. Промпт реинъекции стиля (anti-drift)
    # ------------------------------------------------------------------

    def build_reinjection_prompt(self, author: AuthorProfile) -> str:
        """
        Формирует короткое напоминание о стиле для mid-generation реинъекции.

        Используется в Orchestrator каждые N слов (``anti_drift.reinjection_every_n_words``)
        как дополнительное user-сообщение в середине длинной генерации.

        Args:
            author: профиль автора.

        Returns:
            Строка напоминания (не список – передаётся как отдельное user-сообщение).
        """
        anchor_phrases = author.anti_drift.anchor_phrases
        if anchor_phrases:
            anchor_block = "\n".join(f"  - «{p}»" for p in anchor_phrases[:5])
        else:
            # Фолбэк на sentence_starters из style_rules
            starters = author.style_rules.sentence_starters[:5]
            if starters:
                anchor_block = "\n".join(f"  - «{s}»" for s in starters)
            else:
                anchor_block = "  - Строгий академический тон\n  - Без восклицательных знаков"

        return _REINJECTION_TEMPLATE.format(
            name=author.name,
            anchor_phrases=anchor_block,
        )
