"""Generic Role-Based Access Control (RBAC) for qazstack.governance.

Provides a configurable permission system with no external dependencies.
Users define their own Role enums or use the built-in DefaultRoles preset.

Example::

    from qazstack.governance.roles import RoleRegistry, DefaultRoles, check_permission

    registry = RoleRegistry()
    registry.register(DefaultRoles)

    check_permission(DefaultRoles.ADMIN, "param_change")  # True
    check_permission(DefaultRoles.VIEWER, "param_change")  # False

    require_permission(DefaultRoles.VIEWER, "delete")  # raises PermissionDeniedError
"""

from __future__ import annotations

from enum import Enum
from typing import Iterable

# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class PermissionDeniedError(PermissionError):
    """Raised when a role does not have the required permission.

    Attributes:
        role: The role that was checked.
        permission: The permission that was required.
    """

    def __init__(self, role: str, permission: str) -> None:
        self.role = role
        self.permission = permission
        super().__init__(f"Role '{role}' does not have permission '{permission}'")


# ---------------------------------------------------------------------------
# Role base class
# ---------------------------------------------------------------------------


class Role(str, Enum):
    """Base class for user-defined role enums.

    Subclass this to create project-specific roles::

        class MyRole(Role):
            READER = "reader"
            WRITER = "writer"
    """


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------


class RoleRegistry:
    """Registry mapping roles to permission sets.

    Supports any role type (str, Role enum, or plain string) to a set of
    permission strings.  Thread-safe for reads; register all roles before
    concurrent use.

    Example::

        registry = RoleRegistry()
        registry.register_role("admin", {"read", "write", "delete"})
        registry.register_role("viewer", {"read"})
        assert registry.has_permission("admin", "delete")
    """

    def __init__(self) -> None:
        self._permissions: dict[str, set[str]] = {}

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def register_role(self, role: "str | Role", permissions: Iterable[str]) -> None:
        """Register *role* with the given *permissions*.

        Args:
            role: A role identifier – string or Role enum member.
            permissions: Iterable of permission strings to grant.
        """
        key = role.value if isinstance(role, Enum) else str(role)
        self._permissions[key] = set(permissions)

    def register(self, role_enum: "type[Role]") -> None:
        """Bulk-register all members of a Role enum subclass.

        The enum's ``ROLE_PERMISSIONS`` class attribute (a dict mapping
        member to set of strings) is used when present.  Members without an
        entry receive an empty permission set.

        Args:
            role_enum: A Role enum class that optionally defines
                ``ROLE_PERMISSIONS`` as a ``dict[member, set[str]]``.
        """
        perms: dict = getattr(role_enum, "ROLE_PERMISSIONS", {})
        for member in role_enum:
            self.register_role(member, perms.get(member, set()))

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    def has_permission(self, role: "str | Role", permission: str) -> bool:
        """Return *True* if *role* has *permission*."""
        key = role.value if isinstance(role, Enum) else str(role)
        return permission in self._permissions.get(key, set())

    def permissions_for(self, role: "str | Role") -> frozenset:
        """Return all permissions granted to *role*."""
        key = role.value if isinstance(role, Enum) else str(role)
        return frozenset(self._permissions.get(key, set()))

    def require(self, role: "str | Role", permission: str) -> None:
        """Raise :exc:`PermissionDeniedError` if *role* lacks *permission*.

        Args:
            role: Role to check.
            permission: Required permission string.

        Raises:
            PermissionDeniedError: When the role does not hold the permission.
        """
        if not self.has_permission(role, permission):
            key = role.value if isinstance(role, Enum) else str(role)
            raise PermissionDeniedError(key, permission)


# ---------------------------------------------------------------------------
# Module-level helpers backed by a shared default registry
# ---------------------------------------------------------------------------

_default_registry = RoleRegistry()


def check_permission(role: "str | Role", permission: str) -> bool:
    """Check permission against the module-level default registry.

    Args:
        role: Role to check.
        permission: Permission string.

    Returns:
        ``True`` if the role holds the permission.
    """
    return _default_registry.has_permission(role, permission)


def require_permission(role: "str | Role", permission: str) -> None:
    """Require permission using the module-level default registry.

    Args:
        role: Role to check.
        permission: Permission string.

    Raises:
        PermissionDeniedError: When the role does not hold the permission.
    """
    _default_registry.require(role, permission)


def get_default_registry() -> RoleRegistry:
    """Return the module-level default :class:`RoleRegistry`."""
    return _default_registry


# ---------------------------------------------------------------------------
# DefaultRoles preset
# ---------------------------------------------------------------------------


class DefaultRoles(Role):
    """Four-tier role preset suitable for most applications.

    Permissions follow a cumulative model:

    * ``viewer``     – read-only access
    * ``editor``     – viewer + write / execute
    * ``admin``      – editor + configuration management
    * ``superadmin`` – all permissions including override and audit

    The ``ROLE_PERMISSIONS`` class attribute maps each member to its
    permission set and is read by :meth:`RoleRegistry.register`.
    """

    VIEWER = "viewer"
    EDITOR = "editor"
    ADMIN = "admin"
    SUPERADMIN = "superadmin"


# Attach the permissions mapping after class definition so that member
# references (DefaultRoles.VIEWER, etc.) are fully resolved.
DefaultRoles.ROLE_PERMISSIONS = {  # type: ignore[attr-defined]
    DefaultRoles.VIEWER: {"read"},
    DefaultRoles.EDITOR: {"read", "write", "execute"},
    DefaultRoles.ADMIN: {"read", "write", "execute", "configure", "param_change"},
    DefaultRoles.SUPERADMIN: {
        "read",
        "write",
        "execute",
        "configure",
        "param_change",
        "audit",
        "override",
        "delete",
    },
}

# Register DefaultRoles into the default registry so module-level helpers
# work out of the box.
_default_registry.register(DefaultRoles)
