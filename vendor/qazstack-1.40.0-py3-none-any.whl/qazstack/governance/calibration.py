"""Calibration workflow for qazstack.governance.

Manages a pending → approved | rejected review process for proposed
parameter changes.  Pure Python – no external dependencies.

Example::

    from qazstack.governance.calibration import CalibrationBoard

    board = CalibrationBoard()
    req = board.create_request(
        requested_by="alice",
        parameter_name="threshold",
        current_value={"value": 0.5},
        proposed_value={"value": 0.6},
        reason="Observed drift in regime detection",
    )
    print(req.status)  # "pending"

    approved = board.decide(req.request_id, approved=True,
                            decided_by="bob", reason="Backtest passed")
    print(approved.status)  # "approved"
"""

from __future__ import annotations

import threading
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Protocol, runtime_checkable

# ---------------------------------------------------------------------------
# CalibrationRequest dataclass
# ---------------------------------------------------------------------------


@dataclass
class CalibrationRequest:
    """A single calibration review request.

    Attributes:
        request_id: Unique identifier (e.g. ``"CAL-A3F8C012"``).
        requested_by: Actor who submitted the request.
        parameter_name: Name of the parameter being proposed for change.
        current_value: Snapshot of the current parameter value.
        proposed_value: Proposed new parameter value.
        reason: Justification for the change.
        status: Workflow state – one of ``"pending"``, ``"approved"``,
            ``"rejected"``.
        requested_at: UTC timestamp of submission.
        decided_by: Actor who made the approval decision (``None`` while pending).
        decided_at: UTC timestamp of the decision (``None`` while pending).
        decision_reason: Free-text rationale for the decision.
        backtest_result: Optional backtest summary attached by a reviewer.
    """

    request_id: str
    requested_by: str
    parameter_name: str
    current_value: Any
    proposed_value: Any
    reason: str
    status: str = "pending"
    requested_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    decided_by: str | None = None
    decided_at: datetime | None = None
    decision_reason: str | None = None
    backtest_result: dict | None = None


def _new_request_id() -> str:
    return f"CAL-{uuid.uuid4().hex[:8].upper()}"


# ---------------------------------------------------------------------------
# CalibrationStore backend Protocol
# ---------------------------------------------------------------------------


@runtime_checkable
class CalibrationStore(Protocol):
    """Protocol for pluggable calibration request storage."""

    def save(self, request: CalibrationRequest) -> None:
        """Persist *request* (insert or update)."""
        ...

    def get(self, request_id: str) -> CalibrationRequest | None:
        """Return the request with the given ID, or ``None``."""
        ...

    def list_all(self) -> list[CalibrationRequest]:
        """Return all requests, newest first."""
        ...


# ---------------------------------------------------------------------------
# InMemoryCalibrationStore
# ---------------------------------------------------------------------------


class InMemoryCalibrationStore:
    """Thread-safe in-memory calibration store (satisfies :class:`CalibrationStore`)."""

    def __init__(self) -> None:
        self._store: dict[str, CalibrationRequest] = {}
        self._lock = threading.Lock()

    def save(self, request: CalibrationRequest) -> None:
        with self._lock:
            self._store[request.request_id] = request

    def get(self, request_id: str) -> CalibrationRequest | None:
        with self._lock:
            return self._store.get(request_id)

    def list_all(self) -> list[CalibrationRequest]:
        with self._lock:
            return sorted(
                self._store.values(),
                key=lambda r: r.requested_at,
                reverse=True,
            )


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class CalibrationError(Exception):
    """Base exception for calibration workflow errors."""


class RequestNotFoundError(CalibrationError):
    """Raised when a request_id is not found in the store."""

    def __init__(self, request_id: str) -> None:
        self.request_id = request_id
        super().__init__(f"Calibration request '{request_id}' not found")


class InvalidStatusTransitionError(CalibrationError):
    """Raised when a status transition is not allowed."""

    def __init__(self, request_id: str, current: str, target: str) -> None:
        self.request_id = request_id
        self.current = current
        self.target = target
        super().__init__(f"Cannot transition request '{request_id}' from '{current}' to '{target}'")


# ---------------------------------------------------------------------------
# CalibrationBoard
# ---------------------------------------------------------------------------


class CalibrationBoard:
    """Manages the full lifecycle of calibration requests.

    The status flow is linear: ``pending`` → ``approved`` or ``rejected``.
    Once decided, a request is immutable.

    Args:
        store: Backing store for requests.  Defaults to
            :class:`InMemoryCalibrationStore`.

    Example::

        board = CalibrationBoard()
        req = board.create_request(
            requested_by="analyst",
            parameter_name="vol_floor",
            current_value=0.02,
            proposed_value=0.03,
            reason="Elevated volatility regime",
        )
        board.decide(req.request_id, approved=True, decided_by="head_risk",
                     reason="Committee approved")
    """

    def __init__(self, store: CalibrationStore | None = None) -> None:
        self._store: CalibrationStore = store or InMemoryCalibrationStore()

    @property
    def store(self) -> CalibrationStore:
        """The underlying store instance."""
        return self._store

    def create_request(
        self,
        *,
        requested_by: str,
        parameter_name: str,
        current_value: Any,
        proposed_value: Any,
        reason: str,
        request_id: str | None = None,
        backtest_result: dict | None = None,
    ) -> CalibrationRequest:
        """Submit a new calibration request.

        Args:
            requested_by: Actor submitting the request.
            parameter_name: Name of the parameter under review.
            current_value: Existing value (any serialisable type).
            proposed_value: Proposed replacement value.
            reason: Justification text.
            request_id: Explicit ID.  Auto-generated when ``None``.
            backtest_result: Optional pre-run backtest data.

        Returns:
            The newly created :class:`CalibrationRequest` in ``"pending"`` status.
        """
        req = CalibrationRequest(
            request_id=request_id or _new_request_id(),
            requested_by=requested_by,
            parameter_name=parameter_name,
            current_value=current_value,
            proposed_value=proposed_value,
            reason=reason,
            status="pending",
            backtest_result=backtest_result,
        )
        self._store.save(req)
        return req

    def get_request(self, request_id: str) -> CalibrationRequest:
        """Return the request with *request_id*.

        Args:
            request_id: Identifier to look up.

        Returns:
            The matching :class:`CalibrationRequest`.

        Raises:
            RequestNotFoundError: When *request_id* is unknown.
        """
        req = self._store.get(request_id)
        if req is None:
            raise RequestNotFoundError(request_id)
        return req

    def decide(
        self,
        request_id: str,
        approved: bool,
        decided_by: str,
        reason: str,
        *,
        backtest_result: dict | None = None,
    ) -> CalibrationRequest:
        """Approve or reject a pending calibration request.

        Args:
            request_id: The request to decide on.
            approved: ``True`` to approve, ``False`` to reject.
            decided_by: Actor making the decision.
            reason: Free-text rationale.
            backtest_result: Optional backtest data to attach.

        Returns:
            The updated :class:`CalibrationRequest` with final status.

        Raises:
            RequestNotFoundError: When *request_id* is not found.
            InvalidStatusTransitionError: When the request is not ``"pending"``.
        """
        req = self.get_request(request_id)
        if req.status != "pending":
            target = "approved" if approved else "rejected"
            raise InvalidStatusTransitionError(request_id, req.status, target)

        req.status = "approved" if approved else "rejected"
        req.decided_by = decided_by
        req.decided_at = datetime.now(timezone.utc)
        req.decision_reason = reason
        if backtest_result is not None:
            req.backtest_result = backtest_result
        self._store.save(req)
        return req

    def attach_backtest(self, request_id: str, backtest_result: dict) -> CalibrationRequest:
        """Attach backtest data to a pending request without deciding it.

        Args:
            request_id: The request to update.
            backtest_result: Backtest summary dictionary.

        Returns:
            The updated :class:`CalibrationRequest`.

        Raises:
            RequestNotFoundError: When *request_id* is not found.
        """
        req = self.get_request(request_id)
        req.backtest_result = backtest_result
        self._store.save(req)
        return req

    def list_requests(
        self,
        status: str | None = None,
        limit: int = 20,
    ) -> list[CalibrationRequest]:
        """Return calibration requests, optionally filtered by status.

        Args:
            status: One of ``"pending"``, ``"approved"``, ``"rejected"``,
                or ``None`` to return all.
            limit: Maximum number of results (default 20).

        Returns:
            List of :class:`CalibrationRequest` objects, newest first.
        """
        all_reqs = self._store.list_all()
        if status is not None:
            all_reqs = [r for r in all_reqs if r.status == status]
        return all_reqs[:limit]
