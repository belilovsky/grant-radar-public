"""Async HTTP client for video generation via QazCompute / Wan Studio.

Reads configuration from environment variables:
    QAZCOMPUTE_URL      – base URL (default: https://vgen.qdev.run)
    QAZCOMPUTE_API_KEY  – X-API-Key for authentication (optional for direct Wan Studio)
    VIDEO_CALLER        – X-Caller identifier for cost tracking

Features:
    - Automatic retry with exponential backoff (3 attempts)
    - Circuit breaker protection
    - generate_and_wait() with polling
    - Configurable timeouts
"""

from __future__ import annotations

import asyncio
import logging
import os
import time
import uuid
from typing import Any

import httpx

from .models import (
    GpuStatusResponse,
    VideoGenerateRequest,
    VideoGenerateResponse,
    VideoPreset,
    VideoStatusResponse,
)

logger = logging.getLogger(__name__)

_DEFAULT_URL = "https://vgen.qdev.run"


class VideoError(Exception):
    """Raised when the video service is unreachable or returns an unexpected response."""


class CircuitOpenError(VideoError):
    """Raised when the circuit breaker is open (service assumed down)."""


class _CircuitBreaker:
    """Simple circuit breaker: after `threshold` consecutive failures,
    reject requests for `cooldown` seconds before allowing a probe."""

    def __init__(self, threshold: int = 5, cooldown: float = 30.0):
        self.threshold = threshold
        self.cooldown = cooldown
        self._failures = 0
        self._last_failure: float = 0.0
        self._state = "closed"  # closed | open | half-open

    @property
    def is_open(self) -> bool:
        if self._state == "open":
            if time.monotonic() - self._last_failure > self.cooldown:
                self._state = "half-open"
                return False
            return True
        return False

    def record_success(self) -> None:
        self._failures = 0
        self._state = "closed"

    def record_failure(self) -> None:
        self._failures += 1
        self._last_failure = time.monotonic()
        if self._failures >= self.threshold:
            self._state = "open"
            logger.warning(
                "Circuit breaker OPEN: %d consecutive failures, cooldown %ds",
                self._failures,
                self.cooldown,
            )


class VideoClient:
    """Async HTTP client for Wan Studio video generation with retry and circuit breaker.

    Supports two modes based on the configured URL:
    - **Gateway mode** (URL contains ``/api/v1``): Routes through QazCompute gateway.
      Uses paths like ``/api/v1/video/generate``.
    - **Direct mode** (plain base URL): Talks directly to Wan Studio.
      Uses paths like ``/api/generate``.

    Args:
        base_url: Override the service URL. Defaults to ``QAZCOMPUTE_URL`` env var,
            then ``WANSTUDIO_URL``, then ``https://vgen.qdev.run``.
        api_key: Override the API key (``QAZCOMPUTE_API_KEY`` env var).
        caller: X-Caller header value for cost tracking (``VIDEO_CALLER`` env var).
        timeout: HTTP request timeout in seconds (default 120s for long video gen).
        max_retries: Number of retry attempts on transient failures.
        circuit_threshold: Consecutive failures before circuit opens.
        circuit_cooldown: Seconds to wait before retrying after circuit opens.
    """

    def __init__(
        self,
        base_url: str | None = None,
        api_key: str | None = None,
        caller: str = "",
        timeout: float = 120.0,
        max_retries: int = 3,
        circuit_threshold: int = 5,
        circuit_cooldown: float = 30.0,
    ) -> None:
        raw_url = (base_url or os.getenv("QAZCOMPUTE_URL") or os.getenv("WANSTUDIO_URL") or _DEFAULT_URL).rstrip("/")

        # Determine gateway vs direct mode.
        # Gateway mode: base URL already has /api/v1 embedded, or explicitly set.
        # We normalise so that self.base_url is always the scheme+host root and
        # self._gateway controls which path prefix to use.
        if "/api/v1" in raw_url:
            # Strip the /api/v1 portion so httpx base_url is clean.
            self.base_url = raw_url.split("/api/v1")[0]
            self._gateway = True
        else:
            self.base_url = raw_url
            self._gateway = False

        self.api_key = api_key or os.getenv("QAZCOMPUTE_API_KEY", "")
        self.caller = caller or os.getenv("VIDEO_CALLER", "")
        self.timeout = timeout
        self.max_retries = max_retries
        self._client: httpx.AsyncClient | None = None
        self._circuit = _CircuitBreaker(threshold=circuit_threshold, cooldown=circuit_cooldown)

    # ------------------------------------------------------------------
    # HTTP client lifecycle
    # ------------------------------------------------------------------

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            headers: dict[str, str] = {}
            if self.api_key:
                headers["X-API-Key"] = self.api_key
            if self.caller:
                headers["X-Caller"] = self.caller
            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                headers=headers,
                timeout=httpx.Timeout(self.timeout),
            )
        return self._client

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()
            self._client = None

    # ------------------------------------------------------------------
    # Request helpers
    # ------------------------------------------------------------------

    def _path(self, direct_path: str, gateway_path: str) -> str:
        """Return the appropriate path for the current mode."""
        return f"/api/v1{gateway_path}" if self._gateway else f"/api{direct_path}"

    async def _request_with_retry(self, method: str, path: str, **kwargs: Any) -> Any:
        """Execute HTTP request with retry + circuit breaker."""
        if self._circuit.is_open:
            raise CircuitOpenError(
                f"Circuit breaker is open for video service at {self.base_url}. "
                f"Service assumed unavailable. Will retry after cooldown."
            )

        client = await self._get_client()
        req_id = str(uuid.uuid4())[:12]
        last_exc: Exception | None = None

        for attempt in range(1, self.max_retries + 1):
            try:
                if method == "POST":
                    resp = await client.post(path, headers={"X-Request-ID": req_id}, **kwargs)
                elif method == "DELETE":
                    resp = await client.delete(path, headers={"X-Request-ID": req_id}, **kwargs)
                else:
                    resp = await client.get(path, headers={"X-Request-ID": req_id}, **kwargs)

                # 429 Too Many Requests – respect Retry-After
                if resp.status_code == 429:
                    retry_after = int(resp.headers.get("Retry-After", "5"))
                    if attempt < self.max_retries:
                        logger.warning(
                            "Video service rate limited (429), retry in %ds (attempt %d/%d) req_id=%s",
                            retry_after,
                            attempt,
                            self.max_retries,
                            req_id,
                        )
                        await asyncio.sleep(min(retry_after, 30))
                        continue
                    resp.raise_for_status()

                # 5xx – retryable server errors
                if resp.status_code >= 500:
                    if attempt < self.max_retries:
                        backoff = min(2 ** (attempt - 1), 16)
                        logger.warning(
                            "Video service %s returned %d, retry in %ds (attempt %d/%d) req_id=%s",
                            path,
                            resp.status_code,
                            backoff,
                            attempt,
                            self.max_retries,
                            req_id,
                        )
                        await asyncio.sleep(backoff)
                        continue
                    resp.raise_for_status()

                # 4xx – client errors, don't retry
                resp.raise_for_status()

                self._circuit.record_success()
                return resp

            except httpx.ConnectError as exc:
                last_exc = exc
                self._circuit.record_failure()
                if attempt < self.max_retries:
                    backoff = min(2 ** (attempt - 1), 16)
                    logger.warning(
                        "Video service connection failed, retry in %ds (attempt %d/%d) req_id=%s: %s",
                        backoff,
                        attempt,
                        self.max_retries,
                        req_id,
                        exc,
                    )
                    await asyncio.sleep(backoff)
                    continue

            except httpx.TimeoutException as exc:
                last_exc = exc
                self._circuit.record_failure()
                if attempt < self.max_retries:
                    backoff = min(2 ** (attempt - 1), 16)
                    logger.warning(
                        "Video service timeout, retry in %ds (attempt %d/%d) req_id=%s: %s",
                        backoff,
                        attempt,
                        self.max_retries,
                        req_id,
                        exc,
                    )
                    await asyncio.sleep(backoff)
                    continue

            except httpx.HTTPStatusError as exc:
                self._circuit.record_failure()
                logger.error(
                    "Video service %s returned %s: %s req_id=%s",
                    path,
                    exc.response.status_code,
                    exc.response.text[:500],
                    req_id,
                )
                raise

        # All retries exhausted
        raise VideoError(
            f"Cannot connect to video service at {self.base_url} after {self.max_retries} attempts: {last_exc}"
        )

    async def _post_json(self, path: str, json: dict[str, Any]) -> Any:
        """POST with JSON body; return parsed JSON."""
        resp = await self._request_with_retry("POST", path, json=json)
        return resp.json()

    async def _get_json(self, path: str, params: dict[str, Any] | None = None) -> Any:
        """GET; return parsed JSON."""
        resp = await self._request_with_retry("GET", path, params=params)
        return resp.json()

    async def _get_bytes(self, path: str) -> bytes:
        """GET; return raw bytes (for video download)."""
        resp = await self._request_with_retry("GET", path)
        return resp.content

    async def _delete(self, path: str) -> None:
        """DELETE; ignore response body."""
        await self._request_with_retry("DELETE", path)

    # ------------------------------------------------------------------
    # Public API – Video Generation
    # ------------------------------------------------------------------

    async def generate(
        self,
        request: VideoGenerateRequest | None = None,
        **kwargs: Any,
    ) -> VideoGenerateResponse:
        """Submit a video generation job.

        Accepts either a :class:`VideoGenerateRequest` instance or keyword
        arguments that map directly to its fields::

            await client.generate(prompt="Cinematic sunset", frames=65)

        Returns:
            :class:`VideoGenerateResponse` with ``id``, ``prompt_id``,
            ``status``, ``prompt``, and ``mode``.
        """
        if request is None:
            request = VideoGenerateRequest(**kwargs)
        elif kwargs:
            # Merge extra kwargs into the existing request
            data = request.model_dump()
            data.update(kwargs)
            request = VideoGenerateRequest(**data)

        path = self._path("/generate", "/video/generate")
        payload = request.to_api_dict()
        data = await self._post_json(path, payload)
        return VideoGenerateResponse(**data)

    async def status(self, generation_id: int) -> VideoStatusResponse:
        """Get the status of a video generation job.

        Args:
            generation_id: The numeric ID returned by :meth:`generate`.

        Returns:
            :class:`VideoStatusResponse` with full generation details.
        """
        path = self._path(f"/status/{generation_id}", f"/video/status/{generation_id}")
        data = await self._get_json(path)
        return VideoStatusResponse(**data)

    async def download(self, generation_id: int) -> bytes:
        """Download a completed video as raw bytes.

        Args:
            generation_id: The numeric ID of a completed generation.

        Returns:
            Raw video bytes (typically MP4).

        Raises:
            :exc:`httpx.HTTPStatusError`: If the video is not yet ready (404)
                or another error occurs.
        """
        path = self._path(f"/video/{generation_id}", f"/video/download/{generation_id}")
        return await self._get_bytes(path)

    async def generate_and_wait(
        self,
        timeout: float = 300.0,
        poll_interval: float = 5.0,
        request: VideoGenerateRequest | None = None,
        **kwargs: Any,
    ) -> bytes:
        """Generate a video and wait until it is complete.

        Submits the generation job, then polls :meth:`status` every
        ``poll_interval`` seconds until the job reaches ``completed``
        or ``failed`` status, or until ``timeout`` seconds have elapsed.

        Args:
            timeout: Maximum seconds to wait for completion (default 300).
            poll_interval: Seconds between status polls (default 5).
            request: Optional pre-built :class:`VideoGenerateRequest`.
            **kwargs: Passed to :meth:`generate` if ``request`` is not provided.

        Returns:
            Raw video bytes on success.

        Raises:
            :exc:`VideoError`: If the job fails or times out.
        """
        gen = await self.generate(request=request, **kwargs)
        generation_id = gen.id
        deadline = time.monotonic() + timeout

        logger.info(
            "Video generation submitted: id=%d prompt_id=%s status=%s",
            generation_id,
            gen.prompt_id,
            gen.status,
        )

        while time.monotonic() < deadline:
            await asyncio.sleep(poll_interval)
            stat = await self.status(generation_id)
            logger.debug("Video %d status=%s", generation_id, stat.status)

            if stat.status == "completed":
                return await self.download(generation_id)

            if stat.status == "failed":
                raise VideoError(f"Video generation {generation_id} failed: {stat.error_message}")

        raise VideoError(f"Video generation {generation_id} did not complete within {timeout}s")

    async def list_generations(self) -> list[VideoStatusResponse]:
        """List all video generation jobs.

        Returns:
            List of :class:`VideoStatusResponse` objects.
        """
        path = self._path("/generations", "/video/generations")
        data = await self._get_json(path)
        return [VideoStatusResponse(**item) for item in data]

    async def delete_generation(self, generation_id: int) -> None:
        """Delete a video generation job.

        Args:
            generation_id: The numeric ID of the generation to delete.
        """
        path = self._path(
            f"/generations/{generation_id}",
            f"/video/generations/{generation_id}",
        )
        await self._delete(path)

    # ------------------------------------------------------------------
    # Public API – GPU Status
    # ------------------------------------------------------------------

    async def gpu_status(self) -> GpuStatusResponse:
        """Get GPU status from Wan Studio.

        Returns:
            :class:`GpuStatusResponse` with VRAM info and queue depths.
        """
        path = self._path("/gpu-status", "/video/gpu-status")
        data = await self._get_json(path)
        return GpuStatusResponse(**data)

    # ------------------------------------------------------------------
    # Public API – Presets
    # ------------------------------------------------------------------

    async def list_presets(self) -> list[VideoPreset]:
        """List all saved prompt presets.

        Returns:
            List of :class:`VideoPreset` objects.
        """
        path = self._path("/presets", "/video/presets")
        data = await self._get_json(path)
        return [VideoPreset(**item) for item in data]

    async def create_preset(
        self,
        name: str,
        prompt: str,
        negative_prompt: str = "",
    ) -> VideoPreset:
        """Create a new prompt preset.

        Args:
            name: Display name for the preset.
            prompt: Positive prompt text.
            negative_prompt: Negative prompt text (optional).

        Returns:
            The created :class:`VideoPreset` with server-assigned ``id``.
        """
        path = self._path("/presets", "/video/presets")
        payload: dict[str, Any] = {
            "name": name,
            "prompt": prompt,
            "negative_prompt": negative_prompt,
        }
        data = await self._post_json(path, payload)
        return VideoPreset(**data)

    async def delete_preset(self, preset_id: int) -> None:
        """Delete a prompt preset.

        Args:
            preset_id: The numeric ID of the preset to delete.
        """
        path = self._path(f"/presets/{preset_id}", f"/video/presets/{preset_id}")
        await self._delete(path)

    # ------------------------------------------------------------------
    # Context manager support
    # ------------------------------------------------------------------

    async def __aenter__(self) -> "VideoClient":
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.close()
