"""FastAPI router for Data Bus HTTP endpoints.

Provides REST API for:
- Publishing events from external services
- Querying event history
- Bus status/health
"""

from typing import Any, Optional

from pydantic import BaseModel, Field

from .bus import EventBus
from .event import Event, EventPriority

# --- Request / Response models (module-level for FastAPI compatibility) ---


class EventPublish(BaseModel):
    topic: str = Field(..., description="Event topic (e.g. entity.created)")
    source: str = Field("api", description="Source project")
    payload: dict[str, Any] = Field(default_factory=dict)
    priority: str = Field("normal", description="low/normal/high/critical")
    entity_id: Optional[int] = None
    correlation_id: Optional[str] = None


class EventResponse(BaseModel):
    event_id: str
    topic: str
    handlers_invoked: int


class BusStatus(BaseModel):
    subscriber_patterns: int
    total_handlers: int
    topics_seen: int
    event_counts: dict[str, int]
    history_size: int


def bus_router(bus: EventBus, prefix: str = "/api/bus"):
    """Create a FastAPI APIRouter for the Data Bus.

    Args:
        bus: EventBus instance
        prefix: URL prefix for all endpoints

    Returns:
        APIRouter with bus endpoints
    """
    from fastapi import APIRouter, HTTPException

    router = APIRouter(prefix=prefix, tags=["bus"])

    @router.post("/emit", response_model=EventResponse)
    async def emit_event(body: EventPublish):
        """Publish an event to the Data Bus."""
        try:
            priority = EventPriority(body.priority)
        except ValueError:
            raise HTTPException(400, f"Invalid priority: {body.priority}")

        event = Event(
            topic=body.topic,
            source=body.source,
            payload=body.payload,
            priority=priority,
            entity_id=body.entity_id,
            correlation_id=body.correlation_id,
        )
        count = await bus.emit(event)
        return EventResponse(
            event_id=event.event_id,
            topic=event.topic,
            handlers_invoked=count,
        )

    @router.get("/history")
    async def get_history(
        topic: Optional[str] = None,
        source: Optional[str] = None,
        limit: int = 50,
    ):
        """Query event history."""
        events = bus.history(topic=topic, source=source, limit=limit)
        return [e.to_dict() for e in events]

    @router.get("/topics")
    async def get_topics():
        """List all seen event topics."""
        return bus.topics

    @router.get("/status", response_model=BusStatus)
    async def get_status():
        """Get Data Bus status."""
        return bus.stats()

    return router
