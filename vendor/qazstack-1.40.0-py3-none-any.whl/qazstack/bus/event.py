"""Event model – the unit of communication on the Data Bus.

Events are typed messages with a topic, source project, and payload.
They flow through the bus from publishers to subscribers.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional


class EventPriority(str, Enum):
    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class Event:
    """A single event on the Data Bus.

    Attributes:
        topic: dot-separated event type (e.g. "entity.created")
        source: project that emitted the event
        payload: event-specific data
        priority: event priority level
        event_id: unique event identifier (auto-generated)
        timestamp: when the event was created (auto-generated)
        correlation_id: optional ID to link related events
        entity_id: optional linked entity ID
    """

    topic: str
    source: str = "unknown"
    payload: dict[str, Any] = field(default_factory=dict)
    priority: EventPriority = EventPriority.NORMAL
    event_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    correlation_id: Optional[str] = None
    entity_id: Optional[int] = None

    def matches(self, pattern: str) -> bool:
        """Check if event topic matches a pattern.

        Supports:
        - Exact match: "entity.created"
        - Wildcard suffix: "entity.*"
        - All: "*"
        """
        if pattern == "*":
            return True
        if pattern.endswith(".*"):
            prefix = pattern[:-2]
            return self.topic.startswith(prefix + ".")
        return self.topic == pattern

    def to_dict(self) -> dict[str, Any]:
        return {
            "event_id": self.event_id,
            "topic": self.topic,
            "source": self.source,
            "payload": self.payload,
            "priority": self.priority.value,
            "timestamp": self.timestamp,
            "correlation_id": self.correlation_id,
            "entity_id": self.entity_id,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Event":
        return cls(
            topic=data["topic"],
            source=data.get("source", "unknown"),
            payload=data.get("payload", {}),
            priority=EventPriority(data.get("priority", "normal")),
            event_id=data.get("event_id", uuid.uuid4().hex[:12]),
            timestamp=data.get("timestamp", datetime.now(timezone.utc).isoformat()),
            correlation_id=data.get("correlation_id"),
            entity_id=data.get("entity_id"),
        )
