"""Reviewable activity evidence without participant PII or product policy."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from qazstack.contracts._validation import require_aware, require_identifier, require_one_of, require_text

REVIEWED_ACTIVITY_SCHEMA = "qazstack-reviewed-activity-evidence-v1"
ACTIVITY_EVIDENCE_STATUSES = frozenset({"submitted", "accepted", "rejected", "withdrawn"})


def _iso(value: datetime | None) -> str | None:
    if value is None:
        return None
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _validate_refs(values: tuple[str, ...], field_name: str) -> None:
    if not values:
        raise ValueError(f"{field_name} must not be empty")
    if len(values) != len(set(values)):
        raise ValueError(f"{field_name} must not contain duplicates")
    for value in values:
        require_text(value, field_name)


@dataclass(frozen=True, slots=True)
class ReviewedActivityEvidence:
    """One product-owned activity record with an explicit review state."""

    evidence_id: str
    subject_ref: str
    activity_type: str
    status: str
    occurred_at: datetime
    recorded_at: datetime
    source_refs: tuple[str, ...]
    policy_version: str
    participant_ref: str = ""
    reviewer_ref: str = ""
    reviewed_at: datetime | None = None
    decision_reason: str = ""
    schema_version: str = field(default=REVIEWED_ACTIVITY_SCHEMA, init=False)

    def __post_init__(self) -> None:
        require_identifier(self.evidence_id, "evidence_id")
        require_identifier(self.subject_ref, "subject_ref")
        require_identifier(self.activity_type, "activity_type")
        require_one_of(self.status, ACTIVITY_EVIDENCE_STATUSES, "status")
        require_aware(self.occurred_at, "occurred_at")
        require_aware(self.recorded_at, "recorded_at")
        if self.recorded_at < self.occurred_at:
            raise ValueError("recorded_at cannot be before occurred_at")
        _validate_refs(self.source_refs, "source_refs")
        require_identifier(self.policy_version, "policy_version")
        if self.participant_ref:
            require_identifier(self.participant_ref, "participant_ref")

        reviewed = self.status in {"accepted", "rejected"}
        if reviewed:
            require_identifier(self.reviewer_ref, "reviewer_ref")
            if self.reviewed_at is None:
                raise ValueError("reviewed evidence requires reviewed_at")
            require_aware(self.reviewed_at, "reviewed_at")
            if self.reviewed_at < self.recorded_at:
                raise ValueError("reviewed_at cannot be before recorded_at")
            require_text(self.decision_reason, "decision_reason")
        elif self.reviewer_ref or self.reviewed_at or self.decision_reason:
            raise ValueError("unreviewed evidence must not contain review fields")

    def as_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "evidence_id": self.evidence_id,
            "subject_ref": self.subject_ref,
            "activity_type": self.activity_type,
            "status": self.status,
            "occurred_at": _iso(self.occurred_at),
            "recorded_at": _iso(self.recorded_at),
            "source_refs": list(self.source_refs),
            "policy_version": self.policy_version,
            "participant_ref": self.participant_ref or None,
            "reviewer_ref": self.reviewer_ref or None,
            "reviewed_at": _iso(self.reviewed_at),
            "decision_reason": self.decision_reason or None,
        }
