"""QazStack Audit – plugin-based project compliance checker.

Usage::

    # CLI
    qazstack audit                    # run all checkers
    qazstack audit --category code    # run only code checkers
    qazstack audit --fix              # auto-fix where possible
    qazstack audit --json             # JSON output

    # Python API
    from qazstack.audit import AuditRunner, CheckerRegistry
    from qazstack.audit.checkers import code, infra, deps, ui_seo

    registry = CheckerRegistry()
    registry.auto_discover()
    runner = AuditRunner(registry)
    results = runner.run(Path("."))
"""

from qazstack.audit.api_specs import (
    API_SPEC_CHECK_SCHEMA,
    ApiSpecCheck,
    check_api_spec,
    check_asyncapi_spec,
    check_openapi_spec,
    load_api_spec,
)
from qazstack.audit.assets import (
    ASSET_MANIFEST_SCHEMA,
    AssetDigest,
    AssetManifest,
    AssetManifestError,
    build_asset_manifest,
    describe_asset,
    load_asset_manifest,
    verify_asset_manifest,
)
from qazstack.audit.base import BaseChecker
from qazstack.audit.models import CheckResult, CheckStatus, Severity
from qazstack.audit.registry import CheckerRegistry
from qazstack.audit.runner import AuditRunner

__all__ = [
    "ASSET_MANIFEST_SCHEMA",
    "API_SPEC_CHECK_SCHEMA",
    "ApiSpecCheck",
    "AssetDigest",
    "AssetManifest",
    "AssetManifestError",
    "BaseChecker",
    "CheckResult",
    "CheckStatus",
    "CheckerRegistry",
    "AuditRunner",
    "Severity",
    "build_asset_manifest",
    "check_api_spec",
    "check_asyncapi_spec",
    "check_openapi_spec",
    "describe_asset",
    "load_api_spec",
    "load_asset_manifest",
    "verify_asset_manifest",
]
