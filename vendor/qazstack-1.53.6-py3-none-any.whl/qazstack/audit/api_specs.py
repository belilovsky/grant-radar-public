"""Offline OpenAPI and AsyncAPI artifact checks."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal

API_SPEC_CHECK_SCHEMA = "qazstack-api-spec-check-v1"


@dataclass(frozen=True, slots=True)
class ApiSpecCheck:
    """Result of checking one machine-readable API artifact."""

    path: str
    kind: Literal["openapi", "asyncapi"]
    status: Literal["ok", "error"]
    version: str | None
    operations: int
    detail: str
    schema_version: str = API_SPEC_CHECK_SCHEMA

    @property
    def ok(self) -> bool:
        return self.status == "ok"

    def as_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "path": self.path,
            "kind": self.kind,
            "status": self.status,
            "version": self.version,
            "operations": self.operations,
            "detail": self.detail,
        }


def load_api_spec(path: str | Path) -> dict[str, Any]:
    """Load a JSON or YAML API spec into a mapping.

    YAML support is optional and uses PyYAML when installed. JSON remains the
    recommended CI artifact format because it has no extra dependency.
    """

    spec_path = Path(path)
    text = spec_path.read_text(encoding="utf-8")
    if spec_path.suffix.lower() in {".yaml", ".yml"}:
        try:
            import yaml  # type: ignore[import-not-found]
        except ImportError as exc:
            raise ValueError("YAML API specs require PyYAML") from exc
        payload = yaml.safe_load(text)
    else:
        payload = json.loads(text)
    if not isinstance(payload, dict):
        raise ValueError("API spec root must be an object")
    return payload


def check_openapi_spec(path: str | Path) -> ApiSpecCheck:
    """Validate a minimal OpenAPI artifact boundary without network calls."""

    spec_path = Path(path)
    try:
        payload = load_api_spec(spec_path)
        version = payload.get("openapi")
        if not isinstance(version, str) or not version:
            raise ValueError("missing openapi version")
        paths = payload.get("paths")
        if not isinstance(paths, dict) or not paths:
            raise ValueError("openapi paths must be a non-empty object")
        operations = _count_openapi_operations(paths)
        if operations < 1:
            raise ValueError("openapi paths must contain at least one operation")
        info = payload.get("info")
        if not isinstance(info, dict) or not info.get("title") or not info.get("version"):
            raise ValueError("openapi info.title and info.version are required")
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        return ApiSpecCheck(str(spec_path), "openapi", "error", None, 0, str(exc))
    return ApiSpecCheck(str(spec_path), "openapi", "ok", version, operations, "valid OpenAPI artifact")


def check_asyncapi_spec(path: str | Path) -> ApiSpecCheck:
    """Validate a minimal AsyncAPI artifact boundary without network calls."""

    spec_path = Path(path)
    try:
        payload = load_api_spec(spec_path)
        version = payload.get("asyncapi")
        if not isinstance(version, str) or not version:
            raise ValueError("missing asyncapi version")
        channels = payload.get("channels")
        if not isinstance(channels, dict) or not channels:
            raise ValueError("asyncapi channels must be a non-empty object")
        operations = _count_asyncapi_operations(payload, channels)
        if operations < 1:
            raise ValueError("asyncapi must contain at least one operation or channel message")
        info = payload.get("info")
        if not isinstance(info, dict) or not info.get("title") or not info.get("version"):
            raise ValueError("asyncapi info.title and info.version are required")
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        return ApiSpecCheck(str(spec_path), "asyncapi", "error", None, 0, str(exc))
    return ApiSpecCheck(str(spec_path), "asyncapi", "ok", version, operations, "valid AsyncAPI artifact")


def check_api_spec(path: str | Path) -> ApiSpecCheck:
    """Detect and validate an OpenAPI or AsyncAPI artifact."""

    spec_path = Path(path)
    try:
        payload = load_api_spec(spec_path)
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        return ApiSpecCheck(str(spec_path), "openapi", "error", None, 0, str(exc))
    if "openapi" in payload:
        return check_openapi_spec(spec_path)
    if "asyncapi" in payload:
        return check_asyncapi_spec(spec_path)
    return ApiSpecCheck(str(spec_path), "openapi", "error", None, 0, "missing openapi or asyncapi version")


def _count_openapi_operations(paths: dict[str, Any]) -> int:
    methods = {"get", "put", "post", "delete", "options", "head", "patch", "trace"}
    total = 0
    for path_item in paths.values():
        if not isinstance(path_item, dict):
            continue
        total += sum(method in path_item for method in methods)
    return total


def _count_asyncapi_operations(payload: dict[str, Any], channels: dict[str, Any]) -> int:
    operations = payload.get("operations")
    if isinstance(operations, dict) and operations:
        return len(operations)
    total = 0
    for channel in channels.values():
        if not isinstance(channel, dict):
            continue
        messages = channel.get("messages")
        if isinstance(messages, dict):
            total += len(messages)
    return total
