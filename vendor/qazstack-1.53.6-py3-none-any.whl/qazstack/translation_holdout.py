"""Fail-closed, aggregate-only frozen holdout assembly.

This module does not create approvals. It accepts events that were already
approved by a named reviewer and packages only their aggregate and gate
outputs for owner review. Empty input is valid but remains ``hold``.
"""

from __future__ import annotations

import re
from typing import Any, Iterable

from qazstack.locale_contract import CANONICAL_LOCALES, normalize_locale
from qazstack.translation_feedback import (
    TranslationFeedbackEvent,
    aggregate_translation_feedback,
    evaluate_translation_feedback_gate,
)

HOLDOUT_SCHEMA_VERSION = "qazstack-translation-holdout-v1"
HOLDOUT_CONTRACT_ID = "qazstack.translation_holdout.v1"
_ID_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9:._/-]{0,255}$")


def _require_id(value: str, field_name: str) -> str:
    if not isinstance(value, str) or not value.strip() or not _ID_PATTERN.fullmatch(value.strip()):
        raise ValueError(f"{field_name} must be a bounded identifier")
    return value.strip()


def _require_locale(value: str, field_name: str) -> str:
    normalized = normalize_locale(value)
    if normalized not in CANONICAL_LOCALES:
        raise ValueError(f"{field_name} must normalize to one of: {', '.join(CANONICAL_LOCALES)}")
    return normalized


def build_translation_holdout(
    events: Iterable[TranslationFeedbackEvent],
    *,
    holdout_id: str,
    project_id: str,
    source_locale: str,
    target_locale: str,
    source_snapshot_ref: str,
    min_events: int,
    min_publish_ready_rate: float,
    max_issue_rate: float,
    min_mean_quality_score: float,
) -> dict[str, Any]:
    """Build a text-free frozen holdout result from approved-only events.

    The function rejects mixed or merely reviewed events instead of silently
    filtering them. This keeps a caller from accidentally treating a partial
    review set as an approved canary.
    """

    holdout_id = _require_id(holdout_id, "holdout_id")
    project_id = _require_id(project_id, "project_id")
    source_snapshot_ref = _require_id(source_snapshot_ref, "source_snapshot_ref")
    source_locale = _require_locale(source_locale, "source_locale")
    target_locale = _require_locale(target_locale, "target_locale")
    if source_locale == target_locale:
        raise ValueError("source_locale and target_locale must differ")

    materialized = tuple(events)
    if any(not isinstance(event, TranslationFeedbackEvent) for event in materialized):
        raise TypeError("events must contain TranslationFeedbackEvent instances")
    for event in materialized:
        if event.project_id != project_id:
            raise ValueError("holdout events must belong to project_id")
        if event.source_locale != source_locale or event.target_locale != target_locale:
            raise ValueError("holdout events must use the declared language pair")
        if event.review_status != "approved" or event.memory_eligibility != "approved":
            raise ValueError("holdout accepts approved-only events")

    aggregate = aggregate_translation_feedback(materialized)
    gate = evaluate_translation_feedback_gate(
        aggregate,
        min_events=min_events,
        min_publish_ready_rate=min_publish_ready_rate,
        max_issue_rate=max_issue_rate,
        min_mean_quality_score=min_mean_quality_score,
    )
    return {
        "schema_version": HOLDOUT_SCHEMA_VERSION,
        "contract_id": HOLDOUT_CONTRACT_ID,
        "contract_version": "1.0.0",
        "holdout_id": holdout_id,
        "project_id": project_id,
        "source_locale": source_locale,
        "target_locale": target_locale,
        "source_snapshot_ref": source_snapshot_ref,
        "approved_only": True,
        "event_count": len(materialized),
        "thresholds": {
            "min_events": min_events,
            "min_publish_ready_rate": min_publish_ready_rate,
            "max_issue_rate": max_issue_rate,
            "min_mean_quality_score": min_mean_quality_score,
        },
        "aggregate": aggregate,
        "gate": gate,
        "policy": {
            "raw_text_export": False,
            "remote_write": False,
            "automatic_memory_promotion": False,
        },
    }


__all__ = [
    "HOLDOUT_CONTRACT_ID",
    "HOLDOUT_SCHEMA_VERSION",
    "build_translation_holdout",
]
