"""Privacy-safe language coverage metrics for consumer shadow reports."""

from __future__ import annotations

import re
from collections.abc import Iterable, Mapping, Sequence
from typing import Any

from .locale_contract import CANONICAL_LOCALES, normalize_locale

SCHEMA_VERSION = "qazstack-language-observability-v1"
CONTRACT_ID = "qazstack.language_observability.v1"
CONTRACT_VERSION = "1.0.0"
_IDENTIFIER = re.compile(r"^[a-z0-9][A-Za-z0-9._:/-]{0,127}$")


def _bounded_identifier(value: Any, field_name: str) -> str:
    normalized = str(value or "").strip()
    if not _IDENTIFIER.fullmatch(normalized):
        raise ValueError(f"{field_name} must be a bounded identifier")
    return normalized


def _ratio(numerator: int, denominator: int) -> float | None:
    if denominator == 0:
        return None
    return round(numerator / denominator, 6)


def _locale_values(value: Any) -> tuple[str, ...]:
    if isinstance(value, str):
        values: Sequence[Any] = (value,)
    elif isinstance(value, (list, tuple, set, frozenset)):
        values = tuple(value)
    else:
        return ()
    normalized: list[str] = []
    for item in values:
        locale = normalize_locale(item if isinstance(item, str) else None)
        if locale and locale not in normalized:
            normalized.append(locale)
    return tuple(normalized)


def _catalog_metrics(catalog: Mapping[str, Any]) -> tuple[tuple[str, ...], int, float | None]:
    locale_keys: dict[str, set[str]] = {}
    for raw_locale, entries in catalog.items():
        locale = normalize_locale(raw_locale if isinstance(raw_locale, str) else None)
        if not locale:
            continue
        keys = set(entries) if isinstance(entries, Mapping) else set()
        locale_keys.setdefault(locale, set()).update(str(key) for key in keys)
    locales = tuple(sorted(locale_keys))
    union = set().union(*locale_keys.values()) if locale_keys else set()
    slots = len(locales) * len(union)
    present = sum(len(keys) for keys in locale_keys.values())
    return locales, len(union), _ratio(present, slots)


def build_language_observability_report(
    *,
    project_id: str,
    surface: str,
    ui_catalog: Mapping[str, Any],
    public_items: Iterable[Mapping[str, Any]],
    public_item_locale_field: str = "locale",
    translation_target_locales: Iterable[str] = (),
    public_translation_coverage_rate: float | None = None,
    candidate_count: int = 0,
    approved_count: int = 0,
    rejected_count: int = 0,
) -> dict[str, Any]:
    """Build deterministic aggregate-only metrics; never copy text values."""

    project_id = _bounded_identifier(project_id, "project_id")
    surface = _bounded_identifier(surface, "surface")
    if not isinstance(ui_catalog, Mapping):
        raise TypeError("ui_catalog must be a mapping")
    items = tuple(public_items)
    if any(not isinstance(item, Mapping) for item in items):
        raise TypeError("public_items must contain mappings")
    counts = (candidate_count, approved_count, rejected_count)
    if any(isinstance(value, bool) or not isinstance(value, int) or value < 0 for value in counts):
        raise ValueError("translation state counts must be non-negative integers")
    if public_translation_coverage_rate is not None and not (
        isinstance(public_translation_coverage_rate, (int, float))
        and not isinstance(public_translation_coverage_rate, bool)
        and 0 <= public_translation_coverage_rate <= 1
    ):
        raise ValueError("public_translation_coverage_rate must be between 0 and 1")

    ui_locales, ui_key_count, ui_parity_rate = _catalog_metrics(ui_catalog)
    observed_locales: set[str] = set()
    known_count = 0
    canonical_count = 0
    for item in items:
        values = _locale_values(item.get(public_item_locale_field))
        if values:
            known_count += 1
            observed_locales.update(values)
            if all(value in CANONICAL_LOCALES for value in values):
                canonical_count += 1

    target_locales = tuple(sorted({locale for raw in translation_target_locales for locale in _locale_values(raw)}))
    return {
        "schema_version": SCHEMA_VERSION,
        "contract_id": CONTRACT_ID,
        "contract_version": CONTRACT_VERSION,
        "project_id": project_id,
        "surface": surface,
        "mode": "shadow",
        "dimensions": {
            "ui_locales": list(ui_locales),
            "observed_item_locales": sorted(observed_locales),
            "translation_target_locales": list(target_locales),
        },
        "metrics": {
            "ui_catalog_key_count": ui_key_count,
            "ui_catalog_parity_rate": ui_parity_rate,
            "public_item_count": len(items),
            "public_item_language_metadata_known_rate": _ratio(known_count, len(items)),
            "public_item_canonical_language_rate": _ratio(canonical_count, len(items)),
            "public_translation_coverage_rate": (
                round(float(public_translation_coverage_rate), 6)
                if public_translation_coverage_rate is not None
                else None
            ),
            "candidate_count": candidate_count,
            "approved_count": approved_count,
            "rejected_count": rejected_count,
        },
        "policy": {
            "raw_text_export": False,
            "remote_write": False,
            "automatic_memory_promotion": False,
            "source_language_metadata_is_not_translation": True,
        },
    }


__all__ = [
    "CONTRACT_ID",
    "CONTRACT_VERSION",
    "SCHEMA_VERSION",
    "build_language_observability_report",
]
