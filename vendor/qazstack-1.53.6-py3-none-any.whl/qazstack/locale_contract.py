"""Canonical locale contract shared by QazStack consumers and SDKs.

Only exact canonical tags are valid in persistent consumer configuration.  The
normalizer is deliberately an ingress boundary: it accepts documented legacy
aliases, but never turns an arbitrary Chinese or regional tag into a locale.
"""

from __future__ import annotations

import json
from importlib.resources import files
from typing import Final, Iterable

# Resolve the resource from the root package.  Asking importlib.resources for
# ``qazstack.i18n`` imports that package's compatibility re-exports, which in
# turn import this module and creates a circular import for direct consumers.
_CONTRACT: Final = json.loads(files("qazstack").joinpath("i18n", "resources", "locale-contract.v1.json").read_text())

CANONICAL_LOCALES: Final = tuple(_CONTRACT["canonical_locales"])
DEFAULT_ACTIVE_LOCALES: Final = tuple(_CONTRACT["default_active_locales"])
DEFAULT_LOCALE: Final = _CONTRACT["default_locale"]
LEGACY_LOCALE_ALIASES: Final = dict(_CONTRACT["aliases"])
LEGACY_PROVIDER_LOCALE_MAP: Final = dict(_CONTRACT["legacy_provider_locale_map"])
LOCALE_CONTRACT: Final = _CONTRACT
_CANONICAL_BY_FOLDED: Final = {locale.casefold(): locale for locale in CANONICAL_LOCALES}


def normalize_locale(value: str | None) -> str:
    """Normalize documented ingress input to a canonical locale or ``""``.

    The only Chinese ingress aliases are ``zh``, ``zh-CN`` and ``zh-SG``.
    In particular, ``zh-TW`` and all traditional Chinese tags are rejected.
    """

    normalized = str(value or "").strip().casefold().replace("_", "-")
    if not normalized:
        return ""
    if normalized in LEGACY_LOCALE_ALIASES:
        return LEGACY_LOCALE_ALIASES[normalized]
    if normalized in _CANONICAL_BY_FOLDED:
        return _CANONICAL_BY_FOLDED[normalized]

    # Retain the established regional ingress compatibility for non-Chinese
    # languages only. Chinese regional/script tags must be explicitly listed.
    base = normalized.split("-", 1)[0]
    if base in {"kk", "ru", "en"}:
        return base
    return ""


def is_canonical_locale(value: object) -> bool:
    """Return whether *value* is an exact internal locale-contract value."""

    return isinstance(value, str) and value in CANONICAL_LOCALES


def validate_consumer_locale(value: object, field_name: str = "locale") -> str:
    """Fail closed for noncanonical persisted/configured consumer values."""

    if not is_canonical_locale(value):
        raise ValueError(f"{field_name} must be one of: {', '.join(CANONICAL_LOCALES)}")
    return value


def validate_consumer_locales(values: Iterable[object], field_name: str = "supported_langs") -> tuple[str, ...]:
    """Validate a non-empty, duplicate-free canonical consumer locale list."""

    if isinstance(values, (str, bytes)):
        raise ValueError(f"{field_name} must be a list of canonical locales")
    resolved = tuple(validate_consumer_locale(value, field_name) for value in values)
    if not resolved:
        raise ValueError(f"{field_name} must not be empty")
    if len(set(resolved)) != len(resolved):
        raise ValueError(f"{field_name} must not contain duplicates")
    return resolved


def to_legacy_provider_locale(value: str | None) -> str:
    """Map a canonical locale to the legacy key expected by a provider."""

    normalized = normalize_locale(value)
    return LEGACY_PROVIDER_LOCALE_MAP.get(normalized, normalized)


def canonicalize_locales(values: Iterable[str | None]) -> tuple[str, ...]:
    """Normalize ingress values and omit invalid values (not for configuration)."""

    return tuple(dict.fromkeys(locale for value in values if (locale := normalize_locale(value))))


def locale_url_prefix(value: object) -> str:
    """Return a canonical public URL prefix from a strict consumer locale."""

    return f"/{validate_consumer_locale(value).lower()}"
