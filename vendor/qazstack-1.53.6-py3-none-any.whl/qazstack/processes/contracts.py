"""Versioned process-model interchange contracts.

The contract is intentionally small and dependency-free.  It makes the
operational minimum explicit (owner, artefact reference and graph integrity)
without turning QazStack into a workflow engine or taking ownership of a
product's approval policy.
"""

from __future__ import annotations

import hashlib
import json
import math
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from typing import Any

from qazstack.contracts._validation import require_identifier, require_one_of, require_text

PROCESS_MODEL_SCHEMA_VERSION = "qazstack-process-model-v1"
PROCESS_NOTATIONS = frozenset({"process", "idef0", "uml"})
PROCESS_RISKS = frozenset({"low", "medium", "high", "critical"})
PROCESS_DETAIL_LEVELS = frozenset({"core", "full", "control"})
PROCESS_NODE_KINDS = frozenset({"activity", "gateway", "role", "input", "control", "output", "mechanism"})
PROCESS_EDGE_RELATIONS = frozenset(
    {"sequence", "message", "input", "control", "output", "mechanism", "decomposition", "approval", "rework"}
)
PROCESS_MODEL_FIELDS = frozenset(
    {
        "schema_version",
        "model_id",
        "title",
        "notation",
        "template_id",
        "detail_mode",
        "process_owner",
        "purpose",
        "review_cadence",
        "nodes",
        "edges",
    }
)
PROCESS_NODE_FIELDS = frozenset(
    {
        "id",
        "title",
        "category",
        "owner",
        "evidence_ref",
        "risk",
        "kind",
        "acceptance_criteria",
        "sla_hours",
        "escalation_ref",
        "position",
    }
)
PROCESS_EDGE_FIELDS = frozenset({"id", "source", "target", "label", "relation"})


def _optional_text(value: str | None, field_name: str) -> str | None:
    if value is None:
        return None
    return require_text(value, field_name)


def _position_payload(value: tuple[float, float] | None) -> dict[str, float] | None:
    if value is None:
        return None
    return {"x": value[0], "y": value[1]}


def _position_from_payload(value: object) -> tuple[float, float] | None:
    if value is None:
        return None
    if not isinstance(value, Mapping):
        raise ValueError("position must be an object")
    _reject_unknown_fields(value, {"x", "y"}, "position")
    x, y = value.get("x"), value.get("y")
    if isinstance(x, bool) or isinstance(y, bool) or not isinstance(x, (int, float)) or not isinstance(y, (int, float)):
        raise ValueError("position x and y must be finite numbers")
    if not float("-inf") < float(x) < float("inf") or not float("-inf") < float(y) < float("inf"):
        raise ValueError("position x and y must be finite numbers")
    return (float(x), float(y))


def _as_mapping(value: object, field_name: str) -> Mapping[str, object]:
    if not isinstance(value, Mapping):
        raise ValueError(f"{field_name} must be an object")
    return value


def _as_sequence(value: object, field_name: str) -> Sequence[object]:
    if isinstance(value, (str, bytes)) or not isinstance(value, Sequence):
        raise ValueError(f"{field_name} must be an array")
    return value


def _reject_unknown_fields(payload: Mapping[str, object], allowed: frozenset[str] | set[str], field_name: str) -> None:
    unknown = sorted(str(key) for key in payload if key not in allowed)
    if unknown:
        raise ValueError(f"{field_name} contains unknown fields: {', '.join(unknown)}")


def _mermaid_id(value: str) -> str:
    return "n_" + "".join(char if char.isalnum() else "_" for char in value)


def _mermaid_label(value: str) -> str:
    return value.replace('"', "'").replace("[", "(").replace("]", ")").replace("\n", " ")


@dataclass(frozen=True, slots=True)
class ProcessNode:
    """One accountable process block; never carries raw evidence or campaign text."""

    node_id: str
    title: str
    category: str
    owner: str
    evidence_ref: str
    risk: str = "medium"
    position: tuple[float, float] | None = None
    kind: str | None = None
    acceptance_criteria: tuple[str, ...] = ()
    sla_hours: float | None = None
    escalation_ref: str | None = None

    def __post_init__(self) -> None:
        require_identifier(self.node_id, "node_id")
        require_text(self.title, "title")
        require_text(self.category, "category")
        require_text(self.owner, "owner")
        require_text(self.evidence_ref, "evidence_ref")
        require_one_of(self.risk, PROCESS_RISKS, "risk")
        object.__setattr__(self, "kind", _optional_text(self.kind, "kind"))
        if self.kind is not None:
            require_one_of(self.kind, PROCESS_NODE_KINDS, "kind")
        if not isinstance(self.acceptance_criteria, tuple):
            object.__setattr__(self, "acceptance_criteria", tuple(self.acceptance_criteria))
        for criterion in self.acceptance_criteria:
            require_text(criterion, "acceptance_criteria item")
        if self.sla_hours is not None:
            is_valid_sla = (
                not isinstance(self.sla_hours, bool)
                and isinstance(self.sla_hours, (int, float))
                and math.isfinite(float(self.sla_hours))
                and self.sla_hours > 0
            )
            if not is_valid_sla:
                raise ValueError("sla_hours must be a positive finite number")
            object.__setattr__(self, "sla_hours", float(self.sla_hours))
        object.__setattr__(self, "escalation_ref", _optional_text(self.escalation_ref, "escalation_ref"))
        if self.kind in {"activity", "gateway"}:
            if not self.acceptance_criteria or self.sla_hours is None:
                raise ValueError("executable process nodes require acceptance_criteria and sla_hours")
            if self.risk in {"high", "critical"} and self.escalation_ref is None:
                raise ValueError("high-risk executable process nodes require escalation_ref")
        if self.position is not None:
            normalized_position = _position_from_payload(_position_payload(self.position))
            object.__setattr__(self, "position", normalized_position)

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "id": self.node_id,
            "title": self.title,
            "category": self.category,
            "owner": self.owner,
            "evidence_ref": self.evidence_ref,
            "risk": self.risk,
        }
        if self.position is not None:
            payload["position"] = _position_payload(self.position)
        if self.kind is not None:
            payload["kind"] = self.kind
        if self.acceptance_criteria:
            payload["acceptance_criteria"] = list(self.acceptance_criteria)
        if self.sla_hours is not None:
            payload["sla_hours"] = self.sla_hours
        if self.escalation_ref is not None:
            payload["escalation_ref"] = self.escalation_ref
        return payload

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> "ProcessNode":
        _reject_unknown_fields(payload, PROCESS_NODE_FIELDS, "node")
        return cls(
            node_id=str(payload.get("id", "")),
            title=str(payload.get("title", "")),
            category=str(payload.get("category", "")),
            owner=str(payload.get("owner", "")),
            evidence_ref=str(payload.get("evidence_ref", "")),
            risk=str(payload.get("risk", "medium")),
            position=_position_from_payload(payload.get("position")),
            kind=payload.get("kind") if isinstance(payload.get("kind"), str) else None,
            acceptance_criteria=(
                tuple(str(value) for value in _as_sequence(payload.get("acceptance_criteria"), "acceptance_criteria"))
                if payload.get("acceptance_criteria") is not None
                else ()
            ),
            sla_hours=(
                payload.get("sla_hours")
                if isinstance(payload.get("sla_hours"), (int, float)) and not isinstance(payload.get("sla_hours"), bool)
                else None
            ),
            escalation_ref=payload.get("escalation_ref") if isinstance(payload.get("escalation_ref"), str) else None,
        )


@dataclass(frozen=True, slots=True)
class ProcessEdge:
    """A directed structural relation between two declared process nodes."""

    edge_id: str
    source: str
    target: str
    label: str = ""
    relation: str | None = None

    def __post_init__(self) -> None:
        require_identifier(self.edge_id, "edge_id")
        require_identifier(self.source, "source")
        require_identifier(self.target, "target")
        if self.source == self.target:
            raise ValueError("process edge must not target its own node")
        if self.label:
            require_text(self.label, "label")
        object.__setattr__(self, "relation", _optional_text(self.relation, "relation"))
        if self.relation is not None:
            require_one_of(self.relation, PROCESS_EDGE_RELATIONS, "relation")

    def to_dict(self) -> dict[str, str]:
        payload = {"id": self.edge_id, "source": self.source, "target": self.target, "label": self.label}
        if self.relation is not None:
            payload["relation"] = self.relation
        return payload

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> "ProcessEdge":
        _reject_unknown_fields(payload, PROCESS_EDGE_FIELDS, "edge")
        return cls(
            edge_id=str(payload.get("id", "")),
            source=str(payload.get("source", "")),
            target=str(payload.get("target", "")),
            label=str(payload.get("label", "")),
            relation=payload.get("relation") if isinstance(payload.get("relation"), str) else None,
        )


@dataclass(frozen=True, slots=True)
class ProcessModel:
    """A portable process model with a deterministic interchange representation."""

    model_id: str
    title: str
    notation: str
    nodes: tuple[ProcessNode, ...]
    edges: tuple[ProcessEdge, ...] = ()
    template_id: str | None = None
    detail_mode: str | None = None
    process_owner: str | None = None
    purpose: str | None = None
    review_cadence: str | None = None
    schema_version: str = field(default=PROCESS_MODEL_SCHEMA_VERSION, init=False)

    def __post_init__(self) -> None:
        require_identifier(self.model_id, "model_id")
        require_text(self.title, "title")
        require_one_of(self.notation, PROCESS_NOTATIONS, "notation")
        if not self.nodes:
            raise ValueError("process model requires at least one node")
        object.__setattr__(self, "template_id", _optional_text(self.template_id, "template_id"))
        object.__setattr__(self, "detail_mode", _optional_text(self.detail_mode, "detail_mode"))
        object.__setattr__(self, "process_owner", _optional_text(self.process_owner, "process_owner"))
        object.__setattr__(self, "purpose", _optional_text(self.purpose, "purpose"))
        object.__setattr__(self, "review_cadence", _optional_text(self.review_cadence, "review_cadence"))
        if self.detail_mode is not None:
            require_one_of(self.detail_mode, PROCESS_DETAIL_LEVELS, "detail_mode")
        node_ids = [node.node_id for node in self.nodes]
        if len(node_ids) != len(set(node_ids)):
            raise ValueError("process node ids must be unique")
        edge_ids = [edge.edge_id for edge in self.edges]
        if len(edge_ids) != len(set(edge_ids)):
            raise ValueError("process edge ids must be unique")
        known_nodes = set(node_ids)
        for edge in self.edges:
            if edge.source not in known_nodes or edge.target not in known_nodes:
                raise ValueError("process edge references an unknown node")

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "schema_version": self.schema_version,
            "model_id": self.model_id,
            "title": self.title,
            "notation": self.notation,
            "nodes": [node.to_dict() for node in self.nodes],
            "edges": [edge.to_dict() for edge in self.edges],
        }
        if self.template_id is not None:
            payload["template_id"] = self.template_id
        if self.detail_mode is not None:
            payload["detail_mode"] = self.detail_mode
        if self.process_owner is not None:
            payload["process_owner"] = self.process_owner
        if self.purpose is not None:
            payload["purpose"] = self.purpose
        if self.review_cadence is not None:
            payload["review_cadence"] = self.review_cadence
        return payload

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> "ProcessModel":
        _reject_unknown_fields(payload, PROCESS_MODEL_FIELDS, "process model")
        if payload.get("schema_version") != PROCESS_MODEL_SCHEMA_VERSION:
            raise ValueError(f"schema_version must be {PROCESS_MODEL_SCHEMA_VERSION}")
        nodes = tuple(
            ProcessNode.from_dict(_as_mapping(value, "node")) for value in _as_sequence(payload.get("nodes"), "nodes")
        )
        edges = tuple(
            ProcessEdge.from_dict(_as_mapping(value, "edge")) for value in _as_sequence(payload.get("edges"), "edges")
        )
        return cls(
            model_id=str(payload.get("model_id", "")),
            title=str(payload.get("title", "")),
            notation=str(payload.get("notation", "")),
            template_id=payload.get("template_id") if isinstance(payload.get("template_id"), str) else None,
            detail_mode=payload.get("detail_mode") if isinstance(payload.get("detail_mode"), str) else None,
            process_owner=payload.get("process_owner") if isinstance(payload.get("process_owner"), str) else None,
            purpose=payload.get("purpose") if isinstance(payload.get("purpose"), str) else None,
            review_cadence=payload.get("review_cadence") if isinstance(payload.get("review_cadence"), str) else None,
            nodes=nodes,
            edges=edges,
        )

    def digest(self) -> str:
        """Return a stable integrity hash without adding a mutable timestamp."""

        encoded = json.dumps(self.to_dict(), ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
        return f"sha256:{hashlib.sha256(encoded).hexdigest()}"

    def to_mermaid(self) -> str:
        """Export a safe structural diagram; rendering remains a consumer concern."""

        if self.notation == "uml":
            lines = ["sequenceDiagram"]
            lines.extend(
                f"  participant {_mermaid_id(node.node_id)} as {_mermaid_label(node.title)}" for node in self.nodes
            )
            lines.extend(
                f"  {_mermaid_id(edge.source)}->>{_mermaid_id(edge.target)}: {_mermaid_label(edge.label or 'передача')}"
                for edge in self.edges
            )
            return "\n".join(lines)
        lines = ["flowchart LR"]
        lines.extend(f'  {_mermaid_id(node.node_id)}["{_mermaid_label(node.title)}"]' for node in self.nodes)
        lines.extend(
            f"  {_mermaid_id(edge.source)} -->|{_mermaid_label(edge.label)}| {_mermaid_id(edge.target)}"
            if edge.label
            else f"  {_mermaid_id(edge.source)} --> {_mermaid_id(edge.target)}"
            for edge in self.edges
        )
        return "\n".join(lines)
