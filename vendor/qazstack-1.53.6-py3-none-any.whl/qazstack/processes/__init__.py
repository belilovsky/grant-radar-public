"""Portable, accountable process-model contracts.

The package represents structure only: nodes, accountable owners, artefact
references and edges. Products keep their own process policy, UI layout,
editorial copy, permissions and persistence.
"""

from qazstack.processes.contracts import (
    PROCESS_EDGE_RELATIONS,
    PROCESS_MODEL_SCHEMA_VERSION,
    PROCESS_NODE_KINDS,
    PROCESS_NOTATIONS,
    PROCESS_RISKS,
    ProcessEdge,
    ProcessModel,
    ProcessNode,
)

__all__ = [
    "PROCESS_MODEL_SCHEMA_VERSION",
    "PROCESS_EDGE_RELATIONS",
    "PROCESS_NODE_KINDS",
    "PROCESS_NOTATIONS",
    "PROCESS_RISKS",
    "ProcessEdge",
    "ProcessModel",
    "ProcessNode",
]
