"""QazStack CLI – project scaffolding, audit, and platform checks.

Usage:
    qazstack new my-project          # Scaffold a new project
    qazstack check                   # Check current project compliance
    qazstack audit                   # Full platform audit (plugin-based)
    qazstack audit --category code   # Audit only code checks
    qazstack audit --fix             # Auto-fix where possible
    qazstack audit --json            # JSON output
    qazstack version                 # Show version
"""

from __future__ import annotations

import argparse
import getpass
import hashlib
import json
import sys
from pathlib import Path

from qazstack import __version__

SCAFFOLD_DIR = Path(__file__).parent.parent.parent.parent / "templates" / "scaffold"


def cli():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="qazstack",
        description="QazStack – modular toolkit for FastAPI projects",
    )
    parser.add_argument("--version", action="version", version=f"qazstack {__version__}")

    sub = parser.add_subparsers(dest="command")

    # qazstack new
    new_parser = sub.add_parser("new", help="Create a new project from template")
    new_parser.add_argument("name", help="Project name (lowercase, hyphens)")
    new_parser.add_argument("--port", type=int, default=8000, help="App port")
    new_parser.add_argument("--db", choices=["postgres", "sqlite", "none"], default="postgres")
    new_parser.add_argument("--accent", default="#1a365d", help="Brand accent color")
    new_parser.add_argument(
        "--owner",
        default=getpass.getuser(),
        help="Accountable owner for reuse and consumer contracts (default: current OS user)",
    )

    # qazstack check
    check_parser = sub.add_parser("check", help="Check project compliance with platform standard")
    check_parser.add_argument("path", nargs="?", default=".", help="Project path")
    check_modes = check_parser.add_mutually_exclusive_group()
    check_modes.add_argument(
        "--legacy",
        action="store_true",
        help="Run structural checks only; bypass an existing reuse manifest during migration",
    )
    check_modes.add_argument(
        "--require-reuse",
        action="store_true",
        help="Fail when the reuse manifest or its evidence is missing",
    )
    check_parser.add_argument("--json", action="store_true", dest="json_output", help="Emit JSON")

    # qazstack audit
    audit_parser = sub.add_parser("audit", help="Full platform audit (plugin-based)")
    audit_parser.add_argument("--category", "-c", help="Run only this category (code, infra, deps, ui_seo)")
    audit_parser.add_argument("--fix", action="store_true", help="Auto-fix issues where possible")
    audit_parser.add_argument("--json", action="store_true", dest="json_output", help="Output as JSON")
    audit_parser.add_argument("path", nargs="?", default=".", help="Project path (default: current dir)")

    # qazstack contract
    contract_parser = sub.add_parser("contract", help="Manage QazStack consumer contracts")
    contract_sub = contract_parser.add_subparsers(dest="contract_command", required=True)

    contract_init = contract_sub.add_parser("init", help="Create a consumer contract template")
    contract_init.add_argument("path", nargs="?", default="qazstack-consumer.json")
    contract_init.add_argument("--project-id", required=True)
    contract_init.add_argument("--product-name", required=True)
    contract_init.add_argument("--owner", required=True)
    contract_init.add_argument(
        "--lifecycle", choices=["planned", "pilot", "beta", "production", "archived"], default="production"
    )
    contract_init.add_argument(
        "--integration-mode",
        choices=[
            "python-package",
            "http-contract",
            "typescript-contract",
            "vendored-temporary",
            "vendored-release",
            "documented-only",
        ],
        default="http-contract",
    )
    contract_init.add_argument("--force", action="store_true")

    contract_validate = contract_sub.add_parser("validate", help="Validate a consumer contract")
    contract_validate.add_argument("path")
    contract_validate.add_argument("--strict", action="store_true", help="Require production runtime evidence")

    contract_diff = contract_sub.add_parser("diff", help="Compare a contract with this QazStack release")
    contract_diff.add_argument("path")

    contract_fetch = contract_sub.add_parser("fetch", help="Fetch and validate a public consumer contract")
    contract_fetch.add_argument("url")
    contract_fetch.add_argument("--strict", action="store_true")
    contract_fetch.add_argument("--timeout", type=float, default=10.0)

    contract_publish = contract_sub.add_parser("publish", help="Prepare an immutable publication bundle")
    contract_publish.add_argument("path")
    contract_publish.add_argument("--output", required=True)

    contract_inventory = contract_sub.add_parser(
        "inventory", help="Validate explicit consumer contracts below a directory"
    )
    contract_inventory.add_argument("path", nargs="?", default=".")
    contract_inventory.add_argument(
        "--strict", action="store_true", help="Require runtime evidence for production contracts"
    )
    contract_inventory.add_argument(
        "--json", action="store_true", dest="json_output", help="Emit machine-readable rows"
    )
    contract_portfolio = contract_sub.add_parser(
        "portfolio", help="Report QazStack consumer coverage from a Codex workspace index"
    )
    contract_portfolio.add_argument("workspace_root")
    contract_portfolio.add_argument(
        "--strict", action="store_true", help="Require runtime evidence for production contracts"
    )
    contract_portfolio.add_argument(
        "--json", action="store_true", dest="json_output", help="Emit a machine-readable portfolio payload"
    )
    contract_portfolio.add_argument("--digest", action="store_true", help="Emit a compact operator digest")
    contract_portfolio.add_argument("--out-json", help="Write the machine-readable payload to this path")
    contract_portfolio.add_argument("--out-md", help="Write the human-readable report to this path")
    contract_portfolio.add_argument("--out-digest", help="Write the compact operator digest to this path")
    contract_portfolio.add_argument("--baseline", help="Compare against a previously saved portfolio JSON payload")
    contract_portfolio.add_argument(
        "--runtime-smoke", action="store_true", help="Probe declared production runtime URLs without writes"
    )
    contract_portfolio.add_argument(
        "--runtime-timeout", type=float, default=10.0, help="Per-runtime URL timeout in seconds"
    )
    contract_portfolio.add_argument(
        "--runtime-retries",
        type=int,
        default=1,
        help="Retry count for transient network and 5xx runtime smoke failures",
    )
    contract_portfolio.add_argument(
        "--runtime-exclude", action="append", default=[], help="Product to skip during runtime smoke (repeatable)"
    )
    contract_portfolio.add_argument(
        "--fail-on-runtime-error", action="store_true", help="Exit non-zero when runtime smoke has errors"
    )
    contract_portfolio.add_argument(
        "--evidence-freshness",
        action="store_true",
        help="Check evidence.verified_at age for discoverable consumer contracts",
    )
    contract_portfolio.add_argument(
        "--max-evidence-age-days",
        type=int,
        default=30,
        help="Maximum accepted evidence age in days for the freshness check",
    )
    contract_portfolio.add_argument(
        "--evidence-exclude",
        action="append",
        default=[],
        help="Product to skip during evidence freshness checks (repeatable)",
    )
    contract_portfolio.add_argument(
        "--fail-on-stale-evidence",
        action="store_true",
        help="Exit non-zero when evidence freshness reports warnings or errors",
    )
    contract_portfolio.add_argument(
        "--compare-state",
        help="Compare the current monitor payload against a previous JSON state file",
    )
    contract_portfolio.add_argument(
        "--fail-on-regression",
        action="store_true",
        help="Exit non-zero when the baseline comparison finds a regression",
    )

    # qazstack reuse
    reuse_parser = sub.add_parser("reuse", help="Manage reuse-first decisions and duplicate regression scans")
    reuse_sub = reuse_parser.add_subparsers(dest="reuse_command", required=True)
    reuse_init = reuse_sub.add_parser("init", help="Create a reuse-first manifest")
    reuse_init.add_argument("path", nargs="?", default=".")
    reuse_init.add_argument("--project-id", required=True)
    reuse_init.add_argument("--owner", required=True)
    reuse_init.add_argument("--force", action="store_true")

    reuse_check = reuse_sub.add_parser("check", help="Validate one project's reuse-first evidence")
    reuse_check.add_argument("path", nargs="?", default=".")
    reuse_check.add_argument("--no-strict", action="store_false", dest="strict")
    reuse_check.add_argument("--json", action="store_true", dest="json_output")
    reuse_check.set_defaults(strict=True)

    reuse_portfolio = reuse_sub.add_parser("portfolio", help="Scan indexed projects for reuse coverage and clones")
    reuse_portfolio.add_argument("workspace_root")
    reuse_portfolio.add_argument("--json", action="store_true", dest="json_output")
    reuse_portfolio.add_argument("--digest", action="store_true")
    reuse_portfolio.add_argument("--out-json")
    reuse_portfolio.add_argument("--out-md")
    reuse_portfolio.add_argument(
        "--out-baseline-candidate",
        help="Write a compact semantics-v2 regression baseline candidate for owner review",
    )
    reuse_portfolio.add_argument("--baseline")
    reuse_portfolio.add_argument("--fail-on-regression", action="store_true")
    reuse_portfolio.add_argument(
        "--classification-baseline",
        help="Reviewed exact-duplicate classification baseline JSON",
    )
    reuse_portfolio.add_argument(
        "--fail-on-unclassified",
        action="store_true",
        help="Exit non-zero when any exact or structural cluster is not covered by the classification baseline",
    )
    reuse_portfolio.add_argument(
        "--fail-on-actionable-unclassified",
        action="store_true",
        help="Exit non-zero for unclassified cross- or mixed-repository exact duplicate clusters",
    )
    reuse_portfolio.add_argument(
        "--out-classification-candidate",
        help="Migrate matching prior classifications into a candidate file for owner review",
    )
    reuse_portfolio.add_argument(
        "--checkout-override",
        action="append",
        default=[],
        metavar="PRODUCT=PATH",
        help="Override one indexed checkout (repeatable)",
    )

    args = parser.parse_args()

    if args.command == "new":
        cmd_new(args)
    elif args.command == "check":
        cmd_check(args)
    elif args.command == "audit":
        cmd_audit(args)
    elif args.command == "contract":
        cmd_contract(args)
    elif args.command == "reuse":
        cmd_reuse(args)
    else:
        parser.print_help()


def cmd_new(args):
    """Scaffold a new project."""
    from qazstack.contracts import contract_template
    from qazstack.governance.reuse import ReuseManifestError, reuse_manifest_template

    try:
        reuse_manifest = reuse_manifest_template(args.name, args.owner, version=__version__)
    except ReuseManifestError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc
    project_dir = Path.cwd() / args.name
    if project_dir.exists():
        print(f"Error: directory '{args.name}' already exists")
        sys.exit(1)

    print(f"Creating project: {args.name}")

    # Create directory structure
    dirs = [
        "app/routers",
        "app/services",
        "static/css",
        "static/js",
        "static/img",
        "templates",
        "scripts",
        "nginx",
        "tests",
    ]
    for d in dirs:
        (project_dir / d).mkdir(parents=True, exist_ok=True)

    # Generate files
    _write(project_dir / "app" / "__init__.py", "")
    _write(project_dir / "app" / "routers" / "__init__.py", "")
    _write(project_dir / "app" / "services" / "__init__.py", "")

    _write(project_dir / "app" / "config.py", _config_py(args))
    _write(project_dir / "app" / "main.py", _main_py(args))
    _write(project_dir / "app" / "database.py", _database_py(args))
    _write(project_dir / "app" / "routers" / "pages.py", _pages_py(args))
    _write(project_dir / "app" / "routers" / "api.py", _api_py(args))

    _write(project_dir / "templates" / "base.html", _base_html(args))
    _write(project_dir / "templates" / "index.html", _index_html(args))
    _write(project_dir / "static" / "css" / "style.css", _style_css(args))

    _write(project_dir / "Dockerfile", _dockerfile(args))
    _write(project_dir / "docker-compose.yml", _docker_compose(args))
    _write(project_dir / "nginx" / "default.conf", _nginx_conf())
    _write(project_dir / ".env.example", _env_example(args))
    _write(project_dir / ".gitignore", _gitignore())
    _write(project_dir / "pyproject.toml", _pyproject(args))
    _write(project_dir / "tests" / "test_health.py", _health_test())
    _write(project_dir / ".github" / "workflows" / "ci.yml", _project_ci())
    consumer = contract_template(
        args.name,
        args.name.replace("-", " ").title(),
        owner=args.owner,
        qazstack_version=__version__,
        lifecycle="planned",
        integration_mode="python-package",
    )
    consumer["primitives"] = ["core-foundation"]
    consumer["evidence"]["source_files"] = ["app/config.py", "app/main.py"]
    consumer["evidence"]["test_commands"] = ["pytest -q"]
    _write_json(project_dir / "qazstack-consumer.json", consumer)
    _write_json(project_dir / "qazstack-reuse.json", reuse_manifest)
    _write(project_dir / "README.md", _project_readme(args))

    print(f"Project created at ./{args.name}")
    print(f"  cd {args.name}")
    print("  qazstack check .")
    print("  cp .env.example .env  # edit settings")
    print("  docker compose up --build")


def cmd_check(args):
    """Check current project for platform compliance."""
    cwd = Path(args.path).resolve()
    if not cwd.is_dir():
        print(f"Error: project path is not a directory: {cwd}", file=sys.stderr)
        raise SystemExit(1)
    checks = {
        "pyproject.toml": (cwd / "pyproject.toml").exists(),
        "Dockerfile": (cwd / "Dockerfile").exists(),
        "docker-compose.yml": (cwd / "docker-compose.yml").exists(),
        ".env.example": (cwd / ".env.example").exists(),
        ".gitignore": (cwd / ".gitignore").exists(),
        "health endpoint": _check_health_endpoint(cwd),
        "HEALTHCHECK in Dockerfile": _check_dockerfile_health(cwd),
    }
    reuse_report = None
    manifest_exists = (cwd / "qazstack-reuse.json").is_file()
    if not args.legacy and (manifest_exists or args.require_reuse):
        from qazstack.governance.reuse import check_project_reuse

        reuse_report = check_project_reuse(cwd, strict=True)
        checks["reuse-first manifest and evidence"] = not reuse_report["counts"]["errors"]
    elif not args.legacy:
        reuse_report = {
            "schema_version": "qazstack-reuse-check-v1",
            "project_root": str(cwd),
            "status": "warning",
            "project_id": None,
            "counts": {"errors": 0, "warnings": 1},
            "errors": [],
            "warnings": ["reuse manifest is not adopted yet; migrate with `qazstack reuse init`"],
        }

    all_pass = True
    if args.json_output:
        payload = {
            "schema_version": "qazstack-project-check-v1",
            "project_root": str(cwd),
            "legacy": args.legacy,
            "status": "ok" if all(checks.values()) else "error",
            "checks": [{"name": name, "passed": passed} for name, passed in checks.items()],
            "reuse": reuse_report,
        }
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        if payload["status"] != "ok":
            raise SystemExit(1)
        return
    for name, passed in checks.items():
        icon = "✅" if passed else "❌"
        print(f"  {icon} {name}")
        if not passed:
            all_pass = False
    if reuse_report:
        for error in reuse_report["errors"]:
            print(f"      {error}")
        for warning in reuse_report["warnings"]:
            print(f"      warning: {warning}")

    if all_pass:
        print("\nAll checks passed!")
    else:
        print("\nSome checks failed. Fix the issues above.")
        sys.exit(1)


def cmd_audit(args):
    """Run full platform audit."""
    from qazstack.audit import AuditRunner, CheckerRegistry

    project_path = Path(args.path).resolve()
    if not project_path.is_dir():
        print(f"Error: {args.path} is not a directory")
        sys.exit(1)

    registry = CheckerRegistry()
    registry.auto_discover()
    runner = AuditRunner(registry)

    categories = [args.category] if args.category else None

    # Run auto-fix first if requested
    if args.fix:
        fixes = runner.run_fix(project_path, categories=categories)
        if fixes:
            print("Auto-fixes applied:")
            for fix in fixes:
                print(f"  \u2714 {fix}")
            print()

    report = runner.run(project_path, categories=categories)

    if args.json_output:
        print(AuditRunner.format_json(report))
    else:
        print(AuditRunner.format_text(report))

    # Exit with error code if any errors found
    if report.errors:
        sys.exit(1)


def cmd_contract(args):
    """Manage consumer contracts without changing a remote registry."""
    from qazstack.contracts import (
        ConsumerContractClient,
        ConsumerContractError,
        compatibility_status,
        contract_template,
        inventory_consumer_contracts,
        load_consumer_contract,
        publication_bundle,
    )

    try:
        if args.contract_command == "init":
            path = Path(args.path).resolve()
            if path.exists() and not args.force:
                raise ConsumerContractError(f"refusing to overwrite existing file: {path}")
            payload = contract_template(
                args.project_id,
                args.product_name,
                owner=args.owner,
                qazstack_version=__version__,
                lifecycle=args.lifecycle,
                integration_mode=args.integration_mode,
            )
            _write_json(path, payload)
            print(f"created: {path}")
        elif args.contract_command == "validate":
            contract = load_consumer_contract(args.path, strict=args.strict)
            print(f"valid: {args.path} ({contract.project_id})")
        elif args.contract_command == "diff":
            contract = load_consumer_contract(args.path)
            status = compatibility_status(contract.qazstack_version, __version__)
            print(
                f"project={contract.project_id} contract={contract.qazstack_version} "
                f"current={__version__} status={status}"
            )
            if status in {"missing", "legacy", "incompatible"}:
                raise SystemExit(1)
        elif args.contract_command == "fetch":
            contract = ConsumerContractClient(timeout=args.timeout).fetch(args.url, strict=args.strict)
            print(json.dumps(contract.to_dict(), ensure_ascii=False, indent=2))
        elif args.contract_command == "publish":
            contract = load_consumer_contract(args.path, strict=True)
            output = Path(args.output).resolve()
            _write_json(output, publication_bundle(contract))
            print(f"prepared: {output}")
        elif args.contract_command == "inventory":
            entries = inventory_consumer_contracts(args.path, strict=args.strict)
            payload = [
                {
                    "path": str(entry.path),
                    "project_id": entry.project_id,
                    "status": entry.status,
                    "error": entry.error,
                }
                for entry in entries
            ]
            if args.json_output:
                print(json.dumps(payload, ensure_ascii=False, indent=2))
            elif entries:
                for entry in entries:
                    detail = f" ({entry.error})" if entry.error else ""
                    print(f"{entry.status}: {entry.path} [{entry.project_id or '-'}]{detail}")
            else:
                print(f"no consumer contracts found below: {Path(args.path).resolve()}")
            if any(entry.status == "invalid" for entry in entries):
                raise SystemExit(1)
        elif args.contract_command == "portfolio":
            from qazstack.governance.portfolio_inventory import (
                portfolio_evidence_freshness,
                portfolio_inventory_payload,
                portfolio_monitor_changes,
                portfolio_regressions,
                portfolio_runtime_smoke,
                render_portfolio_changes_digest,
                render_portfolio_freshness_digest,
                render_portfolio_inventory_digest,
                render_portfolio_inventory_markdown,
                render_portfolio_runtime_digest,
            )

            payload = portfolio_inventory_payload(args.workspace_root, strict=args.strict)
            markdown = render_portfolio_inventory_markdown(payload)
            regressions: list[str] = []
            if args.baseline:
                baseline_path = Path(args.baseline).resolve()
                baseline = json.loads(baseline_path.read_text(encoding="utf-8"))
                regressions = portfolio_regressions(payload, baseline)
            digest = render_portfolio_inventory_digest(payload, regressions=regressions)
            runtime = None
            if args.runtime_smoke:
                runtime = portfolio_runtime_smoke(
                    args.workspace_root,
                    strict=args.strict,
                    timeout=args.runtime_timeout,
                    retries=args.runtime_retries,
                    excluded_products=args.runtime_exclude,
                )
                payload["runtime_smoke"] = runtime
                runtime_digest = render_portfolio_runtime_digest(runtime)
                digest = f"{digest}\n{runtime_digest}"
                markdown = f"{markdown}\n## Runtime smoke\n\n```text\n{runtime_digest}```\n"
            freshness = None
            if args.evidence_freshness:
                freshness = portfolio_evidence_freshness(
                    args.workspace_root,
                    strict=args.strict,
                    max_age_days=args.max_evidence_age_days,
                    excluded_products=args.evidence_exclude,
                )
                payload["evidence_freshness"] = freshness
                freshness_digest = render_portfolio_freshness_digest(freshness)
                digest = f"{digest}\n{freshness_digest}"
                markdown = f"{markdown}\n## Evidence freshness\n\n```text\n{freshness_digest}```\n"
            changes: list[str] = []
            if args.compare_state:
                previous_path = Path(args.compare_state).resolve()
                previous = json.loads(previous_path.read_text(encoding="utf-8"))
                changes = portfolio_monitor_changes(payload, previous)
                changes_digest = render_portfolio_changes_digest(changes)
                payload["monitor_changes"] = changes
                digest = f"{digest}\n{changes_digest}"
                markdown = f"{markdown}\n## Portfolio changes\n\n```text\n{changes_digest}```\n"
            if args.out_json:
                _write_json(Path(args.out_json).resolve(), payload)
            if args.out_md:
                output = Path(args.out_md).resolve()
                output.parent.mkdir(parents=True, exist_ok=True)
                output.write_text(markdown, encoding="utf-8")
            if args.out_digest:
                output = Path(args.out_digest).resolve()
                output.parent.mkdir(parents=True, exist_ok=True)
                output.write_text(digest, encoding="utf-8")
            if args.json_output:
                print(json.dumps(payload, ensure_ascii=False, indent=2))
            elif args.digest:
                print(digest, end="")
            else:
                print(markdown, end="")
            if (
                payload["summary"]["invalid_rows"]
                or (args.fail_on_regression and regressions)
                or (args.fail_on_runtime_error and runtime and runtime["counts"]["errors"])
                or (
                    args.fail_on_stale_evidence
                    and freshness
                    and (freshness["counts"]["errors"] or freshness["counts"]["warnings"])
                )
            ):
                raise SystemExit(1)
    except (OSError, json.JSONDecodeError, ConsumerContractError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc


def cmd_reuse(args):
    """Manage reuse-first manifests and portfolio regressions."""
    from qazstack.governance.reuse import (
        DEFAULT_REUSE_FILENAME,
        ReuseManifestError,
        check_project_reuse,
        reuse_manifest_from_project,
    )

    try:
        if args.reuse_command == "init":
            root = Path(args.path).resolve()
            if not root.is_dir():
                raise ReuseManifestError(f"project path is not a directory: {root}")
            output = root / DEFAULT_REUSE_FILENAME
            if output.exists() and not args.force:
                raise ReuseManifestError(f"refusing to overwrite existing file: {output}")
            _write_json(output, reuse_manifest_from_project(root, args.project_id, args.owner))
            print(f"created: {output}")
        elif args.reuse_command == "check":
            payload = check_project_reuse(args.path, strict=args.strict)
            if args.json_output:
                print(json.dumps(payload, ensure_ascii=False, indent=2))
            else:
                print(
                    f"{payload['status']}: {payload['project_root']} "
                    f"({payload['counts']['errors']} errors, {payload['counts']['warnings']} warnings)"
                )
                for error in payload["errors"]:
                    print(f"  error: {error}")
                for warning in payload["warnings"]:
                    print(f"  warning: {warning}")
            if payload["counts"]["errors"]:
                raise SystemExit(1)
        elif args.reuse_command == "portfolio":
            from qazstack.governance.reuse_scan import (
                SCANNER_SEMANTICS_VERSION,
                build_classification_baseline_candidate,
                build_reuse_regression_baseline_candidate,
                classify_reuse_scan,
                ensure_classification_baseline_reviewed,
                ensure_reuse_baseline_compatible,
                ensure_reuse_baseline_reviewed,
                render_reuse_scan_digest,
                render_reuse_scan_markdown,
                reuse_scan_regressions,
                scan_portfolio_reuse,
            )

            if args.fail_on_regression and not args.baseline:
                raise ReuseManifestError("--fail-on-regression requires --baseline")
            if (args.fail_on_unclassified or args.fail_on_actionable_unclassified) and not args.classification_baseline:
                option = "--fail-on-unclassified" if args.fail_on_unclassified else "--fail-on-actionable-unclassified"
                raise ReuseManifestError(f"{option} requires --classification-baseline")
            if args.out_classification_candidate and not args.classification_baseline:
                raise ReuseManifestError("--out-classification-candidate requires --classification-baseline")

            baseline = None
            baseline_metadata = None
            if args.baseline:
                baseline_path = Path(args.baseline).resolve()
                baseline_bytes = baseline_path.read_bytes()
                baseline = json.loads(baseline_bytes)
                baseline_semantics = baseline.get("scanner_semantics_version")
                semantics_compatible = baseline_semantics == SCANNER_SEMANTICS_VERSION
                baseline_metadata = {
                    "path": str(baseline_path),
                    "sha256": hashlib.sha256(baseline_bytes).hexdigest(),
                    "scanner_semantics_version": baseline_semantics,
                    "semantics_compatible": semantics_compatible,
                }
                if args.fail_on_regression:
                    ensure_reuse_baseline_compatible(baseline)
                    ensure_reuse_baseline_reviewed(baseline)

            overrides: dict[str, str] = {}
            for value in args.checkout_override:
                if "=" not in value:
                    raise ReuseManifestError("checkout override must use PRODUCT=PATH")
                product, path = value.split("=", 1)
                if not product.strip() or not path.strip():
                    raise ReuseManifestError("checkout override must use non-empty PRODUCT=PATH")
                overrides[product.strip()] = path.strip()
            payload = scan_portfolio_reuse(args.workspace_root, checkout_overrides=overrides)
            regressions: list[str] = []
            if baseline_metadata is not None:
                payload["regression_baseline"] = baseline_metadata
            if baseline is not None and baseline_metadata and baseline_metadata["semantics_compatible"]:
                regressions = reuse_scan_regressions(payload, baseline)
            payload["regressions"] = regressions
            classification = None
            classification_baseline = None
            if args.classification_baseline:
                classification_baseline = json.loads(Path(args.classification_baseline).read_text(encoding="utf-8"))
                if args.fail_on_unclassified or args.fail_on_actionable_unclassified:
                    ensure_classification_baseline_reviewed(classification_baseline)
                classification = classify_reuse_scan(payload, classification_baseline)
                payload["classification"] = classification
            digest = render_reuse_scan_digest(payload, regressions)
            markdown = render_reuse_scan_markdown(payload, regressions)
            if args.out_json:
                _write_json(Path(args.out_json).resolve(), payload)
            if args.out_md:
                output = Path(args.out_md).resolve()
                output.parent.mkdir(parents=True, exist_ok=True)
                output.write_text(markdown, encoding="utf-8")
            if args.out_baseline_candidate:
                _write_json(
                    Path(args.out_baseline_candidate).resolve(),
                    build_reuse_regression_baseline_candidate(payload),
                )
            if args.out_classification_candidate and classification_baseline is not None:
                _write_json(
                    Path(args.out_classification_candidate).resolve(),
                    build_classification_baseline_candidate(payload, classification_baseline),
                )
            if args.json_output:
                print(json.dumps(payload, ensure_ascii=False, indent=2))
            else:
                print(digest, end="")
            if args.fail_on_regression and regressions:
                raise SystemExit(1)
            if (
                args.fail_on_unclassified
                and classification is not None
                and classification.get("total_unclassified_clusters", 0)
            ):
                raise SystemExit(1)
            if (
                args.fail_on_actionable_unclassified
                and classification is not None
                and classification.get("actionable_unclassified_exact_clusters", 0)
            ):
                raise SystemExit(1)
    except (OSError, json.JSONDecodeError, ReuseManifestError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc


def _write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def _check_health_endpoint(cwd: Path) -> bool:
    """Check if any Python file contains /health endpoint."""
    for py_file in cwd.rglob("*.py"):
        try:
            content = py_file.read_text()
            if "/health" in content or "create_app(" in content:
                return True
        except Exception:
            pass
    return False


def _check_dockerfile_health(cwd: Path) -> bool:
    """Check if Dockerfile contains HEALTHCHECK."""
    dockerfile = cwd / "Dockerfile"
    if not dockerfile.exists():
        return False
    return "HEALTHCHECK" in dockerfile.read_text()


def _write(path: Path, content: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


# --- Template generators ---


def _config_py(args) -> str:
    name_title = args.name.replace("-", " ").title()
    database_url = (
        "postgresql+asyncpg://user:pass@db:5432/" + args.name.replace("-", "_") if args.db == "postgres" else ""
    )
    return f'''"""Application settings."""

from qazstack.core import BaseConfig


class Settings(BaseConfig):
    app_name: str = "{name_title}"
    version: str = "1.0.0"
    database_url: str = "{database_url}"

settings = Settings()
'''


def _main_py(args) -> str:
    return f'''"""{args.name} – FastAPI application."""

from pathlib import Path
from qazstack.core import create_app, Database
from app.config import settings

BASE = Path(__file__).parent.parent

db = Database(settings.database_url) if settings.database_url else None

app = create_app(
    settings,
    static_dir=BASE / "static",
    templates_dir=BASE / "templates",
    database=db,
)

from app.routers import pages, api  # noqa: E402
app.include_router(pages.router)
app.include_router(api.router)
'''


def _database_py(args) -> str:
    return '''"""Database models."""

from qazstack.core.database import Base
from sqlalchemy import Column, Integer, String, DateTime, func


# Define your models here:
# class MyModel(Base):
#     __tablename__ = "my_table"
#     id = Column(Integer, primary_key=True)
#     name = Column(String, nullable=False)
#     created_at = Column(DateTime, server_default=func.now())
'''


def _pages_py(args) -> str:
    return '''"""SSR page routes."""

from fastapi import APIRouter, Request

router = APIRouter(tags=["pages"])


@router.get("/")
async def index(request: Request):
    templates = request.app.state.templates
    return templates.TemplateResponse(request, "index.html")
'''


def _api_py(args) -> str:
    return '''"""API routes."""

from fastapi import APIRouter

router = APIRouter(prefix="/api", tags=["api"])


@router.get("/info")
async def info():
    from app.config import settings
    return {"name": settings.app_name, "version": settings.version}
'''


def _base_html(args) -> str:
    name_title = args.name.replace("-", " ").title()
    return f"""<!DOCTYPE html>
<html lang="ru" data-theme="light">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{% block title %}}{name_title}{{% endblock %}}</title>
    <meta name="description" content="{{% block meta_description %}}{{% endblock %}}">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/static/css/style.css">
    {{% block head %}}{{% endblock %}}
</head>
<body>
    <header class="site-header">
        <div class="container header-inner">
            <a href="/" class="logo">{name_title}</a>
            <nav class="main-nav">
                {{% block nav %}}{{% endblock %}}
            </nav>
        </div>
    </header>

    <main>
        <div class="container">
            {{% block content %}}{{% endblock %}}
        </div>
    </main>

    <footer class="site-footer">
        <div class="container footer-inner">
            <p>&copy; {{{{ year }}}} {name_title}</p>
        </div>
    </footer>
    {{% block scripts %}}{{% endblock %}}
</body>
</html>
"""


def _index_html(args) -> str:
    name_title = args.name.replace("-", " ").title()
    return f"""{{% extends "base.html" %}}
{{% block title %}}{name_title}{{% endblock %}}
{{% block content %}}
<h1>{name_title}</h1>
<p>Built with QazStack.</p>
{{% endblock %}}
"""


def _style_css(args) -> str:
    return f"""/* {args.name} – styles */
:root {{
    --bg: #f0f2f5;
    --surface: #ffffff;
    --text: #1a1a2e;
    --text-secondary: #4a5568;
    --text-muted: #718096;
    --accent: {args.accent};
    --accent-hover: color-mix(in srgb, {args.accent} 80%, black);
    --border: #e2e8f0;
    --border-light: #edf2f7;
    --shadow-sm: 0 1px 3px rgba(0,0,0,0.06);
    --shadow-md: 0 4px 12px rgba(0,0,0,0.08);
    --shadow-lg: 0 8px 30px rgba(0,0,0,0.12);
    --radius-sm: 6px;
    --radius: 10px;
    --radius-lg: 14px;
    --transition: 0.2s ease;
    --success: #38a169;
    --warning: #d69e2e;
    --danger: #e53e3e;
}}

[data-theme="dark"] {{
    --bg: #0f1117;
    --surface: #1a1d27;
    --text: #e4e5e7;
    --text-secondary: #a1a3a8;
    --text-muted: #6c6f77;
    --border: #2a2d37;
    --shadow-sm: 0 1px 2px rgba(0,0,0,0.3);
    --shadow-md: 0 4px 12px rgba(0,0,0,0.4);
    --shadow-lg: 0 8px 30px rgba(0,0,0,0.5);
}}

*, *::before, *::after {{ box-sizing: border-box; }}
body {{
    margin: 0;
    font-family: "Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    background: var(--bg);
    color: var(--text);
    line-height: 1.6;
}}

.container {{
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 24px;
}}

.site-header {{
    background: var(--surface);
    border-bottom: 1px solid var(--border);
    padding: 0 0;
    position: sticky;
    top: 0;
    z-index: 100;
}}

.header-inner {{
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 60px;
}}

.logo {{
    font-weight: 700;
    font-size: 1.2rem;
    color: var(--accent);
    text-decoration: none;
}}

.site-footer {{
    background: var(--surface);
    border-top: 1px solid var(--border);
    padding: 24px 0;
    margin-top: 60px;
    color: var(--text-muted);
    font-size: 0.875rem;
}}
"""


def _dockerfile(args) -> str:
    return """FROM python:3.12-slim

WORKDIR /app

RUN apt-get update && apt-get install -y --no-install-recommends \\
    libpq5 curl && \\
    rm -rf /var/lib/apt/lists/*

COPY pyproject.toml .
COPY app/ app/
RUN pip install --no-cache-dir .

COPY . .

EXPOSE 8000

HEALTHCHECK --interval=30s --timeout=10s --start-period=15s --retries=3 \\
    CMD curl -f http://localhost:8000/health || exit 1

CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000", "--workers", "2"]
"""


def _docker_compose(args) -> str:
    project = args.name.replace("-", "_")
    compose = f"""services:
  app:
    build: .
    container_name: {project}_app
    restart: unless-stopped
    env_file: .env
    ports:
      - "${{APP_PORT:-8000}}:8000"
"""
    if args.db == "postgres":
        compose += f"""    depends_on:
      db:
        condition: service_healthy
    networks:
      - app_net

  db:
    image: pgvector/pgvector:pg16
    container_name: {project}_db
    restart: unless-stopped
    environment:
      POSTGRES_DB: ${{DB_NAME:-{project}}}
      POSTGRES_USER: ${{DB_USER:-{project}}}
      POSTGRES_PASSWORD: ${{DB_PASSWORD:?DB_PASSWORD required}}
    ports:
      - "127.0.0.1:${{DB_PORT:-5432}}:5432"
    volumes:
      - pgdata:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U ${{DB_USER:-{project}}}"]
      interval: 10s
      timeout: 5s
      retries: 5
    networks:
      - app_net

volumes:
  pgdata:
    name: {project}_pgdata

networks:
  app_net:
    name: {project}_net
    driver: bridge
"""
    else:
        compose += f"""    networks:
      - app_net

networks:
  app_net:
    name: {project}_net
    driver: bridge
"""
    return compose


def _nginx_conf() -> str:
    return """server {
    listen 80;
    server_name _;
    client_max_body_size 10M;

    location /static/ {
        alias /usr/share/nginx/static/;
        expires 7d;
        add_header Cache-Control "public, immutable";
    }

    location / {
        proxy_pass http://app:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location /nginx-health {
        return 200 "ok";
        add_header Content-Type text/plain;
    }
}
"""


def _env_example(args) -> str:
    project = args.name.replace("-", "_")
    env = f"""# === Application ===
APP_NAME={args.name.replace("-", " ").title()}
APP_PORT=8000
DEBUG=false
SECRET_KEY=change-me-in-production
"""
    if args.db == "postgres":
        env += f"""
# === Database ===
DB_NAME={project}
DB_USER={project}
DB_PASSWORD=
DB_PORT=5432
DATABASE_URL=postgresql+asyncpg://{project}:{project}@db:5432/{project}
"""
    return env


def _gitignore() -> str:
    return """__pycache__/
*.pyc
.env
*.egg-info/
dist/
build/
.venv/
venv/
node_modules/
.DS_Store
*.db
*.sqlite3
"""


def _health_test() -> str:
    return '''"""Verify the shared QazStack health primitive is wired."""

from fastapi.testclient import TestClient

from app.main import app


def test_health() -> None:
    response = TestClient(app).get("/health")
    assert response.status_code == 200
'''


def _project_ci() -> str:
    return """name: CI

on:
  push:
  pull_request:

jobs:
  reuse-first:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"
      - run: python -m pip install -e ".[dev]"
      - run: qazstack check . --require-reuse
      - run: pytest -q
"""


def _project_readme(args) -> str:
    return f"""# {args.name}

Built with QazStack {__version__}.

Reuse decisions are recorded in `qazstack-reuse.json`; the machine-readable
integration boundary is recorded in `qazstack-consumer.json`. Before adding a
generic service, helper, client or contract, search the QazStack module catalog
and either adopt the shared module or add a reviewed, expiring local exception.

```bash
python -m pip install -e ".[dev]"
qazstack check .
pytest -q
```
"""


def _pyproject(args) -> str:
    return f'''[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "{args.name}"
version = "1.0.0"
requires-python = ">=3.11"
dependencies = [
    "qazstack~={__version__}",
]

[project.optional-dependencies]
dev = ["pytest>=8.0"]

[tool.hatch.build.targets.wheel]
packages = ["app"]

[tool.ruff]
line-length = 120
target-version = "py312"
'''


if __name__ == "__main__":
    cli()
