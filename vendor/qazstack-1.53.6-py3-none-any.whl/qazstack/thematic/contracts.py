"""Portable contracts for evidence-led public thematic products.

The contract stops a common failure mode across public products: a polished
surface shipping cards or map layers whose source, review state, freshness, or
degraded behavior is unknown. It is deliberately a release envelope, not a
generic content schema. Each product retains its domain model and persistence.
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path, PurePosixPath
from typing import Any, Mapping
from urllib.parse import urlparse

THEMATIC_PRODUCT_SCHEMA_VERSION = "qazstack-thematic-product-v1"
THEMATIC_RELEASE_SCHEMA_VERSION = "qazstack-thematic-release-v1"

LIFECYCLES = frozenset({"planned", "pilot", "beta", "production", "archived"})
PUBLIC_MODES = frozenset({"explore", "understand", "act", "follow", "trust"})
MODULE_KINDS = frozenset({"map", "catalog", "indicator", "pulse", "registry", "guide", "tool", "timeline"})
DATA_MODULE_KINDS = frozenset({"map", "catalog", "indicator", "pulse", "registry", "timeline"})
SOURCE_CLASSES = frozenset({"official", "public-sector", "research", "editorial", "community", "user-submitted"})
PUBLICATION_MODES = frozenset({"reviewed-snapshot", "reviewed-api", "mixed"})
EMPTY_STATES = frozenset({"hide", "degraded-state", "curated-snapshot"})
MODULE_STATES = frozenset({"ready", "degraded", "empty", "hidden"})
GEO_PRECISIONS = frozenset({"none", "country", "region", "generalized", "exact"})
SENSITIVITY_CLASSES = frozenset(
    {
        "personal-data",
        "precise-location",
        "critical-infrastructure",
        "legal-risk",
        "animal-welfare",
        "commercial-confidentiality",
    }
)
ID_RE = re.compile(r"^[a-z0-9][a-z0-9-]{1,63}$")
DIGEST_RE = re.compile(r"^sha256:[a-f0-9]{64}$")
SHA256_HEX_RE = re.compile(r"^[a-f0-9]{64}$")
REVISION_RE = re.compile(r"^[a-f0-9]{7,64}$")
SCIENTIFIC_FOUNDATION_STATUSES = frozenset(
    {"pending", "draft", "migrated_needs_review", "reviewed", "published", "superseded"}
)
SCIENTIFIC_FOUNDATION_DISPLAY_MODES = frozenset({"status-only", "reviewed-evidence"})

MANIFEST_KEYS = frozenset(
    {
        "schema_version",
        "product_id",
        "product_name",
        "lifecycle",
        "subject",
        "qazstack_consumer_contract",
        "public_modes",
        "source_policy",
        "scientific_foundation",
        "publication",
        "geo_policy",
        "sensitivity",
        "modules",
        "release",
        "notes",
    }
)
SOURCE_POLICY_KEYS = frozenset({"registry_path", "allowed_classes", "candidates_require_review"})
SCIENTIFIC_FOUNDATION_KEYS = frozenset(
    {"project_id", "status", "bundle_path", "metadata_path", "qazknowledge_revision", "bundle_sha256", "display_mode"}
)
PUBLICATION_KEYS = frozenset({"mode", "public_records_require_review", "explicit_degraded_state"})
GEO_POLICY_KEYS = frozenset({"public_precision", "private_browser_access_forbidden", "exact_user_locations_public"})
SENSITIVITY_KEYS = frozenset({"classes", "public_prohibitions"})
MODULE_KEYS = frozenset({"id", "mode", "kind", "data_contract", "empty_state"})
RELEASE_KEYS = frozenset({"public_release_path", "test_commands", "runtime_urls", "verified_at", "checked_by"})
THEMATIC_RELEASE_KEYS = frozenset(
    {
        "schema_version",
        "product_id",
        "release_id",
        "published_at",
        "data_as_of",
        "manifest_digest",
        "modules",
    }
)
THEMATIC_RELEASE_MODULE_KEYS = frozenset({"id", "state", "record_count", "as_of", "source_ids", "notes"})


class ThematicContractError(ValueError):
    """Raised when a thematic product contract is not safe to publish."""


def _require_mapping(value: Any, name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ThematicContractError(f"{name} must be an object")
    return value


def _require_string(record: Mapping[str, Any], key: str) -> str:
    value = record.get(key)
    if not isinstance(value, str) or not value.strip():
        raise ThematicContractError(f"{key} must be a non-empty string")
    return value


def _require_unique_strings(value: Any, name: str, *, min_length: int = 0) -> tuple[str, ...]:
    if not isinstance(value, list) or any(not isinstance(item, str) or not item.strip() for item in value):
        raise ThematicContractError(f"{name} must be an array of non-empty strings")
    if len(value) < min_length:
        raise ThematicContractError(f"{name} must contain at least {min_length} item(s)")
    if len(value) != len(set(value)):
        raise ThematicContractError(f"{name} must not contain duplicates")
    return tuple(value)


def _reject_unknown(record: Mapping[str, Any], allowed: frozenset[str], name: str) -> None:
    unknown = sorted(record.keys() - allowed)
    if unknown:
        raise ThematicContractError(f"{name} has unknown fields: {', '.join(unknown)}")


def _parse_datetime(value: Any, name: str) -> datetime:
    if not isinstance(value, str):
        raise ThematicContractError(f"{name} must be an ISO-8601 string")
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ThematicContractError(f"{name} must be ISO-8601: {exc}") from exc


def _validate_urls(value: Any, name: str) -> tuple[str, ...]:
    urls = _require_unique_strings(value, name)
    for url in urls:
        parsed = urlparse(url)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            raise ThematicContractError(f"{name} contains an invalid URL: {url}")
    return urls


def _validate_id(value: str, name: str) -> None:
    if not ID_RE.fullmatch(value):
        raise ThematicContractError(f"{name} must be lowercase kebab-case, 2-64 characters")


def _validate_relative_path(record: Mapping[str, Any], key: str, name: str) -> str:
    value = _require_string(record, key)
    path = PurePosixPath(value)
    if path.is_absolute() or ".." in path.parts or value in {".", ""}:
        raise ThematicContractError(f"{name}.{key} must be a safe relative path")
    return value


def _validate_scientific_foundation(value: Any) -> None:
    foundation = _require_mapping(value, "scientific_foundation")
    _reject_unknown(foundation, SCIENTIFIC_FOUNDATION_KEYS, "scientific_foundation")
    project_id = _require_string(foundation, "project_id")
    _validate_id(project_id, "scientific_foundation.project_id")
    status = _require_string(foundation, "status")
    if status not in SCIENTIFIC_FOUNDATION_STATUSES:
        raise ThematicContractError(
            "scientific_foundation.status must be one of: " + ", ".join(sorted(SCIENTIFIC_FOUNDATION_STATUSES))
        )
    _validate_relative_path(foundation, "bundle_path", "scientific_foundation")
    _validate_relative_path(foundation, "metadata_path", "scientific_foundation")
    revision = _require_string(foundation, "qazknowledge_revision")
    if not REVISION_RE.fullmatch(revision):
        raise ThematicContractError("scientific_foundation.qazknowledge_revision must be a Git revision")
    bundle_sha256 = _require_string(foundation, "bundle_sha256")
    if not SHA256_HEX_RE.fullmatch(bundle_sha256):
        raise ThematicContractError("scientific_foundation.bundle_sha256 must be a SHA-256 hex digest")
    display_mode = _require_string(foundation, "display_mode")
    if display_mode not in SCIENTIFIC_FOUNDATION_DISPLAY_MODES:
        raise ThematicContractError(
            "scientific_foundation.display_mode must be one of: "
            + ", ".join(sorted(SCIENTIFIC_FOUNDATION_DISPLAY_MODES))
        )
    if status == "published" and display_mode != "reviewed-evidence":
        raise ThematicContractError("published scientific foundations require reviewed-evidence display mode")
    if status != "published" and display_mode != "status-only":
        raise ThematicContractError("unpublished scientific foundations must use status-only display mode")


def _validate_manifest_modules(value: Any, public_modes: set[str]) -> tuple[dict[str, Any], ...]:
    if not isinstance(value, list) or not value:
        raise ThematicContractError("modules must be a non-empty array")

    module_ids: list[str] = []
    module_modes: set[str] = set()
    modules: list[dict[str, Any]] = []
    for index, candidate in enumerate(value):
        module = _require_mapping(candidate, f"modules[{index}]")
        _reject_unknown(module, MODULE_KEYS, f"modules[{index}]")
        for key in ("id", "mode", "kind", "empty_state"):
            _require_string(module, key)
        module_id = module["id"]
        _validate_id(module_id, f"modules[{index}].id")
        mode = module["mode"]
        if mode not in PUBLIC_MODES:
            raise ThematicContractError(f"modules[{index}].mode must be one of: {', '.join(sorted(PUBLIC_MODES))}")
        if mode not in public_modes:
            raise ThematicContractError(f"modules[{index}].mode must be declared in public_modes")
        kind = module["kind"]
        if kind not in MODULE_KINDS:
            raise ThematicContractError(f"modules[{index}].kind must be one of: {', '.join(sorted(MODULE_KINDS))}")
        empty_state = module["empty_state"]
        if empty_state not in EMPTY_STATES:
            raise ThematicContractError(
                f"modules[{index}].empty_state must be one of: {', '.join(sorted(EMPTY_STATES))}"
            )
        data_contract = module.get("data_contract")
        if kind in DATA_MODULE_KINDS:
            if not isinstance(data_contract, str) or not data_contract.strip():
                raise ThematicContractError(f"modules[{index}].data_contract is required for {kind} modules")
        elif data_contract is not None and (not isinstance(data_contract, str) or not data_contract.strip()):
            raise ThematicContractError(f"modules[{index}].data_contract must be a non-empty string when provided")
        module_ids.append(module_id)
        module_modes.add(mode)
        modules.append(dict(module))
    if len(module_ids) != len(set(module_ids)):
        raise ThematicContractError("module ids must be unique")
    missing_modes = sorted(public_modes - module_modes)
    if missing_modes:
        raise ThematicContractError(f"public_modes require a module: {', '.join(missing_modes)}")
    return tuple(modules)


def validate_thematic_product_manifest(record: Any, *, strict: bool = False) -> None:
    """Validate a thematic product manifest and its public safety boundary."""
    manifest = _require_mapping(record, "manifest")
    required = {
        "schema_version",
        "product_id",
        "product_name",
        "lifecycle",
        "subject",
        "qazstack_consumer_contract",
        "public_modes",
        "source_policy",
        "publication",
        "geo_policy",
        "sensitivity",
        "modules",
        "release",
    }
    missing = sorted(required - manifest.keys())
    if missing:
        raise ThematicContractError(f"missing required fields: {', '.join(missing)}")
    _reject_unknown(manifest, MANIFEST_KEYS, "manifest")
    if manifest["schema_version"] != THEMATIC_PRODUCT_SCHEMA_VERSION:
        raise ThematicContractError(f"schema_version must be {THEMATIC_PRODUCT_SCHEMA_VERSION}")
    product_id = _require_string(manifest, "product_id")
    _validate_id(product_id, "product_id")
    _require_string(manifest, "product_name")
    _require_string(manifest, "subject")
    _require_string(manifest, "qazstack_consumer_contract")
    lifecycle = _require_string(manifest, "lifecycle")
    if lifecycle not in LIFECYCLES:
        raise ThematicContractError(f"lifecycle must be one of: {', '.join(sorted(LIFECYCLES))}")
    public_modes = set(_require_unique_strings(manifest["public_modes"], "public_modes"))
    if not public_modes <= PUBLIC_MODES:
        raise ThematicContractError(f"public_modes must use: {', '.join(sorted(PUBLIC_MODES))}")

    source_policy = _require_mapping(manifest["source_policy"], "source_policy")
    _reject_unknown(source_policy, SOURCE_POLICY_KEYS, "source_policy")
    _require_string(source_policy, "registry_path")
    source_classes = set(
        _require_unique_strings(source_policy.get("allowed_classes"), "source_policy.allowed_classes", min_length=1)
    )
    if not source_classes <= SOURCE_CLASSES:
        raise ThematicContractError(f"source_policy.allowed_classes must use: {', '.join(sorted(SOURCE_CLASSES))}")
    if source_policy.get("candidates_require_review") is not True:
        raise ThematicContractError("source_policy.candidates_require_review must be true")

    if "scientific_foundation" in manifest:
        _validate_scientific_foundation(manifest["scientific_foundation"])

    publication = _require_mapping(manifest["publication"], "publication")
    _reject_unknown(publication, PUBLICATION_KEYS, "publication")
    if publication.get("mode") not in PUBLICATION_MODES:
        raise ThematicContractError(f"publication.mode must be one of: {', '.join(sorted(PUBLICATION_MODES))}")
    if publication.get("public_records_require_review") is not True:
        raise ThematicContractError("publication.public_records_require_review must be true")
    if publication.get("explicit_degraded_state") is not True:
        raise ThematicContractError("publication.explicit_degraded_state must be true")

    geo_policy = _require_mapping(manifest["geo_policy"], "geo_policy")
    _reject_unknown(geo_policy, GEO_POLICY_KEYS, "geo_policy")
    if geo_policy.get("public_precision") not in GEO_PRECISIONS:
        raise ThematicContractError(f"geo_policy.public_precision must be one of: {', '.join(sorted(GEO_PRECISIONS))}")
    if geo_policy.get("private_browser_access_forbidden") is not True:
        raise ThematicContractError("geo_policy.private_browser_access_forbidden must be true")
    if geo_policy.get("exact_user_locations_public") is not False:
        raise ThematicContractError("geo_policy.exact_user_locations_public must be false")

    sensitivity = _require_mapping(manifest["sensitivity"], "sensitivity")
    _reject_unknown(sensitivity, SENSITIVITY_KEYS, "sensitivity")
    sensitivity_classes = set(_require_unique_strings(sensitivity.get("classes"), "sensitivity.classes"))
    if not sensitivity_classes <= SENSITIVITY_CLASSES:
        raise ThematicContractError(f"sensitivity.classes must use: {', '.join(sorted(SENSITIVITY_CLASSES))}")
    _require_unique_strings(sensitivity.get("public_prohibitions"), "sensitivity.public_prohibitions", min_length=1)

    _validate_manifest_modules(manifest["modules"], public_modes)

    release = _require_mapping(manifest["release"], "release")
    _reject_unknown(release, RELEASE_KEYS, "release")
    _require_string(release, "public_release_path")
    test_commands = _require_unique_strings(release.get("test_commands"), "release.test_commands")
    runtime_urls = _validate_urls(release.get("runtime_urls"), "release.runtime_urls")
    if "verified_at" in release:
        _parse_datetime(release["verified_at"], "release.verified_at")
    if "checked_by" in release:
        _require_string(release, "checked_by")
    if lifecycle in {"pilot", "beta", "production"} and not test_commands:
        raise ThematicContractError("active thematic products require at least one release.test_commands entry")
    if strict and lifecycle == "production":
        if not runtime_urls:
            raise ThematicContractError("production thematic products require at least one release.runtime_urls entry")
        if "verified_at" not in release:
            raise ThematicContractError("production thematic products require release.verified_at")
        if "checked_by" not in release:
            raise ThematicContractError("production thematic products require release.checked_by")


def thematic_manifest_digest(manifest: Mapping[str, Any]) -> str:
    """Return the canonical digest that binds a public release to its manifest."""
    validate_thematic_product_manifest(manifest)
    encoded = json.dumps(manifest, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return f"sha256:{hashlib.sha256(encoded).hexdigest()}"


def validate_thematic_release(record: Any, *, manifest: Mapping[str, Any] | None = None) -> None:
    """Validate a public release without interpreting domain-specific records."""
    release = _require_mapping(record, "release")
    required = {
        "schema_version",
        "product_id",
        "release_id",
        "published_at",
        "data_as_of",
        "manifest_digest",
        "modules",
    }
    missing = sorted(required - release.keys())
    if missing:
        raise ThematicContractError(f"missing required fields: {', '.join(missing)}")
    _reject_unknown(release, THEMATIC_RELEASE_KEYS, "release")
    if release["schema_version"] != THEMATIC_RELEASE_SCHEMA_VERSION:
        raise ThematicContractError(f"schema_version must be {THEMATIC_RELEASE_SCHEMA_VERSION}")
    product_id = _require_string(release, "product_id")
    _validate_id(product_id, "release.product_id")
    _require_string(release, "release_id")
    published_at = _parse_datetime(release["published_at"], "release.published_at")
    data_as_of = _parse_datetime(release["data_as_of"], "release.data_as_of")
    if data_as_of > published_at:
        raise ThematicContractError("release.data_as_of must not be after release.published_at")
    digest = _require_string(release, "manifest_digest")
    if not DIGEST_RE.fullmatch(digest):
        raise ThematicContractError("release.manifest_digest must be a sha256: digest")
    modules = release["modules"]
    if not isinstance(modules, list) or not modules:
        raise ThematicContractError("release.modules must be a non-empty array")
    module_ids: list[str] = []
    for index, candidate in enumerate(modules):
        module = _require_mapping(candidate, f"release.modules[{index}]")
        _reject_unknown(module, THEMATIC_RELEASE_MODULE_KEYS, f"release.modules[{index}]")
        module_id = _require_string(module, "id")
        _validate_id(module_id, f"release.modules[{index}].id")
        state = _require_string(module, "state")
        if state not in MODULE_STATES:
            raise ThematicContractError(
                f"release.modules[{index}].state must be one of: {', '.join(sorted(MODULE_STATES))}"
            )
        record_count = module.get("record_count")
        if not isinstance(record_count, int) or isinstance(record_count, bool) or record_count < 0:
            raise ThematicContractError(f"release.modules[{index}].record_count must be a non-negative integer")
        if state == "ready" and record_count == 0:
            raise ThematicContractError(f"release.modules[{index}] cannot be ready with zero records")
        if state in {"empty", "hidden"} and record_count:
            raise ThematicContractError(f"release.modules[{index}] {state} state must have zero records")
        module_as_of = _parse_datetime(module.get("as_of"), f"release.modules[{index}].as_of")
        if module_as_of > published_at:
            raise ThematicContractError(f"release.modules[{index}].as_of must not be after release.published_at")
        source_ids = _require_unique_strings(module.get("source_ids"), f"release.modules[{index}].source_ids")
        if state == "ready" and not source_ids:
            raise ThematicContractError(f"release.modules[{index}] ready state requires source_ids")
        if "notes" in module:
            _require_string(module, "notes")
        elif state == "degraded":
            raise ThematicContractError(f"release.modules[{index}] degraded state requires notes")
        module_ids.append(module_id)
    if len(module_ids) != len(set(module_ids)):
        raise ThematicContractError("release module ids must be unique")

    if manifest is not None:
        validate_thematic_product_manifest(manifest)
        if release["product_id"] != manifest["product_id"]:
            raise ThematicContractError("release.product_id must match manifest.product_id")
        if digest != thematic_manifest_digest(manifest):
            raise ThematicContractError("release.manifest_digest must match the supplied manifest")
        declared_module_ids = {module["id"] for module in manifest["modules"]}
        unknown_modules = sorted(set(module_ids) - declared_module_ids)
        if unknown_modules:
            raise ThematicContractError(f"release contains undeclared modules: {', '.join(unknown_modules)}")


@dataclass(frozen=True, slots=True)
class ThematicProductManifest:
    """Validated portable manifest for a public thematic product."""

    payload: dict[str, Any]

    @classmethod
    def from_mapping(cls, record: Mapping[str, Any], *, strict: bool = False) -> "ThematicProductManifest":
        validate_thematic_product_manifest(record, strict=strict)
        return cls(payload=dict(record))

    def to_dict(self) -> dict[str, Any]:
        return json.loads(json.dumps(self.payload))


@dataclass(frozen=True, slots=True)
class ThematicRelease:
    """Validated release envelope that keeps empty and degraded modules visible."""

    payload: dict[str, Any]

    @classmethod
    def from_mapping(
        cls,
        record: Mapping[str, Any],
        *,
        manifest: Mapping[str, Any] | None = None,
    ) -> "ThematicRelease":
        validate_thematic_release(record, manifest=manifest)
        return cls(payload=dict(record))

    def to_dict(self) -> dict[str, Any]:
        return json.loads(json.dumps(self.payload))


def load_thematic_product_manifest(path: str | Path, *, strict: bool = False) -> ThematicProductManifest:
    """Load and validate a thematic manifest from JSON."""
    return ThematicProductManifest.from_mapping(json.loads(Path(path).read_text(encoding="utf-8")), strict=strict)


def load_thematic_release(
    path: str | Path,
    *,
    manifest: Mapping[str, Any] | None = None,
) -> ThematicRelease:
    """Load and validate one public thematic release from JSON."""
    return ThematicRelease.from_mapping(json.loads(Path(path).read_text(encoding="utf-8")), manifest=manifest)


def thematic_product_template(
    product_id: str,
    product_name: str,
    *,
    subject: str,
    lifecycle: str = "planned",
) -> dict[str, Any]:
    """Return a conservative manifest template with no publishable modules."""
    return {
        "schema_version": THEMATIC_PRODUCT_SCHEMA_VERSION,
        "product_id": product_id,
        "product_name": product_name,
        "lifecycle": lifecycle,
        "subject": subject,
        "qazstack_consumer_contract": "qazstack-consumer.json",
        "public_modes": ["trust"],
        "source_policy": {
            "registry_path": "docs/sources.json",
            "allowed_classes": ["official", "research", "editorial"],
            "candidates_require_review": True,
        },
        "publication": {
            "mode": "reviewed-snapshot",
            "public_records_require_review": True,
            "explicit_degraded_state": True,
        },
        "geo_policy": {
            "public_precision": "region",
            "private_browser_access_forbidden": True,
            "exact_user_locations_public": False,
        },
        "sensitivity": {"classes": [], "public_prohibitions": ["Complete before the first public release."]},
        "modules": [
            {
                "id": "source-status",
                "mode": "trust",
                "kind": "registry",
                "data_contract": "public/source-status.json",
                "empty_state": "degraded-state",
            }
        ],
        "release": {
            "public_release_path": "public/thematic-release.json",
            "test_commands": [],
            "runtime_urls": [],
        },
    }
