"""Versioned contracts for public thematic products.

The module models the reusable delivery boundary shared by thematic products:
source policy, public modules, a reviewed release, and explicit degraded
states. It deliberately does not own a product's domain records or database.
"""

from .contracts import (
    THEMATIC_PRODUCT_SCHEMA_VERSION,
    THEMATIC_RELEASE_SCHEMA_VERSION,
    ThematicContractError,
    ThematicProductManifest,
    ThematicRelease,
    load_thematic_product_manifest,
    load_thematic_release,
    thematic_manifest_digest,
    thematic_product_template,
    validate_thematic_product_manifest,
    validate_thematic_release,
)
from .source_registry import (
    REVIEWED_SOURCE_REGISTRY_SCHEMA_VERSION,
    ReviewedSourceRegistryError,
    validate_reviewed_source_registry,
)

__all__ = [
    "THEMATIC_PRODUCT_SCHEMA_VERSION",
    "THEMATIC_RELEASE_SCHEMA_VERSION",
    "REVIEWED_SOURCE_REGISTRY_SCHEMA_VERSION",
    "ReviewedSourceRegistryError",
    "ThematicContractError",
    "ThematicProductManifest",
    "ThematicRelease",
    "load_thematic_product_manifest",
    "load_thematic_release",
    "thematic_manifest_digest",
    "thematic_product_template",
    "validate_thematic_product_manifest",
    "validate_thematic_release",
    "validate_reviewed_source_registry",
]
