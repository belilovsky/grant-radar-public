"""Portable validation for reviewed public source registries."""

from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from datetime import date
from typing import Any
from urllib.parse import urlparse

REVIEWED_SOURCE_REGISTRY_SCHEMA_VERSION = "qazstack-reviewed-source-registry-v1"
SOURCE_CLASSES = frozenset({"official", "public-sector", "research", "editorial", "community", "user-submitted"})
RIGHTS_DECISIONS = frozenset(
    {
        "approved-link-metadata",
        "approved-citation",
        "approved-copy",
        "restricted",
        "rejected",
    }
)
REGISTRY_STATUSES = frozenset({"active-link-metadata", "reviewed-snapshot", "degraded"})
SOURCE_ID_PATTERN = re.compile(r"^[a-z0-9][a-z0-9-]{1,127}$")
LOCALIZED_TEXT_PATTERN = re.compile(r"^(summary|use_case)_[a-z]{2,8}$")


class ReviewedSourceRegistryError(ValueError):
    """Raised when a public source registry is incomplete or unsafe."""


def _mapping(value: Any, context: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ReviewedSourceRegistryError(f"{context} must be an object")
    return value


def _text(value: Any, context: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ReviewedSourceRegistryError(f"{context} must be a non-empty string")
    return value.strip()


def _https_url(value: Any, context: str) -> str:
    normalized = _text(value, context)
    parsed = urlparse(normalized)
    if parsed.scheme != "https" or not parsed.netloc:
        raise ReviewedSourceRegistryError(f"{context} must be an absolute HTTPS URL")
    return normalized


def _iso_date(value: Any, context: str) -> str:
    normalized = _text(value, context)
    try:
        date.fromisoformat(normalized)
    except ValueError as exc:
        raise ReviewedSourceRegistryError(f"{context} must use YYYY-MM-DD") from exc
    return normalized


def _unique_strings(value: Any, context: str) -> tuple[str, ...]:
    if not isinstance(value, list) or not value:
        raise ReviewedSourceRegistryError(f"{context} must be a non-empty array")
    normalized = tuple(_text(item, context) for item in value)
    if len(set(normalized)) != len(normalized):
        raise ReviewedSourceRegistryError(f"{context} must not contain duplicates")
    return normalized


def _has_localized_text(source: Mapping[str, Any], prefix: str) -> bool:
    direct = source.get(prefix)
    if isinstance(direct, Mapping):
        return any(isinstance(value, str) and value.strip() for value in direct.values())
    return any(
        key.startswith(f"{prefix}_")
        and LOCALIZED_TEXT_PATTERN.fullmatch(key)
        and isinstance(value, str)
        and value.strip()
        for key, value in source.items()
    )


def validate_reviewed_source_registry(record: Any) -> None:
    """Validate a reviewed, metadata-only public source registry.

    Products retain their domain-specific source types, notes and publication
    decisions. The shared contract only enforces stable identity, transport,
    rights, review and evidence-boundary fields.
    """

    registry = _mapping(record, "registry")
    if registry.get("schema_version") != REVIEWED_SOURCE_REGISTRY_SCHEMA_VERSION:
        raise ReviewedSourceRegistryError(f"schema_version must be {REVIEWED_SOURCE_REGISTRY_SCHEMA_VERSION}")
    if registry.get("status") not in REGISTRY_STATUSES:
        raise ReviewedSourceRegistryError("registry.status is invalid")
    sources = registry.get("sources")
    if not isinstance(sources, Sequence) or isinstance(sources, (str, bytes)) or not sources:
        raise ReviewedSourceRegistryError("registry.sources must be a non-empty array")
    if registry.get("source_count") != len(sources):
        raise ReviewedSourceRegistryError("registry.source_count must match sources")

    policy = _mapping(registry.get("policy"), "registry.policy")
    allowed_classes = set(_unique_strings(policy.get("allowed_classes"), "policy.allowed_classes"))
    if not allowed_classes <= SOURCE_CLASSES:
        raise ReviewedSourceRegistryError("policy.allowed_classes contains an unknown class")
    for required_flag in (
        "requires_rights_review",
        "requires_human_review_before_publication",
        "private_materials_are_excluded",
    ):
        if policy.get(required_flag) is not True:
            raise ReviewedSourceRegistryError(f"policy.{required_flag} must be true")

    source_ids: list[str] = []
    for index, value in enumerate(sources):
        source = _mapping(value, f"sources[{index}]")
        source_id = _text(source.get("id"), f"sources[{index}].id")
        if not SOURCE_ID_PATTERN.fullmatch(source_id):
            raise ReviewedSourceRegistryError(f"sources[{index}].id must be lowercase kebab-case")
        source_ids.append(source_id)
        for key in ("title", "publisher", "source_type", "scope", "claim_publication"):
            _text(source.get(key), f"sources[{index}].{key}")
        source_class = _text(source.get("source_class"), f"sources[{index}].source_class")
        if source_class not in allowed_classes:
            raise ReviewedSourceRegistryError(f"sources[{index}].source_class is not allowed by policy")
        _https_url(source.get("url"), f"sources[{index}].url")
        if source.get("fallback_url") is not None:
            _https_url(source.get("fallback_url"), f"sources[{index}].fallback_url")
        _iso_date(source.get("retrieved_at"), f"sources[{index}].retrieved_at")
        if source.get("rights_decision") not in RIGHTS_DECISIONS:
            raise ReviewedSourceRegistryError(f"sources[{index}].rights_decision is invalid")
        if not _has_localized_text(source, "summary"):
            raise ReviewedSourceRegistryError(f"sources[{index}] requires localized summary text")
        if not _has_localized_text(source, "use_case"):
            raise ReviewedSourceRegistryError(f"sources[{index}] requires localized use_case text")
        if "languages" in source:
            _unique_strings(source["languages"], f"sources[{index}].languages")

    if len(set(source_ids)) != len(source_ids):
        raise ReviewedSourceRegistryError("registry source ids must be unique")
