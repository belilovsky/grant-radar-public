"""Product-neutral control-plane profile helpers for admin surfaces.

The helper builds the common read-only profile shape used by content/admin
consumers. Products keep their own routes, policy hooks, pipeline semantics and
copy; QazStack only owns the manifest lookup, fallback handling and counts.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

StringMap = Mapping[str, Any]
PackageFallback = Mapping[str, str]


def _mapping(value: Any) -> StringMap:
    """Return mapping values only; malformed manifest fragments become empty."""
    return value if isinstance(value, Mapping) else {}


def _string_sequence(value: Any, fallback: Sequence[str]) -> list[str]:
    """Return clean string values from manifest data or local fallback."""
    if not isinstance(value, list):
        return [str(item) for item in fallback if str(item).strip()]
    return [str(item) for item in value if str(item).strip()]


def resolve_manifest_product_packages(
    manifest: StringMap | None,
    fallback_packages: Sequence[PackageFallback],
) -> list[dict[str, str]]:
    """Resolve package labels from a Platform manifest with local fallbacks.

    The manifest may contain a top-level ``product_packages`` mapping keyed by
    package ID. Products provide the ordered fallback list, so QazStack never
    decides which packages a product claims or how those packages should be
    named when the manifest is absent.
    """

    source_packages = _mapping(_mapping(manifest).get("product_packages"))
    packages: list[dict[str, str]] = []
    for fallback in fallback_packages:
        package_id = str(fallback.get("id") or "").strip()
        if not package_id:
            continue
        source = _mapping(source_packages.get(package_id))
        packages.append(
            {
                "id": package_id,
                "name": str(source.get("name") or fallback.get("name") or package_id),
                "wave": str(source.get("wave") or fallback.get("wave") or "unknown"),
                "readiness": str(source.get("readiness") or fallback.get("readiness") or "unknown"),
            }
        )
    return packages


def build_manifest_control_plane_profile(
    *,
    project_id: str,
    adoption_target: str,
    manifest_url: str,
    product_packages: Sequence[PackageFallback],
    pipeline_stages: Sequence[str],
    evidence_events: Sequence[str],
    entity_types: Sequence[str],
    policy_hooks: Sequence[str],
    next_gate: str,
    manifest: StringMap | None = None,
    fallback_status: str = "partial-local",
    done_status: str = "done",
    done_variant: str = "success",
    fallback_variant: str = "info",
) -> dict[str, Any]:
    """Build a safe admin control-plane profile from optional manifest data.

    ``manifest`` is treated as untrusted public catalog data. Only the adoption
    status, next gate, project binding ``policy_hooks`` and ``entity_types``,
    and product package labels are read from it. Every operational decision
    remains product-owned through the function parameters.
    """

    clean_project_id = str(project_id).strip()
    clean_adoption_target = str(adoption_target).strip()
    if not clean_project_id:
        raise ValueError("project_id is required")
    if not clean_adoption_target:
        raise ValueError("adoption_target is required")

    manifest_root = _mapping(manifest)
    adoption = _mapping(_mapping(manifest_root.get("consumer_adoption_targets")).get(clean_adoption_target))
    binding = _mapping(_mapping(manifest_root.get("project_bindings")).get(clean_project_id))
    has_manifest = bool(manifest_root)
    packages = resolve_manifest_product_packages(manifest_root, product_packages)
    resolved_policy_hooks = _string_sequence(binding.get("policy_hooks"), policy_hooks)
    resolved_entity_types = _string_sequence(binding.get("entity_types"), entity_types)
    resolved_pipeline_stages = [str(item) for item in pipeline_stages if str(item).strip()]
    resolved_evidence_events = [str(item) for item in evidence_events if str(item).strip()]
    status = str(adoption.get("status") or fallback_status)

    return {
        "project_id": clean_project_id,
        "adoption_target": clean_adoption_target,
        "manifest_url": str(manifest_url),
        "source": "manifest" if has_manifest else "local",
        "status": status,
        "variant": done_variant if status == done_status else fallback_variant,
        "product_packages": packages,
        "pipeline_stages": resolved_pipeline_stages,
        "evidence_events": resolved_evidence_events,
        "entity_types": resolved_entity_types,
        "policy_hooks": resolved_policy_hooks,
        "counts": {
            "product_packages": len(packages),
            "pipeline_stages": len(resolved_pipeline_stages),
            "evidence_events": len(resolved_evidence_events),
            "entity_types": len(resolved_entity_types),
            "policy_hooks": len(resolved_policy_hooks),
        },
        "next_gate": str(adoption.get("next_gate") or next_gate),
    }
