"""Admin module: SQLAlchemy admin panel for FastAPI projects.

Wraps sqladmin with Belilovsky Platform defaults (branding, auth, i18n).

Usage:
    from qazstack.admin import setup_admin, ModelAdmin

    # Define admin views
    class ArticleAdmin(ModelAdmin, model=Article):
        column_list = [Article.id, Article.title, Article.pub_date]
        column_searchable_list = [Article.title]
        column_sortable_list = [Article.id, Article.pub_date]
        page_size = 25

    # In main.py
    setup_admin(app, engine=db.engine, views=[ArticleAdmin])
"""

from qazstack.admin.control_plane import build_manifest_control_plane_profile, resolve_manifest_product_packages
from qazstack.admin.setup import ModelAdmin, setup_admin

__all__ = [
    "ModelAdmin",
    "build_manifest_control_plane_profile",
    "resolve_manifest_product_packages",
    "setup_admin",
]
