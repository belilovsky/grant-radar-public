"""Portable MCP primitive manifest contracts.

The contracts describe what a product exposes to MCP-aware clients without
starting a server, storing credentials or assuming a specific framework such as
FastMCP. Products can publish these manifests in docs, health endpoints or CI
artifacts and validate them before wiring agents to live tools.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

MCP_SERVER_MANIFEST_SCHEMA_VERSION = "qazstack-mcp-server-manifest-v1"
_IDENTIFIER_PATTERN = re.compile(r"^[a-z0-9][a-z0-9._-]*$")
_PRIMITIVE_NAME_PATTERN = re.compile(r"^[A-Za-z0-9_.:-]+$")
_SCOPES = {"public", "owner", "private", "admin"}
_TRANSPORTS = {"stdio", "http", "sse", "in-app", "external"}
_SECRET_PATTERNS = (
    re.compile(r"(^|[^A-Za-z0-9])sk-[A-Za-z0-9_-]+"),
    re.compile(r"(^|[^A-Za-z0-9])ghp_[A-Za-z0-9_]+"),
    re.compile(r"(^|[^A-Za-z0-9])github_pat_[A-Za-z0-9_]+"),
    re.compile(r"(bot_token|access_token|client_secret)", re.IGNORECASE),
)

McpScope = Literal["public", "owner", "private", "admin"]
McpTransport = Literal["stdio", "http", "sse", "in-app", "external"]


def _require_identifier(value: str, field_name: str) -> str:
    cleaned = value.strip()
    if not _IDENTIFIER_PATTERN.fullmatch(cleaned):
        raise ValueError(f"{field_name} must be a lowercase identifier")
    return cleaned


def _require_text(value: str, field_name: str) -> str:
    cleaned = value.strip()
    if not cleaned:
        raise ValueError(f"{field_name} must not be blank")
    if any(pattern.search(cleaned) for pattern in _SECRET_PATTERNS):
        raise ValueError(f"{field_name} must not contain credential markers")
    return cleaned


def _require_primitive_name(value: str, field_name: str) -> str:
    cleaned = _require_text(value, field_name)
    if not _PRIMITIVE_NAME_PATTERN.fullmatch(cleaned):
        raise ValueError(f"{field_name} must be an MCP-safe primitive name")
    return cleaned


def _unique_text(values: tuple[str, ...], field_name: str) -> tuple[str, ...]:
    cleaned = tuple(_require_text(value, field_name) for value in values)
    if len(set(cleaned)) != len(cleaned):
        raise ValueError(f"{field_name} must not contain duplicates")
    return cleaned


def _validate_scope(scope: str) -> McpScope:
    if scope not in _SCOPES:
        raise ValueError(f"unsupported MCP scope: {scope}")
    return scope  # type: ignore[return-value]


def _as_mapping(value: object, field_name: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ValueError(f"{field_name} must be an object")
    return dict(value)


def _as_sequence(value: object, field_name: str) -> tuple[object, ...]:
    if value is None:
        return ()
    if not isinstance(value, list | tuple):
        raise ValueError(f"{field_name} must be a list")
    return tuple(value)


@dataclass(frozen=True, slots=True)
class McpTool:
    """One executable MCP tool exposed by a product."""

    name: str
    description: str
    scope: McpScope = "owner"
    input_schema_ref: str | None = None
    requires_user_confirmation: bool = False
    evidence_refs: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        object.__setattr__(self, "name", _require_primitive_name(self.name, "tool.name"))
        object.__setattr__(self, "description", _require_text(self.description, "tool.description"))
        object.__setattr__(self, "scope", _validate_scope(self.scope))
        if self.input_schema_ref is not None:
            object.__setattr__(self, "input_schema_ref", _require_text(self.input_schema_ref, "input_schema_ref"))
        object.__setattr__(self, "evidence_refs", _unique_text(self.evidence_refs, "tool.evidence_refs"))

    def as_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "scope": self.scope,
            "input_schema_ref": self.input_schema_ref,
            "requires_user_confirmation": self.requires_user_confirmation,
            "evidence_refs": list(self.evidence_refs),
        }

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "McpTool":
        return cls(
            name=str(payload.get("name", "")),
            description=str(payload.get("description", "")),
            scope=str(payload.get("scope", "owner")),  # type: ignore[arg-type]
            input_schema_ref=payload.get("input_schema_ref")
            if isinstance(payload.get("input_schema_ref"), str)
            else None,
            requires_user_confirmation=bool(payload.get("requires_user_confirmation", False)),
            evidence_refs=tuple(
                str(value) for value in _as_sequence(payload.get("evidence_refs"), "tool.evidence_refs")
            ),
        )


@dataclass(frozen=True, slots=True)
class McpResource:
    """One read-oriented MCP resource exposed by a product."""

    uri: str
    name: str
    description: str
    scope: McpScope = "public"
    mime_type: str | None = None
    evidence_refs: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        object.__setattr__(self, "uri", _require_text(self.uri, "resource.uri"))
        object.__setattr__(self, "name", _require_primitive_name(self.name, "resource.name"))
        object.__setattr__(self, "description", _require_text(self.description, "resource.description"))
        object.__setattr__(self, "scope", _validate_scope(self.scope))
        if self.mime_type is not None:
            object.__setattr__(self, "mime_type", _require_text(self.mime_type, "mime_type"))
        object.__setattr__(self, "evidence_refs", _unique_text(self.evidence_refs, "resource.evidence_refs"))

    def as_dict(self) -> dict[str, Any]:
        return {
            "uri": self.uri,
            "name": self.name,
            "description": self.description,
            "scope": self.scope,
            "mime_type": self.mime_type,
            "evidence_refs": list(self.evidence_refs),
        }

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "McpResource":
        return cls(
            uri=str(payload.get("uri", "")),
            name=str(payload.get("name", "")),
            description=str(payload.get("description", "")),
            scope=str(payload.get("scope", "public")),  # type: ignore[arg-type]
            mime_type=payload.get("mime_type") if isinstance(payload.get("mime_type"), str) else None,
            evidence_refs=tuple(
                str(value) for value in _as_sequence(payload.get("evidence_refs"), "resource.evidence_refs")
            ),
        )


@dataclass(frozen=True, slots=True)
class McpPrompt:
    """One reusable MCP prompt template exposed by a product."""

    name: str
    description: str
    arguments: tuple[str, ...] = ()
    scope: McpScope = "owner"
    evidence_refs: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        object.__setattr__(self, "name", _require_primitive_name(self.name, "prompt.name"))
        object.__setattr__(self, "description", _require_text(self.description, "prompt.description"))
        object.__setattr__(
            self,
            "arguments",
            tuple(_require_primitive_name(value, "prompt.arguments") for value in self.arguments),
        )
        if len(set(self.arguments)) != len(self.arguments):
            raise ValueError("prompt.arguments must not contain duplicates")
        object.__setattr__(self, "scope", _validate_scope(self.scope))
        object.__setattr__(self, "evidence_refs", _unique_text(self.evidence_refs, "prompt.evidence_refs"))

    def as_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "arguments": list(self.arguments),
            "scope": self.scope,
            "evidence_refs": list(self.evidence_refs),
        }

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "McpPrompt":
        return cls(
            name=str(payload.get("name", "")),
            description=str(payload.get("description", "")),
            arguments=tuple(str(value) for value in _as_sequence(payload.get("arguments"), "prompt.arguments")),
            scope=str(payload.get("scope", "owner")),  # type: ignore[arg-type]
            evidence_refs=tuple(
                str(value) for value in _as_sequence(payload.get("evidence_refs"), "prompt.evidence_refs")
            ),
        )


@dataclass(frozen=True, slots=True)
class McpServerManifest:
    """Offline description of a product's MCP-facing surface."""

    server_id: str
    title: str
    transport: McpTransport
    auth_boundary: str
    tools: tuple[McpTool, ...] = ()
    resources: tuple[McpResource, ...] = ()
    prompts: tuple[McpPrompt, ...] = ()
    evidence_refs: tuple[str, ...] = ()
    schema_version: str = MCP_SERVER_MANIFEST_SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        object.__setattr__(self, "server_id", _require_identifier(self.server_id, "server_id"))
        object.__setattr__(self, "title", _require_text(self.title, "title"))
        if self.transport not in _TRANSPORTS:
            raise ValueError(f"unsupported MCP transport: {self.transport}")
        object.__setattr__(self, "auth_boundary", _require_text(self.auth_boundary, "auth_boundary"))
        if self.schema_version != MCP_SERVER_MANIFEST_SCHEMA_VERSION:
            raise ValueError(f"schema_version must be {MCP_SERVER_MANIFEST_SCHEMA_VERSION}")
        object.__setattr__(self, "evidence_refs", _unique_text(self.evidence_refs, "evidence_refs"))
        if not (self.tools or self.resources or self.prompts):
            raise ValueError("manifest must expose at least one MCP primitive")
        self._validate_unique_names("tool", tuple(tool.name for tool in self.tools))
        self._validate_unique_names("resource", tuple(resource.name for resource in self.resources))
        self._validate_unique_names("prompt", tuple(prompt.name for prompt in self.prompts))
        private_scopes = {
            primitive.scope
            for primitive in (*self.tools, *self.resources, *self.prompts)
            if primitive.scope in {"owner", "private", "admin"}
        }
        if private_scopes and self.auth_boundary.lower() in {"none", "public", "anonymous"}:
            raise ValueError("private MCP primitives require an explicit auth_boundary")

    @staticmethod
    def _validate_unique_names(kind: str, names: tuple[str, ...]) -> None:
        if len(set(names)) != len(names):
            raise ValueError(f"{kind} names must be unique")

    @property
    def summary(self) -> dict[str, Any]:
        scopes = {
            scope: sum(primitive.scope == scope for primitive in (*self.tools, *self.resources, *self.prompts))
            for scope in sorted(_SCOPES)
        }
        return {
            "tools": len(self.tools),
            "resources": len(self.resources),
            "prompts": len(self.prompts),
            "primitive_count": len(self.tools) + len(self.resources) + len(self.prompts),
            "scopes": scopes,
            "requires_confirmation": sum(tool.requires_user_confirmation for tool in self.tools),
        }

    def as_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "server_id": self.server_id,
            "title": self.title,
            "transport": self.transport,
            "auth_boundary": self.auth_boundary,
            "summary": self.summary,
            "tools": [tool.as_dict() for tool in sorted(self.tools, key=lambda item: item.name)],
            "resources": [resource.as_dict() for resource in sorted(self.resources, key=lambda item: item.name)],
            "prompts": [prompt.as_dict() for prompt in sorted(self.prompts, key=lambda item: item.name)],
            "evidence_refs": list(self.evidence_refs),
            "metadata": dict(sorted(self.metadata.items())),
        }

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "McpServerManifest":
        if payload.get("schema_version") != MCP_SERVER_MANIFEST_SCHEMA_VERSION:
            raise ValueError(f"schema_version must be {MCP_SERVER_MANIFEST_SCHEMA_VERSION}")
        return cls(
            server_id=str(payload.get("server_id", "")),
            title=str(payload.get("title", "")),
            transport=str(payload.get("transport", "")),  # type: ignore[arg-type]
            auth_boundary=str(payload.get("auth_boundary", "")),
            tools=tuple(
                McpTool.from_dict(_as_mapping(item, "tools[]")) for item in _as_sequence(payload.get("tools"), "tools")
            ),
            resources=tuple(
                McpResource.from_dict(_as_mapping(item, "resources[]"))
                for item in _as_sequence(payload.get("resources"), "resources")
            ),
            prompts=tuple(
                McpPrompt.from_dict(_as_mapping(item, "prompts[]"))
                for item in _as_sequence(payload.get("prompts"), "prompts")
            ),
            evidence_refs=tuple(str(value) for value in _as_sequence(payload.get("evidence_refs"), "evidence_refs")),
            metadata=_as_mapping(payload.get("metadata", {}), "metadata"),
        )


def load_mcp_server_manifest(path: str | Path) -> McpServerManifest:
    """Load and validate one checked-in MCP manifest JSON file."""

    import json

    manifest_path = Path(path)
    return McpServerManifest.from_dict(json.loads(manifest_path.read_text(encoding="utf-8")))
