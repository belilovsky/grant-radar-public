"""qazstack.monitor – unified monitoring and data collection module.

Provides a complete monitoring pipeline: collect data from multiple sources
(RSS, Telegram, HTTP), process with NLP, generate alerts, and store results.

Models (SQLAlchemy 2.0)::

    from qazstack.monitor import MonitorBase, Source, Message, AnalysisResult, Alert, CheckResult

Store (async CRUD)::

    from qazstack.monitor import MonitorStore
    store = MonitorStore()
    async with db.session() as session:
        source = await store.add_source(session, name="Feed", source_type="rss", project="myapp")

Collectors::

    from qazstack.monitor import HTTPChecker, CollectorResult
    http = HTTPChecker()
    async for result in http.collect({"url": "https://example.com/health"}):
        print(result.text)

Pipeline (NLP)::

    from qazstack.monitor import MonitorPipeline
    pipeline = MonitorPipeline(steps=["lang_detect", "normalize"])
    results = await pipeline.process_text("Привет мир")

Alerts::

    from qazstack.monitor import AlertManager, TelegramChannel
    mgr = AlertManager(channels=[TelegramChannel(bot_token="...", chat_id="...")])
    await mgr.fire("state_change", "critical", "app:health", "Endpoint down")

Scheduler (ARQ)::

    from qazstack.monitor import create_monitor_tasks
    tasks = create_monitor_tasks(store=store, pipeline=pipeline)
"""

from qazstack.monitor.alerts import AlertManager, TelegramChannel, WebhookChannel
from qazstack.monitor.collectors.base import BaseCollector, CollectorResult
from qazstack.monitor.collectors.http import HTTPChecker
from qazstack.monitor.consumer_probes import (
    ConsumerProbe,
    probes_from_registry,
    run_consumer_probe,
    run_consumer_probes,
    validate_probe_response,
)
from qazstack.monitor.pipeline import MonitorPipeline
from qazstack.monitor.probes import ProbeResult, http_probe, summarize_probes, threshold_probe
from qazstack.monitor.public_surface import (
    canonical_matches_root,
    collect_public_surface_status,
    detect_analytics,
    detect_seo,
    detect_sitemap,
    fetch_analytics_summary,
    normalize_analytics_summary,
    normalize_site_url,
)
from qazstack.monitor.quality import DataQualityObservation

try:
    from qazstack.monitor.models import (
        Alert,
        AnalysisResult,
        CheckResult,
        Message,
        MonitorBase,
        Source,
    )
except ImportError:
    Alert = AnalysisResult = CheckResult = Message = MonitorBase = Source = None  # type: ignore[assignment,misc]

try:
    from qazstack.monitor.scheduler import create_monitor_tasks
except ImportError:
    create_monitor_tasks = None  # type: ignore[assignment]

try:
    from qazstack.monitor.store import MonitorStore
except ImportError:
    MonitorStore = None  # type: ignore[assignment,misc]

# Optional collectors – may not be installed
try:
    from qazstack.monitor.collectors.rss import RSSCollector
except ImportError:
    RSSCollector = None  # type: ignore[assignment,misc]

try:
    from qazstack.monitor.collectors.telegram import TelegramAdapter
except ImportError:
    TelegramAdapter = None  # type: ignore[assignment,misc]


__all__ = [
    # Models
    "MonitorBase",
    "Source",
    "Message",
    "AnalysisResult",
    "Alert",
    "CheckResult",
    # Store
    "MonitorStore",
    # Pipeline
    "MonitorPipeline",
    "ProbeResult",
    "http_probe",
    "summarize_probes",
    "threshold_probe",
    "ConsumerProbe",
    "probes_from_registry",
    "run_consumer_probe",
    "run_consumer_probes",
    "validate_probe_response",
    # Alerts
    "AlertManager",
    "TelegramChannel",
    "WebhookChannel",
    # Collectors
    "BaseCollector",
    "CollectorResult",
    "HTTPChecker",
    # Public surface diagnostics
    "collect_public_surface_status",
    "canonical_matches_root",
    "detect_analytics",
    "detect_seo",
    "detect_sitemap",
    "fetch_analytics_summary",
    "normalize_analytics_summary",
    "normalize_site_url",
    "RSSCollector",
    "TelegramAdapter",
    # Scheduler
    "create_monitor_tasks",
    "DataQualityObservation",
]
