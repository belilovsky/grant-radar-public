"""Read-only public surface checks for the admin system dashboard."""

from __future__ import annotations

import asyncio
import re
import urllib.parse
import xml.etree.ElementTree as ET
from html.parser import HTMLParser
from typing import Any

import httpx

from qazstack.core.public_urls import canonical_matches_root, derive_url, normalize_site_url

HTTP_TIMEOUT_SECONDS = 3.0


class SurfaceHtmlParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.in_title = False
        self.title_chunks: list[str] = []
        self.description: str | None = None
        self.canonical_url: str | None = None
        self.robots_meta: str | None = None
        self.hreflangs: list[str] = []
        self.og: dict[str, str] = {}

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        tag = tag.lower()
        attr_map = {str(key).lower(): value for key, value in attrs if key}
        if tag == "title":
            self.in_title = True
            return
        if tag == "meta":
            name = str(attr_map.get("name") or "").strip().lower()
            prop = str(attr_map.get("property") or "").strip().lower()
            content = str(attr_map.get("content") or "").strip()
            if name == "description" and content:
                self.description = content
            if name == "robots" and content:
                self.robots_meta = content
            if prop.startswith("og:") and content:
                self.og[prop] = content
            return
        if tag == "link":
            rel_tokens = {token.strip().lower() for token in str(attr_map.get("rel") or "").split() if token.strip()}
            href = str(attr_map.get("href") or "").strip()
            if "canonical" in rel_tokens and href:
                self.canonical_url = href
            hreflang = str(attr_map.get("hreflang") or "").strip().lower()
            if "alternate" in rel_tokens and hreflang:
                self.hreflangs.append(hreflang)

    def handle_endtag(self, tag: str) -> None:
        if tag.lower() == "title":
            self.in_title = False

    def handle_data(self, data: str) -> None:
        if self.in_title:
            self.title_chunks.append(data)

    @property
    def title(self) -> str | None:
        joined = " ".join(chunk.strip() for chunk in self.title_chunks if chunk.strip())
        return joined or None


_canonical_matches_root = canonical_matches_root


def detect_analytics(html: str) -> dict[str, Any]:
    ga4_ids = {match.upper() for match in re.findall(r"\bG-[A-Z0-9]+\b", html, flags=re.IGNORECASE)}
    gtm_ids = {match.upper() for match in re.findall(r"\bGTM-[A-Z0-9]+\b", html, flags=re.IGNORECASE)}
    providers: list[str] = []
    measurement_ids: list[str] = []

    if ga4_ids or "googletagmanager.com/gtag/js" in html or "gtag(" in html:
        providers.append("ga4")
        measurement_ids.extend(sorted(ga4_ids))
    if gtm_ids:
        providers.append("gtm")
        measurement_ids.extend(sorted(gtm_ids))
    if "umami" in html.lower() or "data-website-id=" in html.lower():
        providers.append("umami")

    return {
        "tag_present": bool(providers),
        "providers": list(dict.fromkeys(providers)),
        "measurement_ids": list(dict.fromkeys(measurement_ids)),
    }


def detect_seo(html: str, root_url: str) -> dict[str, Any]:
    parser = SurfaceHtmlParser()
    parser.feed(html)
    robots_meta = (parser.robots_meta or "").lower()
    canonical_url = urllib.parse.urljoin(root_url, parser.canonical_url) if parser.canonical_url else None
    return {
        "title_present": bool(parser.title),
        "description_present": bool(parser.description),
        "canonical_url": canonical_url,
        "canonical_matches_root": canonical_matches_root(parser.canonical_url, root_url),
        "og_title_present": bool(parser.og.get("og:title")),
        "og_description_present": bool(parser.og.get("og:description")),
        "og_image_present": bool(parser.og.get("og:image")),
        "hreflangs": list(dict.fromkeys(parser.hreflangs)),
        "page_noindex": "noindex" in robots_meta,
    }


def _strip_ns(tag: str) -> str:
    return tag.rsplit("}", 1)[-1] if "}" in tag else tag


def detect_sitemap(body: str, content_type: str | None) -> dict[str, Any]:
    raw = body.lstrip()
    if not raw:
        return {
            "summary": "invalid",
            "xml_valid": False,
            "kind": None,
            "entry_count": 0,
            "lastmod_count": 0,
            "sample_urls": [],
            "content_type": content_type,
            "error": "empty body",
        }
    if "<" not in raw[:32]:
        return {
            "summary": "invalid",
            "xml_valid": False,
            "kind": None,
            "entry_count": 0,
            "lastmod_count": 0,
            "sample_urls": [],
            "content_type": content_type,
            "error": "non-xml response",
        }

    try:
        root = ET.fromstring(body)
    except ET.ParseError as exc:
        return {
            "summary": "invalid",
            "xml_valid": False,
            "kind": None,
            "entry_count": 0,
            "lastmod_count": 0,
            "sample_urls": [],
            "content_type": content_type,
            "error": f"xml parse error: {exc}",
        }

    kind = _strip_ns(root.tag).lower()
    if kind not in {"urlset", "sitemapindex"}:
        return {
            "summary": "invalid",
            "xml_valid": False,
            "kind": kind,
            "entry_count": 0,
            "lastmod_count": 0,
            "sample_urls": [],
            "content_type": content_type,
            "error": f"unexpected root element: {kind}",
        }

    entry_name = "url" if kind == "urlset" else "sitemap"
    entries = [child for child in root if _strip_ns(child.tag).lower() == entry_name]
    sample_urls: list[str] = []
    lastmod_count = 0
    for entry in entries:
        loc = None
        has_lastmod = False
        for child in entry:
            child_name = _strip_ns(child.tag).lower()
            text = (child.text or "").strip()
            if child_name == "loc" and text and len(sample_urls) < 5:
                loc = text
            if child_name == "lastmod" and text:
                has_lastmod = True
        if loc:
            sample_urls.append(loc)
        if has_lastmod:
            lastmod_count += 1

    summary = "ok"
    if not entries:
        summary = "empty"
    elif lastmod_count == 0:
        summary = "no_lastmod"
    return {
        "summary": summary,
        "xml_valid": True,
        "kind": kind,
        "entry_count": len(entries),
        "lastmod_count": lastmod_count,
        "sample_urls": sample_urls,
        "content_type": content_type,
        "error": None,
    }


def _robots_blocks_all(body: str) -> bool:
    for raw_line in body.splitlines():
        line = raw_line.strip().lower()
        if line.startswith("disallow:") and line.split(":", 1)[1].strip() == "/":
            return True
    return False


def _sitemap_declared(body: str) -> bool:
    return any(line.strip().lower().startswith("sitemap:") for line in body.splitlines())


def _next_actions(gaps: list[str]) -> list[str]:
    actions: list[str] = []
    if "root_unreachable" in gaps:
        actions.append("restore the public root route")
    if "robots_unreachable" in gaps:
        actions.append("restore robots.txt")
    if "sitemap_unreachable" in gaps:
        actions.append("restore sitemap.xml")
    if "sitemap_not_declared" in gaps:
        actions.append("declare sitemap.xml in robots.txt")
    if "page_noindex" in gaps:
        actions.append("remove noindex from the public root page")
    if "analytics_tag_missing" in gaps:
        actions.append("install a live analytics tag or configure the summary adapter")
    if "canonical_mismatch" in gaps:
        actions.append("align the canonical URL with the public root URL")
    if "hreflang_missing" in gaps:
        actions.append("add alternate hreflang links where the locale surface exists")
    if "sitemap_invalid" in gaps:
        actions.append("serve a valid XML sitemap response")
    if "sitemap_empty" in gaps:
        actions.append("populate sitemap.xml with public URLs")
    if "sitemap_lastmod_missing" in gaps:
        actions.append("add lastmod to sitemap entries")
    return actions


async def _fetch_text(
    client: httpx.AsyncClient,
    url: str,
) -> dict[str, Any]:
    try:
        response = await client.get(url)
    except httpx.HTTPError as exc:
        return {
            "ok": False,
            "url": url,
            "final_url": url,
            "status_code": None,
            "content_type": None,
            "body": "",
            "error": str(exc),
        }
    return {
        "ok": 200 <= response.status_code < 300,
        "url": url,
        "final_url": str(response.url),
        "status_code": response.status_code,
        "content_type": response.headers.get("content-type"),
        "body": response.text,
        "error": None if 200 <= response.status_code < 300 else f"http {response.status_code}",
    }


def normalize_analytics_summary(payload: dict[str, Any]) -> dict[str, Any]:
    nested_payload = payload.get("payload")
    envelope: dict[str, Any] = nested_payload if isinstance(nested_payload, dict) else payload
    return {
        "configured": True,
        "available": True,
        "provider": envelope.get("provider") or "unknown",
        "range": envelope.get("range"),
        "users": envelope.get("users"),
        "sessions": envelope.get("sessions"),
        "pageviews": envelope.get("pageviews"),
        "engagement_rate": envelope.get("engagement_rate"),
        "updated_at": envelope.get("updated_at"),
        "top_pages": list(envelope.get("top_pages") or [])[:5],
        "sources": list(envelope.get("sources") or [])[:5],
    }


async def fetch_analytics_summary(
    analytics_summary_url: str | None,
    *,
    timeout: float = HTTP_TIMEOUT_SECONDS,
) -> dict[str, Any]:
    if not analytics_summary_url:
        return {
            "configured": False,
            "available": False,
            "reason": "PUBLIC_ANALYTICS_SUMMARY_URL is not set",
        }
    try:
        async with httpx.AsyncClient(follow_redirects=True, timeout=timeout) as client:
            response = await client.get(analytics_summary_url)
            response.raise_for_status()
            payload = response.json()
    except (httpx.HTTPError, ValueError) as exc:
        return {
            "configured": True,
            "available": False,
            "reason": str(exc),
        }
    return normalize_analytics_summary(payload)


async def collect_public_surface_status(
    site_url: str,
    *,
    timeout: float = HTTP_TIMEOUT_SECONDS,
) -> dict[str, Any]:
    normalized_site_url = normalize_site_url(site_url)
    robots_url = derive_url(normalized_site_url, "/robots.txt")
    sitemap_url = derive_url(normalized_site_url, "/sitemap.xml")

    async with httpx.AsyncClient(follow_redirects=True, timeout=timeout) as client:
        root_probe, robots_probe, sitemap_probe = await asyncio.gather(
            _fetch_text(client, normalized_site_url),
            _fetch_text(client, robots_url),
            _fetch_text(client, sitemap_url),
        )

    root_html = root_probe["body"] if root_probe["ok"] else ""
    analytics = (
        detect_analytics(root_html)
        if root_html
        else {
            "tag_present": False,
            "providers": [],
            "measurement_ids": [],
        }
    )
    seo = (
        detect_seo(root_html, root_probe["final_url"])
        if root_html
        else {
            "title_present": False,
            "description_present": False,
            "canonical_url": None,
            "canonical_matches_root": False,
            "og_title_present": False,
            "og_description_present": False,
            "og_image_present": False,
            "hreflangs": [],
            "page_noindex": False,
        }
    )
    sitemap = (
        detect_sitemap(sitemap_probe["body"], sitemap_probe["content_type"])
        if sitemap_probe["ok"]
        else {
            "summary": "invalid",
            "xml_valid": False,
            "kind": None,
            "entry_count": 0,
            "lastmod_count": 0,
            "sample_urls": [],
            "content_type": sitemap_probe["content_type"],
            "error": sitemap_probe["error"] or "sitemap probe failed",
        }
    )

    robots_body = robots_probe["body"] if robots_probe["ok"] else ""
    gaps: list[str] = []
    if not root_probe["ok"]:
        gaps.append("root_unreachable")
    if not robots_probe["ok"]:
        gaps.append("robots_unreachable")
    if not sitemap_probe["ok"]:
        gaps.append("sitemap_unreachable")
    if robots_probe["ok"] and not _sitemap_declared(robots_body):
        gaps.append("sitemap_not_declared")
    if robots_probe["ok"] and _robots_blocks_all(robots_body):
        gaps.append("robots_blocks_all")
    if seo["page_noindex"]:
        gaps.append("page_noindex")
    if not analytics["tag_present"]:
        gaps.append("analytics_tag_missing")
    if root_probe["ok"] and not seo["canonical_matches_root"]:
        gaps.append("canonical_mismatch")
    if sitemap["summary"] == "invalid":
        gaps.append("sitemap_invalid")
    elif sitemap["summary"] == "empty":
        gaps.append("sitemap_empty")
    elif sitemap["summary"] == "no_lastmod":
        gaps.append("sitemap_lastmod_missing")

    return {
        "site_url": normalized_site_url,
        "status": "healthy" if not gaps else "attention",
        "crawl": {
            "root_reachable": root_probe["ok"],
            "robots_reachable": robots_probe["ok"],
            "sitemap_reachable": sitemap_probe["ok"],
            "robots_blocks_all": "robots_blocks_all" in gaps,
            "sitemap_declared": _sitemap_declared(robots_body) if robots_probe["ok"] else False,
            "page_noindex": seo["page_noindex"],
        },
        "sitemap": sitemap,
        "seo": seo,
        "analytics": analytics,
        "gaps": gaps,
        "next_actions": _next_actions(gaps),
    }
