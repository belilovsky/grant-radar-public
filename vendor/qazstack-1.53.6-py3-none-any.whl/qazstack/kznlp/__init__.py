"""KzNLP – NLP utilities for Kazakh and Russian text processing.

Provides language detection, text normalization, tokenization, NER,
lemmatization, stopwords, sentiment analysis, and a unified processing
pipeline for the bilingual Kazakh-Russian environment.

Basic usage (no heavy deps)::

    from qazstack.kznlp import detect_lang, normalize_text, tokenize
    from qazstack.kznlp import STOPWORDS_RU, STOPWORDS_KK

    lang = detect_lang("Президент Токаев выступил с обращением")
    # → "ru"

    tokens = tokenize("Еңбек етсең ерінбей.")
    # → ["Еңбек", "етсең", "ерінбей", "."]

    clean = normalize_text("  Қайыpлы   таӊ!  ")
    # → "Қайырлы тан!"

NER (requires natasha for Russian, or transformers for Kazakh)::

    from qazstack.kznlp import extract_entities

    entities = extract_entities("Президент Токаев встретился с Путиным в Астане")
    # → [Entity(text="Токаев", label="PER", ...), ...]

Sentiment (requires transformers + torch)::

    from qazstack.kznlp import classify_sentiment, SentimentResult

    result = classify_sentiment("Отличные новости для экономики")
    # → SentimentResult(label='positive', score=0.89, tone=0.74, ...)
"""

from qazstack.kznlp.advisory import (
    AdvisoryEntity,
    QazShieldEntityAdviser,
    entities_from_anonymize_payload,
    get_default_entity_adviser,
    normalize_entity_text,
    normalize_entity_type,
    should_reject_person_candidate,
)
from qazstack.kznlp.lang_detect import (
    LanguageDetection,
    detect_lang,
    detect_lang_with_confidence,
    is_kazakh,
    is_russian,
)
from qazstack.kznlp.lemma import lemmatize, lemmatize_tokens
from qazstack.kznlp.ner import Entity, extract_entities
from qazstack.kznlp.normalize import (
    collapse_whitespace,
    fix_homoglyphs,
    normalize_text,
    strip_html_tags,
)
from qazstack.kznlp.stopwords import STOPWORDS_ALL, STOPWORDS_KK, STOPWORDS_RU, is_stopword
from qazstack.kznlp.tokenize import sent_tokenize, tokenize

# Sentiment – optional heavy dependency (transformers + torch)
try:
    from qazstack.kznlp.sentiment import (
        SentimentResult,
        classify_sentiment,
        classify_sentiment_batch,
    )
except ImportError:
    classify_sentiment = None  # type: ignore[assignment]
    classify_sentiment_batch = None  # type: ignore[assignment]
    SentimentResult = None  # type: ignore[assignment,misc]

__all__ = [
    # Advisory entity classification
    "AdvisoryEntity",
    "QazShieldEntityAdviser",
    "entities_from_anonymize_payload",
    "get_default_entity_adviser",
    "normalize_entity_text",
    "normalize_entity_type",
    "should_reject_person_candidate",
    # Language detection
    "LanguageDetection",
    "detect_lang",
    "detect_lang_with_confidence",
    "is_kazakh",
    "is_russian",
    # Normalization
    "normalize_text",
    "fix_homoglyphs",
    "collapse_whitespace",
    "strip_html_tags",
    # Tokenization
    "tokenize",
    "sent_tokenize",
    # Stopwords
    "STOPWORDS_RU",
    "STOPWORDS_KK",
    "STOPWORDS_ALL",
    "is_stopword",
    # NER
    "extract_entities",
    "Entity",
    # Lemmatization
    "lemmatize",
    "lemmatize_tokens",
    # Sentiment
    "classify_sentiment",
    "classify_sentiment_batch",
    "SentimentResult",
]
