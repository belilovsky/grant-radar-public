"""Bounded tail sampling for optional trace telemetry."""

from __future__ import annotations

import time
from collections import OrderedDict
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class TailSampleDecision:
    trace_id: str
    sampled: bool
    reason: str


@dataclass(slots=True)
class _TraceBuffer:
    max_duration_ms: int = 0
    has_error: bool = False
    span_count: int = 0
    size_bytes: int = 0


class TailSampler:
    """Keep traces until an error/slow/rate policy can make one decision.

    This sampler is intentionally backend-neutral. It bounds active traces,
    span count, bytes, and decisions; callers remain responsible for exporting
    sampled spans and for keeping correctness evidence outside sampling.
    """

    def __init__(
        self,
        *,
        max_traces: int = 1024,
        max_spans_per_trace: int = 256,
        max_trace_bytes: int = 1_048_576,
        slow_threshold_ms: int = 1000,
        normal_sample_rate: float = 0.1,
        decision_ttl_seconds: float = 60.0,
        max_decisions: int = 4096,
        clock=time.monotonic,
    ) -> None:
        if min(max_traces, max_spans_per_trace, max_trace_bytes, max_decisions) < 1:
            raise ValueError("tail sampler bounds must be positive")
        if slow_threshold_ms < 0:
            raise ValueError("slow_threshold_ms must not be negative")
        if not 0 <= normal_sample_rate <= 1:
            raise ValueError("normal_sample_rate must be between zero and one")
        if decision_ttl_seconds <= 0:
            raise ValueError("decision_ttl_seconds must be positive")
        self.max_traces = max_traces
        self.max_spans_per_trace = max_spans_per_trace
        self.max_trace_bytes = max_trace_bytes
        self.slow_threshold_ms = slow_threshold_ms
        self.decision_ttl_seconds = decision_ttl_seconds
        self.max_decisions = max_decisions
        self._normal_sample_rate = normal_sample_rate
        self._clock = clock
        self._traces: OrderedDict[str, _TraceBuffer] = OrderedDict()
        self._decisions: OrderedDict[str, tuple[float, TailSampleDecision]] = OrderedDict()
        self._tokens = 1.0
        self._last_token_at = clock()
        self._metrics = {
            "sampled": 0,
            "dropped": 0,
            "dropped_too_early": 0,
            "decision_cache_hits": 0,
        }

    def _cached_decision(self, trace_id: str, now: float) -> TailSampleDecision | None:
        entry = self._decisions.get(trace_id)
        if entry is None:
            return None
        expires_at, decision = entry
        if expires_at <= now:
            self._decisions.pop(trace_id, None)
            return None
        self._decisions.move_to_end(trace_id)
        self._metrics["decision_cache_hits"] += 1
        return decision

    def _remember(self, decision: TailSampleDecision, now: float) -> None:
        self._decisions[decision.trace_id] = (now + self.decision_ttl_seconds, decision)
        self._decisions.move_to_end(decision.trace_id)
        while len(self._decisions) > self.max_decisions:
            self._decisions.popitem(last=False)
        self._metrics["sampled" if decision.sampled else "dropped"] += 1

    def _drop_early(self, trace_id: str, now: float) -> None:
        self._traces.pop(trace_id, None)
        self._metrics["dropped_too_early"] += 1
        self._remember(TailSampleDecision(trace_id, False, "dropped-too-early"), now)

    def add_span(
        self,
        trace_id: str,
        *,
        duration_ms: int = 0,
        status: str = "ok",
        size_bytes: int = 1,
        now: float | None = None,
    ) -> bool:
        """Buffer a span; return ``False`` when the trace is already dropped."""
        if not trace_id.strip():
            raise ValueError("trace_id must be non-empty")
        if duration_ms < 0 or size_bytes < 1:
            raise ValueError("duration_ms and size_bytes are invalid")
        current_time = self._clock() if now is None else now
        if self._cached_decision(trace_id, current_time) is not None:
            return False
        if trace_id not in self._traces and len(self._traces) >= self.max_traces:
            oldest_id, _ = self._traces.popitem(last=False)
            self._drop_early(oldest_id, current_time)
        buffer = self._traces.setdefault(trace_id, _TraceBuffer())
        self._traces.move_to_end(trace_id)
        buffer.span_count += 1
        buffer.size_bytes += size_bytes
        buffer.max_duration_ms = max(buffer.max_duration_ms, duration_ms)
        buffer.has_error = buffer.has_error or status.lower() in {"error", "failed"}
        if buffer.span_count > self.max_spans_per_trace or buffer.size_bytes > self.max_trace_bytes:
            self._drop_early(trace_id, current_time)
            return False
        return True

    def _consume_normal_token(self, now: float) -> bool:
        elapsed = max(0.0, now - self._last_token_at)
        self._last_token_at = now
        self._tokens = min(1.0, self._tokens + elapsed * self._normal_sample_rate)
        if self._tokens < 1.0:
            return False
        self._tokens -= 1.0
        return True

    def decide(self, trace_id: str, *, now: float | None = None) -> TailSampleDecision:
        if not trace_id.strip():
            raise ValueError("trace_id must be non-empty")
        current_time = self._clock() if now is None else now
        cached = self._cached_decision(trace_id, current_time)
        if cached is not None:
            return cached
        buffer = self._traces.pop(trace_id, None)
        if buffer is None:
            decision = TailSampleDecision(trace_id, False, "missing")
            self._remember(decision, current_time)
            return decision
        if buffer.has_error:
            reason = "error"
            sampled = True
        elif buffer.max_duration_ms >= self.slow_threshold_ms:
            reason = "slow"
            sampled = True
        else:
            sampled = self._consume_normal_token(current_time)
            reason = "rate" if sampled else "rate-limited"
        decision = TailSampleDecision(trace_id, sampled, reason)
        self._remember(decision, current_time)
        return decision

    @property
    def metrics(self) -> dict[str, int]:
        return {
            **self._metrics,
            "traces_in_memory": len(self._traces),
            "decisions_in_memory": len(self._decisions),
        }


__all__ = ["TailSampleDecision", "TailSampler"]
