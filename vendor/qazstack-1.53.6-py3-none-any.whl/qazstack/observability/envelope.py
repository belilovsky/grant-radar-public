"""Portable correlation envelope for logs, metrics and tracing adapters."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from qazstack.contracts._validation import require_aware, require_identifier, require_text


@dataclass(frozen=True, slots=True)
class ObservabilityEnvelope:
    service: str
    event: str
    occurred_at: datetime
    request_id: str | None = None
    run_id: str | None = None
    trace_id: str | None = None
    span_id: str | None = None
    severity: str = "info"
    duration_ms: int | None = None
    error_code: str | None = None
    attributes: tuple[tuple[str, str], ...] = ()
    evidence_refs: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        require_identifier(self.service, "service")
        require_identifier(self.event, "event")
        require_aware(self.occurred_at, "occurred_at")
        if self.severity not in {"debug", "info", "warning", "error", "critical"}:
            raise ValueError("severity is unsupported")
        if not any((self.request_id, self.run_id, self.trace_id, self.span_id)):
            raise ValueError("at least one correlation identifier is required")
        for name in ("request_id", "run_id", "trace_id", "span_id"):
            value = getattr(self, name)
            if value is not None:
                require_text(value, name)
        if self.duration_ms is not None and self.duration_ms < 0:
            raise ValueError("duration_ms must be non-negative")
        if len({key for key, _ in self.attributes}) != len(self.attributes):
            raise ValueError("attribute keys must be unique")
        for key, value in self.attributes:
            require_text(key, "attribute key")
            require_text(value, "attribute value")
        if len(set(self.evidence_refs)) != len(self.evidence_refs):
            raise ValueError("evidence_refs must be unique")
        for ref in self.evidence_refs:
            require_text(ref, "evidence_ref")

    def as_attributes(self) -> dict[str, str]:
        return dict(self.attributes)

    def as_otel_attributes(self) -> dict[str, str | int]:
        """Return OpenTelemetry-friendly attributes without binding a backend."""

        payload: dict[str, str | int] = {
            "service.name": self.service,
            "event.name": self.event,
            "event.severity": self.severity,
        }
        if self.request_id:
            payload["qazstack.request_id"] = self.request_id
        if self.run_id:
            payload["qazstack.run_id"] = self.run_id
        if self.trace_id:
            payload["trace_id"] = self.trace_id
        if self.span_id:
            payload["span_id"] = self.span_id
        if self.duration_ms is not None:
            payload["duration_ms"] = self.duration_ms
        if self.error_code:
            payload["error.type"] = self.error_code
        for key, value in self.attributes:
            payload[f"qazstack.{key}"] = value
        for index, ref in enumerate(self.evidence_refs):
            payload[f"qazstack.evidence_ref.{index}"] = ref
        return payload

    def as_event(self) -> dict[str, object]:
        """Serialize a deterministic event record for logs, probes or tasks."""

        return {
            "service": self.service,
            "event": self.event,
            "occurred_at": self.occurred_at.isoformat(),
            "severity": self.severity,
            "request_id": self.request_id,
            "run_id": self.run_id,
            "trace_id": self.trace_id,
            "span_id": self.span_id,
            "duration_ms": self.duration_ms,
            "error_code": self.error_code,
            "attributes": self.as_attributes(),
            "evidence_refs": list(self.evidence_refs),
        }
