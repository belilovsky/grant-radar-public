"""Observability: Sentry, request ID tracking, structured logging.

Consolidated from: qazposter/sentry_setup.py, qazposter/middleware/logging_middleware.py

Usage::

    from qazstack.observability import init_sentry, RequestIDMiddleware

    # In main.py:
    init_sentry(dsn="https://...", environment="production")
    app.add_middleware(RequestIDMiddleware)
"""

from qazstack.observability.envelope import ObservabilityEnvelope
from qazstack.observability.middleware import RequestIDMiddleware
from qazstack.observability.sentry import init_sentry
from qazstack.observability.tail_sampling import TailSampleDecision, TailSampler

__all__ = ["init_sentry", "ObservabilityEnvelope", "RequestIDMiddleware", "TailSampleDecision", "TailSampler"]
