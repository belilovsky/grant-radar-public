"""Digest-only runtime evidence for a provisioned QazStack task consumer.

The contract is intentionally storage and signer neutral. A release controller
measures the queue and worker, signs the canonical payload as a compact JWS and
the consumer verifies that JWS against the controller's JWKS. Constructing this
value is not, by itself, evidence that a runtime has been provisioned.
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import asdict, dataclass
from datetime import datetime
from typing import Any, Mapping

from qazstack.contracts._validation import require_aware, require_one_of, require_text

TASK_CONSUMER_RECEIPT_SCHEMA_VERSION = "qazstack-task-consumer-receipt-v1"
_DIGEST_RE = re.compile(r"^sha256:[0-9a-f]{64}$")
_CONSUMER_RE = re.compile(r"^[a-z0-9][a-z0-9-]{1,63}$")
_NAMESPACE_RE = re.compile(r"^[a-z0-9][a-z0-9-]{1,63}:v[1-9][0-9]*$")
_COMPACT_JWS_RE = re.compile(r"^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$")


def _digest(value: str, field_name: str) -> str:
    normalized = require_text(value, field_name)
    if not _DIGEST_RE.fullmatch(normalized):
        raise ValueError(f"{field_name} must be a sha256 digest")
    return normalized


@dataclass(frozen=True, slots=True)
class TaskConsumerRuntimeReceipt:
    """Signed proof that one revision-bound queue consumer passed runtime probes."""

    receipt_id: str
    consumer: str
    revision: str
    qazstack_revision: str
    namespace: str
    issued_at: datetime
    expires_at: datetime
    issuer: str
    signer_key_id: str
    queue_probe_digest: str
    worker_readiness_digest: str
    restart_probe_digest: str
    retry_probe_digest: str
    result_receipt_digest: str
    signature: str
    status: str = "provisioned"
    service_auth: str = "service-jwt"
    schema_version: str = TASK_CONSUMER_RECEIPT_SCHEMA_VERSION

    def __post_init__(self) -> None:
        require_one_of(self.schema_version, frozenset({TASK_CONSUMER_RECEIPT_SCHEMA_VERSION}), "schema_version")
        require_text(self.receipt_id, "receipt_id")
        if not _CONSUMER_RE.fullmatch(require_text(self.consumer, "consumer")):
            raise ValueError("consumer must be a canonical service slug")
        require_text(self.revision, "revision")
        require_text(self.qazstack_revision, "qazstack_revision")
        if len(self.revision) < 7 or len(self.qazstack_revision) < 7:
            raise ValueError("revision fields must be stable revisions")
        if not _NAMESPACE_RE.fullmatch(self.namespace):
            raise ValueError("namespace must be a versioned, consumer-owned namespace")
        require_one_of(self.status, frozenset({"provisioned"}), "status")
        require_one_of(self.service_auth, frozenset({"service-jwt", "mtls"}), "service_auth")
        require_aware(self.issued_at, "issued_at")
        require_aware(self.expires_at, "expires_at")
        if self.expires_at <= self.issued_at:
            raise ValueError("expires_at must be after issued_at")
        require_text(self.issuer, "issuer")
        require_text(self.signer_key_id, "signer_key_id")
        signature = require_text(self.signature, "signature")
        if len(signature) < 64 or not _COMPACT_JWS_RE.fullmatch(signature):
            raise ValueError("signature must contain a compact JWS")
        for field_name in (
            "queue_probe_digest",
            "worker_readiness_digest",
            "restart_probe_digest",
            "retry_probe_digest",
            "result_receipt_digest",
        ):
            _digest(getattr(self, field_name), field_name)

    def signing_payload(self) -> dict[str, Any]:
        """Return the canonical digest-only payload covered by the external JWS."""
        value = asdict(self)
        value.pop("signature")
        value["issued_at"] = self.issued_at.isoformat().replace("+00:00", "Z")
        value["expires_at"] = self.expires_at.isoformat().replace("+00:00", "Z")
        return value

    def payload_digest(self) -> str:
        encoded = json.dumps(self.signing_payload(), sort_keys=True, separators=(",", ":")).encode()
        return "sha256:" + hashlib.sha256(encoded).hexdigest()

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> "TaskConsumerRuntimeReceipt":
        payload = dict(value)
        for field_name in ("issued_at", "expires_at"):
            raw = payload.get(field_name)
            if not isinstance(raw, str):
                raise ValueError(f"{field_name} must be an ISO-8601 string")
            payload[field_name] = datetime.fromisoformat(raw.replace("Z", "+00:00"))
        return cls(**payload)


__all__ = ["TASK_CONSUMER_RECEIPT_SCHEMA_VERSION", "TaskConsumerRuntimeReceipt"]
