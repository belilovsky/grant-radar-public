"""Versioned public opportunity contracts for machine consumers.

The models describe portable public records. Products still own source
adapters, relevance rules, editorial language, eligibility interpretation and
publication decisions.
"""

from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping, Sequence
from datetime import date, datetime
from decimal import Decimal
from typing import Any, Literal
from urllib.parse import urlparse
from uuid import UUID

from pydantic import BaseModel, Field

OPPORTUNITY_SCHEMA_VERSION = "opportunity.v1"
OPPORTUNITY_DATASET_SCHEMA_VERSION = "opportunity-dataset.v1"


class LocalizedText(BaseModel):
    """Optional localized forms of one public text field."""

    ru: str | None = None
    kk: str | None = None
    en: str | None = None


class FundingAmount(BaseModel):
    """Structured funding amount with an optional source-form display value."""

    minimum: Decimal | None = None
    maximum: Decimal | None = None
    currency: str | None = None
    display: str | None = None


class SourceReference(BaseModel):
    """Stable public reference to the originating source."""

    id: str
    name: str
    url: str


class OpportunityTimestamps(BaseModel):
    """Collection and verification timestamps retained by the public record."""

    discovered_at: datetime
    source_checked_at: datetime | None = None
    last_verified_at: datetime | None = None


class OpportunityProvenance(BaseModel):
    """Evidence and content identity for a public opportunity."""

    evidence_state: Literal["verified", "sourced", "archival", "compiled", "unlinked"]
    verification_method: str
    adapter: str
    snapshot_hash: str | None = None
    content_hash: str


class OpportunityQuality(BaseModel):
    """Record-completeness signals, never an approval-probability estimate."""

    status: Literal["complete", "partial", "review_required"]
    confidence_score: float = Field(ge=0.0, le=1.0)
    missing_fields: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    score_meaning: str = "record completeness and source evidence, not approval probability"


class OpportunityLinks(BaseModel):
    """Consumer-facing links for a public opportunity."""

    public_page: str
    api: str
    official_source: str
    application: str | None = None


class OpportunityV1(BaseModel):
    """Portable public opportunity record."""

    schema_version: Literal["opportunity.v1"] = OPPORTUNITY_SCHEMA_VERSION
    id: UUID
    title: str
    title_i18n: LocalizedText = Field(default_factory=LocalizedText)
    summary: str
    summary_i18n: LocalizedText = Field(default_factory=LocalizedText)
    status: str
    deadline: date | None = None
    deadline_type: Literal["fixed", "rolling", "unknown"]
    formats: list[str] = Field(default_factory=list)
    target_audience: list[str] = Field(default_factory=list)
    themes: list[str] = Field(default_factory=list)
    regions: list[str] = Field(default_factory=list)
    source: SourceReference
    funder: str | None = None
    funding_amount: FundingAmount = Field(default_factory=FundingAmount)
    eligibility_summary: str | None = None
    eligibility: list[str] = Field(default_factory=list)
    timestamps: OpportunityTimestamps
    provenance: OpportunityProvenance
    quality: OpportunityQuality
    links: OpportunityLinks


def semantic_payload_hash(payload: Mapping[str, Any]) -> str:
    """Return a deterministic SHA-256 digest for a JSON-compatible payload."""

    serialized = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(serialized.encode("utf-8")).hexdigest()


def opportunity_dataset_revision(
    items: Sequence[OpportunityV1],
    *,
    schema_version: str = OPPORTUNITY_DATASET_SCHEMA_VERSION,
) -> str:
    """Return a stable dataset revision from record IDs and content hashes."""

    rows = sorted(
        (
            {
                "id": str(item.id),
                "content_hash": item.provenance.content_hash,
            }
            for item in items
        ),
        key=lambda row: row["id"],
    )
    return semantic_payload_hash({"schema_version": schema_version, "rows": rows})


def source_host(url: str) -> str:
    """Return a normalized host label for a public source URL."""

    return (urlparse(url).hostname or "").removeprefix("www.")


__all__ = [
    "FundingAmount",
    "LocalizedText",
    "OPPORTUNITY_DATASET_SCHEMA_VERSION",
    "OPPORTUNITY_SCHEMA_VERSION",
    "OpportunityLinks",
    "OpportunityProvenance",
    "OpportunityQuality",
    "OpportunityTimestamps",
    "OpportunityV1",
    "SourceReference",
    "opportunity_dataset_revision",
    "semantic_payload_hash",
    "source_host",
]
