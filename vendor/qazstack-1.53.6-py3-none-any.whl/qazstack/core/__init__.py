"""Core contracts and optional FastAPI helpers.

The operational contracts stay importable in minimal consumers. Web helpers
remain available on demand for applications that install the web extra.
"""

from qazstack.core.content_cache import (
    CachedArtifact,
    ContentAddressedCache,
    ContentCacheCorruptionError,
    content_cache_key,
)
from qazstack.core.membership import BloomFilter, IntBitmap, MembershipFilterError
from qazstack.core.operations import (
    ArtifactRef,
    BackupManifest,
    ConfigIssue,
    ConfigRule,
    DeploymentProof,
    MigrationPlan,
    MigrationProof,
    MigrationStep,
    ReleaseManifest,
    RestoreProof,
    RollbackProof,
    validate_config,
)
from qazstack.core.placement import BoundedRendezvousRouter, NoAvailableNodeError, PlacementNode
from qazstack.core.public_urls import canonical_matches_root, derive_url, normalize_site_url

_OPTIONAL_EXPORTS = {
    "BaseConfig": ("qazstack.core.config", "BaseConfig"),
    "Database": ("qazstack.core.database", "Database"),
    "create_app": ("qazstack.core.factory", "create_app"),
    "health_router": ("qazstack.core.health", "health_router"),
    "PublicCacheMiddleware": ("qazstack.core.public_cache", "PublicCacheMiddleware"),
    "append_vary": ("qazstack.core.public_cache", "append_vary"),
    "etag_matches": ("qazstack.core.public_cache", "etag_matches"),
    "weak_etag": ("qazstack.core.public_cache", "weak_etag"),
}


def __getattr__(name: str):
    """Load FastAPI, database and cache helpers only when a consumer requests one."""
    if name not in _OPTIONAL_EXPORTS:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
    module_name, attribute = _OPTIONAL_EXPORTS[name]
    module = __import__(module_name, fromlist=[attribute])
    value = getattr(module, attribute)
    globals()[name] = value
    return value


__all__ = [
    "BaseConfig",
    "Database",
    "create_app",
    "health_router",
    "PublicCacheMiddleware",
    "append_vary",
    "etag_matches",
    "weak_etag",
    "ArtifactRef",
    "BackupManifest",
    "ConfigIssue",
    "ConfigRule",
    "DeploymentProof",
    "MigrationPlan",
    "MigrationProof",
    "MigrationStep",
    "ReleaseManifest",
    "RestoreProof",
    "RollbackProof",
    "validate_config",
    "CachedArtifact",
    "ContentAddressedCache",
    "ContentCacheCorruptionError",
    "content_cache_key",
    "BoundedRendezvousRouter",
    "NoAvailableNodeError",
    "PlacementNode",
    "BloomFilter",
    "IntBitmap",
    "MembershipFilterError",
    "canonical_matches_root",
    "derive_url",
    "normalize_site_url",
]
