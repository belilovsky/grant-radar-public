"""Small content-addressed cache for deterministic generated artifacts."""

from __future__ import annotations

import hashlib
import json
import os
import tempfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping


class ContentCacheCorruptionError(ValueError):
    """Raised when a cached manifest or blob fails integrity validation."""


def _canonical_json(value: Mapping[str, Any]) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def content_cache_key(inputs: Mapping[str, Any], *, generator_version: str) -> str:
    """Return a stable SHA-256 key for declared inputs and generator identity."""
    if not generator_version.strip():
        raise ValueError("generator_version must be non-empty")
    return hashlib.sha256(_canonical_json({"generator_version": generator_version, "inputs": dict(inputs)})).hexdigest()


@dataclass(frozen=True, slots=True)
class CachedArtifact:
    key: str
    generator_version: str
    input_digest: str
    output_digest: str
    size_bytes: int
    created_at: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "key": self.key,
            "generator_version": self.generator_version,
            "input_digest": self.input_digest,
            "output_digest": self.output_digest,
            "size_bytes": self.size_bytes,
            "created_at": self.created_at,
        }


class ContentAddressedCache:
    """Filesystem blob cache with atomic writes and verified reads.

    The cache never decides whether an artifact is publishable. Consumers still
    own freshness, permissions, and release gates; this class only proves that
    a cached output matches the declared input key and stored output digest.
    """

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)

    def _paths(self, key: str) -> tuple[Path, Path]:
        if len(key) != 64 or any(char not in "0123456789abcdef" for char in key):
            raise ValueError("key must be a lowercase SHA-256 digest")
        directory = self.root / key[:2] / key
        return directory / "payload", directory / "manifest.json"

    def get(self, key: str) -> tuple[bytes, CachedArtifact] | None:
        payload_path, manifest_path = self._paths(key)
        if not manifest_path.is_file() or not payload_path.is_file():
            return None
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            payload = payload_path.read_bytes()
        except (OSError, json.JSONDecodeError) as exc:
            raise ContentCacheCorruptionError(f"cannot read cache entry {key}") from exc
        if not isinstance(manifest, dict):
            raise ContentCacheCorruptionError(f"cache manifest is not an object: {key}")
        try:
            artifact = CachedArtifact(**manifest)
        except (TypeError, ValueError) as exc:
            raise ContentCacheCorruptionError(f"invalid cache manifest: {key}") from exc
        if artifact.key != key or artifact.size_bytes != len(payload):
            raise ContentCacheCorruptionError(f"cache manifest mismatch: {key}")
        if hashlib.sha256(payload).hexdigest() != artifact.output_digest:
            raise ContentCacheCorruptionError(f"cache output digest mismatch: {key}")
        return payload, artifact

    def put(
        self,
        inputs: Mapping[str, Any],
        payload: bytes,
        *,
        generator_version: str,
    ) -> CachedArtifact:
        if not isinstance(payload, bytes):
            raise TypeError("payload must be bytes")
        key = content_cache_key(inputs, generator_version=generator_version)
        payload_path, manifest_path = self._paths(key)
        payload_path.parent.mkdir(parents=True, exist_ok=True)
        input_digest = hashlib.sha256(_canonical_json(dict(inputs))).hexdigest()
        artifact = CachedArtifact(
            key=key,
            generator_version=generator_version,
            input_digest=input_digest,
            output_digest=hashlib.sha256(payload).hexdigest(),
            size_bytes=len(payload),
            created_at=datetime.now(timezone.utc).isoformat(),
        )
        self._atomic_write(payload_path, payload)
        self._atomic_write(
            manifest_path,
            json.dumps(artifact.as_dict(), ensure_ascii=False, sort_keys=True, indent=2).encode("utf-8"),
        )
        return artifact

    @staticmethod
    def _atomic_write(path: Path, payload: bytes) -> None:
        temporary_name: str | None = None
        try:
            with tempfile.NamedTemporaryFile(dir=path.parent, prefix=f".{path.name}.", delete=False) as temporary:
                temporary_name = temporary.name
                temporary.write(payload)
                temporary.flush()
                os.fsync(temporary.fileno())
            os.replace(temporary_name, path)
            temporary_name = None
        finally:
            if temporary_name is not None:
                try:
                    os.unlink(temporary_name)
                except OSError:
                    pass


__all__ = ["CachedArtifact", "ContentAddressedCache", "ContentCacheCorruptionError", "content_cache_key"]
