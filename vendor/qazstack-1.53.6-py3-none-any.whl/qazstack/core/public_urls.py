"""Dependency-free helpers for comparing canonical public URLs."""

from __future__ import annotations

import ipaddress
import urllib.parse


def _normalize_host(host: str) -> str:
    """Return a stable IP or IDNA hostname without a DNS root dot."""
    candidate = host[:-1] if host.endswith(".") else host
    if not candidate:
        raise ValueError("site_url must contain a valid hostname")

    try:
        return str(ipaddress.ip_address(candidate)).lower()
    except ValueError:
        pass

    try:
        normalized = candidate.encode("idna").decode("ascii").lower()
    except UnicodeError as exc:
        raise ValueError("site_url must contain a valid IDNA hostname") from exc

    # The IDNA codec also maps Unicode full stops. Strip the one DNS root dot
    # that may appear after mapping, but reject empty labels and invalid DNS
    # label syntax rather than returning an unusable HTTP origin.
    if normalized.endswith("."):
        normalized = normalized[:-1]
    labels = normalized.split(".")
    if (
        not normalized
        or len(normalized) > 253
        or any(
            not label
            or len(label) > 63
            or label.startswith("-")
            or label.endswith("-")
            or any(not (character.isascii() and (character.isalnum() or character == "-")) for character in label)
            for label in labels
        )
    ):
        raise ValueError("site_url must contain a valid IDNA hostname")
    return normalized


def normalize_site_url(site_url: str) -> str:
    """Return an HTTP(S) site root with a trailing slash and no credentials."""
    try:
        parsed = urllib.parse.urlparse(site_url.strip())
        port = parsed.port
    except ValueError as exc:
        raise ValueError("site_url must be a valid HTTP(S) URL") from exc
    if parsed.scheme.lower() not in {"http", "https"} or not parsed.hostname:
        raise ValueError("site_url must be an absolute HTTP(S) URL")
    if parsed.username is not None or parsed.password is not None:
        raise ValueError("site_url must not contain credentials")
    host = _normalize_host(parsed.hostname)
    rendered_host = f"[{host}]" if ":" in host else host
    default_port = (parsed.scheme.lower() == "http" and port == 80) or (
        parsed.scheme.lower() == "https" and port == 443
    )
    netloc = rendered_host if port is None or default_port else f"{rendered_host}:{port}"
    path = parsed.path or "/"
    if not path.endswith("/"):
        path += "/"
    return urllib.parse.urlunparse((parsed.scheme.lower(), netloc, path, "", "", ""))


def derive_url(site_url: str, path: str) -> str:
    """Resolve a public path from a normalized site root."""
    candidate = urllib.parse.urlparse(path)
    if candidate.scheme or candidate.netloc:
        raise ValueError("path must not override the configured site origin")
    return urllib.parse.urljoin(normalize_site_url(site_url), path)


def _normalized_netloc(parsed: urllib.parse.ParseResult) -> str | None:
    if parsed.username is not None or parsed.password is not None or not parsed.hostname:
        return None
    try:
        host = _normalize_host(parsed.hostname)
        port = parsed.port
    except (UnicodeError, ValueError):
        return None
    default_port = (parsed.scheme.lower() == "http" and port == 80) or (
        parsed.scheme.lower() == "https" and port == 443
    )
    rendered_host = f"[{host}]" if ":" in host else host
    return f"{rendered_host}:{port}" if port is not None and not default_port else rendered_host


def canonical_matches_root(canonical_url: str | None, root_url: str) -> bool:
    """Return whether a canonical URL points at the configured site root.

    Query strings and fragments do not affect the root match. Host comparison
    uses IDNA so Unicode domains and their punycode form compare as one surface.
    """
    if not canonical_url:
        return False
    try:
        root = urllib.parse.urlparse(normalize_site_url(root_url))
        canonical = urllib.parse.urlparse(urllib.parse.urljoin(root.geturl(), canonical_url))
        root_netloc = _normalized_netloc(root)
        canonical_netloc = _normalized_netloc(canonical)
    except (UnicodeError, ValueError):
        return False
    if (
        canonical.scheme.lower() not in {"http", "https"}
        or root.scheme.lower() != canonical.scheme.lower()
        or root_netloc is None
        or canonical_netloc is None
        or root_netloc != canonical_netloc
    ):
        return False
    root_path = root.path or "/"
    canonical_path = canonical.path or "/"
    if root_path != "/":
        return canonical_path.rstrip("/") == root_path.rstrip("/")
    return canonical_path in {"", "/"}


__all__ = ["canonical_matches_root", "derive_url", "normalize_site_url"]
