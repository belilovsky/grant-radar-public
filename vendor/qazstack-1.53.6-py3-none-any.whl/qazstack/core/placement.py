"""Stable bounded-load placement for cache and worker keys."""

from __future__ import annotations

import hashlib
import math
from collections.abc import Mapping, Sequence
from dataclasses import dataclass


class NoAvailableNodeError(RuntimeError):
    """Raised when no healthy node has capacity for the requested replicas."""


@dataclass(frozen=True, slots=True)
class PlacementNode:
    node_id: str
    weight: float = 1.0
    capacity: int | None = None
    healthy: bool = True

    def __post_init__(self) -> None:
        if not self.node_id.strip():
            raise ValueError("node_id must be non-empty")
        if self.weight <= 0:
            raise ValueError("weight must be positive")
        if self.capacity is not None and self.capacity < 1:
            raise ValueError("capacity must be positive when provided")


class BoundedRendezvousRouter:
    """Route stable keys with weighted HRW ranking and hard capacities.

    A key is ranked independently against every healthy node. Saturated nodes
    are skipped, so adding/removing a node changes only the affected keys while
    capacity remains bounded. ``loads`` is a caller-owned snapshot, keeping
    queue/storage policy outside this deterministic placement primitive.
    """

    def __init__(self, nodes: Sequence[PlacementNode]) -> None:
        if not nodes:
            raise ValueError("at least one node is required")
        if len({node.node_id for node in nodes}) != len(nodes):
            raise ValueError("node_id values must be unique")
        self._nodes = tuple(nodes)

    @property
    def nodes(self) -> tuple[PlacementNode, ...]:
        return self._nodes

    def replace(self, nodes: Sequence[PlacementNode]) -> "BoundedRendezvousRouter":
        """Return a new immutable membership snapshot."""
        return type(self)(nodes)

    @staticmethod
    def _score(key: str, node: PlacementNode) -> float:
        digest = hashlib.sha256(f"{key}\0{node.node_id}".encode("utf-8")).digest()
        integer = int.from_bytes(digest, "big")
        unit = (integer + 1) / ((1 << 256) + 1)
        return -math.log(unit) / node.weight

    def route(
        self,
        key: str,
        *,
        replicas: int = 1,
        loads: Mapping[str, int] | None = None,
    ) -> tuple[str, ...]:
        if not key.strip():
            raise ValueError("key must be non-empty")
        if replicas < 1:
            raise ValueError("replicas must be positive")
        load_snapshot = loads or {}
        if any(value < 0 for value in load_snapshot.values()):
            raise ValueError("loads must not be negative")
        ranked = sorted(
            (node for node in self._nodes if node.healthy),
            key=lambda node: self._score(key, node),
        )
        selected: list[str] = []
        for node in ranked:
            current_load = load_snapshot.get(node.node_id, 0)
            if node.capacity is not None and current_load >= node.capacity:
                continue
            selected.append(node.node_id)
            if len(selected) == replicas:
                return tuple(selected)
        raise NoAvailableNodeError(f"no capacity for key {key!r} and {replicas} replica(s)")


__all__ = ["BoundedRendezvousRouter", "NoAvailableNodeError", "PlacementNode"]
