"""Fast membership filters for bounded source/entity lookup paths."""

from __future__ import annotations

import hashlib
import math
import struct


class MembershipFilterError(ValueError):
    """Raised when a serialized membership filter is invalid."""


class BloomFilter:
    """Compact probabilistic negative filter; false positives are allowed."""

    _HEADER = struct.Struct(">4sII")
    _MAGIC = b"QZBF"

    def __init__(self, *, expected_items: int, false_positive_rate: float = 0.01) -> None:
        if expected_items < 1:
            raise ValueError("expected_items must be positive")
        if not 0 < false_positive_rate < 1:
            raise ValueError("false_positive_rate must be between zero and one")
        self.bit_count = max(8, math.ceil(-(expected_items * math.log(false_positive_rate)) / (math.log(2) ** 2)))
        self.hash_count = max(1, math.ceil((self.bit_count / expected_items) * math.log(2)))
        self._bits = bytearray((self.bit_count + 7) // 8)

    @classmethod
    def _from_serialized(cls, bit_count: int, hash_count: int, bits: bytes) -> "BloomFilter":
        if bit_count < 8 or hash_count < 1:
            raise MembershipFilterError("Bloom filter dimensions are invalid")
        expected_bytes = (bit_count + 7) // 8
        if len(bits) != expected_bytes:
            raise MembershipFilterError("Bloom filter payload length is invalid")
        instance = cls.__new__(cls)
        instance.bit_count = bit_count
        instance.hash_count = hash_count
        instance._bits = bytearray(bits)
        return instance

    def _positions(self, value: str | bytes):
        raw = value.encode("utf-8") if isinstance(value, str) else value
        digest = hashlib.sha256(raw).digest()
        first = int.from_bytes(digest[:16], "big")
        second = int.from_bytes(digest[16:], "big") | 1
        for index in range(self.hash_count):
            yield (first + (index * second)) % self.bit_count

    def add(self, value: str | bytes) -> None:
        for position in self._positions(value):
            self._bits[position // 8] |= 1 << (position % 8)

    def might_contain(self, value: str | bytes) -> bool:
        return all(self._bits[position // 8] & (1 << (position % 8)) for position in self._positions(value))

    def __contains__(self, value: str | bytes) -> bool:
        return self.might_contain(value)

    def to_bytes(self) -> bytes:
        return self._HEADER.pack(self._MAGIC, self.bit_count, self.hash_count) + bytes(self._bits)

    @classmethod
    def from_bytes(cls, payload: bytes) -> "BloomFilter":
        if len(payload) < cls._HEADER.size:
            raise MembershipFilterError("Bloom filter payload is too short")
        magic, bit_count, hash_count = cls._HEADER.unpack(payload[: cls._HEADER.size])
        if magic != cls._MAGIC:
            raise MembershipFilterError("Bloom filter magic is invalid")
        return cls._from_serialized(bit_count, hash_count, payload[cls._HEADER.size :])


class IntBitmap:
    """Exact compact bitmap for non-negative integer IDs."""

    def __init__(self, values: tuple[int, ...] | list[int] = ()) -> None:
        self._bits = 0
        self.update(values)

    def add(self, value: int) -> None:
        if value < 0:
            raise ValueError("bitmap values must be non-negative")
        self._bits |= 1 << value

    def update(self, values) -> None:
        for value in values:
            self.add(value)

    def __contains__(self, value: int) -> bool:
        return value >= 0 and bool(self._bits & (1 << value))

    def intersection(self, other: "IntBitmap") -> "IntBitmap":
        result = type(self)()
        result._bits = self._bits & other._bits
        return result

    def union(self, other: "IntBitmap") -> "IntBitmap":
        result = type(self)()
        result._bits = self._bits | other._bits
        return result

    def to_tuple(self) -> tuple[int, ...]:
        values: list[int] = []
        bits = self._bits
        while bits:
            lowest = bits & -bits
            values.append(lowest.bit_length() - 1)
            bits ^= lowest
        return tuple(values)


__all__ = ["BloomFilter", "IntBitmap", "MembershipFilterError"]
