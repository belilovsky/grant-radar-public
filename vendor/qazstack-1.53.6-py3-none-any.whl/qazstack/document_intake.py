"""Local, Markdown-first intake for immutable document attachments.

The operation accepts a local path only. It never uploads source content, calls
an LLM, or writes alongside the original. MarkItDown handles ordinary office
files and text PDFs; the established QazStack/Tesseract backend is used only
when PDF text recovery is empty or for image inputs. Docling is an explicit,
locally approved fallback for difficult layout and tables.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from enum import StrEnum
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
from typing import Any, Callable

# The intake design was cut against this verified annotated release, rather
# than a moving branch or package-index claim. It remains a provenance anchor,
# not the installed package version of a consuming project.
IMPLEMENTATION_BASE = {
    "tag": "v1.52.0",
    "tag_object": "7231ff20c471a74051194f28beb9a007924cc188",
    "source_commit": "d0fa78f17eb7da1e9bf08b4ac332b38154b49c61",
}


class ConversionStatus(StrEnum):
    """Conservative terminal states for a Markdown conversion."""

    CONVERTED = "converted"
    NEEDS_REVIEW = "needs_review"
    UNSUPPORTED = "unsupported"
    FAILED = "failed"


@dataclass(frozen=True, slots=True)
class ConversionProvenance:
    """Minimal private provenance; source content and paths are excluded."""

    source_sha256: str | None
    converter: str
    converter_version: str | None
    page_count: int | None
    warnings: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class MarkdownConversion:
    """Result returned by :func:`convert_to_markdown`."""

    markdown: str | None
    status: ConversionStatus
    detected_type: str
    provenance: ConversionProvenance


_IMAGE_TYPES = frozenset({"bmp", "gif", "jpeg", "jpg", "png", "tif", "tiff", "webp"})
_MARKITDOWN_TYPES = frozenset({"doc", "docx", "html", "htm", "pdf", "ppt", "pptx", "rtf", "xlsx"})
_PLAIN_TEXT_TYPES = frozenset({"csv", "json", "md", "text", "txt", "xml"})
_MIME_TYPES = {
    "application/pdf": "pdf",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": "docx",
    "application/vnd.openxmlformats-officedocument.presentationml.presentation": "pptx",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": "xlsx",
    "image/jpeg": "jpeg",
    "image/png": "png",
    "text/plain": "txt",
    "text/markdown": "md",
}


def _package_version(package: str) -> str | None:
    try:
        return version(package)
    except PackageNotFoundError:
        return None


def _markitdown_factory() -> Callable[[], Any]:
    try:
        from markitdown import MarkItDown
    except ImportError as exc:
        raise RuntimeError("MarkItDown is unavailable; install qazstack[document-intake]") from exc
    return lambda: MarkItDown(enable_plugins=False)


def _docling_factory() -> Any:
    try:
        from docling.document_converter import DocumentConverter
    except ImportError as exc:
        raise RuntimeError("Docling is unavailable; install qazstack[document-intake-layout]") from exc
    return DocumentConverter()


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _normalise_type(path: Path, detected_type: str | None) -> str:
    candidate = (detected_type or path.suffix).strip().lower()
    if candidate in _MIME_TYPES:
        return _MIME_TYPES[candidate]
    if candidate.startswith("."):
        candidate = candidate[1:]
    if candidate.startswith("text/"):
        return candidate.split("/", 1)[1]
    return candidate or "unknown"


def _result(
    *,
    markdown: str | None,
    status: ConversionStatus,
    detected_type: str,
    source_sha256: str | None,
    converter: str,
    converter_version: str | None,
    page_count: int | None = None,
    warnings: tuple[str, ...] = (),
) -> MarkdownConversion:
    return MarkdownConversion(
        markdown=markdown,
        status=status,
        detected_type=detected_type,
        provenance=ConversionProvenance(
            source_sha256=source_sha256,
            converter=converter,
            converter_version=converter_version,
            page_count=page_count,
            warnings=warnings,
        ),
    )


def _convert_with_ocr(
    path: Path, detected_type: str, source_sha256: str, backend: Any, config: Any
) -> MarkdownConversion:
    from qazstack.ocr import extract_document

    try:
        document = extract_document(path, backend=backend, config=config)
    except Exception as exc:
        return _result(
            markdown=None,
            status=ConversionStatus.FAILED,
            detected_type=detected_type,
            source_sha256=source_sha256,
            converter="qazstack-ocr/tesseract",
            converter_version=None,
            warnings=(f"local OCR failed: {type(exc).__name__}",),
        )

    quality = document.quality()
    warnings = ["local OCR was required because text recovery was unavailable"]
    if quality.requires_review:
        warnings.append("OCR output needs review")
    engine_version = document.metadata.get("engine_version")
    return _result(
        markdown=document.to_markdown(),
        status=ConversionStatus.NEEDS_REVIEW if quality.requires_review else ConversionStatus.CONVERTED,
        detected_type=detected_type,
        source_sha256=source_sha256,
        converter=f"qazstack-ocr/{document.engine}",
        converter_version=str(engine_version) if engine_version is not None else None,
        page_count=len(document.pages),
        warnings=tuple(warnings),
    )


def convert_to_markdown(
    source: str | Path,
    detected_type: str | None = None,
    *,
    allow_layout_fallback: bool = False,
    ocr_backend: Any | None = None,
    ocr_config: Any | None = None,
) -> MarkdownConversion:
    """Convert one local attachment to Markdown without modifying the source.

    ``allow_layout_fallback`` is false by default. Set it only after the
    consumer's dependency gate has accepted the pinned local Docling runtime,
    its models, licences, and resource cost. The operation never downloads or
    accepts a remote model/service on the caller's behalf.
    """

    path = Path(source)
    kind = _normalise_type(path, detected_type)
    if not path.is_file():
        return _result(
            markdown=None,
            status=ConversionStatus.FAILED,
            detected_type=kind,
            source_sha256=None,
            converter="none",
            converter_version=None,
            warnings=("source does not exist or is not a file",),
        )

    source_sha256 = _sha256(path)
    if kind in _PLAIN_TEXT_TYPES:
        try:
            markdown = path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError) as exc:
            return _result(
                markdown=None,
                status=ConversionStatus.FAILED,
                detected_type=kind,
                source_sha256=source_sha256,
                converter="local-text",
                converter_version="python-stdlib",
                warnings=(f"local text read failed: {type(exc).__name__}",),
            )
        return _result(
            markdown=markdown,
            status=ConversionStatus.CONVERTED if markdown.strip() else ConversionStatus.NEEDS_REVIEW,
            detected_type=kind,
            source_sha256=source_sha256,
            converter="local-text",
            converter_version="python-stdlib",
            warnings=("source contains no readable text",) if not markdown.strip() else (),
        )

    if kind in _IMAGE_TYPES:
        return _convert_with_ocr(path, kind, source_sha256, ocr_backend, ocr_config)

    if kind not in _MARKITDOWN_TYPES:
        return _result(
            markdown=None,
            status=ConversionStatus.UNSUPPORTED,
            detected_type=kind,
            source_sha256=source_sha256,
            converter="none",
            converter_version=None,
            warnings=(f"unsupported document type: {kind}",),
        )

    try:
        converter = _markitdown_factory()()
        # MarkItDown's local converter accepts a path string across supported
        # versions; passing Path directly bypasses its normal stream handling.
        converted = converter.convert(str(path))
        markdown = str(getattr(converted, "text_content", "") or "").strip()
    except Exception as exc:
        return _result(
            markdown=None,
            status=ConversionStatus.FAILED,
            detected_type=kind,
            source_sha256=source_sha256,
            converter="markitdown",
            converter_version=_package_version("markitdown"),
            warnings=(f"MarkItDown conversion failed: {type(exc).__name__}",),
        )

    if kind == "pdf" and not markdown:
        return _convert_with_ocr(path, kind, source_sha256, ocr_backend, ocr_config)
    if not markdown:
        return _result(
            markdown=None,
            status=ConversionStatus.NEEDS_REVIEW,
            detected_type=kind,
            source_sha256=source_sha256,
            converter="markitdown",
            converter_version=_package_version("markitdown"),
            warnings=("MarkItDown returned no readable text",),
        )

    if allow_layout_fallback:
        try:
            layout_document = _docling_factory().convert(str(path)).document
            layout_markdown = str(layout_document.export_to_markdown() or "").strip()
        except Exception as exc:
            return _result(
                markdown=markdown,
                status=ConversionStatus.NEEDS_REVIEW,
                detected_type=kind,
                source_sha256=source_sha256,
                converter="markitdown",
                converter_version=_package_version("markitdown"),
                warnings=(f"approved layout fallback unavailable: {type(exc).__name__}",),
            )
        if layout_markdown:
            return _result(
                markdown=layout_markdown,
                status=ConversionStatus.CONVERTED,
                detected_type=kind,
                source_sha256=source_sha256,
                converter="docling",
                converter_version=_package_version("docling"),
                warnings=("explicit local layout fallback used",),
            )

    return _result(
        markdown=markdown,
        status=ConversionStatus.CONVERTED,
        detected_type=kind,
        source_sha256=source_sha256,
        converter="markitdown",
        converter_version=_package_version("markitdown"),
    )
