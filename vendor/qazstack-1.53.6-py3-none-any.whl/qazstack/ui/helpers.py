"""QazStack UI integration for FastAPI.

Single-call setup that registers templates, static files, and Jinja2 globals.

Usage:
    from qazstack.ui import setup_ui

    app = FastAPI()
    setup_ui(app, settings=settings, static_dir="static", templates_dir="templates")

After setup:
    - QazStack component templates are available in Jinja2 (e.g. "components/card.html")
    - QazStack static files served at /qs-static/
    - Jinja2 globals: qs_static(), year, settings, theme_script(), static()
    - Project templates_dir is searched FIRST, then qazstack.ui templates
"""

from __future__ import annotations

import hashlib
from datetime import datetime, timezone
from functools import lru_cache
from pathlib import Path
from typing import Any

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from jinja2 import ChoiceLoader, FileSystemLoader

# Paths to qazstack.ui bundled assets
_UI_DIR = Path(__file__).parent
_TEMPLATES_DIR = _UI_DIR / "templates"
_STATIC_DIR = _UI_DIR / "static"


@lru_cache(maxsize=256)
def _file_hash(filepath: Path) -> str:
    """MD5 hash of file content for cache busting."""
    if filepath.exists():
        return hashlib.md5(filepath.read_bytes()).hexdigest()[:8]
    return ""


def static_directory() -> Path:
    """Return the packaged QazStack UI asset directory.

    Consumers that mount QazStack assets themselves should use this public
    accessor instead of importing a module-private path constant.
    """

    return _STATIC_DIR


def static_url(path: str) -> str:
    """Generate a cache-busting URL for a QazStack UI static file.

    Returns: /qs-static/css/tokens.css?v=a1b2c3
    """
    path = str(path or "").lstrip("/")
    h = _file_hash(static_directory() / path)
    if h:
        return f"/qs-static/{path}?v={h}"
    return f"/qs-static/{path}"


# Compatibility aliases for consumers released before the public asset API.
# New integrations must import static_directory/static_url instead.
_qs_static = static_url


@lru_cache(maxsize=256)
def _project_static_hash(filepath: str, static_dir: str) -> str:
    """Generate cache-busting URL for a project static file."""
    full = Path(static_dir) / filepath
    if full.exists():
        h = hashlib.md5(full.read_bytes()).hexdigest()[:8]
        return f"/static/{filepath}?v={h}"
    return f"/static/{filepath}"


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _truncate_words(text: str, count: int = 30, end: str = "...") -> str:
    words = text.split()
    if len(words) <= count:
        return text
    return " ".join(words[:count]) + end


def _format_date(dt: datetime | str, fmt: str = "%d.%m.%Y") -> str:
    if isinstance(dt, str):
        try:
            dt = datetime.fromisoformat(dt)
        except (ValueError, TypeError):
            return str(dt)
    return dt.strftime(fmt)


def _nl2br(text: str) -> str:
    return text.replace("\n", "<br>\n")


def _format_number(value: int | float, separator: str = " ") -> str:
    """Format number with thousands separator: 1234 → 1 234."""
    if isinstance(value, float):
        parts = f"{value:,.2f}".split(".")
        return parts[0].replace(",", separator) + "." + parts[1]
    return f"{value:,}".replace(",", separator)


def _time_ago(dt: datetime | str) -> str:
    """Human-readable time ago: 5 минут назад, 2 часа назад."""
    if isinstance(dt, str):
        try:
            dt = datetime.fromisoformat(dt)
        except (ValueError, TypeError):
            return str(dt)
    now = datetime.now(timezone.utc)
    if dt.tzinfo is None:
        from datetime import timezone as _tz

        dt = dt.replace(tzinfo=_tz.utc)
    diff = now - dt
    seconds = int(diff.total_seconds())
    if seconds < 60:
        return "только что"
    minutes = seconds // 60
    if minutes < 60:
        if minutes % 10 == 1 and minutes != 11:
            return f"{minutes} минуту назад"
        elif minutes % 10 in (2, 3, 4) and minutes not in (12, 13, 14):
            return f"{minutes} минуты назад"
        return f"{minutes} минут назад"
    hours = minutes // 60
    if hours < 24:
        if hours % 10 == 1 and hours != 11:
            return f"{hours} час назад"
        elif hours % 10 in (2, 3, 4) and hours not in (12, 13, 14):
            return f"{hours} часа назад"
        return f"{hours} часов назад"
    days = hours // 24
    if days < 30:
        if days % 10 == 1 and days != 11:
            return f"{days} день назад"
        elif days % 10 in (2, 3, 4) and days not in (12, 13, 14):
            return f"{days} дня назад"
        return f"{days} дней назад"
    return dt.strftime("%d.%m.%Y")


def _pluralize(count: int, form1: str, form2: str, form5: str) -> str:
    """Russian pluralization: _pluralize(5, "статья", "статьи", "статей") → "5 статей"."""
    n = abs(count) % 100
    n1 = n % 10
    if 10 < n < 20:
        return f"{count} {form5}"
    if n1 == 1:
        return f"{count} {form1}"
    if 2 <= n1 <= 4:
        return f"{count} {form2}"
    return f"{count} {form5}"


def setup_ui(
    app: FastAPI,
    *,
    settings: Any = None,
    static_dir: str | Path = "static",
    templates_dir: str | Path = "templates",
    extra_globals: dict[str, Any] | None = None,
) -> Jinja2Templates:
    """Set up QazStack UI for a FastAPI application.

    1. Mounts qazstack.ui static files at /qs-static/
    2. Creates Jinja2Templates with dual loader (project + qazstack.ui)
    3. Registers all standard globals and filters
    4. Returns the configured Jinja2Templates instance

    Args:
        app: FastAPI application instance
        settings: Project settings object (accessible as {{ settings }} in templates)
        static_dir: Path to project's own static directory
        templates_dir: Path to project's own templates directory
        extra_globals: Additional Jinja2 globals to register

    Returns:
        Configured Jinja2Templates instance
    """
    static_dir = Path(static_dir)
    templates_dir = Path(templates_dir)

    # Mount qazstack.ui static files
    app.mount("/qs-static", StaticFiles(directory=str(static_directory())), name="qs-static")

    # Mount project static files (if not already mounted)
    if static_dir.exists():
        try:
            app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")
        except Exception:
            pass  # Already mounted

    # Create Jinja2 templates with dual loader
    # Project templates take priority (searched first)
    loaders = []
    if templates_dir.exists():
        loaders.append(FileSystemLoader(str(templates_dir)))
    loaders.append(FileSystemLoader(str(_TEMPLATES_DIR)))

    templates = Jinja2Templates(directory=str(templates_dir))
    templates.env.loader = ChoiceLoader(loaders)

    # Standard globals
    env = templates.env
    env.globals["qs_static"] = static_url
    env.globals["static"] = lambda path: _project_static_hash(path, str(static_dir))
    env.globals["now"] = _now
    env.globals["year"] = _now().year

    if settings:
        env.globals["settings"] = settings
        env.globals["site_name"] = getattr(settings, "app_name", "")

    # Theme support
    from qazstack.ui.theme import ThemeToggle

    env.globals.update(ThemeToggle.jinja_globals())

    # Extra globals
    if extra_globals:
        env.globals.update(extra_globals)

    # Filters
    env.filters["truncate_words"] = _truncate_words
    env.filters["format_date"] = _format_date
    env.filters["nl2br"] = _nl2br
    env.filters["format_number"] = _format_number
    env.filters["time_ago"] = _time_ago
    env.filters["pluralize"] = _pluralize

    return templates


__all__ = ["setup_ui", "static_directory", "static_url"]
