(function () {
  "use strict";

  var GA_ID = "G-9EF720PSER";
  var YM_ID = 109803011;
  var CLARITY_ID = "x5ualin2jv";

  function loadScript(src) {
    if (document.querySelector('script[src="' + src + '"]')) {
      return;
    }
    var script = document.createElement("script");
    script.async = true;
    script.src = src;
    document.head.appendChild(script);
  }

  window.dataLayer = window.dataLayer || [];
  window.gtag = window.gtag || function () {
    window.dataLayer.push(arguments);
  };
  window.gtag("js", new Date());
  window.gtag("config", GA_ID);
  loadScript("https://www.googletagmanager.com/gtag/js?id=" + encodeURIComponent(GA_ID));

  window.ym = window.ym || function () {
    (window.ym.a = window.ym.a || []).push(arguments);
  };
  window.ym.l = 1 * new Date();
  window.ym(YM_ID, "init", {
    ssr: true,
    webvisor: true,
    clickmap: true,
    ecommerce: "dataLayer",
    accurateTrackBounce: true,
    trackLinks: true
  });
  loadScript("https://mc.yandex.ru/metrika/tag.js?id=" + YM_ID);

  window.clarity = window.clarity || function () {
    (window.clarity.q = window.clarity.q || []).push(arguments);
  };
  loadScript("https://www.clarity.ms/tag/" + CLARITY_ID);
}());
