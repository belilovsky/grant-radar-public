"""Versioned access to packaged QazStack UI assets."""

from __future__ import annotations

from importlib import resources
from pathlib import Path, PurePosixPath

from qazstack import __version__

UI_ASSET_VERSION = f"qazstack-ui-{__version__}"


class UiAssetError(ValueError):
    """Raised when a UI asset path is unsafe or unavailable."""


def _safe_asset_path(relative_path: str) -> PurePosixPath:
    path = PurePosixPath(relative_path)
    if path.is_absolute() or ".." in path.parts or not path.parts:
        raise UiAssetError("UI asset path must be a safe relative path")
    return path


def read_ui_asset(relative_path: str) -> bytes:
    """Read a packaged QazStack UI asset by path relative to ``static/``."""
    path = _safe_asset_path(relative_path)
    resource = resources.files("qazstack.ui").joinpath("static", *path.parts)
    if not resource.is_file():
        raise UiAssetError(f"QazStack UI asset not found: {relative_path}")
    return resource.read_bytes()


def materialize_ui_asset(relative_path: str, destination: str | Path) -> Path:
    """Copy a packaged QazStack UI asset to a project-controlled location."""
    target = Path(destination)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(read_ui_asset(relative_path))
    return target


__all__ = ["UI_ASSET_VERSION", "UiAssetError", "materialize_ui_asset", "read_ui_asset"]
