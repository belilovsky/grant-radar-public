"""QazStack Video – client for Wan Studio video generation service.

Generate AI videos via Wan 2.2 on RunPod GPU through QazCompute gateway
or directly to Wan Studio.

Usage::

    from qazstack.video import VideoClient

    video = VideoClient()  # reads QAZCOMPUTE_URL from env
    result = await video.generate(prompt="Cinematic sunset over mountains")
    video_bytes = await video.generate_and_wait(prompt="A cat on windowsill")
"""

from .client import CircuitOpenError, VideoClient, VideoError
from .models import (
    GpuStatusResponse,
    VideoGenerateRequest,
    VideoGenerateResponse,
    VideoPreset,
    VideoStatusResponse,
)
from .presets import BUILTIN_PRESETS

__all__ = [
    "VideoClient",
    "VideoError",
    "CircuitOpenError",
    "VideoGenerateRequest",
    "VideoGenerateResponse",
    "VideoStatusResponse",
    "GpuStatusResponse",
    "VideoPreset",
    "BUILTIN_PRESETS",
]
