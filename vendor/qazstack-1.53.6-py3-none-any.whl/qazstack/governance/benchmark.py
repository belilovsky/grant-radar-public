"""Benchmark contracts for comparing QazStack with external platform patterns.

The module is intentionally descriptive and offline. It does not call external
services, scrape competitors or decide product strategy. It gives operators a
stable shape for recording what was compared, which evidence was checked and
which gaps should become governance actions.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Literal

from qazstack.governance.workflow import ActionItem, ScorecardResult

BENCHMARK_SCHEMA_VERSION = "qazstack-platform-benchmark-v1"
_IDENTIFIER_PATTERN = re.compile(r"^[a-z0-9][a-z0-9._-]*$")
_STATUSES = {"implemented", "partial", "missing", "not-applicable"}
_PRIORITIES = {"critical", "high", "medium", "low"}

BenchmarkStatus = Literal["implemented", "partial", "missing", "not-applicable"]
BenchmarkPriority = Literal["critical", "high", "medium", "low"]


def _require_identifier(value: str, field_name: str) -> str:
    cleaned = value.strip()
    if not _IDENTIFIER_PATTERN.fullmatch(cleaned):
        raise ValueError(f"{field_name} must be a lowercase identifier")
    return cleaned


def _require_text(value: str, field_name: str) -> str:
    cleaned = value.strip()
    if not cleaned:
        raise ValueError(f"{field_name} must not be blank")
    return cleaned


def _unique_text(values: tuple[str, ...], field_name: str) -> tuple[str, ...]:
    cleaned = tuple(_require_text(value, field_name) for value in values)
    if len(set(cleaned)) != len(cleaned):
        raise ValueError(f"{field_name} must not contain duplicates")
    return cleaned


@dataclass(frozen=True, slots=True)
class BenchmarkReference:
    """One external benchmark source or analogue."""

    ref_id: str
    title: str
    url: str
    scope: str

    def __post_init__(self) -> None:
        object.__setattr__(self, "ref_id", _require_identifier(self.ref_id, "ref_id"))
        for field_name in ("title", "url", "scope"):
            object.__setattr__(self, field_name, _require_text(getattr(self, field_name), field_name))

    def as_dict(self) -> dict[str, str]:
        return {
            "id": self.ref_id,
            "title": self.title,
            "url": self.url,
            "scope": self.scope,
        }


@dataclass(frozen=True, slots=True)
class BenchmarkCapability:
    """A capability expected from a mature platform/control-plane toolkit."""

    capability_id: str
    title: str
    category: str
    description: str
    analog_refs: tuple[str, ...]
    priority: BenchmarkPriority = "medium"

    def __post_init__(self) -> None:
        object.__setattr__(self, "capability_id", _require_identifier(self.capability_id, "capability_id"))
        for field_name in ("title", "category", "description"):
            object.__setattr__(self, field_name, _require_text(getattr(self, field_name), field_name))
        object.__setattr__(self, "analog_refs", _unique_text(self.analog_refs, "analog_refs"))
        if self.priority not in _PRIORITIES:
            raise ValueError(f"unsupported benchmark priority: {self.priority}")

    def as_dict(self) -> dict[str, Any]:
        return {
            "id": self.capability_id,
            "title": self.title,
            "category": self.category,
            "description": self.description,
            "analog_refs": list(self.analog_refs),
            "priority": self.priority,
        }


@dataclass(frozen=True, slots=True)
class BenchmarkEvidence:
    """QazStack status for one benchmark capability."""

    capability_id: str
    status: BenchmarkStatus
    summary: str
    evidence_refs: tuple[str, ...]
    next_step: str | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "capability_id", _require_identifier(self.capability_id, "capability_id"))
        if self.status not in _STATUSES:
            raise ValueError(f"unsupported benchmark status: {self.status}")
        object.__setattr__(self, "summary", _require_text(self.summary, "summary"))
        object.__setattr__(self, "evidence_refs", _unique_text(self.evidence_refs, "evidence_refs"))
        if self.next_step is not None:
            object.__setattr__(self, "next_step", _require_text(self.next_step, "next_step"))

    @property
    def needs_action(self) -> bool:
        return self.status in {"partial", "missing"}

    def as_dict(self) -> dict[str, Any]:
        return {
            "capability_id": self.capability_id,
            "status": self.status,
            "summary": self.summary,
            "evidence_refs": list(self.evidence_refs),
            "next_step": self.next_step,
        }


@dataclass(frozen=True, slots=True)
class BenchmarkAssessment:
    """Deterministic benchmark snapshot for one platform surface."""

    subject_id: str
    references: tuple[BenchmarkReference, ...]
    capabilities: tuple[BenchmarkCapability, ...]
    evidence: tuple[BenchmarkEvidence, ...]
    schema_version: str = BENCHMARK_SCHEMA_VERSION
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        object.__setattr__(self, "subject_id", _require_identifier(self.subject_id, "subject_id"))
        if self.schema_version != BENCHMARK_SCHEMA_VERSION:
            raise ValueError(f"schema_version must be {BENCHMARK_SCHEMA_VERSION}")
        reference_ids = [item.ref_id for item in self.references]
        capability_ids = [item.capability_id for item in self.capabilities]
        evidence_ids = [item.capability_id for item in self.evidence]
        if len(set(reference_ids)) != len(reference_ids):
            raise ValueError("reference identifiers must be unique")
        if len(set(capability_ids)) != len(capability_ids):
            raise ValueError("capability identifiers must be unique")
        if len(set(evidence_ids)) != len(evidence_ids):
            raise ValueError("evidence capability_ids must be unique")

        known_refs = set(reference_ids)
        for capability in self.capabilities:
            missing_refs = [ref for ref in capability.analog_refs if ref not in known_refs]
            if missing_refs:
                raise ValueError(f"capability analog_refs are unknown: {', '.join(missing_refs)}")

        known_capabilities = set(capability_ids)
        missing_evidence = sorted(known_capabilities - set(evidence_ids))
        unknown_evidence = sorted(set(evidence_ids) - known_capabilities)
        if missing_evidence:
            raise ValueError(f"capabilities missing evidence: {', '.join(missing_evidence)}")
        if unknown_evidence:
            raise ValueError(f"evidence references unknown capabilities: {', '.join(unknown_evidence)}")

    @property
    def summary(self) -> dict[str, Any]:
        scored = [item for item in self.evidence if item.status != "not-applicable"]
        score = 0.0
        for item in scored:
            if item.status == "implemented":
                score += 1.0
            elif item.status == "partial":
                score += 0.5
        max_score = float(len(scored))
        coverage = round((score / max_score) * 100, 1) if max_score else 100.0
        return {
            "capabilities": len(self.capabilities),
            "references": len(self.references),
            "coverage_score": coverage,
            "statuses": {status: sum(item.status == status for item in self.evidence) for status in sorted(_STATUSES)},
            "actions": sum(item.needs_action for item in self.evidence),
        }

    def scorecards(self) -> tuple[ScorecardResult, ...]:
        capability_by_id = {item.capability_id: item for item in self.capabilities}
        status_map = {
            "implemented": "pass",
            "partial": "warning",
            "missing": "failure",
            "not-applicable": "unknown",
        }
        return tuple(
            ScorecardResult(
                check_id=f"benchmark.{item.capability_id}",
                title=capability_by_id[item.capability_id].title,
                status=status_map[item.status],  # type: ignore[arg-type]
                summary=item.summary,
                evidence_refs=item.evidence_refs,
                owner="qazstack",
            )
            for item in sorted(self.evidence, key=lambda evidence: evidence.capability_id)
        )

    def actions(self) -> tuple[ActionItem, ...]:
        capability_by_id = {item.capability_id: item for item in self.capabilities}
        actions: list[ActionItem] = []
        for item in sorted(self.evidence, key=lambda evidence: evidence.capability_id):
            if not item.needs_action:
                continue
            capability = capability_by_id[item.capability_id]
            title = item.next_step or f"Improve benchmark capability: {capability.title}"
            actions.append(
                ActionItem(
                    action_id=f"benchmark.{item.capability_id}",
                    title=title,
                    priority=capability.priority,
                    source_check_id=f"benchmark.{item.capability_id}",
                    owner="qazstack",
                    evidence_refs=item.evidence_refs,
                )
            )
        return tuple(actions)

    def as_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "subject_id": self.subject_id,
            "summary": self.summary,
            "references": [item.as_dict() for item in sorted(self.references, key=lambda ref: ref.ref_id)],
            "capabilities": [
                item.as_dict() for item in sorted(self.capabilities, key=lambda capability: capability.capability_id)
            ],
            "evidence": [item.as_dict() for item in sorted(self.evidence, key=lambda item: item.capability_id)],
            "metadata": dict(sorted(self.metadata.items())),
        }
