"""Conservative cross-project duplicate and reuse coverage scanner."""

from __future__ import annotations

import ast
import hashlib
import json
import re
import subprocess
import urllib.parse
from collections import Counter
from dataclasses import dataclass
from itertools import chain, combinations
from pathlib import Path
from typing import Any, Iterable, Mapping

from qazstack import __version__
from qazstack.governance.portfolio_inventory import (
    NOT_APPLICABLE_PRODUCTS,
    PROVIDER_PRODUCTS,
    SUPPORTING_CONTRACT_ROOTS,
    load_portfolio_projects,
)
from qazstack.governance.reuse import (
    DEFAULT_REUSE_FILENAME,
    ReuseManifestError,
    check_project_reuse,
    load_reuse_manifest,
)

SOURCE_SUFFIXES = frozenset({".py", ".js", ".jsx", ".ts", ".tsx"})
SKIP_PARTS = frozenset(
    {
        ".git",
        ".venv",
        "venv",
        "node_modules",
        "dist",
        "build",
        "vendor",
        "tests",
        "test",
        "__pycache__",
        "migrations",
    }
)
MIN_PYTHON_STATEMENTS = 4
MIN_SOURCE_LINES = 8
CLASSIFICATION_SCHEMA_VERSION = "qazstack-reuse-classification-baseline-v1"
REGRESSION_BASELINE_SCHEMA_VERSION = "qazstack-portfolio-reuse-regression-baseline-v2"
CLASSIFICATION_KINDS = frozenset({"exact", "structural"})
REPOSITORY_SCOPES = frozenset({"cross-repository", "mixed-repository", "same-repository", "unknown-repository"})
REGRESSION_DIGEST_LIMIT = 20
REGRESSION_MARKDOWN_LIMIT = 100
SCANNER_SEMANTICS_VERSION = "qazstack-reuse-scan-semantics-v2"
VERSION_DRIFT_WARNING_PREFIX = "manifest targets QazStack "


@dataclass(frozen=True, slots=True)
class CodeUnit:
    project: str
    checkout: str
    path: str
    symbol: str
    language: str
    start_line: int
    end_line: int
    fingerprint: str
    structural_fingerprint: str

    def location(self) -> dict[str, Any]:
        return {
            "project": self.project,
            "checkout": self.checkout,
            "path": self.path,
            "symbol": self.symbol,
            "language": self.language,
            "start_line": self.start_line,
            "end_line": self.end_line,
        }


def _tracked_source_files(root: Path) -> list[Path]:
    try:
        result = subprocess.run(
            ["git", "-C", str(root), "ls-files", "-z"],
            check=True,
            capture_output=True,
        )
        names = result.stdout.decode("utf-8", errors="replace").split("\0")
    except (OSError, subprocess.CalledProcessError) as exc:
        raise ReuseManifestError(f"cannot enumerate tracked source files in {root}") from exc
    files = []
    for name in names:
        if not name:
            continue
        relative = Path(name)
        if relative.suffix.lower() not in SOURCE_SUFFIXES or any(part in SKIP_PARTS for part in relative.parts):
            continue
        candidate = root / relative
        if candidate.is_file() and candidate.stat().st_size <= 1_000_000:
            files.append(candidate)
    return sorted(files)


def _git_value(root: Path, *args: str) -> str | None:
    try:
        result = subprocess.run(
            ["git", "-C", str(root), *args],
            check=True,
            capture_output=True,
            text=True,
        )
    except (OSError, subprocess.CalledProcessError):
        return None
    return result.stdout.strip() or None


def _source_snapshot(
    root: Path,
    files: Iterable[Path],
    *,
    contents: Mapping[Path, bytes] | None = None,
) -> dict[str, Any]:
    """Return the exact local source identity consumed by the scanner."""
    digest = hashlib.sha256()
    for path in files:
        relative = str(path.relative_to(root))
        digest.update(relative.encode("utf-8"))
        digest.update(b"\0")
        digest.update(contents[path] if contents is not None else path.read_bytes())
        digest.update(b"\0")
    status = _git_value(root, "status", "--porcelain=v1", "--untracked-files=all") or ""
    return {
        "source_revision": _git_value(root, "rev-parse", "HEAD"),
        "source_branch": _git_value(root, "symbolic-ref", "--short", "HEAD"),
        "source_dirty": bool(status),
        "dirty_file_count": len(status.splitlines()) if status else 0,
        "source_digest_sha256": digest.hexdigest(),
    }


def _checker_snapshot() -> dict[str, Any]:
    scanner_path = Path(__file__).resolve()
    source_root = scanner_path.parents[3]
    package_root = scanner_path.parents[1]
    if (source_root / "src/qazstack/__init__.py").is_file():
        checker_root = source_root
        source_kind = "source-checkout"
        implementation_files = [
            scanner_path,
            checker_root / "src/qazstack/__init__.py",
            checker_root / "src/qazstack/cli/main.py",
            checker_root / "src/qazstack/governance/reuse.py",
            checker_root / "src/qazstack/contracts/consumer.py",
            checker_root / "src/qazstack/contracts/_validation.py",
            checker_root / "src/qazstack/governance/portfolio_inventory.py",
        ]
    else:
        checker_root = package_root
        source_kind = "installed-package"
        implementation_files = [
            scanner_path,
            checker_root / "__init__.py",
            checker_root / "cli/main.py",
            checker_root / "governance/reuse.py",
            checker_root / "contracts/consumer.py",
            checker_root / "contracts/_validation.py",
            checker_root / "governance/portfolio_inventory.py",
        ]
    return {
        "qazstack_version": __version__,
        "source_kind": source_kind,
        "checkout": str(checker_root),
        "implementation_files": [str(path.relative_to(checker_root)) for path in implementation_files],
        **_source_snapshot(checker_root, implementation_files),
    }


def _scan_units_consistently(project: str, root: Path, files: list[Path]) -> tuple[list[CodeUnit], dict[str, Any]]:
    """Parse exactly one stable tracked-source snapshot or fail closed."""
    contents = {path: path.read_bytes() for path in files}
    before = _source_snapshot(root, files, contents=contents)
    units: list[CodeUnit] = []
    for path in files:
        if path.suffix == ".py":
            units.extend(_python_units(project, root, path, source_bytes=contents[path]))
        else:
            units.extend(_javascript_units(project, root, path, source_bytes=contents[path]))
    after_files = _tracked_source_files(root)
    after = _source_snapshot(root, after_files)
    stable_keys = ("source_revision", "source_digest_sha256")
    if any(before.get(key) != after.get(key) for key in stable_keys):
        raise ReuseManifestError(f"tracked source changed while scanning {root}; rerun from a stable checkout")
    return units, after


def _adoption_evidence_view(check: Mapping[str, Any]) -> dict[str, Any]:
    warnings = [str(item) for item in check.get("warnings", [])]
    version_warnings = [item for item in warnings if item.startswith(VERSION_DRIFT_WARNING_PREFIX)]
    evidence_warnings = [item for item in warnings if not item.startswith(VERSION_DRIFT_WARNING_PREFIX)]
    errors = [str(item) for item in check.get("errors", [])]
    evidence_status = "error" if errors else ("warning" if evidence_warnings else "ok")
    return {
        **check,
        "evidence_status": evidence_status,
        "evidence_warnings": evidence_warnings,
        "version_status": "drift" if version_warnings else "current",
        "version_warnings": version_warnings,
    }


def _python_units(
    project: str,
    root: Path,
    path: Path,
    *,
    source_bytes: bytes | None = None,
) -> list[CodeUnit]:
    try:
        source = (source_bytes if source_bytes is not None else path.read_bytes()).decode("utf-8")
        tree = ast.parse(source)
    except (OSError, UnicodeDecodeError, SyntaxError):
        return []
    units: list[CodeUnit] = []
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        end = getattr(node, "end_lineno", node.lineno)
        if end - node.lineno + 1 < MIN_SOURCE_LINES or len(node.body) < MIN_PYTHON_STATEMENTS:
            continue
        exact_node = ast.parse(ast.unparse(node)).body[0]
        exact_node.name = "__symbol__"
        exact = ast.dump(exact_node, include_attributes=False)
        structural_node = ast.parse(ast.unparse(exact_node)).body[0]
        for descendant in ast.walk(structural_node):
            if isinstance(descendant, ast.Name):
                descendant.id = "<name>"
            elif isinstance(descendant, ast.arg):
                descendant.arg = "<arg>"
            elif isinstance(descendant, ast.Attribute):
                descendant.attr = "<attr>"
            elif isinstance(descendant, ast.Constant):
                descendant.value = f"<{type(descendant.value).__name__}>"
        structural = ast.dump(structural_node, include_attributes=False)
        units.append(
            CodeUnit(
                project=project,
                checkout=str(root),
                path=str(path.relative_to(root)),
                symbol=node.name,
                language="python",
                start_line=node.lineno,
                end_line=end,
                fingerprint=hashlib.sha256(exact.encode()).hexdigest(),
                structural_fingerprint=hashlib.sha256(structural.encode()).hexdigest(),
            )
        )
    return units


JS_FUNCTION_RE = re.compile(
    r"(?P<header>(?:export\s+)?(?:async\s+)?function\s+(?P<name>[A-Za-z_$][\w$]*)\s*\([^)]*\)\s*\{)",
    flags=re.MULTILINE,
)


def _matching_brace(source: str, start: int) -> int | None:
    depth = 0
    quote: str | None = None
    escaped = False
    for index in range(start, len(source)):
        char = source[index]
        if quote:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == quote:
                quote = None
            continue
        if char in {"'", '"', "`"}:
            quote = char
        elif char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                return index
    return None


def _javascript_units(
    project: str,
    root: Path,
    path: Path,
    *,
    source_bytes: bytes | None = None,
) -> list[CodeUnit]:
    try:
        source = (source_bytes if source_bytes is not None else path.read_bytes()).decode("utf-8")
    except (OSError, UnicodeDecodeError):
        return []
    units: list[CodeUnit] = []
    for match in JS_FUNCTION_RE.finditer(source):
        brace = source.find("{", match.start("header"), match.end("header"))
        end = _matching_brace(source, brace)
        if end is None:
            continue
        body = source[match.start() : end + 1]
        start_line = source.count("\n", 0, match.start()) + 1
        end_line = source.count("\n", 0, end) + 1
        if end_line - start_line + 1 < MIN_SOURCE_LINES:
            continue
        normalized = re.sub(r"//[^\n]*|/\*.*?\*/", "", body, flags=re.DOTALL)
        normalized = re.sub(r"(['\"`])(?:\\.|(?!\1).)*\1", "<string>", normalized, flags=re.DOTALL)
        normalized = re.sub(r"\b\d+(?:\.\d+)?\b", "<number>", normalized)
        normalized = re.sub(r"\s+", "", normalized)
        structural = re.sub(r"\b[A-Za-z_$][\w$]*\b", "<name>", normalized)
        units.append(
            CodeUnit(
                project=project,
                checkout=str(root),
                path=str(path.relative_to(root)),
                symbol=match.group("name"),
                language=path.suffix.lower().lstrip("."),
                start_line=start_line,
                end_line=end_line,
                fingerprint=hashlib.sha256(normalized.encode()).hexdigest(),
                structural_fingerprint=hashlib.sha256(structural.encode()).hexdigest(),
            )
        )
    return units


def _clusters(units: Iterable[CodeUnit], attribute: str) -> list[dict[str, Any]]:
    grouped: dict[str, list[CodeUnit]] = {}
    for unit in units:
        grouped.setdefault(getattr(unit, attribute), []).append(unit)
    clusters = []
    for fingerprint, members in grouped.items():
        projects = sorted({member.project for member in members})
        checkouts = {member.checkout for member in members}
        if len(projects) < 2 or len(checkouts) < 2:
            continue
        locations = sorted(
            (member.location() for member in members),
            key=lambda item: (item["project"], item["path"], item["start_line"]),
        )
        cluster_id = hashlib.sha256(
            json.dumps(
                [(item["project"], item["path"], item["symbol"]) for item in locations],
                separators=(",", ":"),
            ).encode()
        ).hexdigest()[:16]
        clusters.append(
            {
                "cluster_id": cluster_id,
                "fingerprint": fingerprint,
                "projects": projects,
                "category": _cluster_category(locations),
                "locations": locations,
            }
        )
    return sorted(clusters, key=lambda cluster: (-len(cluster["projects"]), cluster["cluster_id"]))


def _cluster_category(locations: Iterable[Mapping[str, Any]]) -> str:
    paths = " ".join(str(location["path"]).lower() for location in locations)
    if any(marker in paths for marker in ("components/ui/", "ui-kit/", "av-ds/", "avds/")):
        return "shared-ui-copy"
    if any(
        marker in paths
        for marker in ("vite.", "logger.", "route-helpers.", "script/build", "scripts/build", "selftest.")
    ):
        return "scaffold-or-tooling"
    if any(marker in paths for marker in ("collector", "pipeline", "ingest", "etl", "scraper")):
        return "data-pipeline"
    return "application-code"


def _resolve_checkout(product: str, indexed: Path | None, overrides: Mapping[str, str | Path]) -> Path | None:
    if product in overrides:
        return Path(overrides[product]).expanduser().resolve()
    if indexed and indexed.is_dir():
        return indexed.resolve()
    for candidate in SUPPORTING_CONTRACT_ROOTS.get(product, ()):
        if candidate.is_dir():
            return candidate.resolve()
    return indexed.resolve() if indexed else None


def _normalize_repository_identity(remote_url: str) -> str | None:
    """Return a credential-free repository identity for common Git URL forms."""
    raw = remote_url.strip()
    if not raw:
        return None

    scp_match = None
    if "://" not in raw and not raw.startswith(("/", "./", "../")):
        scp_match = re.fullmatch(r"(?:[^@/]+@)?(?P<host>[^:/]+):(?P<path>.+)", raw)
    if scp_match:
        host = scp_match.group("host").lower()
        repository_path = scp_match.group("path")
    else:
        parsed = urllib.parse.urlsplit(raw)
        if parsed.hostname:
            host = parsed.hostname.lower()
            try:
                port = parsed.port
            except ValueError:
                return None
            if port:
                host = f"{host}:{port}"
            repository_path = parsed.path
        else:
            local_path = raw.removeprefix("file://")
            try:
                return f"local:{Path(local_path).expanduser().resolve()}"
            except OSError:
                return f"local:{local_path}"

    repository_path = urllib.parse.unquote(repository_path).strip("/")
    if repository_path.endswith(".git"):
        repository_path = repository_path[:-4]
    if not repository_path:
        return None
    return f"{host}/{repository_path}"


def _repository_identity(root: Path) -> str | None:
    """Read the local origin URL without contacting the remote."""
    try:
        result = subprocess.run(
            ["git", "-C", str(root), "remote", "get-url", "origin"],
            check=True,
            capture_output=True,
            text=True,
        )
    except (OSError, subprocess.CalledProcessError):
        return None
    return _normalize_repository_identity(result.stdout)


def _annotate_repository_scope(
    clusters: Iterable[Mapping[str, Any]],
    repository_by_checkout: Mapping[str, str | None],
) -> list[dict[str, Any]]:
    """Describe repository ownership without hiding shared-remote clusters."""
    annotated: list[dict[str, Any]] = []
    for cluster in clusters:
        checkout_ids = {
            str(location.get("checkout", "")): repository_by_checkout.get(str(location.get("checkout", "")))
            for location in cluster.get("locations", [])
            if location.get("checkout")
        }
        repository_ids = list(checkout_ids.values())
        known_ids = sorted({identity for identity in repository_ids if identity})
        if not checkout_ids or not all(repository_ids):
            scope = "unknown-repository"
        elif len(known_ids) == 1:
            scope = "same-repository"
        elif len(known_ids) < len(checkout_ids):
            scope = "mixed-repository"
        else:
            scope = "cross-repository"
        annotated.append(
            {
                **cluster,
                "repository_scope": scope,
                "repository_ids": known_ids,
            }
        )
    return annotated


def _qazstack_provider_modules(cluster: Mapping[str, Any]) -> set[str]:
    """Infer top-level QazStack modules represented by provider locations."""
    modules: set[str] = set()
    marker = ("src", "qazstack")
    for location in cluster.get("locations", []):
        if location.get("project") != "QazStack":
            continue
        parts = Path(str(location.get("path", ""))).parts
        try:
            index = next(position for position in range(len(parts) - 1) if parts[position : position + 2] == marker)
        except StopIteration:
            continue
        if index + 2 < len(parts):
            modules.add(parts[index + 2].removesuffix(".py"))
    return modules


def _adoption_covers_location(
    manifest: Mapping[str, Any] | None,
    path: str,
    provider_modules: set[str],
) -> bool:
    if not manifest or not provider_modules:
        return False
    for adoption in manifest.get("adoptions", []):
        if not isinstance(adoption, Mapping) or adoption.get("module") not in provider_modules:
            continue
        evidence = adoption.get("evidence", [])
        if isinstance(evidence, list) and path in evidence:
            return True
    return False


def _is_declared_qazstack_reuse(cluster: Mapping[str, Any], manifests: Mapping[str, Mapping[str, Any]]) -> bool:
    """Return true when every consumer match cites the matching provider module."""
    if "QazStack" not in cluster.get("projects", []):
        return False
    consumer_locations = [
        location for location in cluster.get("locations", []) if location.get("project") != "QazStack"
    ]
    if not consumer_locations:
        return False
    provider_modules = _qazstack_provider_modules(cluster)
    for location in consumer_locations:
        checkout = str(location.get("checkout", ""))
        if not _adoption_covers_location(
            manifests.get(checkout),
            str(location.get("path", "")),
            provider_modules,
        ):
            return False
    return True


def _cluster_classification_key(cluster: Mapping[str, Any], *, kind: str = "exact") -> tuple[str, str, tuple[str, ...]]:
    if kind not in CLASSIFICATION_KINDS:
        raise ReuseManifestError(f"classification kind must be one of: {', '.join(sorted(CLASSIFICATION_KINDS))}")
    fingerprint = str(cluster.get("fingerprint", ""))
    projects = tuple(sorted(str(project) for project in cluster.get("projects", [])))
    return kind, fingerprint, projects


def _declared_qazstack_reuse_keys(payload: Mapping[str, Any]) -> set[tuple[str, str, tuple[str, ...]]]:
    """Return consumer-side exact-cluster keys already covered by QazStack reuse evidence."""
    keys: set[tuple[str, str, tuple[str, ...]]] = set()
    for cluster in payload.get("verified_declared_qazstack_reuse_matches", []):
        fingerprint = str(cluster.get("fingerprint", ""))
        projects = sorted(str(project) for project in cluster.get("projects", []) if project != "QazStack")
        if fingerprint and len(projects) >= 2:
            keys.add(("exact", fingerprint, tuple(projects)))
    return keys


def _load_classification_records(baseline: Mapping[str, Any]) -> list[dict[str, Any]]:
    if baseline.get("schema_version") != CLASSIFICATION_SCHEMA_VERSION:
        raise ReuseManifestError(f"classification baseline schema_version must be {CLASSIFICATION_SCHEMA_VERSION}")
    records: list[dict[str, Any]] = []
    for index, item in enumerate(baseline.get("classifications", [])):
        if not isinstance(item, Mapping):
            raise ReuseManifestError(f"classifications[{index}] must be an object")
        kind = item.get("kind", "exact")
        fingerprint = item.get("fingerprint")
        projects = item.get("projects")
        classification = item.get("classification")
        owner = item.get("owner")
        reason = item.get("reason")
        if not isinstance(kind, str) or kind not in CLASSIFICATION_KINDS:
            raise ReuseManifestError(
                f"classifications[{index}].kind must be one of: {', '.join(sorted(CLASSIFICATION_KINDS))}"
            )
        if not isinstance(fingerprint, str) or not fingerprint:
            raise ReuseManifestError(f"classifications[{index}].fingerprint must be a non-empty string")
        if (
            not isinstance(projects, list)
            or len(projects) < 2
            or any(not isinstance(project, str) for project in projects)
        ):
            raise ReuseManifestError(f"classifications[{index}].projects must contain at least two project names")
        if not isinstance(classification, str) or not classification:
            raise ReuseManifestError(f"classifications[{index}].classification must be a non-empty string")
        if not isinstance(owner, str) or not owner:
            raise ReuseManifestError(f"classifications[{index}].owner must be a non-empty string")
        if not isinstance(reason, str) or not reason:
            raise ReuseManifestError(f"classifications[{index}].reason must be a non-empty string")
        records.append(
            {
                **item,
                "kind": kind,
                "fingerprint": fingerprint,
                "projects": sorted(projects),
            }
        )
    return records


def _classification_keys(records: Iterable[Mapping[str, Any]]) -> set[tuple[str, str, tuple[str, ...]]]:
    return {
        (
            str(record["kind"]),
            str(record["fingerprint"]),
            tuple(str(project) for project in record["projects"]),
        )
        for record in records
    }


def _classification_fingerprint_index(
    records: Iterable[Mapping[str, Any]],
) -> dict[tuple[str, str], list[Mapping[str, Any]]]:
    indexed: dict[tuple[str, str], list[Mapping[str, Any]]] = {}
    for record in records:
        key = (str(record["kind"]), str(record["fingerprint"]))
        indexed.setdefault(key, []).append(record)
    return indexed


def _baseline_project_set_drift(
    cluster: Mapping[str, Any],
    records: Iterable[Mapping[str, Any]],
    *,
    kind: str,
) -> dict[str, Any]:
    """Attach the closest prior project set without silently classifying the drift."""
    current_projects = set(str(project) for project in cluster.get("projects", []))
    matches = list(records)
    closest = min(
        matches,
        key=lambda item: (
            len(current_projects.symmetric_difference(set(str(project) for project in item["projects"]))),
            tuple(str(project) for project in item["projects"]),
        ),
    )
    baseline_projects = set(str(project) for project in closest["projects"])
    return {
        "cluster_id": _classification_cluster_id(cluster, kind=kind),
        "projects": sorted(current_projects),
        "repository_scope": cluster.get("repository_scope", "unknown-repository"),
        "baseline_projects": sorted(baseline_projects),
        "project_members_added": sorted(current_projects - baseline_projects),
        "project_members_removed": sorted(baseline_projects - current_projects),
        "baseline_classification": closest.get("classification"),
        "baseline_owner": closest.get("owner"),
    }


def _classification_cluster_id(cluster: Mapping[str, Any], *, kind: str) -> str:
    existing = cluster.get("cluster_id")
    if isinstance(existing, str) and existing:
        return existing
    identity = json.dumps(
        {
            "kind": kind,
            "fingerprint": cluster.get("fingerprint"),
            "projects": sorted(str(project) for project in cluster.get("projects", [])),
        },
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    )
    return hashlib.sha256(identity.encode("utf-8")).hexdigest()[:16]


def _repository_scope_counts(clusters: Iterable[Mapping[str, Any]]) -> dict[str, int]:
    counts = Counter(str(cluster.get("repository_scope", "unknown")) for cluster in clusters)
    return {
        "cross": counts["cross-repository"],
        "mixed": counts["mixed-repository"],
        "same": counts["same-repository"],
        "unknown": counts["unknown-repository"]
        + sum(amount for scope, amount in counts.items() if scope not in REPOSITORY_SCOPES),
    }


def classify_reuse_scan(
    payload: Mapping[str, Any],
    classification_baseline: Mapping[str, Any],
) -> dict[str, Any]:
    """Split duplicate and structural clusters into reviewed and unclassified buckets."""
    classification_records = _load_classification_records(classification_baseline)
    classified_keys = _classification_keys(classification_records)
    fingerprint_index = _classification_fingerprint_index(classification_records)
    declared_qazstack_keys = _declared_qazstack_reuse_keys(payload)
    classified_exact = []
    declared_qazstack_reuse = []
    unclassified_exact = []
    baseline_drift_exact = []
    new_unclassified_exact = []
    for cluster in payload.get("exact_duplicate_clusters", []):
        key = _cluster_classification_key(cluster, kind="exact")
        if key in classified_keys:
            classified_exact.append(cluster)
        elif key in declared_qazstack_keys:
            declared_qazstack_reuse.append(cluster)
        else:
            unclassified_exact.append(cluster)
            prior_records = fingerprint_index.get(("exact", str(cluster.get("fingerprint", ""))), [])
            if prior_records:
                baseline_drift_exact.append(_baseline_project_set_drift(cluster, prior_records, kind="exact"))
            else:
                new_unclassified_exact.append(cluster)
    classified_structural = []
    unclassified_structural = []
    baseline_drift_structural = []
    new_unclassified_structural = []
    for cluster in payload.get("structural_candidate_clusters", []):
        key = _cluster_classification_key(cluster, kind="structural")
        if key in classified_keys:
            classified_structural.append(cluster)
        else:
            unclassified_structural.append(cluster)
            prior_records = fingerprint_index.get(("structural", str(cluster.get("fingerprint", ""))), [])
            if prior_records:
                baseline_drift_structural.append(_baseline_project_set_drift(cluster, prior_records, kind="structural"))
            else:
                new_unclassified_structural.append(cluster)
    classified_exact_count = len(classified_exact) + len(declared_qazstack_reuse)
    classified_structural_count = len(classified_structural)
    unclassified_exact_scope = _repository_scope_counts(unclassified_exact)
    actionable_unclassified_exact = [
        cluster
        for cluster in unclassified_exact
        if cluster.get("repository_scope") in {"cross-repository", "mixed-repository"}
    ]
    drift_exact_scope = _repository_scope_counts(baseline_drift_exact)
    new_exact_scope = _repository_scope_counts(new_unclassified_exact)
    drift_structural_scope = _repository_scope_counts(baseline_drift_structural)
    new_structural_scope = _repository_scope_counts(new_unclassified_structural)
    return {
        "schema_version": "qazstack-reuse-classification-result-v2",
        "baseline_reviewed_at": classification_baseline.get("reviewed_at"),
        "baseline_owner": classification_baseline.get("owner"),
        "baseline_classified_exact_duplicate_clusters": len(classified_exact),
        "baseline_classified_structural_candidate_clusters": classified_structural_count,
        "declared_qazstack_reuse_exact_clusters": len(declared_qazstack_reuse),
        "classified_exact_duplicate_clusters": classified_exact_count,
        "unclassified_exact_duplicate_clusters": len(unclassified_exact),
        "unclassified_cross_repository_exact_clusters": unclassified_exact_scope["cross"],
        "unclassified_mixed_repository_exact_clusters": unclassified_exact_scope["mixed"],
        "unclassified_same_repository_exact_clusters": unclassified_exact_scope["same"],
        "unclassified_unknown_repository_exact_clusters": unclassified_exact_scope["unknown"],
        "actionable_unclassified_exact_clusters": len(actionable_unclassified_exact),
        "baseline_drift_exact_duplicate_clusters": len(baseline_drift_exact),
        "new_unclassified_exact_duplicate_clusters": len(new_unclassified_exact),
        "baseline_drift_cross_repository_exact_clusters": drift_exact_scope["cross"],
        "baseline_drift_mixed_repository_exact_clusters": drift_exact_scope["mixed"],
        "baseline_drift_same_repository_exact_clusters": drift_exact_scope["same"],
        "baseline_drift_unknown_repository_exact_clusters": drift_exact_scope["unknown"],
        "new_unclassified_cross_repository_exact_clusters": new_exact_scope["cross"],
        "new_unclassified_mixed_repository_exact_clusters": new_exact_scope["mixed"],
        "new_unclassified_same_repository_exact_clusters": new_exact_scope["same"],
        "new_unclassified_unknown_repository_exact_clusters": new_exact_scope["unknown"],
        "classified_structural_candidate_clusters": classified_structural_count,
        "unclassified_structural_candidate_clusters": len(unclassified_structural),
        "baseline_drift_structural_candidate_clusters": len(baseline_drift_structural),
        "new_unclassified_structural_candidate_clusters": len(new_unclassified_structural),
        "baseline_drift_cross_repository_structural_clusters": drift_structural_scope["cross"],
        "baseline_drift_mixed_repository_structural_clusters": drift_structural_scope["mixed"],
        "baseline_drift_same_repository_structural_clusters": drift_structural_scope["same"],
        "baseline_drift_unknown_repository_structural_clusters": drift_structural_scope["unknown"],
        "new_unclassified_cross_repository_structural_clusters": new_structural_scope["cross"],
        "new_unclassified_mixed_repository_structural_clusters": new_structural_scope["mixed"],
        "new_unclassified_same_repository_structural_clusters": new_structural_scope["same"],
        "new_unclassified_unknown_repository_structural_clusters": new_structural_scope["unknown"],
        "total_classified_clusters": classified_exact_count + classified_structural_count,
        "total_unclassified_clusters": len(unclassified_exact) + len(unclassified_structural),
        "total_baseline_drift_clusters": len(baseline_drift_exact) + len(baseline_drift_structural),
        "total_new_unclassified_clusters": len(new_unclassified_exact) + len(new_unclassified_structural),
        "unclassified_exact_cluster_ids": [
            _classification_cluster_id(cluster, kind="exact") for cluster in unclassified_exact
        ],
        "actionable_unclassified_exact_cluster_ids": [
            _classification_cluster_id(cluster, kind="exact") for cluster in actionable_unclassified_exact
        ],
        "unclassified_structural_cluster_ids": [
            _classification_cluster_id(cluster, kind="structural") for cluster in unclassified_structural
        ],
        "baseline_drift_exact_clusters": baseline_drift_exact,
        "baseline_drift_structural_clusters": baseline_drift_structural,
        "new_unclassified_exact_cluster_ids": [
            _classification_cluster_id(cluster, kind="exact") for cluster in new_unclassified_exact
        ],
        "new_unclassified_structural_cluster_ids": [
            _classification_cluster_id(cluster, kind="structural") for cluster in new_unclassified_structural
        ],
    }


def scan_portfolio_reuse(
    workspace_root: str | Path,
    *,
    checkout_overrides: Mapping[str, str | Path] | None = None,
) -> dict[str, Any]:
    """Scan distinct indexed checkouts for conservative cross-project clones."""
    workspace_path = Path(workspace_root).expanduser().resolve()
    workspace_index = workspace_path / "CODEX_PROJECT_INDEX.md"
    workspace_index_bytes = workspace_index.read_bytes()
    overrides = checkout_overrides or {}
    units: list[CodeUnit] = []
    provider_units: list[CodeUnit] = []
    projects_payload: list[dict[str, Any]] = []
    scanned_checkouts: set[Path] = set()
    scanned_product_by_checkout: dict[Path, str] = {}
    products_by_checkout: dict[Path, list[str]] = {}
    manifests_by_checkout: dict[str, Mapping[str, Any]] = {}
    verified_manifests_by_checkout: dict[str, Mapping[str, Any]] = {}
    repository_by_checkout: dict[str, str | None] = {}
    projects = load_portfolio_projects(workspace_root)
    for project in projects:
        checkout = _resolve_checkout(project.product, project.checkout, overrides)
        repository_id = _repository_identity(checkout) if checkout and checkout.is_dir() else None
        if checkout and checkout.is_dir():
            repository_by_checkout[str(checkout)] = repository_id
        if project.product == "QazStack":
            if not checkout or not checkout.is_dir():
                projects_payload.append(
                    {"project": project.product, "checkout": str(checkout) if checkout else None, "status": "missing"}
                )
                continue
            files = _tracked_source_files(checkout)
            provider_units, snapshot = _scan_units_consistently(project.product, checkout, files)
            projects_payload.append(
                {
                    "project": project.product,
                    "checkout": str(checkout),
                    "status": "provider-scanned",
                    "repository_id": repository_id,
                    "source_files": len(files),
                    "code_units": len(provider_units),
                    **snapshot,
                }
            )
            continue
        if project.product in PROVIDER_PRODUCTS or project.product in NOT_APPLICABLE_PRODUCTS:
            projects_payload.append(
                {
                    "project": project.product,
                    "checkout": str(checkout) if checkout else None,
                    "status": "excluded",
                    "repository_id": repository_id,
                }
            )
            continue
        if not checkout or not checkout.is_dir():
            projects_payload.append(
                {"project": project.product, "checkout": str(checkout) if checkout else None, "status": "missing"}
            )
            continue
        if checkout in scanned_checkouts:
            scan_label = scanned_product_by_checkout[checkout]
            products_by_checkout[checkout].append(project.product)
            projects_payload.append(
                {
                    "project": project.product,
                    "checkout": str(checkout),
                    "status": "shared-checkout-unscanned",
                    "scan_label": scan_label,
                    "product_identity_preserved": True,
                    "repository_id": repository_id,
                }
            )
            continue
        scanned_checkouts.add(checkout)
        scanned_product_by_checkout[checkout] = project.product
        products_by_checkout[checkout] = [project.product]
        manifest_status = "missing"
        manifest_error = None
        adoption_check = None
        try:
            manifest = load_reuse_manifest(checkout / DEFAULT_REUSE_FILENAME, strict=False)
            manifest_status = "valid"
            manifests_by_checkout[str(checkout)] = manifest
            adoption_check = _adoption_evidence_view(check_project_reuse(checkout, strict=True))
            if adoption_check["evidence_status"] == "ok":
                verified_manifests_by_checkout[str(checkout)] = manifest
        except ReuseManifestError as exc:
            manifest_status = "invalid" if (checkout / DEFAULT_REUSE_FILENAME).exists() else "missing"
            manifest_error = str(exc)
        files = _tracked_source_files(checkout)
        project_units, snapshot = _scan_units_consistently(project.product, checkout, files)
        units.extend(project_units)
        projects_payload.append(
            {
                "project": project.product,
                "checkout": str(checkout),
                "status": "scanned",
                "repository_id": repository_id,
                "source_files": len(files),
                "code_units": len(project_units),
                "reuse_manifest": manifest_status,
                "manifest_error": manifest_error,
                "reuse_adoption_check": adoption_check,
                **snapshot,
            }
        )

    exact = _annotate_repository_scope(_clusters(units, "fingerprint"), repository_by_checkout)
    structural = _annotate_repository_scope(_clusters(units, "structural_fingerprint"), repository_by_checkout)
    all_provider_matches = [
        cluster
        for cluster in _annotate_repository_scope(
            _clusters([*units, *provider_units], "fingerprint"),
            repository_by_checkout,
        )
        if "QazStack" in cluster["projects"]
    ]
    declared_provider_matches = [
        cluster for cluster in all_provider_matches if _is_declared_qazstack_reuse(cluster, manifests_by_checkout)
    ]
    verified_declared_provider_matches = [
        cluster
        for cluster in declared_provider_matches
        if _is_declared_qazstack_reuse(cluster, verified_manifests_by_checkout)
    ]
    unverified_declared_provider_matches = [
        cluster for cluster in declared_provider_matches if cluster not in verified_declared_provider_matches
    ]
    provider_matches = [
        cluster for cluster in all_provider_matches if not _is_declared_qazstack_reuse(cluster, manifests_by_checkout)
    ]
    provider_matches.extend(unverified_declared_provider_matches)
    provider_matches.sort(key=lambda cluster: (-len(cluster["projects"]), cluster["cluster_id"]))
    scanned = sum(row["status"] == "scanned" for row in projects_payload)
    missing = sum(row["status"] == "missing" for row in projects_payload)
    valid_manifests = sum(row.get("reuse_manifest") == "valid" for row in projects_payload)
    adoption_evidence_statuses = Counter(
        str(check["evidence_status"])
        for row in projects_payload
        if isinstance((check := row.get("reuse_adoption_check")), Mapping) and "evidence_status" in check
    )
    adoption_version_statuses = Counter(
        str(check["version_status"])
        for row in projects_payload
        if isinstance((check := row.get("reuse_adoption_check")), Mapping) and "version_status" in check
    )
    dirty_scanned_projects = sum(
        row.get("source_dirty") is True for row in projects_payload if row["status"] in {"scanned", "provider-scanned"}
    )
    same_repository_exact = [cluster for cluster in exact if cluster["repository_scope"] == "same-repository"]
    cross_repository_exact = [cluster for cluster in exact if cluster["repository_scope"] == "cross-repository"]
    mixed_repository_exact = [cluster for cluster in exact if cluster["repository_scope"] == "mixed-repository"]
    unknown_repository_exact = [cluster for cluster in exact if cluster["repository_scope"] == "unknown-repository"]
    same_repository_structural = [cluster for cluster in structural if cluster["repository_scope"] == "same-repository"]
    cross_repository_structural = [
        cluster for cluster in structural if cluster["repository_scope"] == "cross-repository"
    ]
    mixed_repository_structural = [
        cluster for cluster in structural if cluster["repository_scope"] == "mixed-repository"
    ]
    unknown_repository_structural = [
        cluster for cluster in structural if cluster["repository_scope"] == "unknown-repository"
    ]
    shared_checkout_groups = [
        {
            "checkout": str(checkout),
            "scan_label": products[0],
            "products": products,
            "product_identity_preserved": True,
            "requires_product_scope": True,
        }
        for checkout, products in sorted(products_by_checkout.items(), key=lambda item: str(item[0]))
        if len(products) > 1
    ]
    current_workspace_index_bytes = workspace_index.read_bytes()
    if current_workspace_index_bytes != workspace_index_bytes:
        raise ReuseManifestError("workspace index changed while scanning; rerun from a stable index")
    return {
        "schema_version": "qazstack-portfolio-reuse-scan-v1",
        "scanner_semantics_version": SCANNER_SEMANTICS_VERSION,
        "checker": _checker_snapshot(),
        "workspace_root": str(workspace_path),
        "workspace_index_sha256": hashlib.sha256(workspace_index_bytes).hexdigest(),
        "workspace_products": [project.product for project in projects],
        "shared_checkout_groups": shared_checkout_groups,
        "counts": {
            "indexed_projects": len(projects_payload),
            "scanned_projects": scanned,
            "missing_projects": missing,
            "source_files": sum(row.get("source_files", 0) for row in projects_payload),
            "code_units": len(units),
            "qazstack_code_units": len(provider_units),
            "valid_reuse_manifests": valid_manifests,
            "reuse_adoption_evidence_ok_projects": adoption_evidence_statuses["ok"],
            "reuse_adoption_evidence_warning_projects": adoption_evidence_statuses["warning"],
            "reuse_adoption_evidence_error_projects": adoption_evidence_statuses["error"],
            "reuse_version_current_projects": adoption_version_statuses["current"],
            "reuse_version_drift_projects": adoption_version_statuses["drift"],
            "shared_checkout_groups": len(shared_checkout_groups),
            "shared_checkout_unscanned_products": sum(len(group["products"]) - 1 for group in shared_checkout_groups),
            "dirty_scanned_projects": dirty_scanned_projects,
            "exact_duplicate_clusters": len(exact),
            "structural_candidate_clusters": len(structural),
            "cross_repository_exact_clusters": len(cross_repository_exact),
            "mixed_repository_exact_clusters": len(mixed_repository_exact),
            "same_repository_exact_clusters": len(same_repository_exact),
            "unknown_repository_exact_clusters": len(unknown_repository_exact),
            "cross_repository_structural_clusters": len(cross_repository_structural),
            "mixed_repository_structural_clusters": len(mixed_repository_structural),
            "same_repository_structural_clusters": len(same_repository_structural),
            "unknown_repository_structural_clusters": len(unknown_repository_structural),
            "qazstack_exact_match_clusters": len(provider_matches),
            "declared_qazstack_reuse_clusters": len(declared_provider_matches),
            "verified_declared_qazstack_reuse_clusters": len(verified_declared_provider_matches),
            "unverified_declared_qazstack_reuse_clusters": len(unverified_declared_provider_matches),
        },
        "projects": projects_payload,
        "exact_duplicate_clusters": exact,
        "structural_candidate_clusters": structural,
        "qazstack_exact_matches": provider_matches,
        "declared_qazstack_reuse_matches": declared_provider_matches,
        "verified_declared_qazstack_reuse_matches": verified_declared_provider_matches,
        "unverified_declared_qazstack_reuse_matches": unverified_declared_provider_matches,
    }


def _portable_repository_id(value: Any) -> str | None:
    if not isinstance(value, str) or not value:
        return None
    return "local-checkout" if value.startswith("local:") else value


def _compact_baseline_cluster(cluster: Mapping[str, Any]) -> dict[str, Any]:
    """Keep only fields consumed by regression comparison."""
    locations = []
    for location in cluster.get("locations", []):
        if not isinstance(location, Mapping):
            continue
        project = location.get("project")
        if isinstance(project, str) and project:
            locations.append({"project": project})
    return {
        "fingerprint": cluster.get("fingerprint"),
        "projects": sorted(str(project) for project in cluster.get("projects", [])),
        "repository_scope": cluster.get("repository_scope", "unknown-repository"),
        "locations": locations,
    }


def build_reuse_regression_baseline_candidate(payload: Mapping[str, Any]) -> dict[str, Any]:
    """Build a compact deterministic snapshot that still requires owner review."""
    if payload.get("scanner_semantics_version") != SCANNER_SEMANTICS_VERSION:
        raise ReuseManifestError(
            "reuse scan uses incompatible scanner semantics; "
            f"expected {SCANNER_SEMANTICS_VERSION}, got {payload.get('scanner_semantics_version') or 'missing'}"
        )
    counts = payload.get("counts")
    if not isinstance(counts, Mapping):
        raise ReuseManifestError("reuse scan counts must be an object")
    checker = payload.get("checker") if isinstance(payload.get("checker"), Mapping) else {}
    projects = []
    for project in payload.get("projects", []):
        if not isinstance(project, Mapping) or not isinstance(project.get("project"), str):
            continue
        row = {
            "project": project["project"],
            "status": project.get("status"),
            "reuse_manifest": project.get("reuse_manifest"),
        }
        repository_id = _portable_repository_id(project.get("repository_id"))
        if repository_id:
            row["repository_id"] = repository_id
        adoption_check = project.get("reuse_adoption_check")
        if isinstance(adoption_check, Mapping):
            row["reuse_adoption_check"] = {"evidence_status": adoption_check.get("evidence_status")}
        projects.append(row)
    projects.sort(key=lambda item: item["project"])
    return {
        "schema_version": REGRESSION_BASELINE_SCHEMA_VERSION,
        "scanner_semantics_version": SCANNER_SEMANTICS_VERSION,
        "review_status": "candidate",
        "review_instruction": (
            "Verify workspace coverage, dirty snapshots, product identities and duplicate lineages; "
            "then set review_status=reviewed and record reviewed_at plus owner."
        ),
        "derived_from": {
            "workspace_index_sha256": payload.get("workspace_index_sha256"),
            "qazstack_version": checker.get("qazstack_version"),
            "source_revision": checker.get("source_revision"),
            "source_digest_sha256": checker.get("source_digest_sha256"),
        },
        "counts": {
            "scanned_projects": counts.get("scanned_projects", 0),
            "valid_reuse_manifests": counts.get("valid_reuse_manifests", 0),
        },
        "workspace_products": sorted(str(project) for project in payload.get("workspace_products", [])),
        "projects": projects,
        "exact_duplicate_clusters": [
            _compact_baseline_cluster(cluster) for cluster in payload.get("exact_duplicate_clusters", [])
        ],
        "qazstack_exact_matches": [
            _compact_baseline_cluster(cluster) for cluster in payload.get("qazstack_exact_matches", [])
        ],
    }


def _classification_example_locations(cluster: Mapping[str, Any]) -> list[str]:
    examples = []
    for location in cluster.get("locations", []):
        if not isinstance(location, Mapping):
            continue
        examples.append(
            "{project}:{path}:{start}:{symbol}".format(
                project=location.get("project", "unknown"),
                path=location.get("path", "unknown"),
                start=location.get("start_line", "?"),
                symbol=location.get("symbol", "unknown"),
            )
        )
    return examples[:6]


def build_classification_baseline_candidate(
    payload: Mapping[str, Any],
    prior_baseline: Mapping[str, Any],
) -> dict[str, Any]:
    """Carry prior owner decisions into the current identity model without approving drift."""
    if payload.get("scanner_semantics_version") != SCANNER_SEMANTICS_VERSION:
        raise ReuseManifestError(
            "reuse scan uses incompatible scanner semantics; "
            f"expected {SCANNER_SEMANTICS_VERSION}, got {payload.get('scanner_semantics_version') or 'missing'}"
        )
    records = _load_classification_records(prior_baseline)
    records_by_key = {
        (
            str(record["kind"]),
            str(record["fingerprint"]),
            tuple(str(project) for project in record["projects"]),
        ): record
        for record in records
    }
    fingerprint_index = _classification_fingerprint_index(records)
    migrated: list[dict[str, Any]] = []
    carried_forward = 0
    project_set_migrations = 0
    matched_prior_keys: set[tuple[str, str, tuple[str, ...]]] = set()
    current_clusters = (("exact", cluster) for cluster in payload.get("exact_duplicate_clusters", []))
    structural_clusters = (("structural", cluster) for cluster in payload.get("structural_candidate_clusters", []))
    for kind, cluster in chain(current_clusters, structural_clusters):
        current_key = _cluster_classification_key(cluster, kind=kind)
        prior_record: Mapping[str, Any] | None = None
        state = "carried-forward"
        if current_key in records_by_key:
            prior_record = records_by_key[current_key]
            carried_forward += 1
        else:
            candidates = fingerprint_index.get((kind, str(cluster.get("fingerprint", ""))), [])
            if not candidates:
                continue
            drift = _baseline_project_set_drift(cluster, candidates, kind=kind)
            prior_projects = tuple(str(project) for project in drift["baseline_projects"])
            prior_record = next(
                record
                for record in candidates
                if tuple(str(project) for project in record["projects"]) == prior_projects
            )
            state = "candidate-project-set-migration"
            project_set_migrations += 1
        prior_key = (
            str(prior_record["kind"]),
            str(prior_record["fingerprint"]),
            tuple(str(project) for project in prior_record["projects"]),
        )
        matched_prior_keys.add(prior_key)
        record = {
            **prior_record,
            "kind": kind,
            "fingerprint": str(cluster.get("fingerprint", "")),
            "projects": sorted(str(project) for project in cluster.get("projects", [])),
            "category": cluster.get("category", prior_record.get("category")),
            "example_locations": _classification_example_locations(cluster),
            "migration": {
                "state": state,
                "prior_projects": sorted(str(project) for project in prior_record["projects"]),
            },
        }
        migrated.append(record)
    migrated.sort(key=lambda item: (str(item["kind"]), str(item["fingerprint"]), tuple(item["projects"])))
    return {
        "schema_version": CLASSIFICATION_SCHEMA_VERSION,
        "review_status": "candidate",
        "review_instruction": (
            "Review every candidate-project-set-migration and the remaining unclassified queue; "
            "then set review_status=reviewed and record reviewed_at plus owner."
        ),
        "source_reviewed_at": prior_baseline.get("reviewed_at"),
        "source_owner": prior_baseline.get("owner"),
        "scanner_semantics_version": SCANNER_SEMANTICS_VERSION,
        "counts": {
            "source_classifications": len(records),
            "carried_forward": carried_forward,
            "candidate_project_set_migrations": project_set_migrations,
            "dropped_source_classifications": len(records) - len(matched_prior_keys),
            "candidate_classifications": len(migrated),
        },
        "classifications": migrated,
    }


def ensure_reuse_baseline_compatible(baseline: Mapping[str, Any]) -> None:
    """Reject regression baselines produced under different scan semantics."""
    baseline_semantics = baseline.get("scanner_semantics_version")
    if baseline_semantics != SCANNER_SEMANTICS_VERSION:
        raise ReuseManifestError(
            "reuse baseline uses incompatible scanner semantics; "
            f"expected {SCANNER_SEMANTICS_VERSION}, got {baseline_semantics or 'missing'}"
        )


def ensure_reuse_baseline_reviewed(baseline: Mapping[str, Any]) -> None:
    """Keep generated candidates out of the strict regression gate."""
    review_status = baseline.get("review_status")
    if review_status == "candidate":
        raise ReuseManifestError("reuse baseline is a candidate and has not been owner-reviewed")
    if baseline.get("schema_version") == REGRESSION_BASELINE_SCHEMA_VERSION:
        if review_status != "reviewed":
            raise ReuseManifestError("semantics-v2 reuse baseline must declare review_status=reviewed")
        if not isinstance(baseline.get("reviewed_at"), str) or not baseline["reviewed_at"].strip():
            raise ReuseManifestError("reviewed reuse baseline must record reviewed_at")
        if not isinstance(baseline.get("owner"), str) or not baseline["owner"].strip():
            raise ReuseManifestError("reviewed reuse baseline must record owner")


def ensure_classification_baseline_reviewed(baseline: Mapping[str, Any]) -> None:
    """Keep mechanically migrated classifications out of the strict gate."""
    baseline_semantics = baseline.get("scanner_semantics_version")
    if baseline_semantics != SCANNER_SEMANTICS_VERSION:
        raise ReuseManifestError(
            "classification baseline uses incompatible scanner semantics; "
            f"expected {SCANNER_SEMANTICS_VERSION}, got {baseline_semantics or 'missing'}"
        )
    review_status = baseline.get("review_status")
    if review_status == "candidate":
        raise ReuseManifestError("classification baseline is a candidate and has not been owner-reviewed")
    if review_status != "reviewed":
        raise ReuseManifestError("semantics-v2 classification baseline must declare review_status=reviewed")
    if not isinstance(baseline.get("reviewed_at"), str) or not baseline["reviewed_at"].strip():
        raise ReuseManifestError("reviewed classification baseline must record reviewed_at")
    if not isinstance(baseline.get("owner"), str) or not baseline["owner"].strip():
        raise ReuseManifestError("reviewed classification baseline must record owner")


def reuse_scan_regressions(current: Mapping[str, Any], baseline: Mapping[str, Any]) -> list[str]:
    """Return deterministic coverage or exact-clone regressions."""
    ensure_reuse_baseline_compatible(baseline)
    regressions: list[str] = []
    current_counts = current["counts"]
    baseline_counts = baseline["counts"]
    for key, label in (
        ("scanned_projects", "scanned project coverage"),
        ("valid_reuse_manifests", "valid reuse-manifest coverage"),
    ):
        if current_counts[key] < baseline_counts.get(key, 0):
            regressions.append(f"{label} dropped from {baseline_counts.get(key, 0)} to {current_counts[key]}")
    declared_qazstack_keys = _declared_qazstack_reuse_keys(current)

    current_products = {str(project) for project in current.get("workspace_products", [])}
    baseline_products = {str(project) for project in baseline.get("workspace_products", [])}
    if current_products and baseline_products:
        removed_products = sorted(baseline_products - current_products)
        if removed_products:
            regressions.append(f"indexed products disappeared: {', '.join(removed_products)}")

    def project_rows(payload: Mapping[str, Any]) -> dict[str, Mapping[str, Any]]:
        return {
            str(row["project"]): row
            for row in payload.get("projects", [])
            if isinstance(row, Mapping) and isinstance(row.get("project"), str)
        }

    current_rows = project_rows(current)
    baseline_rows = project_rows(baseline)
    scan_status_rank = {
        "excluded": 1,
        "shared-checkout-unscanned": 2,
        "provider-scanned": 3,
        "scanned": 3,
    }
    evidence_rank = {"ok": 0, "warning": 1, "error": 2}
    for project in sorted(current_rows.keys() & baseline_rows.keys()):
        current_row = current_rows[project]
        baseline_row = baseline_rows[project]
        baseline_status = str(baseline_row.get("status", ""))
        current_status = str(current_row.get("status", ""))
        if scan_status_rank.get(current_status, 0) < scan_status_rank.get(baseline_status, 0):
            regressions.append(f"{project} scan status degraded from {baseline_status} to {current_status}")
        if baseline_row.get("reuse_manifest") == "valid" and current_row.get("reuse_manifest") != "valid":
            regressions.append(f"{project} reuse manifest is no longer schema-valid")
        current_check = current_row.get("reuse_adoption_check")
        baseline_check = baseline_row.get("reuse_adoption_check")
        if isinstance(current_check, Mapping) and isinstance(baseline_check, Mapping):
            current_evidence = str(current_check.get("evidence_status", "error"))
            baseline_evidence = str(baseline_check.get("evidence_status", "error"))
            if evidence_rank.get(current_evidence, 3) > evidence_rank.get(baseline_evidence, 3):
                regressions.append(
                    f"{project} adoption evidence degraded from {baseline_evidence} to {current_evidence}"
                )

    def repository_ids(payload: Mapping[str, Any]) -> dict[str, str]:
        result = {}
        for project in payload.get("projects", []):
            if not isinstance(project, Mapping) or not isinstance(project.get("project"), str):
                continue
            repository_id = _portable_repository_id(project.get("repository_id"))
            if repository_id:
                result[str(project["project"])] = repository_id
        return result

    def membership(
        cluster: Mapping[str, Any],
        *,
        exclude_qazstack: bool,
        project_repositories: Mapping[str, str],
    ) -> set[str]:
        members: set[str] = set()
        locations = cluster.get("locations", [])
        if isinstance(locations, list):
            for location in locations:
                if not isinstance(location, Mapping):
                    continue
                project = str(location.get("project", ""))
                if exclude_qazstack and project == "QazStack":
                    continue
                repository_id = project_repositories.get(project)
                members.add(f"project:{project}|repository:{repository_id}" if repository_id else f"project:{project}")
        if not members:
            members.update(
                f"project:{project}"
                for project in cluster.get("projects", [])
                if not (exclude_qazstack and project == "QazStack")
            )
        return members

    def lineages(payload: Mapping[str, Any], *, current_payload: bool) -> dict[str, dict[str, Any]]:
        grouped: dict[str, dict[str, Any]] = {}
        project_repositories = repository_ids(payload)
        for cluster in payload.get("exact_duplicate_clusters", []):
            if current_payload and _cluster_classification_key(cluster) in declared_qazstack_keys:
                continue
            fingerprint = str(cluster["fingerprint"])
            record = grouped.setdefault(
                fingerprint,
                {"members": set(), "projects": set(), "repository_scopes": set(), "qazstack": False},
            )
            record["members"].update(
                membership(cluster, exclude_qazstack=False, project_repositories=project_repositories)
            )
            record["projects"].update(str(project) for project in cluster.get("projects", []))
            record["repository_scopes"].add(str(cluster.get("repository_scope", "unknown-repository")))
        for cluster in payload.get("qazstack_exact_matches", []):
            fingerprint = str(cluster["fingerprint"])
            record = grouped.setdefault(
                fingerprint,
                {"members": set(), "projects": set(), "repository_scopes": set(), "qazstack": False},
            )
            record["qazstack"] = True
            record["members"].update(
                membership(cluster, exclude_qazstack=True, project_repositories=project_repositories)
            )
            record["projects"].update(str(project) for project in cluster.get("projects", []) if project != "QazStack")
        return grouped

    current_lineages = lineages(current, current_payload=True)
    baseline_lineages = lineages(baseline, current_payload=False)
    for fingerprint, lineage in sorted(current_lineages.items()):
        projects = set(lineage["projects"])
        members = set(lineage["members"])
        prior = baseline_lineages.get(fingerprint)
        label = "local implementation matching QazStack" if lineage["qazstack"] else "exact duplicate cluster"
        if prior is None:
            regressions.append(f"new {label} across: {', '.join(sorted(projects))}")
            continue
        if lineage["qazstack"] and not prior["qazstack"]:
            regressions.append(f"new local implementation matching QazStack across: {', '.join(sorted(projects))}")
            continue
        if members - set(prior["members"]):
            regressions.append(f"{label} expanded to: {', '.join(sorted(projects))}")
            continue
        scope_rank = {"same-repository": 0, "mixed-repository": 1, "cross-repository": 2}
        current_rank = max((scope_rank.get(scope, -1) for scope in lineage["repository_scopes"]), default=-1)
        prior_rank = max((scope_rank.get(scope, -1) for scope in prior["repository_scopes"]), default=-1)
        if prior_rank >= 0 and current_rank > prior_rank:
            regressions.append(
                "exact duplicate cluster repository scope expanded from "
                f"{sorted(prior['repository_scopes'])} to {sorted(lineage['repository_scopes'])}: "
                f"{', '.join(sorted(projects))}"
            )
    return regressions


def render_reuse_scan_digest(payload: Mapping[str, Any], regressions: Iterable[str] = ()) -> str:
    counts = payload["counts"]
    lines = [
        (
            "reuse-scan: "
            f"{counts['scanned_projects']} scanned, {counts['missing_projects']} missing, "
            f"{counts['valid_reuse_manifests']} schema-valid manifests"
        ),
        (
            "adoption-evidence: "
            f"{counts.get('reuse_adoption_evidence_ok_projects', 0)} ok/"
            f"{counts.get('reuse_adoption_evidence_warning_projects', 0)} warning/"
            f"{counts.get('reuse_adoption_evidence_error_projects', 0)} error; "
            f"version {counts.get('reuse_version_current_projects', 0)} current/"
            f"{counts.get('reuse_version_drift_projects', 0)} drift"
        ),
        (
            "duplicates: "
            f"{counts['exact_duplicate_clusters']} exact, "
            f"{counts['structural_candidate_clusters']} structural candidates, "
            f"{counts.get('qazstack_exact_match_clusters', 0)} unverified/undeclared QazStack matches, "
            f"{counts.get('verified_declared_qazstack_reuse_clusters', 0)} verified declared QazStack reuse"
        ),
        (
            "repository-scope: "
            f"exact {counts.get('cross_repository_exact_clusters', 0)} cross/"
            f"{counts.get('mixed_repository_exact_clusters', 0)} mixed/"
            f"{counts.get('same_repository_exact_clusters', 0)} same/"
            f"{counts.get('unknown_repository_exact_clusters', 0)} unknown; "
            f"structural {counts.get('cross_repository_structural_clusters', 0)} cross/"
            f"{counts.get('mixed_repository_structural_clusters', 0)} mixed/"
            f"{counts.get('same_repository_structural_clusters', 0)} same/"
            f"{counts.get('unknown_repository_structural_clusters', 0)} unknown"
        ),
        (
            "shared-checkout-scope: "
            f"{counts.get('shared_checkout_groups', 0)} groups/"
            f"{counts.get('shared_checkout_unscanned_products', 0)} product identities require product-level scope"
        ),
        (
            "checker: "
            f"QazStack {payload.get('checker', {}).get('qazstack_version', 'unknown')} "
            f"at {payload.get('checker', {}).get('source_revision', 'unknown')}; "
            f"dirty={payload.get('checker', {}).get('source_dirty', 'unknown')}"
        ),
    ]
    materialized = list(regressions)
    baseline_metadata = payload.get("regression_baseline")
    if isinstance(baseline_metadata, Mapping):
        lines.append(
            "regression-baseline: "
            + ("comparable" if baseline_metadata.get("semantics_compatible") else "not-comparable")
        )
    lines.append(f"regressions: {len(materialized)}")
    classification = payload.get("classification")
    if isinstance(classification, Mapping):
        lines.append(
            "classification: "
            f"exact {classification.get('classified_exact_duplicate_clusters', 0)} classified/"
            f"{classification.get('unclassified_exact_duplicate_clusters', 0)} unclassified; "
            f"structural {classification.get('classified_structural_candidate_clusters', 0)} classified/"
            f"{classification.get('unclassified_structural_candidate_clusters', 0)} unclassified"
        )
        lines.append(
            "classification-delta: "
            f"exact {classification.get('baseline_drift_exact_duplicate_clusters', 0)} baseline drift/"
            f"{classification.get('new_unclassified_exact_duplicate_clusters', 0)} new "
            f"({classification.get('new_unclassified_cross_repository_exact_clusters', 0)} cross/"
            f"{classification.get('new_unclassified_mixed_repository_exact_clusters', 0)} mixed/"
            f"{classification.get('new_unclassified_same_repository_exact_clusters', 0)} same/"
            f"{classification.get('new_unclassified_unknown_repository_exact_clusters', 0)} unknown); "
            f"structural {classification.get('baseline_drift_structural_candidate_clusters', 0)} baseline drift/"
            f"{classification.get('new_unclassified_structural_candidate_clusters', 0)} new "
            f"({classification.get('new_unclassified_cross_repository_structural_clusters', 0)} cross/"
            f"{classification.get('new_unclassified_mixed_repository_structural_clusters', 0)} mixed/"
            f"{classification.get('new_unclassified_same_repository_structural_clusters', 0)} same/"
            f"{classification.get('new_unclassified_unknown_repository_structural_clusters', 0)} unknown)"
        )
    lines.extend(f"- {item}" for item in materialized[:REGRESSION_DIGEST_LIMIT])
    if len(materialized) > REGRESSION_DIGEST_LIMIT:
        lines.append(f"- ... and {len(materialized) - REGRESSION_DIGEST_LIMIT} more regressions; see the JSON payload")
    return "\n".join(lines) + "\n"


def render_reuse_scan_markdown(payload: Mapping[str, Any], regressions: Iterable[str] = ()) -> str:
    """Render an operator report without treating candidates as migration decisions."""
    counts = payload["counts"]
    categories = Counter(cluster["category"] for cluster in payload["exact_duplicate_clusters"])
    cross_repository_pairs: Counter[tuple[str, str]] = Counter()
    mixed_repository_pairs: Counter[tuple[str, str]] = Counter()
    same_repository_pairs: Counter[tuple[str, str]] = Counter()
    unknown_repository_pairs: Counter[tuple[str, str]] = Counter()
    for cluster in payload["exact_duplicate_clusters"]:
        pairs = combinations(sorted(cluster["projects"]), 2)
        if cluster.get("repository_scope") == "same-repository":
            same_repository_pairs.update(pairs)
        elif cluster.get("repository_scope") == "cross-repository":
            cross_repository_pairs.update(pairs)
        elif cluster.get("repository_scope") == "mixed-repository":
            mixed_repository_pairs.update(pairs)
        else:
            unknown_repository_pairs.update(pairs)
    missing_manifests = [
        row["project"] for row in payload["projects"] if row.get("reuse_manifest") in {"missing", "invalid"}
    ]
    lines = [
        "# QazStack portfolio reuse scan",
        "",
        "This is a conservative source snapshot, not an automatic extraction or deletion plan.",
        "",
        "## Coverage",
        "",
        f"- Indexed projects: {counts['indexed_projects']}",
        f"- Distinct consumer checkouts scanned: {counts['scanned_projects']}",
        f"- Missing checkouts: {counts['missing_projects']}",
        f"- Tracked source files: {counts['source_files']}",
        f"- Consumer code units: {counts['code_units']}",
        f"- QazStack code units: {counts.get('qazstack_code_units', 0)}",
        f"- Schema-valid reuse manifests: {counts['valid_reuse_manifests']}",
        (
            "- Full adoption checks: "
            f"{counts.get('reuse_adoption_evidence_ok_projects', 0)} evidence-ok; "
            f"{counts.get('reuse_adoption_evidence_warning_projects', 0)} evidence-warning; "
            f"{counts.get('reuse_adoption_evidence_error_projects', 0)} evidence-error"
        ),
        (
            "- Declared QazStack versions: "
            f"{counts.get('reuse_version_current_projects', 0)} current; "
            f"{counts.get('reuse_version_drift_projects', 0)} drift"
        ),
        f"- Dirty scanned source snapshots: {counts.get('dirty_scanned_projects', 0)}",
        f"- Workspace index SHA-256: `{payload.get('workspace_index_sha256', 'unknown')}`",
        (
            "- Shared-checkout scope gaps: "
            f"{counts.get('shared_checkout_groups', 0)} groups; "
            f"{counts.get('shared_checkout_unscanned_products', 0)} additional product identities "
            "need product-level rules"
        ),
        (
            "- Checker source: "
            f"QazStack `{payload.get('checker', {}).get('qazstack_version', 'unknown')}` at "
            f"`{payload.get('checker', {}).get('source_revision', 'unknown')}`, "
            f"dirty=`{payload.get('checker', {}).get('source_dirty', 'unknown')}`"
        ),
        (
            "- Regression baseline semantics: "
            + (
                "compatible"
                if payload.get("regression_baseline", {}).get("semantics_compatible")
                else "not comparable or not supplied"
            )
        ),
        "",
        "## Findings",
        "",
        f"- Exact duplicate clusters: {counts['exact_duplicate_clusters']}",
        f"- Structural candidates: {counts['structural_candidate_clusters']}",
        (
            "- Exact repository scope: "
            f"{counts.get('cross_repository_exact_clusters', 0)} cross-repository; "
            f"{counts.get('mixed_repository_exact_clusters', 0)} mixed-repository; "
            f"{counts.get('same_repository_exact_clusters', 0)} same-repository; "
            f"{counts.get('unknown_repository_exact_clusters', 0)} unknown"
        ),
        (
            "- Structural repository scope: "
            f"{counts.get('cross_repository_structural_clusters', 0)} cross-repository; "
            f"{counts.get('mixed_repository_structural_clusters', 0)} mixed-repository; "
            f"{counts.get('same_repository_structural_clusters', 0)} same-repository; "
            f"{counts.get('unknown_repository_structural_clusters', 0)} unknown"
        ),
        (
            "- Exact local implementations matching QazStack but not declared: "
            f"{counts.get('qazstack_exact_match_clusters', 0)}"
        ),
        (
            "- Declared exact QazStack reuse matches: "
            f"{counts.get('verified_declared_qazstack_reuse_clusters', 0)} verified; "
            f"{counts.get('unverified_declared_qazstack_reuse_clusters', 0)} unverified"
        ),
        "",
        "| Exact-cluster category | Count |",
        "|---|---:|",
    ]
    lines.extend(f"| {category} | {amount} |" for category, amount in sorted(categories.items()))
    lines.extend(
        [
            "",
            "## Highest-overlap cross-repository project pairs",
            "",
            "| Pair | Exact clusters |",
            "|---|---:|",
        ]
    )
    lines.extend(
        f"| {first} ↔ {second} | {amount} |" for (first, second), amount in cross_repository_pairs.most_common(20)
    )
    if mixed_repository_pairs:
        lines.extend(
            [
                "",
                "## Mixed-repository project pairs",
                "",
                "These clusters contain both shared-remote and independently owned checkouts and require "
                "pair-level review.",
                "",
                "| Pair | Exact clusters |",
                "|---|---:|",
            ]
        )
        lines.extend(
            f"| {first} ↔ {second} | {amount} |" for (first, second), amount in mixed_repository_pairs.most_common(10)
        )
    lines.extend(
        [
            "",
            "## Same-repository checkout pairs",
            "",
            "These overlaps remain visible and participate in regression detection. Shared Git ownership does not",
            "prove that two product surfaces have the same policy or lifecycle.",
            "",
            "| Pair | Exact clusters |",
            "|---|---:|",
        ]
    )
    lines.extend(
        f"| {first} ↔ {second} | {amount} |" for (first, second), amount in same_repository_pairs.most_common(10)
    )
    if unknown_repository_pairs:
        lines.extend(
            [
                "",
                "## Unknown-repository checkout pairs",
                "",
                "At least one checkout has no readable origin; resolve repository identity before extraction.",
                "",
                "| Pair | Exact clusters |",
                "|---|---:|",
            ]
        )
        lines.extend(
            f"| {first} ↔ {second} | {amount} |" for (first, second), amount in unknown_repository_pairs.most_common(10)
        )
    lines.extend(
        [
            "",
            "## Unclassified local code already present in QazStack",
            "",
            "| Products | Category | Locations |",
            "|---|---|---|",
        ]
    )
    for cluster in payload.get("qazstack_exact_matches", []):
        locations = "<br>".join(
            f"`{location['project']}: {location['path']}:{location['start_line']} ({location['symbol']})`"
            for location in cluster["locations"]
        )
        lines.append(f"| {', '.join(cluster['projects'])} | {cluster['category']} | {locations} |")
    if not payload.get("qazstack_exact_matches"):
        lines.append("| - | - | No exact matches |")
    lines.extend(
        [
            "",
            "## Declared QazStack reuse matches",
            "",
            "| Products | Category | Locations |",
            "|---|---|---|",
        ]
    )
    for cluster in payload.get("declared_qazstack_reuse_matches", []):
        locations = "<br>".join(
            f"`{location['project']}: {location['path']}:{location['start_line']} ({location['symbol']})`"
            for location in cluster["locations"]
        )
        lines.append(f"| {', '.join(cluster['projects'])} | {cluster['category']} | {locations} |")
    if not payload.get("declared_qazstack_reuse_matches"):
        lines.append("| - | - | No declared exact reuse matches |")
    lines.extend(
        [
            "",
            "## Classification baseline",
            "",
        ]
    )
    classification = payload.get("classification")
    if isinstance(classification, Mapping):
        exact_by_id = {
            _classification_cluster_id(cluster, kind="exact"): cluster
            for cluster in payload.get("exact_duplicate_clusters", [])
        }
        structural_by_id = {
            _classification_cluster_id(cluster, kind="structural"): cluster
            for cluster in payload.get("structural_candidate_clusters", [])
        }
        lines.extend(
            [
                (
                    "- Classified exact duplicate clusters: "
                    f"{classification.get('classified_exact_duplicate_clusters', 0)}"
                ),
                (
                    "- Baseline-reviewed exact duplicate clusters: "
                    f"{classification.get('baseline_classified_exact_duplicate_clusters', 0)}"
                ),
                (
                    "- Declared QazStack reuse exact clusters: "
                    f"{classification.get('declared_qazstack_reuse_exact_clusters', 0)}"
                ),
                (
                    "- Unclassified exact duplicate clusters: "
                    f"{classification.get('unclassified_exact_duplicate_clusters', 0)}"
                ),
                (
                    "- Exact baseline project-set drift: "
                    f"{classification.get('baseline_drift_exact_duplicate_clusters', 0)}"
                ),
                (
                    "- Genuinely new exact fingerprints: "
                    f"{classification.get('new_unclassified_exact_duplicate_clusters', 0)} "
                    f"({classification.get('new_unclassified_cross_repository_exact_clusters', 0)} "
                    "cross-repository; "
                    f"{classification.get('new_unclassified_mixed_repository_exact_clusters', 0)} "
                    "mixed-repository; "
                    f"{classification.get('new_unclassified_same_repository_exact_clusters', 0)} "
                    "same-repository; "
                    f"{classification.get('new_unclassified_unknown_repository_exact_clusters', 0)} unknown)"
                ),
                (
                    "- Classified structural candidate clusters: "
                    f"{classification.get('classified_structural_candidate_clusters', 0)}"
                ),
                (
                    "- Baseline-reviewed structural candidate clusters: "
                    f"{classification.get('baseline_classified_structural_candidate_clusters', 0)}"
                ),
                (
                    "- Unclassified structural candidate clusters: "
                    f"{classification.get('unclassified_structural_candidate_clusters', 0)}"
                ),
                (
                    "- Structural baseline project-set drift: "
                    f"{classification.get('baseline_drift_structural_candidate_clusters', 0)}"
                ),
                (
                    "- Genuinely new structural fingerprints: "
                    f"{classification.get('new_unclassified_structural_candidate_clusters', 0)}"
                ),
                "",
            ]
        )
        if classification.get("new_unclassified_exact_cluster_ids"):
            lines.extend(
                [
                    "### Genuinely new exact fingerprints",
                    "",
                    "| Products | Scope | Category | Locations |",
                    "|---|---|---|---|",
                ]
            )
            new_exact = sorted(
                (
                    exact_by_id[cluster_id]
                    for cluster_id in classification["new_unclassified_exact_cluster_ids"]
                    if cluster_id in exact_by_id
                ),
                key=lambda cluster: (
                    cluster.get("repository_scope") != "cross-repository",
                    tuple(cluster.get("projects", [])),
                    cluster.get("fingerprint", ""),
                ),
            )
            for cluster in new_exact[:50]:
                locations = "<br>".join(
                    f"`{location['project']}: {location['path']}:{location['start_line']} ({location['symbol']})`"
                    for location in cluster["locations"][:6]
                )
                lines.append(
                    f"| {', '.join(cluster['projects'])} | "
                    f"{cluster.get('repository_scope', 'unknown')} | {cluster['category']} | {locations} |"
                )
            if len(new_exact) > 50:
                lines.append(f"| ... | ... | ... | {len(new_exact) - 50} more genuinely new exact fingerprints |")
            lines.append("")
        if classification.get("baseline_drift_exact_clusters"):
            lines.extend(
                [
                    "### Exact fingerprints with baseline project-set drift",
                    "",
                    "| Current products | Added | Removed | Prior owner |",
                    "|---|---|---|---|",
                ]
            )
            drift_exact = classification["baseline_drift_exact_clusters"]
            for cluster in drift_exact[:50]:
                lines.append(
                    "| "
                    f"{', '.join(cluster['projects'])} | "
                    f"{', '.join(cluster['project_members_added']) or '-'} | "
                    f"{', '.join(cluster['project_members_removed']) or '-'} | "
                    f"{cluster.get('baseline_owner') or '-'} |"
                )
            if len(drift_exact) > 50:
                lines.append(f"| ... | ... | ... | {len(drift_exact) - 50} more drifted exact fingerprints |")
            lines.append("")
        if classification.get("new_unclassified_structural_cluster_ids"):
            lines.extend(
                [
                    "### Genuinely new structural fingerprints",
                    "",
                    "| Products | Category | Locations |",
                    "|---|---|---|",
                ]
            )
            new_structural = [
                structural_by_id[cluster_id]
                for cluster_id in classification["new_unclassified_structural_cluster_ids"]
                if cluster_id in structural_by_id
            ]
            for cluster in new_structural[:50]:
                locations = "<br>".join(
                    f"`{location['project']}: {location['path']}:{location['start_line']} ({location['symbol']})`"
                    for location in cluster["locations"][:6]
                )
                lines.append(f"| {', '.join(cluster['projects'])} | {cluster['category']} | {locations} |")
            if len(new_structural) > 50:
                lines.append(f"| ... | ... | {len(new_structural) - 50} more genuinely new structural fingerprints |")
            lines.append("")
    else:
        lines.extend(
            [
                (
                    "No classification baseline was supplied. Raw exact duplicate clusters and structural candidates "
                    "remain review candidates."
                ),
                "",
            ]
        )
    lines.extend(
        [
            "## Reuse-manifest migration queue",
            "",
            f"{len(missing_manifests)} scanned projects still need an owner-reviewed `qazstack-reuse.json`:",
            "",
            ", ".join(missing_manifests) if missing_manifests else "None.",
            "",
            "## Recommended bounded work",
            "",
            "1. Replace the exact local/QazStack matches with package imports or versioned shared assets.",
            "2. Review cross-repository candidates before same-repository product branches and recovery copies.",
            "3. Resolve high-overlap pairs by naming the owning runtime; do not copy the same implementation twice.",
            "4. Separate baseline project-set drift from genuinely new fingerprints before reviewing classifications.",
            "5. Add reuse manifests product by product, with real source/test evidence and expiring exceptions.",
            "6. Save a reviewed baseline only after owners classify intentional forks and generated/shared assets.",
            "",
            "## Regression result",
            "",
        ]
    )
    materialized = list(regressions)
    if materialized:
        lines.extend(f"- {item}" for item in materialized[:REGRESSION_MARKDOWN_LIMIT])
        if len(materialized) > REGRESSION_MARKDOWN_LIMIT:
            lines.append(
                f"- ... and {len(materialized) - REGRESSION_MARKDOWN_LIMIT} more regressions; see the JSON payload"
            )
    else:
        lines.append("No baseline regressions were requested or detected.")
    lines.extend(
        [
            "",
            "The JSON payload is the authoritative location-level evidence. Similarity does not by itself prove",
            "that product policy, private data, deployment code or provider-specific behavior belongs in QazStack.",
            "",
        ]
    )
    return "\n".join(lines)
