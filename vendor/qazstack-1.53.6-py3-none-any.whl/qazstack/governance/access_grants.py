"""Opaque, revocable access grants without credentials or contact details."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from qazstack.contracts._validation import require_aware, require_identifier, require_one_of, require_text

ACCESS_GRANT_SCHEMA = "qazstack-access-grant-v1"
ACCESS_GRANT_STATUSES = frozenset({"pending", "active", "revoked", "expired"})


def _iso(value: datetime | None) -> str | None:
    if value is None:
        return None
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


@dataclass(frozen=True, slots=True)
class AccessGrant:
    """Lifecycle record for access to one protected resource."""

    grant_id: str
    resource_ref: str
    subject_ref: str
    status: str
    scopes: tuple[str, ...]
    requested_at: datetime
    policy_version: str
    evidence_refs: tuple[str, ...] = ()
    granted_by: str = ""
    granted_at: datetime | None = None
    expires_at: datetime | None = None
    revoked_by: str = ""
    revoked_at: datetime | None = None
    reason: str = ""
    schema_version: str = field(default=ACCESS_GRANT_SCHEMA, init=False)

    def __post_init__(self) -> None:
        for value, name in (
            (self.grant_id, "grant_id"),
            (self.resource_ref, "resource_ref"),
            (self.subject_ref, "subject_ref"),
            (self.policy_version, "policy_version"),
        ):
            require_identifier(value, name)
        require_one_of(self.status, ACCESS_GRANT_STATUSES, "status")
        require_aware(self.requested_at, "requested_at")
        if not self.scopes or len(self.scopes) != len(set(self.scopes)):
            raise ValueError("scopes must be non-empty and unique")
        for scope in self.scopes:
            require_identifier(scope, "scope")
        if len(self.evidence_refs) != len(set(self.evidence_refs)):
            raise ValueError("evidence_refs must not contain duplicates")
        for value in self.evidence_refs:
            require_text(value, "evidence_refs")

        if self.status == "pending":
            if any((self.granted_by, self.granted_at, self.expires_at, self.revoked_by, self.revoked_at, self.reason)):
                raise ValueError("pending grants must not contain decision fields")
            return

        require_identifier(self.granted_by, "granted_by")
        if self.granted_at is None:
            raise ValueError("a decided grant requires granted_at")
        require_aware(self.granted_at, "granted_at")
        if self.granted_at < self.requested_at:
            raise ValueError("granted_at cannot be before requested_at")
        if self.expires_at is None:
            raise ValueError("a decided grant requires expires_at")
        require_aware(self.expires_at, "expires_at")
        if self.expires_at <= self.granted_at:
            raise ValueError("expires_at must be after granted_at")
        require_text(self.reason, "reason")
        if not self.evidence_refs:
            raise ValueError("a decided grant requires evidence_refs")

        if self.status == "revoked":
            require_identifier(self.revoked_by, "revoked_by")
            if self.revoked_at is None:
                raise ValueError("revoked grants require revoked_at")
            require_aware(self.revoked_at, "revoked_at")
            if self.revoked_at < self.granted_at:
                raise ValueError("revoked_at cannot be before granted_at")
        elif self.revoked_by or self.revoked_at:
            raise ValueError("non-revoked grants must not contain revocation fields")

    def as_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "grant_id": self.grant_id,
            "resource_ref": self.resource_ref,
            "subject_ref": self.subject_ref,
            "status": self.status,
            "scopes": list(self.scopes),
            "requested_at": _iso(self.requested_at),
            "policy_version": self.policy_version,
            "evidence_refs": list(self.evidence_refs),
            "granted_by": self.granted_by or None,
            "granted_at": _iso(self.granted_at),
            "expires_at": _iso(self.expires_at),
            "revoked_by": self.revoked_by or None,
            "revoked_at": _iso(self.revoked_at),
            "reason": self.reason or None,
        }
