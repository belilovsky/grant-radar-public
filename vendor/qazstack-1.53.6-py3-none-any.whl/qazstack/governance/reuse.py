"""Reuse-first manifests and project-level enforcement.

The manifest records which QazStack modules a project deliberately adopts and
which local implementations are temporary, reviewed exceptions.  It is kept
separate from the consumer contract: the consumer contract describes the
integration boundary, while this file makes reuse decisions reviewable.
"""

from __future__ import annotations

import json
import os
import re
import tomllib
from datetime import date
from pathlib import Path, PurePosixPath
from typing import Any, Mapping

from qazstack import __version__
from qazstack.contracts.consumer import (
    ConsumerContractError,
    discover_consumer_contract_paths,
    load_consumer_contract,
)

REUSE_SCHEMA_VERSION = "qazstack-reuse-v1"
DEFAULT_REUSE_FILENAME = "qazstack-reuse.json"
REQUIRED_MANIFEST_KEYS = frozenset(
    {"schema_version", "project_id", "qazstack_version", "owner", "adoptions", "local_exceptions"}
)
OPTIONAL_MANIFEST_KEYS = frozenset({"consumer_contract_path"})
MANIFEST_KEYS = REQUIRED_MANIFEST_KEYS | OPTIONAL_MANIFEST_KEYS
ADOPTION_KEYS = frozenset({"module", "capabilities", "reason", "evidence"})
EXCEPTION_KEYS = frozenset({"capability", "reason", "owner", "reviewed_at", "expires_at", "evidence"})
ID_RE = re.compile(r"^[a-z0-9][a-z0-9-]{1,63}$")
MODULE_RE = re.compile(r"^[a-z][a-z0-9_]{1,63}$")
VERSION_RE = re.compile(r"^[0-9]+\.[0-9]+\.[0-9]+$")
SKIP_DISCOVERY_DIRECTORIES = frozenset(
    {".git", ".venv", "venv", "node_modules", "dist", "build", "__pycache__", "tests"}
)


class ReuseManifestError(ValueError):
    """Raised when a reuse-first manifest is invalid."""


def _required_string(record: Mapping[str, Any], key: str) -> str:
    value = record.get(key)
    if not isinstance(value, str) or not value.strip():
        raise ReuseManifestError(f"{key} must be a non-empty string")
    return value


def _unique_strings(value: Any, key: str, *, allow_empty: bool = False) -> tuple[str, ...]:
    if not isinstance(value, list) or any(not isinstance(item, str) or not item.strip() for item in value):
        raise ReuseManifestError(f"{key} must be an array of non-empty strings")
    if not allow_empty and not value:
        raise ReuseManifestError(f"{key} must contain at least one item")
    if len(value) != len(set(value)):
        raise ReuseManifestError(f"{key} must not contain duplicates")
    return tuple(value)


def _safe_evidence_paths(value: Any, key: str, *, allow_empty: bool = False) -> tuple[str, ...]:
    paths = _unique_strings(value, key, allow_empty=allow_empty)
    for item in paths:
        path = PurePosixPath(item)
        if path.is_absolute() or ".." in path.parts:
            raise ReuseManifestError(f"{key} must contain safe project-relative paths")
    return paths


def _safe_project_relative_path(value: Any, key: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ReuseManifestError(f"{key} must be a non-empty string")
    path = PurePosixPath(value)
    if path.is_absolute() or ".." in path.parts:
        raise ReuseManifestError(f"{key} must be a safe project-relative path")
    return value


def _iso_date(value: Any, key: str) -> date:
    if not isinstance(value, str):
        raise ReuseManifestError(f"{key} must be an ISO date")
    try:
        return date.fromisoformat(value)
    except ValueError as exc:
        raise ReuseManifestError(f"{key} must be an ISO date: {exc}") from exc


def validate_reuse_manifest(record: Any, *, strict: bool = False, today: date | None = None) -> None:
    """Validate a reuse-first manifest and optionally enforce review freshness."""
    if not isinstance(record, Mapping):
        raise ReuseManifestError("manifest root must be an object")
    missing = sorted(REQUIRED_MANIFEST_KEYS - record.keys())
    if missing:
        raise ReuseManifestError(f"missing required fields: {', '.join(missing)}")
    unknown = sorted(record.keys() - MANIFEST_KEYS)
    if unknown:
        raise ReuseManifestError(f"unknown fields: {', '.join(unknown)}")
    if record["schema_version"] != REUSE_SCHEMA_VERSION:
        raise ReuseManifestError(f"schema_version must be {REUSE_SCHEMA_VERSION}")
    if "consumer_contract_path" in record:
        _safe_project_relative_path(record["consumer_contract_path"], "consumer_contract_path")

    project_id = _required_string(record, "project_id")
    if not ID_RE.fullmatch(project_id):
        raise ReuseManifestError("project_id must be lowercase kebab-case, 2-64 characters")
    version = _required_string(record, "qazstack_version")
    if not VERSION_RE.fullmatch(version):
        raise ReuseManifestError("qazstack_version must be SemVer")
    _required_string(record, "owner")

    adoptions = record["adoptions"]
    if not isinstance(adoptions, list) or not adoptions:
        raise ReuseManifestError("adoptions must contain at least one adoption")
    adopted_modules: set[str] = set()
    adopted_capabilities: set[str] = set()
    for index, adoption in enumerate(adoptions):
        prefix = f"adoptions[{index}]"
        if not isinstance(adoption, Mapping):
            raise ReuseManifestError(f"{prefix} must be an object")
        unknown_adoption = sorted(adoption.keys() - ADOPTION_KEYS)
        missing_adoption = sorted(ADOPTION_KEYS - adoption.keys())
        if missing_adoption:
            raise ReuseManifestError(f"{prefix} missing fields: {', '.join(missing_adoption)}")
        if unknown_adoption:
            raise ReuseManifestError(f"{prefix} unknown fields: {', '.join(unknown_adoption)}")
        module = _required_string(adoption, "module")
        if not MODULE_RE.fullmatch(module):
            raise ReuseManifestError(f"{prefix}.module must be a lowercase Python module name")
        if module in adopted_modules:
            raise ReuseManifestError(f"module adopted more than once: {module}")
        adopted_modules.add(module)
        capabilities = _unique_strings(adoption["capabilities"], f"{prefix}.capabilities")
        if any(not ID_RE.fullmatch(item) for item in capabilities):
            raise ReuseManifestError(f"{prefix}.capabilities must be lowercase kebab-case")
        duplicate_capabilities = adopted_capabilities & set(capabilities)
        if duplicate_capabilities:
            raise ReuseManifestError(
                f"capabilities adopted more than once: {', '.join(sorted(duplicate_capabilities))}"
            )
        adopted_capabilities.update(capabilities)
        _required_string(adoption, "reason")
        _safe_evidence_paths(adoption["evidence"], f"{prefix}.evidence")

    exceptions = record["local_exceptions"]
    if not isinstance(exceptions, list):
        raise ReuseManifestError("local_exceptions must be an array")
    exception_capabilities: set[str] = set()
    clock = today or date.today()
    for index, exception in enumerate(exceptions):
        prefix = f"local_exceptions[{index}]"
        if not isinstance(exception, Mapping):
            raise ReuseManifestError(f"{prefix} must be an object")
        missing_exception = sorted(EXCEPTION_KEYS - exception.keys())
        unknown_exception = sorted(exception.keys() - EXCEPTION_KEYS)
        if missing_exception:
            raise ReuseManifestError(f"{prefix} missing fields: {', '.join(missing_exception)}")
        if unknown_exception:
            raise ReuseManifestError(f"{prefix} unknown fields: {', '.join(unknown_exception)}")
        capability = _required_string(exception, "capability")
        if not ID_RE.fullmatch(capability):
            raise ReuseManifestError(f"{prefix}.capability must be lowercase kebab-case")
        if capability in exception_capabilities:
            raise ReuseManifestError(f"local exception repeated: {capability}")
        if capability in adopted_capabilities:
            raise ReuseManifestError(f"capability cannot be both adopted and locally excepted: {capability}")
        exception_capabilities.add(capability)
        _required_string(exception, "reason")
        _required_string(exception, "owner")
        reviewed_at = _iso_date(exception["reviewed_at"], f"{prefix}.reviewed_at")
        expires_at = _iso_date(exception["expires_at"], f"{prefix}.expires_at")
        if expires_at < reviewed_at:
            raise ReuseManifestError(f"{prefix}.expires_at must not precede reviewed_at")
        if strict and expires_at < clock:
            raise ReuseManifestError(f"{prefix} expired on {expires_at.isoformat()}")
        _safe_evidence_paths(exception["evidence"], f"{prefix}.evidence")


def reuse_manifest_template(project_id: str, owner: str, *, version: str = __version__) -> dict[str, Any]:
    """Return the minimal explicit reuse decision for a new QazStack project."""
    payload = {
        "schema_version": REUSE_SCHEMA_VERSION,
        "project_id": project_id,
        "qazstack_version": version,
        "owner": owner,
        "adoptions": [
            {
                "module": "core",
                "capabilities": ["app-factory", "configuration", "health"],
                "reason": "Use QazStack's shared application foundation before adding product-specific code.",
                "evidence": ["app/config.py", "app/main.py"],
            }
        ],
        "local_exceptions": [],
    }
    validate_reuse_manifest(payload)
    return payload


def reuse_manifest_from_project(
    project_root: str | Path,
    project_id: str,
    owner: str,
    *,
    version: str = __version__,
) -> dict[str, Any]:
    """Build an initial manifest from real QazStack imports, never guessed modules."""
    root = Path(project_root).resolve()
    imports: dict[str, set[str]] = {}
    pattern = re.compile(r"^\s*(?:from|import)\s+qazstack\.([a-z][a-z0-9_]*)", flags=re.MULTILINE)
    for current_root, directories, files in os.walk(root):
        directories[:] = [directory for directory in directories if directory not in SKIP_DISCOVERY_DIRECTORIES]
        current = Path(current_root)
        for filename in files:
            if not filename.endswith(".py"):
                continue
            path = current / filename
            try:
                modules = set(pattern.findall(path.read_text(encoding="utf-8")))
            except (OSError, UnicodeDecodeError):
                continue
            relative = path.relative_to(root).as_posix()
            for module in modules:
                imports.setdefault(module, set()).add(relative)
    if not imports:
        raise ReuseManifestError(
            "no QazStack module imports found; create the manifest manually for HTTP, TypeScript or planned adoption"
        )
    payload = {
        "schema_version": REUSE_SCHEMA_VERSION,
        "project_id": project_id,
        "qazstack_version": version,
        "owner": owner,
        "adoptions": [
            {
                "module": module,
                "capabilities": [module.replace("_", "-")],
                "reason": f"Existing project source imports the shared qazstack.{module} module.",
                "evidence": sorted(paths),
            }
            for module, paths in sorted(imports.items())
        ],
        "local_exceptions": [],
    }
    validate_reuse_manifest(payload)
    return payload


def load_reuse_manifest(path: str | Path, *, strict: bool = False) -> dict[str, Any]:
    manifest_path = Path(path)
    try:
        payload = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ReuseManifestError(f"failed to load {manifest_path}: {exc}") from exc
    validate_reuse_manifest(payload, strict=strict)
    return dict(payload)


def _declares_qazstack_dependency(project_root: Path) -> bool:
    dependency_re = re.compile(r"^qazstack(?:\[[^\]]+\])?(?:\s*[<>=!~].*)?$", flags=re.IGNORECASE)
    pyproject = project_root / "pyproject.toml"
    if pyproject.exists():
        try:
            project = tomllib.loads(pyproject.read_text(encoding="utf-8")).get("project", {})
        except (OSError, tomllib.TOMLDecodeError):
            project = {}
        declared_dependencies = list(project.get("dependencies", []))
        optional_dependencies = project.get("optional-dependencies", {})
        if isinstance(optional_dependencies, Mapping):
            for group in optional_dependencies.values():
                if isinstance(group, list):
                    declared_dependencies.extend(group)
        if any(isinstance(dependency, str) and dependency_re.match(dependency) for dependency in declared_dependencies):
            return True

    requirement_re = re.compile(r"^\s*qazstack(?:\[[^\]]+\])?\s*(?:[<>=!~].*)?$", flags=re.IGNORECASE)
    wheel_re = re.compile(r"(?:^|[/\\])qazstack-[0-9][A-Za-z0-9_.!+-]*\.whl$", flags=re.IGNORECASE)
    for requirements in project_root.glob("requirements*.txt"):
        try:
            lines = requirements.read_text(encoding="utf-8").splitlines()
        except OSError:
            continue
        for line in lines:
            candidate = line.split("#", 1)[0].strip()
            if requirement_re.fullmatch(candidate) or wheel_re.search(candidate):
                return True

    runtime_paths: list[Path] = [project_root / ".env.example"]
    runtime_paths.extend(sorted(project_root.glob("Dockerfile*")))
    runtime_paths.extend(sorted(project_root.glob("docker-compose*.yml")))
    runtime_paths.extend(sorted(project_root.glob("docker-compose*.yaml")))
    runtime_paths.extend(sorted(project_root.glob("compose*.yml")))
    runtime_paths.extend(sorted(project_root.glob("compose*.yaml")))
    for path in runtime_paths:
        if not path.is_file():
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        if (
            "QAZSTACK_PATH" in text
            or "QAZSTACK_MODE" in text
            or "qazstack-*.whl" in text
            or "/opt/qazstack" in text
            or "site-packages/qazstack" in text
        ):
            return True
    return False


def check_project_reuse(project_root: str | Path, *, strict: bool = True) -> dict[str, Any]:
    """Check manifest, consumer contract, dependency and declared source evidence."""
    root = Path(project_root).resolve()
    errors: list[str] = []
    warnings: list[str] = []
    manifest: dict[str, Any] | None = None
    contract = None

    manifest_path = root / DEFAULT_REUSE_FILENAME
    try:
        manifest = load_reuse_manifest(manifest_path, strict=strict)
    except ReuseManifestError as exc:
        errors.append(str(exc))

    contract_path = root / "qazstack-consumer.json"
    explicit_contract_path = (
        root / manifest["consumer_contract_path"]
        if manifest is not None and isinstance(manifest.get("consumer_contract_path"), str)
        else None
    )
    if explicit_contract_path is not None:
        contract_path = explicit_contract_path
    elif not contract_path.is_file():
        discovered = discover_consumer_contract_paths(root)
        if len(discovered) == 1:
            contract_path = discovered[0]
        elif len(discovered) > 1:
            errors.append("multiple consumer contracts found; keep one canonical contract per project")
    try:
        contract = load_consumer_contract(contract_path, strict=False)
    except (OSError, ConsumerContractError, json.JSONDecodeError) as exc:
        errors.append(f"invalid consumer contract: {exc}")

    if (
        contract is not None
        and contract.integration_mode == "python-package"
        and not _declares_qazstack_dependency(root)
    ):
        errors.append("pyproject.toml must declare a QazStack dependency")

    if manifest is not None:
        if contract is not None and manifest["project_id"] != contract.project_id:
            errors.append("reuse manifest and consumer contract project_id values differ")
        if (
            contract is not None
            and contract.qazstack_version != "contract-only"
            and manifest["qazstack_version"] != contract.qazstack_version
        ):
            errors.append("reuse manifest and consumer contract QazStack versions differ")
        if manifest["qazstack_version"] != __version__:
            warnings.append(f"manifest targets QazStack {manifest['qazstack_version']}; checker is {__version__}")
        for adoption in manifest["adoptions"]:
            module = adoption["module"]
            evidence_seen = False
            for relative in adoption["evidence"]:
                evidence_path = root / relative
                if not evidence_path.is_file():
                    errors.append(f"missing reuse evidence: {relative}")
                    continue
                evidence_seen = True
                if (
                    evidence_path.suffix == ".py"
                    and contract is not None
                    and contract.integration_mode == "python-package"
                ):
                    text = evidence_path.read_text(encoding="utf-8", errors="replace")
                    if f"qazstack.{module}" not in text and not (module == "core" and "from qazstack import" in text):
                        warnings.append(f"{relative} does not visibly import qazstack.{module}")
            if not evidence_seen:
                errors.append(f"adoption {module} has no existing evidence file")
        for exception in manifest["local_exceptions"]:
            for relative in exception["evidence"]:
                if not (root / relative).is_file():
                    errors.append(f"missing local-exception evidence: {relative}")

    return {
        "schema_version": "qazstack-reuse-check-v1",
        "project_root": str(root),
        "status": "error" if errors else ("warning" if warnings else "ok"),
        "project_id": manifest["project_id"] if manifest else None,
        "counts": {"errors": len(errors), "warnings": len(warnings)},
        "errors": errors,
        "warnings": warnings,
    }
