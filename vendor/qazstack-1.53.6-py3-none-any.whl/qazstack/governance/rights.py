"""Rights-clearance decisions that keep product policy and holder PII local."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from qazstack.contracts._validation import require_aware, require_identifier, require_one_of, require_text

RIGHTS_CLEARANCE_SCHEMA = "qazstack-rights-clearance-v1"
RIGHTS_CLEARANCE_STATUSES = frozenset({"unreviewed", "review-required", "cleared", "restricted", "denied", "expired"})


def _iso(value: datetime | None) -> str | None:
    if value is None:
        return None
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


@dataclass(frozen=True, slots=True)
class RightsClearance:
    """A review decision over named uses of one content item."""

    item_ref: str
    status: str
    requested_uses: tuple[str, ...]
    permitted_uses: tuple[str, ...]
    policy_version: str
    evidence_refs: tuple[str, ...] = ()
    decided_by: str = ""
    decided_at: datetime | None = None
    expires_at: datetime | None = None
    reason: str = ""
    schema_version: str = field(default=RIGHTS_CLEARANCE_SCHEMA, init=False)

    def __post_init__(self) -> None:
        require_identifier(self.item_ref, "item_ref")
        require_one_of(self.status, RIGHTS_CLEARANCE_STATUSES, "status")
        require_identifier(self.policy_version, "policy_version")
        self._validate_uses()
        if len(self.evidence_refs) != len(set(self.evidence_refs)):
            raise ValueError("evidence_refs must not contain duplicates")
        for value in self.evidence_refs:
            require_text(value, "evidence_refs")

        decided = self.status in {"cleared", "restricted", "denied", "expired"}
        if decided:
            require_identifier(self.decided_by, "decided_by")
            if self.decided_at is None:
                raise ValueError("a terminal rights decision requires decided_at")
            require_aware(self.decided_at, "decided_at")
            require_text(self.reason, "reason")
            if not self.evidence_refs:
                raise ValueError("a terminal rights decision requires evidence_refs")
        elif self.decided_by or self.decided_at or self.expires_at or self.reason:
            raise ValueError("an open rights decision must not contain decision fields")

        if self.expires_at is not None:
            require_aware(self.expires_at, "expires_at")
            if self.decided_at is None or self.expires_at <= self.decided_at:
                raise ValueError("expires_at must be after decided_at")
        if self.status in {"unreviewed", "review-required", "denied", "expired"} and self.permitted_uses:
            raise ValueError(f"{self.status} rights must not contain permitted_uses")

    def _validate_uses(self) -> None:
        if not self.requested_uses:
            raise ValueError("requested_uses must not be empty")
        if len(self.requested_uses) != len(set(self.requested_uses)):
            raise ValueError("requested_uses must not contain duplicates")
        if len(self.permitted_uses) != len(set(self.permitted_uses)):
            raise ValueError("permitted_uses must not contain duplicates")
        for value in (*self.requested_uses, *self.permitted_uses):
            require_identifier(value, "use")
        if not set(self.permitted_uses).issubset(self.requested_uses):
            raise ValueError("permitted_uses must be a subset of requested_uses")
        if self.status == "cleared" and set(self.permitted_uses) != set(self.requested_uses):
            raise ValueError("cleared rights must permit every requested use")
        if self.status == "restricted" and (
            not self.permitted_uses or set(self.permitted_uses) == set(self.requested_uses)
        ):
            raise ValueError("restricted rights must permit a non-empty subset of requested uses")

    def as_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "item_ref": self.item_ref,
            "status": self.status,
            "requested_uses": list(self.requested_uses),
            "permitted_uses": list(self.permitted_uses),
            "policy_version": self.policy_version,
            "evidence_refs": list(self.evidence_refs),
            "decided_by": self.decided_by or None,
            "decided_at": _iso(self.decided_at),
            "expires_at": _iso(self.expires_at),
            "reason": self.reason or None,
        }
