"""Workspace-level QazStack consumer inventory helpers.

The module is read-only by design: it parses the Codex workspace index,
validates checked-in consumer contracts and classifies unresolved rows without
guessing deployment ownership.
"""

from __future__ import annotations

import json
import re
import subprocess
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

import httpx

from qazstack.contracts import (
    ConsumerContractError,
    discover_consumer_contract_paths,
    load_consumer_contract,
)

PROVIDER_PRODUCTS = frozenset({"QazStack", "AV DS 4"})
OWNER_BLOCKED_PRODUCTS = frozenset()
NOT_APPLICABLE_PRODUCTS = {
    "QTask": "No proven QazStack consumer boundary; current evidence shows QazCompute and AV DS usage only.",
}
SUPPORTING_CONTRACT_ROOTS = {
    "EdPol": (Path("/Users/belilovsky/Documents/Codex/2026-07-08/edpol-pro-codex-text-link-https/work/editorial-hub"),),
    "KJ": (Path("/Users/belilovsky/Documents/Codex/2026-04-28/codex-kj-qdev-run-codex-cli/tokaev-dashboard"),),
    "Papa / Collect": (Path("/Users/belilovsky/Documents/Codex/2026-05-17-collect-family/knife-collection"),),
}
INDEX_FILENAME = "CODEX_PROJECT_INDEX.md"


@dataclass(frozen=True, slots=True)
class PortfolioProject:
    """One product row from CODEX_PROJECT_INDEX.md."""

    product: str
    surface: str
    checkout: Path | None


@dataclass(frozen=True, slots=True)
class PortfolioInventoryRow:
    """Classified QazStack discovery status for a workspace product row."""

    product: str
    surface: str
    checkout: str | None
    status: str
    contract_path: str | None = None
    contract_project_id: str | None = None
    contract_status: str | None = None
    note: str = ""
    dirty: bool | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "product": self.product,
            "surface": self.surface,
            "checkout": self.checkout,
            "status": self.status,
            "contract_path": self.contract_path,
            "contract_project_id": self.contract_project_id,
            "contract_status": self.contract_status,
            "note": self.note,
            "dirty": self.dirty,
        }


def load_portfolio_projects(workspace_root: str | Path) -> list[PortfolioProject]:
    """Parse the canonical Codex project index table."""
    root = Path(workspace_root).expanduser().resolve()
    index = root / INDEX_FILENAME
    if not index.is_file():
        raise FileNotFoundError(f"missing workspace index: {index}")

    rows: list[PortfolioProject] = []
    in_table = False
    for raw_line in index.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if line.startswith("| Codex Project |"):
            in_table = True
            continue
        if not in_table:
            continue
        if not line.startswith("|"):
            if rows:
                break
            continue
        if set(line.replace("|", "").strip()) <= {"-", " "}:
            continue
        columns = [column.strip() for column in line.strip("|").split("|")]
        if len(columns) < 3:
            continue
        checkout = _extract_first_backtick_path(columns[2])
        rows.append(PortfolioProject(product=columns[0], surface=columns[1], checkout=checkout))
    return rows


def inventory_portfolio(workspace_root: str | Path, *, strict: bool = False) -> list[PortfolioInventoryRow]:
    """Classify every workspace-index row by QazStack consumer discovery state."""
    projects = load_portfolio_projects(workspace_root)
    rows: list[PortfolioInventoryRow] = []
    for project in projects:
        rows.append(_classify_project(project, strict=strict))
    return rows


def portfolio_summary(rows: Iterable[PortfolioInventoryRow]) -> dict[str, int]:
    """Return stable counters for portfolio reports."""
    materialized = list(rows)
    providers = sum(row.status == "provider" for row in materialized)
    discoverable = sum(row.status == "discoverable" for row in materialized)
    consumers = len(materialized) - providers
    return {
        "workspace_rows": len(materialized),
        "provider_rows": providers,
        "not_applicable_rows": sum(row.status == "not-applicable" for row in materialized),
        "consumer_rows": consumers - sum(row.status == "not-applicable" for row in materialized),
        "discoverable_rows": discoverable,
        "consumer_discoverable_rows": discoverable,
        "blocked_rows": sum(row.status in {"owner-blocked", "dirty-blocked"} for row in materialized),
        "missing_rows": sum(row.status in {"missing-contract", "missing-checkout"} for row in materialized),
        "invalid_rows": sum(row.status == "invalid-contract" for row in materialized),
    }


def portfolio_inventory_payload(workspace_root: str | Path, *, strict: bool = False) -> dict[str, Any]:
    rows = inventory_portfolio(workspace_root, strict=strict)
    return {
        "schema_version": "qazstack-portfolio-consumer-inventory-v1",
        "workspace_root": str(Path(workspace_root).expanduser().resolve()),
        "strict": strict,
        "summary": portfolio_summary(rows),
        "rows": [row.to_dict() for row in rows],
    }


def portfolio_runtime_smoke(
    workspace_root: str | Path,
    *,
    strict: bool = True,
    timeout: float = 10.0,
    retries: int = 1,
    excluded_products: Iterable[str] = (),
    client: Any | None = None,
) -> dict[str, Any]:
    """Probe declared production runtime URLs without changing any consumer.

    This supplements, rather than replaces, schema validation. A contract can
    remain discoverable while its runtime is unavailable; callers opt into a
    non-zero exit with ``--fail-on-runtime-error`` when that distinction is a
    release requirement. Products excluded by an operator are reported as
    skipped, never silently omitted.
    """
    if retries < 0:
        raise ValueError("retries must not be negative")
    excluded = set(excluded_products)
    results: list[dict[str, Any]] = []
    skipped: list[dict[str, str]] = []
    for row in inventory_portfolio(workspace_root, strict=strict):
        if row.status != "discoverable" or not row.contract_path:
            continue
        if row.product in excluded:
            skipped.append({"product": row.product, "reason": "operator-excluded"})
            continue
        contract = load_consumer_contract(Path(row.contract_path), strict=strict)
        if contract.lifecycle != "production":
            skipped.append({"product": row.product, "reason": f"lifecycle={contract.lifecycle}"})
            continue
        for url in contract.evidence.runtime_urls:
            results.append(
                _runtime_probe(
                    f"{row.product}: {url}",
                    url,
                    timeout=timeout,
                    retries=retries,
                    client=client,
                )
            )

    errors = sum(result["status"] == "error" for result in results)
    warnings = sum(result["status"] == "warning" for result in results)
    return {
        "status": "error" if errors else ("warning" if warnings else "ok"),
        "counts": {"total": len(results), "errors": errors, "warnings": warnings, "skipped": len(skipped)},
        "checks": results,
        "skipped": skipped,
    }


def portfolio_evidence_freshness(
    workspace_root: str | Path,
    *,
    strict: bool = True,
    max_age_days: int = 30,
    excluded_products: Iterable[str] = (),
    now: datetime | None = None,
) -> dict[str, Any]:
    """Check whether checked-in consumer evidence is still operationally fresh.

    This is an operator SLA, not a schema rule. It allows the portfolio monitor
    to warn when a contract remains valid but the proof behind it is getting
    old. Callers decide whether stale evidence should fail a release gate.
    """
    if max_age_days < 1:
        raise ValueError("max_age_days must be positive")
    checked_at = _as_utc(now or datetime.now(timezone.utc))
    excluded = set(excluded_products)
    checks: list[dict[str, Any]] = []
    skipped: list[dict[str, str]] = []

    for row in inventory_portfolio(workspace_root, strict=strict):
        if row.status != "discoverable" or not row.contract_path:
            continue
        if row.product in excluded:
            skipped.append({"product": row.product, "reason": "operator-excluded"})
            continue
        contract = load_consumer_contract(Path(row.contract_path), strict=strict)
        if contract.lifecycle != "production":
            skipped.append({"product": row.product, "reason": f"lifecycle={contract.lifecycle}"})
            continue
        verified_at = contract.evidence.verified_at
        if not verified_at:
            checks.append(
                {
                    "product": row.product,
                    "project_id": contract.project_id,
                    "contract_path": row.contract_path,
                    "lifecycle": contract.lifecycle,
                    "verified_at": None,
                    "age_days": None,
                    "max_age_days": max_age_days,
                    "status": "warning",
                    "detail": "missing evidence.verified_at",
                }
            )
            continue

        verified_dt = _parse_contract_datetime(verified_at)
        age_seconds = (checked_at - verified_dt).total_seconds()
        age_days = round(age_seconds / 86_400, 1)
        if age_seconds < -300:
            status = "error"
            detail = "evidence.verified_at is in the future"
        elif age_days > max_age_days:
            status = "warning"
            detail = f"evidence older than {max_age_days} days"
        else:
            status = "ok"
            detail = f"evidence age {age_days} days"
        checks.append(
            {
                "product": row.product,
                "project_id": contract.project_id,
                "contract_path": row.contract_path,
                "lifecycle": contract.lifecycle,
                "verified_at": verified_at,
                "age_days": max(0, age_days),
                "max_age_days": max_age_days,
                "status": status,
                "detail": detail,
            }
        )

    errors = sum(check["status"] == "error" for check in checks)
    warnings = sum(check["status"] == "warning" for check in checks)
    return {
        "status": "error" if errors else ("warning" if warnings else "ok"),
        "checked_at": checked_at.isoformat(timespec="seconds").replace("+00:00", "Z"),
        "max_age_days": max_age_days,
        "counts": {"total": len(checks), "errors": errors, "warnings": warnings, "skipped": len(skipped)},
        "checks": checks,
        "skipped": skipped,
    }


def render_portfolio_freshness_digest(freshness: dict[str, Any], *, limit: int = 8) -> str:
    """Render a compact evidence freshness summary for daily monitors."""
    counts = freshness["counts"]
    lines = [
        "Evidence freshness",
        (
            f"Checks: {counts['total']} | errors: {counts['errors']} | "
            f"warnings: {counts['warnings']} | skipped: {counts['skipped']} | "
            f"max age: {freshness['max_age_days']}d"
        ),
    ]
    attention = [check for check in freshness["checks"] if check["status"] != "ok"]
    for check in attention[:limit]:
        verified = check["verified_at"] or "-"
        lines.append(f"- {check['status']}: {check['product']} ({check['detail']}; verified_at={verified})")
    if len(attention) > limit:
        lines.append(f"- ...and {len(attention) - limit} more")
    for skipped in freshness["skipped"][:limit]:
        lines.append(f"- skipped: {skipped['product']} ({skipped['reason']})")
    return "\n".join(lines) + "\n"


def portfolio_monitor_changes(current: dict[str, Any], previous: dict[str, Any]) -> list[str]:
    """Return human-readable monitor changes between two portfolio payloads."""
    changes: list[str] = []
    changes.extend(_row_status_changes(current.get("rows", []), previous.get("rows", [])))
    changes.extend(
        _named_status_changes(
            "runtime",
            current.get("runtime_smoke", {}).get("checks", []),
            previous.get("runtime_smoke", {}).get("checks", []),
            key_name="name",
        )
    )
    changes.extend(
        _named_status_changes(
            "evidence",
            current.get("evidence_freshness", {}).get("checks", []),
            previous.get("evidence_freshness", {}).get("checks", []),
            key_name="product",
        )
    )
    return changes


def render_portfolio_changes_digest(changes: Iterable[str], *, limit: int = 12) -> str:
    """Render a concise state-diff section for noisy recurring monitors."""
    materialized = list(changes)
    if not materialized:
        return "Portfolio changes\nNo changes from previous state.\n"
    lines = ["Portfolio changes"]
    lines.extend(f"- {change}" for change in materialized[:limit])
    if len(materialized) > limit:
        lines.append(f"- ...and {len(materialized) - limit} more")
    return "\n".join(lines) + "\n"


def render_portfolio_runtime_digest(runtime: dict[str, Any], *, limit: int = 8) -> str:
    """Render a concise, operator-facing runtime availability summary."""
    counts = runtime["counts"]
    lines = [
        "Runtime smoke",
        (
            f"Checks: {counts['total']} | errors: {counts['errors']} | "
            f"warnings: {counts['warnings']} | skipped: {counts['skipped']}"
        ),
    ]
    attention = [check for check in runtime["checks"] if check["status"] != "ok"]
    for check in attention[:limit]:
        lines.append(f"- {check['status']}: {check['name']} ({check['detail']})")
    if len(attention) > limit:
        lines.append(f"- ...and {len(attention) - limit} more")
    for skipped in runtime["skipped"][:limit]:
        lines.append(f"- skipped: {skipped['product']} ({skipped['reason']})")
    return "\n".join(lines) + "\n"


def _runtime_probe(name: str, url: str, *, timeout: float, retries: int, client: Any | None) -> dict[str, Any]:
    """Probe one URL while keeping the governance module free of ORM imports."""
    started = time.monotonic()
    owned = client is None
    active = client or httpx.Client(timeout=timeout, follow_redirects=False)
    attempts = 0
    try:
        for attempt in range(retries + 1):
            attempts = attempt + 1
            try:
                response = active.get(url)
                code = response.status_code
                status = "ok" if 200 <= code < 400 else ("warning" if code in {401, 403, 429} else "error")
                detail = f"HTTP {code}"
                if status != "error" or code < 500 or attempt == retries:
                    break
            except httpx.HTTPError as exc:
                status = "error"
                detail = exc.__class__.__name__
                if attempt == retries:
                    break
    finally:
        if owned:
            active.close()
    if attempts > 1:
        detail = f"{detail} after {attempts} attempts"
    return {
        "name": name,
        "status": status,
        "elapsed_ms": round((time.monotonic() - started) * 1000, 1),
        "detail": detail,
    }


def _parse_contract_datetime(value: str) -> datetime:
    return _as_utc(datetime.fromisoformat(value.replace("Z", "+00:00")))


def _as_utc(value: datetime) -> datetime:
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc)


def _row_status_changes(current_rows: Iterable[dict[str, Any]], previous_rows: Iterable[dict[str, Any]]) -> list[str]:
    current = {row["product"]: row for row in current_rows}
    previous = {row["product"]: row for row in previous_rows}
    changes: list[str] = []
    for product in sorted(previous.keys() - current.keys()):
        changes.append(f"inventory {product}: disappeared")
    for product in sorted(current.keys() - previous.keys()):
        changes.append(f"inventory {product}: new {current[product].get('status', 'unknown')}")
    for product in sorted(current.keys() & previous.keys()):
        old = previous[product].get("status")
        new = current[product].get("status")
        if old != new:
            changes.append(f"inventory {product}: {old} -> {new}")
    return changes


def _named_status_changes(
    prefix: str,
    current_checks: Iterable[dict[str, Any]],
    previous_checks: Iterable[dict[str, Any]],
    *,
    key_name: str,
) -> list[str]:
    current = {check[key_name]: check for check in current_checks if key_name in check}
    previous = {check[key_name]: check for check in previous_checks if key_name in check}
    changes: list[str] = []
    for key in sorted(previous.keys() - current.keys()):
        changes.append(f"{prefix} {key}: removed")
    for key in sorted(current.keys() - previous.keys()):
        changes.append(f"{prefix} {key}: new {current[key].get('status', 'unknown')}")
    for key in sorted(current.keys() & previous.keys()):
        old = previous[key].get("status")
        new = current[key].get("status")
        if old != new:
            changes.append(f"{prefix} {key}: {old} -> {new}")
    return changes


def portfolio_regressions(payload: dict[str, Any], baseline: dict[str, Any]) -> list[str]:
    """Return meaningful consumer-discovery regressions against a saved baseline.

    The comparison ignores absolute checkout paths and report timestamps. It
    only fails a monitor when an already discoverable consumer is lost, overall
    discoverability falls, or the invalid-contract count increases.
    """
    current_rows = {row["product"]: row for row in payload.get("rows", [])}
    baseline_rows = {row["product"]: row for row in baseline.get("rows", [])}
    regressions: list[str] = []

    for product, baseline_row in baseline_rows.items():
        if baseline_row.get("status") != "discoverable":
            continue
        current = current_rows.get(product)
        if current is None:
            regressions.append(f"{product}: workspace row disappeared")
        elif current.get("status") != "discoverable":
            regressions.append(f"{product}: discoverable -> {current.get('status', 'unknown')}")

    baseline_summary = baseline.get("summary", {})
    current_summary = payload.get("summary", {})
    if current_summary.get("consumer_discoverable_rows", 0) < baseline_summary.get("consumer_discoverable_rows", 0):
        regressions.append("discoverable consumer coverage decreased")
    if current_summary.get("invalid_rows", 0) > baseline_summary.get("invalid_rows", 0):
        regressions.append("invalid consumer contract count increased")
    return regressions


def render_portfolio_inventory_markdown(payload: dict[str, Any]) -> str:
    """Render a human-readable report from a payload returned by portfolio_inventory_payload."""
    summary = payload["summary"]
    lines = [
        "# QazStack portfolio consumer inventory",
        "",
        f"Workspace: `{payload['workspace_root']}`",
        f"Strict validation: `{str(payload['strict']).lower()}`",
        "",
        "## Summary",
        "",
        f"- Workspace rows: {summary['workspace_rows']}",
        f"- Provider rows: {summary['provider_rows']}",
        f"- Not applicable rows: {summary['not_applicable_rows']}",
        f"- Consumer rows: {summary['consumer_rows']}",
        f"- Discoverable consumer rows: {summary['consumer_discoverable_rows']}",
        f"- Blocked rows: {summary['blocked_rows']}",
        f"- Missing rows: {summary['missing_rows']}",
        f"- Invalid rows: {summary['invalid_rows']}",
        "",
        "## Rows",
        "",
        "| Product | Status | Contract | Note |",
        "| --- | --- | --- | --- |",
    ]
    for row in payload["rows"]:
        contract = row["contract_path"] or "-"
        note = row["note"] or "-"
        lines.append(f"| {row['product']} | `{row['status']}` | `{contract}` | {note} |")
    return "\n".join(lines) + "\n"


def render_portfolio_inventory_digest(
    payload: dict[str, Any], *, limit: int = 8, regressions: Iterable[str] = ()
) -> str:
    """Render a compact operator-facing digest for chat/Telegram monitors."""
    summary = payload["summary"]
    rows = payload["rows"]
    consumers = summary["consumer_rows"]
    discoverable = summary["consumer_discoverable_rows"]
    percent = round(discoverable / consumers * 100) if consumers else 100
    attention = [
        row
        for row in rows
        if row["status"]
        in {
            "invalid-contract",
            "missing-contract",
            "missing-checkout",
            "dirty-blocked",
            "owner-blocked",
            "not-applicable",
        }
    ]
    regression_list = list(regressions)
    lines = [
        "QazStack MCP inventory",
        f"Coverage: {discoverable}/{consumers} consumers ({percent}%)",
        f"Invalid contracts: {summary['invalid_rows']}",
        f"Blocked/not-applicable rows: {summary['blocked_rows'] + summary['not_applicable_rows']}",
    ]
    if regression_list:
        lines.extend(["", "Baseline regressions:"])
        lines.extend(f"- {regression}" for regression in regression_list)
    else:
        lines.append("Baseline: no regressions.")
    if attention:
        lines.append("")
        lines.append("Needs attention:")
        for row in attention[:limit]:
            lines.append(f"- {row['product']}: {row['status']} - {row['note']}")
        if len(attention) > limit:
            lines.append(f"- ...and {len(attention) - limit} more")
    else:
        lines.append("")
        lines.append("No attention rows.")
    lines.extend(
        [
            "",
            "Next safe actions:",
            "- Keep invalid contracts at 0.",
            "- Resolve owner-blocked rows only from owner/runtime evidence.",
            "- Add contracts to dirty checkouts only during product cleanup passes.",
        ]
    )
    return "\n".join(lines) + "\n"


def _classify_project(project: PortfolioProject, *, strict: bool) -> PortfolioInventoryRow:
    checkout = str(project.checkout) if project.checkout else None
    if project.product in PROVIDER_PRODUCTS:
        return PortfolioInventoryRow(
            product=project.product,
            surface=project.surface,
            checkout=checkout,
            status="provider",
            note="Provider row; excluded from ordinary consumer coverage.",
        )
    if not project.checkout:
        return PortfolioInventoryRow(
            product=project.product,
            surface=project.surface,
            checkout=None,
            status="missing-checkout",
            note="No checkout path found in CODEX_PROJECT_INDEX.md.",
        )
    if not project.checkout.exists():
        return PortfolioInventoryRow(
            product=project.product,
            surface=project.surface,
            checkout=checkout,
            status="missing-checkout",
            note="Checkout path does not exist locally.",
        )

    if project.product in NOT_APPLICABLE_PRODUCTS:
        return PortfolioInventoryRow(
            product=project.product,
            surface=project.surface,
            checkout=checkout,
            status="not-applicable",
            note=NOT_APPLICABLE_PRODUCTS[project.product],
            dirty=_git_dirty(project.checkout),
        )

    contracts = _validated_contracts(project.checkout, strict=strict)
    for related_root in SUPPORTING_CONTRACT_ROOTS.get(project.product, ()):
        if related_root.exists():
            contracts.extend(_validated_contracts(related_root, strict=strict))
    dirty = _git_dirty(project.checkout)
    first_contract = contracts[0] if contracts else None

    if project.product in OWNER_BLOCKED_PRODUCTS:
        return PortfolioInventoryRow(
            product=project.product,
            surface=project.surface,
            checkout=checkout,
            status="owner-blocked",
            contract_path=str(first_contract["path"]) if first_contract else None,
            contract_project_id=first_contract.get("project_id") if first_contract else None,
            contract_status=first_contract.get("status") if first_contract else None,
            note="Owner/source-runtime mapping is blocked; child contracts are evidence, not parent-row proof.",
            dirty=dirty,
        )

    invalid = next((contract for contract in contracts if contract["status"] == "invalid"), None)
    if invalid:
        return PortfolioInventoryRow(
            product=project.product,
            surface=project.surface,
            checkout=checkout,
            status="invalid-contract",
            contract_path=str(invalid["path"]),
            contract_project_id=None,
            contract_status="invalid",
            note=invalid.get("error", "Consumer contract is invalid."),
            dirty=dirty,
        )
    if first_contract:
        return PortfolioInventoryRow(
            product=project.product,
            surface=project.surface,
            checkout=checkout,
            status="discoverable",
            contract_path=str(first_contract["path"]),
            contract_project_id=first_contract.get("project_id"),
            contract_status=first_contract.get("status"),
            note="Schema-valid checked-in consumer contract discovered.",
            dirty=dirty,
        )
    if dirty:
        return PortfolioInventoryRow(
            product=project.product,
            surface=project.surface,
            checkout=checkout,
            status="dirty-blocked",
            note="No contract found and checkout has unrelated local changes; handle in product cleanup pass.",
            dirty=dirty,
        )
    return PortfolioInventoryRow(
        product=project.product,
        surface=project.surface,
        checkout=checkout,
        status="missing-contract",
        note="No checked-in QazStack consumer contract found.",
        dirty=dirty,
    )


def _validated_contracts(root: Path, *, strict: bool) -> list[dict[str, str | Path | None]]:
    records: list[dict[str, str | Path | None]] = []
    try:
        paths = discover_consumer_contract_paths(root)
    except ConsumerContractError as exc:
        return [{"path": root, "project_id": None, "status": "invalid", "error": str(exc)}]
    for path in paths:
        try:
            contract = load_consumer_contract(path, strict=strict)
        except (OSError, json.JSONDecodeError, ConsumerContractError) as exc:
            records.append({"path": path, "project_id": None, "status": "invalid", "error": str(exc)})
            continue
        records.append({"path": path, "project_id": contract.project_id, "status": "valid", "error": None})
    return records


def _git_dirty(path: Path) -> bool | None:
    git_root = _nearest_git_root(path)
    if git_root is None:
        return None
    result = subprocess.run(
        ["git", "-C", str(git_root), "status", "--short"],
        check=False,
        capture_output=True,
        text=True,
        timeout=10,
    )
    if result.returncode != 0:
        return None
    return bool(result.stdout.strip())


def _nearest_git_root(path: Path) -> Path | None:
    current = path.resolve()
    if current.is_file():
        current = current.parent
    for candidate in (current, *current.parents):
        if (candidate / ".git").exists():
            return candidate
    return None


def _extract_first_backtick_path(value: str) -> Path | None:
    match = re.search(r"`(/[^`]+)`", value)
    if not match:
        return None
    return Path(match.group(1)).expanduser()
