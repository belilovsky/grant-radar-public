"""Strict, versioned payload-profile registry for data-record consumers.

The envelope stays stable across domains, while this registry gives each
record type one reviewed payload shape. Unknown record types and non-approved
profiles fail closed; no semantic inference or source-specific coercion is
performed here.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any, Mapping

from jsonschema import Draft202012Validator, FormatChecker

PROFILE_REGISTRY_SCHEMA_VERSION = "qazstack-payload-profile-registry-v1"
_RESOURCE_ROOT = Path(__file__).resolve().parent / "resources"
REGISTRY_PATH = _RESOURCE_ROOT / "payload-profile-registry.v1.json"
REGISTRY_SCHEMA_PATH = _RESOURCE_ROOT / "payload-profile-registry.v1.schema.json"


class PayloadProfileError(ValueError):
    """Raised when a profile registry or payload does not pass its contract."""


def _read_json(path: Path, *, label: str) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise PayloadProfileError(f"{label} is unavailable or invalid JSON") from exc
    if not isinstance(value, dict):
        raise PayloadProfileError(f"{label} must be a JSON object")
    return value


@dataclass(frozen=True, slots=True)
class PayloadProfile:
    """One immutable payload schema binding."""

    profile_id: str
    profile_version: str
    status: str
    record_types: tuple[str, ...]
    schema_ref: str
    description: str
    canonicalization: Mapping[str, str]
    schema: Mapping[str, Any]

    def validate(self, payload: Mapping[str, Any]) -> dict[str, Any]:
        if not isinstance(payload, Mapping):
            raise PayloadProfileError(f"{self.profile_id}: payload must be an object")
        errors = sorted(
            Draft202012Validator(self.schema, format_checker=FormatChecker()).iter_errors(payload),
            key=lambda error: list(error.path),
        )
        if errors:
            location = "/".join(str(item) for item in errors[0].path) or "$"
            raise PayloadProfileError(f"{self.profile_id}: payload at {location} {errors[0].message}")
        return dict(payload)


@dataclass(frozen=True, slots=True)
class PayloadProfileRegistry:
    """Validated registry with unambiguous record-type resolution."""

    registry_version: str
    profiles: tuple[PayloadProfile, ...]

    def by_id(self, profile_id: str) -> PayloadProfile:
        for profile in self.profiles:
            if profile.profile_id == profile_id:
                return profile
        raise PayloadProfileError(f"unknown payload profile: {profile_id}")

    def for_record_type(
        self,
        record_type: str,
        *,
        include_non_approved: bool = False,
    ) -> PayloadProfile:
        matches = [
            profile
            for profile in self.profiles
            if record_type in profile.record_types and (include_non_approved or profile.status == "approved")
        ]
        if not matches:
            raise PayloadProfileError(f"no approved payload profile is registered for record_type {record_type}")
        if len(matches) != 1:
            ids = ", ".join(profile.profile_id for profile in matches)
            raise PayloadProfileError(f"record_type {record_type} resolves to multiple payload profiles: {ids}")
        return matches[0]

    def validate(
        self,
        record_type: str,
        payload: Mapping[str, Any],
        *,
        profile_id: str | None = None,
        include_non_approved: bool = False,
    ) -> dict[str, Any]:
        profile = (
            self.by_id(profile_id)
            if profile_id is not None
            else self.for_record_type(
                record_type,
                include_non_approved=include_non_approved,
            )
        )
        if record_type not in profile.record_types:
            raise PayloadProfileError(f"profile {profile.profile_id} is not registered for record_type {record_type}")
        if not include_non_approved and profile.status != "approved":
            raise PayloadProfileError(f"payload profile {profile.profile_id} is not approved")
        return profile.validate(payload)


def _load_registry() -> PayloadProfileRegistry:
    registry = _read_json(REGISTRY_PATH, label="payload profile registry")
    schema = _read_json(REGISTRY_SCHEMA_PATH, label="payload profile registry schema")
    Draft202012Validator.check_schema(schema)
    registry_errors = sorted(
        Draft202012Validator(schema, format_checker=FormatChecker()).iter_errors(registry),
        key=lambda error: list(error.path),
    )
    if registry_errors:
        raise PayloadProfileError(f"payload profile registry is invalid: {registry_errors[0].message}")

    profiles: list[PayloadProfile] = []
    profile_ids: set[str] = set()
    record_types: dict[str, str] = {}
    for item in registry["profiles"]:
        profile_id = str(item["profile_id"])
        if profile_id in profile_ids:
            raise PayloadProfileError(f"duplicate payload profile: {profile_id}")
        profile_ids.add(profile_id)
        for record_type in item["record_types"]:
            previous = record_types.get(record_type)
            if previous is not None:
                raise PayloadProfileError(f"record_type {record_type} is mapped to both {previous} and {profile_id}")
            record_types[record_type] = profile_id
        schema_path = _RESOURCE_ROOT / str(item["schema_ref"]).removeprefix("resources/")
        profile_schema = _read_json(schema_path, label=f"profile schema {profile_id}")
        Draft202012Validator.check_schema(profile_schema)
        profiles.append(
            PayloadProfile(
                profile_id=profile_id,
                profile_version=str(item["profile_version"]),
                status=str(item["status"]),
                record_types=tuple(item["record_types"]),
                schema_ref=str(item["schema_ref"]),
                description=str(item["description"]),
                canonicalization=dict(item["canonicalization"]),
                schema=profile_schema,
            )
        )
    return PayloadProfileRegistry(
        registry_version=str(registry["registry_version"]),
        profiles=tuple(profiles),
    )


@lru_cache(maxsize=1)
def load_payload_profile_registry() -> PayloadProfileRegistry:
    """Load and validate the packaged registry once per process."""

    return _load_registry()


def validate_payload_profile(
    record_type: str,
    payload: Mapping[str, Any],
    *,
    profile_id: str | None = None,
    include_non_approved: bool = False,
) -> dict[str, Any]:
    """Validate one payload without coercing or inferring its domain."""

    return load_payload_profile_registry().validate(
        record_type,
        payload,
        profile_id=profile_id,
        include_non_approved=include_non_approved,
    )
