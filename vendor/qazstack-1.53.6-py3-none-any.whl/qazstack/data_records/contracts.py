"""Strict, storage-neutral QazStack data-record contracts.

The envelope deliberately separates four identities:

* ``record_id`` identifies one source item across revisions;
* ``version_id`` identifies one immutable content/governance/collection occurrence;
* ``content_digest`` groups byte-equivalent canonical JSON across sources;
* product/entity resolution remains outside this contract and requires review.

This keeps exact deduplication deterministic without silently merging source
occurrences or asserting that two people, places, documents, or events are the
same domain object.
"""

from __future__ import annotations

import hashlib
import json
import math
import unicodedata
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any

from qazstack.contracts._validation import (
    require_aware,
    require_http_url,
    require_identifier,
    require_one_of,
    require_ratio,
    require_sha256,
    require_text,
)

DATA_RECORD_SCHEMA_VERSION = "qazstack-data-record-v1"
DATA_RECORD_BATCH_SCHEMA_VERSION = "qazstack-data-record-batch-v1"
DATA_RECORD_ACCESS_TIERS = frozenset({"public", "portfolio", "restricted", "private"})
DATA_RECORD_RIGHTS_STATES = frozenset({"allowed", "review_required", "restricted", "prohibited", "unknown"})
DATA_RECORD_QUALITY_STATES = frozenset({"valid", "warning", "quarantined"})
MAX_SAFE_JSON_INTEGER = 9_007_199_254_740_991

_ACCESS_FIELDS = frozenset(
    {
        "tier",
        "allowed_projects",
        "scopes",
        "policy_version",
        "contains_personal_data",
        "rights_state",
        "license_id",
    }
)
_PROVENANCE_FIELDS = frozenset(
    {
        "producer",
        "pipeline",
        "run_id",
        "collected_at",
        "source_url",
        "collector_version",
        "transformation_refs",
    }
)
_QUALITY_FIELDS = frozenset({"state", "completeness", "warnings", "validator_version"})
_RECORD_FIELDS = frozenset(
    {
        "schema_version",
        "record_id",
        "version_id",
        "record_type",
        "source_ref",
        "external_id",
        "observed_at",
        "published_at",
        "captured_at",
        "language",
        "subject_refs",
        "payload",
        "content_digest",
        "provenance",
        "access",
        "quality",
    }
)
_BATCH_FIELDS = frozenset({"schema_version", "batch_id", "producer", "created_at", "records"})


def _reject_unknown_fields(payload: Mapping[str, object], allowed: frozenset[str], field_name: str) -> None:
    unknown = sorted(str(key) for key in payload if str(key) not in allowed)
    if unknown:
        raise ValueError(f"{field_name} contains unknown fields: {', '.join(unknown)}")


def _mapping(value: object, field_name: str) -> Mapping[str, object]:
    if not isinstance(value, Mapping):
        raise ValueError(f"{field_name} must be an object")
    return value


def _string(value: object, field_name: str) -> str:
    if not isinstance(value, str):
        raise ValueError(f"{field_name} must be a string")
    return value


def _optional_string(value: object, field_name: str) -> str:
    if value is None:
        return ""
    return _string(value, field_name)


def _datetime(value: object, field_name: str) -> datetime:
    if isinstance(value, datetime):
        parsed = value
    elif isinstance(value, str):
        try:
            parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError as exc:
            raise ValueError(f"{field_name} must be an ISO-8601 timestamp") from exc
    else:
        raise ValueError(f"{field_name} must be an ISO-8601 timestamp")
    require_aware(parsed, field_name)
    return parsed


def _optional_datetime(value: object, field_name: str) -> datetime | None:
    if value is None:
        return None
    return _datetime(value, field_name)


def _tuple_of_strings(value: object, field_name: str) -> tuple[str, ...]:
    if value is None:
        return ()
    if isinstance(value, (str, bytes)) or not isinstance(value, Sequence):
        raise ValueError(f"{field_name} must be an array")
    result = tuple(_string(item, f"{field_name} item") for item in value)
    if len(result) != len(set(result)):
        raise ValueError(f"{field_name} must not contain duplicate values")
    return result


def _utc_iso(value: datetime | None) -> str | None:
    if value is None:
        return None
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _canonical_number(value: int | float) -> str:
    if isinstance(value, bool):
        raise ValueError("payload booleans must not be treated as numbers")
    if isinstance(value, int):
        if abs(value) > MAX_SAFE_JSON_INTEGER:
            raise ValueError("payload integers outside the interoperable JSON range must be strings")
        return str(value)
    if not math.isfinite(value):
        raise ValueError("payload numbers must be finite")
    if value == 0:
        return "0"
    if value.is_integer() and abs(value) > MAX_SAFE_JSON_INTEGER:
        raise ValueError("payload integers outside the interoperable JSON range must be strings")
    text = format(Decimal(repr(value)), "f")
    if "." in text:
        text = text.rstrip("0").rstrip(".")
    return text


def canonical_json(value: Any) -> str:
    """Serialize the v1 cross-language canonical JSON data model.

    Strings and keys use NFKC, object keys sort by normalized Unicode scalar
    value, finite binary64 numbers use expanded shortest-roundtrip decimals,
    integral floats equal integers, and integers outside the JavaScript-safe
    range must be transported as strings.
    """
    if value is None or isinstance(value, bool):
        return "null" if value is None else ("true" if value else "false")
    if isinstance(value, str):
        return json.dumps(
            unicodedata.normalize("NFKC", value),
            ensure_ascii=False,
            separators=(",", ":"),
        )
    if isinstance(value, (int, float)):
        return _canonical_number(value)
    if isinstance(value, Mapping):
        normalized: dict[str, Any] = {}
        for raw_key, item in value.items():
            if not isinstance(raw_key, str):
                raise ValueError("payload object keys must be strings")
            key = unicodedata.normalize("NFKC", raw_key)
            if key in normalized:
                raise ValueError("payload contains keys that collide after Unicode normalization")
            normalized[key] = item
        return (
            "{"
            + ",".join(f"{canonical_json(key)}:{canonical_json(normalized[key])}" for key in sorted(normalized))
            + "}"
        )
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        return "[" + ",".join(canonical_json(item) for item in value) + "]"
    raise ValueError(f"payload contains non-JSON value of type {type(value).__name__}")


def canonical_payload_digest(payload: Mapping[str, Any]) -> str:
    """Return the exact-dedup fingerprint for canonical JSON payload content."""
    encoded = canonical_json(payload).encode("utf-8")
    return f"sha256:{hashlib.sha256(encoded).hexdigest()}"


def _normalize_external_id(value: str) -> str:
    normalized = unicodedata.normalize("NFKC", value).strip()
    if not normalized:
        raise ValueError("external_id must be non-empty when supplied")
    if len(normalized) > 512:
        raise ValueError("external_id must not exceed 512 Unicode characters")
    if any(unicodedata.category(char) == "Cc" for char in normalized):
        raise ValueError("external_id must not contain control characters")
    return normalized


def build_record_id(source_ref: str, *, external_id: str = "", content_digest: str) -> str:
    """Build a stable source-item identity without exposing its source key."""
    source_ref = require_identifier(source_ref, "source_ref")
    content_digest = require_sha256(content_digest, "content_digest")
    identity = _normalize_external_id(external_id) if external_id else content_digest
    encoded = f"{source_ref}\0{identity}".encode("utf-8")
    return f"record:{hashlib.sha256(encoded).hexdigest()}"


def canonical_version_digest(record: Mapping[str, Any]) -> str:
    """Hash one immutable material state and collection occurrence.

    Access, rights and quality changes must create a new version even when the
    source payload is unchanged. Collection occurrence fields are included so
    a later observation cannot collapse onto an earlier A state after A→B→A.
    Retrying the exact same envelope remains idempotent. Set-like arrays are
    sorted to keep the identity language-neutral.
    """
    provenance = _mapping(record.get("provenance"), "provenance")
    access = _mapping(record.get("access"), "access")
    quality = _mapping(record.get("quality"), "quality")
    external_id = record.get("external_id")
    normalized_external_id = (
        _normalize_external_id(_string(external_id, "external_id")) if external_id is not None else None
    )
    completeness = quality.get("completeness")
    if isinstance(completeness, bool) or not isinstance(completeness, (int, float)):
        raise ValueError("quality.completeness must be a number")

    material = {
        "record_id": require_identifier(_string(record.get("record_id"), "record_id"), "record_id"),
        "record_type": require_identifier(_string(record.get("record_type"), "record_type"), "record_type"),
        "source_ref": require_identifier(_string(record.get("source_ref"), "source_ref"), "source_ref"),
        "external_id": normalized_external_id,
        "observed_at": _utc_iso(_datetime(record.get("observed_at"), "observed_at")),
        "published_at": _utc_iso(_optional_datetime(record.get("published_at"), "published_at")),
        "captured_at": _utc_iso(_datetime(record.get("captured_at"), "captured_at")),
        "language": (
            require_identifier(
                _optional_string(record.get("language"), "language").lower(),
                "language",
            )
            if record.get("language") is not None
            else None
        ),
        "subject_refs": sorted(_tuple_of_strings(record.get("subject_refs"), "subject_refs")),
        "content_digest": require_sha256(
            _string(record.get("content_digest"), "content_digest"),
            "content_digest",
        ),
        "provenance": {
            "producer": _string(provenance.get("producer"), "provenance.producer"),
            "pipeline": _string(provenance.get("pipeline"), "provenance.pipeline"),
            "run_id": _string(provenance.get("run_id"), "provenance.run_id"),
            "collected_at": _utc_iso(_datetime(provenance.get("collected_at"), "provenance.collected_at")),
            "source_url": _optional_string(provenance.get("source_url"), "provenance.source_url") or None,
            "collector_version": _optional_string(
                provenance.get("collector_version"),
                "provenance.collector_version",
            )
            or None,
            "transformation_refs": sorted(
                _tuple_of_strings(
                    provenance.get("transformation_refs"),
                    "provenance.transformation_refs",
                )
            ),
        },
        "access": {
            "tier": _string(access.get("tier"), "access.tier"),
            "allowed_projects": sorted(_tuple_of_strings(access.get("allowed_projects"), "access.allowed_projects")),
            "scopes": sorted(_tuple_of_strings(access.get("scopes"), "access.scopes")),
            "policy_version": _string(access.get("policy_version"), "access.policy_version"),
            "contains_personal_data": access.get("contains_personal_data"),
            "rights_state": _string(access.get("rights_state"), "access.rights_state"),
            "license_id": _optional_string(access.get("license_id"), "access.license_id") or None,
        },
        "quality": {
            "state": _string(quality.get("state"), "quality.state"),
            "completeness": float(completeness),
            "warnings": sorted(_tuple_of_strings(quality.get("warnings"), "quality.warnings")),
            "validator_version": _string(quality.get("validator_version"), "quality.validator_version"),
        },
    }
    if not isinstance(material["access"]["contains_personal_data"], bool):
        raise ValueError("access.contains_personal_data must be a boolean")
    return canonical_payload_digest(material)


def build_version_id(record_id: str, version_digest: str) -> str:
    """Build an immutable identity for one material record revision."""
    record_id = require_identifier(record_id, "record_id")
    version_digest = require_sha256(version_digest, "version_digest")
    encoded = f"{record_id}\0{version_digest}".encode("utf-8")
    return f"version:{hashlib.sha256(encoded).hexdigest()}"


def build_record_version_id(record: Mapping[str, Any]) -> str:
    """Build a version id from the canonical material fields of a record."""
    record_id = _string(record.get("record_id"), "record_id")
    return build_version_id(record_id, canonical_version_digest(record))


@dataclass(frozen=True, slots=True)
class DataRecordAccess:
    """Portable access decision metadata; authorization remains QazLake-owned."""

    tier: str
    allowed_projects: tuple[str, ...]
    scopes: tuple[str, ...]
    policy_version: str
    contains_personal_data: bool = False
    rights_state: str = "unknown"
    license_id: str = ""

    def __post_init__(self) -> None:
        require_one_of(self.tier, DATA_RECORD_ACCESS_TIERS, "tier")
        require_identifier(self.policy_version, "policy_version")
        require_one_of(self.rights_state, DATA_RECORD_RIGHTS_STATES, "rights_state")
        if not isinstance(self.contains_personal_data, bool):
            raise ValueError("contains_personal_data must be a boolean")
        if len(self.allowed_projects) != len(set(self.allowed_projects)):
            raise ValueError("allowed_projects must not contain duplicates")
        for project in self.allowed_projects:
            if project != "*":
                require_identifier(project, "allowed_projects")
        if not self.scopes or len(self.scopes) != len(set(self.scopes)):
            raise ValueError("scopes must be non-empty and unique")
        for scope in self.scopes:
            require_identifier(scope, "scopes")
        if self.license_id:
            require_identifier(self.license_id, "license_id")

        if self.tier == "public":
            if self.allowed_projects != ("*",):
                raise ValueError("public records must allow all projects")
            if self.contains_personal_data:
                raise ValueError("public records must not contain personal data")
            if self.rights_state != "allowed" or not self.license_id:
                raise ValueError("public records require allowed rights and license_id")
        elif self.tier == "portfolio":
            if not self.allowed_projects:
                raise ValueError("portfolio records require allowed_projects")
            if self.contains_personal_data:
                raise ValueError("portfolio records with personal data must be restricted")
            if self.rights_state in {"prohibited", "unknown"}:
                raise ValueError("portfolio records require reviewed rights")
        elif self.tier == "restricted":
            if not self.allowed_projects or "*" in self.allowed_projects:
                raise ValueError("restricted records require explicit project ids")
        elif self.allowed_projects:
            raise ValueError("private records must not advertise allowed_projects")

    def to_dict(self) -> dict[str, object]:
        return {
            "tier": self.tier,
            "allowed_projects": list(self.allowed_projects),
            "scopes": list(self.scopes),
            "policy_version": self.policy_version,
            "contains_personal_data": self.contains_personal_data,
            "rights_state": self.rights_state,
            "license_id": self.license_id or None,
        }

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> DataRecordAccess:
        _reject_unknown_fields(payload, _ACCESS_FIELDS, "access")
        contains_personal_data = payload.get("contains_personal_data", False)
        if not isinstance(contains_personal_data, bool):
            raise ValueError("contains_personal_data must be a boolean")
        return cls(
            tier=_string(payload.get("tier"), "tier"),
            allowed_projects=_tuple_of_strings(payload.get("allowed_projects", []), "allowed_projects"),
            scopes=_tuple_of_strings(payload.get("scopes", []), "scopes"),
            policy_version=_string(payload.get("policy_version"), "policy_version"),
            contains_personal_data=contains_personal_data,
            rights_state=_string(payload.get("rights_state", "unknown"), "rights_state"),
            license_id=_optional_string(payload.get("license_id"), "license_id"),
        )


@dataclass(frozen=True, slots=True)
class DataRecordProvenance:
    """Producer and collection lineage without credentials or raw errors."""

    producer: str
    pipeline: str
    run_id: str
    collected_at: datetime
    source_url: str = ""
    collector_version: str = ""
    transformation_refs: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        for value, name in (
            (self.producer, "producer"),
            (self.pipeline, "pipeline"),
            (self.run_id, "run_id"),
        ):
            require_identifier(value, name)
        require_aware(self.collected_at, "collected_at")
        if self.source_url:
            object.__setattr__(self, "source_url", require_http_url(self.source_url, "source_url"))
        if self.collector_version:
            require_text(self.collector_version, "collector_version")
        if len(self.transformation_refs) != len(set(self.transformation_refs)):
            raise ValueError("transformation_refs must not contain duplicates")
        for ref in self.transformation_refs:
            require_text(ref, "transformation_refs")

    def to_dict(self) -> dict[str, object]:
        return {
            "producer": self.producer,
            "pipeline": self.pipeline,
            "run_id": self.run_id,
            "collected_at": _utc_iso(self.collected_at),
            "source_url": self.source_url or None,
            "collector_version": self.collector_version or None,
            "transformation_refs": list(self.transformation_refs),
        }

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> DataRecordProvenance:
        _reject_unknown_fields(payload, _PROVENANCE_FIELDS, "provenance")
        return cls(
            producer=_string(payload.get("producer"), "producer"),
            pipeline=_string(payload.get("pipeline"), "pipeline"),
            run_id=_string(payload.get("run_id"), "run_id"),
            collected_at=_datetime(payload.get("collected_at"), "collected_at"),
            source_url=_optional_string(payload.get("source_url"), "source_url"),
            collector_version=_optional_string(payload.get("collector_version"), "collector_version"),
            transformation_refs=_tuple_of_strings(payload.get("transformation_refs", []), "transformation_refs"),
        )


@dataclass(frozen=True, slots=True)
class DataRecordQuality:
    """Comparable validation state without product-specific ranking weights."""

    state: str
    completeness: float
    validator_version: str
    warnings: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        require_one_of(self.state, DATA_RECORD_QUALITY_STATES, "state")
        require_ratio(self.completeness, "completeness")
        require_identifier(self.validator_version, "validator_version")
        if len(self.warnings) != len(set(self.warnings)):
            raise ValueError("warnings must not contain duplicates")
        for warning in self.warnings:
            require_identifier(warning, "warnings")
        if self.state == "valid" and self.warnings:
            raise ValueError("valid records must not carry warnings")
        if self.state == "quarantined" and not self.warnings:
            raise ValueError("quarantined records require warning reason codes")

    def to_dict(self) -> dict[str, object]:
        return {
            "state": self.state,
            "completeness": self.completeness,
            "warnings": list(self.warnings),
            "validator_version": self.validator_version,
        }

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> DataRecordQuality:
        _reject_unknown_fields(payload, _QUALITY_FIELDS, "quality")
        completeness = payload.get("completeness")
        if isinstance(completeness, bool) or not isinstance(completeness, (int, float)):
            raise ValueError("completeness must be a number")
        return cls(
            state=_string(payload.get("state"), "state"),
            completeness=float(completeness),
            warnings=_tuple_of_strings(payload.get("warnings", []), "warnings"),
            validator_version=_string(payload.get("validator_version"), "validator_version"),
        )


@dataclass(frozen=True, slots=True)
class DataRecord:
    """One immutable, access-labelled version of a source record."""

    record_id: str
    version_id: str
    record_type: str
    source_ref: str
    observed_at: datetime
    captured_at: datetime
    payload: Mapping[str, Any]
    content_digest: str
    provenance: DataRecordProvenance
    access: DataRecordAccess
    quality: DataRecordQuality
    external_id: str = ""
    published_at: datetime | None = None
    language: str = ""
    subject_refs: tuple[str, ...] = ()
    schema_version: str = field(default=DATA_RECORD_SCHEMA_VERSION, init=False)

    def __post_init__(self) -> None:
        if self.schema_version != DATA_RECORD_SCHEMA_VERSION:
            raise ValueError(f"schema_version must be {DATA_RECORD_SCHEMA_VERSION}")
        require_identifier(self.record_id, "record_id")
        require_identifier(self.version_id, "version_id")
        require_identifier(self.record_type, "record_type")
        require_identifier(self.source_ref, "source_ref")
        require_aware(self.observed_at, "observed_at")
        require_aware(self.captured_at, "captured_at")
        if self.captured_at < self.observed_at:
            raise ValueError("captured_at cannot precede observed_at")
        if self.published_at is not None:
            require_aware(self.published_at, "published_at")
            if self.published_at > self.captured_at:
                raise ValueError("published_at cannot be later than captured_at")
        if self.provenance.collected_at > self.captured_at:
            raise ValueError("provenance.collected_at cannot be later than captured_at")

        normalized_external_id = _normalize_external_id(self.external_id) if self.external_id else ""
        object.__setattr__(self, "external_id", normalized_external_id)
        if self.language:
            object.__setattr__(self, "language", require_identifier(self.language.lower(), "language"))
        if len(self.subject_refs) != len(set(self.subject_refs)):
            raise ValueError("subject_refs must not contain duplicates")
        for ref in self.subject_refs:
            require_identifier(ref, "subject_refs")
        if not isinstance(self.payload, Mapping):
            raise ValueError("payload must be an object")

        canonical_digest = canonical_payload_digest(self.payload)
        supplied_digest = require_sha256(self.content_digest, "content_digest")
        if supplied_digest != canonical_digest:
            raise ValueError("content_digest does not match canonical payload")
        object.__setattr__(self, "content_digest", supplied_digest)

        expected_record_id = build_record_id(
            self.source_ref,
            external_id=self.external_id,
            content_digest=self.content_digest,
        )
        if self.record_id != expected_record_id:
            raise ValueError("record_id does not match source identity")
        if self.version_id != build_record_version_id(self.to_dict()):
            raise ValueError("version_id does not match record material state")

    @property
    def exact_duplicate_key(self) -> str:
        """The cross-source exact-dedup key; source occurrences stay separate."""
        return self.content_digest

    def to_dict(self) -> dict[str, object]:
        return {
            "schema_version": self.schema_version,
            "record_id": self.record_id,
            "version_id": self.version_id,
            "record_type": self.record_type,
            "source_ref": self.source_ref,
            "external_id": self.external_id or None,
            "observed_at": _utc_iso(self.observed_at),
            "published_at": _utc_iso(self.published_at),
            "captured_at": _utc_iso(self.captured_at),
            "language": self.language or None,
            "subject_refs": list(self.subject_refs),
            "payload": dict(self.payload),
            "content_digest": self.content_digest,
            "provenance": self.provenance.to_dict(),
            "access": self.access.to_dict(),
            "quality": self.quality.to_dict(),
        }

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> DataRecord:
        _reject_unknown_fields(payload, _RECORD_FIELDS, "data record")
        schema_version = payload.get("schema_version")
        if schema_version != DATA_RECORD_SCHEMA_VERSION:
            raise ValueError(f"schema_version must be {DATA_RECORD_SCHEMA_VERSION}")
        raw_payload = _mapping(payload.get("payload"), "payload")
        return cls(
            record_id=_string(payload.get("record_id"), "record_id"),
            version_id=_string(payload.get("version_id"), "version_id"),
            record_type=_string(payload.get("record_type"), "record_type"),
            source_ref=_string(payload.get("source_ref"), "source_ref"),
            external_id=_optional_string(payload.get("external_id"), "external_id"),
            observed_at=_datetime(payload.get("observed_at"), "observed_at"),
            published_at=_optional_datetime(payload.get("published_at"), "published_at"),
            captured_at=_datetime(payload.get("captured_at"), "captured_at"),
            language=_optional_string(payload.get("language"), "language"),
            subject_refs=_tuple_of_strings(payload.get("subject_refs", []), "subject_refs"),
            payload=raw_payload,
            content_digest=_string(payload.get("content_digest"), "content_digest"),
            provenance=DataRecordProvenance.from_dict(_mapping(payload.get("provenance"), "provenance")),
            access=DataRecordAccess.from_dict(_mapping(payload.get("access"), "access")),
            quality=DataRecordQuality.from_dict(_mapping(payload.get("quality"), "quality")),
        )


@dataclass(frozen=True, slots=True)
class DataRecordBatch:
    """Bounded transport batch; scheduling and delivery receipts stay external."""

    batch_id: str
    producer: str
    created_at: datetime
    records: tuple[DataRecord, ...]
    schema_version: str = field(default=DATA_RECORD_BATCH_SCHEMA_VERSION, init=False)

    def __post_init__(self) -> None:
        if self.schema_version != DATA_RECORD_BATCH_SCHEMA_VERSION:
            raise ValueError(f"schema_version must be {DATA_RECORD_BATCH_SCHEMA_VERSION}")
        require_identifier(self.batch_id, "batch_id")
        require_identifier(self.producer, "producer")
        require_aware(self.created_at, "created_at")
        if not self.records:
            raise ValueError("records must not be empty")
        if any(record.provenance.producer != self.producer for record in self.records):
            raise ValueError("all records must belong to the batch producer")
        record_ids = [record.record_id for record in self.records]
        version_ids = [record.version_id for record in self.records]
        if len(record_ids) != len(set(record_ids)):
            raise ValueError("batch record_id values must be unique")
        if len(version_ids) != len(set(version_ids)):
            raise ValueError("batch version_id values must be unique")

    def to_dict(self) -> dict[str, object]:
        return {
            "schema_version": self.schema_version,
            "batch_id": self.batch_id,
            "producer": self.producer,
            "created_at": _utc_iso(self.created_at),
            "records": [record.to_dict() for record in self.records],
        }

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> DataRecordBatch:
        _reject_unknown_fields(payload, _BATCH_FIELDS, "data record batch")
        if payload.get("schema_version") != DATA_RECORD_BATCH_SCHEMA_VERSION:
            raise ValueError(f"schema_version must be {DATA_RECORD_BATCH_SCHEMA_VERSION}")
        raw_records = payload.get("records")
        if isinstance(raw_records, (str, bytes)) or not isinstance(raw_records, Sequence):
            raise ValueError("records must be an array")
        return cls(
            batch_id=_string(payload.get("batch_id"), "batch_id"),
            producer=_string(payload.get("producer"), "producer"),
            created_at=_datetime(payload.get("created_at"), "created_at"),
            records=tuple(DataRecord.from_dict(_mapping(item, "record")) for item in raw_records),
        )


def data_record_from_payload(
    *,
    record_type: str,
    source_ref: str,
    payload: Mapping[str, Any],
    observed_at: datetime,
    captured_at: datetime,
    provenance: DataRecordProvenance,
    access: DataRecordAccess,
    quality: DataRecordQuality,
    external_id: str = "",
    published_at: datetime | None = None,
    language: str = "",
    subject_refs: tuple[str, ...] = (),
) -> DataRecord:
    """Build a fully self-consistent record from a producer payload."""
    content_digest = canonical_payload_digest(payload)
    record_id = build_record_id(source_ref, external_id=external_id, content_digest=content_digest)
    version_material = {
        "record_id": record_id,
        "record_type": record_type,
        "source_ref": source_ref,
        "external_id": external_id or None,
        "observed_at": _utc_iso(observed_at),
        "published_at": _utc_iso(published_at),
        "captured_at": _utc_iso(captured_at),
        "language": language or None,
        "subject_refs": list(subject_refs),
        "content_digest": content_digest,
        "provenance": provenance.to_dict(),
        "access": access.to_dict(),
        "quality": quality.to_dict(),
    }
    return DataRecord(
        record_id=record_id,
        version_id=build_record_version_id(version_material),
        record_type=record_type,
        source_ref=source_ref,
        external_id=external_id,
        observed_at=observed_at,
        published_at=published_at,
        captured_at=captured_at,
        language=language,
        subject_refs=subject_refs,
        payload=payload,
        content_digest=content_digest,
        provenance=provenance,
        access=access,
        quality=quality,
    )
