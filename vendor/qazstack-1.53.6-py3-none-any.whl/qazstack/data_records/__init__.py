"""Portable data-record envelopes for QazPipe, QazLake, and consumers.

QazStack owns only the transport contract and deterministic identifiers.
Storage, authorization, retention, deduplication policy, and publication remain
consumer-owned responsibilities.
"""

from qazstack.data_records.contracts import (
    DATA_RECORD_ACCESS_TIERS,
    DATA_RECORD_BATCH_SCHEMA_VERSION,
    DATA_RECORD_QUALITY_STATES,
    DATA_RECORD_RIGHTS_STATES,
    DATA_RECORD_SCHEMA_VERSION,
    MAX_SAFE_JSON_INTEGER,
    DataRecord,
    DataRecordAccess,
    DataRecordBatch,
    DataRecordProvenance,
    DataRecordQuality,
    build_record_id,
    build_record_version_id,
    build_version_id,
    canonical_json,
    canonical_payload_digest,
    canonical_version_digest,
    data_record_from_payload,
)
from qazstack.data_records.profiles import (
    PROFILE_REGISTRY_SCHEMA_VERSION,
    PayloadProfile,
    PayloadProfileError,
    PayloadProfileRegistry,
    load_payload_profile_registry,
    validate_payload_profile,
)

__all__ = [
    "DATA_RECORD_ACCESS_TIERS",
    "DATA_RECORD_BATCH_SCHEMA_VERSION",
    "DATA_RECORD_QUALITY_STATES",
    "DATA_RECORD_RIGHTS_STATES",
    "DATA_RECORD_SCHEMA_VERSION",
    "MAX_SAFE_JSON_INTEGER",
    "DataRecord",
    "DataRecordAccess",
    "DataRecordBatch",
    "DataRecordProvenance",
    "DataRecordQuality",
    "build_record_id",
    "build_record_version_id",
    "build_version_id",
    "canonical_json",
    "canonical_payload_digest",
    "canonical_version_digest",
    "data_record_from_payload",
    "PROFILE_REGISTRY_SCHEMA_VERSION",
    "PayloadProfile",
    "PayloadProfileError",
    "PayloadProfileRegistry",
    "load_payload_profile_registry",
    "validate_payload_profile",
]
