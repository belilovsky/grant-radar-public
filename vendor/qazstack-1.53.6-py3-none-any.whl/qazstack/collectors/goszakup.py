"""Shared goszakup.gov.kz collector normalization helpers."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any


def normalize_goszakup_announcement(raw: Mapping[str, Any]) -> dict[str, Any]:
    """Normalize one goszakup announcement GraphQL record.

    QazStack owns only the public-safe field mapping. Fetching, pagination,
    persistence, retry policy and source ownership remain in the consuming
    pipeline.
    """
    customer = _mapping(raw.get("customer"))
    status = _mapping(raw.get("refBuyStatus"))
    lots = _list(raw.get("lots"))
    return {
        "id": raw.get("id"),
        "name": raw.get("nameRu"),
        "name_kz": raw.get("nameKz"),
        "start_date": raw.get("startDate"),
        "end_date": raw.get("endDate"),
        "publish_date": raw.get("publishDate"),
        "total_sum": raw.get("totalSum"),
        "customer_bin": raw.get("customerBin"),
        "customer_name": customer.get("nameRu"),
        "customer_address": customer.get("address"),
        "status": status.get("nameRu"),
        "lots_count": len(lots),
        "lots": lots,
        "_raw": raw,
    }


def normalize_goszakup_contract(raw: Mapping[str, Any]) -> dict[str, Any]:
    """Normalize one goszakup contract GraphQL record."""
    customer = _mapping(raw.get("customer"))
    contract_type = _mapping(raw.get("refContractType"))
    status = _mapping(raw.get("refContractStatus"))
    suppliers = _list(raw.get("suppliers"))
    supplier = _mapping(suppliers[0]) if suppliers else {}
    return {
        "id": raw.get("id"),
        "contract_sum": raw.get("contractSum"),
        "fakt_sum": raw.get("faktSumPrice"),
        "sign_date": raw.get("signDate"),
        "end_date": raw.get("faktEndDate"),
        "customer_id": raw.get("customerId"),
        "customer_name": customer.get("nameRu"),
        "supplier_id": raw.get("supplierId"),
        "supplier_name": supplier.get("nameRu"),
        "contract_type": contract_type.get("nameRu"),
        "status": status.get("nameRu"),
        "items_count": len(_list(raw.get("items"))),
        "_raw": raw,
    }


def _mapping(value: Any) -> Mapping[str, Any]:
    return value if isinstance(value, Mapping) else {}


def _list(value: Any) -> list[Any]:
    return value if isinstance(value, list) else []
