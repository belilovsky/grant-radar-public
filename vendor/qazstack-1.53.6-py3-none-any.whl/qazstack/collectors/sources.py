"""Shared source registry helpers for collector-based ingestion."""

from __future__ import annotations

import csv
from os import PathLike


def load_sources_csv(path: str | PathLike[str]) -> dict[str, dict[str, str]]:
    """Load a ``sources.csv`` file into a mapping keyed by source id.

    The helper intentionally keeps policy out of QazStack: projects still own
    the CSV location, source schema extensions and validation rules. QazStack
    only provides the deterministic parser shape duplicated across collectors.
    """
    result: dict[str, dict[str, str]] = {}
    with open(path, newline="", encoding="utf-8") as fh:
        reader = csv.DictReader(fh)
        for row in reader:
            source_id = row.get("id")
            if not source_id:
                continue
            result[source_id] = dict(row)
    return result
