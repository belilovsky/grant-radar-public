"""QazStack Collector Framework – unified data collection → entity extraction pipeline.

Extends ``qazstack.monitor.collectors`` with:

- **CollectorRegistry** – register/discover collector types
- **EntityExtractor** – CollectorResult → NER → Entity Store
- **CollectorPipeline** – orchestrates collect → enrich → extract → store

Quick start::

    from qazstack.collectors import CollectorRegistry, CollectorPipeline, EntityExtractor
    from qazstack.entities import EntityStore
    from qazstack.monitor.collectors import RSSCollector, HTTPChecker

    # 1. Registry
    registry = CollectorRegistry()
    registry.register(RSSCollector())
    registry.register(HTTPChecker())

    # 2. Entity extractor
    extractor = EntityExtractor(store=EntityStore())

    # 3. Pipeline
    pipeline = CollectorPipeline(
        registry=registry,
        extractor=extractor,
    )

    # 4. Run
    async with db.get_session() as session:
        stats = await pipeline.collect_all(session, project="echo-sounder")
"""

from .contracts import (
    NormalizedItem,
    SourceBatch,
    SourceCheckpoint,
    SourceContract,
    SourceFailure,
)
from .extractor import EntityExtractor
from .goszakup import normalize_goszakup_announcement, normalize_goszakup_contract
from .pipeline import CollectorPipeline, CollectStats
from .registry import CollectorRegistry
from .sources import load_sources_csv

__all__ = [
    "CollectorRegistry",
    "EntityExtractor",
    "CollectorPipeline",
    "CollectStats",
    "NormalizedItem",
    "SourceBatch",
    "SourceCheckpoint",
    "SourceContract",
    "SourceFailure",
    "load_sources_csv",
    "normalize_goszakup_announcement",
    "normalize_goszakup_contract",
]
