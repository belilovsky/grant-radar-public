"""Versioned translation-quality vocabulary shared with QMT consumers.

The module is intentionally dependency-free.  It defines the canonical Python
contract for QMT's TypeScript mirror and any future translation-quality
consumer that needs stable verdict, issue and provider-readiness values without
importing the full translation runtime.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from typing import Any

CONTRACT_ID = "qazstack.translation_quality.v1"
CONTRACT_VERSION = "1.0.0"


class QualityVerdictCode(StrEnum):
    PUBLISH_READY = "publish_ready"
    EDIT_REQUIRED = "edit_required"
    TERMINOLOGY_REVIEW = "terminology_review"
    MEANING_RISK = "meaning_risk"
    NOT_ENOUGH_EVIDENCE = "not_enough_evidence"


class QualityVerdictTone(StrEnum):
    SUCCESS = "success"
    WARNING = "warning"
    DANGER = "danger"
    MUTED = "muted"


class IssueSeverity(StrEnum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class QalamIssueType(StrEnum):
    CLICHE = "cliche"
    BUREAUCRATISM = "bureaucratism"
    CALQUE = "calque"
    REPETITION = "repetition"
    CLARITY = "clarity"
    TONE = "tone"
    STRUCTURE = "structure"
    TERMINOLOGY = "terminology"


class MQMSeverity(StrEnum):
    MINOR = "minor"
    MAJOR = "major"
    CRITICAL = "critical"


class ProviderReadinessStatus(StrEnum):
    AVAILABLE = "available"
    DEGRADED = "degraded"
    MISSING_KEY = "missing_key"
    MANUALLY_DISABLED = "manually_disabled"
    CIRCUIT_OPEN = "circuit_open"
    AUTH_FAILED = "auth_failed"
    QUOTA_EXCEEDED = "quota_exceeded"
    PROVIDER_ERROR = "provider_error"
    UNKNOWN = "unknown"


@dataclass(frozen=True, slots=True)
class TranslationQualityVocabulary:
    contract_id: str
    contract_version: str
    quality_verdict_codes: tuple[str, ...]
    quality_verdict_tones: tuple[str, ...]
    issue_severities: tuple[str, ...]
    qalam_issue_types: tuple[str, ...]
    mqm_severities: tuple[str, ...]
    provider_readiness_statuses: tuple[str, ...]

    def as_dict(self) -> dict[str, Any]:
        """Return a JSON-serializable snapshot for cross-language drift checks."""
        return {
            "contract_id": self.contract_id,
            "contract_version": self.contract_version,
            "quality_verdict_codes": list(self.quality_verdict_codes),
            "quality_verdict_tones": list(self.quality_verdict_tones),
            "issue_severities": list(self.issue_severities),
            "qalam_issue_types": list(self.qalam_issue_types),
            "mqm_severities": list(self.mqm_severities),
            "provider_readiness_statuses": list(self.provider_readiness_statuses),
        }


def translation_quality_vocabulary() -> TranslationQualityVocabulary:
    """Return the canonical QazStack translation-quality contract vocabulary."""
    return TranslationQualityVocabulary(
        contract_id=CONTRACT_ID,
        contract_version=CONTRACT_VERSION,
        quality_verdict_codes=tuple(item.value for item in QualityVerdictCode),
        quality_verdict_tones=tuple(item.value for item in QualityVerdictTone),
        issue_severities=tuple(item.value for item in IssueSeverity),
        qalam_issue_types=tuple(item.value for item in QalamIssueType),
        mqm_severities=tuple(item.value for item in MQMSeverity),
        provider_readiness_statuses=tuple(item.value for item in ProviderReadinessStatus),
    )


__all__ = [
    "CONTRACT_ID",
    "CONTRACT_VERSION",
    "IssueSeverity",
    "MQMSeverity",
    "ProviderReadinessStatus",
    "QalamIssueType",
    "QualityVerdictCode",
    "QualityVerdictTone",
    "TranslationQualityVocabulary",
    "translation_quality_vocabulary",
]
