"""
qazstack.editorial.orchestrator
================================
EditorialOrchestrator – главный редактор (Editor-in-Chief паттерн).

Управляет полным пайплайном генерации:
  Research → Draft → Hard Gates → Scoring Loop → [Publish / HITL]

Ключевые принципы:
  • TokenBudget – hard cap на стоимость одного задания (EDITORIAL_MAX_COST_PER_TASK).
  • Hard Gates – фактологические пороги, проверяются ДО scoring loop.
  • Early-exit – прерываем scoring при delta < 0.02 за последние 2 итерации.
  • Все промежуточные черновики сохраняются в editorial.drafts.
"""

from __future__ import annotations

import json
import logging
import re
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any, Optional

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from .config import settings
from .models import GenerationResult, GenerationTask, ScoringResult
from .research_bank import ResearchBank

if TYPE_CHECKING:
    from .author_manager import AuthorManager
    from .models import AuthorProfile
    from .prompt_builder import PromptBuilder
    from .scoring import ScoringLoop

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# TokenBudget
# ─────────────────────────────────────────────────────────────────────────────


@dataclass
class TokenBudget:
    """Отслеживает расход USD на одно задание.

    Attributes:
        max_cost_usd:    Максимально допустимый расход (из settings).
        spent_usd:       Накопленный расход.
        total_prompt:    Суммарный prompt_tokens.
        total_completion: Суммарный completion_tokens.
    """

    max_cost_usd: float = field(default_factory=lambda: settings.editorial_max_cost_per_task)
    spent_usd: float = 0.0
    total_prompt: int = 0
    total_completion: int = 0

    def add(self, prompt_tokens: int, completion_tokens: int, cost_usd: float) -> None:
        """Зафиксировать расход за один LLM-вызов."""
        self.total_prompt += prompt_tokens
        self.total_completion += completion_tokens
        self.spent_usd += cost_usd

    @property
    def remaining(self) -> float:
        """Остаток бюджета в USD."""
        return max(0.0, self.max_cost_usd - self.spent_usd)

    @property
    def is_exhausted(self) -> bool:
        """True – бюджет исчерпан."""
        return self.spent_usd >= self.max_cost_usd


@dataclass
class HardGateResult:
    """Результат предварительной hard-gate проверки."""

    passed: bool
    reason: Optional[str] = None


# ─────────────────────────────────────────────────────────────────────────────
# EditorialOrchestrator
# ─────────────────────────────────────────────────────────────────────────────


class EditorialOrchestrator:
    """
    Главный редактор – оркестратор пайплайна генерации.

    Параметры:
        research_bank:         ResearchBank – поиск контекста в QazLake.
        prompt_builder:        PromptBuilder – формирует системный и user промпты.
        llm_router:            LLMClient – генерирует черновик.
        scoring_loop:          ScoringLoop – итеративная оценка.
        author_manager:        AuthorManager – загружает профиль автора.
        db_session_factory:    async_sessionmaker для editorial БД.

    Пример:
        orch = EditorialOrchestrator(
            research_bank=bank,
            prompt_builder=builder,
            llm_router=llm,
            scoring_loop=scorer,
            author_manager=manager,
            db_session_factory=session_factory,
        )
        result = await orch.generate(task)
    """

    def __init__(
        self,
        research_bank: ResearchBank,
        prompt_builder: PromptBuilder,
        llm_router: Any,  # LLMClient – избегаем circular import
        scoring_loop: ScoringLoop,
        author_manager: AuthorManager,
        db_session_factory: async_sessionmaker,
    ) -> None:
        self._bank = research_bank
        self._prompt_builder = prompt_builder
        self._llm = llm_router
        self._scoring = scoring_loop
        self._authors = author_manager
        self._session_factory = db_session_factory

    # ── Main Entry Point ──────────────────────────────────────────────────────

    async def generate(self, task: GenerationTask) -> GenerationResult:
        """
        Полный пайплайн: от задания до готового черновика.

        Шаги:
        1. Загружаем профиль автора.
        2. Research phase (ResearchBank.search).
        3. Строим промпт (PromptBuilder).
        4. Генерируем первый черновик (LLMClient).
        5. Hard Gates check (до scoring loop – экономия токенов).
        6. Scoring loop (до max_scoring_iterations).
        7. Passes → сохраняем в editorial.publications.
        8. Fails after max → HITL queue с повышенным приоритетом.

        Returns:
            GenerationResult с финальным статусом и метриками.
        """
        task_id = task.task_id or str(uuid.uuid4())
        task = task.model_copy(update={"task_id": task_id})

        budget = TokenBudget()

        async with self._session_factory() as session:
            try:
                return await self._run_pipeline(task, session, budget)
            except Exception as exc:
                logger.exception("Pipeline failed for task %s: %s", task_id, exc)
                await self._mark_task_error(session, task_id, str(exc))
                raise

    # ── Pipeline ──────────────────────────────────────────────────────────────

    async def _run_pipeline(
        self,
        task: GenerationTask,
        session: AsyncSession,
        budget: TokenBudget,
    ) -> GenerationResult:
        """Внутренний метод пайплайна с доступом к сессии."""

        task_id = task.task_id

        # ── 1. Загружаем профиль автора ──────────────────────────────────────
        author = await self._authors.get_author(task.author_id)
        if author is None:
            raise ValueError(f"Автор {task.author_id!r} не найден")

        logger.info("Начало задания %s | автор=%s | тип=%s", task_id, author.name, task.task_type)

        # Сохраняем задание в БД (если ещё нет)
        await self._upsert_task(session, task, author.author_id)
        await self._update_task_status(session, task_id, "researching")

        # ── 2. Research Phase ────────────────────────────────────────────────
        research_query = getattr(task, "research_query", None) or task.brief
        docs = await self._bank.search(
            query=research_query,
            task=task,
            limit=settings.editorial_research_top_k,
        )
        research_context = await self._bank.format_context(
            docs,
            max_tokens=settings.editorial_research_max_tokens,
        )
        research_sources = [d.url for d in docs if d.url]
        logger.info("Найдено %d источников для задания %s", len(docs), task_id)

        # ── 3. Строим промпт ─────────────────────────────────────────────────
        await self._update_task_status(session, task_id, "drafting")
        system_prompt = self._prompt_builder.build_system_prompt(author, task)
        few_shot = self._prompt_builder.build_few_shot_messages(author)

        # Определяем максимальное число итераций
        max_iters = _get_max_iterations(author, task)

        # ── 4. Генерируем первый черновик ────────────────────────────────────
        user_prompt = self._prompt_builder.build_user_prompt(
            task, research_context, iteration=1, previous_feedback=None
        )
        draft_content, gen_meta = await self._generate_draft(
            system_prompt=system_prompt,
            few_shot=few_shot,
            user_prompt=user_prompt,
        )
        budget.add(
            prompt_tokens=gen_meta.get("prompt_tokens", 0),
            completion_tokens=gen_meta.get("completion_tokens", 0),
            cost_usd=gen_meta.get("cost_usd", 0.0),
        )

        # ── 5. Hard Gates (перед scoring loop) ───────────────────────────────
        gate_result = await self._quick_hard_gate_check(draft_content, task, author)
        if not gate_result.passed:
            logger.warning("Hard gate failed для задания %s: %s", task_id, gate_result.reason)
            draft_id = f"{task_id}_v1"
            await self._save_draft(
                session=session,
                draft_id=draft_id,
                task_id=task_id,
                iteration=1,
                content=draft_content,
                research_context=research_context,
                research_sources=research_sources,
                scoring_result=None,
                status="hard_gate_failed",
                llm_model=gen_meta.get("model", settings.editorial_llm_model),
                prompt_tokens=gen_meta.get("prompt_tokens", 0),
                completion_tokens=gen_meta.get("completion_tokens", 0),
                cost_usd=gen_meta.get("cost_usd", 0.0),
            )
            await self._enqueue_hitl(
                session=session,
                task_id=task_id,
                author=author,
                draft_content=draft_content,
                iterations_used=1,
                final_scores={},
                overall_score=0.0,
                research_sources=research_sources,
                priority=1,
                hard_gate_reason=gate_result.reason,
                status="pending",
            )
            await self._update_task_status(session, task_id, "pending_review")

            title = await self._extract_title(draft_content, task)
            return GenerationResult(
                task_id=task_id,
                author_id=author.author_id,
                author_name=author.name,
                title=title,
                content=draft_content,
                lang=task.lang,
                word_count=len(draft_content.split()),
                iterations_used=1,
                final_scores={},
                overall_score=0.0,
                research_sources=research_sources,
                style_metrics=None,
                status="hard_gate_failed",
            )

        # ── 6. Scoring Loop ───────────────────────────────────────────────────
        await self._update_task_status(session, task_id, "scoring")

        best_result: Optional[ScoringResult] = None
        current_draft = draft_content
        previous_feedback: Optional[str] = None
        previous_score: float = 0.0
        iterations_used = 0

        for iteration in range(1, max_iters + 1):
            iterations_used = iteration

            # Обновляем счётчик итераций
            await session.execute(
                text("UPDATE editorial.generation_tasks SET current_iteration = :i WHERE task_id = :tid"),
                {"i": iteration, "tid": task_id},
            )
            await session.commit()

            # На итерациях > 1 – перегенерируем с фидбеком
            if iteration > 1:
                if budget.is_exhausted:
                    logger.warning("Бюджет исчерпан на итерации %d задания %s", iteration, task_id)
                    break
                user_prompt = self._prompt_builder.build_user_prompt(
                    task, research_context, iteration=iteration, previous_feedback=previous_feedback
                )
                current_draft, gen_meta = await self._generate_draft(
                    system_prompt=system_prompt,
                    few_shot=few_shot,
                    user_prompt=user_prompt,
                )
                budget.add(
                    prompt_tokens=gen_meta.get("prompt_tokens", 0),
                    completion_tokens=gen_meta.get("completion_tokens", 0),
                    cost_usd=gen_meta.get("cost_usd", 0.0),
                )

            # Scoring
            draft_id = f"{task_id}_v{iteration}"
            try:
                scoring_result = await self._scoring.score(
                    draft_id=draft_id,
                    iteration=iteration,
                    draft=current_draft,
                    author=author,
                    task=task,
                    style_metrics=None,  # ScoringLoop вычислит внутри
                    style_validator=None,
                    llm_client=self._llm,
                )
            except Exception as exc:
                logger.error("Scoring failed на итерации %d: %s", iteration, exc)
                # Fallback: создаём минимальный ScoringResult
                scoring_result = ScoringResult(
                    draft_id=draft_id,
                    iteration=iteration,
                    scores={},
                    overall_score=0.5,
                    passes_threshold=False,
                    feedback=f"Ошибка scoring: {exc}",
                    style_metrics=None,
                )

            # Добавляем расход scoring в бюджет
            budget.add(
                prompt_tokens=getattr(scoring_result, "prompt_tokens", 0) or 0,
                completion_tokens=getattr(scoring_result, "completion_tokens", 0) or 0,
                cost_usd=getattr(scoring_result, "cost_usd", 0.0) or 0.0,
            )

            # Сохраняем черновик
            await self._save_draft(
                session=session,
                draft_id=draft_id,
                task_id=task_id,
                iteration=iteration,
                content=current_draft,
                research_context=research_context,
                research_sources=research_sources,
                scoring_result=scoring_result,
                status="scored",
                llm_model=gen_meta.get("model", settings.editorial_llm_model)
                if iteration == 1
                else settings.editorial_llm_model,
                prompt_tokens=gen_meta.get("prompt_tokens", 0),
                completion_tokens=gen_meta.get("completion_tokens", 0),
                cost_usd=gen_meta.get("cost_usd", 0.0),
            )

            # Лог scoring
            await self._log_scoring(session, draft_id, task_id, iteration, scoring_result)

            best_result = scoring_result
            previous_feedback = scoring_result.feedback

            logger.info(
                "Итерация %d/%d: score=%.3f passes=%s | задание %s",
                iteration,
                max_iters,
                scoring_result.overall_score,
                scoring_result.passes_threshold,
                task_id,
            )

            # Early exit: если delta улучшения < 0.02 за последние 2 итерации
            delta = scoring_result.overall_score - previous_score
            if iteration >= 3 and delta < 0.02:
                logger.info("Early exit: delta=%.4f < 0.02 на итерации %d", delta, iteration)
                break

            previous_score = scoring_result.overall_score

            if scoring_result.passes_threshold:
                logger.info("Threshold passed на итерации %d для задания %s", iteration, task_id)
                break

        # ── 7. Финальное решение: publish / HITL ─────────────────────────────
        final_score = best_result.overall_score if best_result else 0.0
        passes = best_result.passes_threshold if best_result else False
        final_scores = best_result.scores if best_result else {}
        style_metrics = best_result.style_metrics if best_result else None
        title = await self._extract_title(current_draft, task)

        if passes and final_score >= settings.editorial_publish_threshold:
            # Автоматически публикуем (высокая уверенность)
            await self._save_publication(
                session=session,
                task_id=task_id,
                draft_id=f"{task_id}_v{iterations_used}",
                author=author,
                title=title,
                content=current_draft,
                task=task,
                final_scores=final_scores,
                overall_score=final_score,
                research_sources=research_sources,
                budget=budget,
            )
            await self._update_task_status(session, task_id, "published")
            final_status = "published"
        else:
            # HITL очередь – требует ревью редактора
            priority = 1 if not passes else 3  # failed → приоритет 1, низкий score → 3
            await self._enqueue_hitl(
                session=session,
                task_id=task_id,
                author=author,
                draft_content=current_draft,
                iterations_used=iterations_used,
                final_scores=final_scores,
                overall_score=final_score,
                research_sources=research_sources,
                priority=priority,
                hard_gate_reason=None,
                status="pending",
            )
            await self._update_task_status(session, task_id, "pending_review")
            final_status = "pending_review"

        logger.info(
            "Задание %s завершено: статус=%s score=%.3f итераций=%d расход=$%.4f",
            task_id,
            final_status,
            final_score,
            iterations_used,
            budget.spent_usd,
        )

        return GenerationResult(
            task_id=task_id,
            author_id=author.author_id,
            author_name=author.name,
            title=title,
            content=current_draft,
            lang=task.lang,
            word_count=len(current_draft.split()),
            iterations_used=iterations_used,
            final_scores=final_scores,
            overall_score=final_score,
            research_sources=research_sources,
            style_metrics=style_metrics,
            status=final_status,
        )

    # ── Hard Gates ────────────────────────────────────────────────────────────

    async def _quick_hard_gate_check(
        self,
        content: str,
        task: GenerationTask,
        author: AuthorProfile,
    ) -> HardGateResult:
        """
        Быстрая проверка hard gate критериев.

        Проверяет через LLM-мини-вызов:
        - factual_accuracy < 0.60 → fail
        - hallucination_rate > 0.15 → fail
        - topic_drift > 40% → fail

        При ошибке LLM – пропускаем (pass), не блокируем пайплайн.
        """
        prompt = (
            f"Ты редактор. Оцени черновик по трём критериям. Ответь ТОЛЬКО JSON:\n"
            f'{{"factual_accuracy": 0.0-1.0, "hallucination_rate": 0.0-1.0, "topic_drift": 0.0-1.0}}\n\n'
            f"Тема задания: {task.brief}\n\n"
            f"Черновик (первые 800 слов):\n{' '.join(content.split()[:800])}"
        )
        try:
            raw = await self._llm.generate(
                system="Ты строгий редактор. Отвечай только валидным JSON.",
                messages=[{"role": "user", "content": prompt}],
            )
            # Ищем JSON в ответе
            match = re.search(r"\{[^}]+\}", raw, re.DOTALL)
            if not match:
                return HardGateResult(passed=True)
            data = json.loads(match.group())

            factual = float(data.get("factual_accuracy", 1.0))
            hallucination = float(data.get("hallucination_rate", 0.0))
            topic_drift = float(data.get("topic_drift", 0.0))

            if factual < settings.editorial_hard_gate_factual_min:
                return HardGateResult(
                    passed=False,
                    reason=f"factual_accuracy={factual:.2f} < {settings.editorial_hard_gate_factual_min}",
                )
            if hallucination > settings.editorial_hard_gate_hallucination_max:
                return HardGateResult(
                    passed=False,
                    reason=f"hallucination_rate={hallucination:.2f} > {settings.editorial_hard_gate_hallucination_max}",
                )
            if topic_drift > settings.editorial_hard_gate_topic_drift_max:
                return HardGateResult(
                    passed=False,
                    reason=f"topic_drift={topic_drift:.2f} > {settings.editorial_hard_gate_topic_drift_max}",
                )
            return HardGateResult(passed=True)

        except Exception as exc:
            logger.warning("Hard gate check failed (non-blocking): %s", exc)
            return HardGateResult(passed=True)

    # ── Generate Draft ────────────────────────────────────────────────────────

    async def _generate_draft(
        self,
        system_prompt: str,
        few_shot: list[dict],
        user_prompt: str,
    ) -> tuple[str, dict]:
        """
        Генерировать черновик через LLMClient.

        Returns:
            (content: str, meta: dict) – текст и метаданные (tokens, cost).
        """
        messages = few_shot + [{"role": "user", "content": user_prompt}]
        if hasattr(self._llm, "generate_with_meta"):
            content, meta = await self._llm.generate_with_meta(system=system_prompt, messages=messages)
        else:
            content = await self._llm.generate(system=system_prompt, messages=messages)
            meta = {}
        return content, meta

    # ── Title extraction ──────────────────────────────────────────────────────

    async def _extract_title(self, content: str, task: GenerationTask) -> str:
        """Извлечь заголовок из первой строки или сгенерировать через LLM."""
        first_line = content.split("\n")[0].strip()
        if first_line.startswith("#"):
            return first_line.lstrip("#").strip()
        if first_line and len(first_line) < 120:
            return first_line
        try:
            title = await self._llm.generate(
                system="Ты редактор. Ответь ТОЛЬКО заголовком статьи – без кавычек, без пояснений.",
                messages=[{"role": "user", "content": f"Придумай заголовок для материала по теме: {task.brief}"}],
            )
            return title.strip().strip("\"'").strip()
        except Exception:
            return task.brief[:100]

    # ── DB helpers ────────────────────────────────────────────────────────────

    async def _upsert_task(self, session: AsyncSession, task: GenerationTask, author_id: str) -> None:
        """Создать запись задания в editorial.generation_tasks (если нет)."""
        await session.execute(
            text("""
                INSERT INTO editorial.generation_tasks
                    (task_id, author_id, brief, task_type, lang, target_word_count,
                     research_query, input_data, status, priority)
                VALUES
                    (:tid, :aid, :brief, :ttype, :lang, :wc,
                     :rq, :idata::jsonb, 'pending', :priority)
                ON CONFLICT (task_id) DO NOTHING
            """),
            {
                "tid": task.task_id,
                "aid": author_id,
                "brief": task.brief,
                "ttype": task.task_type,
                "lang": task.lang,
                "wc": task.target_word_count,
                "rq": getattr(task, "research_query", None),
                "idata": json.dumps(getattr(task, "input_data", None) or {}),
                "priority": getattr(task, "priority", 5),
            },
        )
        await session.commit()

    async def _update_task_status(self, session: AsyncSession, task_id: str, status: str) -> None:
        """Обновить статус задания."""
        await session.execute(
            text("UPDATE editorial.generation_tasks SET status = :s, updated_at = NOW() WHERE task_id = :tid"),
            {"s": status, "tid": task_id},
        )
        await session.commit()

    async def _mark_task_error(self, session: AsyncSession, task_id: str, error_msg: str) -> None:
        """Зафиксировать ошибку пайплайна."""
        try:
            await session.execute(
                text(
                    "UPDATE editorial.generation_tasks "
                    "SET status = 'error', error_message = :msg, updated_at = NOW() "
                    "WHERE task_id = :tid"
                ),
                {"msg": error_msg[:1000], "tid": task_id},
            )
            await session.commit()
        except Exception as exc:
            logger.error("Failed to mark task error: %s", exc)

    async def _save_draft(
        self,
        session: AsyncSession,
        draft_id: str,
        task_id: str,
        iteration: int,
        content: str,
        research_context: str,
        research_sources: list[str],
        scoring_result: Optional[ScoringResult],
        status: str,
        llm_model: str,
        prompt_tokens: int,
        completion_tokens: int,
        cost_usd: float,
    ) -> None:
        """Сохранить черновик в editorial.drafts."""
        scores_json = json.dumps(scoring_result.scores if scoring_result else {})
        metrics_json = (
            scoring_result.style_metrics.model_dump_json()
            if (scoring_result and scoring_result.style_metrics)
            else None
        )
        await session.execute(
            text("""
                INSERT INTO editorial.drafts
                    (draft_id, task_id, iteration, content, word_count,
                     research_context, research_sources, style_metrics,
                     scores, overall_score, passes_threshold, critic_feedback,
                     llm_model, llm_cost_usd, prompt_tokens, completion_tokens)
                VALUES
                    (:did, :tid, :iter, :content, :wc,
                     :ctx, :sources::jsonb, :metrics::jsonb,
                     :scores::jsonb, :score, :passes, :feedback,
                     :model, :cost, :pt, :ct)
                ON CONFLICT (draft_id) DO UPDATE
                    SET content = EXCLUDED.content,
                        scores = EXCLUDED.scores,
                        overall_score = EXCLUDED.overall_score,
                        passes_threshold = EXCLUDED.passes_threshold,
                        critic_feedback = EXCLUDED.critic_feedback
            """),
            {
                "did": draft_id,
                "tid": task_id,
                "iter": iteration,
                "content": content,
                "wc": len(content.split()),
                "ctx": research_context[:5000] if research_context else None,
                "sources": json.dumps(research_sources),
                "metrics": metrics_json,
                "scores": scores_json,
                "score": scoring_result.overall_score if scoring_result else None,
                "passes": scoring_result.passes_threshold if scoring_result else False,
                "feedback": scoring_result.feedback if scoring_result else None,
                "model": llm_model,
                "cost": cost_usd,
                "pt": prompt_tokens,
                "ct": completion_tokens,
            },
        )
        await session.commit()

    async def _log_scoring(
        self,
        session: AsyncSession,
        draft_id: str,
        task_id: str,
        iteration: int,
        scoring_result: ScoringResult,
    ) -> None:
        """Записать результат scoring в editorial.scoring_log."""
        await session.execute(
            text("""
                INSERT INTO editorial.scoring_log
                    (draft_id, task_id, iteration, scores, overall_score, passes, feedback)
                VALUES
                    (:did, :tid, :iter, :scores::jsonb, :score, :passes, :feedback)
            """),
            {
                "did": draft_id,
                "tid": task_id,
                "iter": iteration,
                "scores": json.dumps(scoring_result.scores),
                "score": scoring_result.overall_score,
                "passes": scoring_result.passes_threshold,
                "feedback": scoring_result.feedback,
            },
        )
        await session.commit()

    async def _enqueue_hitl(
        self,
        session: AsyncSession,
        task_id: str,
        author: AuthorProfile,
        draft_content: str,
        iterations_used: int,
        final_scores: dict,
        overall_score: float,
        research_sources: list[str],
        priority: int,
        hard_gate_reason: Optional[str],
        status: str,
    ) -> None:
        """Добавить материал в HITL очередь."""
        title_line = draft_content.split("\n")[0].strip().lstrip("#").strip()
        title = title_line[:200] if title_line else "Без заголовка"

        await session.execute(
            text("""
                INSERT INTO editorial.hitl_queue
                    (task_id, author_id, author_name, title, content, lang, word_count,
                     iterations_used, final_scores, overall_score, research_sources,
                     status, hard_gate_reason, priority)
                VALUES
                    (:tid, :aid, :aname, :title, :content, :lang, :wc,
                     :iters, :scores::jsonb, :score, :sources::jsonb,
                     :status, :hg_reason, :priority)
                ON CONFLICT DO NOTHING
            """),
            {
                "tid": task_id,
                "aid": author.author_id,
                "aname": author.name,
                "title": title,
                "content": draft_content,
                "lang": getattr(author, "languages", ["ru"])[0] if getattr(author, "languages", None) else "ru",
                "wc": len(draft_content.split()),
                "iters": iterations_used,
                "scores": json.dumps(final_scores),
                "score": overall_score,
                "sources": json.dumps(research_sources),
                "status": status,
                "hg_reason": hard_gate_reason,
                "priority": priority,
            },
        )
        await session.commit()

    async def _save_publication(
        self,
        session: AsyncSession,
        task_id: str,
        draft_id: str,
        author: AuthorProfile,
        title: str,
        content: str,
        task: GenerationTask,
        final_scores: dict,
        overall_score: float,
        research_sources: list[str],
        budget: TokenBudget,
    ) -> None:
        """Сохранить публикацию в editorial.publications."""
        disclosure = {
            "ai_generated": True,
            "author_id": author.author_id,
            "author_name": author.name,
            "model": settings.editorial_llm_model,
            "draft_id": draft_id,
            "generated_at": datetime.now(UTC).isoformat(),
            "total_cost_usd": round(budget.spent_usd, 6),
        }
        lang = task.lang or "ru"
        wc = len(content.split())

        await session.execute(
            text("""
                INSERT INTO editorial.publications
                    (task_id, author_id, author_name, title, content, lang, word_count,
                     research_sources, final_scores, overall_score, disclosure_metadata)
                VALUES
                    (:tid, :aid, :aname, :title, :content, :lang, :wc,
                     :sources::jsonb, :scores::jsonb, :score, :disclosure::jsonb)
            """),
            {
                "tid": task_id,
                "aid": author.author_id,
                "aname": author.name,
                "title": title,
                "content": content,
                "lang": lang,
                "wc": wc,
                "sources": json.dumps(research_sources),
                "scores": json.dumps(final_scores),
                "score": overall_score,
                "disclosure": json.dumps(disclosure),
            },
        )
        await session.commit()


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────


def _get_max_iterations(author: AuthorProfile, task: GenerationTask) -> int:
    """Определить максимальное число итераций из профиля автора или settings."""
    # Жанровые конфиги имеют приоритет
    genre_configs = getattr(author, "genre_configs", {}) or {}
    genre_config = genre_configs.get(task.task_type)
    if genre_config is not None:
        max_iters = getattr(genre_config, "max_iterations", None)
        if max_iters:
            return max_iters

    # Пробуем author.thresholds.max_scoring_iterations
    thresholds = getattr(author, "thresholds", None)
    if thresholds is not None:
        max_iters = getattr(thresholds, "max_scoring_iterations", None)
        if max_iters:
            return max_iters

    # Fallback из author.max_iterations
    author_max = getattr(author, "max_iterations", None)
    if author_max:
        return author_max

    return settings.editorial_max_iterations
