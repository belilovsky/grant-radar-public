"""Capability and version-negotiation manifest for Open Kitchen consumers.

The event envelope remains the wire contract.  This manifest describes the
stable protocol around it so a producer and a renderer can agree on the same
stage registry without importing one another's runtime.
"""

from __future__ import annotations

from collections.abc import Iterable
from typing import Literal

from pydantic import Field, model_validator

from .contracts import (
    OPEN_KITCHEN_EVENT_TYPES,
    OPEN_KITCHEN_EVIDENCE_STATES,
    OPEN_KITCHEN_SCHEMA_VERSION,
    OPEN_KITCHEN_STAGE_CONTRACT,
    OPEN_KITCHEN_STAGE_IDS,
    OPEN_KITCHEN_STATUSES,
    OpenKitchenEventType,
    OpenKitchenEvidenceState,
    OpenKitchenStage,
    OpenKitchenStatus,
    _OpenKitchenModel,
)

OPEN_KITCHEN_MANIFEST_SCHEMA_VERSION = "qazstack-open-kitchen-manifest-v1"
OPEN_KITCHEN_CONTRACT_ID = "qazstack.open_kitchen"
OPEN_KITCHEN_CONTRACT_VERSION = "1.0.0"
OPEN_KITCHEN_STAGE_REGISTRY_VERSION = "qazstack-open-kitchen-stages-v1"
OPEN_KITCHEN_SUPPORTED_EVENT_SCHEMA_VERSIONS = (OPEN_KITCHEN_SCHEMA_VERSION,)

OpenKitchenEventSchemaVersion = Literal["qazstack-open-kitchen-event-v1"]
OpenKitchenContextKind = Literal["text", "document"]


class OpenKitchenManifest(_OpenKitchenModel):
    """Machine-readable capabilities shared by QMT, QazStack and AV DS 4."""

    schema_version: Literal["qazstack-open-kitchen-manifest-v1"] = OPEN_KITCHEN_MANIFEST_SCHEMA_VERSION
    contract_id: Literal["qazstack.open_kitchen"] = OPEN_KITCHEN_CONTRACT_ID
    contract_version: Literal["1.0.0"] = OPEN_KITCHEN_CONTRACT_VERSION
    event_schema_versions: tuple[OpenKitchenEventSchemaVersion, ...] = Field(min_length=1)
    preferred_event_schema_version: OpenKitchenEventSchemaVersion
    stage_registry_version: Literal["qazstack-open-kitchen-stages-v1"] = OPEN_KITCHEN_STAGE_REGISTRY_VERSION
    stages: tuple[OpenKitchenStage, ...] = Field(min_length=1)
    event_types: tuple[OpenKitchenEventType, ...] = Field(min_length=1)
    statuses: tuple[OpenKitchenStatus, ...] = Field(min_length=1)
    evidence_states: tuple[OpenKitchenEvidenceState, ...] = Field(min_length=1)
    contexts: tuple[OpenKitchenContextKind, ...] = Field(min_length=1)
    redaction_required: Literal[True] = True
    transport: Literal["consumer-owned"] = "consumer-owned"
    persistence: Literal["consumer-owned"] = "consumer-owned"
    ui: Literal["consumer-owned"] = "consumer-owned"
    backward_compatible_with: tuple[OpenKitchenEventSchemaVersion, ...] = Field(min_length=1)

    @model_validator(mode="after")
    def validate_registry(self) -> "OpenKitchenManifest":
        if self.preferred_event_schema_version not in self.event_schema_versions:
            raise ValueError("preferred event schema must be advertised")
        if tuple(self.event_schema_versions) != OPEN_KITCHEN_SUPPORTED_EVENT_SCHEMA_VERSIONS:
            raise ValueError("event schema versions do not match the registered protocol")
        if tuple(stage.id for stage in self.stages) != OPEN_KITCHEN_STAGE_IDS:
            raise ValueError("stages do not match the registered Open Kitchen stage order")
        if tuple(self.event_types) != OPEN_KITCHEN_EVENT_TYPES:
            raise ValueError("event types do not match the registered protocol")
        if tuple(self.statuses) != OPEN_KITCHEN_STATUSES:
            raise ValueError("statuses do not match the registered protocol")
        if tuple(self.evidence_states) != OPEN_KITCHEN_EVIDENCE_STATES:
            raise ValueError("evidence states do not match the registered protocol")
        if tuple(self.contexts) != ("text", "document"):
            raise ValueError("contexts do not match the registered protocol")
        if tuple(self.backward_compatible_with) != OPEN_KITCHEN_SUPPORTED_EVENT_SCHEMA_VERSIONS:
            raise ValueError("backward compatibility declarations do not match the protocol")
        for stage in self.stages:
            expected = OPEN_KITCHEN_STAGE_CONTRACT[stage.id]
            if (
                stage.ordinal != expected["ordinal"]
                or stage.lane != expected["lane"]
                or stage.label_key != expected["label_key"]
            ):
                raise ValueError(f"stage {stage.id} does not match the registered metadata")
        return self

    def supports_event_schema(self, schema_version: str) -> bool:
        """Return whether this manifest can consume the exact event schema."""

        return schema_version in self.event_schema_versions


def build_open_kitchen_manifest() -> OpenKitchenManifest:
    """Build the canonical manifest from the event contract constants."""

    stages = tuple(
        OpenKitchenStage.model_validate({"id": stage_id, **OPEN_KITCHEN_STAGE_CONTRACT[stage_id]})
        for stage_id in OPEN_KITCHEN_STAGE_IDS
    )
    return OpenKitchenManifest(
        event_schema_versions=OPEN_KITCHEN_SUPPORTED_EVENT_SCHEMA_VERSIONS,
        preferred_event_schema_version=OPEN_KITCHEN_SCHEMA_VERSION,
        stages=stages,
        event_types=OPEN_KITCHEN_EVENT_TYPES,
        statuses=OPEN_KITCHEN_STATUSES,
        evidence_states=OPEN_KITCHEN_EVIDENCE_STATES,
        contexts=("text", "document"),
        backward_compatible_with=OPEN_KITCHEN_SUPPORTED_EVENT_SCHEMA_VERSIONS,
    )


OPEN_KITCHEN_MANIFEST = build_open_kitchen_manifest()


def negotiate_open_kitchen_event_schema(
    peer_versions: Iterable[str],
    *,
    supported_versions: Iterable[str] = OPEN_KITCHEN_SUPPORTED_EVENT_SCHEMA_VERSIONS,
) -> str | None:
    """Choose the preferred exact event schema shared by two consumers.

    Unknown future versions are ignored.  A caller must install an explicit
    adapter before advertising a new event schema; this function never coerces
    one version into another.
    """

    if isinstance(peer_versions, (str, bytes)) or isinstance(supported_versions, (str, bytes)):
        raise TypeError("schema version lists must be iterables of strings")
    offered = {version for version in peer_versions if isinstance(version, str)}
    supported = {version for version in supported_versions if isinstance(version, str)}
    return next(
        (
            version
            for version in OPEN_KITCHEN_SUPPORTED_EVENT_SCHEMA_VERSIONS
            if version in offered and version in supported
        ),
        None,
    )
