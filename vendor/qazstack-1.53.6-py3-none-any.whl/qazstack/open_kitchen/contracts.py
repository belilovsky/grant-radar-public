"""Versioned, redacted event contract for a visible process run.

The contract describes evidence that a product has already decided is safe to
show. It does not execute a workflow, persist a journal, expose provider
payloads or prescribe a UI. Product runtimes own event production and
transport; consumers may render the same envelope as a timeline, dashboard or
mobile event log.
"""

from __future__ import annotations

import math
from datetime import datetime
from typing import Annotated, Literal, Union

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

OPEN_KITCHEN_SCHEMA_VERSION = "qazstack-open-kitchen-event-v1"
OPEN_KITCHEN_STAGE_IDS = (
    "intake",
    "memory",
    "routing",
    "engines",
    "critic",
    "synthesis",
    "quality",
    "style",
    "integrity",
    "result",
)
OPEN_KITCHEN_STAGE_CONTRACT = {
    "intake": {"ordinal": 1, "lane": "serial", "label_key": "pipeline.intake"},
    "memory": {"ordinal": 2, "lane": "serial", "label_key": "pipeline.memory"},
    "routing": {"ordinal": 3, "lane": "serial", "label_key": "pipeline.routing"},
    "engines": {"ordinal": 4, "lane": "parallel", "label_key": "pipeline.engines"},
    "critic": {"ordinal": 5, "lane": "serial", "label_key": "pipeline.critic"},
    "synthesis": {"ordinal": 6, "lane": "serial", "label_key": "pipeline.synthesis"},
    "quality": {"ordinal": 7, "lane": "gate", "label_key": "pipeline.quality"},
    "style": {"ordinal": 8, "lane": "gate", "label_key": "pipeline.style"},
    "integrity": {"ordinal": 9, "lane": "gate", "label_key": "pipeline.integrity"},
    "result": {"ordinal": 10, "lane": "serial", "label_key": "pipeline.result"},
}
OPEN_KITCHEN_EVENT_TYPES = (
    "run.started",
    "stage.started",
    "stage.completed",
    "stage.failed",
    "stage.cancelled",
    "run.completed",
    "run.failed",
    "run.cancelled",
)
OPEN_KITCHEN_STATUSES = ("running", "completed", "failed", "skipped", "cancelled")
OPEN_KITCHEN_EVIDENCE_STATES = ("verified", "observed", "derived", "missing")

OpenKitchenStageId = Literal[
    "intake",
    "memory",
    "routing",
    "engines",
    "critic",
    "synthesis",
    "quality",
    "style",
    "integrity",
    "result",
]
OpenKitchenLane = Literal["serial", "parallel", "gate"]
OpenKitchenEventType = Literal[
    "run.started",
    "stage.started",
    "stage.completed",
    "stage.failed",
    "stage.cancelled",
    "run.completed",
    "run.failed",
    "run.cancelled",
]
OpenKitchenStatus = Literal["running", "completed", "failed", "skipped", "cancelled"]
OpenKitchenEvidenceState = Literal["verified", "observed", "derived", "missing"]
OpenKitchenMetric = Union[str, bool, int, float]
OpenKitchenEvidenceRef = Annotated[str, Field(min_length=1, max_length=512)]
OpenKitchenMetricKey = Annotated[str, Field(min_length=1, max_length=128)]

_EVENT_STATUS = {
    "run.started": "running",
    "stage.started": "running",
    "stage.completed": "completed",
    "stage.failed": "failed",
    "stage.cancelled": "cancelled",
    "run.completed": "completed",
    "run.failed": "failed",
    "run.cancelled": "cancelled",
}


class _OpenKitchenModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class OpenKitchenActor(_OpenKitchenModel):
    """Safe actor identity; provider secrets and raw model output are excluded."""

    engine_id: str | None = Field(default=None, min_length=1, max_length=128)
    provider: str | None = Field(default=None, min_length=1, max_length=128)
    model_family: str | None = Field(default=None, min_length=1, max_length=128)


class OpenKitchenContext(_OpenKitchenModel):
    kind: Literal["text", "document"]
    document_id: str | None = Field(default=None, min_length=1, max_length=256)
    segment_index: int | None = Field(default=None, ge=0)
    total_segments: int | None = Field(default=None, ge=1)

    @model_validator(mode="after")
    def validate_scope(self) -> "OpenKitchenContext":
        if self.kind == "text" and any(
            value is not None for value in (self.document_id, self.segment_index, self.total_segments)
        ):
            raise ValueError("text context must not contain document or segment fields")
        if (
            self.segment_index is not None
            and self.total_segments is not None
            and self.segment_index >= self.total_segments
        ):
            raise ValueError("segment_index must be smaller than total_segments")
        return self


class OpenKitchenStage(_OpenKitchenModel):
    id: OpenKitchenStageId
    ordinal: int = Field(ge=1)
    lane: OpenKitchenLane
    label_key: str = Field(min_length=1, max_length=128)

    @model_validator(mode="after")
    def validate_registry_entry(self) -> "OpenKitchenStage":
        expected = OPEN_KITCHEN_STAGE_CONTRACT[self.id]
        if self.ordinal != expected["ordinal"]:
            raise ValueError("stage ordinal does not match the Open Kitchen registry")
        if self.lane != expected["lane"]:
            raise ValueError("stage lane does not match the Open Kitchen registry")
        if self.label_key != expected["label_key"]:
            raise ValueError("stage label_key does not match the Open Kitchen registry")
        return self


class OpenKitchenTiming(_OpenKitchenModel):
    duration_ms: float | None = Field(default=None, ge=0)
    since_previous_ms: float = Field(ge=0)

    @field_validator("duration_ms", "since_previous_ms")
    @classmethod
    def require_finite_timing(cls, value: float | None) -> float | None:
        if value is not None and not math.isfinite(value):
            raise ValueError("timing values must be finite")
        return value


class OpenKitchenEvidence(_OpenKitchenModel):
    state: OpenKitchenEvidenceState
    refs: list[OpenKitchenEvidenceRef] = Field(
        default_factory=list,
        max_length=32,
        json_schema_extra={"uniqueItems": True},
    )
    redacted: Literal[True] = True

    @field_validator("refs")
    @classmethod
    def validate_refs(cls, value: list[str]) -> list[str]:
        if any(not ref.strip() or len(ref) > 512 for ref in value):
            raise ValueError("evidence refs must be bounded non-empty strings")
        if len(value) != len(set(value)):
            raise ValueError("evidence refs must be unique")
        return value


class OpenKitchenDisplay(_OpenKitchenModel):
    safe_title: str = Field(min_length=1, max_length=240)
    safe_detail: str | None = Field(default=None, max_length=2000)

    @field_validator("safe_title", "safe_detail")
    @classmethod
    def require_display_copy(cls, value: str | None) -> str | None:
        if value is not None and not value.strip():
            raise ValueError("display copy must be non-empty")
        return value


class OpenKitchenEvent(_OpenKitchenModel):
    """One ordered, privacy-safe event suitable for public observation."""

    schema_version: Literal["qazstack-open-kitchen-event-v1"] = OPEN_KITCHEN_SCHEMA_VERSION
    event_id: str = Field(min_length=1, max_length=256)
    run_id: str = Field(min_length=1, max_length=256)
    correlation_id: str = Field(min_length=1, max_length=256)
    sequence: int = Field(ge=1)
    emitted_at: datetime
    source: str = Field(min_length=1, max_length=128)
    type: OpenKitchenEventType
    stage: OpenKitchenStage
    status: OpenKitchenStatus
    context: OpenKitchenContext | None = None
    actor: OpenKitchenActor | None = None
    timing: OpenKitchenTiming
    metrics: dict[OpenKitchenMetricKey, OpenKitchenMetric] = Field(
        default_factory=dict,
        max_length=32,
    )
    evidence: OpenKitchenEvidence
    display: OpenKitchenDisplay

    @field_validator("emitted_at")
    @classmethod
    def require_timezone(cls, value: datetime) -> datetime:
        if value.tzinfo is None or value.utcoffset() is None:
            raise ValueError("emitted_at must be timezone-aware")
        return value

    @field_validator("metrics")
    @classmethod
    def validate_metrics(cls, value: dict[str, OpenKitchenMetric]) -> dict[str, OpenKitchenMetric]:
        if len(value) > 32:
            raise ValueError("metrics must contain at most 32 entries")
        if any(not key.strip() or len(key) > 128 for key in value):
            raise ValueError("metric keys must be bounded non-empty strings")
        if any(isinstance(metric, float) and not math.isfinite(metric) for metric in value.values()):
            raise ValueError("metrics must contain finite numbers")
        return value

    @field_validator("event_id", "run_id", "correlation_id", "source")
    @classmethod
    def require_identity_fields(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("event identity fields must be non-empty")
        return value

    @model_validator(mode="after")
    def validate_event_status(self) -> "OpenKitchenEvent":
        expected = _EVENT_STATUS[self.type]
        if self.status != expected:
            raise ValueError(f"{self.type} requires status={expected}")
        return self
