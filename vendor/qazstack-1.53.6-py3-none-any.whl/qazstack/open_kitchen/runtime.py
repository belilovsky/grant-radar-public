"""Small, transport-neutral runtime helpers for Open Kitchen.

The event model is deliberately separate from this module.  Products still
own their workflow, persistence and transport; these helpers only make the
truthful lifecycle observable with monotonic sequence numbers, bounded
retention and a terminal-run boundary.
"""

from __future__ import annotations

from collections.abc import Callable, Iterable, Mapping
from dataclasses import dataclass
from datetime import datetime, timezone
from threading import RLock
from typing import Any, Literal, cast

from qazstack.contracts._validation import require_aware, require_text

from .contracts import (
    OPEN_KITCHEN_SCHEMA_VERSION,
    OPEN_KITCHEN_STAGE_CONTRACT,
    OpenKitchenActor,
    OpenKitchenContext,
    OpenKitchenEvent,
    OpenKitchenEvidenceState,
    OpenKitchenMetric,
    OpenKitchenStage,
)

OPEN_KITCHEN_TERMINAL_EVENT_TYPES = frozenset({"run.completed", "run.failed", "run.cancelled"})
OPEN_KITCHEN_STAGE_TERMINAL_TYPES = frozenset({"stage.completed", "stage.failed", "stage.cancelled"})
OPEN_KITCHEN_STAGE_TERMINAL_STATUSES = frozenset({"completed", "failed", "cancelled", "skipped"})

OpenKitchenRunState = Literal["idle", "running", "completed", "failed", "cancelled"]
OpenKitchenAppendReason = Literal["accepted", "duplicate", "late_after_terminal"]
OpenKitchenClock = Callable[[], datetime]
OpenKitchenSink = Callable[[OpenKitchenEvent], None]


class OpenKitchenStreamError(ValueError):
    """Raised when an event stream cannot be safely replayed."""


class OpenKitchenCapacityError(OpenKitchenStreamError):
    """Raised before a bounded journal silently grows beyond its safety cap."""


@dataclass(frozen=True, slots=True)
class OpenKitchenAppendResult:
    """Outcome of adding one event to a live or replay journal."""

    event: OpenKitchenEvent
    accepted: bool
    reason: OpenKitchenAppendReason


def utc_now() -> datetime:
    """Return a timezone-aware UTC timestamp for the default clock."""

    return datetime.now(timezone.utc)


def _coerce_event(value: OpenKitchenEvent | Mapping[str, Any]) -> OpenKitchenEvent:
    if isinstance(value, OpenKitchenEvent):
        return value
    return OpenKitchenEvent.model_validate(value)


def _terminal_type(value: OpenKitchenEvent) -> bool:
    return value.type in OPEN_KITCHEN_TERMINAL_EVENT_TYPES


def _normalise_clock(value: datetime, field_name: str = "clock") -> datetime:
    require_aware(value, field_name)
    return value.astimezone(timezone.utc)


def _stage_for(stage_id: str) -> OpenKitchenStage:
    metadata = OPEN_KITCHEN_STAGE_CONTRACT.get(stage_id)
    if metadata is None:
        raise OpenKitchenStreamError(f"unknown Open Kitchen stage: {stage_id}")
    return OpenKitchenStage(
        id=cast(Any, stage_id),
        ordinal=int(metadata["ordinal"]),
        lane=cast(Any, metadata["lane"]),
        label_key=str(metadata["label_key"]),
    )


class OpenKitchenLedger:
    """Bounded, idempotent event journal with a hard terminal boundary.

    The journal accepts out-of-order delivery for events that logically belong
    before a known terminal event, then exposes a sequence-ordered replay.  A
    new event after the terminal sequence is ignored.  Duplicate delivery is
    also ignored only when the event id and payload are identical; a collision
    is an error because it would make a replay ambiguous.
    """

    def __init__(self, run_id: str, *, max_events: int = 160) -> None:
        self.run_id = require_text(run_id, "run_id")
        if len(self.run_id) > 256:
            raise ValueError("run_id must be at most 256 characters")
        if isinstance(max_events, bool) or not isinstance(max_events, int) or max_events < 1:
            raise ValueError("max_events must be a positive integer")
        self.max_events = max_events
        self._events: list[OpenKitchenEvent] = []
        self._by_event_id: dict[str, OpenKitchenEvent] = {}
        self._by_sequence: dict[int, OpenKitchenEvent] = {}
        self._terminal: OpenKitchenEvent | None = None
        self._lock = RLock()

    @property
    def events(self) -> tuple[OpenKitchenEvent, ...]:
        with self._lock:
            return tuple(self._events)

    @property
    def terminal_event(self) -> OpenKitchenEvent | None:
        with self._lock:
            return self._terminal

    @property
    def state(self) -> OpenKitchenRunState:
        terminal = self.terminal_event
        if terminal is not None:
            return cast(OpenKitchenRunState, terminal.type.removeprefix("run."))
        return "running" if self._events else "idle"

    def append(self, value: OpenKitchenEvent | Mapping[str, Any]) -> OpenKitchenAppendResult:
        """Validate and append one event without ever reviving a run."""

        candidate = _coerce_event(value)
        with self._lock:
            if candidate.run_id != self.run_id:
                raise OpenKitchenStreamError("event belongs to a different run")

            existing_by_id = self._by_event_id.get(candidate.event_id)
            if existing_by_id is not None:
                if existing_by_id.model_dump(mode="json") != candidate.model_dump(mode="json"):
                    raise OpenKitchenStreamError("event_id collision carries a different payload")
                return OpenKitchenAppendResult(candidate, False, "duplicate")

            existing_by_sequence = self._by_sequence.get(candidate.sequence)
            if existing_by_sequence is not None:
                raise OpenKitchenStreamError("sequence collision carries a different event")

            if self._terminal is not None:
                if _terminal_type(candidate):
                    raise OpenKitchenStreamError("run already has a terminal event")
                if candidate.sequence > self._terminal.sequence:
                    return OpenKitchenAppendResult(candidate, False, "late_after_terminal")
            elif _terminal_type(candidate) and any(event.sequence > candidate.sequence for event in self._events):
                raise OpenKitchenStreamError("terminal event cannot precede an already accepted event")

            if len(self._events) >= self.max_events:
                raise OpenKitchenCapacityError(
                    f"Open Kitchen journal exceeded max_events={self.max_events}; "
                    "raise the product-owned retention limit explicitly"
                )

            if candidate.type == "run.started" and any(item.type == "run.started" for item in self._events):
                raise OpenKitchenStreamError("run.started may occur only once")

            self._events.append(candidate)
            self._events.sort(key=lambda item: item.sequence)
            self._by_event_id[candidate.event_id] = candidate
            self._by_sequence[candidate.sequence] = candidate
            if _terminal_type(candidate):
                self._terminal = candidate
            return OpenKitchenAppendResult(candidate, True, "accepted")

    def replay(self, *, limit: int | None = None) -> tuple[OpenKitchenEvent, ...]:
        """Return a bounded sequence-ordered snapshot for a consumer renderer."""

        if limit is not None and (isinstance(limit, bool) or not isinstance(limit, int) or limit < 1):
            raise ValueError("limit must be a positive integer when provided")
        events = self.events
        return events if limit is None else events[-limit:]

    def validate(
        self,
        *,
        require_started: bool = False,
        require_terminal: bool = False,
    ) -> tuple[OpenKitchenEvent, ...]:
        """Run the complete-stream checks against the current snapshot."""

        return validate_open_kitchen_stream(
            self.events,
            expected_run_id=self.run_id,
            require_started=require_started,
            require_terminal=require_terminal,
            max_events=self.max_events,
        )


def validate_open_kitchen_stream(
    events: Iterable[OpenKitchenEvent | Mapping[str, Any]],
    *,
    expected_run_id: str | None = None,
    require_started: bool = False,
    require_terminal: bool = False,
    max_events: int = 160,
) -> tuple[OpenKitchenEvent, ...]:
    """Validate a replayable stream and return it in sequence order.

    Partial live streams are allowed by default.  Consumers that are about to
    publish a completed replay should set both ``require_started`` and
    ``require_terminal``.  Sequence numbers may have gaps in a partial stream,
    but duplicate ids/sequences, source drift, timestamp reversal and events
    after a terminal run event are always rejected.
    """

    if isinstance(max_events, bool) or not isinstance(max_events, int) or max_events < 1:
        raise ValueError("max_events must be a positive integer")
    normalised = [_coerce_event(value) for value in events]
    if len(normalised) > max_events:
        raise OpenKitchenCapacityError(f"Open Kitchen stream exceeds max_events={max_events}")
    if not normalised:
        if require_started or require_terminal:
            raise OpenKitchenStreamError("required Open Kitchen stream events are missing")
        return ()

    run_id = normalised[0].run_id
    correlation_id = normalised[0].correlation_id
    source = normalised[0].source
    if expected_run_id is not None and run_id != expected_run_id:
        raise OpenKitchenStreamError("stream contains an unexpected run_id")

    event_ids: set[str] = set()
    sequences: set[int] = set()
    for event in normalised:
        if event.run_id != run_id:
            raise OpenKitchenStreamError("stream mixes multiple run_id values")
        if event.correlation_id != correlation_id:
            raise OpenKitchenStreamError("stream mixes multiple correlation_id values")
        if event.source != source:
            raise OpenKitchenStreamError("stream mixes multiple source values")
        if event.event_id in event_ids:
            raise OpenKitchenStreamError("stream contains a duplicate event_id")
        if event.sequence in sequences:
            raise OpenKitchenStreamError("stream contains a duplicate sequence")
        event_ids.add(event.event_id)
        sequences.add(event.sequence)

    ordered = tuple(sorted(normalised, key=lambda item: item.sequence))
    for previous, current in zip(ordered, ordered[1:]):
        if current.emitted_at < previous.emitted_at:
            raise OpenKitchenStreamError("emitted_at must not move backwards in sequence order")

    started = [event for event in ordered if event.type == "run.started"]
    if len(started) > 1:
        raise OpenKitchenStreamError("run.started may occur only once")
    if require_started and (not started or started[0] is not ordered[0]):
        raise OpenKitchenStreamError("a complete stream must start with run.started")

    terminals = [event for event in ordered if _terminal_type(event)]
    if len(terminals) > 1:
        raise OpenKitchenStreamError("a run may have only one terminal event")
    if require_terminal and not terminals:
        raise OpenKitchenStreamError("a complete stream must end with a terminal run event")
    if terminals:
        terminal = terminals[0]
        if terminal is not ordered[-1]:
            raise OpenKitchenStreamError("events after a terminal run event are not replayable")

    return ordered


@dataclass(frozen=True, slots=True)
class _ActiveStage:
    started_at: datetime
    context: OpenKitchenContext | None


class OpenKitchenRun:
    """Reference emitter for a product-owned process run.

    It assigns event ids and timings, closes active stages on failure/cancel,
    publishes to an optional sink, and makes terminal callbacks idempotent.
    It never executes a workflow, stores raw provider payloads or decides what
    a product is allowed to publish.
    """

    def __init__(
        self,
        run_id: str,
        source: str,
        *,
        correlation_id: str | None = None,
        base_context: OpenKitchenContext | None = None,
        clock: OpenKitchenClock = utc_now,
        sink: OpenKitchenSink | None = None,
        max_events: int = 160,
    ) -> None:
        self.run_id = require_text(run_id, "run_id")
        self.source = require_text(source, "source")
        self.correlation_id = require_text(correlation_id or self.run_id, "correlation_id")
        if len(self.source) > 128 or len(self.correlation_id) > 256:
            raise ValueError("source or correlation_id exceeds the Open Kitchen limit")
        self.base_context = base_context
        self._clock = clock
        self._sink = sink
        self._ledger = OpenKitchenLedger(self.run_id, max_events=max_events)
        now = _normalise_clock(clock())
        self._previous_at = now
        self._sequence = 0
        self._started = False
        self._start_event: OpenKitchenEvent | None = None
        self._terminal_event: OpenKitchenEvent | None = None
        self._active_stages: dict[tuple[str, str], _ActiveStage] = {}
        self._late_events = 0
        self._lock = RLock()

    @property
    def events(self) -> tuple[OpenKitchenEvent, ...]:
        return self._ledger.events

    @property
    def terminal_event(self) -> OpenKitchenEvent | None:
        return self._terminal_event

    @property
    def state(self) -> OpenKitchenRunState:
        if self._terminal_event is not None:
            return cast(OpenKitchenRunState, self._terminal_event.type.removeprefix("run."))
        return "running" if self._started else "idle"

    @property
    def late_event_count(self) -> int:
        return self._late_events

    def replay(self, *, limit: int | None = None) -> tuple[OpenKitchenEvent, ...]:
        return self._ledger.replay(limit=limit)

    def emit(
        self,
        *,
        type: str,
        stage: str | OpenKitchenStage,
        status: str,
        safe_title: str,
        safe_detail: str | None = None,
        context: OpenKitchenContext | None = None,
        actor: OpenKitchenActor | Mapping[str, Any] | None = None,
        metrics: Mapping[str, OpenKitchenMetric] | None = None,
        evidence_state: OpenKitchenEvidenceState = "observed",
        evidence_refs: Iterable[str] = (),
    ) -> OpenKitchenEvent:
        """Emit one already-redacted lifecycle event.

        ``safe_title`` and ``safe_detail`` are deliberately named to keep raw
        provider responses out of the reusable API.  Products must prepare
        safe copy before calling this method.
        """

        with self._lock:
            if self._terminal_event is not None:
                self._late_events += 1
                return self._terminal_event

            now = _normalise_clock(self._clock())
            if now < self._previous_at:
                now = self._previous_at
            stage_value = stage if isinstance(stage, OpenKitchenStage) else _stage_for(stage)
            if actor is not None and not isinstance(actor, OpenKitchenActor):
                actor = OpenKitchenActor.model_validate(actor)
            effective_context = context if context is not None else self.base_context
            engine_id = actor.engine_id if actor is not None else ""
            stage_key = (stage_value.id, engine_id)
            active = self._active_stages.get(stage_key)
            if status == "running":
                self._active_stages[stage_key] = _ActiveStage(now, effective_context)

            duration_ms: float | None = None
            if type in OPEN_KITCHEN_STAGE_TERMINAL_TYPES or status in OPEN_KITCHEN_STAGE_TERMINAL_STATUSES:
                if active is not None:
                    duration_ms = max(0.0, (now - active.started_at).total_seconds() * 1000.0)
                self._active_stages.pop(stage_key, None)

            event = OpenKitchenEvent.model_validate(
                {
                    "schema_version": OPEN_KITCHEN_SCHEMA_VERSION,
                    "event_id": f"{self.run_id}:{self._sequence + 1}",
                    "run_id": self.run_id,
                    "correlation_id": self.correlation_id,
                    "sequence": self._sequence + 1,
                    "emitted_at": now,
                    "source": self.source,
                    "type": type,
                    "stage": stage_value,
                    "status": status,
                    **({"context": effective_context} if effective_context is not None else {}),
                    **({"actor": actor} if actor is not None else {}),
                    "timing": {
                        "since_previous_ms": max(0.0, (now - self._previous_at).total_seconds() * 1000.0),
                        **({"duration_ms": duration_ms} if duration_ms is not None else {}),
                    },
                    "metrics": dict(metrics or {}),
                    "evidence": {
                        "state": evidence_state,
                        "refs": list(evidence_refs),
                        "redacted": True,
                    },
                    "display": {
                        "safe_title": safe_title,
                        **({"safe_detail": safe_detail} if safe_detail is not None else {}),
                    },
                }
            )
            result = self._ledger.append(event)
            if not result.accepted:
                raise OpenKitchenStreamError("emitter generated a duplicate event")
            self._sequence = event.sequence
            self._previous_at = now
            if _terminal_type(event):
                self._terminal_event = event
            if self._sink is not None:
                self._sink(event)
            return event

    def start(self) -> OpenKitchenEvent:
        with self._lock:
            if self._start_event is not None:
                return self._start_event
            self._started = True
            self.emit(
                type="run.started",
                stage="intake",
                status="running",
                safe_title="Новый run принят",
                safe_detail="Пайплайн открыт для наблюдения",
                evidence_state="verified",
            )
            self._start_event = self.emit(
                type="stage.completed",
                stage="intake",
                status="completed",
                safe_title="Входные данные приняты",
                safe_detail="Запрос принят в текущий run",
                evidence_state="verified",
            )
            return self._start_event

    def _ensure_started(self) -> None:
        if not self._started:
            self.start()

    def _close_active_stages(self, status: Literal["failed", "cancelled"]) -> None:
        active = list(self._active_stages.items())
        for (stage_id, engine_id), state in active:
            self.emit(
                type="stage.cancelled" if status == "cancelled" else "stage.failed",
                stage=stage_id,
                status=status,
                safe_title="Этап остановлен" if status == "cancelled" else "Этап завершён с ошибкой",
                safe_detail=(
                    "Run отменён до завершения этапа" if status == "cancelled" else "Этап закрыт после сбоя run"
                ),
                context=state.context,
                actor=OpenKitchenActor(engine_id=engine_id) if engine_id else None,
                evidence_state="observed",
            )

    def complete(
        self,
        *,
        safe_title: str = "Итоговый результат принят",
        safe_detail: str = "Результат сохранён и готов к проверке",
        context: OpenKitchenContext | None = None,
        metrics: Mapping[str, OpenKitchenMetric] | None = None,
        evidence_state: OpenKitchenEvidenceState = "verified",
    ) -> OpenKitchenEvent:
        with self._lock:
            if self._terminal_event is not None:
                return self._terminal_event
            self._ensure_started()
            self.emit(
                type="stage.completed",
                stage="result",
                status="completed",
                safe_title=safe_title,
                safe_detail=safe_detail,
                context=context,
                metrics=metrics,
                evidence_state=evidence_state,
            )
            return self.emit(
                type="run.completed",
                stage="result",
                status="completed",
                safe_title="Run завершён",
                safe_detail=safe_detail,
                context=context,
                metrics=metrics,
                evidence_state=evidence_state,
            )

    def fail(
        self,
        *,
        safe_title: str = "Итоговый результат не принят",
        safe_detail: str = "Надёжный итоговый результат не получен",
        context: OpenKitchenContext | None = None,
        metrics: Mapping[str, OpenKitchenMetric] | None = None,
        evidence_state: OpenKitchenEvidenceState = "observed",
    ) -> OpenKitchenEvent:
        with self._lock:
            if self._terminal_event is not None:
                return self._terminal_event
            self._ensure_started()
            self._close_active_stages("failed")
            self.emit(
                type="stage.failed",
                stage="result",
                status="failed",
                safe_title=safe_title,
                safe_detail=safe_detail,
                context=context,
                metrics=metrics,
                evidence_state=evidence_state,
            )
            return self.emit(
                type="run.failed",
                stage="result",
                status="failed",
                safe_title="Run завершён с ошибкой",
                safe_detail=safe_detail,
                context=context,
                metrics=metrics,
                evidence_state=evidence_state,
            )

    def cancel(
        self,
        *,
        safe_title: str = "Run отменён",
        safe_detail: str = "Соединение закрыто до завершения пайплайна",
        context: OpenKitchenContext | None = None,
        metrics: Mapping[str, OpenKitchenMetric] | None = None,
        evidence_state: OpenKitchenEvidenceState = "observed",
    ) -> OpenKitchenEvent:
        with self._lock:
            if self._terminal_event is not None:
                return self._terminal_event
            self._ensure_started()
            self._close_active_stages("cancelled")
            return self.emit(
                type="run.cancelled",
                stage="result",
                status="cancelled",
                safe_title=safe_title,
                safe_detail=safe_detail,
                context=context,
                metrics=metrics,
                evidence_state=evidence_state,
            )
