"""QazStack – modular Python toolkit for FastAPI web projects.

Submodules
----------
qazstack.translate
    Unified ru/kk/en translation via OpenAI or DeepSeek; legacy provider key
    ``kz`` is accepted only at the internal compatibility boundary.
    Usage::

        from qazstack.translate import translate, translate_sync
"""

__version__ = "1.53.6"
