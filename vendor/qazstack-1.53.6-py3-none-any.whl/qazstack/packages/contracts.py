"""Content Package interchange contracts for Information Production OS.

These contracts establish a shared language between existing products without
moving ownership of source captures, editorial decisions, task queues or public
publication storage into QazStack.
"""

from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from qazstack.contracts._validation import (
    require_aware,
    require_identifier,
    require_one_of,
    require_ratio,
    require_text,
)

CONTENT_PACKAGE_SCHEMA_VERSION = "qazstack-content-package-v1"
CONTENT_PACKAGE_EVENT_SCHEMA_VERSION = "qazstack-content-package-event-v1"
PACKAGE_WORK_ITEM_SCHEMA_VERSION = "qazstack-package-work-item-v1"
DERIVATIVE_SCHEMA_VERSION = "qazstack-package-derivative-v1"
PACKAGE_GRAPH_CANDIDATE_SCHEMA_VERSION = "qazstack-package-graph-candidate-v1"

PACKAGE_STATUSES = frozenset({"planned", "active", "paused", "archived"})
PACKAGE_EVENT_TYPES = frozenset(
    {
        "package.draft.proposed",
        "package.evidence.linked",
        "package.entity.linked",
        "package.work.requested",
        "package.derivative.linked",
    }
)
WORK_ITEM_KINDS = frozenset({"editorial-case", "research", "factcheck", "review", "publication"})
WORK_ITEM_STATES = frozenset({"draft", "ready", "blocked", "done"})
DERIVATIVE_KINDS = frozenset({"article", "digest", "brief", "social", "timeline", "dataset", "briefing"})
PACKAGE_GRAPH_OBJECT_TYPES = frozenset({"node", "edge"})
PACKAGE_GRAPH_REVIEW_STATES = frozenset({"candidate", "reviewed", "rejected", "superseded"})
PACKAGE_FIELDS = frozenset(
    {
        "schema_version",
        "package_id",
        "title",
        "topic_ref",
        "status",
        "summary",
        "source_refs",
        "entity_refs",
        "evidence_refs",
    }
)
EVENT_FIELDS = frozenset(
    {"schema_version", "event_id", "event_type", "package_id", "occurred_at", "producer", "data", "correlation_id"}
)
WORK_ITEM_FIELDS = frozenset(
    {"schema_version", "work_item_id", "package_id", "kind", "state", "title", "owner_service", "source_ref"}
)
DERIVATIVE_FIELDS = frozenset(
    {"schema_version", "derivative_id", "package_id", "kind", "title", "publication_ref", "source_ref"}
)
BUNDLE_FIELDS = frozenset({"schema_version", "package", "events", "work_items", "derivatives"})
GRAPH_CANDIDATE_FIELDS = frozenset(
    {
        "schema_version",
        "candidate_id",
        "package_id",
        "object_type",
        "object_id",
        "label",
        "source_ref",
        "evidence_refs",
        "producer",
        "confidence",
        "review_state",
        "valid_from",
        "valid_to",
        "created_at",
        "idempotency_key",
        "data",
    }
)


def _reject_unknown_fields(payload: Mapping[str, object], allowed: frozenset[str], field_name: str) -> None:
    unknown = sorted(str(key) for key in payload if key not in allowed)
    if unknown:
        raise ValueError(f"{field_name} contains unknown fields: {', '.join(unknown)}")


def _as_mapping(value: object, field_name: str) -> Mapping[str, object]:
    if not isinstance(value, Mapping):
        raise ValueError(f"{field_name} must be an object")
    return value


def _as_tuple(value: object, field_name: str) -> tuple[str, ...]:
    if value is None:
        return ()
    if isinstance(value, (str, bytes)) or not isinstance(value, Sequence):
        raise ValueError(f"{field_name} must be an array")
    normalized = tuple(require_text(str(item), f"{field_name} item") for item in value)
    if len(normalized) != len(set(normalized)):
        raise ValueError(f"{field_name} must not contain duplicate values")
    return normalized


def _as_tuple_of_mappings(value: object, field_name: str) -> tuple[Mapping[str, object], ...]:
    if value is None:
        return ()
    if isinstance(value, (str, bytes)) or not isinstance(value, Sequence):
        raise ValueError(f"{field_name} must be an array")
    return tuple(_as_mapping(item, f"{field_name} item") for item in value)


def _optional_text(value: object, field_name: str) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str):
        raise ValueError(f"{field_name} must be a string")
    return require_text(str(value), field_name)


def _datetime(value: object, field_name: str) -> datetime:
    if isinstance(value, datetime):
        parsed = value
    elif isinstance(value, str):
        try:
            parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError as exc:
            raise ValueError(f"{field_name} must be an ISO-8601 timestamp") from exc
    else:
        raise ValueError(f"{field_name} must be an ISO-8601 timestamp")
    require_aware(parsed, field_name)
    return parsed.astimezone(timezone.utc)


def _optional_datetime(value: object, field_name: str) -> datetime | None:
    if value is None:
        return None
    return _datetime(value, field_name)


def _stable_digest(payload: Mapping[str, Any]) -> str:
    encoded = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return f"sha256:{hashlib.sha256(encoded).hexdigest()}"


@dataclass(frozen=True, slots=True)
class ContentPackageDraft:
    """A proposed long-lived topic package without product-local private data."""

    package_id: str
    title: str
    topic_ref: str
    status: str = "planned"
    summary: str = ""
    source_refs: tuple[str, ...] = ()
    entity_refs: tuple[str, ...] = ()
    evidence_refs: tuple[str, ...] = ()
    schema_version: str = field(default=CONTENT_PACKAGE_SCHEMA_VERSION, init=False)

    def __post_init__(self) -> None:
        require_identifier(self.package_id, "package_id")
        require_text(self.title, "title")
        require_text(self.topic_ref, "topic_ref")
        require_one_of(self.status, PACKAGE_STATUSES, "status")
        if self.summary:
            require_text(self.summary, "summary")
        object.__setattr__(self, "source_refs", _as_tuple(self.source_refs, "source_refs"))
        object.__setattr__(self, "entity_refs", _as_tuple(self.entity_refs, "entity_refs"))
        object.__setattr__(self, "evidence_refs", _as_tuple(self.evidence_refs, "evidence_refs"))

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "schema_version": self.schema_version,
            "package_id": self.package_id,
            "title": self.title,
            "topic_ref": self.topic_ref,
            "status": self.status,
            "source_refs": list(self.source_refs),
            "entity_refs": list(self.entity_refs),
            "evidence_refs": list(self.evidence_refs),
        }
        if self.summary:
            payload["summary"] = self.summary
        return payload

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> "ContentPackageDraft":
        _reject_unknown_fields(payload, PACKAGE_FIELDS, "content package")
        if payload.get("schema_version") != CONTENT_PACKAGE_SCHEMA_VERSION:
            raise ValueError(f"schema_version must be {CONTENT_PACKAGE_SCHEMA_VERSION}")
        return cls(
            package_id=str(payload.get("package_id", "")),
            title=str(payload.get("title", "")),
            topic_ref=str(payload.get("topic_ref", "")),
            status=str(payload.get("status", "planned")),
            summary=str(payload.get("summary", "")),
            source_refs=_as_tuple(payload.get("source_refs"), "source_refs"),
            entity_refs=_as_tuple(payload.get("entity_refs"), "entity_refs"),
            evidence_refs=_as_tuple(payload.get("evidence_refs"), "evidence_refs"),
        )

    def digest(self) -> str:
        """Return a stable package fingerprint for draft comparison."""
        return _stable_digest(self.to_dict())


@dataclass(frozen=True, slots=True)
class PackageEvent:
    """Transport-neutral package event envelope."""

    event_id: str
    event_type: str
    package_id: str
    occurred_at: datetime
    producer: str
    data: Mapping[str, Any]
    correlation_id: str | None = None
    schema_version: str = field(default=CONTENT_PACKAGE_EVENT_SCHEMA_VERSION, init=False)

    def __post_init__(self) -> None:
        require_identifier(self.event_id, "event_id")
        require_one_of(self.event_type, PACKAGE_EVENT_TYPES, "event_type")
        require_identifier(self.package_id, "package_id")
        object.__setattr__(self, "occurred_at", _datetime(self.occurred_at, "occurred_at"))
        require_identifier(self.producer, "producer")
        if not isinstance(self.data, Mapping):
            raise ValueError("data must be an object")
        object.__setattr__(self, "correlation_id", _optional_text(self.correlation_id, "correlation_id"))

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "schema_version": self.schema_version,
            "event_id": self.event_id,
            "event_type": self.event_type,
            "package_id": self.package_id,
            "occurred_at": self.occurred_at.isoformat().replace("+00:00", "Z"),
            "producer": self.producer,
            "data": dict(self.data),
        }
        if self.correlation_id is not None:
            payload["correlation_id"] = self.correlation_id
        return payload

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> "PackageEvent":
        _reject_unknown_fields(payload, EVENT_FIELDS, "package event")
        if payload.get("schema_version") != CONTENT_PACKAGE_EVENT_SCHEMA_VERSION:
            raise ValueError(f"schema_version must be {CONTENT_PACKAGE_EVENT_SCHEMA_VERSION}")
        return cls(
            event_id=str(payload.get("event_id", "")),
            event_type=str(payload.get("event_type", "")),
            package_id=str(payload.get("package_id", "")),
            occurred_at=_datetime(payload.get("occurred_at"), "occurred_at"),
            producer=str(payload.get("producer", "")),
            data=_as_mapping(payload.get("data"), "data"),
            correlation_id=_optional_text(payload.get("correlation_id"), "correlation_id"),
        )


@dataclass(frozen=True, slots=True)
class PackageWorkItem:
    """A package-linked work reference, not a task queue replacement."""

    work_item_id: str
    package_id: str
    kind: str
    state: str
    title: str
    owner_service: str
    source_ref: str
    schema_version: str = field(default=PACKAGE_WORK_ITEM_SCHEMA_VERSION, init=False)

    def __post_init__(self) -> None:
        require_identifier(self.work_item_id, "work_item_id")
        require_identifier(self.package_id, "package_id")
        require_one_of(self.kind, WORK_ITEM_KINDS, "kind")
        require_one_of(self.state, WORK_ITEM_STATES, "state")
        require_text(self.title, "title")
        require_identifier(self.owner_service, "owner_service")
        require_text(self.source_ref, "source_ref")

    def to_dict(self) -> dict[str, str]:
        return {
            "schema_version": self.schema_version,
            "work_item_id": self.work_item_id,
            "package_id": self.package_id,
            "kind": self.kind,
            "state": self.state,
            "title": self.title,
            "owner_service": self.owner_service,
            "source_ref": self.source_ref,
        }

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> "PackageWorkItem":
        _reject_unknown_fields(payload, WORK_ITEM_FIELDS, "package work item")
        if payload.get("schema_version") != PACKAGE_WORK_ITEM_SCHEMA_VERSION:
            raise ValueError(f"schema_version must be {PACKAGE_WORK_ITEM_SCHEMA_VERSION}")
        return cls(
            work_item_id=str(payload.get("work_item_id", "")),
            package_id=str(payload.get("package_id", "")),
            kind=str(payload.get("kind", "")),
            state=str(payload.get("state", "")),
            title=str(payload.get("title", "")),
            owner_service=str(payload.get("owner_service", "")),
            source_ref=str(payload.get("source_ref", "")),
        )


@dataclass(frozen=True, slots=True)
class PackageDerivative:
    """A package-linked public or internal output reference."""

    derivative_id: str
    package_id: str
    kind: str
    title: str
    publication_ref: str
    source_ref: str
    schema_version: str = field(default=DERIVATIVE_SCHEMA_VERSION, init=False)

    def __post_init__(self) -> None:
        require_identifier(self.derivative_id, "derivative_id")
        require_identifier(self.package_id, "package_id")
        require_one_of(self.kind, DERIVATIVE_KINDS, "kind")
        require_text(self.title, "title")
        require_text(self.publication_ref, "publication_ref")
        require_text(self.source_ref, "source_ref")

    def to_dict(self) -> dict[str, str]:
        return {
            "schema_version": self.schema_version,
            "derivative_id": self.derivative_id,
            "package_id": self.package_id,
            "kind": self.kind,
            "title": self.title,
            "publication_ref": self.publication_ref,
            "source_ref": self.source_ref,
        }

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> "PackageDerivative":
        _reject_unknown_fields(payload, DERIVATIVE_FIELDS, "package derivative")
        if payload.get("schema_version") != DERIVATIVE_SCHEMA_VERSION:
            raise ValueError(f"schema_version must be {DERIVATIVE_SCHEMA_VERSION}")
        return cls(
            derivative_id=str(payload.get("derivative_id", "")),
            package_id=str(payload.get("package_id", "")),
            kind=str(payload.get("kind", "")),
            title=str(payload.get("title", "")),
            publication_ref=str(payload.get("publication_ref", "")),
            source_ref=str(payload.get("source_ref", "")),
        )


@dataclass(frozen=True, slots=True)
class PackageGraphCandidate:
    """A package-bound candidate graph node or edge, not reviewed graph truth."""

    candidate_id: str
    package_id: str
    object_type: str
    object_id: str
    label: str
    source_ref: str
    evidence_refs: tuple[str, ...]
    producer: str
    confidence: float
    review_state: str = "candidate"
    valid_from: datetime | None = None
    valid_to: datetime | None = None
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    idempotency_key: str = ""
    data: Mapping[str, Any] = field(default_factory=dict)
    schema_version: str = field(default=PACKAGE_GRAPH_CANDIDATE_SCHEMA_VERSION, init=False)

    def __post_init__(self) -> None:
        require_identifier(self.candidate_id, "candidate_id")
        require_identifier(self.package_id, "package_id")
        require_one_of(self.object_type, PACKAGE_GRAPH_OBJECT_TYPES, "object_type")
        require_identifier(self.object_id, "object_id")
        require_text(self.label, "label")
        require_text(self.source_ref, "source_ref")
        object.__setattr__(self, "evidence_refs", _as_tuple(self.evidence_refs, "evidence_refs"))
        if not self.evidence_refs:
            raise ValueError("package graph candidates require evidence_refs")
        require_identifier(self.producer, "producer")
        require_ratio(self.confidence, "confidence")
        require_one_of(self.review_state, PACKAGE_GRAPH_REVIEW_STATES, "review_state")
        object.__setattr__(self, "valid_from", _optional_datetime(self.valid_from, "valid_from"))
        object.__setattr__(self, "valid_to", _optional_datetime(self.valid_to, "valid_to"))
        if self.valid_from and self.valid_to and self.valid_to < self.valid_from:
            raise ValueError("valid_to cannot precede valid_from")
        object.__setattr__(self, "created_at", _datetime(self.created_at, "created_at"))
        if not self.idempotency_key:
            object.__setattr__(self, "idempotency_key", self.digest())
        else:
            require_text(self.idempotency_key, "idempotency_key")
        if not isinstance(self.data, Mapping):
            raise ValueError("data must be an object")

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "schema_version": self.schema_version,
            "candidate_id": self.candidate_id,
            "package_id": self.package_id,
            "object_type": self.object_type,
            "object_id": self.object_id,
            "label": self.label,
            "source_ref": self.source_ref,
            "evidence_refs": list(self.evidence_refs),
            "producer": self.producer,
            "confidence": self.confidence,
            "review_state": self.review_state,
            "created_at": self.created_at.isoformat().replace("+00:00", "Z"),
            "idempotency_key": self.idempotency_key,
            "data": dict(self.data),
        }
        if self.valid_from is not None:
            payload["valid_from"] = self.valid_from.isoformat().replace("+00:00", "Z")
        if self.valid_to is not None:
            payload["valid_to"] = self.valid_to.isoformat().replace("+00:00", "Z")
        return payload

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> "PackageGraphCandidate":
        _reject_unknown_fields(payload, GRAPH_CANDIDATE_FIELDS, "package graph candidate")
        if payload.get("schema_version") != PACKAGE_GRAPH_CANDIDATE_SCHEMA_VERSION:
            raise ValueError(f"schema_version must be {PACKAGE_GRAPH_CANDIDATE_SCHEMA_VERSION}")
        return cls(
            candidate_id=str(payload.get("candidate_id", "")),
            package_id=str(payload.get("package_id", "")),
            object_type=str(payload.get("object_type", "")),
            object_id=str(payload.get("object_id", "")),
            label=str(payload.get("label", "")),
            source_ref=str(payload.get("source_ref", "")),
            evidence_refs=_as_tuple(payload.get("evidence_refs"), "evidence_refs"),
            producer=str(payload.get("producer", "")),
            confidence=float(payload.get("confidence", -1)),
            review_state=str(payload.get("review_state", "candidate")),
            valid_from=_optional_datetime(payload.get("valid_from"), "valid_from"),
            valid_to=_optional_datetime(payload.get("valid_to"), "valid_to"),
            created_at=_datetime(payload.get("created_at"), "created_at"),
            idempotency_key=str(payload.get("idempotency_key", "")),
            data=_as_mapping(payload.get("data"), "data"),
        )

    def digest(self) -> str:
        """Return a stable candidate fingerprint without self-referential idempotency."""
        payload = self.to_dict()
        payload.pop("idempotency_key", None)
        return _stable_digest(payload)


@dataclass(frozen=True, slots=True)
class ContentPackageBundle:
    """A schema-shaped package exchange bundle with internal package-id checks."""

    package: ContentPackageDraft
    events: tuple[PackageEvent, ...] = ()
    work_items: tuple[PackageWorkItem, ...] = ()
    derivatives: tuple[PackageDerivative, ...] = ()
    schema_version: str = field(default=CONTENT_PACKAGE_SCHEMA_VERSION, init=False)

    def __post_init__(self) -> None:
        if not isinstance(self.package, ContentPackageDraft):
            raise ValueError("package must be a ContentPackageDraft")
        object.__setattr__(self, "events", tuple(self.events))
        object.__setattr__(self, "work_items", tuple(self.work_items))
        object.__setattr__(self, "derivatives", tuple(self.derivatives))
        related_ids = [item.package_id for item in (*self.events, *self.work_items, *self.derivatives)]
        mismatches = sorted({package_id for package_id in related_ids if package_id != self.package.package_id})
        if mismatches:
            raise ValueError(f"bundle contains records for another package_id: {', '.join(mismatches)}")

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "package": self.package.to_dict(),
            "events": [item.to_dict() for item in self.events],
            "work_items": [item.to_dict() for item in self.work_items],
            "derivatives": [item.to_dict() for item in self.derivatives],
        }

    @classmethod
    def from_dict(cls, payload: Mapping[str, object]) -> "ContentPackageBundle":
        _reject_unknown_fields(payload, BUNDLE_FIELDS, "content package bundle")
        if payload.get("schema_version") != CONTENT_PACKAGE_SCHEMA_VERSION:
            raise ValueError(f"schema_version must be {CONTENT_PACKAGE_SCHEMA_VERSION}")
        return cls(
            package=ContentPackageDraft.from_dict(_as_mapping(payload.get("package"), "package")),
            events=tuple(
                PackageEvent.from_dict(_as_mapping(item, "event"))
                for item in _as_tuple_of_mappings(payload.get("events"), "events")
            ),
            work_items=tuple(
                PackageWorkItem.from_dict(_as_mapping(item, "work_item"))
                for item in _as_tuple_of_mappings(payload.get("work_items"), "work_items")
            ),
            derivatives=tuple(
                PackageDerivative.from_dict(_as_mapping(item, "derivative"))
                for item in _as_tuple_of_mappings(payload.get("derivatives"), "derivatives")
            ),
        )

    def digest(self) -> str:
        """Return a stable fingerprint for the full package exchange bundle."""
        return _stable_digest(self.to_dict())


def package_event_digest(event: PackageEvent) -> str:
    """Return a stable fingerprint for idempotent event publication."""
    return _stable_digest(event.to_dict())


def content_package_from_echo_story(payload: Mapping[str, object]) -> ContentPackageDraft:
    """Map an Echo story cluster into a draft package without reading Echo storage."""
    story_id = str(payload.get("story_id") or payload.get("cluster_id") or payload.get("id") or "")
    title = str(payload.get("title") or payload.get("headline") or "")
    if not story_id:
        raise ValueError("Echo story requires story_id, cluster_id or id")
    source_refs = [f"echo:story:{story_id}"]
    source_url = payload.get("url")
    if isinstance(source_url, str) and source_url.strip():
        source_refs.append(source_url.strip())
    return ContentPackageDraft(
        package_id=f"pkg:echo:{story_id}",
        title=title,
        topic_ref=f"echo:story:{story_id}",
        status="active",
        summary=str(payload.get("summary") or ""),
        source_refs=tuple(source_refs),
        entity_refs=_as_tuple(payload.get("entity_refs") or payload.get("entities"), "entity_refs"),
        evidence_refs=_as_tuple(payload.get("evidence_refs"), "evidence_refs"),
    )


def package_work_item_from_editorial_project(payload: Mapping[str, object]) -> PackageWorkItem:
    """Map an Editorial content project into a package-linked work item."""
    project_id = str(payload.get("project_id") or payload.get("content_project_id") or payload.get("id") or "")
    package_id = str(payload.get("package_id") or payload.get("packageId") or "")
    if not project_id:
        raise ValueError("Editorial project requires project_id, content_project_id or id")
    if not package_id:
        raise ValueError("Editorial project requires package_id")
    return PackageWorkItem(
        work_item_id=f"work:editorial:{project_id}",
        package_id=package_id,
        kind="editorial-case",
        state=str(payload.get("state") or "draft"),
        title=str(payload.get("title") or "Editorial work item"),
        owner_service="editorial",
        source_ref=f"editorial:content-project:{project_id}",
    )


def package_derivative_from_digest_product(payload: Mapping[str, object]) -> PackageDerivative:
    """Map a Digest/ELECT output into a package-linked derivative reference."""
    product_id = str(payload.get("product_id") or payload.get("id") or "")
    package_id = str(payload.get("package_id") or payload.get("packageId") or "")
    if not product_id:
        raise ValueError("Digest product requires product_id or id")
    if not package_id:
        raise ValueError("Digest product requires package_id")
    return PackageDerivative(
        derivative_id=f"derivative:digest:{product_id}",
        package_id=package_id,
        kind=str(payload.get("kind") or "digest"),
        title=str(payload.get("title") or "Digest derivative"),
        publication_ref=str(payload.get("publication_ref") or payload.get("url") or f"digest:product:{product_id}"),
        source_ref=f"digest:product:{product_id}",
    )
