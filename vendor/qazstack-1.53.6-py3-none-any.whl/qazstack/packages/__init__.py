"""Portable contracts for long-lived information production packages.

The package owns interchange structure only. Products keep their local storage,
queues, article bodies, source captures, permissions and publication runtimes.
"""

from qazstack.packages.contracts import (
    CONTENT_PACKAGE_EVENT_SCHEMA_VERSION,
    CONTENT_PACKAGE_SCHEMA_VERSION,
    DERIVATIVE_SCHEMA_VERSION,
    PACKAGE_GRAPH_CANDIDATE_SCHEMA_VERSION,
    PACKAGE_GRAPH_OBJECT_TYPES,
    PACKAGE_GRAPH_REVIEW_STATES,
    PACKAGE_STATUSES,
    PACKAGE_WORK_ITEM_SCHEMA_VERSION,
    ContentPackageBundle,
    ContentPackageDraft,
    PackageDerivative,
    PackageEvent,
    PackageGraphCandidate,
    PackageWorkItem,
    content_package_from_echo_story,
    package_derivative_from_digest_product,
    package_event_digest,
    package_work_item_from_editorial_project,
)

__all__ = [
    "CONTENT_PACKAGE_SCHEMA_VERSION",
    "CONTENT_PACKAGE_EVENT_SCHEMA_VERSION",
    "PACKAGE_WORK_ITEM_SCHEMA_VERSION",
    "DERIVATIVE_SCHEMA_VERSION",
    "PACKAGE_GRAPH_CANDIDATE_SCHEMA_VERSION",
    "PACKAGE_GRAPH_OBJECT_TYPES",
    "PACKAGE_GRAPH_REVIEW_STATES",
    "PACKAGE_STATUSES",
    "ContentPackageBundle",
    "ContentPackageDraft",
    "PackageEvent",
    "PackageGraphCandidate",
    "PackageWorkItem",
    "PackageDerivative",
    "content_package_from_echo_story",
    "package_work_item_from_editorial_project",
    "package_derivative_from_digest_product",
    "package_event_digest",
]
