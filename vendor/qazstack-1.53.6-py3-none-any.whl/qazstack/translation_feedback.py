"""Privacy-safe translation feedback events for the shared learning loop.

QMT remains the source of truth for raw segments, accepted corrections and
translation memory. QazStack receives only bounded metadata and hashes so that
quality signals can be aggregated across consumers without turning the shared
layer into an unreviewed text corpus.
"""

from __future__ import annotations

import re
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass, field
from datetime import datetime
from typing import Any, ClassVar, Iterable

from qazstack.locale_contract import CANONICAL_LOCALES, normalize_locale
from qazstack.translation_quality import (
    IssueSeverity,
    MQMSeverity,
    ProviderReadinessStatus,
    QalamIssueType,
    QualityVerdictCode,
)

CONTRACT_ID = "qazstack.translation_feedback.v1"
CONTRACT_VERSION = "1.1.0"
SCHEMA_VERSION = "qazstack-translation-feedback-v1"
AGGREGATE_SCHEMA_VERSION = "qazstack-translation-feedback-aggregate-v1"
GATE_SCHEMA_VERSION = "qazstack-translation-feedback-gate-v1"

FEEDBACK_KINDS = (
    "review_verdict",
    "correction",
    "issue",
    "provider_observation",
    "usage_signal",
)
REVIEW_STATUSES = ("unreviewed", "reviewed", "approved", "rejected")
MEMORY_ELIGIBILITY = ("not_eligible", "candidate", "approved")
SEVERITIES = tuple(dict.fromkeys(item.value for item in (*IssueSeverity, *MQMSeverity)))
VERDICTS = tuple(item.value for item in QualityVerdictCode)
ISSUE_CODES = (
    tuple(item.value for item in QalamIssueType)
    + tuple(f"mqm.{item.value}" for item in MQMSeverity)
    + ("mqm.accuracy", "mqm.fluency", "mqm.locale_convention", "provider_unavailable")
)
PROVIDER_STATUSES = tuple(item.value for item in ProviderReadinessStatus)

_HASH_PATTERN = re.compile(r"^sha256:[0-9a-f]{64}$")
_ID_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9:._/-]{0,255}$")
_VERSION_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._+/-]{0,127}$")
_RAW_TEXT_KEYS = frozenset(
    {
        "text",
        "source_text",
        "target_text",
        "translation",
        "prompt",
        "completion",
        "raw_text",
        "raw_segment",
    }
)


def _require_string(value: Any, field_name: str, *, pattern: re.Pattern[str] | None = None) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field_name} must be a non-empty string")
    normalized = value.strip()
    if pattern is not None and not pattern.fullmatch(normalized):
        raise ValueError(f"{field_name} has an invalid format")
    return normalized


def _require_timestamp(value: Any, field_name: str) -> str:
    normalized = _require_string(value, field_name)
    try:
        parsed = datetime.fromisoformat(normalized.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError(f"{field_name} must be an ISO-8601 timestamp") from exc
    if parsed.tzinfo is None:
        raise ValueError(f"{field_name} must include a timezone")
    return normalized


@dataclass(frozen=True, slots=True)
class TranslationFeedbackEvent:
    """A hash-only, review-aware signal that can cross project boundaries."""

    event_id: str
    project_id: str
    source_locale: str
    target_locale: str
    source_text_hash: str
    translated_text_hash: str
    feedback_kind: str
    recorded_at: str
    review_status: str = "unreviewed"
    memory_eligibility: str = "not_eligible"
    verdict: str | None = None
    issue_codes: tuple[str, ...] = field(default_factory=tuple)
    severity: str | None = None
    quality_score: float | None = None
    reviewer_ref: str | None = None
    reviewed_at: str | None = None
    provider: str | None = None
    provider_status: str | None = None
    model_version: str | None = None
    glossary_version: str | None = None
    translation_memory_version: str | None = None
    quality_rule_version: str | None = None
    consumer_surface: str | None = None
    correction_hash: str | None = None
    evidence_refs: tuple[str, ...] = field(default_factory=tuple)

    _ALLOWED_INPUT_KEYS: ClassVar[frozenset[str]] = frozenset(
        {
            "schema_version",
            "contract_id",
            "contract_version",
            "event_id",
            "project_id",
            "source_locale",
            "target_locale",
            "source_text_hash",
            "translated_text_hash",
            "feedback_kind",
            "recorded_at",
            "review_status",
            "memory_eligibility",
            "verdict",
            "issue_codes",
            "severity",
            "quality_score",
            "reviewer_ref",
            "reviewed_at",
            "provider",
            "provider_status",
            "model_version",
            "glossary_version",
            "translation_memory_version",
            "quality_rule_version",
            "consumer_surface",
            "correction_hash",
            "evidence_refs",
        }
    )

    def __post_init__(self) -> None:
        object.__setattr__(self, "event_id", _require_string(self.event_id, "event_id", pattern=_ID_PATTERN))
        object.__setattr__(self, "project_id", _require_string(self.project_id, "project_id", pattern=_ID_PATTERN))

        source_locale = normalize_locale(self.source_locale)
        target_locale = normalize_locale(self.target_locale)
        if source_locale not in CANONICAL_LOCALES or target_locale not in CANONICAL_LOCALES:
            raise ValueError(
                "source_locale and target_locale must be canonical values: " + ", ".join(CANONICAL_LOCALES)
            )
        if source_locale == target_locale:
            raise ValueError("source_locale and target_locale must differ")
        object.__setattr__(self, "source_locale", source_locale)
        object.__setattr__(self, "target_locale", target_locale)

        for field_name in ("source_text_hash", "translated_text_hash"):
            object.__setattr__(
                self,
                field_name,
                _require_string(getattr(self, field_name), field_name, pattern=_HASH_PATTERN),
            )

        if self.feedback_kind not in FEEDBACK_KINDS:
            raise ValueError(f"feedback_kind must be one of {FEEDBACK_KINDS}")
        if self.review_status not in REVIEW_STATUSES:
            raise ValueError(f"review_status must be one of {REVIEW_STATUSES}")
        if self.memory_eligibility not in MEMORY_ELIGIBILITY:
            raise ValueError(f"memory_eligibility must be one of {MEMORY_ELIGIBILITY}")
        object.__setattr__(self, "recorded_at", _require_timestamp(self.recorded_at, "recorded_at"))

        if self.verdict is not None and self.verdict not in VERDICTS:
            raise ValueError(f"verdict must be one of {VERDICTS}")
        if self.severity is not None and self.severity not in SEVERITIES:
            raise ValueError(f"severity must be one of {SEVERITIES}")
        if self.provider_status is not None and self.provider_status not in PROVIDER_STATUSES:
            raise ValueError(f"provider_status must be one of {PROVIDER_STATUSES}")
        if self.quality_score is not None and not 0 <= self.quality_score <= 1:
            raise ValueError("quality_score must be between 0 and 1")

        issue_codes = tuple(self.issue_codes)
        if len(issue_codes) > 20 or len(set(issue_codes)) != len(issue_codes):
            raise ValueError("issue_codes must contain at most 20 distinct values")
        if any(not re.fullmatch(r"^[a-z][a-z0-9_.-]{1,63}$", code) for code in issue_codes):
            raise ValueError("issue_codes must use bounded lowercase codes")
        object.__setattr__(self, "issue_codes", issue_codes)

        evidence_refs = tuple(self.evidence_refs)
        if (
            len(evidence_refs) > 20
            or len(set(evidence_refs)) != len(evidence_refs)
            or any(not _HASH_PATTERN.fullmatch(ref) for ref in evidence_refs)
        ):
            raise ValueError("evidence_refs must contain at most 20 distinct sha256 digests")
        object.__setattr__(self, "evidence_refs", evidence_refs)

        for field_name in (
            "provider",
            "model_version",
            "glossary_version",
            "translation_memory_version",
            "quality_rule_version",
            "consumer_surface",
        ):
            value = getattr(self, field_name)
            if value is not None:
                object.__setattr__(self, field_name, _require_string(value, field_name, pattern=_VERSION_PATTERN))
        for field_name in ("reviewer_ref",):
            value = getattr(self, field_name)
            if value is not None:
                object.__setattr__(self, field_name, _require_string(value, field_name, pattern=_HASH_PATTERN))
        for field_name in ("correction_hash",):
            value = getattr(self, field_name)
            if value is not None:
                object.__setattr__(self, field_name, _require_string(value, field_name, pattern=_HASH_PATTERN))

        if self.review_status in {"reviewed", "approved"}:
            if not self.reviewer_ref or not self.reviewed_at:
                raise ValueError("reviewed and approved events require reviewer_ref and reviewed_at")
            object.__setattr__(self, "reviewed_at", _require_timestamp(self.reviewed_at, "reviewed_at"))
        elif self.reviewed_at is not None:
            object.__setattr__(self, "reviewed_at", _require_timestamp(self.reviewed_at, "reviewed_at"))

        if self.memory_eligibility == "candidate" and self.review_status not in {"reviewed", "approved"}:
            raise ValueError("memory candidate requires a reviewed event")
        if self.memory_eligibility == "approved":
            if self.review_status != "approved":
                raise ValueError("approved memory requires review_status=approved")
            if self.feedback_kind == "correction" and not self.correction_hash:
                raise ValueError("approved correction requires correction_hash")
            if self.feedback_kind != "correction" and self.verdict != QualityVerdictCode.PUBLISH_READY:
                raise ValueError("approved non-correction memory requires publish_ready verdict")

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> TranslationFeedbackEvent:
        """Parse a boundary payload and reject raw-text or unknown fields."""

        if not isinstance(payload, dict):
            raise ValueError("translation feedback payload must be an object")
        unknown = set(payload) - cls._ALLOWED_INPUT_KEYS
        if unknown:
            if unknown & _RAW_TEXT_KEYS:
                raise ValueError("raw translation text is not allowed in shared feedback events")
            raise ValueError(f"unknown translation feedback fields: {sorted(unknown)}")
        if payload.get("schema_version") not in {None, SCHEMA_VERSION}:
            raise ValueError(f"schema_version must be {SCHEMA_VERSION}")
        if payload.get("contract_id") not in {None, CONTRACT_ID}:
            raise ValueError(f"contract_id must be {CONTRACT_ID}")
        if payload.get("contract_version") not in {None, CONTRACT_VERSION}:
            raise ValueError(f"contract_version must be {CONTRACT_VERSION}")

        values = dict(payload)
        values.pop("schema_version", None)
        values.pop("contract_id", None)
        values.pop("contract_version", None)
        for field_name in ("issue_codes", "evidence_refs"):
            if field_name in values:
                if not isinstance(values[field_name], list | tuple):
                    raise ValueError(f"{field_name} must be an array")
                values[field_name] = tuple(values[field_name])
        return cls(**values)

    def as_dict(self) -> dict[str, Any]:
        """Return the stable JSON shape; never include raw text."""

        payload = asdict(self)
        payload["schema_version"] = SCHEMA_VERSION
        payload["contract_id"] = CONTRACT_ID
        payload["contract_version"] = CONTRACT_VERSION
        for field_name in ("issue_codes", "evidence_refs"):
            payload[field_name] = list(payload[field_name])
        return payload


def _ratio(numerator: int, denominator: int) -> float | None:
    """Return a bounded, deterministic ratio or ``None`` without observations."""

    if denominator == 0:
        return None
    return round(numerator / denominator, 6)


def aggregate_translation_feedback(
    events: Iterable[TranslationFeedbackEvent],
) -> dict[str, Any]:
    """Build a deterministic, text-free quality projection for QazLake.

    The aggregate intentionally accepts already validated events only.  It
    contains counts, rates and version/provider dimensions, but never hashes
    beyond the event-level input and never copies source/target text.
    """

    materialized = tuple(events)
    if any(not isinstance(event, TranslationFeedbackEvent) for event in materialized):
        raise TypeError("events must contain TranslationFeedbackEvent instances")

    review_status_counts = Counter(event.review_status for event in materialized)
    memory_counts = Counter(event.memory_eligibility for event in materialized)
    feedback_kind_counts = Counter(event.feedback_kind for event in materialized)
    verdict_counts = Counter(event.verdict for event in materialized if event.verdict)
    provider_status_counts = Counter(event.provider_status or "unset" for event in materialized)
    issue_counts = Counter(issue_code for event in materialized for issue_code in event.issue_codes)

    grouped: dict[str, list[TranslationFeedbackEvent]] = defaultdict(list)
    for event in materialized:
        pair = f"{event.source_locale}->{event.target_locale}"
        provider = event.provider or "unset"
        grouped[f"pair:{pair}"].append(event)
        grouped[f"project:{event.project_id}"].append(event)
        grouped[f"provider:{provider}"].append(event)

    def slice_payload(slice_events: list[TranslationFeedbackEvent]) -> dict[str, Any]:
        event_count = len(slice_events)
        scored = [event.quality_score for event in slice_events if event.quality_score is not None]
        issue_event_count = sum(bool(event.issue_codes) for event in slice_events)
        publish_ready_count = sum(event.verdict == QualityVerdictCode.PUBLISH_READY for event in slice_events)
        return {
            "event_count": event_count,
            "reviewed_event_count": sum(event.review_status in {"reviewed", "approved"} for event in slice_events),
            "approved_memory_event_count": sum(event.memory_eligibility == "approved" for event in slice_events),
            "publish_ready_count": publish_ready_count,
            "publish_ready_rate": _ratio(publish_ready_count, event_count),
            "issue_event_count": issue_event_count,
            "issue_rate": _ratio(issue_event_count, event_count),
            "issue_count": sum(len(event.issue_codes) for event in slice_events),
            "scored_event_count": len(scored),
            "mean_quality_score": (round(sum(scored) / len(scored), 6) if scored else None),
        }

    slices: dict[str, dict[str, dict[str, Any]]] = {
        "language_pair": {},
        "project": {},
        "provider": {},
    }
    for group_key, slice_events in sorted(grouped.items()):
        dimension, value = group_key.split(":", 1)
        slices[{"pair": "language_pair", "project": "project", "provider": "provider"}[dimension]][value] = (
            slice_payload(slice_events)
        )

    return {
        "schema_version": AGGREGATE_SCHEMA_VERSION,
        "contract_id": CONTRACT_ID,
        "contract_version": CONTRACT_VERSION,
        "event_count": len(materialized),
        "quality_summary": slice_payload(list(materialized)),
        "review_status_counts": dict(sorted(review_status_counts.items())),
        "memory_eligibility_counts": dict(sorted(memory_counts.items())),
        "feedback_kind_counts": dict(sorted(feedback_kind_counts.items())),
        "verdict_counts": dict(sorted(verdict_counts.items())),
        "provider_status_counts": dict(sorted(provider_status_counts.items())),
        "issue_code_counts": dict(sorted(issue_counts.items())),
        "slices": slices,
    }


def evaluate_translation_feedback_gate(
    aggregate: dict[str, Any],
    *,
    min_events: int,
    min_publish_ready_rate: float,
    max_issue_rate: float,
    min_mean_quality_score: float,
) -> dict[str, Any]:
    """Evaluate explicit owner-supplied thresholds without promoting memory.

    The function is deliberately a holdout/release signal, not a publication
    or training command. Thresholds belong to the consumer/domain owner and
    are returned alongside each observed value for auditability.
    """

    if not isinstance(aggregate, dict):
        raise TypeError("aggregate must be an object")
    if aggregate.get("schema_version") != AGGREGATE_SCHEMA_VERSION:
        raise ValueError(f"aggregate schema_version must be {AGGREGATE_SCHEMA_VERSION}")
    if not isinstance(min_events, int) or isinstance(min_events, bool) or min_events < 1:
        raise ValueError("min_events must be a positive integer")
    for field_name, value in (
        ("min_publish_ready_rate", min_publish_ready_rate),
        ("max_issue_rate", max_issue_rate),
        ("min_mean_quality_score", min_mean_quality_score),
    ):
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not 0 <= value <= 1:
            raise ValueError(f"{field_name} must be between 0 and 1")

    summary = aggregate.get("quality_summary")
    if not isinstance(summary, dict):
        raise ValueError("aggregate quality_summary is required")

    checks = [
        {
            "id": "minimum_events",
            "status": "pass" if aggregate.get("event_count", 0) >= min_events else "fail",
            "observed": aggregate.get("event_count"),
            "expected": min_events,
        },
        {
            "id": "publish_ready_rate",
            "status": "pass"
            if isinstance(summary.get("publish_ready_rate"), (int, float))
            and summary["publish_ready_rate"] >= min_publish_ready_rate
            else "fail",
            "observed": summary.get("publish_ready_rate"),
            "expected": min_publish_ready_rate,
        },
        {
            "id": "issue_rate",
            "status": "pass"
            if isinstance(summary.get("issue_rate"), (int, float)) and summary["issue_rate"] <= max_issue_rate
            else "fail",
            "observed": summary.get("issue_rate"),
            "expected": max_issue_rate,
        },
        {
            "id": "mean_quality_score",
            "status": "pass"
            if isinstance(summary.get("mean_quality_score"), (int, float))
            and summary["mean_quality_score"] >= min_mean_quality_score
            else "fail",
            "observed": summary.get("mean_quality_score"),
            "expected": min_mean_quality_score,
        },
    ]
    passed = all(check["status"] == "pass" for check in checks)
    return {
        "schema_version": GATE_SCHEMA_VERSION,
        "aggregate_schema_version": AGGREGATE_SCHEMA_VERSION,
        "decision": "pass" if passed else "hold",
        "eligible_for_owner_approval": passed,
        "automatic_memory_promotion": False,
        "checks": checks,
    }


__all__ = [
    "CONTRACT_ID",
    "CONTRACT_VERSION",
    "AGGREGATE_SCHEMA_VERSION",
    "GATE_SCHEMA_VERSION",
    "aggregate_translation_feedback",
    "evaluate_translation_feedback_gate",
    "FEEDBACK_KINDS",
    "MEMORY_ELIGIBILITY",
    "REVIEW_STATUSES",
    "SCHEMA_VERSION",
    "TranslationFeedbackEvent",
]
