"""Unified translation module for ru↔kk↔en.

Consolidates translation logic from QazPoster and total-kz.
Supports OpenAI and DeepSeek backends.

Basic usage::

    from qazstack.translate import translate, translate_sync

    # Async
    result = await translate("Добрый день", source_lang="ru", target_lang="kk")

    # Sync
    result = translate_sync("Добрый день", source_lang="ru", target_lang="kk")

Backend selection (in priority order):
  1. Explicit ``api_key`` + ``api_base`` arguments
  2. ``DEEPSEEK_API_KEY`` env var  → DeepSeek API (cheaper)
  3. ``OPENAI_API_KEY`` env var    → OpenAI API
"""

import logging
import os
from typing import Literal

import httpx

from qazstack.i18n.locales import normalize_locale, to_legacy_provider_locale

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# System prompts – merged best-of from QazPoster and total-kz
# ---------------------------------------------------------------------------

SYSTEM_PROMPT_RU_KZ = (
    "Ты – профессиональный переводчик с русского на казахский язык "
    "для казахстанского контента.\n\n"
    "Требования к переводу:\n"
    "1. Используй литературный казахский язык (әдеби қазақ тілі), не разговорный\n"
    "2. Имена собственные людей НЕ переводи – оставь как есть "
    "(Касым-Жомарт Токаев, Аида Балаева)\n"
    "3. Казахстанские названия используй на казахском "
    "(ВКО→ШҚО, ЗКО→БҚО, СКО→СҚО, Восточный Казахстан→Шығыс Қазақстан, "
    "Западный Казахстан→Батыс Қазақстан, Северный Казахстан→Солтүстік Қазақстан, "
    "Министерство внутренних дел→Ішкі істер министрлігі)\n"
    "4. Сохраняй стиль и тональность оригинала\n"
    "5. Не добавляй комментариев – только перевод"
)

SYSTEM_PROMPT_KZ_RU = (
    "Ты – профессиональный переводчик с казахского на русский язык.\n"
    "Переводи точно, сохраняя стиль. Имена собственные оставляй как есть."
)

SYSTEM_PROMPT_EN = (
    "You are a professional translator. Translate accurately, preserving style and tone. Keep proper nouns as-is."
)


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class TranslationError(Exception):
    """Raised when translation fails due to API or configuration issues."""


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


async def translate(
    text: str,
    source_lang: Literal["kk", "kz", "ru", "en"] | str,
    target_lang: Literal["kk", "kz", "ru", "en"] | str,
    *,
    model: str = "",
    api_key: str = "",
    api_base: str = "",
    timeout: float = 30.0,
) -> str:
    """Translate *text* from *source_lang* to *target_lang* using an LLM.

    Auto-detects backend:
    - If ``DEEPSEEK_API_KEY`` is set, uses DeepSeek (cheaper, default model
      ``deepseek-chat``).
    - Falls back to ``OPENAI_API_KEY`` with ``gpt-4o-mini``.
    - Override either by passing explicit *api_key* + *api_base*.

    Parameters
    ----------
    text:
        Text to translate.
    source_lang:
        Locale of the source language. Canonical Kazakh is ``"kk"``;
        legacy ``"kz"`` aliases remain accepted.
    target_lang:
        Locale of the target language. Canonical Kazakh is ``"kk"``;
        legacy ``"kz"`` aliases remain accepted.
    model:
        Override the LLM model name.
    api_key:
        Override the API key (must also set *api_base* when used).
    api_base:
        Override the API base URL (e.g. ``"https://api.deepseek.com/v1"``).
    timeout:
        HTTP request timeout in seconds.

    Returns
    -------
    str
        Translated text.

    Raises
    ------
    TranslationError
        On any API error or missing credentials.
    """
    # Keep the public QazStack locale contract canonical while preserving the
    # old ``kz`` key expected by this provider/prompt implementation.
    raw_source = str(source_lang or "")
    raw_target = str(target_lang or "")
    source_canonical = normalize_locale(raw_source)
    target_canonical = normalize_locale(raw_target)
    has_chinese_request = (
        source_canonical == "zh-Hans"
        or target_canonical == "zh-Hans"
        or raw_source.casefold().startswith("zh")
        or raw_target.casefold().startswith("zh")
    )
    if has_chinese_request:
        raise TranslationError(
            "Generic QazStack runtime translation does not support Chinese; use the QMT catalog workflow."
        )
    source_lang = to_legacy_provider_locale(source_lang)
    target_lang = to_legacy_provider_locale(target_lang)

    if source_lang == target_lang:
        return text

    # Select system prompt based on direction
    if target_lang == "kz":
        system = SYSTEM_PROMPT_RU_KZ
    elif target_lang == "ru" and source_lang == "kz":
        system = SYSTEM_PROMPT_KZ_RU
    else:
        system = SYSTEM_PROMPT_EN

    user_msg = f"Переведи с {_lang_name(source_lang)} на {_lang_name(target_lang)}:\n\n{text}"

    # Resolve API credentials
    resolved_key = api_key
    resolved_base = api_base
    resolved_model = model

    if not resolved_key:
        resolved_key = os.getenv("DEEPSEEK_API_KEY", "") or os.getenv("OPENAI_API_KEY", "")

    if not resolved_base:
        if os.getenv("DEEPSEEK_API_KEY"):
            resolved_base = "https://api.deepseek.com/v1"
            resolved_model = resolved_model or "deepseek-chat"
        else:
            resolved_base = "https://api.openai.com/v1"
            resolved_model = resolved_model or "gpt-4o-mini"

    if not resolved_key:
        raise TranslationError("No API key configured – set OPENAI_API_KEY or DEEPSEEK_API_KEY")

    async with httpx.AsyncClient(timeout=timeout) as client:
        try:
            resp = await client.post(
                f"{resolved_base}/chat/completions",
                headers={"Authorization": f"Bearer {resolved_key}"},
                json={
                    "model": resolved_model,
                    "messages": [
                        {"role": "system", "content": system},
                        {"role": "user", "content": user_msg},
                    ],
                    "temperature": 0.3,
                },
            )
            resp.raise_for_status()
            data = resp.json()
            return data["choices"][0]["message"]["content"].strip()
        except TranslationError:
            raise
        except Exception as exc:
            raise TranslationError(f"Translation API error: {exc}") from exc


def translate_sync(
    text: str,
    source_lang: Literal["kk", "kz", "ru", "en"] | str,
    target_lang: Literal["kk", "kz", "ru", "en"] | str,
    **kwargs,
) -> str:
    """Synchronous wrapper around :func:`translate`.

    Works both inside and outside a running asyncio event loop:

    - Outside a loop: calls ``asyncio.run()``.
    - Inside a running loop (e.g. Jupyter, FastAPI startup): spawns a
      ``ThreadPoolExecutor`` to avoid blocking the loop.

    All keyword arguments are forwarded to :func:`translate`.
    """
    import asyncio

    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop and loop.is_running():
        import concurrent.futures

        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            future = pool.submit(
                asyncio.run,
                translate(text, source_lang, target_lang, **kwargs),
            )
            return future.result()

    return asyncio.run(translate(text, source_lang, target_lang, **kwargs))


# ---------------------------------------------------------------------------
# Internals
# ---------------------------------------------------------------------------


def _lang_name(code: str) -> str:
    """Return a Russian genitive language name for use in prompts."""
    return {
        "ru": "русского",
        "kz": "казахского",
        "en": "английского",
    }.get(to_legacy_provider_locale(code), code)
