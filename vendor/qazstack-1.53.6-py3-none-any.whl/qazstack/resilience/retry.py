"""Retry with exponential backoff and jitter.

Consolidated from: qazposter/adapters/resilience.py, pssr-regime-engine/aggregator.py

Usage::

    from qazstack.resilience import retry_with_backoff

    result = await retry_with_backoff(fetch_data, url, max_retries=3)

    # With circuit breaker:
    from qazstack.resilience import retry_with_backoff, get_breaker

    breaker = get_breaker("api")
    result = await retry_with_backoff(
        fetch_data, url,
        max_retries=3,
        circuit_breaker=breaker,
    )
"""

from __future__ import annotations

import asyncio
import logging
import random
from typing import Any, Callable

import httpx

from qazstack.resilience.breaker import CircuitBreaker, CircuitOpenError

logger = logging.getLogger("qazstack.resilience")

RETRYABLE_HTTP_STATUSES = frozenset({408, 425, 429, 500, 502, 503, 504})

# Default retryable exceptions
DEFAULT_RETRYABLE = (
    httpx.TransportError,
    httpx.TimeoutException,
    httpx.HTTPStatusError,
    ConnectionError,
    TimeoutError,
    OSError,
)


def _is_retryable_exception(exc: Exception) -> bool:
    if isinstance(exc, httpx.HTTPStatusError):
        return exc.response.status_code in RETRYABLE_HTTP_STATUSES
    return True


async def retry_with_backoff(
    func: Callable,
    *args: Any,
    max_retries: int = 3,
    base_delay: float = 1.0,
    max_delay: float = 30.0,
    retryable_exceptions: tuple = DEFAULT_RETRYABLE,
    circuit_breaker: CircuitBreaker | None = None,
    on_retry: Callable | None = None,
    max_elapsed_seconds: float | None = None,
    **kwargs: Any,
) -> Any:
    """Execute async func with exponential backoff retry.

    Args:
        func: Async callable to execute.
        max_retries: Maximum number of retry attempts.
        base_delay: Initial delay in seconds.
        max_delay: Maximum delay cap in seconds.
        retryable_exceptions: Tuple of exception types to retry on.
        circuit_breaker: Optional CircuitBreaker instance.
        on_retry: Optional callback(attempt, exception) called before each retry.
        max_elapsed_seconds: Optional wall-clock retry budget for all attempts.

    Returns:
        Result of func.

    Raises:
        CircuitOpenError: If circuit breaker is open.
        Last exception if all retries exhausted.
    """
    last_exc: Exception | None = None
    started_at = asyncio.get_running_loop().time()
    if max_elapsed_seconds is not None and max_elapsed_seconds < 0:
        raise ValueError("max_elapsed_seconds must not be negative")

    for attempt in range(max_retries + 1):
        # Check circuit breaker
        if circuit_breaker and not circuit_breaker.allow_request:
            raise CircuitOpenError(circuit_breaker.name, circuit_breaker.time_until_recovery)

        try:
            result = await func(*args, **kwargs)
            if circuit_breaker:
                circuit_breaker.record_success()
            return result

        except retryable_exceptions as exc:
            last_exc = exc
            if not _is_retryable_exception(exc):
                raise
            if circuit_breaker:
                circuit_breaker.record_failure()

            if attempt == max_retries:
                break

            # Exponential backoff with full jitter.
            delay_cap = min(base_delay * (2**attempt), max_delay)
            delay = random.uniform(0.0, delay_cap)
            if max_elapsed_seconds is not None:
                remaining = max_elapsed_seconds - (asyncio.get_running_loop().time() - started_at)
                if remaining <= 0:
                    break
                delay = min(delay, remaining)

            if on_retry:
                try:
                    on_retry(attempt + 1, exc)
                except Exception:
                    pass

            logger.warning(
                "Retry %d/%d after %.1fs: %s",
                attempt + 1,
                max_retries,
                delay,
                exc,
            )
            await asyncio.sleep(delay)

    raise last_exc  # type: ignore[misc]
