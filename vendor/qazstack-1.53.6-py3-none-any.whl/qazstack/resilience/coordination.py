"""Duplicate-work suppression and bounded adaptive concurrency primitives."""

from __future__ import annotations

import asyncio
import threading
from collections.abc import Awaitable, Callable
from typing import Any


class ConcurrencyLimitError(RuntimeError):
    """Raised when optional work is shed at a saturated upstream boundary."""

    def __init__(self, name: str, limit: int) -> None:
        self.name = name
        self.limit = limit
        super().__init__(f"upstream concurrency limit reached for {name!r}: {limit}")


class AdaptiveConcurrencyLimiter:
    """Fail-fast bounded controller that adapts to observed request latency.

    The limiter deliberately does not queue callers. Optional enrichment and
    refresh work can be dropped at saturation, preserving capacity for the
    primary request path. A slow/error sample contracts the limit; a sustained
    fast sample grows it one slot at a time up to ``maximum``.
    """

    def __init__(
        self,
        *,
        name: str = "upstream",
        initial: int = 4,
        minimum: int = 1,
        maximum: int = 32,
        target_seconds: float = 1.0,
    ) -> None:
        if not name.strip():
            raise ValueError("name must be non-empty")
        if minimum < 1 or maximum < minimum or initial < 1:
            raise ValueError("concurrency bounds are invalid")
        if target_seconds <= 0:
            raise ValueError("target_seconds must be positive")
        self.name = name
        self.minimum = minimum
        self.maximum = maximum
        self.target_seconds = target_seconds
        self.limit = min(maximum, max(minimum, initial))
        self.inflight = 0
        self.ewma_seconds: float | None = None
        self._lock = threading.Lock()

    def try_acquire(self) -> bool:
        """Reserve one slot, returning ``False`` instead of waiting."""
        with self._lock:
            if self.inflight >= self.limit:
                return False
            self.inflight += 1
            return True

    def release(self, *, elapsed_seconds: float, success: bool) -> None:
        """Record one completed request and update the bounded limit."""
        if elapsed_seconds < 0:
            raise ValueError("elapsed_seconds must not be negative")
        with self._lock:
            self.inflight = max(0, self.inflight - 1)
            if self.ewma_seconds is None:
                self.ewma_seconds = elapsed_seconds
            else:
                self.ewma_seconds = (self.ewma_seconds * 0.8) + (elapsed_seconds * 0.2)
            if not success or self.ewma_seconds > self.target_seconds:
                self.limit = max(self.minimum, int(self.limit * 0.7))
            elif self.ewma_seconds < self.target_seconds * 0.8:
                self.limit = min(self.maximum, self.limit + 1)

    @property
    def stats(self) -> dict[str, Any]:
        with self._lock:
            return {
                "name": self.name,
                "limit": self.limit,
                "inflight": self.inflight,
                "minimum": self.minimum,
                "maximum": self.maximum,
                "ewma_seconds": self.ewma_seconds,
            }


class AsyncSingleFlight:
    """Share one in-flight async result for each explicit read key."""

    def __init__(self) -> None:
        self._lock = asyncio.Lock()
        self._flights: dict[str, asyncio.Future[Any]] = {}

    async def run(self, key: str, operation: Callable[[], Awaitable[Any]]) -> Any:
        if not key.strip():
            raise ValueError("key must be non-empty")
        async with self._lock:
            future = self._flights.get(key)
            leader = future is None
            if leader:
                future = asyncio.get_running_loop().create_future()
                self._flights[key] = future
        if not leader:
            return await asyncio.shield(future)

        try:
            result = await operation()
            future.set_result(result)
            return result
        except BaseException as exc:
            future.set_exception(exc)
            future.exception()
            raise
        finally:
            async with self._lock:
                if self._flights.get(key) is future:
                    self._flights.pop(key, None)


__all__ = ["AdaptiveConcurrencyLimiter", "AsyncSingleFlight", "ConcurrencyLimitError"]
