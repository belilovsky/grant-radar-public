"""Resilient JSON HTTP helpers built on the shared retry and breaker APIs."""

from __future__ import annotations

import time
from collections.abc import Callable
from typing import Any

import httpx

from qazstack.resilience.breaker import CircuitBreaker, CircuitOpenError, get_breaker
from qazstack.resilience.contracts import IdempotencyKey
from qazstack.resilience.coordination import AdaptiveConcurrencyLimiter, AsyncSingleFlight, ConcurrencyLimitError
from qazstack.resilience.retry import retry_with_backoff


async def with_breaker(
    breaker: CircuitBreaker | str,
    func: Callable,
    *args: Any,
    on_open: Callable[[CircuitBreaker], None] | None = None,
    **kwargs: Any,
) -> Any:
    """Execute a callable and update a named or explicit breaker."""
    active = get_breaker(breaker) if isinstance(breaker, str) else breaker
    if not active.allow_request:
        raise CircuitOpenError(active.name, active.time_until_recovery)
    try:
        result = await func(*args, **kwargs)
    except Exception:
        active.record_failure()
        if not active.allow_request and on_open is not None:
            on_open(active)
        raise
    active.record_success()
    return result


async def resilient_json_request(
    method: str,
    url: str,
    *,
    breaker: CircuitBreaker | str | None = None,
    max_retries: int = 3,
    base_delay: float = 1.0,
    max_delay: float = 30.0,
    timeout: float = 15.0,
    headers: dict[str, str] | None = None,
    client_factory=httpx.AsyncClient,
    concurrency_limiter: AdaptiveConcurrencyLimiter | None = None,
    single_flight: AsyncSingleFlight | None = None,
    coalesce_key: str | None = None,
    idempotency_key: IdempotencyKey | None = None,
    **request_kwargs: Any,
) -> Any:
    """Request JSON with optional breaker, coalescing, and load shedding.

    Coalescing is opt-in and intended for read-only requests. A limiter rejects
    optional work immediately at saturation rather than adding queue latency.
    """

    request_headers = dict(headers or {})
    if idempotency_key is not None:
        request_headers.setdefault("Idempotency-Key", idempotency_key.storage_key)
    safe_method = method.upper() in {"GET", "HEAD", "OPTIONS", "PUT", "DELETE"}
    effective_max_retries = max_retries if safe_method or idempotency_key is not None else 0

    async def _run_request() -> Any:
        if concurrency_limiter is not None and not concurrency_limiter.try_acquire():
            raise ConcurrencyLimitError(concurrency_limiter.name, concurrency_limiter.limit)
        started_at = time.monotonic()
        succeeded = False
        active = get_breaker(breaker) if isinstance(breaker, str) else breaker
        try:
            async with client_factory(timeout=timeout, headers=request_headers) as client:

                async def _request() -> Any:
                    response = await client.request(method, url, **request_kwargs)
                    response.raise_for_status()
                    return response.json()

                result = await retry_with_backoff(
                    _request,
                    max_retries=effective_max_retries,
                    base_delay=base_delay,
                    max_delay=max_delay,
                    circuit_breaker=active,
                )
                succeeded = True
                return result
        finally:
            if concurrency_limiter is not None:
                concurrency_limiter.release(
                    elapsed_seconds=max(0.0, time.monotonic() - started_at),
                    success=succeeded,
                )

    if single_flight is not None and coalesce_key is not None:
        return await single_flight.run(coalesce_key, _run_request)
    return await _run_request()


async def resilient_get(
    url: str,
    *,
    breaker: CircuitBreaker | str | None = None,
    **kwargs: Any,
) -> Any:
    return await resilient_json_request("GET", url, breaker=breaker, **kwargs)


async def resilient_post(
    url: str,
    json: Any = None,
    *,
    breaker: CircuitBreaker | str | None = None,
    **kwargs: Any,
) -> Any:
    return await resilient_json_request("POST", url, breaker=breaker, json=json, **kwargs)
