"""Internationalization module: middleware, translations, Jinja2 helpers."""

from qazstack.i18n.locales import (
    CANONICAL_LOCALES,
    DEFAULT_ACTIVE_LOCALES,
    LEGACY_LOCALE_ALIASES,
    normalize_locale,
    to_legacy_provider_locale,
)
from qazstack.i18n.middleware import I18nMiddleware, get_lang
from qazstack.i18n.routing import DEFAULT_LANGUAGES, LanguageRoute, resolve_language
from qazstack.i18n.translations import TranslationManager, t

__all__ = [
    "DEFAULT_LANGUAGES",
    "CANONICAL_LOCALES",
    "DEFAULT_ACTIVE_LOCALES",
    "I18nMiddleware",
    "LEGACY_LOCALE_ALIASES",
    "LanguageRoute",
    "TranslationManager",
    "get_lang",
    "normalize_locale",
    "resolve_language",
    "to_legacy_provider_locale",
    "t",
]
