"""Compatibility re-export for the dependency-free locale contract."""

from qazstack.locale_contract import (
    CANONICAL_LOCALES,
    DEFAULT_ACTIVE_LOCALES,
    DEFAULT_LOCALE,
    LEGACY_LOCALE_ALIASES,
    LEGACY_PROVIDER_LOCALE_MAP,
    LOCALE_CONTRACT,
    canonicalize_locales,
    is_canonical_locale,
    locale_url_prefix,
    normalize_locale,
    to_legacy_provider_locale,
    validate_consumer_locale,
    validate_consumer_locales,
)

__all__ = [
    "CANONICAL_LOCALES",
    "DEFAULT_ACTIVE_LOCALES",
    "DEFAULT_LOCALE",
    "LEGACY_LOCALE_ALIASES",
    "LEGACY_PROVIDER_LOCALE_MAP",
    "LOCALE_CONTRACT",
    "canonicalize_locales",
    "is_canonical_locale",
    "locale_url_prefix",
    "normalize_locale",
    "to_legacy_provider_locale",
    "validate_consumer_locale",
    "validate_consumer_locales",
]
