"""Simple dict-based translation system.

Usage:
    from qazstack.i18n import TranslationManager

    tm = TranslationManager(default_lang="ru")
    tm.load({
        "ru": {"home": "Главная", "search": "Поиск"},
        "kk": {"home": "Басты бет", "search": "Іздеу"},
        "en": {"home": "Home", "search": "Search"},
    })

    # Get a translation
    tm.t("home", lang="kk")  # → "Басты бет"

    # Module-level shortcut (after setup)
    from qazstack.i18n import t
    t("search")  # → "Поиск" (uses default lang)
"""

from __future__ import annotations

from typing import Any

from qazstack.i18n.locales import (
    DEFAULT_ACTIVE_LOCALES,
    normalize_locale,
    validate_consumer_locale,
    validate_consumer_locales,
)

# Global translation manager instance
_manager: TranslationManager | None = None


class TranslationManager:
    """Manages translations for multiple languages."""

    def __init__(
        self,
        default_lang: str = "ru",
        supported_langs: list[str] | None = None,
    ):
        self.default_lang = validate_consumer_locale(default_lang, "default_lang")
        self.supported_langs = list(validate_consumer_locales(supported_langs or DEFAULT_ACTIVE_LOCALES))
        if self.default_lang not in self.supported_langs:
            raise ValueError("default_lang must be included in supported_langs")
        self._translations: dict[str, dict[str, str]] = {}
        self._current_lang: str = self.default_lang

        # Set as global
        global _manager
        _manager = self

    def load(self, translations: dict[str, dict[str, str]]) -> None:
        """Load translations dict. Keys are lang codes, values are {key: text} dicts."""
        for language, values in translations.items():
            normalized = normalize_locale(language)
            if not normalized:
                raise ValueError(f"catalog language is not supported: {language!r}")
            if not isinstance(values, dict):
                raise ValueError(f"catalog for {normalized} must be a mapping")
            self._translations[normalized] = values

    def load_from_yaml(self, path: str) -> None:
        """Load translations from a YAML file."""
        from pathlib import Path

        import yaml

        data = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
        self.load(data)

    def set_lang(self, lang: str) -> None:
        """Set current language for thread-local usage."""
        normalized = normalize_locale(lang)
        if normalized in self.supported_langs:
            self._current_lang = normalized

    @property
    def lang(self) -> str:
        return self._current_lang

    def t(self, key: str, lang: str | None = None, **kwargs: Any) -> str:
        """Translate a key.

        Falls back: requested lang → default lang → key itself, except that
        ``zh-Hans`` never falls back. A Chinese catalog therefore has to be
        complete before a consumer can publish it.
        Supports format strings: t("greeting", name="World")
        """
        lang = normalize_locale(lang or self._current_lang)
        requested = self._translations.get(lang, {}).get(key)
        if lang == "zh-Hans":
            text = requested if _usable_translation(requested) else key
        else:
            fallback = self._translations.get(self.default_lang, {}).get(key)
            text = requested if _usable_translation(requested) else fallback if _usable_translation(fallback) else key
        if kwargs:
            try:
                return text.format(**kwargs)
            except (KeyError, IndexError):
                return text
        return text

    def get_all(self, lang: str | None = None) -> dict[str, str]:
        """Get all translations for a language."""
        lang = normalize_locale(lang or self._current_lang)
        return self._translations.get(lang, {})

    def catalog_status(self, lang: str) -> dict[str, object]:
        """Return structural readiness against the default-language key set."""

        target = normalize_locale(lang)
        if not target:
            raise ValueError(f"catalog language is not supported: {lang!r}")
        reference = self._translations.get(self.default_lang, {})
        catalog = self._translations.get(target, {})
        expected = tuple(reference)
        missing = tuple(key for key in expected if key not in catalog)
        blank = tuple(key for key in expected if key in catalog and not _usable_translation(catalog[key]))
        return {
            "language": target,
            "ready": bool(expected) and not missing and not blank,
            "missing_keys": missing,
            "blank_keys": blank,
        }

    def assert_catalog_ready(self, lang: str) -> None:
        """Raise a publish-gate error for incomplete or blank catalog entries."""

        status = self.catalog_status(lang)
        if not status["ready"]:
            raise ValueError(
                f"catalog {status['language']} is not publish-ready: "
                f"missing={','.join(status['missing_keys']) or '-'} blank={','.join(status['blank_keys']) or '-'}"
            )

    @property
    def ready_languages(self) -> list[str]:
        """Languages with complete local catalogs; suitable for a route gate."""

        return [language for language in self.supported_langs if self.catalog_status(language)["ready"]]

    def jinja_globals(self) -> dict[str, Any]:
        """Return dict of globals to inject into Jinja2 templates.

        Usage:
            templates.env.globals.update(tm.jinja_globals())
        Then in templates:
            {{ t("home") }}
            {{ lang }}
            {{ languages }}
        """
        return {
            "t": self.t,
            "lang": self._current_lang,
            # ``languages`` remains the historic default kk/ru/en template
            # surface. Opt-in locales are exposed only through the readiness
            # list and must still pass the consumer's own receipt gate.
            "languages": [language for language in DEFAULT_ACTIVE_LOCALES if language in self.supported_langs],
            "ready_languages": self.ready_languages,
            "public_languages": self.ready_languages,
        }


def _usable_translation(value: object) -> bool:
    return isinstance(value, str) and bool(value.strip())


def t(key: str, lang: str | None = None, **kwargs: Any) -> str:
    """Module-level translation shortcut."""
    if _manager is None:
        return key
    return _manager.t(key, lang=lang, **kwargs)
