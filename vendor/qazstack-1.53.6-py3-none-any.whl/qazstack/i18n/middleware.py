"""i18n middleware for FastAPI – reads ?lang= param or cookie.

Usage:
    from qazstack.i18n import I18nMiddleware, get_lang

    app.add_middleware(I18nMiddleware, default_lang="ru", supported_langs=["ru", "kk", "en"])

    @app.get("/")
    async def index(request: Request):
        lang = get_lang(request)  # → "ru" | "kk" | "en"
"""

from __future__ import annotations

from contextvars import ContextVar
from typing import Sequence

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

from qazstack.i18n.locales import (
    DEFAULT_ACTIVE_LOCALES,
    normalize_locale,
    validate_consumer_locale,
    validate_consumer_locales,
)

_lang_ctx: ContextVar[str] = ContextVar("current_lang", default="ru")


class I18nMiddleware(BaseHTTPMiddleware):
    """Detect language from ?lang= query param, cookie, or Accept-Language header."""

    def __init__(
        self,
        app,
        default_lang: str = "ru",
        supported_langs: Sequence[str] = DEFAULT_ACTIVE_LOCALES,
        cookie_name: str = "lang",
        cookie_max_age: int = 365 * 24 * 3600,
    ):
        super().__init__(app)
        self.default_lang = validate_consumer_locale(default_lang, "default_lang")
        self.supported_langs = set(validate_consumer_locales(supported_langs))
        if self.default_lang not in self.supported_langs:
            raise ValueError("default_lang must be included in supported_langs")
        self.cookie_name = cookie_name
        self.cookie_max_age = cookie_max_age

    async def dispatch(self, request: Request, call_next) -> Response:
        lang = self._detect_lang(request)
        _lang_ctx.set(lang)
        request.state.lang = lang

        response: Response = await call_next(request)

        # Set cookie if lang was explicitly requested via query param
        requested = normalize_locale(request.query_params.get("lang"))
        if requested in self.supported_langs:
            response.set_cookie(
                self.cookie_name,
                lang,
                max_age=self.cookie_max_age,
                httponly=False,
                samesite="lax",
            )

        return response

    def _detect_lang(self, request: Request) -> str:
        # 1. Query parameter ?lang=kk (legacy ?lang=kz is normalized)
        if lang := normalize_locale(request.query_params.get("lang")):
            if lang in self.supported_langs:
                return lang

        # 2. Cookie
        if lang := normalize_locale(request.cookies.get(self.cookie_name)):
            if lang in self.supported_langs:
                return lang

        # 3. Accept-Language header
        accept = request.headers.get("accept-language", "")
        for part in accept.split(","):
            code = normalize_locale(part.split(";")[0])
            if code in self.supported_langs:
                return code

        return self.default_lang


def get_lang(request: Request) -> str:
    """Get current language from request (set by I18nMiddleware)."""
    return getattr(request.state, "lang", _lang_ctx.get())
