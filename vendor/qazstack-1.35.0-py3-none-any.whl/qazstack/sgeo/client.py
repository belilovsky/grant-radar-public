"""Async QazStack client for the public SGEO integration contract."""

from __future__ import annotations

import os
from typing import Any

import httpx

from qazstack.sgeo.models import SgeoBidirectionalProof, SgeoEvidence, SgeoIntegrationState

DEFAULT_SGEO_URL = "https://sgeo.live"
REQUIRED_PRIMITIVES = {
    "analytics-and-kznlp",
    "geo-and-location",
    "proxy-and-transport",
    "reports-and-export",
}


class SgeoError(RuntimeError):
    """Raised when the SGEO integration contract cannot be read or validated."""


class SgeoClient:
    """Read SGEO runtime evidence and verify the two-way QazStack contract."""

    def __init__(
        self,
        base_url: str | None = None,
        *,
        timeout: float = 10.0,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self.base_url = (base_url or os.getenv("SGEO_URL", DEFAULT_SGEO_URL)).rstrip("/")
        self.timeout = timeout
        self._transport = transport
        self._client: httpx.AsyncClient | None = None

    async def _http(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                timeout=self.timeout,
                transport=self._transport,
                headers={"accept": "application/json", "user-agent": "qazstack-sgeo/1"},
            )
        return self._client

    async def close(self) -> None:
        if self._client is not None and not self._client.is_closed:
            await self._client.aclose()

    async def __aenter__(self) -> "SgeoClient":
        return self

    async def __aexit__(self, *_args: Any) -> None:
        await self.close()

    async def _get(self, path: str) -> dict[str, Any]:
        try:
            response = await (await self._http()).get(path)
            response.raise_for_status()
            payload = response.json()
        except (httpx.HTTPError, ValueError) as exc:
            raise SgeoError(f"SGEO request failed for {path}") from exc
        if not isinstance(payload, dict):
            raise SgeoError(f"SGEO returned a non-object payload for {path}")
        return payload

    async def health(self) -> dict[str, Any]:
        return await self._get("/api/health")

    async def readiness(self) -> dict[str, Any]:
        return await self._get("/api/readiness")

    async def integration(self) -> SgeoIntegrationState:
        return SgeoIntegrationState.model_validate(await self._get("/api/integrations/qazstack"))

    async def evidence(self) -> SgeoEvidence:
        return SgeoEvidence.model_validate(await self._get("/api/integrations/qazstack/evidence"))

    async def verify_bidirectional(self) -> SgeoBidirectionalProof:
        integration = await self.integration()
        evidence = await self.evidence()
        primitive_ids = set(integration.consumer.primitive_ids if integration.consumer else [])
        capabilities = set(evidence.capabilities)
        missing_primitives = sorted(REQUIRED_PRIMITIVES - primitive_ids)
        missing_capabilities = sorted(REQUIRED_PRIMITIVES - capabilities)
        connected = (
            integration.status == "connected"
            and integration.consumer is not None
            and evidence.runtime.ready
            and not missing_primitives
            and not missing_capabilities
        )
        return SgeoBidirectionalProof(
            connected=connected,
            integration=integration,
            evidence=evidence,
            missing_primitives=missing_primitives,
            missing_capabilities=missing_capabilities,
        )
