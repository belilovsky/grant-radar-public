"""Typed SGEO <-> QazStack integration contracts."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


class SgeoConsumerContract(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    id: Literal["sgeo-lane"]
    name: str
    status: str
    primitive_ids: list[str] = Field(default_factory=list, alias="primitiveIds")
    evidence: list[str] = Field(default_factory=list)
    linked_idea_ids: list[str] = Field(default_factory=list, alias="linkedIdeaIds")


class SgeoIntegrationState(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    schema_version: Literal["sgeo-qazstack-integration-v1"] = Field(alias="schemaVersion")
    status: Literal["connected", "degraded"]
    checked_at: str = Field(alias="checkedAt")
    registry_url: str = Field(alias="registryUrl")
    registry_schema_version: str | None = Field(default=None, alias="registrySchemaVersion")
    registry_generated_at: str | None = Field(default=None, alias="registryGeneratedAt")
    consumer: SgeoConsumerContract | None = None
    error: str | None = None


class SgeoEvidenceRuntime(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    ready: bool
    visibility_tests: dict[str, int] = Field(alias="visibilityTests")
    latest_completed_benchmark: dict[str, Any] | None = Field(alias="latestCompletedBenchmark")


class SgeoEvidence(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    schema_version: Literal["sgeo-qazstack-evidence-v1"] = Field(alias="schemaVersion")
    producer: Literal["sgeo.live"]
    consumer_lane: Literal["sgeo-lane"] = Field(alias="consumerLane")
    generated_at: str = Field(alias="generatedAt")
    capabilities: list[str]
    runtime: SgeoEvidenceRuntime
    endpoints: dict[str, str]


class SgeoBidirectionalProof(BaseModel):
    connected: bool
    integration: SgeoIntegrationState
    evidence: SgeoEvidence
    missing_primitives: list[str] = Field(default_factory=list)
    missing_capabilities: list[str] = Field(default_factory=list)
