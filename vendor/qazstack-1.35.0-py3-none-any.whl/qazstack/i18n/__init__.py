"""Internationalization module: middleware, translations, Jinja2 helpers."""

from qazstack.i18n.middleware import I18nMiddleware, get_lang
from qazstack.i18n.routing import DEFAULT_LANGUAGES, LanguageRoute, resolve_language
from qazstack.i18n.translations import TranslationManager, t

__all__ = [
    "DEFAULT_LANGUAGES",
    "I18nMiddleware",
    "LanguageRoute",
    "TranslationManager",
    "get_lang",
    "resolve_language",
    "t",
]
