"""i18n middleware for FastAPI – reads ?lang= param or cookie.

Usage:
    from qazstack.i18n import I18nMiddleware, get_lang

    app.add_middleware(I18nMiddleware, default_lang="ru", supported_langs=["ru", "kz", "en"])

    @app.get("/")
    async def index(request: Request):
        lang = get_lang(request)  # → "ru" | "kz" | "en"
"""

from __future__ import annotations

from contextvars import ContextVar
from typing import Sequence

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

_lang_ctx: ContextVar[str] = ContextVar("current_lang", default="ru")


class I18nMiddleware(BaseHTTPMiddleware):
    """Detect language from ?lang= query param, cookie, or Accept-Language header."""

    def __init__(
        self,
        app,
        default_lang: str = "ru",
        supported_langs: Sequence[str] = ("ru", "kz", "en"),
        cookie_name: str = "lang",
        cookie_max_age: int = 365 * 24 * 3600,
    ):
        super().__init__(app)
        self.default_lang = default_lang
        self.supported_langs = set(supported_langs)
        self.cookie_name = cookie_name
        self.cookie_max_age = cookie_max_age

    async def dispatch(self, request: Request, call_next) -> Response:
        lang = self._detect_lang(request)
        _lang_ctx.set(lang)
        request.state.lang = lang

        response: Response = await call_next(request)

        # Set cookie if lang was explicitly requested via query param
        if "lang" in request.query_params:
            response.set_cookie(
                self.cookie_name,
                lang,
                max_age=self.cookie_max_age,
                httponly=False,
                samesite="lax",
            )

        return response

    def _detect_lang(self, request: Request) -> str:
        # 1. Query parameter ?lang=kz
        if lang := request.query_params.get("lang"):
            if lang in self.supported_langs:
                return lang

        # 2. Cookie
        if lang := request.cookies.get(self.cookie_name):
            if lang in self.supported_langs:
                return lang

        # 3. Accept-Language header
        accept = request.headers.get("accept-language", "")
        for part in accept.split(","):
            code = part.split(";")[0].strip().lower()[:2]
            if code in self.supported_langs:
                return code

        return self.default_lang


def get_lang(request: Request) -> str:
    """Get current language from request (set by I18nMiddleware)."""
    return getattr(request.state, "lang", _lang_ctx.get())
