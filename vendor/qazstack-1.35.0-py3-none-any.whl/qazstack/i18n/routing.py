"""Deterministic kk/ru/en language selection independent of translation data."""

from __future__ import annotations

from dataclasses import dataclass

DEFAULT_LANGUAGES = ("kk", "ru", "en")


@dataclass(frozen=True, slots=True)
class LanguageRoute:
    language: str
    source: str
    should_persist: bool
    canonical_prefix: str


def _accepted_language(header: str | None, supported: tuple[str, ...]) -> str | None:
    if not header:
        return None
    candidates: list[tuple[float, int, str]] = []
    for index, raw in enumerate(header.split(",")):
        parts = raw.strip().lower().split(";")
        language = parts[0].split("-")[0]
        quality = 1.0
        for parameter in parts[1:]:
            if parameter.strip().startswith("q="):
                try:
                    quality = float(parameter.strip()[2:])
                except ValueError:
                    quality = 0.0
        if language in supported:
            candidates.append((quality, -index, language))
    return max(candidates)[2] if candidates else None


def resolve_language(
    *,
    explicit: str | None = None,
    url_language: str | None = None,
    profile_language: str | None = None,
    accept_language: str | None = None,
    supported: tuple[str, ...] = DEFAULT_LANGUAGES,
    default: str = "ru",
) -> LanguageRoute:
    """Apply explicit, URL, profile, browser and default precedence."""
    if not supported or default not in supported or len(set(supported)) != len(supported):
        raise ValueError("supported languages must be unique and include default")
    candidates = (
        (explicit, "explicit", True),
        (url_language, "url", False),
        (profile_language, "profile", False),
        (_accepted_language(accept_language, supported), "browser", False),
        (default, "default", False),
    )
    for value, source, persist in candidates:
        normalized = (value or "").lower().split("-")[0]
        if normalized in supported:
            return LanguageRoute(normalized, source, persist, f"/{normalized}")
    raise AssertionError("default language resolution failed")
