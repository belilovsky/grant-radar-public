"""Portable, storage-neutral operational task lifecycle contracts."""

from __future__ import annotations

import re
from collections.abc import Mapping
from dataclasses import dataclass, field, replace
from datetime import datetime
from typing import Any

from qazstack.contracts._validation import require_aware, require_identifier, require_one_of, require_text

OPERATIONAL_TASK_SCHEMA_VERSION = "qazstack-operational-task-v1"
TASK_STATUSES = frozenset({"new", "assigned", "acknowledged", "in_progress", "blocked", "completed", "cancelled"})
TASK_PRIORITIES = frozenset({"low", "normal", "high", "critical"})
_ALLOWED_TRANSITIONS: dict[str, frozenset[str]] = {
    "new": frozenset({"assigned", "cancelled"}),
    "assigned": frozenset({"acknowledged", "in_progress", "blocked", "cancelled"}),
    "acknowledged": frozenset({"in_progress", "blocked", "cancelled"}),
    "in_progress": frozenset({"blocked", "completed", "cancelled"}),
    "blocked": frozenset({"assigned", "in_progress", "cancelled"}),
    "completed": frozenset(),
    "cancelled": frozenset(),
}
_OPAQUE_REFERENCE_RE = re.compile(r"^(?:artifact|evidence|qazlake|qazstack|source):(?:/{2})?[^\s]{1,480}$")


def _reference(value: str, field_name: str) -> str:
    """Validate a bounded, product-owned internal reference without payload content."""
    normalized = require_text(value, field_name)
    if not _OPAQUE_REFERENCE_RE.fullmatch(normalized):
        raise ValueError(f"{field_name} must be an opaque internal reference")
    return normalized


def _references(values: tuple[str, ...], field_name: str) -> tuple[str, ...]:
    """Validate and deduplicate opaque references while preserving order."""
    normalized = tuple(dict.fromkeys(_reference(value, field_name) for value in values))
    if len(normalized) > 20:
        raise ValueError(f"{field_name} must contain at most 20 items")
    return normalized


def _bounded_text(value: str, field_name: str, maximum: int) -> str:
    """Normalize required product-owned display metadata at a bounded length."""
    normalized = " ".join(require_text(value, field_name).split())
    if len(normalized) > maximum:
        raise ValueError(f"{field_name} must be at most {maximum} characters")
    return normalized


@dataclass(frozen=True, slots=True)
class OperationalTask:
    """A product-owned task record with portable lifecycle and evidence invariants."""

    task_id: str
    correlation_id: str
    source_type: str
    source_ref: str
    title: str
    assignee_role: str
    created_at: datetime
    updated_at: datetime
    status: str = "new"
    priority: str = "normal"
    assignee_id: str | None = None
    deadline_at: datetime | None = None
    acknowledged_at: datetime | None = None
    started_at: datetime | None = None
    completed_at: datetime | None = None
    evidence_refs: tuple[str, ...] = ()
    outcome: Mapping[str, Any] = field(default_factory=dict)
    version: int = 0

    def __post_init__(self) -> None:
        """Validate storage-neutral task state without assuming a product database."""
        require_identifier(self.task_id, "task_id")
        _bounded_text(self.correlation_id, "correlation_id", 256)
        require_identifier(self.source_type, "source_type")
        object.__setattr__(self, "source_ref", _reference(self.source_ref, "source_ref"))
        object.__setattr__(self, "title", _bounded_text(self.title, "title", 240))
        require_identifier(self.assignee_role, "assignee_role")
        require_one_of(self.status, TASK_STATUSES, "status")
        require_one_of(self.priority, TASK_PRIORITIES, "priority")
        require_aware(self.created_at, "created_at")
        require_aware(self.updated_at, "updated_at")
        if self.updated_at < self.created_at:
            raise ValueError("updated_at cannot be before created_at")
        for field_name in ("deadline_at", "acknowledged_at", "started_at", "completed_at"):
            value = getattr(self, field_name)
            if value is not None:
                require_aware(value, field_name)
        if self.assignee_id is not None:
            require_identifier(self.assignee_id, "assignee_id")
        if self.status in {"assigned", "acknowledged", "in_progress", "blocked", "completed"} and not self.assignee_id:
            raise ValueError(f"{self.status} tasks require assignee_id")
        if self.status in {"acknowledged", "in_progress", "completed"} and self.acknowledged_at is None:
            raise ValueError(f"{self.status} tasks require acknowledged_at")
        if self.status in {"in_progress", "completed"} and self.started_at is None:
            raise ValueError(f"{self.status} tasks require started_at")
        evidence = _references(self.evidence_refs, "evidence_refs")
        object.__setattr__(self, "evidence_refs", evidence)
        if not isinstance(self.outcome, Mapping) or len(self.outcome) > 24:
            raise ValueError("outcome must be a mapping with at most 24 fields")
        object.__setattr__(self, "outcome", dict(self.outcome))
        if self.status == "completed":
            if self.completed_at is None:
                raise ValueError("completed tasks require completed_at")
            if not evidence or not self.outcome:
                raise ValueError("completed tasks require evidence_refs and outcome")
        if self.version < 0:
            raise ValueError("version must be non-negative")


@dataclass(frozen=True, slots=True)
class TaskTransition:
    """One optimistic-concurrency transition requested by a product adapter."""

    task_id: str
    status: str
    actor_id: str
    occurred_at: datetime
    expected_version: int
    assignee_id: str | None = None
    evidence_refs: tuple[str, ...] = ()
    outcome: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Validate transition metadata before an adapter persists it."""
        require_identifier(self.task_id, "task_id")
        require_one_of(self.status, TASK_STATUSES, "status")
        require_identifier(self.actor_id, "actor_id")
        require_aware(self.occurred_at, "occurred_at")
        if self.expected_version < 0:
            raise ValueError("expected_version must be non-negative")
        if self.assignee_id is not None:
            require_identifier(self.assignee_id, "assignee_id")
        object.__setattr__(self, "evidence_refs", _references(self.evidence_refs, "evidence_refs"))
        if not isinstance(self.outcome, Mapping) or len(self.outcome) > 24:
            raise ValueError("outcome must be a mapping with at most 24 fields")
        object.__setattr__(self, "outcome", dict(self.outcome))


@dataclass(frozen=True, slots=True)
class OperationalTaskEvent:
    """Append-only audit record returned alongside a validated state transition."""

    task_id: str
    event_type: str
    actor_id: str
    occurred_at: datetime
    status_from: str
    status_to: str
    version: int
    evidence_refs: tuple[str, ...] = ()
    outcome: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Validate event metadata while keeping persistence product-owned."""
        require_identifier(self.task_id, "task_id")
        require_identifier(self.event_type, "event_type")
        require_identifier(self.actor_id, "actor_id")
        require_aware(self.occurred_at, "occurred_at")
        require_one_of(self.status_from, TASK_STATUSES, "status_from")
        require_one_of(self.status_to, TASK_STATUSES, "status_to")
        if self.version <= 0:
            raise ValueError("version must be positive")
        object.__setattr__(self, "evidence_refs", _references(self.evidence_refs, "evidence_refs"))
        if not isinstance(self.outcome, Mapping) or len(self.outcome) > 24:
            raise ValueError("outcome must be a mapping with at most 24 fields")
        object.__setattr__(self, "outcome", dict(self.outcome))


def apply_task_transition(
    task: OperationalTask, transition: TaskTransition
) -> tuple[OperationalTask, OperationalTaskEvent]:
    """Return immutable next state and audit event without persisting either one."""
    if transition.task_id != task.task_id:
        raise ValueError("transition task_id does not match task")
    if transition.expected_version != task.version:
        raise ValueError("task version conflict")
    if transition.status not in _ALLOWED_TRANSITIONS[task.status]:
        raise ValueError(f"task transition is not allowed: {task.status} -> {transition.status}")

    assignee_id = transition.assignee_id or task.assignee_id
    if transition.status == "assigned" and assignee_id is None:
        raise ValueError("assigned tasks require assignee_id")
    evidence_refs = transition.evidence_refs or task.evidence_refs
    outcome = dict(transition.outcome) or dict(task.outcome)
    if transition.status == "completed" and (not evidence_refs or not outcome):
        raise ValueError("completed tasks require evidence_refs and outcome")

    occurred_at = transition.occurred_at
    next_task = replace(
        task,
        status=transition.status,
        assignee_id=assignee_id,
        # Starting work directly from "assigned" is an implicit acknowledgement.
        acknowledged_at=(
            occurred_at
            if transition.status == "acknowledged"
            or (transition.status == "in_progress" and task.acknowledged_at is None)
            else task.acknowledged_at
        ),
        started_at=occurred_at if transition.status == "in_progress" else task.started_at,
        completed_at=occurred_at if transition.status == "completed" else task.completed_at,
        evidence_refs=evidence_refs,
        outcome=outcome if transition.status == "completed" else task.outcome,
        updated_at=occurred_at,
        version=task.version + 1,
    )
    event = OperationalTaskEvent(
        task_id=task.task_id,
        event_type="status_changed",
        actor_id=transition.actor_id,
        occurred_at=occurred_at,
        status_from=task.status,
        status_to=next_task.status,
        version=next_task.version,
        evidence_refs=evidence_refs,
        outcome=outcome if transition.status == "completed" else {},
    )
    return next_task, event


__all__ = [
    "OPERATIONAL_TASK_SCHEMA_VERSION",
    "OperationalTask",
    "OperationalTaskEvent",
    "TASK_PRIORITIES",
    "TASK_STATUSES",
    "TaskTransition",
    "apply_task_transition",
]
