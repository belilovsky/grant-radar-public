"""Queue-neutral background run, schedule and cache coordination contracts."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from qazstack.contracts._validation import require_aware, require_identifier, require_one_of, require_positive

RUN_STATUSES = frozenset({"queued", "running", "succeeded", "failed", "cancelled"})
OVERLAP_POLICIES = frozenset({"allow", "forbid", "replace"})
MISFIRE_POLICIES = frozenset({"skip", "run_once", "catch_up"})
CACHE_STATUSES = frozenset({"miss", "fresh", "stale", "negative"})


@dataclass(frozen=True, slots=True)
class BackgroundRun:
    run_id: str
    task_name: str
    status: str
    attempt: int
    max_attempts: int
    created_at: datetime
    started_at: datetime | None = None
    finished_at: datetime | None = None
    lease_expires_at: datetime | None = None
    cancel_requested: bool = False

    def __post_init__(self) -> None:
        require_identifier(self.run_id, "run_id")
        require_identifier(self.task_name, "task_name")
        require_one_of(self.status, RUN_STATUSES, "status")
        require_positive(self.attempt, "attempt")
        require_positive(self.max_attempts, "max_attempts")
        require_aware(self.created_at, "created_at")
        for name in ("started_at", "finished_at", "lease_expires_at"):
            value = getattr(self, name)
            if value is not None:
                require_aware(value, name)
        if self.attempt > self.max_attempts:
            raise ValueError("attempt cannot exceed max_attempts")
        if self.status == "running" and self.started_at is None:
            raise ValueError("running jobs require started_at")
        if self.status in {"succeeded", "failed", "cancelled"} and self.finished_at is None:
            raise ValueError("terminal jobs require finished_at")

    @property
    def retryable(self) -> bool:
        return self.status == "failed" and self.attempt < self.max_attempts and not self.cancel_requested


@dataclass(frozen=True, slots=True)
class ScheduleDefinition:
    schedule_id: str
    task_name: str
    cron: str
    timezone: str
    overlap_policy: str = "forbid"
    misfire_policy: str = "run_once"
    max_catch_up: int = 1
    enabled: bool = True

    def __post_init__(self) -> None:
        require_identifier(self.schedule_id, "schedule_id")
        require_identifier(self.task_name, "task_name")
        if len(self.cron.split()) not in {5, 6}:
            raise ValueError("cron must contain five or six fields")
        try:
            ZoneInfo(self.timezone)
        except ZoneInfoNotFoundError as exc:
            raise ValueError("timezone must be a valid IANA timezone") from exc
        require_one_of(self.overlap_policy, OVERLAP_POLICIES, "overlap_policy")
        require_one_of(self.misfire_policy, MISFIRE_POLICIES, "misfire_policy")
        require_positive(self.max_catch_up, "max_catch_up")
        if self.misfire_policy != "catch_up" and self.max_catch_up != 1:
            raise ValueError("max_catch_up only applies to catch_up schedules")


@dataclass(frozen=True, slots=True)
class ScheduleRun:
    schedule_id: str
    background_run_id: str
    due_at: datetime
    triggered_at: datetime
    trigger: str = "scheduled"

    def __post_init__(self) -> None:
        require_identifier(self.schedule_id, "schedule_id")
        require_identifier(self.background_run_id, "background_run_id")
        require_aware(self.due_at, "due_at")
        require_aware(self.triggered_at, "triggered_at")
        require_one_of(self.trigger, frozenset({"scheduled", "catch_up", "manual"}), "trigger")


@dataclass(frozen=True, slots=True)
class CacheEntryPolicy:
    namespace: str
    key: str
    ttl_seconds: int
    stale_while_revalidate_seconds: int = 0
    negative_ttl_seconds: int = 0
    single_flight: bool = True

    def __post_init__(self) -> None:
        require_identifier(self.namespace, "namespace")
        if not self.key.strip():
            raise ValueError("key must be non-empty")
        require_positive(self.ttl_seconds, "ttl_seconds")
        require_positive(self.stale_while_revalidate_seconds, "stale_while_revalidate_seconds", allow_zero=True)
        require_positive(self.negative_ttl_seconds, "negative_ttl_seconds", allow_zero=True)

    @property
    def cache_key(self) -> str:
        return f"{self.namespace}:{self.key}"


@dataclass(frozen=True, slots=True)
class CacheLookup:
    status: str
    age_seconds: float | None
    lock_acquired: bool = False

    def __post_init__(self) -> None:
        require_one_of(self.status, CACHE_STATUSES, "status")
        if self.status == "miss" and self.age_seconds is not None:
            raise ValueError("cache misses cannot have an age")
        if self.age_seconds is not None:
            require_positive(self.age_seconds, "age_seconds", allow_zero=True)

    @property
    def should_recompute(self) -> bool:
        return self.status in {"miss", "stale"} and self.lock_acquired
