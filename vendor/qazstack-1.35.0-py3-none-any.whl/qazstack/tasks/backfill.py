"""Resume-safe, rate-limited orchestration for corpus backfill jobs."""

from __future__ import annotations

import asyncio
import inspect
import json
import time
from collections.abc import Awaitable, Callable, Iterable, Mapping, Sequence
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

CountCandidates = Callable[[str], int]
IterCandidates = Callable[[str, int], Iterable[Any]]
EnqueueCandidate = Callable[[str, Any], Awaitable[None]]
ProgressWriter = Callable[[Mapping[str, Any]], None]
ErrorHandler = Callable[[str, Any, Exception], None]


def inclusive_date_to_exclusive(day: str | None) -> str:
    """Convert an inclusive ISO date to the following exclusive date."""
    if not day:
        return ""
    value = day[:10].strip()
    try:
        return (datetime.fromisoformat(value).date() + timedelta(days=1)).isoformat()
    except ValueError:
        return value


def write_json_progress(path: str | Path, state: Mapping[str, Any]) -> None:
    """Atomically persist progress without exposing a partially written file."""
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    payload = dict(state)
    payload["updated_at"] = datetime.now(timezone.utc).isoformat()
    temporary = target.with_suffix(f"{target.suffix}.tmp")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(target)


class BackfillRunner:
    """Generic queue producer; database and task contracts stay in adapters."""

    def __init__(
        self,
        *,
        kinds: Sequence[str],
        count_candidates: CountCandidates,
        iter_candidates: IterCandidates,
        enqueue_candidate: EnqueueCandidate,
        progress_writer: ProgressWriter | None = None,
        stop_requested: Callable[[], bool] | None = None,
        on_error: ErrorHandler | None = None,
        progress_every: int = 100,
        metadata: Mapping[str, Any] | None = None,
    ) -> None:
        self.kinds = list(dict.fromkeys(kinds))
        self.count_candidates = count_candidates
        self.iter_candidates = iter_candidates
        self.enqueue_candidate = enqueue_candidate
        self.progress_writer = progress_writer
        self.stop_requested = stop_requested or (lambda: False)
        self.on_error = on_error
        self.progress_every = max(1, progress_every)
        self.metadata = dict(metadata or {})

    def plan(self) -> list[dict[str, Any]]:
        return [{"kind": kind, "candidates": int(self.count_candidates(kind))} for kind in self.kinds]

    def _write(self, state: dict[str, Any]) -> None:
        if self.progress_writer is not None:
            self.progress_writer(dict(state))

    async def run(
        self,
        *,
        rps: float = 5.0,
        batch: int = 500,
        dry_run: bool = False,
        max_enqueue: int | None = None,
    ) -> dict[str, Any]:
        plan = self.plan()
        total_candidates = sum(item["candidates"] for item in plan)
        if dry_run:
            return {"dry_run": True, "plan": plan, "total_candidates": total_candidates, **self.metadata}

        state: dict[str, Any] = {
            "started_at": datetime.now(timezone.utc).isoformat(),
            "kinds": self.kinds,
            "plan": plan,
            "total_candidates": total_candidates,
            "enqueued": 0,
            "failed": 0,
            "current_kind": None,
            "done_per_kind": {kind: 0 for kind in self.kinds},
            "status": "running",
            **self.metadata,
        }
        self._write(state)
        started = time.monotonic()
        interval = 1.0 / rps if rps > 0 else 0.0

        for kind in self.kinds:
            if self.stop_requested():
                break
            state["current_kind"] = kind
            for candidate in self.iter_candidates(kind, batch):
                if self.stop_requested():
                    break
                if max_enqueue is not None and state["enqueued"] >= max_enqueue:
                    break
                try:
                    result = self.enqueue_candidate(kind, candidate)
                    if inspect.isawaitable(result):
                        await result
                    state["enqueued"] += 1
                    state["done_per_kind"][kind] += 1
                except Exception as exc:
                    state["failed"] += 1
                    if self.on_error is not None:
                        self.on_error(kind, candidate, exc)

                if state["enqueued"] and state["enqueued"] % self.progress_every == 0:
                    elapsed = max(time.monotonic() - started, 0.001)
                    state["elapsed_sec"] = round(elapsed, 1)
                    state["rate_per_sec"] = round(state["enqueued"] / elapsed, 2)
                    self._write(state)
                if interval:
                    await asyncio.sleep(interval)

            if max_enqueue is not None and state["enqueued"] >= max_enqueue:
                break

        limited = max_enqueue is not None and state["enqueued"] >= max_enqueue
        state["status"] = "stopped" if self.stop_requested() else ("limited" if limited else "completed")
        state["finished_at"] = datetime.now(timezone.utc).isoformat()
        state["elapsed_sec"] = round(time.monotonic() - started, 1)
        self._write(state)
        return state
