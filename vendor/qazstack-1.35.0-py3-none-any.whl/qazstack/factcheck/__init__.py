"""Provider-neutral fact-checking contracts and deterministic helpers.

The package deliberately does not assign editorial verdicts, fetch sources or
persist product records. Consumers keep those responsibilities and map their
domain models into these small, testable contracts.
"""

from qazstack.factcheck.contracts import AtomicClaim, EvidenceReference
from qazstack.factcheck.forensics import (
    AnalysisProvenance,
    ForensicArtifact,
    ForensicRunRecord,
    ForensicSignal,
)
from qazstack.factcheck.matching import ClaimMatchResult, ClaimMatchWeights, score_claim_match
from qazstack.factcheck.quality import (
    FactCheckQualityInput,
    QualityEvaluation,
    QualityFinding,
    evaluate_factcheck_quality,
)

__all__ = [
    "AnalysisProvenance",
    "AtomicClaim",
    "ClaimMatchResult",
    "ClaimMatchWeights",
    "EvidenceReference",
    "FactCheckQualityInput",
    "ForensicArtifact",
    "ForensicRunRecord",
    "ForensicSignal",
    "QualityEvaluation",
    "QualityFinding",
    "evaluate_factcheck_quality",
    "score_claim_match",
]
