"""Deterministic publication-readiness checks for fact-check records."""

from __future__ import annotations

from dataclasses import dataclass

from qazstack.contracts._validation import require_http_url, require_one_of
from qazstack.factcheck.contracts import EvidenceReference

PUBLICATION_STATES = frozenset({"draft", "review", "ready", "published", "corrected", "archived"})
TRANSLATION_STATES = frozenset({"source", "machine", "review", "verified"})
_PUBLICATION_BOUND = frozenset({"ready", "published", "corrected"})


@dataclass(frozen=True, slots=True)
class FactCheckQualityInput:
    claim_text: str = ""
    analysis_text: str = ""
    evidence: tuple[EvidenceReference, ...] = ()
    official_source_url: str = ""
    origin_url: str = ""
    origin_locator: str = ""
    limitations: str = ""
    reviewer_ids: tuple[str, ...] = ()
    publication_state: str = "draft"
    translation_state: str = "source"

    def __post_init__(self) -> None:
        require_one_of(self.publication_state, PUBLICATION_STATES, "publication_state")
        require_one_of(self.translation_state, TRANSLATION_STATES, "translation_state")
        if self.official_source_url:
            require_http_url(self.official_source_url, "official_source_url")
        if self.origin_url:
            require_http_url(self.origin_url, "origin_url")
        if any(not isinstance(item, EvidenceReference) for item in self.evidence):
            raise ValueError("evidence must contain EvidenceReference values")


@dataclass(frozen=True, slots=True)
class QualityFinding:
    code: str
    field: str
    severity: str

    def __post_init__(self) -> None:
        require_one_of(self.severity, frozenset({"warning", "blocker"}), "severity")


@dataclass(frozen=True, slots=True)
class QualityEvaluation:
    state: str
    findings: tuple[QualityFinding, ...]

    @property
    def is_ready(self) -> bool:
        return self.state == "ready"


def evaluate_factcheck_quality(value: FactCheckQualityInput) -> QualityEvaluation:
    """Evaluate explicit metadata without fetching sources or inferring truth."""
    findings: list[QualityFinding] = []
    publication_bound = value.publication_state in _PUBLICATION_BOUND
    missing_severity = "blocker" if publication_bound else "warning"

    def add(code: str, field: str, severity: str = missing_severity) -> None:
        findings.append(QualityFinding(code, field, severity))

    if not value.claim_text.strip():
        add("claim-text-missing", "claim_text")
    if not value.analysis_text.strip():
        add("analysis-text-missing", "analysis_text")
    if not value.evidence and not value.official_source_url.strip():
        add("source-evidence-missing", "evidence")
    if publication_bound and not (value.origin_url.strip() or value.origin_locator.strip()):
        add("claim-origin-missing", "origin")
    if publication_bound and not value.limitations.strip():
        add("limitations-missing", "limitations")
    if publication_bound and not any(item.strip() for item in value.reviewer_ids):
        add("reviewer-missing", "reviewer_ids")
    if value.publication_state == "published" and value.translation_state == "machine":
        add("machine-translation-unreviewed", "translation_state", "blocker")

    if any(item.severity == "blocker" for item in findings):
        state = "blocked"
    elif findings:
        state = "attention"
    else:
        state = "ready"
    return QualityEvaluation(state, tuple(findings))
