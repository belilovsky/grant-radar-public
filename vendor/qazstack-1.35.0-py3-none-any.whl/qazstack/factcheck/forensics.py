"""Stable provenance contracts for product-owned forensic analysis runs."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from qazstack.contracts._validation import (
    require_aware,
    require_identifier,
    require_one_of,
    require_positive,
    require_ratio,
    require_sha256,
    require_text,
)

FORENSIC_STATUSES = frozenset({"pending", "completed", "failed", "unavailable"})


@dataclass(frozen=True, slots=True)
class AnalysisProvenance:
    provider: str
    model: str
    model_version: str
    generated_at: datetime
    input_digest: str

    def __post_init__(self) -> None:
        object.__setattr__(self, "provider", require_identifier(self.provider, "provider"))
        object.__setattr__(self, "model", require_text(self.model, "model"))
        object.__setattr__(self, "model_version", require_text(self.model_version, "model_version"))
        require_aware(self.generated_at, "generated_at")
        object.__setattr__(self, "input_digest", require_sha256(self.input_digest, "input_digest"))


@dataclass(frozen=True, slots=True)
class ForensicSignal:
    code: str
    value: str
    confidence: float | None = None
    explanation: str = ""

    def __post_init__(self) -> None:
        object.__setattr__(self, "code", require_identifier(self.code, "code"))
        object.__setattr__(self, "value", require_text(self.value, "value"))
        if self.confidence is not None:
            require_ratio(self.confidence, "confidence")


@dataclass(frozen=True, slots=True)
class ForensicArtifact:
    artifact_id: str
    media_type: str
    digest: str
    reference: str

    def __post_init__(self) -> None:
        object.__setattr__(self, "artifact_id", require_identifier(self.artifact_id, "artifact_id"))
        object.__setattr__(self, "media_type", require_text(self.media_type, "media_type"))
        object.__setattr__(self, "digest", require_sha256(self.digest))
        object.__setattr__(self, "reference", require_text(self.reference, "reference"))


@dataclass(frozen=True, slots=True)
class ForensicRunRecord:
    run_id: str
    analysis_type: str
    status: str
    requested_at: datetime
    completed_at: datetime | None = None
    latency_ms: int | None = None
    provenance: AnalysisProvenance | None = None
    signals: tuple[ForensicSignal, ...] = ()
    artifacts: tuple[ForensicArtifact, ...] = ()
    error_code: str = ""

    def __post_init__(self) -> None:
        object.__setattr__(self, "run_id", require_identifier(self.run_id, "run_id"))
        object.__setattr__(self, "analysis_type", require_identifier(self.analysis_type, "analysis_type"))
        require_one_of(self.status, FORENSIC_STATUSES, "status")
        require_aware(self.requested_at, "requested_at")
        if self.completed_at is not None:
            require_aware(self.completed_at, "completed_at")
            if self.completed_at < self.requested_at:
                raise ValueError("completed_at must not precede requested_at")
        if self.latency_ms is not None:
            require_positive(self.latency_ms, "latency_ms", allow_zero=True)

        if self.status == "pending":
            terminal_values = (
                self.completed_at,
                self.latency_ms,
                self.provenance,
                self.signals,
                self.artifacts,
                self.error_code,
            )
            if any(value is not None and value != () and value != "" for value in terminal_values):
                raise ValueError("pending forensic run must not include terminal metadata")
        elif self.status == "completed":
            if self.completed_at is None or self.provenance is None:
                raise ValueError("completed forensic run requires completed_at and provenance")
            if self.error_code:
                raise ValueError("completed forensic run must not include error_code")
        else:
            if self.completed_at is None or not self.error_code:
                raise ValueError("terminal unsuccessful run requires completed_at and error_code")
            if self.signals or self.artifacts:
                raise ValueError("terminal unsuccessful run must not expose successful outputs")
