"""Traceable claim and evidence contracts shared by fact-checking products."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from qazstack.contracts._validation import (
    require_aware,
    require_http_url,
    require_identifier,
    require_one_of,
    require_sha256,
    require_text,
)

EVIDENCE_RELATIONS = frozenset({"supports", "refutes", "context", "unknown"})
EVIDENCE_SOURCE_TYPES = frozenset({"primary", "official", "dataset", "media", "witness", "archive", "secondary"})
EVIDENCE_CAPTURE_STATUSES = frozenset({"pending", "completed", "failed", "unavailable"})
EVIDENCE_FRESHNESS_STATUSES = frozenset({"current", "stale", "unknown", "not-applicable"})


@dataclass(frozen=True, slots=True)
class AtomicClaim:
    """One independently verifiable statement and its original location."""

    claim_id: str
    text: str
    language: str
    source_url: str = ""
    source_locator: str = ""
    author: str = ""
    published_at: datetime | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "claim_id", require_identifier(self.claim_id, "claim_id"))
        object.__setattr__(self, "text", require_text(self.text, "text"))
        object.__setattr__(self, "language", require_identifier(self.language, "language"))
        if self.source_url:
            object.__setattr__(self, "source_url", require_http_url(self.source_url, "source_url"))
        if self.published_at is not None:
            require_aware(self.published_at, "published_at")


@dataclass(frozen=True, slots=True)
class EvidenceReference:
    """A source reference and its explicit relation to a claim."""

    evidence_id: str
    title: str
    url: str
    source_type: str
    relation: str = "unknown"
    note: str = ""
    captured_at: datetime | None = None
    digest: str = ""
    claim_ids: tuple[str, ...] = ()
    capture_status: str = "unavailable"
    freshness_status: str = "unknown"
    published_at: datetime | None = None
    archive_ref: str = ""
    retention_class: str = ""
    provider: str = ""

    def __post_init__(self) -> None:
        object.__setattr__(self, "evidence_id", require_identifier(self.evidence_id, "evidence_id"))
        object.__setattr__(self, "title", require_text(self.title, "title"))
        object.__setattr__(self, "url", require_http_url(self.url, "url"))
        require_one_of(self.source_type, EVIDENCE_SOURCE_TYPES, "source_type")
        require_one_of(self.relation, EVIDENCE_RELATIONS, "relation")
        require_one_of(self.capture_status, EVIDENCE_CAPTURE_STATUSES, "capture_status")
        require_one_of(self.freshness_status, EVIDENCE_FRESHNESS_STATUSES, "freshness_status")
        if self.captured_at is not None:
            require_aware(self.captured_at, "captured_at")
        if self.published_at is not None:
            require_aware(self.published_at, "published_at")
        if self.digest:
            object.__setattr__(self, "digest", require_sha256(self.digest))
        if len(set(self.claim_ids)) != len(self.claim_ids):
            raise ValueError("claim_ids must not contain duplicates")
        for claim_id in self.claim_ids:
            require_identifier(claim_id, "claim_ids")
        if self.capture_status == "completed":
            if self.captured_at is None or not self.digest or not self.archive_ref:
                raise ValueError("completed evidence requires captured_at, digest and archive_ref")
            require_text(self.retention_class, "retention_class")
            require_text(self.provider, "provider")
