"""Admin panel setup using sqladmin.

Provides a preconfigured admin panel with:
- Platform branding (title, logo)
- Session-based authentication
- Sensible defaults for list/detail views

Requires: pip install qazstack[admin]
"""

from __future__ import annotations

from typing import Any, Sequence, Type

from fastapi import FastAPI

try:
    from sqladmin import Admin, ModelView
    from sqladmin.authentication import AuthenticationBackend
    from starlette.requests import Request

    HAS_SQLADMIN = True
except ImportError:
    HAS_SQLADMIN = False
    Admin = None  # type: ignore
    ModelView = object  # type: ignore
    AuthenticationBackend = object  # type: ignore


class ModelAdmin(ModelView if HAS_SQLADMIN else object):
    """Base model admin with platform defaults.

    Subclass for each model:

        class ArticleAdmin(ModelAdmin, model=Article):
            column_list = [Article.id, Article.title, Article.pub_date]
            column_searchable_list = [Article.title]
            page_size = 25
    """

    page_size = 25
    page_size_options = [10, 25, 50, 100]
    can_create = True
    can_edit = True
    can_delete = True
    can_export = True


class AdminAuth(AuthenticationBackend if HAS_SQLADMIN else object):
    """Simple session-based admin auth.

    Checks request.session for a logged-in user with admin role.
    Works with qazstack.auth.SessionAuth.
    """

    def __init__(
        self,
        secret_key: str,
        *,
        admin_username: str = "admin",
        admin_password: str = "",
        session_key: str = "user",
    ):
        if HAS_SQLADMIN:
            super().__init__(secret_key)
        self._admin_username = admin_username
        self._admin_password = admin_password
        self._session_key = session_key

    async def login(self, request: Request) -> bool:
        """Handle admin login form."""
        form = await request.form()
        username = form.get("username", "")
        password = form.get("password", "")

        if username == self._admin_username and password == self._admin_password:
            request.session["admin_authenticated"] = True
            request.session["admin_user"] = username
            return True
        return False

    async def logout(self, request: Request) -> bool:
        """Handle admin logout."""
        request.session.pop("admin_authenticated", None)
        request.session.pop("admin_user", None)
        return True

    async def authenticate(self, request: Request) -> bool:
        """Check if admin is authenticated."""
        return request.session.get("admin_authenticated", False)


def setup_admin(
    app: FastAPI,
    *,
    engine: Any,
    views: Sequence[Type[ModelAdmin]] | None = None,
    title: str = "Admin Panel",
    auth_secret: str = "",
    admin_username: str = "admin",
    admin_password: str = "",
    base_url: str = "/admin",
    templates_dir: str | None = None,
) -> Any:
    """Setup sqladmin on a FastAPI app.

    Args:
        app: FastAPI application.
        engine: SQLAlchemy async engine (db.engine).
        views: List of ModelAdmin subclasses to register.
        title: Admin panel title shown in header.
        auth_secret: Secret key for admin session cookie.
        admin_username: Admin login username.
        admin_password: Admin login password.
        base_url: URL prefix for admin panel.
        templates_dir: Custom templates directory (optional).

    Returns:
        Admin instance (or None if sqladmin not installed).

    Example:
        setup_admin(
            app,
            engine=db.engine,
            views=[ArticleAdmin, CategoryAdmin],
            title="Total.KZ Admin",
            auth_secret=settings.secret_key,
            admin_username="admin",
            admin_password=settings.admin_password,
        )
    """
    if not HAS_SQLADMIN:
        import warnings

        warnings.warn(
            "sqladmin is not installed. Install with: pip install qazstack[admin]",
            stacklevel=2,
        )
        return None

    # Auth backend (optional – if no password, no auth)
    auth_backend = None
    if admin_password:
        auth_backend = AdminAuth(
            secret_key=auth_secret or "change-me",
            admin_username=admin_username,
            admin_password=admin_password,
        )

    admin_kwargs: dict[str, Any] = {
        "title": title,
        "base_url": base_url,
        "authentication_backend": auth_backend,
    }
    if templates_dir is not None:
        admin_kwargs["templates_dir"] = templates_dir

    admin = Admin(
        app,
        engine,
        **admin_kwargs,
    )

    # Register views
    if views:
        for view_class in views:
            admin.add_view(view_class)

    return admin
