"""Provider-neutral notification and delivery contracts."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from qazstack.contracts._validation import require_aware, require_identifier, require_one_of, require_text


@dataclass(frozen=True, slots=True)
class NotificationEnvelope:
    notification_id: str
    subject: str
    body: str
    severity: str
    channels: tuple[str, ...]
    deduplication_key: str
    created_at: datetime
    quiet: bool = False

    def __post_init__(self) -> None:
        require_identifier(self.notification_id, "notification_id")
        require_text(self.subject, "subject")
        require_text(self.body, "body")
        require_one_of(self.severity, frozenset({"info", "warning", "error", "critical"}), "severity")
        if not self.channels or any(not channel.strip() for channel in self.channels):
            raise ValueError("channels must contain non-empty values")
        require_text(self.deduplication_key, "deduplication_key")
        require_aware(self.created_at, "created_at")


@dataclass(frozen=True, slots=True)
class DeliveryResult:
    notification_id: str
    channel: str
    status: str
    attempted_at: datetime
    provider_message_id: str | None = None
    retry_after_seconds: int | None = None

    def __post_init__(self) -> None:
        require_identifier(self.notification_id, "notification_id")
        require_text(self.channel, "channel")
        require_one_of(self.status, frozenset({"sent", "suppressed", "failed", "retry"}), "status")
        require_aware(self.attempted_at, "attempted_at")
        if self.status == "sent" and not (self.provider_message_id or "").strip():
            raise ValueError("sent results require provider_message_id")
        if self.status == "retry" and (self.retry_after_seconds is None or self.retry_after_seconds <= 0):
            raise ValueError("retry results require a positive retry_after_seconds")
