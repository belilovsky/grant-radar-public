"""Neutral opportunity records and source declarations.

The package carries portable metadata only. A product retains ownership of
relevance scoring, legal interpretation, source adapters, scheduling and every
decision to display, alert on or archive an opportunity.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from datetime import date
from math import isfinite
from typing import Any

from qazstack.contracts._validation import require_http_url, require_identifier, require_text


def _normalized_tags(values: Sequence[str], *, field_name: str) -> tuple[str, ...]:
    if isinstance(values, (str, bytes)):
        raise ValueError(f"{field_name} must be a sequence of strings")
    normalized = tuple(require_text(value, field_name) for value in values)
    if len(set(normalized)) != len(normalized):
        raise ValueError(f"{field_name} must not contain duplicates")
    return normalized


@dataclass(frozen=True, slots=True)
class OpportunityRecord:
    """Minimal, product-neutral opportunity metadata for shared adapters."""

    source: str
    title: str
    summary: str = ""
    description: str = ""
    source_url: str | None = None
    funder: str | None = None
    eligibility: Sequence[str] = field(default_factory=tuple)
    languages: Sequence[str] = field(default_factory=tuple)
    tags: Sequence[str] = field(default_factory=tuple)
    deadline: date | None = None
    raw: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Validate stable identifiers while leaving product content untouched."""

        require_identifier(self.source, "source")
        require_text(self.title, "title")
        if self.source_url is not None:
            require_http_url(self.source_url, "source_url")
        for field_name in ("summary", "description"):
            value = getattr(self, field_name)
            if not isinstance(value, str):
                raise ValueError(f"{field_name} must be a string")
        if self.funder is not None:
            require_text(self.funder, "funder")
        object.__setattr__(self, "eligibility", _normalized_tags(self.eligibility, field_name="eligibility"))
        object.__setattr__(self, "languages", _normalized_tags(self.languages, field_name="languages"))
        object.__setattr__(self, "tags", _normalized_tags(self.tags, field_name="tags"))
        if not isinstance(self.raw, Mapping):
            raise ValueError("raw must be a mapping")


@dataclass(frozen=True, slots=True)
class SourceContract:
    """Public metadata for a product-owned opportunity source adapter."""

    slug: str
    name: str
    base_url: str
    request_delay: float = 1.0
    default_tags: Sequence[str] = field(default_factory=tuple)

    def __post_init__(self) -> None:
        """Reject ambiguous public source metadata before an adapter is registered."""

        self.validate()
        object.__setattr__(self, "default_tags", _normalized_tags(self.default_tags, field_name="default_tags"))

    def validate(self) -> None:
        """Raise ``ValueError`` when the source declaration is not usable."""

        require_identifier(self.slug, "slug")
        require_text(self.name, "name")
        require_http_url(self.base_url, "base_url")
        if (
            not isinstance(self.request_delay, (int, float))
            or isinstance(self.request_delay, bool)
            or not isfinite(self.request_delay)
        ):
            raise ValueError("request_delay must be a number")
        if self.request_delay < 0:
            raise ValueError("request_delay must be non-negative")
