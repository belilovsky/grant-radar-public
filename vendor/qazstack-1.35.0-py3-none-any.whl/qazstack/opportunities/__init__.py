"""Portable contracts for opportunity-radar consumers."""

from qazstack.opportunities.contracts import OpportunityRecord, SourceContract

__all__ = ["OpportunityRecord", "SourceContract"]
