"""Audit data models."""

from __future__ import annotations

import enum
from dataclasses import dataclass, field
from typing import ClassVar


class Severity(str, enum.Enum):
    """Severity level for a check result."""

    ERROR = "error"
    WARNING = "warning"
    INFO = "info"
    PASS = "pass"


class CheckStatus(enum.Enum):
    """Status of a single check."""

    PASSED = "passed"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class CheckResult:
    """Result of a single audit check."""

    name: str
    status: CheckStatus
    severity: Severity = Severity.INFO
    message: str = ""
    details: list[str] = field(default_factory=list)
    category: str = ""
    fixable: bool = False
    file: str | None = None
    fix_hint: str | None = None

    @property
    def passed(self) -> bool:
        return self.status == CheckStatus.PASSED

    @property
    def failed(self) -> bool:
        return self.status == CheckStatus.FAILED

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "status": self.status.value,
            "severity": self.severity.value,
            "message": self.message,
            "details": self.details,
            "category": self.category,
            "fixable": self.fixable,
            "file": self.file,
            "fix_hint": self.fix_hint,
        }


@dataclass
class AuditReport:
    """Aggregate report from a full audit run."""

    results: list[CheckResult] = field(default_factory=list)
    project_path: str = ""

    @property
    def total(self) -> int:
        return len(self.results)

    @property
    def passed(self) -> int:
        return sum(1 for r in self.results if r.passed)

    @property
    def failed(self) -> int:
        return sum(1 for r in self.results if r.failed)

    @property
    def skipped(self) -> int:
        return sum(1 for r in self.results if r.status == CheckStatus.SKIPPED)

    @property
    def errors(self) -> list[CheckResult]:
        return [r for r in self.results if r.failed and r.severity == Severity.ERROR]

    @property
    def warnings(self) -> list[CheckResult]:
        return [r for r in self.results if r.failed and r.severity == Severity.WARNING]

    # Weights for failed checks by severity.  A failed ERROR costs 3×
    # as much as a passed check;  WARNING costs 2×;  INFO costs 1×.
    _FAIL_WEIGHT: ClassVar[dict[Severity, float]] = {
        Severity.ERROR: 3.0,
        Severity.WARNING: 2.0,
        Severity.INFO: 1.0,
        Severity.PASS: 1.0,
    }

    @property
    def score(self) -> float:
        """Weighted compliance score 0-100.

        Each checkable result has a weight: passed checks add 1 point,
        failed checks subtract proportionally to severity (ERROR=3, WARNING=2, INFO=1).
        The score is the ratio of earned points to maximum possible points.
        """
        if not self.results:
            return 100.0
        checkable = [r for r in self.results if r.status != CheckStatus.SKIPPED]
        if not checkable:
            return 100.0

        max_points = 0.0
        earned = 0.0
        for r in checkable:
            w = self._FAIL_WEIGHT.get(r.severity, 1.0)
            max_points += w
            if r.passed:
                earned += w
        if max_points == 0:
            return 100.0
        return round(earned / max_points * 100, 1)

    def by_category(self) -> dict[str, list[CheckResult]]:
        cats: dict[str, list[CheckResult]] = {}
        for r in self.results:
            cats.setdefault(r.category, []).append(r)
        return cats

    def to_dict(self) -> dict:
        return {
            "project_path": self.project_path,
            "total": self.total,
            "passed": self.passed,
            "failed": self.failed,
            "skipped": self.skipped,
            "score": self.score,
            "results": [r.to_dict() for r in self.results],
        }
