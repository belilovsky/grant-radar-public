"""Deterministic integrity manifests for nested static assets."""

from __future__ import annotations

import json
import re
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import asdict, dataclass
from pathlib import Path, PurePosixPath
from typing import Any

from qazstack.compute.artifacts import file_sha256

ASSET_MANIFEST_SCHEMA = "qazstack-static-assets-v1"
_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")


class AssetManifestError(ValueError):
    """Raised when a static-asset manifest or its files cannot be trusted."""


def _asset_name(value: str) -> str:
    if not value or "\\" in value:
        raise ValueError("asset path must be a non-empty POSIX relative path")
    path = PurePosixPath(value)
    if path.is_absolute() or any(part in {"", ".", ".."} for part in path.parts):
        raise ValueError("asset path must stay within the manifest root")
    normalized = path.as_posix()
    if normalized != value:
        raise ValueError("asset path must be normalized")
    return normalized


@dataclass(frozen=True, slots=True)
class AssetDigest:
    path: str
    size_bytes: int
    sha256: str

    def __post_init__(self) -> None:
        object.__setattr__(self, "path", _asset_name(self.path))
        if self.size_bytes < 0:
            raise ValueError("asset size must not be negative")
        if not _SHA256_RE.fullmatch(self.sha256):
            raise ValueError("asset sha256 must be a lowercase hex digest")


@dataclass(frozen=True, slots=True)
class AssetManifest:
    files: tuple[AssetDigest, ...]
    schema_version: str = ASSET_MANIFEST_SCHEMA

    def __post_init__(self) -> None:
        if self.schema_version != ASSET_MANIFEST_SCHEMA:
            raise ValueError(f"schema_version must be {ASSET_MANIFEST_SCHEMA}")
        paths = [item.path for item in self.files]
        if paths != sorted(paths):
            raise ValueError("asset paths must use deterministic sorted order")
        if len(paths) != len(set(paths)):
            raise ValueError("asset paths must be unique")

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> "AssetManifest":
        try:
            raw_files = value["files"]
            if not isinstance(raw_files, Sequence) or isinstance(raw_files, (str, bytes)):
                raise TypeError("files must be an array")
            return cls(
                schema_version=str(value["schema_version"]),
                files=tuple(AssetDigest(**dict(item)) for item in raw_files),
            )
        except (KeyError, TypeError, ValueError) as exc:
            raise AssetManifestError(f"invalid static-asset manifest: {exc}") from exc

    def as_dict(self) -> dict[str, object]:
        return {
            "schema_version": self.schema_version,
            "files": [asdict(item) for item in self.files],
        }


def _asset_file(root: Path, relative_path: str) -> Path:
    root_resolved = root.resolve()
    candidate = (root_resolved / _asset_name(relative_path)).resolve()
    if not candidate.is_relative_to(root_resolved):
        raise AssetManifestError(f"asset escapes manifest root: {relative_path}")
    return candidate


def describe_asset(root: Path, relative_path: str) -> AssetDigest:
    """Describe one nested asset without allowing traversal outside ``root``."""
    path = _asset_file(root, relative_path)
    try:
        size_bytes = path.stat().st_size
    except OSError as exc:
        raise AssetManifestError(f"asset is unavailable: {relative_path}") from exc
    if not path.is_file():
        raise AssetManifestError(f"asset is not a regular file: {relative_path}")
    return AssetDigest(path=relative_path, size_bytes=size_bytes, sha256=file_sha256(path))


def build_asset_manifest(root: Path, relative_paths: Iterable[str]) -> AssetManifest:
    """Build a stable manifest for an explicit set of consumer-owned files."""
    paths = sorted(_asset_name(value) for value in relative_paths)
    if len(paths) != len(set(paths)):
        raise AssetManifestError("asset paths must be unique")
    return AssetManifest(files=tuple(describe_asset(root, path) for path in paths))


def load_asset_manifest(path: Path) -> AssetManifest:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise AssetManifestError(f"cannot read static-asset manifest: {exc}") from exc
    if not isinstance(payload, Mapping):
        raise AssetManifestError("static-asset manifest must be an object")
    return AssetManifest.from_mapping(payload)


def verify_asset_manifest(root: Path, manifest: AssetManifest) -> None:
    """Fail closed when a declared asset is missing, resized or modified."""
    for expected in manifest.files:
        actual = describe_asset(root, expected.path)
        if actual.size_bytes != expected.size_bytes:
            raise AssetManifestError(f"asset size mismatch: {expected.path}")
        if actual.sha256 != expected.sha256:
            raise AssetManifestError(f"asset checksum mismatch: {expected.path}")


__all__ = [
    "ASSET_MANIFEST_SCHEMA",
    "AssetDigest",
    "AssetManifest",
    "AssetManifestError",
    "build_asset_manifest",
    "describe_asset",
    "load_asset_manifest",
    "verify_asset_manifest",
]
