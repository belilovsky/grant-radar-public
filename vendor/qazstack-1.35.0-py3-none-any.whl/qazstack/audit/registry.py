"""Checker registry – discovers and holds all checker instances."""

from __future__ import annotations

from qazstack.audit.base import BaseChecker


class CheckerRegistry:
    """Registry for audit checkers."""

    def __init__(self) -> None:
        self._checkers: list[BaseChecker] = []

    def register(self, checker: BaseChecker) -> None:
        """Register a single checker instance."""
        self._checkers.append(checker)

    def get_all(self) -> list[BaseChecker]:
        return list(self._checkers)

    def get_by_category(self, category: str) -> list[BaseChecker]:
        return [c for c in self._checkers if c.category == category]

    @property
    def categories(self) -> list[str]:
        seen: dict[str, None] = {}
        for c in self._checkers:
            seen.setdefault(c.category, None)
        return list(seen.keys())

    def auto_discover(self) -> None:
        """Register all built-in checkers."""
        from qazstack.audit.checkers.code import (
            RuffLintChecker,
            DeadImportsChecker,
            PlatformStandardChecker,
            VendoredCodeChecker,
        )
        from qazstack.audit.checkers.infra import (
            DockerfileChecker,
            DockerComposeChecker,
            EnvFileChecker,
            NginxChecker,
            GitignoreChecker,
        )
        from qazstack.audit.checkers.deps import (
            QazStackVersionChecker,
            QazStackUsageChecker,
            PythonVersionChecker,
            UnusedDepsChecker,
        )
        from qazstack.audit.checkers.ui_seo import (
            CSSTokensChecker,
            MetaTagsChecker,
            SitemapChecker,
            RobotsTxtChecker,
            AccessibilityChecker,
        )
        from qazstack.audit.checkers.security import (
            HardcodedSecretsChecker,
            OpenPortsChecker,
            DocsUrlChecker,
            DebugModeChecker,
        )

        for cls in [
            # Code
            RuffLintChecker,
            DeadImportsChecker,
            PlatformStandardChecker,
            VendoredCodeChecker,
            # Infra
            DockerfileChecker,
            DockerComposeChecker,
            EnvFileChecker,
            NginxChecker,
            GitignoreChecker,
            # Deps
            QazStackVersionChecker,
            QazStackUsageChecker,
            PythonVersionChecker,
            UnusedDepsChecker,
            # UI/SEO
            CSSTokensChecker,
            MetaTagsChecker,
            SitemapChecker,
            RobotsTxtChecker,
            AccessibilityChecker,
            # Security
            HardcodedSecretsChecker,
            OpenPortsChecker,
            DocsUrlChecker,
            DebugModeChecker,
        ]:
            self.register(cls())
