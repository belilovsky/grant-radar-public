"""Audit runner – orchestrates checker execution and produces reports."""

from __future__ import annotations

import json
from pathlib import Path

from qazstack.audit.models import AuditReport, CheckResult, CheckStatus, Severity
from qazstack.audit.registry import CheckerRegistry

# ANSI escape codes – zero external deps.
_RESET = "\033[0m"
_BOLD = "\033[1m"
_DIM = "\033[2m"
_RED = "\033[31m"
_GREEN = "\033[32m"
_YELLOW = "\033[33m"
_CYAN = "\033[36m"

_CATEGORY_LABELS: dict[str, str] = {
    "code": "\U0001f4cb Код",
    "infra": "\U0001f3d7\ufe0f  Инфраструктура",
    "deps": "\U0001f4e6 Зависимости",
    "ui_seo": "\U0001f3a8 UI / SEO",
    "security": "\U0001f512 Безопасность",
}


class AuditRunner:
    """Runs registered checkers against a project directory."""

    def __init__(self, registry: CheckerRegistry) -> None:
        self.registry = registry

    def run(
        self,
        project_path: Path,
        *,
        categories: list[str] | None = None,
    ) -> AuditReport:
        """Run all (or filtered) checkers and return an AuditReport."""
        report = AuditReport(project_path=str(project_path))

        checkers = self.registry.get_all()
        if categories:
            checkers = [c for c in checkers if c.category in categories]

        for checker in checkers:
            try:
                results = checker.run(project_path)
                report.results.extend(results)
            except Exception as exc:
                report.results.append(
                    CheckResult(
                        name=f"{checker.name}:crash",
                        status=CheckStatus.FAILED,
                        severity=Severity.ERROR,
                        message=f"Checker crashed: {exc}",
                        category=checker.category,
                    )
                )

        return report

    def run_fix(self, project_path: Path, *, categories: list[str] | None = None) -> list[str]:
        """Run auto-fix on all checkers that support it.

        Returns list of human-readable fix descriptions.
        """
        fixes: list[str] = []
        checkers = self.registry.get_all()
        if categories:
            checkers = [c for c in checkers if c.category in categories]

        for checker in checkers:
            try:
                checker_fixes = checker.fix(project_path)
                for desc in checker_fixes:
                    fixes.append(f"[{checker.name}] {desc}")
            except Exception as exc:
                fixes.append(f"[{checker.name}] fix failed: {exc}")

        return fixes

    @staticmethod
    def format_text(report: AuditReport) -> str:
        """Pretty terminal output with ANSI colors and box-drawing."""
        project_name = Path(report.project_path).name
        lines: list[str] = []

        # Header box
        title = f"  QazStack Audit \u2013 {project_name}  "
        width = max(len(title) + 4, 40)
        horizontal_rule = "\u2550" * width
        lines.append(f"{_BOLD}{_CYAN}\u2554{horizontal_rule}\u2557{_RESET}")
        lines.append(f"{_BOLD}{_CYAN}\u2551{title:^{width}}\u2551{_RESET}")
        lines.append(f"{_BOLD}{_CYAN}\u255a{horizontal_rule}\u255d{_RESET}")
        lines.append("")

        # Group by category
        for category, results in report.by_category().items():
            label = _CATEGORY_LABELS.get(category, category)
            lines.append(f"{_BOLD}{label} ({len(results)} checks){_RESET}")

            for r in results:
                if r.status == CheckStatus.PASSED:
                    icon = "\u2705"
                    color = _GREEN
                elif r.status == CheckStatus.SKIPPED:
                    icon = "\u23ed\ufe0f "
                    color = _DIM
                elif r.severity == Severity.WARNING:
                    icon = "\u26a0\ufe0f "
                    color = _YELLOW
                else:
                    icon = "\u274c"
                    color = _RED

                line = f"  {icon} {color}{r.name}{_RESET}"
                if r.message:
                    line += f" \u2013 {r.message}"
                lines.append(line)

                for d in r.details[:10]:
                    lines.append(f"     {_DIM}\u2192 {d}{_RESET}")
                if len(r.details) > 10:
                    lines.append(f"     {_DIM}... and {len(r.details) - 10} more{_RESET}")

                if r.fix_hint:
                    lines.append(f"     {_DIM}\U0001f4a1 {r.fix_hint}{_RESET}")

            lines.append("")

        # Summary
        n_passed = report.passed
        n_warnings = len(report.warnings)
        n_errors = len(report.errors)
        score = report.score

        summary = f"{_BOLD}\U0001f4ca Summary: "
        summary += f"{_GREEN}{n_passed} passed{_RESET}"
        if n_warnings:
            summary += f", {_YELLOW}{n_warnings} warnings{_RESET}"
        if n_errors:
            summary += f", {_RED}{n_errors} errors{_RESET}"
        summary += f"  ({score}%)"
        lines.append(summary)

        return "\n".join(lines)

    @staticmethod
    def format_json(report: AuditReport) -> str:
        """Format report as JSON."""
        return json.dumps(report.to_dict(), indent=2, ensure_ascii=False)

    @staticmethod
    def save_report(report: AuditReport, path: str) -> None:
        """Save report to file (JSON)."""
        data = json.dumps(report.to_dict(), indent=2, ensure_ascii=False)
        Path(path).write_text(data, encoding="utf-8")
