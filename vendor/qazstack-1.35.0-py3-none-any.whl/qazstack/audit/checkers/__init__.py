"""Built-in audit checkers – auto-imports for registry discovery."""

from qazstack.audit.checkers.code import (  # noqa: F401
    DeadImportsChecker,
    PlatformStandardChecker,
    RuffLintChecker,
    VendoredCodeChecker,
)
from qazstack.audit.checkers.deps import (  # noqa: F401
    PythonVersionChecker,
    QazStackUsageChecker,
    QazStackVersionChecker,
    UnusedDepsChecker,
)
from qazstack.audit.checkers.infra import (  # noqa: F401
    DockerComposeChecker,
    DockerfileChecker,
    EnvFileChecker,
    GitignoreChecker,
    NginxChecker,
)
from qazstack.audit.checkers.security import (  # noqa: F401
    DebugModeChecker,
    DocsUrlChecker,
    HardcodedSecretsChecker,
    OpenPortsChecker,
)
from qazstack.audit.checkers.ui_seo import (  # noqa: F401
    AccessibilityChecker,
    CSSTokensChecker,
    MetaTagsChecker,
    RobotsTxtChecker,
    SitemapChecker,
)
