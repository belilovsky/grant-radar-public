"""UI & SEO checkers: CSS tokens, meta tags, sitemap, robots.txt, accessibility."""

from __future__ import annotations

import re
from pathlib import Path

from qazstack.audit.base import BaseChecker, is_excluded
from qazstack.audit.models import Severity

# Required CSS custom properties per platform standard.
_REQUIRED_CSS_VARS = [
    "--bg", "--surface", "--text", "--text-secondary", "--accent",
    "--border", "--shadow-sm", "--radius", "--transition",
]

_RECOMMENDED_CSS_VARS = [
    "--text-muted", "--accent-hover", "--border-light",
    "--shadow-md", "--shadow-lg", "--radius-sm", "--radius-lg",
    "--success", "--warning", "--danger",
]


class CSSTokensChecker(BaseChecker):
    """Two-part CSS check:
    1. Verify required CSS custom properties are defined.
    2. Flag hardcoded colors outside :root / variable definitions.
    """

    category = "ui_seo"
    name = "css-tokens"

    _COLOR_RE = re.compile(
        r"(?<!var\()"
        r"(?:"
        r"#[0-9a-fA-F]{3,8}\b"
        r"|rgb\([^)]+\)"
        r"|rgba\([^)]+\)"
        r"|hsl\([^)]+\)"
        r")"
    )
    _VAR_DEF_RE = re.compile(r"^\s*--[\w-]+\s*:")

    def run(self, project_path: Path) -> list:
        from qazstack.audit.models import CheckResult

        results: list[CheckResult] = []

        css_files = [f for f in project_path.rglob("*.css") if not is_excluded(f, project_path)]
        if not css_files:
            # Check if project uses qazstack.ui (setup_ui) – tokens provided by framework
            uses_qs_ui = _uses_qazstack_ui(project_path)
            if uses_qs_ui:
                return [self._make_result("css-tokens", True, message="Using qazstack.ui (tokens from framework)")]
            return [self._make_result("css-tokens", True, message="No CSS files found", skipped=True)]

        all_css = ""
        for f in css_files:
            try:
                all_css += f.read_text(encoding="utf-8", errors="ignore") + "\n"
            except Exception:
                continue

        # ── Part 1: required CSS variables defined ──
        missing_required = [v for v in _REQUIRED_CSS_VARS if v + ":" not in all_css]
        missing_recommended = [v for v in _RECOMMENDED_CSS_VARS if v + ":" not in all_css]

        if not _uses_qazstack_ui(project_path):
            if missing_required:
                results.append(self._make_result(
                    "css-vars-required", False,
                    message=f"{len(missing_required)} required CSS variables missing",
                    details=[f"Missing: {v}" for v in missing_required],
                    severity=Severity.WARNING,
                ))
            else:
                results.append(self._make_result("css-vars-required", True, message="All required CSS variables defined"))

            if missing_recommended:
                results.append(self._make_result(
                    "css-vars-recommended", False,
                    message=f"{len(missing_recommended)} recommended CSS variables missing",
                    details=[f"Missing: {v}" for v in missing_recommended],
                    severity=Severity.INFO,
                ))

        # ── Part 2: hardcoded colors ──
        issues: list[str] = []
        for css_file in css_files:
            try:
                lines = css_file.read_text(encoding="utf-8", errors="ignore").splitlines()
            except Exception:
                continue
            rel = css_file.relative_to(project_path)
            for i, line in enumerate(lines, 1):
                if self._VAR_DEF_RE.match(line):
                    continue
                matches = self._COLOR_RE.findall(line)
                for m in matches:
                    issues.append(f"{rel}:{i}  {m.strip()} \u2192 use CSS variable")

        if issues:
            results.append(self._make_result(
                "css-hardcoded-colors", False,
                message=f"{len(issues)} hardcoded color(s) – use CSS variables",
                details=issues[:15],
                severity=Severity.INFO,
            ))
        else:
            results.append(self._make_result("css-hardcoded-colors", True, message="No hardcoded colors"))

        return results


class MetaTagsChecker(BaseChecker):
    """Check HTML templates for essential meta tags."""

    category = "ui_seo"
    name = "meta-tags"

    _REQUIRED_META: list[tuple[str, str]] = [
        ("viewport", r'<meta\s+name=["\']viewport["\']'),
        ("description", r'<meta\s+name=["\']description["\']|meta_description'),
        ("og:title", r'<meta\s+property=["\']og:title["\']|og_title'),
        ("og:image", r'<meta\s+property=["\']og:image["\']|og_image'),
    ]

    def run(self, project_path: Path) -> list:
        from qazstack.audit.models import CheckResult

        html_files = [f for f in project_path.rglob("*.html") if not is_excluded(f, project_path)]
        if not html_files:
            return [self._make_result("meta-tags", True, message="No HTML templates found", skipped=True)]

        all_content = ""
        for f in html_files:
            try:
                all_content += f.read_text(encoding="utf-8", errors="ignore") + "\n"
            except Exception:
                continue

        missing: list[str] = []
        for name, pattern in self._REQUIRED_META:
            if not re.search(pattern, all_content, re.IGNORECASE):
                missing.append(name)

        if missing:
            return [self._make_result(
                "meta-tags", False,
                message=f"Missing meta tags: {', '.join(missing)}",
                details=[f"Add <meta> for: {m}" for m in missing],
                severity=Severity.WARNING,
            )]
        return [self._make_result("meta-tags", True, message="All essential meta tags present")]


class SitemapChecker(BaseChecker):
    """Check if sitemap.xml exists or is served by the app."""

    category = "ui_seo"
    name = "sitemap"

    def run(self, project_path: Path) -> list:
        from qazstack.audit.models import CheckResult

        # Check common static locations: root, static/, app/static/
        for candidate in [
            project_path / "static" / "sitemap.xml",
            project_path / "app" / "static" / "sitemap.xml",
            project_path / "sitemap.xml",
        ]:
            if candidate.exists():
                return [self._make_result("sitemap", True, message=f"sitemap.xml found ({candidate.relative_to(project_path)})")]

        for py_file in project_path.rglob("*.py"):
            if is_excluded(py_file, project_path):
                continue
            try:
                content = py_file.read_text(encoding="utf-8", errors="ignore")
                if "sitemap" in content.lower() and ("@" in content or "route" in content.lower()):
                    return [self._make_result("sitemap", True, message="Sitemap route detected")]
            except Exception:
                continue

        return [self._make_result(
            "sitemap", False, message="No sitemap.xml found", severity=Severity.INFO,
            fix_hint="Add sitemap.xml or a /sitemap.xml route for SEO",
        )]


class RobotsTxtChecker(BaseChecker):
    """Check if robots.txt exists."""

    category = "ui_seo"
    name = "robots-txt"

    def run(self, project_path: Path) -> list:
        from qazstack.audit.models import CheckResult

        for candidate in [
            project_path / "static" / "robots.txt",
            project_path / "app" / "static" / "robots.txt",
            project_path / "robots.txt",
        ]:
            if candidate.exists():
                return [self._make_result("robots-txt", True, message=f"robots.txt found ({candidate.relative_to(project_path)})")]

        for py_file in project_path.rglob("*.py"):
            if is_excluded(py_file, project_path):
                continue
            try:
                if "robots" in py_file.read_text(encoding="utf-8", errors="ignore").lower():
                    return [self._make_result("robots-txt", True, message="robots.txt route detected")]
            except Exception:
                continue

        return [self._make_result("robots-txt", False, message="No robots.txt found", severity=Severity.INFO)]


class AccessibilityChecker(BaseChecker):
    """Basic accessibility checks on HTML templates."""

    category = "ui_seo"
    name = "accessibility"

    def run(self, project_path: Path) -> list:
        from qazstack.audit.models import CheckResult

        html_files = [f for f in project_path.rglob("*.html") if not is_excluded(f, project_path)]
        if not html_files:
            return [self._make_result("accessibility", True, message="No HTML templates found", skipped=True)]

        issues: list[str] = []
        for f in html_files:
            try:
                content = f.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue
            rel = f.relative_to(project_path)

            imgs_no_alt = re.findall(r"<img\b(?![^>]*\balt\s*=)[^>]*>", content, re.IGNORECASE)
            if imgs_no_alt:
                issues.append(f"{rel}: {len(imgs_no_alt)} <img> without alt attribute")

            buttons_no_aria = re.findall(
                r"<button\b(?![^>]*\baria-label)[^>]*>\s*<(?:i|svg|img)\b",
                content, re.IGNORECASE,
            )
            if buttons_no_aria:
                issues.append(f"{rel}: {len(buttons_no_aria)} <button> without aria-label (icon-only)")

        if issues:
            return [self._make_result(
                "accessibility", False,
                message=f"{len(issues)} accessibility issue(s)",
                details=issues[:15],
                severity=Severity.WARNING,
            )]
        return [self._make_result("accessibility", True, message="No accessibility issues detected")]


# Removed SEOFilesChecker – it was duplicating SitemapChecker + RobotsTxtChecker.
# The individual checkers now cover all file existence checks.


# ── Helpers ──────────────────────────────────────────────────────────────────


def _uses_qazstack_ui(project_path: Path) -> bool:
    """Return True if the project calls setup_ui() or imports qazstack.ui."""
    for py_file in project_path.rglob("*.py"):
        if is_excluded(py_file, project_path):
            continue
        try:
            content = py_file.read_text(encoding="utf-8", errors="ignore")
            if "setup_ui" in content or "qazstack.ui" in content:
                return True
        except Exception:
            continue
    return False
