"""Base checker protocol and shared utilities."""

from __future__ import annotations

import abc
from pathlib import Path

from qazstack.audit.models import CheckResult, CheckStatus, Severity

# Directories to always skip during analysis.
EXCLUDED_DIRS = frozenset({
    "__pycache__", ".git", "node_modules", ".venv", "venv",
    "migrations", "alembic", ".mypy_cache", ".pytest_cache", ".ruff_cache",
    "dist", "build", "*.egg-info",
})


def is_excluded(path: Path, root: Path) -> bool:
    """Check if *path* falls inside an excluded directory relative to *root*."""
    parts = set(path.parts)
    return bool(parts & EXCLUDED_DIRS)


class BaseChecker(abc.ABC):
    """Abstract base for all audit checkers.

    Every checker must define:
        - category (str): e.g. "code", "infra", "deps", "ui_seo", "security"
        - name (str): human-readable checker name
        - run(project_path) -> list[CheckResult]

    Optionally:
        - fix(project_path) -> list[str]: auto-fix issues, return descriptions
    """

    category: str = ""
    name: str = ""

    @abc.abstractmethod
    def run(self, project_path: Path) -> list[CheckResult]:
        """Run all checks in this checker and return results."""
        ...

    def fix(self, project_path: Path) -> list[str]:
        """Auto-fix issues. Returns list of fix descriptions. Override in subclasses."""
        return []

    def _make_result(
        self,
        name: str,
        passed: bool,
        message: str = "",
        details: list[str] | None = None,
        severity: Severity | None = None,
        fixable: bool = False,
        skipped: bool = False,
        fix_hint: str | None = None,
    ) -> CheckResult:
        """Helper to create CheckResult with correct category."""
        if skipped:
            status = CheckStatus.SKIPPED
        else:
            status = CheckStatus.PASSED if passed else CheckStatus.FAILED

        return CheckResult(
            name=name,
            status=status,
            severity=severity or (Severity.INFO if passed else Severity.WARNING),
            message=message,
            details=details or [],
            category=self.category,
            fixable=fixable,
            fix_hint=fix_hint,
        )
