"""SGEO – Spatial/Geo intelligence tools for SEO and content monitoring.

Components:
- GeoSERP: Monitor search engine rankings from different countries
- GeoFetcher: Fetch web content from specific geolocations
- SiteVerifier: Verify site accessibility across countries
"""

from qazstack.proxy.sgeo.serp import GeoSERP, SERPQuery, SERPResult, SERPItem, SearchEngine
from qazstack.proxy.sgeo.fetcher import GeoFetcher, GeoResponse, GeoDiff
from qazstack.proxy.sgeo.verifier import SiteVerifier, VerifyResult, SiteReport

__all__ = [
    "GeoSERP",
    "SERPQuery",
    "SERPResult",
    "SERPItem",
    "SearchEngine",
    "GeoFetcher",
    "GeoResponse",
    "GeoDiff",
    "SiteVerifier",
    "VerifyResult",
    "SiteReport",
]
