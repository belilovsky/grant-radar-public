"""Data models for proxy module."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Optional

from qazstack.proxy.config import ProxyType


@dataclass
class Proxy:
    """Single proxy endpoint."""

    url: str                          # e.g. http://user:pass@host:port
    country: str = ""                 # ISO 3166-1 alpha-2 (KZ, US, RU, ...)
    city: str = ""
    proxy_type: ProxyType = ProxyType.RESIDENTIAL
    provider: str = ""
    session_id: str = ""              # For sticky sessions
    created_at: float = field(default_factory=time.time)

    @property
    def host(self) -> str:
        from urllib.parse import urlparse
        parsed = urlparse(self.url)
        return parsed.hostname or ""

    @property
    def port(self) -> int:
        from urllib.parse import urlparse
        parsed = urlparse(self.url)
        return parsed.port or 0

    def as_httpx_proxy(self) -> str:
        """URL string usable with httpx.AsyncClient(proxy=...)."""
        return self.url

    def as_dict(self) -> dict:
        return {
            "url": self.url,
            "country": self.country,
            "city": self.city,
            "proxy_type": self.proxy_type.value,
            "provider": self.provider,
            "session_id": self.session_id,
        }


@dataclass
class ProxyHealth:
    """Health check result for a proxy."""

    proxy_url: str
    is_healthy: bool = True
    latency_ms: float = 0.0
    external_ip: str = ""
    country_detected: str = ""
    checked_at: float = field(default_factory=time.time)
    error: str = ""

    @property
    def age_seconds(self) -> float:
        return time.time() - self.checked_at


@dataclass
class ProxyStats:
    """Aggregated statistics."""

    total_requests: int = 0
    successful: int = 0
    failed: int = 0
    retries: int = 0
    avg_latency_ms: float = 0.0
    bytes_used: int = 0
    by_country: dict[str, int] = field(default_factory=dict)
    by_provider: dict[str, int] = field(default_factory=dict)

    @property
    def success_rate(self) -> float:
        if self.total_requests == 0:
            return 0.0
        return self.successful / self.total_requests

    def record(self, *, success: bool, latency_ms: float = 0.0,
               bytes_count: int = 0, country: str = "", provider: str = "") -> None:
        self.total_requests += 1
        if success:
            self.successful += 1
        else:
            self.failed += 1
        # Running average
        if self.total_requests > 0:
            self.avg_latency_ms = (
                (self.avg_latency_ms * (self.total_requests - 1) + latency_ms)
                / self.total_requests
            )
        self.bytes_used += bytes_count
        if country:
            self.by_country[country] = self.by_country.get(country, 0) + 1
        if provider:
            self.by_provider[provider] = self.by_provider.get(provider, 0) + 1
