"""httpx transport with automatic proxy rotation and retries."""

from __future__ import annotations

import logging
import time
from typing import Optional, TYPE_CHECKING

import httpx

if TYPE_CHECKING:
    from qazstack.proxy.manager import ProxyManager

from qazstack.proxy.config import ProxyType, RotationPolicy

logger = logging.getLogger("qazstack.proxy.transport")


class ProxyTransport(httpx.AsyncBaseTransport):
    """httpx transport that routes requests through rotating proxies.

    Usage:
        transport = ProxyTransport(manager, country="KZ")
        client = httpx.AsyncClient(transport=transport)
        resp = await client.get("https://example.com")

    On failure, retries with a fresh proxy up to max_retries times.
    On total failure with fallback_direct=True, falls back to direct connection.
    """

    def __init__(
        self,
        manager: "ProxyManager",
        *,
        country: str = "",
        city: str = "",
        proxy_type: Optional[ProxyType] = None,
        rotation: Optional[RotationPolicy] = None,
        session_id: str = "",
    ) -> None:
        self._manager = manager
        self._country = country
        self._city = city
        self._proxy_type = proxy_type
        self._rotation = rotation
        self._session_id = session_id

    async def handle_async_request(self, request: httpx.Request) -> httpx.Response:
        last_error: Optional[Exception] = None
        max_retries = self._manager.config.max_retries

        for attempt in range(1, max_retries + 1):
            proxy = await self._manager.get_proxy(
                country=self._country,
                city=self._city,
                proxy_type=self._proxy_type,
                rotation=self._rotation,
                session_id=self._session_id,
            )

            start = time.monotonic()
            try:
                # Create a one-shot transport with this proxy
                transport = httpx.AsyncHTTPTransport(proxy=proxy.url)
                response = await transport.handle_async_request(request)
                elapsed_ms = (time.monotonic() - start) * 1000

                # Record success
                content_length = int(response.headers.get("content-length", 0))
                self._manager.stats.record(
                    success=True,
                    latency_ms=elapsed_ms,
                    bytes_count=content_length,
                    country=proxy.country,
                    provider=proxy.provider,
                )

                logger.debug(
                    "Proxy request OK: %s via %s [%dms]",
                    str(request.url)[:80], proxy.country, int(elapsed_ms),
                )
                return response

            except Exception as e:
                elapsed_ms = (time.monotonic() - start) * 1000
                last_error = e
                self._manager.stats.record(
                    success=False,
                    latency_ms=elapsed_ms,
                    country=proxy.country,
                    provider=proxy.provider,
                )
                self._manager.stats.retries += 1

                logger.warning(
                    "Proxy request failed (attempt %d/%d): %s via %s – %s",
                    attempt, max_retries, str(request.url)[:80], proxy.host, e,
                )

        # All proxy attempts failed
        if self._manager.config.fallback_direct:
            logger.warning(
                "All proxy attempts failed, falling back to direct: %s",
                str(request.url)[:80],
            )
            transport = httpx.AsyncHTTPTransport()
            return await transport.handle_async_request(request)

        raise last_error or RuntimeError("All proxy attempts failed")
