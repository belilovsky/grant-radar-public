"""Proxy configuration and enums."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class ProxyType(str, Enum):
    RESIDENTIAL = "residential"
    DATACENTER = "datacenter"
    MOBILE = "mobile"
    ISP = "isp"


class RotationPolicy(str, Enum):
    PER_REQUEST = "per_request"      # New IP every request
    STICKY = "sticky"                # Same IP for session duration
    TIMED = "timed"                  # Rotate every N seconds


class Provider(str, Enum):
    IPROYAL = "iproyal"
    DECODO = "decodo"
    BRIGHTDATA = "brightdata"
    GENERIC = "generic"              # Any provider via proxy URL template


@dataclass
class ProxyConfig:
    """Central proxy configuration.

    Can be created from env vars:
        PROXY_PROVIDER = iproyal | decodo | brightdata | generic
        PROXY_API_KEY = ...
        PROXY_USERNAME = ...
        PROXY_PASSWORD = ...
        PROXY_DEFAULT_COUNTRY = KZ
        PROXY_DEFAULT_TYPE = residential
        PROXY_ROTATION = per_request | sticky | timed
        PROXY_STICKY_TTL = 600  (seconds, for sticky/timed)
        PROXY_MAX_RETRIES = 3
        PROXY_HEALTH_CHECK_URL = https://httpbin.org/ip
        PROXY_HEALTH_INTERVAL = 300  (seconds)
        PROXY_FALLBACK_DIRECT = true  (fall back to direct if all proxies fail)

        # Generic provider (custom proxy URL):
        PROXY_URL_TEMPLATE = http://user:pass@gate.provider.com:7777
        PROXY_URLS = url1,url2,url3  (comma-separated list)
    """

    provider: Provider = Provider.GENERIC
    api_key: str = ""
    username: str = ""
    password: str = ""

    # Defaults
    default_country: str = ""
    default_type: ProxyType = ProxyType.RESIDENTIAL
    rotation: RotationPolicy = RotationPolicy.PER_REQUEST
    sticky_ttl: int = 600  # seconds

    # Reliability
    max_retries: int = 3
    timeout: float = 30.0
    health_check_url: str = "https://httpbin.org/ip"
    health_interval: int = 300  # seconds
    fallback_direct: bool = True

    # Generic provider
    url_template: str = ""
    urls: list[str] = field(default_factory=list)

    # Provider-specific
    extra: dict = field(default_factory=dict)

    @classmethod
    def from_env(cls, prefix: str = "PROXY_") -> "ProxyConfig":
        """Build config from environment variables."""
        def env(key: str, default: str = "") -> str:
            return os.getenv(f"{prefix}{key}", default)

        provider_str = env("PROVIDER", "generic").lower()
        try:
            provider = Provider(provider_str)
        except ValueError:
            provider = Provider.GENERIC

        type_str = env("DEFAULT_TYPE", "residential").lower()
        try:
            proxy_type = ProxyType(type_str)
        except ValueError:
            proxy_type = ProxyType.RESIDENTIAL

        rotation_str = env("ROTATION", "per_request").lower()
        try:
            rotation = RotationPolicy(rotation_str)
        except ValueError:
            rotation = RotationPolicy.PER_REQUEST

        urls_str = env("URLS", "")
        urls = [u.strip() for u in urls_str.split(",") if u.strip()] if urls_str else []

        return cls(
            provider=provider,
            api_key=env("API_KEY"),
            username=env("USERNAME"),
            password=env("PASSWORD"),
            default_country=env("DEFAULT_COUNTRY", ""),
            default_type=proxy_type,
            rotation=rotation,
            sticky_ttl=int(env("STICKY_TTL", "600")),
            max_retries=int(env("MAX_RETRIES", "3")),
            timeout=float(env("TIMEOUT", "30.0")),
            health_check_url=env("HEALTH_CHECK_URL", "https://httpbin.org/ip"),
            health_interval=int(env("HEALTH_INTERVAL", "300")),
            fallback_direct=env("FALLBACK_DIRECT", "true").lower() in ("true", "1", "yes"),
            url_template=env("URL_TEMPLATE", ""),
            urls=urls,
        )
