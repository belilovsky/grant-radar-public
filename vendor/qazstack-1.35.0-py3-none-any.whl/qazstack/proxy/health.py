"""Proxy health checking."""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Optional

import httpx

from qazstack.proxy.models import Proxy, ProxyHealth

logger = logging.getLogger("qazstack.proxy.health")


class HealthChecker:
    """Checks proxy health by making a test request through the proxy."""

    def __init__(
        self,
        check_url: str = "https://httpbin.org/ip",
        timeout: float = 15.0,
    ) -> None:
        self.check_url = check_url
        self.timeout = timeout
        self._cache: dict[str, ProxyHealth] = {}

    async def check(self, proxy: Proxy, force: bool = False) -> ProxyHealth:
        """Check a single proxy's health.

        Returns cached result if recent (< 60s) unless force=True.
        """
        cache_key = proxy.url
        if not force and cache_key in self._cache:
            cached = self._cache[cache_key]
            if cached.age_seconds < 60:
                return cached

        start = time.monotonic()
        try:
            async with httpx.AsyncClient(
                proxy=proxy.url,
                timeout=self.timeout,
                follow_redirects=True,
            ) as client:
                resp = await client.get(self.check_url)
                resp.raise_for_status()
                elapsed_ms = (time.monotonic() - start) * 1000

                # Try to extract IP from httpbin response
                external_ip = ""
                country = ""
                try:
                    data = resp.json()
                    external_ip = data.get("origin", "")
                except Exception:
                    pass

                health = ProxyHealth(
                    proxy_url=proxy.url,
                    is_healthy=True,
                    latency_ms=elapsed_ms,
                    external_ip=external_ip,
                    country_detected=country,
                )
        except Exception as e:
            elapsed_ms = (time.monotonic() - start) * 1000
            health = ProxyHealth(
                proxy_url=proxy.url,
                is_healthy=False,
                latency_ms=elapsed_ms,
                error=str(e),
            )
            logger.warning("Proxy health check failed: %s – %s", proxy.url[:50], e)

        self._cache[cache_key] = health
        return health

    async def check_many(self, proxies: list[Proxy]) -> list[ProxyHealth]:
        """Check multiple proxies concurrently."""
        tasks = [self.check(p) for p in proxies]
        return await asyncio.gather(*tasks, return_exceptions=False)

    def get_cached(self, proxy_url: str) -> Optional[ProxyHealth]:
        return self._cache.get(proxy_url)

    def clear_cache(self) -> None:
        self._cache.clear()
