"""Generic provider – works with any proxy via URL template or URL list."""

from __future__ import annotations

import itertools
import random
from typing import Optional

from qazstack.proxy.config import ProxyConfig, ProxyType, RotationPolicy
from qazstack.proxy.models import Proxy
from qazstack.proxy.providers.base import BaseProvider


class GenericProvider(BaseProvider):
    """Provider for arbitrary proxy URLs.

    Supports two modes:
    1. URL template: single proxy URL (possibly with rotation built-in by provider)
    2. URL list: multiple proxy URLs with round-robin/random rotation

    Env vars:
        PROXY_URL_TEMPLATE = http://user:pass@gate.provider.com:7777
        PROXY_URLS = http://p1:8080,http://p2:8080,http://p3:8080
    """

    def __init__(self, config: ProxyConfig) -> None:
        super().__init__(config)
        self._urls = config.urls or ([config.url_template] if config.url_template else [])
        self._cycle = itertools.cycle(self._urls) if self._urls else None
        self._sticky_cache: dict[str, str] = {}

    async def get_proxy(
        self,
        *,
        country: str = "",
        city: str = "",
        proxy_type: Optional[ProxyType] = None,
        rotation: Optional[RotationPolicy] = None,
        session_id: str = "",
    ) -> Proxy:
        if not self._urls:
            raise ValueError(
                "GenericProvider requires PROXY_URL_TEMPLATE or PROXY_URLS. "
                "Set env vars or pass urls/url_template in ProxyConfig."
            )

        effective_rotation = rotation or self.config.rotation

        if effective_rotation == RotationPolicy.STICKY and session_id:
            if session_id in self._sticky_cache:
                url = self._sticky_cache[session_id]
            else:
                url = random.choice(self._urls)
                self._sticky_cache[session_id] = url
        elif effective_rotation == RotationPolicy.PER_REQUEST:
            url = next(self._cycle) if self._cycle else self._urls[0]
        else:
            url = random.choice(self._urls)

        return Proxy(
            url=url,
            country=country or self.config.default_country,
            city=city,
            proxy_type=proxy_type or self.config.default_type,
            provider=self.name,
            session_id=session_id,
        )
