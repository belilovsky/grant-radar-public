"""Decodo (ex-Smartproxy) provider – fast, 125M+ IPs, ~$6/GB.

Trial mode: ports 10001-10010 (rotating IPs, no geo-targeting).
Full mode: port 7777 with username suffix for country/city/session.
"""

from __future__ import annotations

import uuid
from typing import Optional
from urllib.parse import quote

from qazstack.proxy.config import ProxyConfig, ProxyType, RotationPolicy
from qazstack.proxy.models import Proxy
from qazstack.proxy.providers.base import BaseProvider


class DecodoProvider(BaseProvider):
    """Decodo (Smartproxy) residential/datacenter proxy integration.

    Gateway format:
        Residential: http://{user}:{pass}@gate.decodo.com:7777
        With country:  user param suffix: -country-{cc}
        With session:  user param suffix: -session-{sid}
        Datacenter: http://{user}:{pass}@dc.decodo.com:10000

    Trial mode (ports 10001-10010):
        Each port is a separate rotating IP, no geo-targeting.
        http://{user}:{pass}@gate.decodo.com:10001

    Env vars:
        PROXY_USERNAME = your_decodo_username
        PROXY_PASSWORD = your_decodo_password
    """

    RESIDENTIAL_HOST = "gate.decodo.com"
    RESIDENTIAL_PORT = 7777
    DATACENTER_HOST = "dc.decodo.com"
    DATACENTER_PORT = 10000

    # Trial ports: each port returns a different rotating IP
    TRIAL_PORTS = list(range(10001, 10011))

    def __init__(self, config: ProxyConfig) -> None:
        super().__init__(config)
        # Auto-detect trial mode from extra config or explicit flag
        self._trial_mode = config.extra.get("trial_mode", False)
        self._trial_port_index = 0

    def _build_residential_url(
        self,
        country: str,
        city: str,
        session_id: str,
        rotation: RotationPolicy,
    ) -> str:
        user = self.config.username

        # Decodo uses username suffix for targeting
        suffixes: list[str] = []
        if country:
            suffixes.append(f"country-{country.lower()}")
        if city:
            suffixes.append(f"city-{city.lower()}")

        if rotation == RotationPolicy.STICKY:
            sid = session_id or uuid.uuid4().hex[:12]
            suffixes.append(f"session-{sid}")
        elif rotation == RotationPolicy.TIMED:
            sid = session_id or uuid.uuid4().hex[:12]
            suffixes.append(f"session-{sid}")
            suffixes.append(f"lifetime-{self.config.sticky_ttl}")

        full_user = user + ("-" + "-".join(suffixes) if suffixes else "")

        # URL-encode credentials (password may contain special chars like =)
        encoded_user = quote(full_user, safe="")
        encoded_pass = quote(self.config.password, safe="")

        return (
            f"http://{encoded_user}:{encoded_pass}"
            f"@{self.RESIDENTIAL_HOST}:{self.RESIDENTIAL_PORT}"
        )

    def _build_trial_url(self) -> str:
        """Build URL using trial port rotation (10001-10010)."""
        port = self.TRIAL_PORTS[self._trial_port_index % len(self.TRIAL_PORTS)]
        self._trial_port_index += 1

        encoded_user = quote(self.config.username, safe="")
        encoded_pass = quote(self.config.password, safe="")

        return f"http://{encoded_user}:{encoded_pass}@{self.RESIDENTIAL_HOST}:{port}"

    def _build_datacenter_url(self, country: str) -> str:
        user = self.config.username
        suffixes: list[str] = []
        if country:
            suffixes.append(f"country-{country.lower()}")
        full_user = user + ("-" + "-".join(suffixes) if suffixes else "")
        encoded_user = quote(full_user, safe="")
        encoded_pass = quote(self.config.password, safe="")
        return f"http://{encoded_user}:{encoded_pass}@{self.DATACENTER_HOST}:{self.DATACENTER_PORT}"

    async def get_proxy(
        self,
        *,
        country: str = "",
        city: str = "",
        proxy_type: Optional[ProxyType] = None,
        rotation: Optional[RotationPolicy] = None,
        session_id: str = "",
    ) -> Proxy:
        effective_country = country or self.config.default_country
        effective_type = proxy_type or self.config.default_type
        effective_rotation = rotation or self.config.rotation

        # Trial mode: use port-based rotation, ignore geo params
        if self._trial_mode:
            url = self._build_trial_url()
            return Proxy(
                url=url,
                country="",  # Trial has no geo-targeting
                city="",
                proxy_type=ProxyType.RESIDENTIAL,
                provider=self.name,
                session_id="",
            )

        if effective_type == ProxyType.DATACENTER:
            url = self._build_datacenter_url(effective_country)
        else:
            url = self._build_residential_url(
                effective_country, city, session_id, effective_rotation,
            )

        return Proxy(
            url=url,
            country=effective_country,
            city=city,
            proxy_type=effective_type,
            provider=self.name,
            session_id=session_id,
        )
