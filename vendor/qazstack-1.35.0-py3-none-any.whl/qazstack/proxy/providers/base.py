"""Base provider protocol."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Optional

from qazstack.proxy.config import ProxyConfig, ProxyType, RotationPolicy
from qazstack.proxy.models import Proxy


class BaseProvider(ABC):
    """Abstract base for proxy providers.

    Each provider must implement get_proxy() which returns a Proxy object
    configured for the requested country/type/rotation.
    """

    def __init__(self, config: ProxyConfig) -> None:
        self.config = config

    @abstractmethod
    async def get_proxy(
        self,
        *,
        country: str = "",
        city: str = "",
        proxy_type: Optional[ProxyType] = None,
        rotation: Optional[RotationPolicy] = None,
        session_id: str = "",
    ) -> Proxy:
        """Get a proxy endpoint.

        Args:
            country: ISO 3166-1 alpha-2 code (e.g. "KZ", "US", "RU").
            city: City name (provider-specific).
            proxy_type: Override default proxy type.
            rotation: Override default rotation policy.
            session_id: Session ID for sticky sessions.

        Returns:
            Proxy object with connection URL.
        """
        ...

    async def close(self) -> None:
        """Cleanup resources (override if needed)."""
        pass

    @property
    def name(self) -> str:
        return self.__class__.__name__.replace("Provider", "").lower()
