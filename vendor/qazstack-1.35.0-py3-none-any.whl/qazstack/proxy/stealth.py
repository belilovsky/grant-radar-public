"""StealthTransport – TLS fingerprint bypass via curl_cffi.

Requires: pip install curl_cffi
"""

from __future__ import annotations

import asyncio
import itertools
import logging
import time
from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from qazstack.proxy.manager import ProxyManager

from qazstack.proxy.config import ProxyType, RotationPolicy

logger = logging.getLogger("qazstack.proxy.stealth")

# Browser impersonation targets – rotated automatically when no fixed browser set
BROWSER_TARGETS = [
    "chrome124",
    "chrome123",
    "chrome120",
    "safari17_0",
    "safari15_5",
    "edge101",
]

try:
    from curl_cffi.requests import AsyncSession
    HAS_CURL_CFFI = True
except ImportError:
    HAS_CURL_CFFI = False
    AsyncSession = None  # type: ignore[assignment,misc]


class StealthClient:
    """HTTP client with TLS fingerprint impersonation via curl_cffi.

    Bypasses JA3/TLS fingerprint detection used by Cloudflare, Akamai, etc.
    Rotates browser impersonation profiles per request unless a fixed profile
    is given. Integrates with ProxyManager for proxy rotation and retries.

    Usage::

        client = StealthClient(manager, country="KZ")
        resp = await client.get("https://protected-site.com")
        print(resp.status_code, resp.text[:200])

        # Force a specific browser fingerprint:
        client = StealthClient(manager, impersonate="chrome124")
        resp = await client.post("https://api.example.com/data", json={"key": "val"})

    Raises:
        ImportError: if curl_cffi is not installed.
        RuntimeError: if all proxy attempts fail and fallback_direct is False.
    """

    def __init__(
        self,
        manager: "ProxyManager",
        *,
        country: str = "",
        city: str = "",
        proxy_type: Optional[ProxyType] = None,
        rotation: Optional[RotationPolicy] = None,
        session_id: str = "",
        impersonate: str = "",       # empty = auto-rotate across BROWSER_TARGETS
        timeout: float = 30.0,
    ) -> None:
        if not HAS_CURL_CFFI:
            raise ImportError(
                "curl_cffi is required for StealthClient. "
                "Install with: pip install curl_cffi"
            )
        self._manager = manager
        self._country = country
        self._city = city
        self._proxy_type = proxy_type
        self._rotation = rotation
        self._session_id = session_id
        self._timeout = timeout
        self._fixed_impersonate = impersonate
        # Cycle through all browser targets for auto-rotation
        self._browser_cycle = itertools.cycle(BROWSER_TARGETS)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _next_browser(self) -> str:
        """Return the next browser impersonation target."""
        if self._fixed_impersonate:
            return self._fixed_impersonate
        return next(self._browser_cycle)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def request(
        self,
        method: str,
        url: str,
        **kwargs,
    ):  # -> curl_cffi.requests.Response
        """Send an HTTP request via a rotating proxy with TLS impersonation.

        Args:
            method: HTTP verb (GET, POST, HEAD, …).
            url: Target URL.
            **kwargs: Forwarded to curl_cffi AsyncSession.request().

        Returns:
            curl_cffi Response object.

        Raises:
            RuntimeError: When all proxy attempts fail and fallback is disabled.
        """
        max_retries = self._manager.config.max_retries
        last_error: Optional[Exception] = None

        for attempt in range(1, max_retries + 1):
            proxy = await self._manager.get_proxy(
                country=self._country,
                city=self._city,
                proxy_type=self._proxy_type,
                rotation=self._rotation,
                session_id=self._session_id,
            )
            browser = self._next_browser()
            start = time.monotonic()

            try:
                async with AsyncSession() as session:
                    resp = await session.request(
                        method,
                        url,
                        proxy=proxy.url,
                        impersonate=browser,
                        timeout=self._timeout,
                        **kwargs,
                    )
                elapsed_ms = (time.monotonic() - start) * 1000
                self._manager.stats.record(
                    success=True,
                    latency_ms=elapsed_ms,
                    bytes_count=len(resp.content),
                    country=proxy.country,
                    provider=proxy.provider,
                )
                logger.debug(
                    "Stealth %s OK: %s via %s [%s] %dms",
                    method,
                    url[:60],
                    proxy.country,
                    browser,
                    int(elapsed_ms),
                )
                return resp

            except Exception as exc:
                elapsed_ms = (time.monotonic() - start) * 1000
                last_error = exc
                self._manager.stats.record(
                    success=False,
                    latency_ms=elapsed_ms,
                    country=proxy.country,
                    provider=proxy.provider,
                )
                self._manager.stats.retries += 1
                logger.warning(
                    "Stealth request failed (attempt %d/%d): %s – %s",
                    attempt,
                    max_retries,
                    url[:60],
                    exc,
                )

        # All proxy attempts exhausted
        if self._manager.config.fallback_direct:
            logger.warning(
                "All stealth proxy attempts failed, trying direct: %s", url[:60]
            )
            async with AsyncSession() as session:
                return await session.request(
                    method,
                    url,
                    impersonate=self._next_browser(),
                    timeout=self._timeout,
                    **kwargs,
                )

        raise last_error or RuntimeError("All stealth proxy attempts failed")

    async def get(self, url: str, **kwargs):
        """GET request with TLS impersonation."""
        return await self.request("GET", url, **kwargs)

    async def post(self, url: str, **kwargs):
        """POST request with TLS impersonation."""
        return await self.request("POST", url, **kwargs)

    async def head(self, url: str, **kwargs):
        """HEAD request with TLS impersonation."""
        return await self.request("HEAD", url, **kwargs)

    async def put(self, url: str, **kwargs):
        """PUT request with TLS impersonation."""
        return await self.request("PUT", url, **kwargs)

    async def patch(self, url: str, **kwargs):
        """PATCH request with TLS impersonation."""
        return await self.request("PATCH", url, **kwargs)

    async def delete(self, url: str, **kwargs):
        """DELETE request with TLS impersonation."""
        return await self.request("DELETE", url, **kwargs)

    # ------------------------------------------------------------------
    # Context manager support
    # ------------------------------------------------------------------

    async def __aenter__(self) -> "StealthClient":
        return self

    async def __aexit__(self, *args) -> None:
        pass
