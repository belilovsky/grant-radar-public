"""Small httpx helpers for a single environment-configured proxy."""

from __future__ import annotations

import os
from collections.abc import Mapping
from typing import Any

import httpx


def proxy_url_from_env(
    *,
    env: Mapping[str, str] | None = None,
    variable: str = "ROTA_PROXY_URL",
) -> str:
    values = os.environ if env is None else env
    return (values.get(variable) or "").strip()


def create_sync_client(
    *,
    proxy_url: str | None = None,
    env: Mapping[str, str] | None = None,
    variable: str = "ROTA_PROXY_URL",
    **kwargs: Any,
) -> httpx.Client:
    proxy = proxy_url if proxy_url is not None else proxy_url_from_env(env=env, variable=variable)
    if proxy:
        kwargs.setdefault("proxy", proxy)
    return httpx.Client(**kwargs)


def http_get(url: str, **kwargs: Any) -> httpx.Response:
    with create_sync_client() as client:
        return client.get(url, **kwargs)


def http_post(url: str, **kwargs: Any) -> httpx.Response:
    with create_sync_client() as client:
        return client.post(url, **kwargs)
