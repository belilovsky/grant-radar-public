"""
qazstack.proxy – Unified proxy management for all Belilovsky projects.

v0.2.0 – Full-featured proxy module with:
- Multi-provider support (IPRoyal, Decodo, BrightData, Generic)
- StealthClient (curl_cffi TLS fingerprint bypass)
- FreePool (aggregated free proxy fallback)
- ProxyChain (cascading: paid → free → direct)
- SGEO tools (GeoSERP, GeoFetcher, SiteVerifier)

Usage:
    from qazstack.proxy import ProxyManager, ProxyConfig

    # Quick start with env vars (PROXY_PROVIDER, PROXY_API_KEY, etc.)
    pm = ProxyManager.from_env()
    async with pm:
        proxy = await pm.get_proxy(country="KZ")
        async with httpx.AsyncClient(proxy=proxy.url) as client:
            resp = await client.get("https://target.com")

    # Stealth mode (TLS fingerprint bypass)
    from qazstack.proxy.stealth import StealthClient
    async with pm:
        stealth = StealthClient(pm, country="US")
        resp = await stealth.get("https://protected-site.com")

    # Cascading chain (paid → free → direct)
    from qazstack.proxy.chain import ProxyChain
    from qazstack.proxy.freepool import FreePool
    async with pm:
        chain = ProxyChain(pm, FreePool())
        result = await chain.get("https://target.com", country="KZ")

    # SGEO: geo-localized SERP monitoring
    from qazstack.proxy.sgeo import GeoSERP, SERPQuery
    async with pm:
        serp = GeoSERP(pm)
        results = await serp.search(
            SERPQuery(query="total.kz", countries=["KZ", "RU", "US"])
        )
"""

__version__ = "0.2.0"

from qazstack.proxy.config import Provider, ProxyConfig, ProxyType, RotationPolicy
from qazstack.proxy.health import HealthChecker
from qazstack.proxy.http import create_sync_client, http_get, http_post, proxy_url_from_env
from qazstack.proxy.manager import ProxyManager
from qazstack.proxy.models import Proxy, ProxyHealth, ProxyStats
from qazstack.proxy.providers.base import BaseProvider
from qazstack.proxy.providers.brightdata import BrightDataProvider
from qazstack.proxy.providers.decodo import DecodoProvider
from qazstack.proxy.providers.generic import GenericProvider
from qazstack.proxy.providers.iproyal import IPRoyalProvider
from qazstack.proxy.transport import ProxyTransport

__all__ = [
    "__version__",
    "ProxyConfig",
    "ProxyType",
    "RotationPolicy",
    "Provider",
    "Proxy",
    "ProxyHealth",
    "ProxyStats",
    "BaseProvider",
    "GenericProvider",
    "IPRoyalProvider",
    "DecodoProvider",
    "BrightDataProvider",
    "ProxyManager",
    "ProxyTransport",
    "HealthChecker",
    "create_sync_client",
    "http_get",
    "http_post",
    "proxy_url_from_env",
]
