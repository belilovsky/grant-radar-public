"""ProxyChain – cascading proxy strategy: paid → free → direct.

Implements a fallback chain that tries the most reliable/expensive proxy
first, falls through cheaper options, and ultimately falls back to a
direct connection if everything else fails.

Designed for qazstack collectors that need best-effort connectivity
across diverse targets (news sites, government portals, social media).
"""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

import httpx

from qazstack.proxy.config import ProxyConfig, ProxyType, RotationPolicy
from qazstack.proxy.models import Proxy, ProxyStats
from qazstack.proxy.freepool import FreePool

logger = logging.getLogger("qazstack.proxy.chain")


class TierName(str, Enum):
    PAID = "paid"
    FREE = "free"
    DIRECT = "direct"


@dataclass
class ChainResult:
    """Result of a chained request."""
    response: Optional[httpx.Response] = None
    tier_used: TierName = TierName.DIRECT
    proxy_used: Optional[Proxy] = None
    latency_ms: float = 0.0
    attempts: int = 0
    errors: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return self.response is not None and self.response.status_code < 400


class ProxyChain:
    """Cascading proxy strategy for maximum reliability.

    Chain order:
    1. Paid proxy (via ProxyManager) – best quality, geo-targeting
    2. Free proxy (via FreePool) – fallback, no guarantees
    3. Direct connection – last resort

    Usage::

        from qazstack.proxy import ProxyManager
        from qazstack.proxy.chain import ProxyChain
        from qazstack.proxy.freepool import FreePool

        manager = ProxyManager.from_env()
        freepool = FreePool()
        chain = ProxyChain(manager, freepool)

        async with manager:
            await freepool.refresh()
            result = await chain.request("GET", "https://target.com", country="KZ")
            if result.ok:
                print(f"Got response via {result.tier_used}: {result.response.status_code}")

    Configuration via constructor or env:
        paid_retries: attempts per paid proxy (default 2)
        free_retries: attempts via free proxies (default 3)
        enable_free: whether to try free tier (default True)
        enable_direct: whether to try direct (default True)
        timeout: per-request timeout (default 30s)
    """

    def __init__(
        self,
        manager,                           # ProxyManager (avoid circular import)
        freepool: Optional[FreePool] = None,
        *,
        paid_retries: int = 2,
        free_retries: int = 3,
        enable_free: bool = True,
        enable_direct: bool = True,
        timeout: float = 30.0,
    ) -> None:
        self._manager = manager
        self._freepool = freepool
        self._paid_retries = paid_retries
        self._free_retries = free_retries
        self._enable_free = enable_free
        self._enable_direct = enable_direct
        self._timeout = timeout
        self.stats = ProxyStats()

    async def request(
        self,
        method: str,
        url: str,
        *,
        country: str = "",
        city: str = "",
        proxy_type: Optional[ProxyType] = None,
        headers: Optional[dict] = None,
        **kwargs,
    ) -> ChainResult:
        """Send a request through the cascade chain.

        Tries paid → free → direct, returning the first successful response.
        """
        result = ChainResult()
        start = time.monotonic()

        # ------ Tier 1: Paid proxy ------
        for attempt in range(1, self._paid_retries + 1):
            result.attempts += 1
            try:
                proxy = await self._manager.get_proxy(
                    country=country, city=city, proxy_type=proxy_type,
                )
                resp = await self._do_request(method, url, proxy.url, headers, **kwargs)
                result.response = resp
                result.tier_used = TierName.PAID
                result.proxy_used = proxy
                result.latency_ms = (time.monotonic() - start) * 1000
                self._record(True, result.latency_ms, proxy.country, "paid")
                logger.debug("Chain: paid proxy OK (%s, attempt %d)", proxy.country, attempt)
                return result
            except Exception as e:
                result.errors.append(f"paid[{attempt}]: {e}")
                logger.debug("Chain: paid proxy failed (attempt %d): %s", attempt, e)

        # ------ Tier 2: Free proxy ------
        if self._enable_free and self._freepool:
            # Auto-refresh if pool is stale
            if self._freepool.needs_refresh:
                try:
                    await self._freepool.refresh(validate=False)
                except Exception as e:
                    logger.warning("FreePool refresh failed: %s", e)

            for attempt in range(1, self._free_retries + 1):
                result.attempts += 1
                proxy_obj = self._freepool.get_proxy(country=country)
                if proxy_obj is None:
                    result.errors.append(f"free[{attempt}]: no proxies available")
                    break

                try:
                    resp = await self._do_request(method, url, proxy_obj.url, headers, **kwargs)
                    result.response = resp
                    result.tier_used = TierName.FREE
                    result.proxy_used = proxy_obj
                    result.latency_ms = (time.monotonic() - start) * 1000
                    self._record(True, result.latency_ms, proxy_obj.country, "freepool")
                    logger.debug("Chain: free proxy OK (%s, attempt %d)", proxy_obj.url[:30], attempt)
                    return result
                except Exception as e:
                    self._freepool.mark_dead(proxy_obj.url)
                    result.errors.append(f"free[{attempt}]: {e}")
                    logger.debug("Chain: free proxy failed (attempt %d): %s", attempt, e)

        # ------ Tier 3: Direct ------
        if self._enable_direct:
            result.attempts += 1
            try:
                resp = await self._do_request(method, url, None, headers, **kwargs)
                result.response = resp
                result.tier_used = TierName.DIRECT
                result.proxy_used = None
                result.latency_ms = (time.monotonic() - start) * 1000
                self._record(True, result.latency_ms, "", "direct")
                logger.debug("Chain: direct connection OK")
                return result
            except Exception as e:
                result.errors.append(f"direct: {e}")
                logger.warning("Chain: direct connection also failed: %s", e)

        # All tiers exhausted
        result.latency_ms = (time.monotonic() - start) * 1000
        self._record(False, result.latency_ms, country, "chain_fail")
        logger.error(
            "Chain: all tiers failed for %s (%d attempts, errors: %s)",
            url[:60], result.attempts, "; ".join(result.errors[-3:]),
        )
        return result

    async def get(self, url: str, **kwargs) -> ChainResult:
        return await self.request("GET", url, **kwargs)

    async def post(self, url: str, **kwargs) -> ChainResult:
        return await self.request("POST", url, **kwargs)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    async def _do_request(
        self,
        method: str,
        url: str,
        proxy_url: Optional[str],
        headers: Optional[dict],
        **kwargs,
    ) -> httpx.Response:
        """Execute a single HTTP request."""
        client_kwargs: dict = {
            "timeout": self._timeout,
            "follow_redirects": True,
        }
        if proxy_url:
            client_kwargs["proxy"] = proxy_url

        async with httpx.AsyncClient(**client_kwargs) as client:
            resp = await client.request(method, url, headers=headers, **kwargs)
            resp.raise_for_status()
            return resp

    def _record(self, success: bool, latency_ms: float, country: str, provider: str) -> None:
        self.stats.record(
            success=success, latency_ms=latency_ms,
            country=country, provider=provider,
        )
        # Also record in parent manager stats
        self._manager.stats.record(
            success=success, latency_ms=latency_ms,
            country=country, provider=provider,
        )
