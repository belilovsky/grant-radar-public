"""Internal FastAPI service for the QazStack OCR contract."""

from __future__ import annotations

import asyncio
import hmac
import math
import os
import tempfile
from collections.abc import Callable
from http import HTTPStatus
from pathlib import Path

from fastapi import FastAPI, File, Form, Header, HTTPException, UploadFile, status

from qazstack import __version__
from qazstack.ocr.backend import (
    OCRConfig,
    OCRDependencyError,
    OCRError,
    OCRInputError,
    OCRProcessingError,
    extract_document,
)
from qazstack.ocr.models import OCR_CONTRACT, OCRDocument

Extractor = Callable[..., OCRDocument]
ReadinessProbe = Callable[[], tuple[bool, dict[str, object]]]


def _positive_int(name: str, default: int) -> int:
    raw = os.getenv(name, str(default))
    try:
        value = int(raw)
    except ValueError as exc:
        raise RuntimeError(f"{name} must be an integer") from exc
    if value < 1:
        raise RuntimeError(f"{name} must be positive")
    return value


def _default_readiness_probe() -> tuple[bool, dict[str, object]]:
    required = {part for part in os.getenv("QAZSTACK_OCR_REQUIRED_LANGUAGES", "kaz+rus+eng").split("+") if part}
    try:
        import pytesseract

        available = set(pytesseract.get_languages(config=""))
        version = str(pytesseract.get_tesseract_version())
    except Exception as exc:
        return False, {"error": f"Tesseract unavailable: {type(exc).__name__}"}
    missing = sorted(required - available)
    return not missing, {
        "engine": "tesseract",
        "engine_version": version,
        "required_languages": sorted(required),
        "missing_languages": missing,
    }


def create_ocr_app(
    *,
    extractor: Extractor = extract_document,
    readiness_probe: ReadinessProbe = _default_readiness_probe,
    api_key: str | None = None,
    max_upload_bytes: int | None = None,
    max_concurrency: int | None = None,
    queue_timeout_seconds: float | None = None,
) -> FastAPI:
    """Build the isolated OCR service with explicit resource limits."""

    configured_api_key = api_key if api_key is not None else os.getenv("QAZSTACK_OCR_API_KEY")
    upload_limit = max_upload_bytes or _positive_int("QAZSTACK_OCR_MAX_UPLOAD_BYTES", 100 * 1024 * 1024)
    concurrency = max_concurrency or _positive_int("QAZSTACK_OCR_MAX_CONCURRENCY", 2)
    queue_timeout = queue_timeout_seconds or float(os.getenv("QAZSTACK_OCR_QUEUE_TIMEOUT_SECONDS", "30"))
    if queue_timeout <= 0:
        raise RuntimeError("QAZSTACK_OCR_QUEUE_TIMEOUT_SECONDS must be positive")
    max_page_pixels = _positive_int("QAZSTACK_OCR_MAX_PAGE_PIXELS", 100_000_000)
    semaphore = asyncio.Semaphore(concurrency)

    app = FastAPI(
        title="QazStack OCR",
        version=__version__,
        docs_url="/docs" if os.getenv("QAZSTACK_OCR_DOCS", "0") == "1" else None,
        redoc_url=None,
        openapi_url="/openapi.json" if os.getenv("QAZSTACK_OCR_DOCS", "0") == "1" else None,
    )

    def authorize(candidate: str | None) -> None:
        if configured_api_key and (not candidate or not hmac.compare_digest(candidate, configured_api_key)):
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="invalid OCR API key")

    @app.get("/health")
    async def health() -> dict[str, object]:
        return {
            "status": "ok",
            "service": "qazstack-ocr",
            "version": __version__,
            "contract": OCR_CONTRACT,
        }

    @app.get("/ready")
    async def ready() -> dict[str, object]:
        healthy, details = await asyncio.to_thread(readiness_probe)
        if not healthy:
            raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail=details)
        return {"status": "ready", **details}

    @app.post("/v1/ocr")
    async def ocr(
        file: UploadFile = File(...),
        languages: str = Form("kaz+rus+eng"),
        dpi: int = Form(300, ge=72, le=600),
        page_segmentation_mode: int = Form(3, ge=0, le=13),
        timeout_seconds: float = Form(120, gt=0, le=600),
        max_pages: int | None = Form(None, ge=1, le=1000),
        x_api_key: str | None = Header(None),
    ) -> dict[str, object]:
        authorize(x_api_key)
        suffix = Path(file.filename or "upload").suffix.lower()
        if not suffix:
            raise HTTPException(status_code=HTTPStatus.UNPROCESSABLE_ENTITY, detail="file extension is required")

        temporary_path: Path | None = None
        written = 0
        try:
            with tempfile.NamedTemporaryFile(prefix="qazstack-ocr-", suffix=suffix, delete=False) as handle:
                temporary_path = Path(handle.name)
                while chunk := await file.read(1024 * 1024):
                    written += len(chunk)
                    if written > upload_limit:
                        raise HTTPException(
                            status_code=HTTPStatus.REQUEST_ENTITY_TOO_LARGE,
                            detail=f"upload exceeds {upload_limit} byte limit",
                        )
                    handle.write(chunk)
            if written == 0:
                raise HTTPException(status_code=HTTPStatus.UNPROCESSABLE_ENTITY, detail="uploaded file is empty")

            config = OCRConfig(
                languages=languages,
                dpi=dpi,
                page_segmentation_mode=page_segmentation_mode,
                timeout_seconds=timeout_seconds,
                max_pages=max_pages,
                max_input_bytes=upload_limit,
                max_page_pixels=max_page_pixels,
            )
            try:
                await asyncio.wait_for(semaphore.acquire(), timeout=queue_timeout)
            except TimeoutError as exc:
                raise HTTPException(
                    status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                    detail="OCR queue is full; retry later",
                    headers={"Retry-After": str(max(1, math.ceil(queue_timeout)))},
                ) from exc
            try:
                document = await asyncio.to_thread(extractor, temporary_path, config=config)
            finally:
                semaphore.release()

            payload = document.to_dict()
            payload["source"] = Path(file.filename or temporary_path.name).name
            return payload
        except HTTPException:
            raise
        except OCRInputError as exc:
            raise HTTPException(status_code=HTTPStatus.UNPROCESSABLE_ENTITY, detail=str(exc)) from exc
        except OCRDependencyError as exc:
            raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail=str(exc)) from exc
        except OCRProcessingError as exc:
            raise HTTPException(status_code=status.HTTP_502_BAD_GATEWAY, detail=str(exc)) from exc
        except (OCRError, ValueError) as exc:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc
        finally:
            await file.close()
            if temporary_path is not None:
                temporary_path.unlink(missing_ok=True)

    return app


app = create_ocr_app()
