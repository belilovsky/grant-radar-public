"""Portable OCR primitives for PDF and image documents.

The default backend uses Tesseract 5 and pypdfium2. High-accuracy document
models can implement :class:`OCRBackend` and return the same result contract.
"""

from qazstack.ocr.backend import (
    OCRBackend,
    OCRConfig,
    OCRDependencyError,
    OCRError,
    OCRInputError,
    OCRProcessingError,
    TesseractBackend,
    extract_document,
    extract_document_async,
)
from qazstack.ocr.models import (
    OCR_CONTRACT,
    BoundingBox,
    OCRBlock,
    OCRDocument,
    OCRPage,
    OCRQualityReport,
    assess_ocr_quality,
    normalize_ocr_text,
)
from qazstack.ocr.remote import RemoteOCRBackend
from qazstack.ocr.schema import load_ocr_schema

__all__ = [
    "OCR_CONTRACT",
    "BoundingBox",
    "OCRBackend",
    "OCRBlock",
    "OCRConfig",
    "OCRDependencyError",
    "OCRDocument",
    "OCRError",
    "OCRInputError",
    "OCRPage",
    "OCRProcessingError",
    "OCRQualityReport",
    "RemoteOCRBackend",
    "TesseractBackend",
    "assess_ocr_quality",
    "extract_document",
    "extract_document_async",
    "load_ocr_schema",
    "normalize_ocr_text",
]
