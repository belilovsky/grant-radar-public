"""Access to the versioned OCR JSON contract shipped in the wheel."""

from __future__ import annotations

import json
from importlib.resources import files
from typing import Any


def load_ocr_schema() -> dict[str, Any]:
    """Return a fresh copy of the packaged ``qazstack-ocr-v1`` schema."""

    schema_file = files("qazstack.ocr").joinpath("qazstack-ocr-v1.json")
    return json.loads(schema_file.read_text(encoding="utf-8"))
