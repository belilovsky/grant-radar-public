"""OCR backend protocol and the portable Tesseract implementation."""

from __future__ import annotations

import asyncio
import hashlib
import math
from collections import defaultdict
from collections.abc import Callable, Iterable
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol, runtime_checkable

from qazstack.ocr.models import BoundingBox, OCRBlock, OCRDocument, OCRPage, normalize_ocr_text

SUPPORTED_IMAGE_SUFFIXES = frozenset({".bmp", ".gif", ".jpeg", ".jpg", ".png", ".tif", ".tiff", ".webp"})


class OCRError(RuntimeError):
    """Base OCR processing error."""


class OCRDependencyError(OCRError):
    """An optional runtime dependency or system binary is unavailable."""


class OCRInputError(OCRError):
    """The source document cannot be processed safely."""


class OCRProcessingError(OCRError):
    """The selected engine failed while processing a valid source."""


@dataclass(frozen=True, slots=True)
class OCRConfig:
    """Backend-neutral OCR execution options."""

    languages: tuple[str, ...] = ("kaz", "rus", "eng")
    dpi: int = 300
    page_segmentation_mode: int = 3
    timeout_seconds: float | None = 120
    max_pages: int | None = None
    max_input_bytes: int | None = 512 * 1024 * 1024
    max_page_pixels: int | None = 100_000_000

    def __post_init__(self) -> None:
        languages = self.languages
        if isinstance(languages, str):
            languages = tuple(part.strip() for part in languages.replace(",", "+").split("+") if part.strip())
        else:
            languages = tuple(dict.fromkeys(str(language).strip() for language in languages if str(language).strip()))
        if not languages:
            raise ValueError("at least one OCR language is required")
        if not 72 <= self.dpi <= 600:
            raise ValueError("OCR DPI must be between 72 and 600")
        if not 0 <= self.page_segmentation_mode <= 13:
            raise ValueError("Tesseract page segmentation mode must be between 0 and 13")
        if self.timeout_seconds is not None and self.timeout_seconds <= 0:
            raise ValueError("OCR timeout must be positive")
        if self.max_pages is not None and self.max_pages < 1:
            raise ValueError("maximum page count must be positive")
        if self.max_input_bytes is not None and self.max_input_bytes < 1:
            raise ValueError("maximum input size must be positive")
        if self.max_page_pixels is not None and self.max_page_pixels < 1:
            raise ValueError("maximum page pixel count must be positive")
        object.__setattr__(self, "languages", languages)


@runtime_checkable
class OCRBackend(Protocol):
    """Contract implemented by local engines and isolated OCR sidecars."""

    name: str

    def extract(self, source: str | Path, *, config: OCRConfig | None = None) -> OCRDocument:
        """Extract a normalized document from a local source path."""


PDFRenderer = Callable[[Path, OCRConfig], Iterable[tuple[int, Any]]]
ImageLoader = Callable[[Path], Any]


def _file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _parse_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if math.isfinite(result) else None


def _at(values: Any, index: int, default: Any = 0) -> Any:
    try:
        return values[index]
    except (IndexError, KeyError, TypeError):
        return default


class TesseractBackend:
    """Tesseract 5 backend with PDFium rendering and structured line output."""

    name = "tesseract"

    def __init__(
        self,
        *,
        engine: Any | None = None,
        pdf_renderer: PDFRenderer | None = None,
        image_loader: ImageLoader | None = None,
    ) -> None:
        self._engine = engine
        self._pdf_renderer = pdf_renderer or self._render_pdf
        self._image_loader = image_loader or self._load_image

    @staticmethod
    def _load_engine() -> Any:
        try:
            import pytesseract
        except ImportError as exc:
            raise OCRDependencyError("install qazstack[ocr] to use the Tesseract backend") from exc
        return pytesseract

    @staticmethod
    def _load_image(path: Path) -> Any:
        try:
            from PIL import Image
        except ImportError as exc:
            raise OCRDependencyError("Pillow is required to process image documents") from exc
        with Image.open(path) as image:
            return image.convert("RGB").copy()

    @staticmethod
    def _render_pdf(path: Path, config: OCRConfig) -> Iterable[tuple[int, Any]]:
        try:
            import pypdfium2
        except ImportError as exc:
            raise OCRDependencyError("pypdfium2 is required to render PDF documents") from exc

        document = pypdfium2.PdfDocument(str(path))
        try:
            page_count = len(document)
            if config.max_pages is not None:
                page_count = min(page_count, config.max_pages)
            for index in range(page_count):
                page = document[index]
                try:
                    scale = config.dpi / 72
                    page_width, page_height = page.get_size()
                    rendered_pixels = math.ceil(page_width * scale) * math.ceil(page_height * scale)
                    if config.max_page_pixels is not None and rendered_pixels > config.max_page_pixels:
                        raise OCRInputError(
                            f"page {index + 1} would render to {rendered_pixels:,} pixels, "
                            f"above the {config.max_page_pixels:,} pixel limit"
                        )
                    bitmap = page.render(scale=scale)
                    try:
                        source_image = bitmap.to_pil()
                        try:
                            image = source_image.convert("RGB").copy()
                        finally:
                            source_image.close()
                    finally:
                        close_bitmap = getattr(bitmap, "close", None)
                        if callable(close_bitmap):
                            close_bitmap()
                    yield index + 1, image
                finally:
                    close_page = getattr(page, "close", None)
                    if callable(close_page):
                        close_page()
        finally:
            close_document = getattr(document, "close", None)
            if callable(close_document):
                close_document()

    @staticmethod
    def _page_size(image: Any) -> tuple[int, int]:
        size = getattr(image, "size", None)
        if not isinstance(size, tuple) or len(size) != 2:
            raise OCRInputError("OCR page image does not expose width and height")
        width, height = (int(size[0]), int(size[1]))
        if width < 1 or height < 1:
            raise OCRInputError("OCR page image dimensions must be positive")
        return width, height

    def _recognize_page(self, image: Any, page_number: int, config: OCRConfig) -> OCRPage:
        engine = self._engine or self._load_engine()
        width, height = self._page_size(image)
        pixels = width * height
        if config.max_page_pixels is not None and pixels > config.max_page_pixels:
            raise OCRInputError(
                f"page {page_number} contains {pixels:,} pixels, above the {config.max_page_pixels:,} pixel limit"
            )
        kwargs: dict[str, Any] = {
            "lang": "+".join(config.languages),
            "config": f"--psm {config.page_segmentation_mode}",
        }
        if config.timeout_seconds is not None:
            kwargs["timeout"] = config.timeout_seconds

        warning: str | None = None
        output = getattr(getattr(engine, "Output", None), "DICT", None)
        data: dict[str, Any] | None = None
        if output is not None and callable(getattr(engine, "image_to_data", None)):
            try:
                candidate = engine.image_to_data(image, output_type=output, **kwargs)
                if isinstance(candidate, dict):
                    data = candidate
            except Exception as exc:  # Backend fallback keeps plain OCR available.
                warning = f"structured Tesseract output unavailable: {type(exc).__name__}"

        blocks = self._blocks_from_data(data) if data else ()
        text = "\n".join(block.text for block in blocks if block.text)
        if not text:
            try:
                text = normalize_ocr_text(engine.image_to_string(image, **kwargs))
            except Exception as exc:
                raise OCRProcessingError(f"Tesseract failed on page {page_number}: {exc}") from exc
            blocks = (OCRBlock(text=text, order=0),) if text else ()

        metadata: dict[str, Any] = {
            "dpi": config.dpi,
            "page_segmentation_mode": config.page_segmentation_mode,
        }
        if warning:
            metadata["warning"] = warning
        return OCRPage(
            page_number=page_number,
            width=width,
            height=height,
            text=text,
            blocks=blocks,
            metadata=metadata,
        )

    def _runtime_metadata(self, config: OCRConfig) -> dict[str, Any]:
        engine = self._engine or self._load_engine()
        metadata: dict[str, Any] = {}
        get_languages = getattr(engine, "get_languages", None)
        if callable(get_languages):
            try:
                available_languages = set(get_languages(config=""))
            except Exception as exc:
                raise OCRDependencyError(f"cannot query Tesseract language packs: {exc}") from exc
            missing_languages = sorted(set(config.languages) - available_languages)
            if missing_languages:
                raise OCRDependencyError("missing Tesseract language packs: " + ", ".join(missing_languages))
        get_version = getattr(engine, "get_tesseract_version", None)
        if callable(get_version):
            try:
                metadata["engine_version"] = str(get_version())
            except Exception as exc:
                raise OCRDependencyError(f"cannot query Tesseract version: {exc}") from exc
        return metadata

    @staticmethod
    def _blocks_from_data(data: dict[str, Any]) -> tuple[OCRBlock, ...]:
        groups: dict[tuple[int, int, int], list[tuple[str, int, int, int, int, float | None]]] = defaultdict(list)
        text_values = data.get("text") or ()
        for index, raw_text in enumerate(text_values):
            text = normalize_ocr_text(raw_text)
            if not text:
                continue
            confidence_value = _parse_float(_at(data.get("conf"), index, -1))
            confidence = None if confidence_value is None or confidence_value < 0 else min(1.0, confidence_value / 100)
            left = max(0, int(_at(data.get("left"), index)))
            top = max(0, int(_at(data.get("top"), index)))
            width = max(0, int(_at(data.get("width"), index)))
            height = max(0, int(_at(data.get("height"), index)))
            key = (
                int(_at(data.get("block_num"), index, 0)),
                int(_at(data.get("par_num"), index, 0)),
                int(_at(data.get("line_num"), index, index + 1)),
            )
            groups[key].append((text, left, top, width, height, confidence))

        blocks: list[OCRBlock] = []
        for order, words in enumerate(groups.values()):
            left = min(word[1] for word in words)
            top = min(word[2] for word in words)
            right = max(word[1] + word[3] for word in words)
            bottom = max(word[2] + word[4] for word in words)
            confidences = [word[5] for word in words if word[5] is not None]
            blocks.append(
                OCRBlock(
                    text=" ".join(word[0] for word in words),
                    order=order,
                    bbox=BoundingBox(left=left, top=top, right=right, bottom=bottom),
                    confidence=sum(confidences) / len(confidences) if confidences else None,
                )
            )
        return tuple(blocks)

    def extract(self, source: str | Path, *, config: OCRConfig | None = None) -> OCRDocument:
        config = config or OCRConfig()
        path = Path(source).expanduser()
        if not path.is_file():
            raise OCRInputError(f"OCR source does not exist or is not a file: {path}")
        input_bytes = path.stat().st_size
        if config.max_input_bytes is not None and input_bytes > config.max_input_bytes:
            raise OCRInputError(f"OCR source is {input_bytes:,} bytes, above the {config.max_input_bytes:,} byte limit")

        suffix = path.suffix.lower()
        if suffix == ".pdf":
            rendered_pages = self._pdf_renderer(path, config)
        elif suffix in SUPPORTED_IMAGE_SUFFIXES:
            rendered_pages = ((1, self._image_loader(path)),)
        else:
            raise OCRInputError(f"unsupported OCR source type: {suffix or '<none>'}")

        runtime_metadata = self._runtime_metadata(config)
        pages: list[OCRPage] = []
        try:
            for page_number, image in rendered_pages:
                if config.max_pages is not None and len(pages) >= config.max_pages:
                    close_image = getattr(image, "close", None)
                    if callable(close_image):
                        close_image()
                    break
                try:
                    pages.append(self._recognize_page(image, int(page_number), config))
                finally:
                    close_image = getattr(image, "close", None)
                    if callable(close_image):
                        close_image()
        except OCRError:
            raise
        except Exception as exc:
            raise OCRProcessingError(f"failed to process {path.name}: {exc}") from exc

        if not pages:
            raise OCRProcessingError(f"no pages were rendered from {path.name}")
        return OCRDocument(
            source=path.name,
            engine=self.name,
            languages=config.languages,
            pages=tuple(pages),
            metadata={
                "input_sha256": _file_sha256(path),
                "input_bytes": input_bytes,
                "dpi": config.dpi,
                "page_segmentation_mode": config.page_segmentation_mode,
                **runtime_metadata,
            },
        )


def extract_document(
    source: str | Path,
    *,
    backend: OCRBackend | None = None,
    config: OCRConfig | None = None,
) -> OCRDocument:
    """Extract a document with an explicit backend or the CPU-safe default."""

    selected = backend or TesseractBackend()
    return selected.extract(source, config=config)


async def extract_document_async(
    source: str | Path,
    *,
    backend: OCRBackend | None = None,
    config: OCRConfig | None = None,
) -> OCRDocument:
    """Run synchronous OCR without blocking an async application event loop."""

    return await asyncio.to_thread(extract_document, source, backend=backend, config=config)
