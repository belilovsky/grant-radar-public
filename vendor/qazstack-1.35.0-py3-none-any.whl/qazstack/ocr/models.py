"""Dependency-free OCR result models and quality checks."""

from __future__ import annotations

import math
import re
import unicodedata
from dataclasses import dataclass, field
from typing import Any, Mapping

OCR_CONTRACT = "qazstack-ocr-v1"


def _weighted_confidence(values: list[tuple[float, int]]) -> float | None:
    total_weight = sum(weight for _, weight in values)
    if not values or total_weight < 1:
        return None
    return sum(value * weight for value, weight in values) / total_weight


def normalize_ocr_text(value: object) -> str:
    """Normalize OCR whitespace without applying project-specific content rules."""

    text = unicodedata.normalize("NFC", str(value or "")).replace("\r\n", "\n").replace("\r", "\n")
    lines = [re.sub(r"[ \t]+", " ", line).strip() for line in text.split("\n")]
    return re.sub(r"\n{3,}", "\n\n", "\n".join(lines)).strip()


@dataclass(frozen=True, slots=True)
class BoundingBox:
    """Axis-aligned pixel coordinates in the source page image."""

    left: float
    top: float
    right: float
    bottom: float

    def __post_init__(self) -> None:
        values = (self.left, self.top, self.right, self.bottom)
        if not all(math.isfinite(value) for value in values):
            raise ValueError("bounding-box coordinates must be finite")
        if self.left < 0 or self.top < 0 or self.right < self.left or self.bottom < self.top:
            raise ValueError("invalid bounding-box coordinates")

    @property
    def width(self) -> float:
        return self.right - self.left

    @property
    def height(self) -> float:
        return self.bottom - self.top

    def to_dict(self) -> dict[str, float]:
        return {
            "left": self.left,
            "top": self.top,
            "right": self.right,
            "bottom": self.bottom,
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> BoundingBox:
        return cls(*(float(value[key]) for key in ("left", "top", "right", "bottom")))


@dataclass(frozen=True, slots=True)
class OCRBlock:
    """One text block in reading order."""

    text: str
    order: int
    bbox: BoundingBox | None = None
    confidence: float | None = None
    kind: str = "text"

    def __post_init__(self) -> None:
        object.__setattr__(self, "text", normalize_ocr_text(self.text))
        if self.order < 0:
            raise ValueError("block order must be non-negative")
        if self.confidence is not None and not 0 <= self.confidence <= 1:
            raise ValueError("block confidence must be between 0 and 1")

    def to_dict(self) -> dict[str, Any]:
        return {
            "text": self.text,
            "order": self.order,
            "bbox": self.bbox.to_dict() if self.bbox else None,
            "confidence": self.confidence,
            "kind": self.kind,
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> OCRBlock:
        bbox = value.get("bbox")
        return cls(
            text=str(value.get("text") or ""),
            order=int(value.get("order") or 0),
            bbox=BoundingBox.from_dict(bbox) if isinstance(bbox, Mapping) else None,
            confidence=float(value["confidence"]) if value.get("confidence") is not None else None,
            kind=str(value.get("kind") or "text"),
        )


@dataclass(frozen=True, slots=True)
class OCRPage:
    """Normalized OCR output for one document page."""

    page_number: int
    width: int
    height: int
    text: str = ""
    blocks: tuple[OCRBlock, ...] = ()
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.page_number < 1:
            raise ValueError("page number must start at 1")
        if self.width < 1 or self.height < 1:
            raise ValueError("page dimensions must be positive")
        blocks = tuple(sorted(self.blocks, key=lambda block: block.order))
        object.__setattr__(self, "blocks", blocks)
        text = self.text or "\n".join(block.text for block in blocks if block.text)
        object.__setattr__(self, "text", normalize_ocr_text(text))
        object.__setattr__(self, "metadata", dict(self.metadata))

    @property
    def confidence(self) -> float | None:
        values = [
            (block.confidence, max(1, len(block.text.replace(" ", ""))))
            for block in self.blocks
            if block.confidence is not None
        ]
        return _weighted_confidence(values)

    def to_dict(self) -> dict[str, Any]:
        return {
            "page_number": self.page_number,
            "width": self.width,
            "height": self.height,
            "text": self.text,
            "confidence": self.confidence,
            "blocks": [block.to_dict() for block in self.blocks],
            "metadata": dict(self.metadata),
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> OCRPage:
        return cls(
            page_number=int(value["page_number"]),
            width=int(value["width"]),
            height=int(value["height"]),
            text=str(value.get("text") or ""),
            blocks=tuple(OCRBlock.from_dict(item) for item in value.get("blocks", ()) if isinstance(item, Mapping)),
            metadata=value.get("metadata") if isinstance(value.get("metadata"), Mapping) else {},
        )


@dataclass(frozen=True, slots=True)
class OCRQualityReport:
    """Deterministic review signal for an OCR result."""

    accepted: bool
    page_count: int
    character_count: int
    mean_confidence: float | None
    blank_pages: tuple[int, ...]
    low_confidence_pages: tuple[int, ...]

    @property
    def requires_review(self) -> bool:
        return not self.accepted

    def to_dict(self) -> dict[str, Any]:
        return {
            "accepted": self.accepted,
            "requires_review": self.requires_review,
            "page_count": self.page_count,
            "character_count": self.character_count,
            "mean_confidence": self.mean_confidence,
            "blank_pages": list(self.blank_pages),
            "low_confidence_pages": list(self.low_confidence_pages),
        }


@dataclass(frozen=True, slots=True)
class OCRDocument:
    """Portable OCR document contract shared by local and remote backends."""

    source: str
    engine: str
    languages: tuple[str, ...]
    pages: tuple[OCRPage, ...]
    metadata: Mapping[str, Any] = field(default_factory=dict)
    contract: str = OCR_CONTRACT

    def __post_init__(self) -> None:
        if self.contract != OCR_CONTRACT:
            raise ValueError(f"unsupported OCR contract: {self.contract}")
        if not self.source.strip():
            raise ValueError("OCR source is required")
        if not self.engine.strip():
            raise ValueError("OCR engine name is required")
        pages = tuple(sorted(self.pages, key=lambda page: page.page_number))
        if not pages:
            raise ValueError("OCR document must contain at least one page")
        if len({page.page_number for page in pages}) != len(pages):
            raise ValueError("duplicate OCR page numbers")
        object.__setattr__(self, "pages", pages)
        languages = tuple(dict.fromkeys(language for language in self.languages if language))
        if not languages:
            raise ValueError("OCR document must contain at least one language")
        object.__setattr__(self, "languages", languages)
        object.__setattr__(self, "metadata", dict(self.metadata))

    @property
    def text(self) -> str:
        return "\n\n".join(page.text for page in self.pages if page.text).strip()

    @property
    def confidence(self) -> float | None:
        values = [
            (page.confidence, max(1, len(page.text.replace(" ", ""))))
            for page in self.pages
            if page.confidence is not None
        ]
        return _weighted_confidence(values)

    def to_markdown(self, *, page_heading: str = "Page {page_number}", fenced: bool = False) -> str:
        parts: list[str] = []
        for page in self.pages:
            heading = page_heading.format(page_number=page.page_number)
            body = f"```text\n{page.text}\n```" if fenced else page.text
            parts.append(f"## {heading}\n\n{body}".rstrip())
        return "\n\n".join(parts).strip()

    def quality(self, *, min_confidence: float = 0.65, min_characters_per_page: int = 20) -> OCRQualityReport:
        return assess_ocr_quality(
            self,
            min_confidence=min_confidence,
            min_characters_per_page=min_characters_per_page,
        )

    def to_dict(self) -> dict[str, Any]:
        quality = self.quality()
        return {
            "contract": self.contract,
            "source": self.source,
            "engine": self.engine,
            "languages": list(self.languages),
            "text": self.text,
            "confidence": self.confidence,
            "pages": [page.to_dict() for page in self.pages],
            "quality": quality.to_dict(),
            "metadata": dict(self.metadata),
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> OCRDocument:
        return cls(
            contract=str(value.get("contract") or OCR_CONTRACT),
            source=str(value.get("source") or ""),
            engine=str(value.get("engine") or ""),
            languages=tuple(str(item) for item in value.get("languages", ())),
            pages=tuple(OCRPage.from_dict(item) for item in value.get("pages", ()) if isinstance(item, Mapping)),
            metadata=value.get("metadata") if isinstance(value.get("metadata"), Mapping) else {},
        )


def assess_ocr_quality(
    document: OCRDocument,
    *,
    min_confidence: float = 0.65,
    min_characters_per_page: int = 20,
) -> OCRQualityReport:
    """Return a conservative review decision without modifying OCR content."""

    if not 0 <= min_confidence <= 1:
        raise ValueError("minimum confidence must be between 0 and 1")
    if min_characters_per_page < 0:
        raise ValueError("minimum characters per page must be non-negative")

    blank = tuple(page.page_number for page in document.pages if len(page.text.strip()) < min_characters_per_page)
    low_confidence = tuple(
        page.page_number for page in document.pages if page.confidence is None or page.confidence < min_confidence
    )
    accepted = bool(document.pages) and not blank and not low_confidence
    return OCRQualityReport(
        accepted=accepted,
        page_count=len(document.pages),
        character_count=len(document.text),
        mean_confidence=document.confidence,
        blank_pages=blank,
        low_confidence_pages=low_confidence,
    )
