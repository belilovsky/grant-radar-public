"""HTTP client backend for the isolated QazStack OCR service."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import httpx

from qazstack.ocr.backend import (
    OCRBackend,
    OCRConfig,
    OCRDependencyError,
    OCRInputError,
    OCRProcessingError,
)
from qazstack.ocr.models import OCRDocument


class RemoteOCRBackend(OCRBackend):
    """Send documents to a service that returns ``qazstack-ocr-v1``."""

    name = "qazstack-remote"

    def __init__(
        self,
        base_url: str,
        *,
        api_key: str | None = None,
        timeout_seconds: float = 300,
        transport: httpx.BaseTransport | None = None,
    ) -> None:
        if not base_url.strip():
            raise ValueError("OCR service base URL is required")
        if timeout_seconds <= 0:
            raise ValueError("OCR service timeout must be positive")
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.timeout_seconds = timeout_seconds
        self.transport = transport

    def extract(self, source: str | Path, *, config: OCRConfig | None = None) -> OCRDocument:
        path = Path(source).expanduser()
        if not path.is_file():
            raise OCRInputError(f"OCR source does not exist or is not a file: {path}")

        selected = config or OCRConfig()
        if selected.max_input_bytes is not None and path.stat().st_size > selected.max_input_bytes:
            raise OCRInputError(
                f"OCR source is {path.stat().st_size:,} bytes, above the {selected.max_input_bytes:,} byte limit"
            )
        data: dict[str, str] = {
            "languages": "+".join(selected.languages),
            "dpi": str(selected.dpi),
            "page_segmentation_mode": str(selected.page_segmentation_mode),
        }
        if selected.timeout_seconds is not None:
            data["timeout_seconds"] = str(selected.timeout_seconds)
        if selected.max_pages is not None:
            data["max_pages"] = str(selected.max_pages)

        headers = {"Accept": "application/json"}
        if self.api_key:
            headers["X-API-Key"] = self.api_key

        try:
            with (
                path.open("rb") as handle,
                httpx.Client(
                    timeout=self.timeout_seconds,
                    transport=self.transport,
                ) as client,
            ):
                response = client.post(
                    f"{self.base_url}/v1/ocr",
                    data=data,
                    files={"file": (path.name, handle, "application/octet-stream")},
                    headers=headers,
                )
        except (httpx.TimeoutException, httpx.NetworkError) as exc:
            raise OCRDependencyError(f"OCR service is unavailable: {exc}") from exc
        except httpx.HTTPError as exc:
            raise OCRProcessingError(f"OCR service request failed: {exc}") from exc

        if response.status_code in {400, 413, 422}:
            raise OCRInputError(self._error_detail(response))
        if response.status_code in {401, 403, 429, 502, 503, 504}:
            raise OCRDependencyError(self._error_detail(response))
        if response.is_error:
            raise OCRProcessingError(self._error_detail(response))

        try:
            payload: Any = response.json()
            if not isinstance(payload, dict):
                raise ValueError("response is not an object")
            document = OCRDocument.from_dict(payload)
        except (TypeError, ValueError) as exc:
            raise OCRProcessingError(f"OCR service returned an invalid contract: {exc}") from exc

        metadata = dict(document.metadata)
        metadata.setdefault("remote_service", self.base_url)
        return OCRDocument(
            source=document.source,
            engine=document.engine,
            languages=document.languages,
            pages=document.pages,
            metadata=metadata,
            contract=document.contract,
        )

    @staticmethod
    def _error_detail(response: httpx.Response) -> str:
        try:
            payload = response.json()
        except ValueError:
            payload = None
        if isinstance(payload, dict) and payload.get("detail"):
            return str(payload["detail"])
        return f"OCR service returned HTTP {response.status_code}"
