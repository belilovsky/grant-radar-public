"""EngineRegistry – central catalog of analytical engines.

Supports:
- Registration by instance or factory
- Discovery by name, category, or tags
- Batch execution with fault isolation
- Built-in engines factory (``with_builtins()``)
- Health monitoring and timing
"""

from __future__ import annotations

import asyncio
import logging
import time
from datetime import datetime, timezone
from typing import Any, Optional

from .engine import BaseEngine, EngineCategory, EngineResult

logger = logging.getLogger(__name__)


class EngineRegistry:
    """Central registry for analytical engines."""

    def __init__(self) -> None:
        self._engines: dict[str, BaseEngine] = {}
        self._disabled: set[str] = set()
        self._run_history: list[dict[str, Any]] = []

    # ── Registration ──────────────────────────────────────────────

    def register(self, engine: BaseEngine) -> None:
        """Register an engine instance."""
        if engine.name in self._engines:
            logger.warning(
                "Overwriting engine '%s' (v%s → v%s)",
                engine.name,
                self._engines[engine.name].version,
                engine.version,
            )
        self._engines[engine.name] = engine
        logger.info("Registered engine: %s v%s (%s)", engine.name, engine.version, engine.category.value)

    def unregister(self, name: str) -> None:
        """Remove an engine."""
        self._engines.pop(name, None)
        self._disabled.discard(name)

    def disable(self, name: str) -> None:
        """Disable an engine (skipped during batch runs)."""
        self._disabled.add(name)

    def enable(self, name: str) -> None:
        """Re-enable a disabled engine."""
        self._disabled.discard(name)

    # ── Discovery ─────────────────────────────────────────────────

    def get(self, name: str) -> Optional[BaseEngine]:
        """Get engine by name."""
        return self._engines.get(name)

    @property
    def all_engines(self) -> list[BaseEngine]:
        """All registered engines."""
        return list(self._engines.values())

    @property
    def active_engines(self) -> list[BaseEngine]:
        """Enabled engines only."""
        return [e for n, e in self._engines.items() if n not in self._disabled]

    def by_category(self, category: EngineCategory) -> list[BaseEngine]:
        """Filter engines by category."""
        return [e for e in self._engines.values() if e.category == category]

    def names(self) -> list[str]:
        """List all registered engine names."""
        return list(self._engines.keys())

    # ── Execution ─────────────────────────────────────────────────

    async def run_one(
        self,
        name: str,
        inputs: dict[str, Any],
        cfg: Optional[dict[str, Any]] = None,
    ) -> EngineResult:
        """Run a single engine by name."""
        engine = self._engines.get(name)
        if engine is None:
            return EngineResult(engine=name, error=f"Engine '{name}' not found", confidence=0.0)
        if name in self._disabled:
            return EngineResult(engine=name, error=f"Engine '{name}' is disabled", confidence=0.0)

        effective_cfg = {**engine.default_config(), **(cfg or {})}

        t0 = time.monotonic()
        result = await engine.safe_run(inputs, effective_cfg)
        elapsed_ms = (time.monotonic() - t0) * 1000

        self._record_run(name, result, elapsed_ms)
        return result

    async def run_many(
        self,
        engine_names: list[str],
        inputs: dict[str, Any],
        cfg: Optional[dict[str, Any]] = None,
    ) -> dict[str, EngineResult]:
        """Run multiple engines in parallel with fault isolation."""
        if not engine_names:
            engine_names = [e.name for e in self.active_engines]

        t0 = time.monotonic()

        tasks = []
        valid_names = []
        for name in engine_names:
            engine = self._engines.get(name)
            if engine is None:
                continue
            if name in self._disabled:
                continue
            effective_cfg = {**engine.default_config(), **(cfg or {})}
            tasks.append(engine.safe_run(inputs, effective_cfg))
            valid_names.append(name)

        if not tasks:
            return {}

        results_list = await asyncio.gather(*tasks)
        elapsed_ms = (time.monotonic() - t0) * 1000

        results = {}
        for name, result in zip(valid_names, results_list):
            results[name] = result
            self._record_run(name, result, elapsed_ms / len(tasks))

        logger.info(
            "Batch run: %d engines in %.0fms (%d ok, %d failed)",
            len(results),
            elapsed_ms,
            sum(1 for r in results.values() if r.ok),
            sum(1 for r in results.values() if not r.ok),
        )

        return results

    async def run_all(
        self,
        inputs: dict[str, Any],
        cfg: Optional[dict[str, Any]] = None,
    ) -> dict[str, EngineResult]:
        """Run all active engines."""
        return await self.run_many(
            [e.name for e in self.active_engines],
            inputs,
            cfg,
        )

    # ── Factory ───────────────────────────────────────────────────

    @classmethod
    def with_builtins(cls) -> "EngineRegistry":
        """Create registry pre-loaded with built-in PSSR-compatible engines.

        Built-in engines provide thin wrappers around the core PSSR calculations,
        making them accessible through the unified analytics interface.
        """
        from .builtins import get_builtin_engines

        registry = cls()
        for engine in get_builtin_engines():
            registry.register(engine)
        return registry

    # ── Status ────────────────────────────────────────────────────

    def status(self) -> dict[str, Any]:
        """Registry status for API."""
        return {
            "total_engines": len(self._engines),
            "active_engines": len(self.active_engines),
            "disabled": sorted(self._disabled),
            "engines": [e.info() for e in self._engines.values()],
            "recent_runs": self._run_history[-10:],
        }

    def _record_run(self, name: str, result: EngineResult, elapsed_ms: float) -> None:
        entry = {
            "engine": name,
            "ok": result.ok,
            "value": result.value,
            "confidence": result.confidence,
            "elapsed_ms": round(elapsed_ms, 1),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        if result.error:
            entry["error"] = result.error
        self._run_history.append(entry)
        if len(self._run_history) > 100:
            self._run_history = self._run_history[-50:]
