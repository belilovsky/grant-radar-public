"""AnalyticsPipeline – orchestrates Entity Store-aware analytics.

Workflow:
1. Accept entity IDs or raw inputs
2. Enrich inputs from Entity Store (mentions, relations, context)
3. Run selected engines via EngineRegistry
4. Persist results to AnalysisResult table (optional)
5. Return structured AnalysisRun

This is the main entry point for running analytics across projects.
"""

from __future__ import annotations

import hashlib
import json
import logging
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional

from .engine import EngineResult
from .registry import EngineRegistry

logger = logging.getLogger(__name__)


@dataclass
class AnalysisRun:
    """Result of a complete analytics pipeline run.

    Groups results from multiple engines with metadata about the run.
    """
    run_id: str
    project: str
    engines_requested: list[str]
    results: dict[str, EngineResult]
    entity_ids: list[int] = field(default_factory=list)
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    elapsed_ms: float = 0.0

    @property
    def ok_count(self) -> int:
        return sum(1 for r in self.results.values() if r.ok)

    @property
    def error_count(self) -> int:
        return sum(1 for r in self.results.values() if not r.ok)

    def get(self, engine_name: str) -> Optional[EngineResult]:
        return self.results.get(engine_name)

    def values(self) -> dict[str, Optional[float]]:
        """Extract primary values from all engines."""
        return {name: r.value for name, r in self.results.items()}

    def signals(self) -> dict[str, float]:
        """Merge all signals into a flat dict."""
        merged: dict[str, float] = {}
        for r in self.results.values():
            merged.update(r.signals)
        return merged

    def to_dict(self) -> dict[str, Any]:
        return {
            "run_id": self.run_id,
            "project": self.project,
            "engines_requested": self.engines_requested,
            "results": {n: r.to_dict() for n, r in self.results.items()},
            "entity_ids": self.entity_ids,
            "timestamp": self.timestamp,
            "elapsed_ms": round(self.elapsed_ms, 1),
            "ok_count": self.ok_count,
            "error_count": self.error_count,
        }


def _inputs_hash(inputs: dict[str, Any]) -> str:
    """Deterministic hash of inputs for dedup/caching."""
    serialized = json.dumps(inputs, sort_keys=True, default=str)
    return hashlib.sha256(serialized.encode()).hexdigest()[:16]


class AnalyticsPipeline:
    """Orchestrates analytics runs with Entity Store integration.

    Args:
        registry: EngineRegistry with registered engines
        entity_store: optional EntityStore for enrichment
        persist: whether to persist results to DB (requires session)
    """

    def __init__(
        self,
        registry: EngineRegistry,
        entity_store: Any = None,
        persist: bool = False,
    ) -> None:
        self.registry = registry
        self.entity_store = entity_store
        self.persist = persist

    async def analyze(
        self,
        inputs: dict[str, Any],
        project: str = "default",
        engines: Optional[list[str]] = None,
        cfg: Optional[dict[str, Any]] = None,
        entity_ids: Optional[list[int]] = None,
        session: Any = None,
    ) -> AnalysisRun:
        """Run analytics pipeline.

        Args:
            inputs: raw input data for engines
            project: project identifier
            engines: list of engine names (None = all active)
            cfg: shared configuration (merged with engine defaults)
            entity_ids: optional entity IDs to link results to
            session: DB session for persistence and entity enrichment

        Returns:
            AnalysisRun with all results
        """
        import time
        t0 = time.monotonic()

        run_id = uuid.uuid4().hex[:12]
        engine_names = engines or [e.name for e in self.registry.active_engines]
        entity_ids = entity_ids or []

        # Enrich inputs from Entity Store if available
        if self.entity_store and entity_ids and session:
            enriched = await self._enrich_from_entities(
                session, entity_ids, inputs
            )
            inputs = {**inputs, **enriched}

        # Run engines
        results = await self.registry.run_many(engine_names, inputs, cfg)

        elapsed = (time.monotonic() - t0) * 1000

        run = AnalysisRun(
            run_id=run_id,
            project=project,
            engines_requested=engine_names,
            results=results,
            entity_ids=entity_ids,
            elapsed_ms=elapsed,
        )

        # Persist results if enabled
        if self.persist and session:
            await self._persist_results(session, run, inputs)

        logger.info(
            "Analysis run %s: %d engines, %d ok, %d failed, %.0fms",
            run_id, len(results), run.ok_count, run.error_count, elapsed,
        )

        return run

    async def analyze_entity(
        self,
        session: Any,
        entity_id: int,
        project: str,
        engines: Optional[list[str]] = None,
        cfg: Optional[dict[str, Any]] = None,
        extra_inputs: Optional[dict[str, Any]] = None,
    ) -> AnalysisRun:
        """Run analytics for a specific entity.

        Fetches entity data from the store, builds inputs from
        mentions/relations context, and runs engines.
        """
        inputs = extra_inputs or {}

        if self.entity_store:
            entity_data = await self._load_entity_context(session, entity_id)
            inputs = {**entity_data, **inputs}

        return await self.analyze(
            inputs=inputs,
            project=project,
            engines=engines,
            cfg=cfg,
            entity_ids=[entity_id],
            session=session,
        )

    async def _enrich_from_entities(
        self,
        session: Any,
        entity_ids: list[int],
        base_inputs: dict[str, Any],
    ) -> dict[str, Any]:
        """Enrich inputs with Entity Store data."""
        enriched: dict[str, Any] = {}

        if not self.entity_store:
            return enriched

        try:
            for eid in entity_ids:
                entity = await self.entity_store.get_entity(session, entity_id=eid)
                if entity:
                    enriched.setdefault("entity_names", []).append(entity.name)
                    enriched.setdefault("entity_types", []).append(entity.entity_type)

                mentions = await self.entity_store.get_mentions(
                    session, entity_id=eid, limit=100
                )
                enriched.setdefault("mention_count", 0)
                enriched["mention_count"] += len(mentions)

                projects = {m.source_project for m in mentions}
                enriched.setdefault("cross_project_count", 0)
                enriched["cross_project_count"] = len(projects)

        except Exception as e:
            logger.warning("Entity enrichment failed: %s", e)

        return enriched

    async def _load_entity_context(
        self, session: Any, entity_id: int
    ) -> dict[str, Any]:
        """Load full entity context for analysis."""
        context: dict[str, Any] = {"entity_id": entity_id}

        if not self.entity_store:
            return context

        try:
            entity = await self.entity_store.get_entity(session, entity_id=entity_id)
            if entity:
                context["entity_name"] = entity.name
                context["entity_type"] = entity.entity_type

            mentions = await self.entity_store.get_mentions(
                session, entity_id=entity_id, limit=200
            )
            context["mention_count"] = len(mentions)
            context["source_projects"] = list({m.source_project for m in mentions})

            relations = await self.entity_store.get_relations(
                session, entity_id=entity_id, limit=100
            )
            context["relation_count"] = len(relations)

        except Exception as e:
            logger.warning("Entity context load failed: %s", e)

        return context

    async def _persist_results(
        self,
        session: Any,
        run: AnalysisRun,
        inputs: dict[str, Any],
    ) -> None:
        """Persist analysis results to database."""
        try:
            from .models import AnalysisResult

            ih = _inputs_hash(inputs)

            for name, result in run.results.items():
                engine = self.registry.get(name)
                row = AnalysisResult(
                    engine=name,
                    version=engine.version if engine else "?",
                    project=run.project,
                    run_id=run.run_id,
                    value=result.value,
                    confidence=result.confidence,
                    signals=result.signals,
                    metadata_json=result.metadata,
                    inputs_hash=ih,
                    entity_id=run.entity_ids[0] if run.entity_ids else None,
                    error=result.error,
                )
                session.add(row)

            await session.flush()
        except Exception as e:
            logger.error("Failed to persist analysis results: %s", e)
