"""Generic state machine with hysteresis transitions.

Prevents oscillation by requiring a configurable number of consecutive
steps above/below a threshold before committing a transition. Users
subclass :class:`State` with their own states and supply a transition
table that maps ``(from_state, to_state)`` pairs to numeric thresholds.
"""

from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Any


class State(str, Enum):
    """Base class for user-defined state enumerations.

    Subclass and add your own members::

        class TrafficLight(State):
            RED = "red"
            YELLOW = "yellow"
            GREEN = "green"
    """


class StateMachine:
    """State machine with hysteresis transitions.

    Hysteresis prevents rapid oscillation between adjacent states by
    requiring the proposed state to be observed for ``n_up`` (escalation)
    or ``n_down`` (de-escalation) consecutive calls before the machine
    commits to the new state.

    Args:
        states: The :class:`State` enum class that defines valid states.
        transitions: Mapping of ``(from_state_value, to_state_value)``
            to a numeric threshold.  The threshold is compared against
            the ``value`` argument passed to :meth:`update`.  A
            transition fires when ``value >= threshold``.  If a pair is
            absent, the transition is not threshold-driven (use the
            ``force`` parameter of :meth:`update` instead).
        initial: Starting state.  Defaults to the first member of
            ``states``.
        n_up: Consecutive steps required to commit an escalation
            (transition to a "higher" state by enum definition order).
        n_down: Consecutive steps required to commit a de-escalation.
        hysteresis: *Fractional* hysteresis gap applied on de-escalation:
            the effective de-escalation threshold is
            ``threshold * (1 + hysteresis)``.  Default ``0.05`` (5 %).
            Set to ``0.0`` for symmetric transitions.

    Example::

        from enum import auto
        from qazstack.analytics.state_machine import State, StateMachine

        class Level(State):
            LOW = "low"
            MEDIUM = "medium"
            HIGH = "high"

        sm = StateMachine(
            states=Level,
            transitions={
                ("low", "medium"): 0.4,
                ("medium", "high"): 0.7,
                ("high", "medium"): 0.5,
                ("medium", "low"): 0.2,
            },
            initial=Level.LOW,
            n_up=2,
            n_down=3,
        )
        state = sm.update(0.8)  # → LOW (need 2 consecutive triggers)
        state = sm.update(0.8)  # → MEDIUM (committed)
    """

    def __init__(
        self,
        states: type[State],
        transitions: dict[tuple[str, str], float],
        initial: State | None = None,
        n_up: int = 2,
        n_down: int = 3,
        hysteresis: float = 0.05,
    ) -> None:
        members = list(states)
        if not members:
            raise ValueError("states enum must have at least one member")

        self._states = states
        self._members: list[State] = members
        self._order: dict[str, int] = {s.value: i for i, s in enumerate(members)}
        self._transitions = transitions
        self.n_up = n_up
        self.n_down = n_down
        self.hysteresis = hysteresis

        self.current: State = initial if initial is not None else members[0]

        # History: list of (timestamp, state) tuples
        self.history: list[tuple[datetime, State]] = [
            (datetime.now(timezone.utc), self.current)
        ]

        # Internal counters
        self._up_counter: int = 0
        self._down_counter: int = 0
        self._pending_up: State | None = None
        self._pending_down: State | None = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def update(self, value: float, **kwargs: Any) -> State:
        """Evaluate *value* and possibly transition to a new state.

        The machine looks for the best matching transition from the
        current state given *value*, applies hysteresis counters, and
        returns the current (possibly updated) state.

        Args:
            value: Numeric signal to evaluate against transition
                thresholds.
            **kwargs: Reserved for future extensions (e.g. per-call
                override configs).

        Returns:
            The current :class:`State` after evaluation.
        """
        proposed = self._propose(value)
        return self._apply(proposed)

    def force(self, state: State) -> State:
        """Immediately transition to *state*, bypassing hysteresis.

        Resets all pending counters.

        Args:
            state: Target state.

        Returns:
            The new current state.
        """
        self._reset_counters()
        if state != self.current:
            self.current = state
            self.history.append((datetime.now(timezone.utc), self.current))
        return self.current

    def velocity(self, window: int = 5) -> float:
        """Rate of state changes over the last *window* transitions.

        Defined as the number of state changes divided by the number of
        history entries in the window.  Returns ``0.0`` when the
        history is shorter than 2 entries.

        Args:
            window: Number of recent history entries to consider.

        Returns:
            A float in ``[0.0, 1.0]``.
        """
        recent = self.history[-window:]
        if len(recent) < 2:
            return 0.0
        changes = sum(
            1
            for i in range(1, len(recent))
            if recent[i][1] != recent[i - 1][1]
        )
        return changes / (len(recent) - 1)

    def reset(self, state: State | None = None) -> None:
        """Reset the machine to *state* (or the initial state) and clear history.

        Args:
            state: Target reset state.  Defaults to the first member of
                the state enum.
        """
        self.current = state if state is not None else self._members[0]
        self.history = [(datetime.now(timezone.utc), self.current)]
        self._reset_counters()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _propose(self, value: float) -> State:
        """Select the best target state for the given *value*."""
        cur_val = self.current.value
        cur_order = self._order[cur_val]

        best_up: State | None = None
        best_up_order = cur_order
        best_down: State | None = None
        best_down_order = cur_order

        for (from_s, to_s), threshold in self._transitions.items():
            if from_s != cur_val:
                continue
            to_order = self._order.get(to_s)
            if to_order is None:
                continue

            if to_order > cur_order:
                # Escalation – fire if value >= threshold
                if value >= threshold and to_order > best_up_order:
                    best_up_order = to_order
                    best_up = self._states(to_s)
            else:
                # De-escalation – apply hysteresis gap
                effective_threshold = threshold * (1.0 + self.hysteresis)
                if value < effective_threshold and to_order < best_down_order:
                    best_down_order = to_order
                    best_down = self._states(to_s)

        # Escalation takes priority over de-escalation
        if best_up is not None:
            return best_up
        if best_down is not None:
            return best_down
        return self.current

    def _apply(self, proposed: State) -> State:
        """Apply hysteresis counters and commit transition if ready."""
        cur_order = self._order[self.current.value]
        prop_order = self._order[proposed.value]

        if prop_order > cur_order:
            # Escalation
            if self._pending_up == proposed:
                self._up_counter += 1
            else:
                self._pending_up = proposed
                self._up_counter = 1
            self._pending_down = None
            self._down_counter = 0

            if self._up_counter >= self.n_up:
                self.current = proposed
                self.history.append((datetime.now(timezone.utc), self.current))
                self._reset_counters()

        elif prop_order < cur_order:
            # De-escalation
            if self._pending_down == proposed:
                self._down_counter += 1
            else:
                self._pending_down = proposed
                self._down_counter = 1
            self._pending_up = None
            self._up_counter = 0

            if self._down_counter >= self.n_down:
                self.current = proposed
                self.history.append((datetime.now(timezone.utc), self.current))
                self._reset_counters()

        else:
            # Same state – reset counters
            self._reset_counters()

        return self.current

    def _reset_counters(self) -> None:
        self._up_counter = 0
        self._down_counter = 0
        self._pending_up = None
        self._pending_down = None
