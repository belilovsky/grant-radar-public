"""Portable, evidence-bound inspection-priority contract.

Products own the scoring method. This module carries only the published
assessment, its reasons, counts and evidence coverage so dashboards and queues
do not need to exchange product-specific score implementations.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

INSPECTION_PRIORITY_CONTRACT = "qazstack-inspection-priority-v1"
InspectionPriority = Literal["low", "medium", "high"]


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


class InspectionRiskCounts(BaseModel):
    """Counts by severity behind an inspection decision."""

    model_config = ConfigDict(extra="forbid")

    critical: int = Field(default=0, ge=0)
    high: int = Field(default=0, ge=0)
    medium: int = Field(default=0, ge=0)
    low: int = Field(default=0, ge=0)


class InspectionEvidenceCoverage(BaseModel):
    """Evidence availability, deliberately separate from confirmation."""

    model_config = ConfigDict(extra="forbid")

    matched_items: int = Field(default=0, ge=0)
    needs_review: bool = True
    source_snapshot: str | None = Field(default=None, min_length=1, max_length=512)

    @field_validator("source_snapshot")
    @classmethod
    def normalize_source_snapshot(cls, value: str | None) -> str | None:
        if value is None:
            return None
        normalized = value.strip()
        if not normalized:
            raise ValueError("source_snapshot must not be blank")
        return normalized


class RegionalInspectionAssessment(BaseModel):
    """A product-neutral, explainable inspection ordering decision."""

    model_config = ConfigDict(extra="forbid")

    schema_version: Literal["qazstack-inspection-priority-v1"] = INSPECTION_PRIORITY_CONTRACT
    subject_id: str = Field(min_length=3, max_length=256, pattern=r"^[a-z][a-z0-9._:-]+$")
    subject_type: Literal["region", "district", "locality", "entity"] = "region"
    priority: InspectionPriority
    risk_counts: InspectionRiskCounts = Field(default_factory=InspectionRiskCounts)
    reasons: list[str] = Field(min_length=1, max_length=12)
    evidence: InspectionEvidenceCoverage = Field(default_factory=InspectionEvidenceCoverage)
    method: str = Field(min_length=1, max_length=256)
    as_of: datetime
    created_at: datetime = Field(default_factory=utc_now)

    @field_validator("reasons")
    @classmethod
    def normalize_reasons(cls, reasons: list[str]) -> list[str]:
        cleaned = [reason.strip() for reason in reasons]
        if any(not reason for reason in cleaned):
            raise ValueError("reasons must not contain blank values")
        if len({reason.casefold() for reason in cleaned}) != len(cleaned):
            raise ValueError("reasons must be unique")
        return cleaned

    @model_validator(mode="after")
    def validate_timestamps(self) -> "RegionalInspectionAssessment":
        if self.as_of.tzinfo is None or self.as_of.utcoffset() is None:
            raise ValueError("as_of must be timezone-aware")
        if self.created_at.tzinfo is None or self.created_at.utcoffset() is None:
            raise ValueError("created_at must be timezone-aware")
        return self
