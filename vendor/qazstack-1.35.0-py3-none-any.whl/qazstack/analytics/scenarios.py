"""Scenario generation and evaluation.

Provides three generic forward-simulation scenarios (inertial,
dampening, stress test) plus a ranking utility.  The simulation
operates on a generic numeric state dict – users supply the keys that
matter to their domain.

The dynamics use a simple mean-reversion model with optional control
and shock impulses.  Users can subclass or wrap these functions to
inject domain-specific dynamics.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------


@dataclass
class ScenarioMetrics:
    """Summary statistics derived from a scenario trajectory.

    Attributes:
        final_value: Value of the primary tracked key at the last step.
        min_value: Minimum of the primary tracked key across all steps.
        max_value: Maximum of the primary tracked key across all steps.
        volatility: Standard deviation of the primary tracked key.
        trend: Qualitative trend – ``"improving"``, ``"degrading"``, or
            ``"stable"``.
    """

    final_value: float = 0.0
    min_value: float = 0.0
    max_value: float = 0.0
    volatility: float = 0.0
    trend: str = "stable"  # "improving" | "degrading" | "stable"


@dataclass
class Scenario:
    """A single scenario with its simulated trajectory and summary metrics.

    Attributes:
        name: Human-readable scenario name.
        trajectory: List of state snapshots (one dict per time step).
        metrics: Computed :class:`ScenarioMetrics`.
        description: Free-text description of what the scenario models.
    """

    name: str
    trajectory: list[dict[str, float]] = field(default_factory=list)
    metrics: ScenarioMetrics = field(default_factory=ScenarioMetrics)
    description: str = ""


# ---------------------------------------------------------------------------
# Internal simulation helpers
# ---------------------------------------------------------------------------


def _std(values: list[float]) -> float:
    """Population standard deviation."""
    n = len(values)
    if n < 2:
        return 0.0
    mean = sum(values) / n
    return math.sqrt(sum((v - mean) ** 2 for v in values) / n)


def _compute_metrics(trajectory: list[dict[str, float]], key: str) -> ScenarioMetrics:
    """Derive :class:`ScenarioMetrics` from *trajectory* for *key*."""
    values = [step.get(key, 0.0) for step in trajectory]
    if not values:
        return ScenarioMetrics()

    final = values[-1]
    initial = values[0]
    min_v = min(values)
    max_v = max(values)
    vol = _std(values)

    delta = final - initial
    threshold = 0.01 * abs(initial) if abs(initial) > 1e-9 else 0.01
    if delta > threshold:
        trend = "improving"
    elif delta < -threshold:
        trend = "degrading"
    else:
        trend = "stable"

    return ScenarioMetrics(
        final_value=final,
        min_value=min_v,
        max_value=max_v,
        volatility=vol,
        trend=trend,
    )


def _mean_revert_step(
    state: dict[str, float],
    targets: dict[str, float],
    rates: dict[str, float],
    control: dict[str, float],
    shock: dict[str, float],
    noise: float = 0.0,
) -> dict[str, float]:
    """Single Euler step with mean-reversion, control, and shock.

    For each key in *state*:
        ``x(t+1) = x(t) + rate * (target - x(t)) + control + shock``

    Keys not in *targets* / *rates* default to a rate of 0 (no
    reversion) and a target equal to the current value.

    Args:
        state: Current state dict.
        targets: Equilibrium / target values per key.
        rates: Mean-reversion rates per key (fraction per step).
        control: Additive control increments per key.
        shock: Additive shock impulses per key (applied only once).
        noise: Standard deviation of Gaussian noise added per key.
            Set to ``0.0`` for deterministic simulation.

    Returns:
        New state dict.
    """
    import random

    new_state: dict[str, float] = {}
    for k, v in state.items():
        rate = rates.get(k, 0.0)
        target = targets.get(k, v)
        u = control.get(k, 0.0)
        xi = shock.get(k, 0.0)
        eta = random.gauss(0.0, noise) if noise > 0.0 else 0.0
        new_state[k] = v + rate * (target - v) + u + xi + eta
    return new_state


def _run_simulation(
    initial: dict[str, float],
    targets: dict[str, float],
    rates: dict[str, float],
    control: dict[str, float],
    shock: dict[str, float],
    steps: int,
    noise: float,
) -> list[dict[str, float]]:
    """Run a full trajectory from *initial* for *steps* time steps.

    Shock is applied only at t=0 (impulse); control is applied at every
    step.
    """
    state = dict(initial)
    trajectory: list[dict[str, float]] = [dict(state)]
    for t in range(steps):
        shock_t = shock if t == 0 else {}
        state = _mean_revert_step(state, targets, rates, control, shock_t, noise)
        trajectory.append(dict(state))
    return trajectory


# ---------------------------------------------------------------------------
# Public scenario generators
# ---------------------------------------------------------------------------

#: Default mean-reversion rates when the caller does not supply them.
_DEFAULT_RATES: dict[str, float] = {}

#: Default equilibrium targets when the caller does not supply them.
_DEFAULT_TARGETS: dict[str, float] = {}


def generate_inertial(
    current: dict[str, float],
    steps: int = 12,
    noise: float = 0.02,
    targets: dict[str, float] | None = None,
    rates: dict[str, float] | None = None,
    track_key: str | None = None,
) -> Scenario:
    """Inertial scenario – no intervention, natural drift only.

    The system evolves under mean-reversion toward *targets* with
    optional noise.  No control actions are applied.

    Args:
        current: Current state of the system.
        steps: Number of forward simulation steps.
        noise: Standard deviation of additive Gaussian noise per step.
            Set to ``0.0`` for a deterministic trajectory.
        targets: Equilibrium targets.  Defaults to *current* (no drift).
        rates: Mean-reversion rates.  Defaults to ``0.0`` for all keys
            (random walk + noise only).
        track_key: Key used for :class:`ScenarioMetrics`.  Defaults to
            the first key in *current*.

    Returns:
        A :class:`Scenario` with name ``"inertial"``.
    """
    _targets = targets if targets is not None else dict(current)
    _rates = rates if rates is not None else {}
    _key = track_key or next(iter(current))

    traj = _run_simulation(current, _targets, _rates, {}, {}, steps, noise)
    metrics = _compute_metrics(traj, _key)
    return Scenario(
        name="inertial",
        trajectory=traj,
        metrics=metrics,
        description="No intervention – system evolves under natural dynamics.",
    )


def generate_dampening(
    current: dict[str, float],
    damping: float = 0.1,
    steps: int = 12,
    noise: float = 0.0,
    targets: dict[str, float] | None = None,
    rates: dict[str, float] | None = None,
    track_key: str | None = None,
    control: dict[str, float] | None = None,
) -> Scenario:
    """Active dampening scenario – intervention that suppresses oscillation.

    Applies a uniform negative control of magnitude *damping* to all
    state variables unless *control* is supplied explicitly.

    Args:
        current: Current state of the system.
        damping: Uniform control magnitude (subtracted from each key per
            step unless overridden by *control*).
        steps: Number of forward simulation steps.
        noise: Additive Gaussian noise standard deviation.
        targets: Equilibrium targets.
        rates: Mean-reversion rates.
        track_key: Key for :class:`ScenarioMetrics`.
        control: Explicit per-key control increments.  If supplied,
            *damping* is ignored.

    Returns:
        A :class:`Scenario` with name ``"dampening"``.
    """
    _targets = targets if targets is not None else dict(current)
    _rates = rates if rates is not None else {}
    _key = track_key or next(iter(current))
    _control = control if control is not None else {k: -damping for k in current}

    traj = _run_simulation(current, _targets, _rates, _control, {}, steps, noise)
    metrics = _compute_metrics(traj, _key)
    return Scenario(
        name="dampening",
        trajectory=traj,
        metrics=metrics,
        description=f"Active dampening with control magnitude {damping:.3f}.",
    )


def generate_stress_test(
    current: dict[str, float],
    shock: float = 0.3,
    steps: int = 12,
    noise: float = 0.0,
    targets: dict[str, float] | None = None,
    rates: dict[str, float] | None = None,
    track_key: str | None = None,
    shock_vector: dict[str, float] | None = None,
) -> Scenario:
    """Stress test – sudden shock applied at t=0.

    Applies an impulse shock at the first time step and then lets the
    system evolve freely.  The shock can be uniform (all keys get
    ``+shock``) or specified per-key via *shock_vector*.

    Args:
        current: Current state of the system.
        shock: Uniform shock magnitude added to all keys at t=0.
        steps: Number of forward simulation steps.
        noise: Additive Gaussian noise standard deviation.
        targets: Equilibrium targets.
        rates: Mean-reversion rates.
        track_key: Key for :class:`ScenarioMetrics`.
        shock_vector: Explicit per-key shock impulses.  If supplied,
            *shock* is ignored.

    Returns:
        A :class:`Scenario` with name ``"stress_test"``.
    """
    _targets = targets if targets is not None else dict(current)
    _rates = rates if rates is not None else {}
    _key = track_key or next(iter(current))
    _shock = shock_vector if shock_vector is not None else {k: shock for k in current}

    traj = _run_simulation(current, _targets, _rates, {}, _shock, steps, noise)
    metrics = _compute_metrics(traj, _key)
    return Scenario(
        name="stress_test",
        trajectory=traj,
        metrics=metrics,
        description=f"Stress test: impulse shock of magnitude {shock:.3f} at t=0.",
    )


def rank_scenarios(
    scenarios: list[Scenario],
    key: str = "final_value",
    ascending: bool = True,
) -> list[Scenario]:
    """Rank *scenarios* by a :class:`ScenarioMetrics` attribute.

    Args:
        scenarios: List of :class:`Scenario` objects to sort.
        key: Attribute name on :class:`ScenarioMetrics` to sort by.
            Valid values: ``"final_value"``, ``"min_value"``,
            ``"max_value"``, ``"volatility"``.
        ascending: ``True`` for ascending order (lower is better).

    Returns:
        A new list sorted by the requested metric.

    Raises:
        AttributeError: If *key* is not a valid :class:`ScenarioMetrics`
            attribute.
    """
    return sorted(
        scenarios,
        key=lambda s: getattr(s.metrics, key),
        reverse=not ascending,
    )
