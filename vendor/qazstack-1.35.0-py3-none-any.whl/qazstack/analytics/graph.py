"""Dependency-free structural analysis for undirected entity graphs."""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from typing import Any, Callable, Hashable, Iterable, Mapping

NodeId = Hashable
EdgeRank = Callable[[Mapping[str, Any]], tuple]


@dataclass(frozen=True, slots=True)
class NodeDegree:
    node_id: NodeId
    degree: int


@dataclass(frozen=True, slots=True)
class GraphMetrics:
    node_count: int
    edge_count: int
    component_count: int
    largest_component: int
    isolate_count: int
    density: float
    bridges: tuple[tuple[NodeId, NodeId], ...]
    degrees: tuple[NodeDegree, ...]


@dataclass(frozen=True, slots=True)
class GraphPath:
    found: bool
    node_ids: tuple[NodeId, ...] = ()
    edges: tuple[Mapping[str, Any], ...] = ()

    @property
    def hops(self) -> int | None:
        return len(self.edges) if self.found else None


def _graph(
    nodes: Iterable[Mapping[str, Any]],
    edges: Iterable[Mapping[str, Any]],
) -> tuple[dict[NodeId, set[NodeId]], list[Mapping[str, Any]]]:
    node_list = list(nodes)
    adjacency: dict[NodeId, set[NodeId]] = {node["id"]: set() for node in node_list}
    edge_list: list[Mapping[str, Any]] = []
    seen_pairs: set[frozenset[NodeId]] = set()
    for edge in edges:
        source = edge.get("source")
        target = edge.get("target")
        if source in adjacency and target in adjacency and source != target:
            pair = frozenset((source, target))
            if pair in seen_pairs:
                continue
            seen_pairs.add(pair)
            edge_list.append(edge)
            adjacency[source].add(target)
            adjacency[target].add(source)
    return adjacency, edge_list


def analyze_undirected_graph(
    nodes: Iterable[Mapping[str, Any]],
    edges: Iterable[Mapping[str, Any]],
) -> GraphMetrics:
    """Return components, density, bridges and degrees for a graph projection."""
    node_list = list(nodes)
    adjacency, edge_list = _graph(node_list, edges)
    components: list[set[NodeId]] = []
    remaining = set(adjacency)
    while remaining:
        start = min(remaining, key=str)
        remaining.remove(start)
        component = {start}
        queue = deque([start])
        while queue:
            current = queue.popleft()
            for neighbor in sorted(adjacency[current], key=str):
                if neighbor in remaining:
                    remaining.remove(neighbor)
                    component.add(neighbor)
                    queue.append(neighbor)
        components.append(component)

    discovery: dict[NodeId, int] = {}
    low: dict[NodeId, int] = {}
    parent: dict[NodeId, NodeId | None] = {}
    bridges: list[tuple[NodeId, NodeId]] = []
    clock = 0

    def visit(node_id: NodeId) -> None:
        nonlocal clock
        clock += 1
        discovery[node_id] = low[node_id] = clock
        for neighbor in sorted(adjacency[node_id], key=str):
            if neighbor not in discovery:
                parent[neighbor] = node_id
                visit(neighbor)
                low[node_id] = min(low[node_id], low[neighbor])
                if low[neighbor] > discovery[node_id]:
                    bridges.append(tuple(sorted((node_id, neighbor), key=str)))
            elif parent.get(node_id) != neighbor:
                low[node_id] = min(low[node_id], discovery[neighbor])

    for node_id in sorted(adjacency, key=str):
        if node_id not in discovery:
            parent[node_id] = None
            visit(node_id)

    node_count = len(node_list)
    possible_edges = node_count * (node_count - 1) / 2
    degrees = tuple(
        NodeDegree(node_id, len(neighbors))
        for node_id, neighbors in sorted(adjacency.items(), key=lambda item: (-len(item[1]), str(item[0])))
    )
    return GraphMetrics(
        node_count=node_count,
        edge_count=len(edge_list),
        component_count=len(components),
        largest_component=max((len(component) for component in components), default=0),
        isolate_count=sum(not neighbors for neighbors in adjacency.values()),
        density=round(len(edge_list) / possible_edges, 5) if possible_edges else 0.0,
        bridges=tuple(sorted(bridges, key=lambda pair: (str(pair[0]), str(pair[1])))),
        degrees=degrees,
    )


def shortest_undirected_path(
    nodes: Iterable[Mapping[str, Any]],
    edges: Iterable[Mapping[str, Any]],
    *,
    source_id: NodeId,
    target_id: NodeId,
    max_hops: int = 6,
    edge_rank: EdgeRank | None = None,
) -> GraphPath:
    """Find a deterministic bounded shortest path and retain source edges."""
    if max_hops < 1:
        raise ValueError("max_hops must be positive")
    node_ids = {node["id"] for node in nodes}
    if source_id not in node_ids or target_id not in node_ids:
        return GraphPath(False)
    if source_id == target_id:
        return GraphPath(True, (source_id,), ())

    adjacency: dict[NodeId, list[tuple[NodeId, Mapping[str, Any]]]] = {node_id: [] for node_id in node_ids}
    for edge in edges:
        source = edge.get("source")
        target = edge.get("target")
        if source in adjacency and target in adjacency and source != target:
            adjacency[source].append((target, edge))
            adjacency[target].append((source, edge))
    for neighbors in adjacency.values():
        neighbors.sort(key=lambda item: ((edge_rank(item[1]) if edge_rank else ()), str(item[0])))

    queue = deque([(source_id, 0)])
    previous: dict[NodeId, tuple[NodeId, Mapping[str, Any]] | None] = {source_id: None}
    while queue:
        current, depth = queue.popleft()
        if depth >= max_hops:
            continue
        for neighbor, edge in adjacency[current]:
            if neighbor in previous:
                continue
            previous[neighbor] = (current, edge)
            if neighbor == target_id:
                queue.clear()
                break
            queue.append((neighbor, depth + 1))

    if target_id not in previous:
        return GraphPath(False)
    path_ids: list[NodeId] = [target_id]
    path_edges: list[Mapping[str, Any]] = []
    cursor = target_id
    while previous[cursor] is not None:
        parent, edge = previous[cursor]
        path_ids.append(parent)
        path_edges.append(edge)
        cursor = parent
    path_ids.reverse()
    path_edges.reverse()
    return GraphPath(True, tuple(path_ids), tuple(path_edges))
