"""Explainable source trust factors separate from evidence quality."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping

from qazstack.contracts._validation import require_identifier, require_ratio, require_text


@dataclass(frozen=True, slots=True)
class SourceTrustFactors:
    authority: float
    transparency: float
    correction_history: float
    freshness: float

    def __post_init__(self) -> None:
        for name in ("authority", "transparency", "correction_history", "freshness"):
            require_ratio(getattr(self, name), name)

    def score(self, weights: Mapping[str, float] | None = None) -> float:
        values = {
            "authority": self.authority,
            "transparency": self.transparency,
            "correction_history": self.correction_history,
            "freshness": self.freshness,
        }
        active_weights = dict(weights or {name: 1.0 for name in values})
        if any(weight < 0 for weight in active_weights.values()):
            raise ValueError("weights must be non-negative")
        total = sum(active_weights.get(name, 0.0) for name in values)
        if total <= 0:
            raise ValueError("at least one factor needs a positive weight")
        return round(sum(value * active_weights.get(name, 0.0) for name, value in values.items()) / total, 6)


@dataclass(frozen=True, slots=True)
class SourceTrustAssessment:
    source_id: str
    factors: SourceTrustFactors
    score: float
    reason: str
    operator_override: float | None = None

    def __post_init__(self) -> None:
        require_identifier(self.source_id, "source_id")
        require_ratio(self.score, "score")
        require_text(self.reason, "reason")
        if self.operator_override is not None:
            require_ratio(self.operator_override, "operator_override")

    @property
    def effective_score(self) -> float:
        return self.score if self.operator_override is None else self.operator_override
