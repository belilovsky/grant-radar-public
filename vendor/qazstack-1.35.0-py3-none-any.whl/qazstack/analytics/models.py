"""SQLAlchemy models for persisting analysis results.

Uses a separate DeclarativeBase (``AnalysisResultBase``) to avoid
conflicts with project models, following the same pattern as
EntityBase and MonitorBase.

Tables:
- ``analysis_results`` – individual engine run results
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Optional

from sqlalchemy import (
    Column, DateTime, Float, Integer, String, Text, JSON,
    Index,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class AnalysisResultBase(DeclarativeBase):
    """Separate declarative base for analytics tables."""
    pass


class AnalysisResult(AnalysisResultBase):
    """Persisted result of an analytical engine run.

    Links to entities via entity_id (optional FK to Entity Store).
    Stores the full signal dict and metadata for reproducibility.
    """

    __tablename__ = "analysis_results"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    engine: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    version: Mapped[str] = mapped_column(String(16), nullable=False, default="1.0")
    project: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    run_id: Mapped[str] = mapped_column(String(64), nullable=False, index=True)

    # Primary output
    value: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    confidence: Mapped[float] = mapped_column(Float, nullable=False, default=1.0)

    # Structured data
    signals: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)
    metadata_json: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)
    inputs_hash: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)

    # Entity linkage (optional)
    entity_id: Mapped[Optional[int]] = mapped_column(Integer, nullable=True, index=True)

    # Error tracking
    error: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=lambda: datetime.now(timezone.utc),
    )

    __table_args__ = (
        Index("ix_analysis_project_engine", "project", "engine"),
        Index("ix_analysis_run_id", "run_id"),
        Index("ix_analysis_entity_engine", "entity_id", "engine"),
    )

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "engine": self.engine,
            "version": self.version,
            "project": self.project,
            "run_id": self.run_id,
            "value": self.value,
            "confidence": self.confidence,
            "signals": self.signals,
            "metadata": self.metadata_json,
            "entity_id": self.entity_id,
            "error": self.error,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }
