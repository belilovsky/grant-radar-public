"""BaseEngine protocol and EngineResult – the contract for all analytical engines.

Every engine:
1. Has a unique ``name``, ``version``, ``category``
2. Declares its ``required_inputs`` (so the pipeline can validate)
3. Implements ``run(inputs, cfg) -> EngineResult``
4. Can optionally implement ``validate_inputs()`` and ``default_config()``

Design mirrors PSSR's calculator pattern but generalises it:
- PSSR engines (indices, spectral, scenarios) can be wrapped as BaseEngine subclasses
- New engines (entity-graph analytics, cross-project metrics) fit the same interface
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional


class EngineCategory(str, Enum):
    """Engine classification."""
    INDEX = "index"             # Scalar index (SSI, SSS, PRS, etc.)
    SPECTRAL = "spectral"       # Jacobian / eigenvalue analysis
    SCENARIO = "scenario"       # Forward-looking trajectory generation
    REGIME = "regime"           # Regime classification / state machine
    GRAPH = "graph"             # Entity-graph analytics (centrality, communities)
    AGGREGATE = "aggregate"     # Cross-engine aggregation (snapshots)
    CUSTOM = "custom"           # User-defined


@dataclass
class EngineResult:
    """Unified result from any analytical engine.

    Fields:
        engine: engine name that produced this result
        value: primary scalar output (None if engine returns structured data only)
        signals: named signal values (engine-specific, follows naming conventions)
        metadata: additional context (timing, diagnostics, entity refs)
        confidence: 0..1 how reliable this result is
        error: error message if engine partially failed
        entities: list of entity IDs referenced in this analysis
        timestamp: when the analysis was performed
    """
    engine: str
    value: Optional[float] = None
    signals: dict[str, float] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)
    confidence: float = 1.0
    error: Optional[str] = None
    entities: list[int] = field(default_factory=list)
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )

    @property
    def ok(self) -> bool:
        return self.error is None

    def to_dict(self) -> dict[str, Any]:
        return {
            "engine": self.engine,
            "value": self.value,
            "signals": self.signals,
            "confidence": self.confidence,
            "error": self.error,
            "entities": self.entities,
            "timestamp": self.timestamp,
            "metadata": self.metadata,
        }


class BaseEngine(ABC):
    """Protocol for analytical engines.

    Subclass and implement:
    - ``name``, ``version``, ``category`` (class attributes or properties)
    - ``required_inputs`` – list of input keys this engine needs
    - ``run(inputs, cfg)`` – the actual computation

    Optional overrides:
    - ``validate_inputs(inputs)`` – custom validation
    - ``default_config()`` – default configuration dict
    """

    name: str = "unnamed"
    version: str = "1.0"
    category: EngineCategory = EngineCategory.CUSTOM
    description: str = ""

    @property
    def required_inputs(self) -> list[str]:
        """Input keys this engine needs. Override in subclasses."""
        return []

    @abstractmethod
    async def run(self, inputs: dict[str, Any], cfg: dict[str, Any]) -> EngineResult:
        """Execute the engine computation.

        Args:
            inputs: named input values (validated against required_inputs)
            cfg: engine-specific configuration (thresholds, weights, etc.)

        Returns:
            EngineResult with computed value(s)
        """

    def validate_inputs(self, inputs: dict[str, Any]) -> list[str]:
        """Validate inputs. Returns list of error messages (empty = valid)."""
        errors = []
        for key in self.required_inputs:
            if key not in inputs:
                errors.append(f"Missing required input: {key}")
        return errors

    def default_config(self) -> dict[str, Any]:
        """Default configuration for this engine. Override for custom defaults."""
        return {}

    def info(self) -> dict[str, Any]:
        """Engine metadata for registry/API."""
        return {
            "name": self.name,
            "version": self.version,
            "category": self.category.value,
            "description": self.description,
            "required_inputs": self.required_inputs,
        }

    async def safe_run(
        self, inputs: dict[str, Any], cfg: dict[str, Any]
    ) -> EngineResult:
        """Run with fault isolation – never raises."""
        try:
            errors = self.validate_inputs(inputs)
            if errors:
                return EngineResult(
                    engine=self.name,
                    error=f"Validation failed: {'; '.join(errors)}",
                    confidence=0.0,
                )
            return await self.run(inputs, cfg)
        except Exception as e:
            return EngineResult(
                engine=self.name,
                error=str(e),
                confidence=0.0,
                metadata={"exception_type": type(e).__name__},
            )
