"""Analytics engine – state machines, early warning, drift detection, scenarios, spectral analysis.

Provides a standard interface for running analytical computations
(indices, spectral analysis, scenarios, regime detection) on
Entity Store data across all projects.

Components:

- **BaseEngine** – protocol for analytical engines
- **EngineRegistry** – register/discover/run engines
- **AnalyticsPipeline** – orchestrates Entity-aware analytics
- **AnalysisResult / AnalysisRun** – typed result models
- **State / StateMachine** – generic hysteresis state machine
- **EWSResult / evaluate_ews** – early warning system indicators
- **DriftResult / calc_drift_index** – composite drift detection
- **Scenario / ScenarioMetrics / generate_*** – forward scenario simulation
- **StabilityResult / build_jacobian / analyze_stability / calc_rho** – spectral analysis (requires numpy)

Quick start::

    from qazstack.analytics import (
        EngineRegistry, AnalyticsPipeline, BaseEngine, EngineResult,
    )

    # 1. Define an engine
    class SSIEngine(BaseEngine):
        name = "ssi"
        version = "9.3"
        description = "Stress Intensity Index"

        async def run(self, inputs: dict, cfg: dict) -> EngineResult:
            ssi = w_delta * abs(inputs["delta_sss"]) + ...
            return EngineResult(engine=self.name, value=ssi, signals={"ssi": ssi})

    # 2. Register
    registry = EngineRegistry()
    registry.register(SSIEngine())

    # 3. Pipeline
    pipeline = AnalyticsPipeline(registry=registry, store=entity_store)
    run = await pipeline.analyze(session, entity_id=42, engines=["ssi"])

"""

from .drift import DriftResult, calc_drift_index
from .engine import BaseEngine, EngineCategory, EngineResult
from .ews import EWSResult, evaluate_ews
from .graph import GraphMetrics, GraphPath, NodeDegree, analyze_undirected_graph, shortest_undirected_path
from .inspection import (
    INSPECTION_PRIORITY_CONTRACT,
    InspectionEvidenceCoverage,
    InspectionRiskCounts,
    RegionalInspectionAssessment,
)
from .models import AnalysisResult, AnalysisResultBase
from .pipeline import AnalysisRun, AnalyticsPipeline
from .registry import EngineRegistry
from .scenarios import (
    Scenario,
    ScenarioMetrics,
    generate_dampening,
    generate_inertial,
    generate_stress_test,
    rank_scenarios,
)
from .state_machine import State, StateMachine
from .trust import SourceTrustAssessment, SourceTrustFactors


# spectral requires numpy – import lazily to avoid hard dependency
def __getattr__(name: str):  # noqa: N807
    _spectral_names = {"StabilityResult", "build_jacobian", "analyze_stability", "calc_rho"}
    if name in _spectral_names:
        from qazstack.analytics import spectral as _spectral

        return getattr(_spectral, name)
    raise AttributeError(f"module 'qazstack.analytics' has no attribute {name!r}")


__all__ = [
    # Pipeline framework
    "BaseEngine",
    "EngineResult",
    "EngineCategory",
    "EngineRegistry",
    "AnalyticsPipeline",
    "AnalysisRun",
    "AnalysisResultBase",
    "AnalysisResult",
    # State machine
    "State",
    "StateMachine",
    # Early warning
    "EWSResult",
    "evaluate_ews",
    "GraphMetrics",
    "GraphPath",
    "NodeDegree",
    "analyze_undirected_graph",
    "shortest_undirected_path",
    "INSPECTION_PRIORITY_CONTRACT",
    "InspectionEvidenceCoverage",
    "InspectionRiskCounts",
    "RegionalInspectionAssessment",
    # Drift
    "DriftResult",
    "calc_drift_index",
    # Scenarios
    "Scenario",
    "ScenarioMetrics",
    "generate_inertial",
    "generate_dampening",
    "generate_stress_test",
    "rank_scenarios",
    # Spectral (numpy required)
    "StabilityResult",
    "build_jacobian",
    "analyze_stability",
    "calc_rho",
    "SourceTrustAssessment",
    "SourceTrustFactors",
]
