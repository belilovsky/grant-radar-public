"""Provider-neutral fail-closed publication decisions."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable
from urllib.parse import urlparse


@dataclass(frozen=True, slots=True)
class PublicationEvidence:
    """One reviewable evidence reference attached to a candidate record."""

    status: str
    source_ref: str | None = None


@dataclass(frozen=True, slots=True)
class PublicationDecision:
    """Explainable decision produced by :class:`PublicationPolicy`."""

    publishable: bool
    reasons: tuple[str, ...]
    direct_source: bool
    reviewed_evidence_count: int


@dataclass(frozen=True, slots=True)
class PublicationPolicy:
    """Minimal publication policy shared by evidence-backed products.

    Products retain ownership of their review workflow and legal/editorial
    thresholds. This contract only enforces the portable invariant that a
    public record is reviewed and has a direct or reviewed evidence source.

    ``trusted_host_suffixes`` lets a product opt into an issuer profile without
    hard-coding that profile into the shared primitive. A source ID is treated
    as a trusted upstream reference; URL-based sources must satisfy the
    configured transport and host policy.
    """

    review_states: frozenset[str] = frozenset({"reviewed", "published"})
    evidence_states: frozenset[str] = frozenset({"reviewed", "verified", "published"})
    trusted_host_suffixes: frozenset[str] | None = None
    require_https: bool = False

    def evaluate(
        self,
        *,
        review_status: str | None,
        source_id: object | None = None,
        source_url: str | None = None,
        evidence: Iterable[PublicationEvidence] = (),
    ) -> PublicationDecision:
        direct_source = source_id is not None or self.accepts_source_url(source_url)
        reviewed_evidence_count = sum(
            item.status in self.evidence_states and bool((item.source_ref or "").strip()) for item in evidence
        )
        reasons: list[str] = []
        if review_status not in self.review_states:
            reasons.append("review_required")
        if not direct_source and not reviewed_evidence_count:
            reasons.append("source_required")
        return PublicationDecision(
            publishable=not reasons,
            reasons=tuple(reasons),
            direct_source=direct_source,
            reviewed_evidence_count=reviewed_evidence_count,
        )

    def accepts_source_url(self, value: str | None) -> bool:
        """Return whether a direct URL satisfies this policy's source profile."""
        if not is_http_source(value):
            return False
        parsed = urlparse(value.strip())
        if self.require_https and parsed.scheme.lower() != "https":
            return False
        if not self.trusted_host_suffixes:
            return True
        host = parsed.hostname.lower().removeprefix("www.") if parsed.hostname else ""
        return any(host == suffix or host.endswith(f".{suffix}") for suffix in self.trusted_host_suffixes)


DEFAULT_PUBLICATION_POLICY = PublicationPolicy()


def is_http_source(value: str | None) -> bool:
    """Return whether *value* is an absolute HTTP(S) source URL."""
    if not value:
        return False
    parsed = urlparse(value.strip())
    return parsed.scheme.lower() in {"http", "https"} and bool(parsed.netloc)
