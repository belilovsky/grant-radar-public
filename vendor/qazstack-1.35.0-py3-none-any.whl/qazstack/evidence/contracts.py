"""Provider-neutral contracts for private evidence capture."""

from __future__ import annotations

import ipaddress
from dataclasses import dataclass, field
from datetime import datetime
from typing import Mapping
from urllib.parse import parse_qsl, urlsplit, urlunsplit

from qazstack.contracts._validation import (
    require_aware,
    require_identifier,
    require_one_of,
    require_positive,
    require_sha256,
    require_text,
)

CAPTURE_STATUSES = frozenset({"pending", "completed", "failed"})
DEFAULT_CONTENT_TYPES = frozenset(
    {
        "application/pdf",
        "image/avif",
        "image/gif",
        "image/jpeg",
        "image/png",
        "image/webp",
        "text/html",
        "text/plain",
    }
)
DEFAULT_RESPONSE_HEADERS = frozenset(
    {
        "cache-control",
        "content-language",
        "content-length",
        "content-type",
        "date",
        "etag",
        "last-modified",
    }
)
DEFAULT_SENSITIVE_QUERY_KEYS = frozenset(
    {
        "access_token",
        "api_key",
        "apikey",
        "auth",
        "authorization",
        "jwt",
        "key",
        "password",
        "secret",
        "session",
        "sessionid",
        "sig",
        "signature",
        "token",
    }
)
_SENSITIVE_QUERY_SUFFIXES = ("_key", "_password", "_secret", "_signature", "_token")


class EvidencePolicyError(ValueError):
    """Raised when capture metadata violates a fail-closed evidence policy."""


@dataclass(frozen=True, slots=True)
class EvidenceCapturePolicy:
    """Resource and disclosure limits shared by capture implementations."""

    max_url_length: int = 2048
    max_bytes: int = 5 * 1024 * 1024
    timeout_seconds: float = 12.0
    max_redirects: int = 3
    allowed_schemes: frozenset[str] = frozenset({"http", "https"})
    allowed_content_types: frozenset[str] = DEFAULT_CONTENT_TYPES
    response_header_allowlist: frozenset[str] = DEFAULT_RESPONSE_HEADERS
    sensitive_query_keys: frozenset[str] = DEFAULT_SENSITIVE_QUERY_KEYS

    def __post_init__(self) -> None:
        require_positive(self.max_url_length, "max_url_length")
        require_positive(self.max_bytes, "max_bytes")
        require_positive(self.timeout_seconds, "timeout_seconds")
        require_positive(self.max_redirects, "max_redirects", allow_zero=True)
        if not self.allowed_schemes or not self.allowed_schemes <= {"http", "https"}:
            raise ValueError("allowed_schemes must contain only http and/or https")
        if not self.allowed_content_types or not self.allowed_content_types <= DEFAULT_CONTENT_TYPES:
            raise ValueError("allowed_content_types must be a non-empty subset of the safe baseline")
        if not self.response_header_allowlist or not self.response_header_allowlist <= DEFAULT_RESPONSE_HEADERS:
            raise ValueError("response_header_allowlist must be a non-empty subset of the safe baseline")
        if not self.sensitive_query_keys >= DEFAULT_SENSITIVE_QUERY_KEYS:
            raise ValueError("sensitive_query_keys must include the fail-closed baseline")


DEFAULT_EVIDENCE_CAPTURE_POLICY = EvidenceCapturePolicy()


def _normalized_query_key(value: str) -> str:
    return value.strip().lower().replace("-", "_").replace(".", "_")


def _has_sensitive_query(url: str, policy: EvidenceCapturePolicy) -> bool:
    for raw_key, _value in parse_qsl(urlsplit(url).query, keep_blank_values=True):
        key = _normalized_query_key(raw_key)
        if key in policy.sensitive_query_keys or key.endswith(_SENSITIVE_QUERY_SUFFIXES):
            return True
    return False


def normalize_evidence_url(
    value: str,
    *,
    policy: EvidenceCapturePolicy = DEFAULT_EVIDENCE_CAPTURE_POLICY,
) -> str:
    """Return a fragment-free public capture URL or fail before persistence."""
    raw = require_text(value, "url")
    if len(raw) > policy.max_url_length:
        raise EvidencePolicyError("url exceeds the configured length limit")
    parsed = urlsplit(raw)
    if parsed.scheme not in policy.allowed_schemes or not parsed.hostname:
        raise EvidencePolicyError("url must use an allowed HTTP(S) scheme")
    if parsed.username or parsed.password:
        raise EvidencePolicyError("url must not contain credentials")
    try:
        port = parsed.port
    except ValueError as exc:
        raise EvidencePolicyError("url contains an invalid port") from exc
    expected_port = 80 if parsed.scheme == "http" else 443
    if port is not None and port != expected_port:
        raise EvidencePolicyError("url must use the standard port for its scheme")

    host = parsed.hostname.lower().rstrip(".")
    if host == "localhost" or host.endswith(".localhost"):
        raise EvidencePolicyError("url must not use localhost")
    try:
        address = ipaddress.ip_address(host)
    except ValueError:
        address = None
    if address is not None and not address.is_global:
        raise EvidencePolicyError("url must not use a private or reserved address")
    if _has_sensitive_query(raw, policy):
        raise EvidencePolicyError("url contains a sensitive query parameter")

    normalized = urlunsplit(parsed._replace(fragment=""))
    if len(normalized) > policy.max_url_length:
        raise EvidencePolicyError("url exceeds the configured length limit")
    return normalized


def validate_public_addresses(addresses: tuple[str, ...] | list[str]) -> tuple[str, ...]:
    """Validate one DNS result set; consumers must repeat this for every hop."""
    if not addresses:
        raise EvidencePolicyError("dns resolution returned no addresses")
    normalized: list[str] = []
    for value in addresses:
        try:
            address = ipaddress.ip_address(value)
        except ValueError as exc:
            raise EvidencePolicyError("dns resolution returned an invalid address") from exc
        if not address.is_global:
            raise EvidencePolicyError("dns resolution returned a non-public address")
        rendered = str(address)
        if rendered not in normalized:
            normalized.append(rendered)
    return tuple(normalized)


def allowlisted_response_headers(
    headers: Mapping[str, str],
    *,
    policy: EvidenceCapturePolicy = DEFAULT_EVIDENCE_CAPTURE_POLICY,
    value_limit: int = 1000,
) -> tuple[tuple[str, str], ...]:
    """Keep bounded provenance headers without cookies or authorization data."""
    require_positive(value_limit, "value_limit")
    selected = {
        key.strip().lower(): str(value)[:value_limit]
        for key, value in headers.items()
        if key.strip().lower() in policy.response_header_allowlist
    }
    return tuple(sorted(selected.items()))


@dataclass(frozen=True, slots=True)
class EvidenceCaptureRecord:
    """Immutable manifest for a product-owned private capture artifact."""

    capture_id: str
    source_url: str
    status: str
    provider: str
    captured_at: datetime
    retention_class: str
    final_url: str = ""
    http_status: int | None = None
    content_type: str = ""
    size_bytes: int = 0
    digest: str = ""
    archive_ref: str = ""
    response_headers: tuple[tuple[str, str], ...] = field(default_factory=tuple)
    error_code: str = ""

    def __post_init__(self) -> None:
        require_identifier(self.capture_id, "capture_id")
        object.__setattr__(self, "source_url", normalize_evidence_url(self.source_url))
        require_one_of(self.status, CAPTURE_STATUSES, "status")
        require_text(self.provider, "provider")
        require_aware(self.captured_at, "captured_at")
        require_text(self.retention_class, "retention_class")
        require_positive(self.size_bytes, "size_bytes", allow_zero=True)
        if self.final_url:
            object.__setattr__(self, "final_url", normalize_evidence_url(self.final_url))
        if len(dict(self.response_headers)) != len(self.response_headers):
            raise ValueError("response_headers must not contain duplicate keys")
        if any(key not in DEFAULT_RESPONSE_HEADERS for key, _value in self.response_headers):
            raise ValueError("response_headers contains a non-allowlisted key")
        if any(len(value) > 1000 for _key, value in self.response_headers):
            raise ValueError("response_headers contains an oversized value")

        if self.status == "completed":
            if self.http_status != 200:
                raise ValueError("completed capture requires HTTP 200")
            if self.content_type not in DEFAULT_CONTENT_TYPES:
                raise ValueError("completed capture requires an allowed content_type")
            require_positive(self.size_bytes, "size_bytes")
            object.__setattr__(self, "digest", require_sha256(self.digest))
            require_text(self.archive_ref, "archive_ref")
            if self.error_code:
                raise ValueError("completed capture must not include error_code")
        elif self.status == "failed":
            require_text(self.error_code, "error_code")
            if self.archive_ref or self.digest:
                raise ValueError("failed capture must not reference a completed artifact")
        elif any(
            (self.http_status, self.content_type, self.size_bytes, self.digest, self.archive_ref, self.error_code)
        ):
            raise ValueError("pending capture must not include terminal metadata")
