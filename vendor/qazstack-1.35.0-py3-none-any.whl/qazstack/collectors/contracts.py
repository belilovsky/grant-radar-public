"""Minimal ingestion source protocol and normalized batch models."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Mapping, Protocol

from qazstack.contracts._validation import require_aware, require_http_url, require_identifier, require_text


@dataclass(frozen=True, slots=True)
class SourceCheckpoint:
    source_id: str
    cursor: str
    updated_at: datetime

    def __post_init__(self) -> None:
        require_identifier(self.source_id, "source_id")
        require_text(self.cursor, "cursor")
        require_aware(self.updated_at, "updated_at")


@dataclass(frozen=True, slots=True)
class NormalizedItem:
    item_id: str
    source_id: str
    canonical_url: str
    observed_at: datetime
    source_updated_at: datetime | None
    payload: Mapping[str, Any]

    def __post_init__(self) -> None:
        require_text(self.item_id, "item_id")
        require_identifier(self.source_id, "source_id")
        require_http_url(self.canonical_url, "canonical_url")
        require_aware(self.observed_at, "observed_at")
        if self.source_updated_at is not None:
            require_aware(self.source_updated_at, "source_updated_at")


@dataclass(frozen=True, slots=True)
class SourceBatch:
    source_id: str
    fetched_at: datetime
    items: tuple[NormalizedItem, ...]
    next_checkpoint: SourceCheckpoint | None

    def __post_init__(self) -> None:
        require_identifier(self.source_id, "source_id")
        require_aware(self.fetched_at, "fetched_at")
        if any(item.source_id != self.source_id for item in self.items):
            raise ValueError("all items must belong to the batch source")
        if self.next_checkpoint and self.next_checkpoint.source_id != self.source_id:
            raise ValueError("checkpoint must belong to the batch source")


@dataclass(frozen=True, slots=True)
class SourceFailure:
    source_id: str
    code: str
    retryable: bool
    message: str

    def __post_init__(self) -> None:
        require_identifier(self.source_id, "source_id")
        require_identifier(self.code, "code")
        require_text(self.message, "message")


class SourceContract(Protocol):
    source_id: str

    async def fetch(self, checkpoint: SourceCheckpoint | None = None) -> SourceBatch: ...

    async def health_check(self) -> bool: ...
