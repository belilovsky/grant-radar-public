"""Collector Pipeline – orchestrates collect → enrich → extract → store.

The main entry point for running data collection across all registered
collectors, with optional NER entity extraction into the Entity Store.

Usage::

    pipeline = CollectorPipeline(
        registry=CollectorRegistry.with_builtins(),
        extractor=EntityExtractor(store=EntityStore()),
    )

    async with db.get_session() as session:
        stats = await pipeline.run_source(
            session,
            source_type="rss",
            config={"url": "https://example.com/rss"},
            project="echo-sounder",
        )
        print(f"Collected: {stats.items_collected}, Entities: {stats.entities_found}")
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Sequence

from sqlalchemy.ext.asyncio import AsyncSession

from qazstack.monitor.collectors.base import BaseCollector, CollectorResult

from .extractor import EntityExtractor
from .registry import CollectorRegistry

logger = logging.getLogger("qazstack.collectors.pipeline")


@dataclass
class CollectStats:
    """Statistics from a collection run."""

    source_type: str = ""
    project: str = ""
    items_collected: int = 0
    entities_found: int = 0
    mentions_added: int = 0
    errors: list[str] = field(default_factory=list)
    duration_ms: float = 0.0

    @property
    def ok(self) -> bool:
        return len(self.errors) == 0


@dataclass
class PipelineStats:
    """Aggregated statistics from running multiple sources."""

    sources_run: int = 0
    total_items: int = 0
    total_entities: int = 0
    total_mentions: int = 0
    source_stats: list[CollectStats] = field(default_factory=list)
    duration_ms: float = 0.0

    @property
    def errors(self) -> list[str]:
        errs = []
        for s in self.source_stats:
            errs.extend(s.errors)
        return errs


class CollectorPipeline:
    """Orchestrates data collection and entity extraction.

    Connects CollectorRegistry (data sources) with EntityExtractor
    (NER → Entity Store) in a single pipeline.
    """

    def __init__(
        self,
        registry: CollectorRegistry,
        extractor: EntityExtractor | None = None,
        *,
        extract_entities: bool = True,
        max_items_per_source: int = 100,
    ) -> None:
        """
        Args:
            registry: Registry of available collectors.
            extractor: EntityExtractor for NER → Entity Store.
                If None, entity extraction is skipped.
            extract_entities: Whether to run NER on collected items.
            max_items_per_source: Maximum items to collect per source.
        """
        self.registry = registry
        self.extractor = extractor
        self.extract_entities = extract_entities and extractor is not None
        self.max_items_per_source = max_items_per_source

    async def run_source(
        self,
        session: AsyncSession,
        *,
        source_type: str,
        config: dict,
        project: str,
        source_table: str = "collector_results",
    ) -> CollectStats:
        """Collect from a single source and optionally extract entities.

        Args:
            session: SQLAlchemy async session.
            source_type: Collector type (e.g. "rss", "http", "telegram").
            config: Source-specific configuration.
            project: Project name for Entity Store.
            source_table: Table name for entity mentions.

        Returns:
            CollectStats with collection statistics.
        """
        stats = CollectStats(source_type=source_type, project=project)
        start = time.monotonic()

        collector = self.registry.get(source_type)
        if not collector:
            stats.errors.append(f"No collector registered for type '{source_type}'")
            return stats

        # 1. Collect
        items: list[CollectorResult] = []
        try:
            async for item in collector.collect(config):
                items.append(item)
                if len(items) >= self.max_items_per_source:
                    break
        except Exception as e:
            stats.errors.append(f"Collection failed: {e}")
            logger.error("Collection error [%s/%s]: %s", project, source_type, e)

        stats.items_collected = len(items)

        # 2. Extract entities (if enabled and items collected)
        if self.extract_entities and self.extractor and items:
            for i, item in enumerate(items):
                try:
                    result = await self.extractor.extract_from_result(
                        session,
                        item=item,
                        source_project=project,
                        source_table=source_table,
                        source_id=i + 1,  # sequential ID within this batch
                    )
                    stats.entities_found += len(result.entities)
                    stats.mentions_added += result.mention_count
                    if result.errors:
                        stats.errors.extend(result.errors[:3])
                except Exception as e:
                    stats.errors.append(f"Entity extraction failed for item {i}: {e}")
                    logger.error("Extraction error: %s", e)

        stats.duration_ms = round((time.monotonic() - start) * 1000, 1)
        return stats

    async def run_sources(
        self,
        session: AsyncSession,
        *,
        sources: Sequence[dict],
        project: str,
    ) -> PipelineStats:
        """Run collection for multiple sources.

        Args:
            session: SQLAlchemy async session.
            sources: List of dicts with keys: source_type, config, [source_table].
                Example: [
                    {"source_type": "rss", "config": {"url": "..."}},
                    {"source_type": "http", "config": {"url": "..."}},
                ]
            project: Project name.

        Returns:
            PipelineStats with aggregated statistics.
        """
        pipeline_stats = PipelineStats()
        start = time.monotonic()

        for source_def in sources:
            source_type = source_def.get("source_type", "")
            config = source_def.get("config", {})
            source_table = source_def.get("source_table", "collector_results")

            stats = await self.run_source(
                session,
                source_type=source_type,
                config=config,
                project=project,
                source_table=source_table,
            )

            pipeline_stats.source_stats.append(stats)
            pipeline_stats.sources_run += 1
            pipeline_stats.total_items += stats.items_collected
            pipeline_stats.total_entities += stats.entities_found
            pipeline_stats.total_mentions += stats.mentions_added

        pipeline_stats.duration_ms = round((time.monotonic() - start) * 1000, 1)
        return pipeline_stats

    async def collect_all(
        self,
        session: AsyncSession,
        *,
        project: str,
        configs: dict[str, dict],
    ) -> PipelineStats:
        """Run all registered collectors with their configs.

        Args:
            session: SQLAlchemy async session.
            project: Project name.
            configs: Dict of source_type → config dict.
                Only collectors with matching config entries are run.

        Returns:
            PipelineStats with aggregated statistics.
        """
        sources = [
            {"source_type": stype, "config": config}
            for stype, config in configs.items()
            if stype in self.registry
        ]
        return await self.run_sources(session, sources=sources, project=project)
