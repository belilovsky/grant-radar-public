"""Entity Extractor – bridge between collected data and the Entity Store.

Takes CollectorResult items, runs NER (via kznlp), and writes entities
+ mentions to the Entity Store. This is the core integration point
between collection and the unified entity graph.

Usage::

    extractor = EntityExtractor(store=EntityStore())

    async with db.get_session() as session:
        entities = await extractor.extract_and_store(
            session,
            text="Президент Токаев встретился с Путиным в Астане",
            source_project="echo-sounder",
            source_table="messages",
            source_id=42,
        )
        # → [Entity(name="Токаев", type="PER"), Entity(name="Путин", type="PER"),
        #    Entity(name="Астана", type="LOC")]
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Sequence

from sqlalchemy.ext.asyncio import AsyncSession

from qazstack.entities.models import Entity
from qazstack.entities.store import EntityStore
from qazstack.monitor.collectors.base import CollectorResult

logger = logging.getLogger("qazstack.collectors.extractor")

# Label mapping: kznlp labels → Entity Store types
_LABEL_MAP: dict[str, str] = {
    "PER": "PER",
    "PERSON": "PER",
    "PERS": "PER",
    "ORG": "ORG",
    "ORGANIZATION": "ORG",
    "LOC": "LOC",
    "LOCATION": "LOC",
    "GPE": "LOC",  # Geo-Political Entity → LOC
    "EVENT": "EVENT",
    "MISC": "MISC",
    "PRODUCT": "MISC",
    "NORP": "ORG",  # Nationalities/political groups → ORG
}


def _map_label(label: str) -> str:
    """Map NER label to Entity Store type."""
    return _LABEL_MAP.get(label.upper(), "MISC")


@dataclass
class ExtractionResult:
    """Result of entity extraction from a single text."""

    entities: list[Entity] = field(default_factory=list)
    mention_count: int = 0
    errors: list[str] = field(default_factory=list)


class EntityExtractor:
    """Extract entities from text and store in Entity Store.

    Integrates kznlp NER with the Entity Store for automatic
    entity discovery and cross-project linking.
    """

    def __init__(
        self,
        store: EntityStore | None = None,
        *,
        min_confidence: float = 0.5,
        min_entity_length: int = 2,
        max_context_chars: int = 200,
    ) -> None:
        self.store = store or EntityStore()
        self.min_confidence = min_confidence
        self.min_entity_length = min_entity_length
        self.max_context_chars = max_context_chars
        self._ner_available: bool | None = None

    def _check_ner(self) -> bool:
        """Check if kznlp NER is available (lazy check, cached)."""
        if self._ner_available is None:
            try:
                from qazstack.kznlp import extract_entities  # noqa: F401
                self._ner_available = True
            except ImportError:
                self._ner_available = False
                logger.warning(
                    "kznlp NER not available. "
                    "Install with: pip install qazstack[nlp]"
                )
        return self._ner_available

    def _run_ner(self, text: str) -> list:
        """Run NER on text. Separated for easy mocking in tests."""
        from qazstack.kznlp import extract_entities
        return extract_entities(text)

    def _extract_context(self, text: str, entity_text: str) -> str:
        """Extract a context snippet around the entity mention."""
        pos = text.lower().find(entity_text.lower())
        if pos < 0:
            return text[: self.max_context_chars]
        start = max(0, pos - 80)
        end = min(len(text), pos + len(entity_text) + 80)
        snippet = text[start:end].strip()
        if start > 0:
            snippet = "…" + snippet
        if end < len(text):
            snippet = snippet + "…"
        return snippet[: self.max_context_chars]

    async def extract_and_store(
        self,
        session: AsyncSession,
        *,
        text: str,
        source_project: str,
        source_table: str,
        source_id: int,
        confidence: float = 1.0,
    ) -> ExtractionResult:
        """Run NER on text and store extracted entities + mentions.

        Args:
            session: SQLAlchemy async session.
            text: Text to extract entities from.
            source_project: Project name (e.g. "echo-sounder").
            source_table: Source table name (e.g. "messages").
            source_id: Source record ID.
            confidence: Confidence score for the mention.

        Returns:
            ExtractionResult with stored entities and mention count.
        """
        result = ExtractionResult()

        if not text or not text.strip():
            return result

        if not self._check_ner():
            result.errors.append("kznlp NER not available")
            return result

        # Run NER
        try:
            ner_entities = self._run_ner(text)
        except Exception as e:
            result.errors.append(f"NER failed: {e}")
            logger.error("NER extraction failed: %s", e)
            return result

        # Deduplicate NER results (same text+label appearing multiple times)
        seen: set[tuple[str, str]] = set()

        for ner_ent in ner_entities:
            ent_text = ner_ent.text.strip()
            if len(ent_text) < self.min_entity_length:
                continue

            entity_type = _map_label(ner_ent.label)
            key = (ent_text.lower(), entity_type)
            if key in seen:
                continue
            seen.add(key)

            try:
                # Add entity (with dedup)
                entity = await self.store.add_entity(
                    session,
                    name=ent_text,
                    entity_type=entity_type,
                    project=source_project,
                )

                # Add mention (with context)
                context = self._extract_context(text, ent_text)
                await self.store.add_mention(
                    session,
                    entity_id=entity.id,
                    source_project=source_project,
                    source_table=source_table,
                    source_id=source_id,
                    context=context,
                    confidence=confidence,
                )

                result.entities.append(entity)
                result.mention_count += 1

            except Exception as e:
                result.errors.append(f"Failed to store entity '{ent_text}': {e}")
                logger.error("Entity store failed for '%s': %s", ent_text, e)

        return result

    async def extract_from_result(
        self,
        session: AsyncSession,
        *,
        item: CollectorResult,
        source_project: str,
        source_table: str = "collector_results",
        source_id: int = 0,
    ) -> ExtractionResult:
        """Extract entities from a CollectorResult.

        Combines title + text for NER processing.
        """
        parts: list[str] = []
        if item.title:
            parts.append(item.title)
        if item.text:
            parts.append(item.text)
        combined = "\n".join(parts)

        return await self.extract_and_store(
            session,
            text=combined,
            source_project=source_project,
            source_table=source_table,
            source_id=source_id,
        )

    async def extract_batch(
        self,
        session: AsyncSession,
        *,
        items: Sequence[tuple[str, str, str, int]],
    ) -> list[ExtractionResult]:
        """Extract entities from multiple (text, project, table, id) tuples.

        Args:
            items: List of (text, source_project, source_table, source_id).

        Returns:
            List of ExtractionResult, one per input item.
        """
        results = []
        for text, project, table, source_id in items:
            r = await self.extract_and_store(
                session,
                text=text,
                source_project=project,
                source_table=table,
                source_id=source_id,
            )
            results.append(r)
        return results
