"""Provider-neutral media metadata and rights contracts."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from qazstack.contracts._validation import (
    require_aware,
    require_http_url,
    require_one_of,
    require_positive,
    require_text,
)


@dataclass(frozen=True, slots=True)
class MetadataValue:
    name: str
    value: str
    source: str
    unit: str | None = None

    def __post_init__(self) -> None:
        require_text(self.name, "name")
        require_text(self.value, "value")
        require_text(self.source, "source")


@dataclass(frozen=True, slots=True)
class MediaMetadata:
    mime_type: str
    size_bytes: int
    width: int | None = None
    height: int | None = None
    captured_at: datetime | None = None
    latitude: float | None = None
    longitude: float | None = None
    fields: tuple[MetadataValue, ...] = ()

    def __post_init__(self) -> None:
        require_text(self.mime_type, "mime_type")
        require_positive(self.size_bytes, "size_bytes")
        for name in ("width", "height"):
            value = getattr(self, name)
            if value is not None:
                require_positive(value, name)
        if (self.width is None) != (self.height is None):
            raise ValueError("width and height must be provided together")
        if self.captured_at is not None:
            require_aware(self.captured_at, "captured_at")
        if (self.latitude is None) != (self.longitude is None):
            raise ValueError("latitude and longitude must be provided together")
        if self.latitude is not None and not -90 <= self.latitude <= 90:
            raise ValueError("latitude is outside its valid range")
        if self.longitude is not None and not -180 <= self.longitude <= 180:
            raise ValueError("longitude is outside its valid range")


@dataclass(frozen=True, slots=True)
class LicenseTerms:
    normalized_license: str
    source_terms_url: str
    attribution_required: bool
    commercial_use_allowed: bool | None
    derivatives_allowed: bool | None
    attribution_text: str | None = None

    def __post_init__(self) -> None:
        require_text(self.normalized_license, "normalized_license")
        require_http_url(self.source_terms_url, "source_terms_url")
        if self.attribution_required and not (self.attribution_text or "").strip():
            raise ValueError("required attribution must include attribution_text")


@dataclass(frozen=True, slots=True)
class RightsDecision:
    decision: str
    reason: str
    policy_id: str
    decided_at: datetime

    def __post_init__(self) -> None:
        require_one_of(self.decision, frozenset({"allow", "deny", "review"}), "decision")
        require_text(self.reason, "reason")
        require_text(self.policy_id, "policy_id")
        require_aware(self.decided_at, "decided_at")
