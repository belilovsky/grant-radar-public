"""Provider-neutral external coverage records and resilient feed composition."""

from __future__ import annotations

import copy
import time
from collections.abc import Awaitable, Callable, Iterable
from dataclasses import dataclass
from datetime import datetime

from qazstack.contracts._validation import require_aware, require_http_url, require_one_of, require_text
from qazstack.resilience import get_breaker

_EDITORIAL_STATES = frozenset({"qazlake_live", "source_linked", "curated_reference"})
_RIGHTS_STATES = frozenset({"external_link_only", "licensed", "owned", "unknown"})
_CORRECTION_STATES = frozenset({"none_recorded", "corrected", "retracted", "disputed"})


@dataclass(frozen=True, slots=True)
class ExternalCoverageRecord:
    """Public-safe metadata for coverage that remains on the source publisher."""

    record_id: str
    title: str
    summary: str
    source_name: str
    source_url: str
    published_at: datetime
    canonical_path: str = ""
    category: str = "monitoring"
    editorial_state: str = "source_linked"
    provenance: str = "external_source"
    rights_status: str = "external_link_only"
    correction_status: str = "none_recorded"
    related_entity_ids: tuple[str, ...] = ()
    tags: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        for name in ("record_id", "title", "source_name", "provenance"):
            require_text(getattr(self, name), name)
        require_http_url(self.source_url, "source_url")
        require_aware(self.published_at, "published_at")
        require_one_of(self.editorial_state, _EDITORIAL_STATES, "editorial_state")
        require_one_of(self.rights_status, _RIGHTS_STATES, "rights_status")
        require_one_of(self.correction_status, _CORRECTION_STATES, "correction_status")
        if self.canonical_path and not self.canonical_path.startswith("/"):
            raise ValueError("canonical_path must be an absolute application path")
        if any(not value.strip() for value in (*self.related_entity_ids, *self.tags)):
            raise ValueError("related_entity_ids and tags cannot contain blank values")

    def to_public_dict(self) -> dict[str, object]:
        """Return the shared camel-case public projection used by web consumers."""

        return {
            "id": self.record_id,
            "title": self.title,
            "summary": self.summary,
            "sourceName": self.source_name,
            "sourceUrl": self.source_url,
            "publishedAt": self.published_at.isoformat(),
            "canonicalPath": self.canonical_path,
            "category": self.category,
            "recordType": "external_coverage",
            "editorialState": self.editorial_state,
            "provenance": self.provenance,
            "rightsStatus": self.rights_status,
            "correctionStatus": self.correction_status,
            "relatedEntityIds": list(self.related_entity_ids),
            "tags": list(self.tags),
        }


@dataclass(frozen=True, slots=True)
class ExternalCoveragePage:
    items: tuple[ExternalCoverageRecord, ...]
    source: str
    next_cursor: str | None = None

    def __post_init__(self) -> None:
        require_text(self.source, "source")

    def to_public_dict(self) -> dict[str, object]:
        return {
            "items": [item.to_public_dict() for item in self.items],
            "source": self.source,
            "nextCursor": self.next_cursor,
        }


@dataclass(frozen=True, slots=True)
class MediaFeedQuery:
    query: str = ""
    category: str = ""
    limit: int = 50
    cursor: int = 0

    def __post_init__(self) -> None:
        if not 1 <= self.limit <= 500:
            raise ValueError("limit must be between 1 and 500")
        if self.cursor < 0:
            raise ValueError("cursor cannot be negative")

    @property
    def cache_key(self) -> tuple[str, str, int]:
        return (self.query.strip().casefold(), self.category.strip().casefold(), self.cursor)


FeedFetcher = Callable[[MediaFeedQuery], Awaitable[ExternalCoveragePage | None]]


class ResilientMediaFeed:
    """Bound one external feed with cache, stale fallback and circuit breaking."""

    def __init__(
        self,
        fetcher: FeedFetcher,
        *,
        name: str,
        cache_ttl: float = 300.0,
        stale_ttl: float = 3600.0,
        failure_threshold: int = 3,
        recovery_timeout: float = 30.0,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        require_text(name, "name")
        if cache_ttl < 0 or stale_ttl < cache_ttl:
            raise ValueError("stale_ttl must be greater than or equal to cache_ttl")
        self._fetcher = fetcher
        self._cache_ttl = cache_ttl
        self._stale_ttl = stale_ttl
        self._clock = clock
        self._name = name
        self._failure_threshold = failure_threshold
        self._recovery_timeout = recovery_timeout
        self._cache: dict[tuple[str, str, int], tuple[float, ExternalCoveragePage]] = {}

    def clear(self) -> None:
        self._cache.clear()

    def _cached(self, query: MediaFeedQuery, max_age: float) -> ExternalCoveragePage | None:
        entry = self._cache.get(query.cache_key)
        if entry is None or self._clock() - entry[0] > max_age:
            return None
        page = entry[1]
        if len(page.items) < query.limit and page.next_cursor is not None:
            return None
        has_more = len(page.items) > query.limit or page.next_cursor is not None
        return ExternalCoveragePage(
            items=copy.deepcopy(page.items[: query.limit]),
            source=page.source,
            next_cursor=str(query.cursor + query.limit) if has_more else None,
        )

    def _store(self, query: MediaFeedQuery, page: ExternalCoveragePage) -> None:
        existing = self._cache.get(query.cache_key)
        if existing is not None:
            existing_page = existing[1]
            if len(existing_page.items) > len(page.items) and existing_page.next_cursor is None:
                return
        self._cache[query.cache_key] = (self._clock(), copy.deepcopy(page))

    async def fetch(self, query: MediaFeedQuery) -> ExternalCoveragePage | None:
        fresh = self._cached(query, self._cache_ttl)
        if fresh is not None:
            return fresh

        stale = self._cached(query, self._stale_ttl)
        breaker = get_breaker(
            self._name,
            failure_threshold=self._failure_threshold,
            recovery_timeout=self._recovery_timeout,
        )
        if not breaker.allow_request:
            return stale

        try:
            page = await self._fetcher(query)
        except Exception:
            breaker.record_failure()
            return stale

        if page is None:
            return stale
        breaker.record_success()
        self._store(query, page)
        return self._cached(query, self._cache_ttl)


def deduplicate_external_coverage(records: Iterable[ExternalCoverageRecord]) -> list[ExternalCoverageRecord]:
    """Deduplicate by source URL, then normalized publisher and title."""

    result: list[ExternalCoverageRecord] = []
    seen_urls: set[str] = set()
    seen_titles: set[tuple[str, str]] = set()
    for record in records:
        url_key = record.source_url.rstrip("/").casefold()
        title_key = (" ".join(record.source_name.casefold().split()), " ".join(record.title.casefold().split()))
        if url_key in seen_urls or title_key in seen_titles:
            continue
        seen_urls.add(url_key)
        seen_titles.add(title_key)
        result.append(record)
    return result
