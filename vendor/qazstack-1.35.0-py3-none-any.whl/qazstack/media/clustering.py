"""Deterministic clustering of originals and syndicated media copies."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Iterable, Mapping


def _datetime(value: object) -> datetime | None:
    if isinstance(value, datetime):
        parsed = value
    elif not value:
        return None
    else:
        try:
            parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        except ValueError:
            return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _comparable_datetime(value: datetime | None) -> datetime:
    if value is None:
        return datetime.max.replace(tzinfo=timezone.utc)
    return value


def _cluster_key(item: Mapping[str, Any], position: int) -> str:
    content_hash = str(item.get("content_hash") or "").strip()
    if content_hash:
        return f"hash:{content_hash}"
    url = str(item.get("url") or item.get("canonical_url") or "").strip()
    if url:
        return f"url:{url}"
    identifier = item.get("media_item_id", item.get("id", position))
    return f"item:{identifier}"


def _member_id(item: Mapping[str, Any], position: int) -> str:
    return str(item.get("media_item_id", item.get("id", position)))


def _representative_rank(item: Mapping[str, Any], position: int) -> tuple[int, bool, datetime, int]:
    published_at = _datetime(item.get("published_at"))
    return (
        0 if item.get("is_repost") is False else 1,
        published_at is None,
        _comparable_datetime(published_at),
        position,
    )


def cluster_syndicated_media(items: Iterable[Mapping[str, Any]]) -> list[dict[str, Any]]:
    """Collapse exact syndicated copies while preserving explainable metadata.

    ``content_hash`` is preferred over canonical URL. A declared original wins;
    otherwise the earliest observed item is the representative. This primitive
    intentionally groups only exact evidence; semantic near-duplicate candidates
    belong to an explicit, model-versioned compute stage. The returned records
    remain shallow copies of consumer input and add portable cluster fields.
    """
    clusters: dict[str, dict[str, Any]] = {}
    for position, source_item in enumerate(items):
        item = dict(source_item)
        published_at = _datetime(item.get("published_at"))
        key = _cluster_key(item, position)
        cluster = clusters.get(key)
        if cluster is None:
            cluster = {
                "representative": item,
                "representative_position": position,
                "key": key,
                "count": 0,
                "publishers": [],
                "member_ids": [],
                "earliest_at": published_at,
                "latest_at": published_at,
                "max_reach": 0,
            }
            clusters[key] = cluster

        cluster["count"] += 1
        publisher = str(item.get("publisher") or "").strip()
        if publisher and publisher not in cluster["publishers"]:
            cluster["publishers"].append(publisher)
        cluster["member_ids"].append(_member_id(item, position))
        reach = item.get("reach")
        if isinstance(reach, (int, float)):
            cluster["max_reach"] = max(cluster["max_reach"], reach)
        if published_at is not None:
            if cluster["earliest_at"] is None or published_at < cluster["earliest_at"]:
                cluster["earliest_at"] = published_at
            if cluster["latest_at"] is None or published_at > cluster["latest_at"]:
                cluster["latest_at"] = published_at

        if _representative_rank(item, position) < _representative_rank(
            cluster["representative"], cluster["representative_position"]
        ):
            cluster["representative"] = item
            cluster["representative_position"] = position

    result: list[dict[str, Any]] = []
    for cluster in clusters.values():
        representative = dict(cluster["representative"])
        representative["syndication_cluster_id"] = cluster["key"]
        representative["syndication_count"] = cluster["count"]
        representative["syndication_publishers"] = sorted(cluster["publishers"], key=str.casefold)
        representative["syndication_member_ids"] = sorted(set(cluster["member_ids"]))
        representative["cluster_basis"] = (
            "declared_original" if representative.get("is_repost") is False else "earliest_seen"
        )
        representative["cluster_earliest_at"] = cluster["earliest_at"]
        representative["cluster_latest_at"] = cluster["latest_at"]
        representative["reach"] = max(representative.get("reach") or 0, cluster["max_reach"]) or None
        result.append(representative)

    result.sort(key=lambda item: item["syndication_cluster_id"])
    result.sort(key=lambda item: _comparable_datetime(_datetime(item.get("cluster_latest_at"))), reverse=True)
    return result
