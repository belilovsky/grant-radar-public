"""Deterministic relevance helpers for event-centric media search.

The helpers deliberately have no HTTP or database dependency.  Callers fetch
candidate materials themselves, then use this module to build focused queries,
remove duplicates and rank the results around a known event.
"""

from __future__ import annotations

import re
from collections.abc import Iterable, Mapping
from datetime import date, datetime, timezone
from typing import Any

MediaItem = Mapping[str, Any]

_TOKEN_SPLIT_RE = re.compile(r"[\s,.;:!?()\[\]{}\"'«»\-––_/]+", re.UNICODE)
_KAZAKH_FOLDS = str.maketrans(
    {"ә": "а", "ғ": "г", "қ": "к", "ң": "н", "ө": "о", "ұ": "у", "ү": "у", "һ": "х", "і": "и", "ё": "е"}
)
_STOP_WORDS = frozenset(
    {
        "a",
        "an",
        "and",
        "are",
        "at",
        "by",
        "for",
        "from",
        "in",
        "into",
        "is",
        "of",
        "on",
        "or",
        "the",
        "to",
        "with",
        "без",
        "была",
        "были",
        "быть",
        "в",
        "во",
        "все",
        "вступление",
        "г",
        "года",
        "год",
        "для",
        "день",
        "дня",
        "его",
        "ее",
        "еще",
        "за",
        "из",
        "июнь",
        "июль",
        "июня",
        "июне",
        "июле",
        "их",
        "к",
        "как",
        "когда",
        "между",
        "методичка",
        "на",
        "над",
        "не",
        "него",
        "нее",
        "нет",
        "но",
        "новая",
        "нового",
        "новой",
        "новую",
        "новый",
        "праздник",
        "праздника",
        "праздничный",
        "государственный",
        "государственная",
        "государственное",
        "выходной",
        "выходные",
        "годовщина",
        "начало",
        "о",
        "об",
        "обзор",
        "около",
        "она",
        "они",
        "от",
        "по",
        "под",
        "при",
        "про",
        "с",
        "со",
        "силу",
        "событие",
        "события",
        "событий",
        "также",
        "тема",
        "темы",
        "то",
        "у",
        "это",
        "этот",
        "эта",
    }
)
_LOW_SIGNAL = frozenset({"дипломатия", "новости", "официальный", "рабочая", "рабочий", "визит"})
_COUNTRY_ALIASES = {
    "ae": ("оаэ", "эмиры", "emirates", "uae"),
    "be": ("бельгия", "белгия", "belgium", "belgique", "belgie"),
    "cn": ("китай", "қытай", "china"),
    "de": ("германия", "deutschland", "germany"),
    "fr": ("франция", "france"),
    "gb": ("великобритания", "британия", "uk", "britain", "united kingdom"),
    "kg": ("кыргызстан", "киргизия", "kyrgyzstan"),
    "kz": ("казахстан", "қазақстан", "kazakhstan"),
    "ru": ("россия", "рф", "russia"),
    "tr": ("турция", "түркия", "turkiye", "turkey"),
    "us": ("сша", "usa", "united states", "america"),
    "uz": ("узбекистан", "өзбекстан", "uzbekistan"),
}


def normalize_match_text(value: object) -> str:
    """Normalize text for tolerant Kazakh/Russian search matching."""
    return str(value or "").lower().translate(_KAZAKH_FOLDS)


def tokenize(value: object) -> list[str]:
    """Return normalized non-empty search tokens."""
    return [token for token in _TOKEN_SPLIT_RE.split(normalize_match_text(value)) if token]


def _useful(token: str) -> bool:
    return len(token) >= 4 and not token.isdigit() and token not in _STOP_WORDS


def _unique(items: Iterable[str]) -> list[str]:
    return list(dict.fromkeys(item for item in items if item))


def _country_terms(value: object) -> list[str]:
    normalized = normalize_match_text(value).strip()
    if normalized in _COUNTRY_ALIASES:
        return _unique((*_COUNTRY_ALIASES[normalized], normalized))
    return tokenize(normalized)


def build_event_media_keywords(event: Mapping[str, Any], *, limit: int = 10) -> list[str]:
    """Build ordered event terms, preferring specific contextual signals."""
    weighted: dict[str, tuple[int, int]] = {}
    order = 0

    def add(values: Iterable[object], weight: int) -> None:
        nonlocal order
        for value in values:
            for token in tokenize(value):
                if not _useful(token):
                    continue
                effective = max(1, weight - 4) if token in _LOW_SIGNAL else weight
                score, first_seen = weighted.get(token, (0, order))
                weighted[token] = (score + effective, first_seen)
                if token not in weighted or score == 0:
                    order += 1

    add(event.get("tags") or (), 5)
    add((event.get("name"),), 4)
    add((event.get("city"),), 3)
    add(_country_terms(event.get("country")), 2)
    add((event.get("venue"),), 2)
    add(event.get("actors") or (), 1)
    return [term for term, _ in sorted(weighted.items(), key=lambda item: (-item[1][0], item[1][1], item[0]))[:limit]]


def build_event_media_queries(event: Mapping[str, Any], *, limit: int = 4) -> list[str]:
    """Build concise search queries from ranked event terms."""
    keywords = build_event_media_keywords(event)
    name = normalize_match_text(event.get("name")).strip()
    if not keywords:
        fallback = " ".join(tokenize(event.get("name"))[:3])
        return [fallback] if fallback else []
    country = _country_terms(event.get("country"))
    terms = keywords + [None, None, None]
    queries = _unique(
        (
            " ".join(term for term in terms[:2] if term),
            " ".join(term for term in terms[:3] if term),
            name,
            " ".join(term for term in (terms[0], country[0] if country else None) if term),
            " ".join(term for term in (terms[0], normalize_match_text(event.get("city")).strip()) if term),
            terms[0],
        )
    )
    return [query for query in queries if len(query) >= 4][:limit]


def _item_text(item: MediaItem) -> str:
    keys = ("title", "text", "snippet", "domain", "channel_name", "source", "url")
    return normalize_match_text(" ".join(str(item.get(key) or "") for key in keys))


def _matches(haystack: str, keyword: str) -> bool:
    keyword = normalize_match_text(keyword)
    if keyword in haystack:
        return True
    stem = keyword[:-1] if len(keyword) >= 6 else ""
    return bool(stem) and any(token.startswith(stem) for token in tokenize(haystack))


def _event_date(value: object) -> date | None:
    try:
        return date.fromisoformat(str(value)[:10])
    except ValueError:
        return None


def _item_date(item: MediaItem) -> date | None:
    for key in ("pub_date", "published_at", "date", "created_at"):
        value = item.get(key)
        if value:
            try:
                return datetime.fromisoformat(str(value).replace("Z", "+00:00")).astimezone(timezone.utc).date()
            except ValueError:
                return _event_date(value)
    return None


def rank_event_media(
    items: Iterable[MediaItem],
    keywords: Iterable[str],
    *,
    event_name: str | None = None,
    event_date: str | None = None,
    limit: int = 20,
) -> list[dict[str, Any]]:
    """Return relevant candidates in descending deterministic relevance order.

    Each result is a shallow copy of the source item with ``relevance_score``.
    Generic event names require an exact event-name match to avoid broad noise.
    """
    keywords = list(keywords)
    normalized_name = normalize_match_text(event_name).strip()
    event_tokens = [token for token in tokenize(event_name) if _useful(token)]
    exact_required = len(event_tokens) <= 2 and len(keywords) <= 2
    event_day = _event_date(event_date)
    primary = [keyword for keyword in keywords if normalize_match_text(keyword) not in _LOW_SIGNAL][:3]
    ranked: list[tuple[int, date, dict[str, Any]]] = []
    for item in items:
        haystack = _item_text(item)
        title = normalize_match_text(item.get("title"))
        text = normalize_match_text(item.get("text") or item.get("snippet"))
        matched = 0
        score = 0
        for index, keyword in enumerate(keywords):
            if not _matches(haystack, keyword):
                continue
            matched += 1
            score += (4 if f" {normalize_match_text(keyword)} " in haystack else 2) + max(1, len(keywords) - index)
            if _matches(title, keyword):
                score += 3
        if keywords and _matches(title, keywords[0]):
            score += 6
        elif keywords and _matches(text, keywords[0]):
            score += 3
        exact = bool(normalized_name) and (normalized_name in title or normalized_name in text)
        primary_in_title = any(_matches(title, keyword) for keyword in primary)
        if exact:
            score += 12 if normalized_name in title else 8
        material_day = _item_date(item)
        if event_day and material_day:
            distance = abs((material_day - event_day).days)
            score += 6 if distance <= 14 else 3 if distance <= 45 else -4 if distance >= 120 else 0
        relevant = (matched >= 2 and primary_in_title) or exact
        if exact_required and normalized_name and not exact:
            relevant = False
        if relevant and score > 0:
            result = dict(item)
            result["relevance_score"] = score
            ranked.append((score, material_day or date.min, result))
    ranked.sort(key=lambda entry: (entry[0], entry[1]), reverse=True)
    return [item for _, _, item in ranked[: max(0, limit)]]


def dedupe_media_items(items: Iterable[MediaItem]) -> list[MediaItem]:
    """Preserve the first item for each normalized source and headline pair."""
    seen: set[str] = set()
    result: list[MediaItem] = []
    for item in items:
        title = normalize_match_text(item.get("title"))
        source = normalize_match_text(item.get("channel_name") or item.get("source") or item.get("domain"))
        if title:
            key = f"{source}|{title}"
        else:
            key = normalize_match_text(item.get("url") or item.get("text") or repr(sorted(item.items())))
        if key not in seen:
            seen.add(key)
            result.append(item)
    return result
