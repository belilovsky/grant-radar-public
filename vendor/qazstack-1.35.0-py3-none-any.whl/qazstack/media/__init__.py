"""QazLake Media client – unified image/media API for all Belilovsky projects.

Provides search, browse, ingest, similarity, face-search, and deduplication
against the QazLake images store. Works with R2 CDN (media.qazlake.kz).

Usage::

    from qazstack.media import MediaClient

    media = MediaClient()  # reads QAZLAKE_API_URL, QAZLAKE_API_KEY from env

    # Semantic search (SigLIP2 + CLIP + FTS + tags)
    results = await media.search("президент Токаев", limit=10)

    # Browse by topic
    photos = await media.browse(topic="politics", source_mode="qazlake")

    # Find similar images
    similar = await media.similar(image_id=28502, limit=5)

    # Ingest new image
    item = await media.ingest(url="https://example.com/photo.jpg", source_name="my_project")

    # Face search
    faces = await media.face_search(embedding=[0.1, 0.2, ...])

    # Find duplicates
    dupes = await media.find_duplicates(image_id=28502)

    # Get image URL for templates (R2 CDN)
    url = media.image_url(web_path="web/ab/cd/abcd1234.webp")
    thumb = media.thumb_url(thumb_path="thumb/ab/cd/abcd1234.webp")

    # Auto-suggest image for text content
    suggestion = await media.suggest_for_text("Парламент одобрил бюджет на 2027 год")

    # Stats
    stats = await media.stats()
"""

from qazstack.media.client import MediaClient, MediaError
from qazstack.media.clustering import cluster_syndicated_media
from qazstack.media.contracts import LicenseTerms, MediaMetadata, MetadataValue, RightsDecision
from qazstack.media.coverage import (
    ExternalCoveragePage,
    ExternalCoverageRecord,
    MediaFeedQuery,
    ResilientMediaFeed,
    deduplicate_external_coverage,
)
from qazstack.media.imageops import (
    ImageTransformResult,
    ImageTransformSpec,
    compute_dhash,
    duplicate_hash_groups,
    optimize_image_bytes,
)
from qazstack.media.relevance import (
    build_event_media_keywords,
    build_event_media_queries,
    dedupe_media_items,
    rank_event_media,
)

__all__ = [
    "MediaClient",
    "MediaError",
    "ExternalCoveragePage",
    "ExternalCoverageRecord",
    "MediaFeedQuery",
    "ResilientMediaFeed",
    "cluster_syndicated_media",
    "deduplicate_external_coverage",
    "build_event_media_keywords",
    "build_event_media_queries",
    "dedupe_media_items",
    "rank_event_media",
    "LicenseTerms",
    "MediaMetadata",
    "MetadataValue",
    "RightsDecision",
    "ImageTransformResult",
    "ImageTransformSpec",
    "compute_dhash",
    "duplicate_hash_groups",
    "optimize_image_bytes",
]
