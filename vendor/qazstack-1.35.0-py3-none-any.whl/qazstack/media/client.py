"""QazLake Media API client with retry, circuit breaker, and CDN URL helpers.

Environment variables:
    QAZLAKE_API_URL – base URL (default: http://qazlake_api:8000)
    QAZLAKE_API_KEY – API key for authenticated endpoints
    QAZLAKE_CDN_URL – R2 CDN base URL (default: https://media.qazlake.kz)
"""

from __future__ import annotations

import logging
import os
from typing import Any

import httpx

logger = logging.getLogger("qazstack.media")

_DEFAULT_API_URL = "http://qazlake_api:8101"
_DEFAULT_CDN_URL = "https://media.qazlake.kz"
_API_PREFIX = "/api/v1/images"


class MediaError(Exception):
    """Raised when QazLake API returns an error."""

    def __init__(self, message: str, status_code: int = 0, detail: str = ""):
        super().__init__(message)
        self.status_code = status_code
        self.detail = detail


class MediaClient:
    """Async client for QazLake Images API.

    Uses the same circuit-breaker pattern as qazstack.compute.ComputeClient.
    """

    def __init__(
        self,
        base_url: str | None = None,
        api_key: str | None = None,
        cdn_url: str | None = None,
        timeout: float = 30.0,
        max_retries: int = 2,
    ):
        self.base_url = (base_url or os.getenv("QAZLAKE_API_URL", _DEFAULT_API_URL)).rstrip("/")
        self.api_key = api_key or os.getenv("QAZLAKE_API_KEY", "")
        self.cdn_url = (cdn_url or os.getenv("QAZLAKE_CDN_URL", _DEFAULT_CDN_URL)).rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries
        self._client: httpx.AsyncClient | None = None

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            headers = {}
            if self.api_key:
                headers["X-API-Key"] = self.api_key
            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                headers=headers,
                timeout=self.timeout,
            )
        return self._client

    async def close(self) -> None:
        if self._client and not self._client.is_closed:
            await self._client.aclose()

    async def _request(self, method: str, path: str, **kwargs) -> Any:
        """Execute request with retry."""
        client = await self._get_client()
        last_err = None
        for attempt in range(self.max_retries + 1):
            try:
                resp = await getattr(client, method)(path, **kwargs)
                if resp.status_code >= 400:
                    detail = ""
                    try:
                        detail = resp.json().get("detail", resp.text[:200])
                    except Exception:
                        detail = resp.text[:200]
                    raise MediaError(
                        f"QazLake API error {resp.status_code}: {detail}",
                        status_code=resp.status_code,
                        detail=detail,
                    )
                return resp.json()
            except (httpx.ConnectError, httpx.ReadTimeout, httpx.WriteTimeout) as exc:
                last_err = exc
                if attempt < self.max_retries:
                    logger.warning("QazLake API retry %d: %s", attempt + 1, exc)
                    continue
        raise MediaError(f"QazLake API unreachable after {self.max_retries + 1} attempts: {last_err}")

    async def _get(self, path: str, params: dict | None = None) -> Any:
        return await self._request("get", path, params=params)

    async def _post(self, path: str, json: dict | None = None) -> Any:
        return await self._request("post", path, json=json)

    # ── Search & Browse ──────────────────────────────────────────────────

    async def search(
        self,
        query: str,
        limit: int = 20,
        source_mode: str = "all",
        use_siglip: bool = True,
        use_clip: bool = True,
        use_fts: bool = True,
        use_tags: bool = True,
        color_hex: str | None = None,
    ) -> list[dict]:
        """Hybrid semantic search (SigLIP2 + CLIP + FTS + tags)."""
        params: dict[str, Any] = {
            "q": query,
            "limit": limit,
            "source_mode": source_mode,
            "use_siglip": use_siglip,
            "use_clip": use_clip,
            "use_fts": use_fts,
            "use_tags": use_tags,
        }
        if color_hex:
            params["color"] = color_hex
        data = await self._get(f"{_API_PREFIX}/hybrid-search", params=params)
        return data.get("results", [])

    async def text_search(
        self,
        query: str,
        limit: int = 50,
        source_mode: str = "all",
        source: str = "all",
    ) -> list[dict]:
        """Full-text search only (faster, no ML)."""
        params = {"q": query, "limit": limit, "source_mode": source_mode, "source": source}
        data = await self._get(f"{_API_PREFIX}/search", params=params)
        return data.get("results", data.get("items", []))

    async def browse(
        self,
        topic: str | None = None,
        source: str | None = None,
        source_mode: str = "all",
        sort: str = "newest",
        limit: int = 50,
        offset: int = 0,
    ) -> dict:
        """Browse images by topic/source. Returns {total, count, results}."""
        params: dict[str, Any] = {
            "source_mode": source_mode,
            "sort": sort,
            "limit": limit,
            "offset": offset,
        }
        if topic:
            params["topic"] = topic
        if source:
            params["source"] = source
        return await self._get(f"{_API_PREFIX}/browse", params=params)

    async def topics(self) -> list[dict]:
        """List all topics with image counts."""
        return await self._get(f"{_API_PREFIX}/topics")

    # ── Single Image ─────────────────────────────────────────────────────

    async def get(self, image_id: int) -> dict:
        """Get full image metadata by ID."""
        return await self._get(f"{_API_PREFIX}/{image_id}")

    async def similar(self, image_id: int, limit: int = 10) -> list[dict]:
        """Find visually similar images (CLIP/SigLIP embedding distance)."""
        data = await self._get(f"{_API_PREFIX}/similar", params={"id": image_id, "limit": limit})
        return data if isinstance(data, list) else data.get("results", [])

    async def find_duplicates(self, image_id: int | None = None, dhash: str | None = None) -> list[dict]:
        """Find near-duplicate images via dHash."""
        params: dict[str, Any] = {}
        if image_id:
            params["id"] = image_id
        if dhash:
            params["dhash"] = dhash
        data = await self._get(f"{_API_PREFIX}/find-duplicates", params=params)
        return data if isinstance(data, list) else data.get("results", [])

    # ── Face Search ──────────────────────────────────────────────────────

    async def face_search(self, embedding: list[float], limit: int = 10) -> list[dict]:
        """Search by face embedding vector."""
        vec_str = "[" + ",".join(f"{v:.6f}" for v in embedding) + "]"
        data = await self._get(
            f"{_API_PREFIX}/face-search",
            params={"embedding": vec_str, "limit": limit},
        )
        return data if isinstance(data, list) else data.get("results", [])

    async def search_persons(self, query: str) -> list[dict]:
        """Search named persons."""
        return await self._get("/api/v1/persons/search", params={"q": query})

    # ── Ingest ───────────────────────────────────────────────────────────

    async def ingest(
        self,
        url: str,
        source_name: str,
        title: str = "",
        alt_text: str = "",
        caption: str = "",
        author: str = "",
        license: str = "unknown",
        tags: list[str] | None = None,
        use_forensics: bool = False,
        use_content: bool = True,
        source_date: str | None = None,
    ) -> dict:
        """Ingest a new image from URL into QazLake."""
        payload: dict[str, Any] = {
            "url": url,
            "source_name": source_name,
            "title": title,
            "alt_text": alt_text,
            "caption": caption,
            "author": author,
            "license": license,
            "tags": tags or [],
            "use_forensics": use_forensics,
            "use_content": use_content,
        }
        if source_date:
            payload["source_date"] = source_date
        return await self._post(f"{_API_PREFIX}/ingest", json=payload)

    async def ingest_batch(self, items: list[dict]) -> list[dict]:
        """Ingest multiple images. Each item should have at least {url, source_name}."""
        results = []
        for item in items:
            try:
                r = await self.ingest(**item)
                results.append(r)
            except MediaError as e:
                logger.warning("Ingest failed for %s: %s", item.get("url", "?"), e)
                results.append({"error": str(e), "url": item.get("url", "")})
        return results

    # ── Processing ───────────────────────────────────────────────────────

    async def embed(self, image_id: int) -> dict:
        """Trigger embedding generation for an image."""
        return await self._post(f"{_API_PREFIX}/embed", json={"image_id": image_id})

    async def auto_tag(self, image_id: int) -> dict:
        """Auto-tag an image using ML."""
        return await self._post(f"{_API_PREFIX}/auto-tag", json={"image_id": image_id})

    async def extract_colors(self, image_id: int) -> dict:
        """Extract dominant colors from an image."""
        return await self._post(f"{_API_PREFIX}/extract-colors", json={"image_id": image_id})

    # ── Stats ────────────────────────────────────────────────────────────

    async def stats(self) -> dict:
        """Get QazLake images module statistics."""
        return await self._get(f"{_API_PREFIX}/stats")

    async def health(self) -> dict:
        """Health check."""
        return await self._get("/health")

    # ── URL Helpers (sync, no API call) ──────────────────────────────────

    def image_url(self, web_path: str | None = None, item: dict | None = None) -> str:
        """Build CDN URL for web-optimized image.

        Args:
            web_path: Direct path like "web/ab/cd/abcd.webp"
            item: Image dict from search results (uses web_path field)
        """
        path = web_path or (item or {}).get("web_path", "")
        if not path:
            return ""
        return f"{self.cdn_url}/{path.lstrip('/')}"

    def thumb_url(self, thumb_path: str | None = None, item: dict | None = None) -> str:
        """Build CDN URL for thumbnail."""
        path = thumb_path or (item or {}).get("thumb_path", "")
        if not path:
            return ""
        return f"{self.cdn_url}/{path.lstrip('/')}"

    def source_url(self, item: dict) -> str:
        """Get original source URL of an image."""
        return item.get("source_url", "")

    # ── Convenience: suggest image for text content ──────────────────────

    async def suggest_for_text(
        self,
        text: str,
        limit: int = 5,
        source_mode: str = "qazlake",
        min_width: int = 600,
    ) -> list[dict]:
        """Find best matching images for a piece of text content.

        Useful for auto-illustrating articles, posts, events.
        Filters out small images and prefers stored (high-quality) ones.
        """
        results = await self.search(
            query=text[:200],  # Truncate long text for search
            limit=limit * 2,
            source_mode=source_mode,
        )
        # Filter by minimum width
        filtered = [r for r in results if (r.get("width") or 0) >= min_width]
        return filtered[:limit] if filtered else results[:limit]

    async def suggest_og_image(self, title: str, fallback_topic: str = "politics") -> str | None:
        """Suggest a single OG image URL for content with given title.

        Returns CDN URL or None if nothing found.
        """
        results = await self.suggest_for_text(title, limit=1, source_mode="qazlake")
        if results:
            return self.image_url(item=results[0])
        # Fallback: try topic browse
        browse = await self.browse(topic=fallback_topic, source_mode="qazlake", limit=1)
        items = browse.get("results", [])
        if items:
            return self.image_url(item=items[0])
        return None

    # ── Context manager ──────────────────────────────────────────────────

    # ── Video ─────────────────────────────────────────────────────────

    async def ingest_video(
        self,
        video_url: str,
        source_name: str = "wan_studio",
        title: str = "",
        tags: list[str] | None = None,
        prompt: str = "",
    ) -> dict:
        """Ingest a video from URL into QazLake CDN.

        Downloads the video from Wan Studio and stores in R2-backed CDN.
        Returns a dict with cdn_url for the stored video.

        Args:
            video_url: Source URL (e.g. https://vgen.qdev.run/api/video/1)
            source_name: Origin identifier
            title: Video title/description
            tags: Optional tags for search
            prompt: Original generation prompt (stored as metadata)
        """
        payload = {
            "url": video_url,
            "source_name": source_name,
            "title": title or "AI Generated Video",
            "tags": tags or ["video", "ai-generated", "wan2.2"],
            "metadata": {"prompt": prompt, "type": "video"},
        }
        return await self._post("/api/v1/videos/ingest", json=payload)

    def video_cdn_url(self, video_path: str | None = None, item: dict | None = None) -> str:
        """Build CDN URL for a stored video.

        Args:
            video_path: Direct path like "videos/ab/cd/abcd.mp4"
            item: Video dict from ingest result (uses video_path field)
        """
        path = video_path or (item or {}).get("video_path", "")
        if not path:
            return ""
        return f"{self.cdn_url}/{path.lstrip('/')}"

    # ── Context manager ──────────────────────────────────────────────────

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.close()
