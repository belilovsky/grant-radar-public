"""Framework-neutral contracts for configuration, releases and data safety."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Mapping

from qazstack.contracts._validation import (
    require_aware,
    require_identifier,
    require_one_of,
    require_positive,
    require_semver,
    require_sha256,
    require_text,
)

CONFIG_SCOPES = frozenset({"all", "development", "staging", "production"})
DEPLOY_STATUSES = frozenset({"prepared", "deployed", "failed", "rolled_back"})
MIGRATION_RISKS = frozenset({"low", "medium", "high"})
RESTORE_STATUSES = frozenset({"not_tested", "passed", "failed"})


@dataclass(frozen=True, slots=True)
class ConfigRule:
    """One explicit configuration requirement without exposing its value."""

    name: str
    required: bool = True
    secret: bool = False
    scope: str = "all"
    incompatible_with: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        require_text(self.name, "name")
        require_one_of(self.scope, CONFIG_SCOPES, "scope")
        if self.name in self.incompatible_with:
            raise ValueError("a configuration key cannot conflict with itself")


@dataclass(frozen=True, slots=True)
class ConfigIssue:
    name: str
    reason: str
    severity: str = "error"

    def __post_init__(self) -> None:
        require_text(self.name, "name")
        require_text(self.reason, "reason")
        require_one_of(self.severity, frozenset({"warning", "error"}), "severity")


def validate_config(
    values: Mapping[str, str | None],
    rules: tuple[ConfigRule, ...],
    *,
    environment: str,
) -> tuple[ConfigIssue, ...]:
    """Return configuration issues without logging secret values."""
    issues: list[ConfigIssue] = []
    active_rules = tuple(rule for rule in rules if rule.scope in {"all", environment})
    for rule in active_rules:
        present = bool((values.get(rule.name) or "").strip())
        if rule.required and not present:
            issues.append(ConfigIssue(rule.name, "required value is missing"))
        if not present:
            continue
        conflicts = sorted(name for name in rule.incompatible_with if (values.get(name) or "").strip())
        if conflicts:
            issues.append(ConfigIssue(rule.name, f"incompatible with: {', '.join(conflicts)}"))
    return tuple(issues)


@dataclass(frozen=True, slots=True)
class ArtifactRef:
    name: str
    digest: str
    size_bytes: int

    def __post_init__(self) -> None:
        require_text(self.name, "name")
        object.__setattr__(self, "digest", require_sha256(self.digest))
        require_positive(self.size_bytes, "size_bytes")


@dataclass(frozen=True, slots=True)
class ReleaseManifest:
    release_id: str
    version: str
    source_revision: str
    artifacts: tuple[ArtifactRef, ...]
    readiness_checks: tuple[str, ...]
    rollback_revision: str
    created_at: datetime
    backup_id: str | None = None

    def __post_init__(self) -> None:
        require_identifier(self.release_id, "release_id")
        require_semver(self.version)
        require_text(self.source_revision, "source_revision")
        require_text(self.rollback_revision, "rollback_revision")
        require_aware(self.created_at, "created_at")
        if not self.artifacts:
            raise ValueError("artifacts must not be empty")
        if not self.readiness_checks:
            raise ValueError("readiness_checks must not be empty")
        if len({artifact.name for artifact in self.artifacts}) != len(self.artifacts):
            raise ValueError("artifact names must be unique")


@dataclass(frozen=True, slots=True)
class DeploymentProof:
    release_id: str
    environment: str
    status: str
    verified_at: datetime
    checks: tuple[str, ...]
    deployed_revision: str | None = None
    rollback_id: str | None = None

    def __post_init__(self) -> None:
        require_identifier(self.release_id, "release_id")
        require_text(self.environment, "environment")
        require_one_of(self.status, DEPLOY_STATUSES, "status")
        require_aware(self.verified_at, "verified_at")
        if self.status == "deployed" and (not self.deployed_revision or not self.checks):
            raise ValueError("deployed proof requires a revision and checks")


@dataclass(frozen=True, slots=True)
class RollbackProof:
    rollback_id: str
    release_id: str
    restored_revision: str
    restored_at: datetime
    checks: tuple[str, ...]

    def __post_init__(self) -> None:
        require_identifier(self.rollback_id, "rollback_id")
        require_identifier(self.release_id, "release_id")
        require_text(self.restored_revision, "restored_revision")
        require_aware(self.restored_at, "restored_at")
        if not self.checks:
            raise ValueError("rollback proof requires verification checks")


@dataclass(frozen=True, slots=True)
class BackupManifest:
    backup_id: str
    created_at: datetime
    source_revision: str
    artifacts: tuple[ArtifactRef, ...]
    retention_days: int
    encrypted: bool

    def __post_init__(self) -> None:
        require_identifier(self.backup_id, "backup_id")
        require_aware(self.created_at, "created_at")
        require_text(self.source_revision, "source_revision")
        require_positive(self.retention_days, "retention_days")
        if not self.artifacts:
            raise ValueError("backup artifacts must not be empty")


@dataclass(frozen=True, slots=True)
class RestoreProof:
    backup_id: str
    status: str
    tested_at: datetime
    checks: tuple[str, ...]
    target: str

    def __post_init__(self) -> None:
        require_identifier(self.backup_id, "backup_id")
        require_one_of(self.status, RESTORE_STATUSES, "status")
        require_aware(self.tested_at, "tested_at")
        require_text(self.target, "target")
        if self.status == "passed" and not self.checks:
            raise ValueError("passed restore proof requires checks")


@dataclass(frozen=True, slots=True)
class MigrationStep:
    revision: str
    description: str
    backward_compatible: bool

    def __post_init__(self) -> None:
        require_text(self.revision, "revision")
        require_text(self.description, "description")


@dataclass(frozen=True, slots=True)
class MigrationPlan:
    migration_id: str
    from_revision: str
    to_revision: str
    steps: tuple[MigrationStep, ...]
    risk: str
    backup_required: bool = True
    dry_run_required: bool = True

    def __post_init__(self) -> None:
        require_identifier(self.migration_id, "migration_id")
        require_text(self.from_revision, "from_revision")
        require_text(self.to_revision, "to_revision")
        require_one_of(self.risk, MIGRATION_RISKS, "risk")
        if not self.steps:
            raise ValueError("migration steps must not be empty")
        if self.steps[-1].revision != self.to_revision:
            raise ValueError("last migration step must match to_revision")

    @property
    def rolling_deploy_safe(self) -> bool:
        return all(step.backward_compatible for step in self.steps)


@dataclass(frozen=True, slots=True)
class MigrationProof:
    migration_id: str
    applied_at: datetime
    applied_revision: str
    dry_run_passed: bool
    backup_id: str | None
    checks: tuple[str, ...] = field(default_factory=tuple)

    def __post_init__(self) -> None:
        require_identifier(self.migration_id, "migration_id")
        require_aware(self.applied_at, "applied_at")
        require_text(self.applied_revision, "applied_revision")
        if not self.dry_run_passed:
            raise ValueError("migration proof requires a successful dry run")
        if not self.checks:
            raise ValueError("migration proof requires post-migration checks")
