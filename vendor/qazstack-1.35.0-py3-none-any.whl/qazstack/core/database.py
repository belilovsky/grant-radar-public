"""Unified async database module.

Supports PostgreSQL (asyncpg) and SQLite (aiosqlite).

Usage:
    from qazstack.core import Database

    db = Database("postgresql+asyncpg://user:pass@db:5432/mydb")

    # In lifespan:
    async with db:
        ...

    # In routes:
    async with db.session() as session:
        result = await session.execute(select(MyModel))
"""

from __future__ import annotations

from contextlib import asynccontextmanager
from typing import AsyncGenerator

from sqlalchemy import MetaData
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase

# Naming convention for constraints (Alembic-friendly)
convention = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}


class Base(DeclarativeBase):
    """Base class for all SQLAlchemy models across projects."""

    metadata = MetaData(naming_convention=convention)


class Database:
    """Async database manager.

    Can be used as an async context manager in FastAPI lifespan,
    or managed manually with init() / dispose().
    """

    def __init__(
        self,
        url: str,
        *,
        pool_size: int = 5,
        max_overflow: int = 10,
        echo: bool = False,
    ):
        if not url:
            self._engine = None
            self._session_factory = None
            return

        # Convert sync URLs to async
        if url.startswith("postgresql://"):
            url = url.replace("postgresql://", "postgresql+asyncpg://", 1)
        elif url.startswith("sqlite:///"):
            url = url.replace("sqlite:///", "sqlite+aiosqlite:///", 1)

        engine_kwargs: dict = {"echo": echo}
        if "postgresql" in url:
            engine_kwargs.update(pool_size=pool_size, max_overflow=max_overflow)

        self._engine = create_async_engine(url, **engine_kwargs)
        self._session_factory = async_sessionmaker(
            self._engine,
            class_=AsyncSession,
            expire_on_commit=False,
        )

    async def __aenter__(self) -> "Database":
        return self

    async def __aexit__(self, *exc) -> None:
        await self.dispose()

    @property
    def engine(self):
        """Access the underlying async engine."""
        return self._engine

    @asynccontextmanager
    async def session(self) -> AsyncGenerator[AsyncSession, None]:
        """Provide a transactional async session scope."""
        if not self._session_factory:
            raise RuntimeError("Database not configured (empty URL)")
        async with self._session_factory() as session:
            try:
                yield session
                await session.commit()
            except Exception:
                await session.rollback()
                raise

    async def get_session(self) -> AsyncGenerator[AsyncSession, None]:
        """FastAPI Depends() compatible session generator.

        Usage:
            @app.get("/items")
            async def get_items(session: AsyncSession = Depends(db.get_session)):
                ...
        """
        async with self.session() as session:
            yield session

    async def create_tables(self) -> None:
        """Create all tables from Base.metadata. Use for dev/testing only."""
        if not self._engine:
            return
        async with self._engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)

    async def dispose(self) -> None:
        """Close engine and all connections."""
        if self._engine:
            await self._engine.dispose()
