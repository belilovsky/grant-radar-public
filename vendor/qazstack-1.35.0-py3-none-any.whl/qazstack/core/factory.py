"""App factory – create a fully configured FastAPI application.

Usage:
    from qazstack.core import create_app, BaseConfig

    class Settings(BaseConfig):
        app_name: str = "MyProject"

    settings = Settings()
    app = create_app(settings)
"""

from __future__ import annotations

from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, AsyncGenerator, Callable, Sequence

from fastapi import FastAPI
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from qazstack.core.config import BaseConfig
from qazstack.core.database import Database
from qazstack.core.health import create_health_router, health_router


def create_app(
    settings: BaseConfig,
    *,
    routers: Sequence[Any] | None = None,
    static_dir: str | Path | None = None,
    templates_dir: str | Path | None = None,
    database: Database | None = None,
    on_startup: Callable | None = None,
    on_shutdown: Callable | None = None,
    middleware: Sequence[tuple] | None = None,
    jinja_globals: dict[str, Any] | None = None,
) -> FastAPI:
    """Create and configure a FastAPI application.

    Args:
        settings: Application settings (subclass of BaseConfig).
        routers: List of APIRouter instances to include.
        static_dir: Path to static files directory.
        templates_dir: Path to Jinja2 templates directory.
        database: Database instance for lifespan management.
        on_startup: Async callable to run on startup (after DB init).
        on_shutdown: Async callable to run on shutdown (before DB dispose).
        middleware: List of (MiddlewareClass, kwargs) tuples.
        jinja_globals: Extra globals to inject into Jinja2 templates.

    Returns:
        Configured FastAPI application instance.
    """

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
        # Startup
        if database:
            app.state.db = database
        if on_startup:
            await on_startup()
        yield
        # Shutdown
        if on_shutdown:
            await on_shutdown()
        if database:
            await database.dispose()

    app = FastAPI(
        title=settings.app_name,
        version=settings.version,
        lifespan=lifespan,
        docs_url=settings.docs_url,
        redoc_url=None,
    )

    # Store settings on app state
    app.state.settings = settings

    # --- Middleware ---
    app.add_middleware(GZipMiddleware, minimum_size=1000)
    if middleware:
        for mw_class, mw_kwargs in middleware:
            app.add_middleware(mw_class, **mw_kwargs)

    # --- Static files ---
    if static_dir:
        static_path = Path(static_dir)
        if static_path.is_dir():
            app.mount("/static", StaticFiles(directory=str(static_path)), name="static")

    # --- Templates ---
    if templates_dir:
        tpl_path = Path(templates_dir)
        if tpl_path.is_dir():
            templates = Jinja2Templates(directory=str(tpl_path))
            # Inject globals
            if jinja_globals:
                templates.env.globals.update(jinja_globals)
            app.state.templates = templates

    # --- Health check ---
    if database:
        app.include_router(
            create_health_router(db=database, redis_url=settings.redis_url)
        )
    else:
        app.include_router(health_router)

    # --- Custom routers ---
    if routers:
        for router in routers:
            app.include_router(router)

    return app
