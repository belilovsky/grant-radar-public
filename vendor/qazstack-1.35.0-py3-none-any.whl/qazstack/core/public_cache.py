"""Reusable conditional-cache middleware for public HTML pages."""

from __future__ import annotations

import hashlib
from collections.abc import Callable, Iterable

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response


def weak_etag(*, namespace: str, fingerprint: str, last_modified: str, path: str, query: str = "") -> str:
    """Build a stable weak ETag from a deployment/content fingerprint."""
    value = "|".join((namespace, fingerprint, last_modified, path, query))
    digest = hashlib.sha256(value.encode("utf-8")).hexdigest()[:16]
    return f'W/"{namespace}-{digest}"'


def append_vary(response: Response, value: str) -> None:
    """Append one Vary token without duplicating existing header values."""
    current = response.headers.get("Vary")
    if not current:
        response.headers["Vary"] = value
        return
    existing = {item.strip().lower() for item in current.split(",")}
    if value.lower() not in existing:
        response.headers["Vary"] = f"{current}, {value}"


def etag_matches(value: str | None, etag: str) -> bool:
    """Support a normal HTTP If-None-Match list without parsing unsafe input."""
    return any(candidate.strip() in {etag, "*"} for candidate in (value or "").split(","))


class PublicCacheMiddleware(BaseHTTPMiddleware):
    """Add ETag, Last-Modified and shared-cache policy to selected HTML routes.

    Dynamic values are callables so a consumer can refresh its own content
    fingerprint without rebuilding the middleware stack.
    """

    def __init__(
        self,
        app,
        *,
        is_public_path: Callable[[str], bool],
        fingerprint: Callable[[], str],
        last_modified: Callable[[], str],
        cache_control: Callable[[str], str],
        namespace: str = "public",
        vary: Iterable[str] = ("Accept-Language",),
    ) -> None:
        super().__init__(app)
        self.is_public_path = is_public_path
        self.fingerprint = fingerprint
        self.last_modified = last_modified
        self.cache_control = cache_control
        self.namespace = namespace
        self.vary = tuple(vary)

    async def dispatch(self, request: Request, call_next) -> Response:
        path = request.url.path
        is_public = request.method in {"GET", "HEAD"} and self.is_public_path(path)
        if not is_public:
            return await call_next(request)

        modified = self.last_modified()
        etag = weak_etag(
            namespace=self.namespace,
            fingerprint=self.fingerprint(),
            last_modified=modified,
            path=path,
            query=request.url.query,
        )
        headers = {
            "ETag": etag,
            "Last-Modified": modified,
            "Cache-Control": self.cache_control(path),
        }
        if etag_matches(request.headers.get("if-none-match"), etag):
            headers["Vary"] = ", ".join(self.vary)
            return Response(status_code=304, headers=headers)

        response = await call_next(request)
        response.headers["ETag"] = etag
        response.headers["Last-Modified"] = modified
        for vary in self.vary:
            append_vary(response, vary)
        if (
            response.status_code == 200
            and "text/html" in response.headers.get("content-type", "")
            and "Cache-Control" not in response.headers
        ):
            response.headers["Cache-Control"] = self.cache_control(path)
        return response
