"""Health check endpoint – mandatory for every project.

Provides /health route that Platform Monitor checks.
Optionally checks database and Redis connectivity.
"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter

health_router = APIRouter(tags=["health"])


@health_router.get("/health")
@health_router.get("/healthz")
async def health_check() -> dict[str, Any]:
    """Basic liveness check."""
    return {"status": "ok"}


def create_health_router(
    *,
    db=None,
    redis_url: str = "",
) -> APIRouter:
    """Create a health router with optional dependency checks.

    Args:
        db: Database instance to check connectivity.
        redis_url: Redis URL to check connectivity.
    """
    router = APIRouter(tags=["health"])

    @router.get("/health")
    @router.get("/healthz")
    async def detailed_health() -> dict[str, Any]:
        checks: dict[str, str] = {}
        overall = "ok"

        # Database check
        if db and db.engine:
            try:
                from sqlalchemy import text

                async with db.session() as session:
                    await session.execute(text("SELECT 1"))
                checks["database"] = "ok"
            except Exception as e:
                checks["database"] = f"error: {e}"
                overall = "degraded"

        # Redis check
        if redis_url:
            try:
                from redis.asyncio import from_url

                r = from_url(redis_url)
                await r.ping()
                await r.aclose()
                checks["redis"] = "ok"
            except Exception as e:
                checks["redis"] = f"error: {e}"
                overall = "degraded"

        return {"status": overall, "checks": checks}

    return router
