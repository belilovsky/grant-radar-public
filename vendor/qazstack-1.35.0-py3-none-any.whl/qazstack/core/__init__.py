"""Core module: app factory, config, database, health and lightweight web helpers."""

from qazstack.core.health import health_router
from qazstack.core.operations import (
    ArtifactRef,
    BackupManifest,
    ConfigIssue,
    ConfigRule,
    DeploymentProof,
    MigrationPlan,
    MigrationProof,
    MigrationStep,
    ReleaseManifest,
    RestoreProof,
    RollbackProof,
    validate_config,
)
from qazstack.core.public_cache import PublicCacheMiddleware, append_vary, etag_matches, weak_etag

# Public cache helpers are deliberately usable in small consumers that mount
# QazStack source without the factory/database dependency set.
try:
    from qazstack.core.config import BaseConfig
    from qazstack.core.database import Database
    from qazstack.core.factory import create_app
except ImportError:
    BaseConfig = None  # type: ignore[assignment,misc]
    Database = None  # type: ignore[assignment,misc]
    create_app = None  # type: ignore[assignment]

__all__ = [
    "BaseConfig",
    "Database",
    "create_app",
    "health_router",
    "PublicCacheMiddleware",
    "append_vary",
    "etag_matches",
    "weak_etag",
    "ArtifactRef",
    "BackupManifest",
    "ConfigIssue",
    "ConfigRule",
    "DeploymentProof",
    "MigrationPlan",
    "MigrationProof",
    "MigrationStep",
    "ReleaseManifest",
    "RestoreProof",
    "RollbackProof",
    "validate_config",
]
