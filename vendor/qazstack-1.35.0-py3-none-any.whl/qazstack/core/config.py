"""Unified config base for all projects.

Usage in a project:
    from qazstack.core import BaseConfig

    class Settings(BaseConfig):
        # Project-specific settings
        openai_api_key: str = ""
        telegram_bot_token: str = ""

    settings = Settings()
"""

from __future__ import annotations

from typing import Literal

from pydantic_settings import BaseSettings


class BaseConfig(BaseSettings):
    """Base settings shared across all Belilovsky Platform projects.

    Reads from .env file automatically. Override fields in subclass
    for project-specific configuration.
    """

    # --- Application ---
    app_name: str = "QazStack App"
    version: str = "1.0.0"
    debug: bool = False
    secret_key: str = "change-me-in-production"
    environment: Literal["dev", "staging", "prod"] = "prod"

    # --- Server ---
    host: str = "0.0.0.0"
    port: int = 8000
    workers: int = 2

    # --- Database ---
    database_url: str = ""
    db_pool_size: int = 5
    db_max_overflow: int = 10
    db_echo: bool = False

    # --- Redis (optional) ---
    redis_url: str = ""

    # --- i18n ---
    default_lang: str = "ru"
    supported_langs: list[str] = ["ru", "kz", "en"]

    # --- Logging ---
    log_level: str = "INFO"

    model_config = {
        "env_file": ".env",
        "env_file_encoding": "utf-8",
        "extra": "ignore",
    }

    @property
    def is_dev(self) -> bool:
        return self.environment == "dev"

    @property
    def is_prod(self) -> bool:
        return self.environment == "prod"

    @property
    def docs_url(self) -> str | None:
        """Show API docs only in dev/debug mode."""
        return "/api/docs" if self.debug or self.is_dev else None
