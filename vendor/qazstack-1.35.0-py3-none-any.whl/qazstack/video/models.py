"""Pydantic models for video generation API."""

from __future__ import annotations
from pydantic import BaseModel, Field


class VideoGenerateRequest(BaseModel):
    """Request to generate a video."""

    mode: str = Field(
        "t2v",
        description="Generation mode: t2v (text-to-video) or i2v (image-to-video)",
    )
    prompt: str = Field(
        ...,
        min_length=1,
        max_length=5000,
        description="Text prompt describing the video",
    )
    negative_prompt: str = Field(
        "",
        max_length=2000,
        description="What to avoid in generation",
    )
    model: str = Field(
        "wan2.2_t2v_high_noise_14B_fp8_scaled",
        description="Model name",
    )
    width: int = Field(480, ge=256, le=1920)
    height: int = Field(480, ge=256, le=1920)
    frames: int = Field(
        33,
        description="Number of frames: 17 (~1s), 33 (~2s), 65 (~4s)",
    )
    steps: int = Field(20, ge=1, le=50, description="Denoising steps")
    cfg: float = Field(6.0, ge=1.0, le=20.0, description="CFG scale")
    use_lora: bool = Field(False, description="Use 4-step LoRA acceleration")

    def to_api_dict(self) -> dict:
        """Convert to Wan Studio API format (camelCase)."""
        return {
            "mode": self.mode,
            "prompt": self.prompt,
            "negativePrompt": self.negative_prompt,
            "model": self.model,
            "width": self.width,
            "height": self.height,
            "frames": self.frames,
            "steps": 4 if self.use_lora else self.steps,
            "cfg": self.cfg,
            "useLora": self.use_lora,
        }


class VideoGenerateResponse(BaseModel):
    """Response from video generation submission."""

    id: int
    prompt_id: str
    status: str
    prompt: str
    mode: str = "t2v"


class VideoStatusResponse(BaseModel):
    """Full status of a video generation."""

    id: int
    prompt_id: str
    mode: str
    prompt: str
    status: str  # pending, running, completed, failed
    output_filename: str | None = None
    error_message: str | None = None
    width: int = 480
    height: int = 480
    frames: int = 33
    steps: int = 20
    cfg: float = 6.0
    use_lora: bool = False
    created_at: str | None = None


class GpuStatusResponse(BaseModel):
    """GPU status from Wan Studio."""

    online: bool
    gpu_name: str | None = None
    vram_total_gb: float | None = None
    vram_used_gb: float | None = None
    vram_free_gb: float | None = None
    queue_running: int = 0
    queue_pending: int = 0


class VideoPreset(BaseModel):
    """A prompt preset for video generation."""

    id: int | None = None
    name: str
    prompt: str
    negative_prompt: str = ""
