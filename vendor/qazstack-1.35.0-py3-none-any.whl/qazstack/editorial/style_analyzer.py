"""
qazstack.editorial.style_analyzer
===================================
Вычисление стилометрических метрик из текста (ru/kk).

Возвращает ``StyleProfile`` с 64+ числовыми параметрами.
Использует ``qazstack.kznlp`` для токенизации, лемматизации и детекции языка,
``pymorphy3`` для морфологии русского (lazy-loaded singleton).

Научный фундамент:
  - TTR/MTLD:        McCarthy & Jarvis (2010)
  - Yule's K:        Yule (1944)
  - F-score:         Heylighen & Dewaele (2002)
  - Passive ratio:   PRTS-based (pymorphy3) + regex fallback
  - Agglutination:   token/lemma ratio heuristic
  - Vowel harmony:   front/back vowel co-occurrence

Версия: 0.3.2 (production-ready, v0.3.1 short-text handling included)
"""
from __future__ import annotations

import math
import re
import statistics
from collections import Counter
from typing import Optional

try:
    from qazstack.kznlp import (
        STOPWORDS_KK,
        STOPWORDS_RU,
        detect_lang,
        is_stopword,
        lemmatize_tokens,
        sent_tokenize,
        tokenize,
    )
    _HAS_KZNLP = True
except ImportError:
    # Fallback stubs for environments without qazstack installed
    import warnings
    warnings.warn("qazstack.kznlp not available – using minimal stubs", stacklevel=2)
    STOPWORDS_KK: frozenset = frozenset()
    STOPWORDS_RU: frozenset = frozenset({"и", "в", "не", "на", "с", "что", "он", "она", "это", "как", "а", "но", "по", "к", "из", "за", "для", "о", "от", "до", "у", "же"})
    def detect_lang(text: str) -> str:
        kk_chars = set("әғқңөұүіһ")
        return "kk" if any(c in kk_chars for c in text.lower()) else "ru"
    def is_stopword(word: str, lang: str = "ru") -> bool:
        return word.lower() in (STOPWORDS_KK if lang == "kk" else STOPWORDS_RU)
    def lemmatize_tokens(tokens: list, lang: str = "ru") -> list:
        return tokens  # identity fallback
    def sent_tokenize(text: str) -> list:
        import re as _re
        return [s.strip() for s in _re.split(r'[.!?]+', text) if s.strip()]
    def tokenize(text: str) -> list:
        import re as _re
        return _re.findall(r'\w+', text)
    _HAS_KZNLP = False

from .models import StyleProfile


# ─────────────────────────────────────────────────────────────────────────────
# Константы – русский язык
# ─────────────────────────────────────────────────────────────────────────────

# Служебные слова для русского (по Barakhnin et al., 2022)
RU_FUNC_WORDS: frozenset[str] = frozenset([
    "и", "в", "не", "на", "с", "что", "а", "по", "к", "из", "за",
    "же", "бы", "ли", "ведь", "то", "вот", "даже", "лишь", "только",
    "именно", "однако", "впрочем", "пожалуй", "видимо", "конечно",
    "хотя", "если", "поскольку", "при", "от", "до", "или", "но",
    "это", "он", "она", "они", "мы", "вы", "я", "его", "её", "их",
    "об", "всё", "так", "уже", "ещё", "тоже", "также", "но", "ну",
    "вот", "ведь", "же", "бы", "б", "ли", "ль", "со", "во", "обо",
])

# Хеджи (маркеры неопределённости / осторожности)
RU_HEDGES: frozenset[str] = frozenset([
    "может", "мог", "возможно", "вероятно", "по-видимому",
    "предположительно", "около", "примерно", "порядка", "в среднем",
    "следует", "должен", "обязан", "нужно", "необходимо",
    "считается", "полагается", "предполагается", "видимо", "наверное",
    "пожалуй", "едва ли", "вряд ли", "по всей видимости",
    "по всей вероятности", "по имеющимся данным",
])

# Авторитативные эвиденциалы (ссылки на источники)
RU_EVIDENTIAL: frozenset[str] = frozenset([
    "по данным", "согласно", "по словам", "по мнению",
    "как отмечается", "как указывается", "по информации",
    "по сведениям", "по оценкам", "как сообщает", "как отметил",
])

# Аргументационные маркеры
RU_ARG_MARKERS: frozenset[str] = frozenset([
    "следовательно", "таким образом", "в результате", "поэтому",
    "что свидетельствует", "что указывает", "доказывает", "подтверждает",
    "как показывает", "в связи с этим", "из чего следует",
    "это означает", "что говорит о", "на основании",
])

# Дискурсивные коннекторы (4 типа)
RU_CONNECTORS: dict[str, frozenset[str]] = {
    "additive": frozenset([
        "также", "кроме того", "более того", "к тому же", "при этом",
        "помимо этого", "вдобавок", "наряду с этим", "аналогично",
    ]),
    "adversative": frozenset([
        "однако", "тем не менее", "вместе с тем", "несмотря на",
        "хотя", "но", "зато", "впрочем", "между тем", "при всём этом",
    ]),
    "causal": frozenset([
        "поэтому", "следовательно", "таким образом", "в результате",
        "ввиду", "поскольку", "вследствие", "из-за этого", "благодаря",
    ]),
    "conclusive": frozenset([
        "в заключение", "подводя итог", "итак", "в конечном счёте",
        "резюмируя", "в итоге", "в целом", "в общем",
    ]),
}

# Усилители (boosters)
RU_BOOSTERS: frozenset[str] = frozenset([
    "очевидно", "несомненно", "безусловно", "явно", "бесспорно",
    "определённо", "совершенно", "абсолютно", "совершенно очевидно",
    "не вызывает сомнений", "вне всякого сомнения",
])

# Положительная лексика для сентимента
_RU_POSITIVE: frozenset[str] = frozenset([
    "рост", "увеличение", "улучшение", "положительный", "успешный",
    "достижение", "прогресс", "развитие", "укрепление", "стабилизация",
    "восстановление", "подъём", "выгода", "преимущество", "эффективный",
])

# Отрицательная лексика для сентимента
_RU_NEGATIVE: frozenset[str] = frozenset([
    "снижение", "падение", "ухудшение", "проблема", "риск", "дефицит",
    "кризис", "потеря", "угроза", "нарушение", "сокращение", "спад",
    "препятствие", "ослабление", "нестабильность",
])


# ─────────────────────────────────────────────────────────────────────────────
# Константы – казахский язык
# ─────────────────────────────────────────────────────────────────────────────

KK_FUNC_WORDS: frozenset[str] = frozenset([
    "және", "мен", "бірақ", "де", "да", "ма", "ме", "ба", "бе",
    "па", "пе", "екен", "ғой", "шығар", "не", "бұл", "ол", "осы",
    "сол", "оның", "өз", "осыған", "оған",
])

KK_HEDGES: frozenset[str] = frozenset([
    "мүмкін", "болар", "сияқты", "деген", "екен", "шығар",
    "болуы мүмкін", "ықтимал", "тәрізді", "болса керек",
    "деп ойлаймыз", "болуы ықтимал",
])

KK_EVIDENTIAL: frozenset[str] = frozenset([
    "екен", "көрінеді", "айтылған", "белгілі", "анықталған",
    "болған", "деректерге сәйкес", "мәліметтерге сүйенсек",
    "хабарлайды", "мәлімдейді",
])

KK_MODAL_PARTICLES: frozenset[str] = frozenset([
    "ғой", "шығар", "қой", "де", "ма", "ме", "ба", "бе",
    "екен", "болса", "ші",
])

KK_POSTPOSITIONS: frozenset[str] = frozenset([
    "үшін", "бойынша", "туралы", "арқылы", "қарай", "дейін",
    "соң", "кейін", "бұрын", "қарсы", "жайында", "жанында",
    "алдында", "артында", "астында", "үстінде",
])

KK_ARG_MARKERS: frozenset[str] = frozenset([
    "сондықтан", "демек", "нәтижесінде", "осылайша",
    "куәландырады", "дәлелдейді", "көрсеткендей",
    "байланысты", "себебі",
])

KK_CONNECTORS: dict[str, frozenset[str]] = {
    "additive": frozenset(["сонымен қатар", "одан басқа", "сондай-ақ", "бұдан өзге"]),
    "adversative": frozenset(["бірақ", "алайда", "дегенмен", "соған қарамастан", "десе де"]),
    "causal": frozenset(["сондықтан", "демек", "нәтижесінде", "себебі", "өйткені"]),
    "conclusive": frozenset(["қорытындылай келе", "сөз жоқ", "жиынтығында", "жалпы алғанда"]),
}

KK_BOOSTERS: frozenset[str] = frozenset([
    "міндетті", "сөзсіз", "анық", "ақиқат", "шынында",
    "толықтай", "айқын", "дәл",
])

# KZ-специфичные символы
_KK_SPECIFIC_CHARS: frozenset[str] = frozenset("әғқңөұүіһ")

# Гласные для проверки сингармонизма
_KK_BACK_VOWELS: frozenset[str] = frozenset("аоұы")
_KK_FRONT_VOWELS: frozenset[str] = frozenset("әөүіе")


# ─────────────────────────────────────────────────────────────────────────────
# Порог для коротких текстов (v0.3.1): MTLD, Yule_K и пр. нестабильны
# ─────────────────────────────────────────────────────────────────────────────
_SHORT_TEXT_THRESHOLD = 150  # слов


class StyleAnalyzer:
    """Вычисляет стилометрические метрики из текста (ru/kk).

    Использует ``qazstack.kznlp`` для базовой обработки текста.
    ``pymorphy3`` загружается лениво при первом обращении для RU-ветки.

    Пример::

        analyzer = StyleAnalyzer()
        profile = analyzer.analyze("Текст аналитического материала...", lang="ru")
        print(profile.f_score_formality)   # → ~72.0 для аналитики
        print(profile.mtld)                # → ~85–120 для сложного текста

    Graceful degradation:
        - Если ``pymorphy3`` не установлен: морфологические метрики = 0.0,
          f_score_formality = 50.0 (нейтрально), perf_verb_ratio = 0.5.
        - Если текст < 150 слов: MTLD, Yule's K возвращаются как 0.0
          (StyleValidator не штрафует за нулевые значения при коротком тексте).
        - Казахская ветка: POS-метрики = 0.0 (требуют stanza-kk, Phase 2).
    """

    def __init__(self, use_pymorphy: bool = True) -> None:
        """
        Args:
            use_pymorphy: Если True – пытается загрузить pymorphy3.
                          Установите False для тестов без зависимости.
        """
        self._morph = None
        self._use_pymorphy = use_pymorphy
        if use_pymorphy:
            self._morph = self._load_pymorphy()

    @staticmethod
    def _load_pymorphy() -> object | None:
        """Lazy-load pymorphy3 MorphAnalyzer (singleton через экземпляр класса)."""
        try:
            import pymorphy3  # type: ignore[import]
            return pymorphy3.MorphAnalyzer()
        except ImportError:
            return None

    # ─────────────────────────────────────────────────────────────────────────
    # Публичный API
    # ─────────────────────────────────────────────────────────────────────────

    def analyze(self, text: str, lang: Optional[str] = None) -> StyleProfile:
        """Основной метод: текст → StyleProfile.

        Args:
            text: Исходный текст (может содержать переносы строк как разделители абзацев).
            lang: Язык (``"ru"`` / ``"kk"`` / ``"en"``).  Если None – определяется автоматически.

        Returns:
            Заполненный ``StyleProfile``.

        Raises:
            ValueError: Если текст пустой или содержит менее одного предложения.
        """
        if not text or not text.strip():
            raise ValueError("Текст не может быть пустым")

        detected_lang = lang or detect_lang(text)

        sentences: list[str] = sent_tokenize(text)
        raw_tokens: list[str] = tokenize(text)
        # Оставляем только словесные токены (буквы и цифры)
        tokens: list[str] = [t for t in raw_tokens if re.match(r"\w", t)]
        lemmas: list[str] = lemmatize_tokens(tokens, lang=detected_lang)
        paragraphs: list[str] = [p.strip() for p in text.split("\n") if p.strip()]

        n: int = len(tokens)
        n_sents: int = len(sentences)
        n_par: int = max(len(paragraphs), 1)

        if n == 0 or n_sents == 0:
            raise ValueError("Текст слишком короткий для анализа (нет токенов или предложений)")

        # Казахская ветка
        if detected_lang == "kk":
            return self._analyze_kazakh(
                text=text,
                tokens=tokens,
                lemmas=lemmas,
                sentences=sentences,
                paragraphs=paragraphs,
                n=n,
                n_sents=n_sents,
                n_par=n_par,
            )

        # ── Русская / нейтральная ветка ──────────────────────────────────────
        return self._analyze_ru(
            text=text,
            tokens=tokens,
            lemmas=lemmas,
            sentences=sentences,
            paragraphs=paragraphs,
            n=n,
            n_sents=n_sents,
            n_par=n_par,
            lang=detected_lang,
        )

    # ─────────────────────────────────────────────────────────────────────────
    # Русская ветка
    # ─────────────────────────────────────────────────────────────────────────

    def _analyze_ru(
        self,
        text: str,
        tokens: list[str],
        lemmas: list[str],
        sentences: list[str],
        paragraphs: list[str],
        n: int,
        n_sents: int,
        n_par: int,
        lang: str,
    ) -> StyleProfile:
        """Полный анализ для русского (и нейтрального) текста."""
        is_short = n < _SHORT_TEXT_THRESHOLD

        # ── Лексические ──────────────────────────────────────────────────────
        ttr_lemma = self._ttr_lemma(lemmas)
        mtld = self._mtld(lemmas) if not is_short else 0.0
        hapax_rate = self._hapax_rate(lemmas, len(lemmas))
        yule_k = self._yule_k(lemmas) if not is_short else 0.0
        avg_word_len = sum(len(t) for t in tokens) / n
        short_word_ratio = sum(1 for t in tokens if len(t) <= 4) / n
        func_word_ratio = self._func_word_ratio(tokens, lang)
        content_word_ratio = 1.0 - func_word_ratio

        # ── Синтаксические ───────────────────────────────────────────────────
        sent_lens = [len(tokenize(s)) for s in sentences]
        # Фильтр: игнорируем пустые «предложения»
        sent_lens = [sl for sl in sent_lens if sl > 0] or [0]
        avg_sent_len = statistics.mean(sent_lens)
        sd_sent_len = statistics.stdev(sent_lens) if len(sent_lens) > 1 else 0.0
        sent_rhythm_index = sd_sent_len / avg_sent_len if avg_sent_len > 0 else 0.0
        question_ratio = sum(1 for s in sentences if s.strip().endswith("?")) / n_sents
        exclamation_ratio = sum(1 for s in sentences if s.strip().endswith("!")) / n_sents
        passive_ratio = self._passive_ratio_ru(text, sentences)

        # ── Морфологические ──────────────────────────────────────────────────
        morph_stats: dict[str, int] = {}
        if self._morph and lang == "ru":
            morph_stats = self._morph_stats_ru(tokens)

        noun_ratio = morph_stats.get("NOUN", 0) / n
        verb_ratio = morph_stats.get("VERB", 0) / n
        adj_density = morph_stats.get("ADJF", 0) / n + morph_stats.get("ADJS", 0) / n
        adv_density = morph_stats.get("ADVB", 0) / n
        pron_ratio = morph_stats.get("NPRO", 0) / n
        particip_density = (
            morph_stats.get("PRTF", 0) / n + morph_stats.get("PRTS", 0) / n
        )
        gerund_density = morph_stats.get("GRND", 0) / n
        perf_verb_ratio = (
            self._perf_verb_ratio(tokens) if self._morph and lang == "ru" else 0.5
        )
        # Родительный падеж: доля от существительных
        noun_count = max(morph_stats.get("NOUN", 0), 1)
        case_genitiv_ratio = morph_stats.get("gent", 0) / noun_count
        f_score = self._f_score_formality(morph_stats, n)

        # ── Дискурсивные ─────────────────────────────────────────────────────
        par_lens = [len(tokenize(p)) for p in paragraphs]
        par_lens = [pl for pl in par_lens if pl > 0] or [0]
        avg_par_len = statistics.mean(par_lens)
        text_lower = text.lower()
        connector_add = self._connector_density(text_lower, RU_CONNECTORS["additive"], n)
        connector_adv = self._connector_density(text_lower, RU_CONNECTORS["adversative"], n)
        connector_caus = self._connector_density(text_lower, RU_CONNECTORS["causal"], n)
        topic_coherence = self._topic_coherence(paragraphs)

        # ── Ритмические ──────────────────────────────────────────────────────
        comma_per_1k = text.count(",") / n * 1000
        dash_per_1k = (text.count("–") + text.count("–")) / n * 1000

        # ── Прагматические ───────────────────────────────────────────────────
        hedging_density = self._lexicon_density(tokens, RU_HEDGES)
        boosting_density = self._lexicon_density(tokens, RU_BOOSTERS)
        epistemic_ratio, deontic_ratio = self._modal_ratios(tokens, lang)

        # ── Тональные ────────────────────────────────────────────────────────
        sentiment = self._simple_sentiment(sentences, lang)
        mean_sent = sentiment["mean"]
        sent_var = sentiment["variance"]

        return StyleProfile(
            # Лексические
            ttr_lemma=round(ttr_lemma, 4),
            mtld=round(mtld, 2),
            hapax_rate=round(hapax_rate, 4),
            yule_k=round(yule_k, 2),
            avg_word_length_chars=round(avg_word_len, 2),
            short_word_ratio=round(short_word_ratio, 4),
            func_word_ratio=round(func_word_ratio, 4),
            content_word_ratio=round(content_word_ratio, 4),
            # Синтаксические
            avg_sent_len_words=round(avg_sent_len, 2),
            sd_sent_len=round(sd_sent_len, 2),
            passive_ratio=round(passive_ratio, 4),
            question_ratio=round(question_ratio, 4),
            exclamation_ratio=round(exclamation_ratio, 4),
            # Морфологические
            noun_ratio=round(noun_ratio, 4),
            verb_ratio=round(verb_ratio, 4),
            adj_density=round(adj_density, 4),
            adv_density=round(adv_density, 4),
            pron_ratio=round(pron_ratio, 4),
            f_score_formality=round(f_score, 2),
            particip_density=round(particip_density, 4),
            gerund_density=round(gerund_density, 4),
            perf_verb_ratio=round(perf_verb_ratio, 4),
            case_genitiv_ratio=round(case_genitiv_ratio, 4),
            # Дискурсивные
            avg_paragraph_len_words=round(avg_par_len, 2),
            connector_additive_density=round(connector_add, 5),
            connector_adversative_density=round(connector_adv, 5),
            connector_causal_density=round(connector_caus, 5),
            topic_coherence_avg=round(topic_coherence, 4),
            # Ритмические
            comma_per_1k=round(comma_per_1k, 2),
            dash_per_1k=round(dash_per_1k, 2),
            sent_rhythm_index=round(sent_rhythm_index, 4),
            # Прагматические
            hedging_density=round(hedging_density, 5),
            epistemic_ratio=round(epistemic_ratio, 4),
            deontic_ratio=round(deontic_ratio, 4),
            boosting_density=round(boosting_density, 5),
            # Тональные
            mean_sentiment=round(mean_sent, 4),
            sentiment_variance=round(sent_var, 4),
            # Метаданные
            word_count=n,
            sentence_count=n_sents,
            paragraph_count=n_par,
            lang=lang,
        )

    # ─────────────────────────────────────────────────────────────────────────
    # Казахская ветка
    # ─────────────────────────────────────────────────────────────────────────

    def _analyze_kazakh(
        self,
        text: str,
        tokens: list[str],
        lemmas: list[str],
        sentences: list[str],
        paragraphs: list[str],
        n: int,
        n_sents: int,
        n_par: int,
    ) -> StyleProfile:
        """KZ-специфичный анализ.

        POS-тэги (noun_ratio, verb_ratio, …) требуют stanza-kk (Phase 2) –
        возвращают 0.0 с нейтральным f_score=50.0.
        Все KZ-специфичные метрики (агглютинация, сингармонизм, …) вычисляются
        лексическими эвристиками без ML.
        """
        is_short = n < _SHORT_TEXT_THRESHOLD
        n_lemmas = len(lemmas)

        # ── Лексические ──────────────────────────────────────────────────────
        ttr_lemma = self._ttr_lemma(lemmas)
        mtld = self._mtld(lemmas) if not is_short else 0.0
        hapax_rate = self._hapax_rate(lemmas, n_lemmas)
        yule_k = self._yule_k(lemmas) if not is_short else 0.0
        avg_word_len = sum(len(t) for t in tokens) / n
        short_word_ratio = sum(1 for t in tokens if len(t) <= 4) / n
        func_word_ratio = self._func_word_ratio(tokens, "kk")
        content_word_ratio = 1.0 - func_word_ratio

        # ── Синтаксические ───────────────────────────────────────────────────
        sent_lens = [len(tokenize(s)) for s in sentences]
        sent_lens = [sl for sl in sent_lens if sl > 0] or [0]
        avg_sent_len = statistics.mean(sent_lens)
        sd_sent_len = statistics.stdev(sent_lens) if len(sent_lens) > 1 else 0.0
        sent_rhythm_index = sd_sent_len / avg_sent_len if avg_sent_len > 0 else 0.0
        question_ratio = sum(1 for s in sentences if s.strip().endswith("?")) / n_sents
        exclamation_ratio = sum(1 for s in sentences if s.strip().endswith("!")) / n_sents

        # ── Дискурсивные ─────────────────────────────────────────────────────
        par_lens = [len(tokenize(p)) for p in paragraphs]
        par_lens = [pl for pl in par_lens if pl > 0] or [0]
        avg_par_len = statistics.mean(par_lens)
        text_lower = text.lower()
        connector_add = self._connector_density(text_lower, KK_CONNECTORS["additive"], n)
        connector_adv = self._connector_density(text_lower, KK_CONNECTORS["adversative"], n)
        connector_caus = self._connector_density(text_lower, KK_CONNECTORS["causal"], n)
        topic_coherence = self._topic_coherence(paragraphs)

        # ── Ритмические ──────────────────────────────────────────────────────
        comma_per_1k = text.count(",") / n * 1000
        dash_per_1k = (text.count("–") + text.count("–")) / n * 1000

        # ── Прагматические ───────────────────────────────────────────────────
        hedging_density = self._lexicon_density(tokens, KK_HEDGES)
        boosting_density = self._lexicon_density(tokens, KK_BOOSTERS)
        evidential_density = self._phrase_density(text_lower, KK_EVIDENTIAL, n)
        modal_particle_density = self._lexicon_density(tokens, KK_MODAL_PARTICLES)

        # ── KZ-специфичные ───────────────────────────────────────────────────
        postposition_ratio = self._lexicon_density(tokens, KK_POSTPOSITIONS)
        agglut_index = self._agglutination_index(tokens, lemmas)
        # stem_ttr использует те же леммы (kznlp строит их через суффикс-стриппинг)
        stem_ttr = self._ttr_lemma(lemmas)
        borrowing_kk = self._kk_borrowing_ratio(tokens)
        vowel_harmony_viol = self._vowel_harmony_violations(tokens)

        # ── Сентимент ────────────────────────────────────────────────────────
        sentiment = self._simple_sentiment(sentences, "kk")

        return StyleProfile(
            # Лексические
            ttr_lemma=round(ttr_lemma, 4),
            mtld=round(mtld, 2),
            hapax_rate=round(hapax_rate, 4),
            yule_k=round(yule_k, 2),
            avg_word_length_chars=round(avg_word_len, 2),
            short_word_ratio=round(short_word_ratio, 4),
            func_word_ratio=round(func_word_ratio, 4),
            content_word_ratio=round(content_word_ratio, 4),
            # Синтаксические
            avg_sent_len_words=round(avg_sent_len, 2),
            sd_sent_len=round(sd_sent_len, 2),
            passive_ratio=0.0,  # пассивный залог в KZ определяется через stanza (Phase 2)
            question_ratio=round(question_ratio, 4),
            exclamation_ratio=round(exclamation_ratio, 4),
            # Морфологические: требуют stanza-kk POS – Phase 2
            noun_ratio=0.0,
            verb_ratio=0.0,
            adj_density=0.0,
            adv_density=0.0,
            pron_ratio=0.0,
            f_score_formality=50.0,  # не применимо для KZ без POS, нейтральное значение
            particip_density=0.0,
            gerund_density=0.0,
            perf_verb_ratio=0.5,
            case_genitiv_ratio=0.0,
            # Дискурсивные
            avg_paragraph_len_words=round(avg_par_len, 2),
            connector_additive_density=round(connector_add, 5),
            connector_adversative_density=round(connector_adv, 5),
            connector_causal_density=round(connector_caus, 5),
            topic_coherence_avg=round(topic_coherence, 4),
            # Ритмические
            comma_per_1k=round(comma_per_1k, 2),
            dash_per_1k=round(dash_per_1k, 2),
            sent_rhythm_index=round(sent_rhythm_index, 4),
            # Прагматические
            hedging_density=round(hedging_density, 5),
            epistemic_ratio=0.0,
            deontic_ratio=0.0,
            boosting_density=round(boosting_density, 5),
            # Тональные
            mean_sentiment=round(sentiment["mean"], 4),
            sentiment_variance=round(sentiment["variance"], 4),
            # Метаданные
            word_count=n,
            sentence_count=n_sents,
            paragraph_count=n_par,
            lang="kk",
            # KZ-specific
            agglutination_index=round(agglut_index, 3),
            stem_ttr=round(stem_ttr, 4),
            borrowing_ratio_kk=round(borrowing_kk, 4),
            postposition_ratio=round(postposition_ratio, 4),
            evidential_density=round(evidential_density, 5),
            modal_particle_density=round(modal_particle_density, 5),
            vowel_harmony_violation_rate=round(vowel_harmony_viol, 4),
        )

    # ─────────────────────────────────────────────────────────────────────────
    # Лексические метрики
    # ─────────────────────────────────────────────────────────────────────────

    @staticmethod
    def _ttr_lemma(lemmas: list[str]) -> float:
        """Type-Token Ratio по леммам.  Диапазон: 0.0–1.0."""
        if not lemmas:
            return 0.0
        return len(set(lemmas)) / len(lemmas)

    @staticmethod
    def _mtld(lemmas: list[str], threshold: float = 0.72) -> float:
        """Measure of Textual Lexical Diversity (McCarthy & Jarvis, 2010).

        Двунаправленное сканирование (forward + backward) / 2.
        Возвращает 0.0 для текстов < 10 токенов.
        """
        if len(lemmas) < 10:
            return 0.0

        def _scan(seq: list[str]) -> float:
            """Сканирование в одном направлении, возвращает число факторов."""
            factors = 0.0
            start = 0
            for i in range(1, len(seq) + 1):
                chunk = seq[start:i]
                ttr = len(set(chunk)) / len(chunk)
                if ttr <= threshold:
                    factors += 1.0
                    start = i
            remaining = seq[start:]
            if remaining:
                ttr_rem = len(set(remaining)) / len(remaining)
                # Частичный фактор: как далеко мы зашли до порога
                factors += (1.0 - ttr_rem) / (1.0 - threshold)
            return factors if factors > 0 else 1.0

        forward = len(lemmas) / _scan(lemmas)
        backward = len(lemmas) / _scan(list(reversed(lemmas)))
        return (forward + backward) / 2.0

    @staticmethod
    def _hapax_rate(lemmas: list[str], n: int) -> float:
        """Доля hapax legomena (слов, встречающихся ровно один раз)."""
        if n == 0:
            return 0.0
        counts = Counter(lemmas)
        hapax = sum(1 for v in counts.values() if v == 1)
        return hapax / n

    @staticmethod
    def _yule_k(lemmas: list[str]) -> float:
        """Yule's K (1944) – константа лексического богатства.

        K = 10^4 * (Σ fx*x² − N) / N²
        где fx – частота частоты x, N – число токенов.
        Большее K → меньшее лексическое богатство.
        """
        if not lemmas:
            return 0.0
        n = len(lemmas)
        counts = Counter(lemmas)
        freq_of_freq = Counter(counts.values())
        sigma = sum(fx * (x ** 2) for x, fx in freq_of_freq.items())
        return 1e4 * (sigma - n) / (n ** 2)

    def _func_word_ratio(self, tokens: list[str], lang: str) -> float:
        """Доля служебных слов относительно всех токенов."""
        if lang == "kk":
            func_set: frozenset[str] = STOPWORDS_KK | KK_FUNC_WORDS
        else:
            func_set = RU_FUNC_WORDS | STOPWORDS_RU
        func_count = sum(1 for t in tokens if t.lower() in func_set)
        return func_count / len(tokens) if tokens else 0.0

    # ─────────────────────────────────────────────────────────────────────────
    # Синтаксические метрики
    # ─────────────────────────────────────────────────────────────────────────

    @staticmethod
    def _gini(values: list[float]) -> float:
        """Коэффициент Джини для распределения длин предложений."""
        if not values or sum(values) == 0:
            return 0.0
        n = len(values)
        sorted_vals = sorted(values)
        cumsum = sum((i + 1) * v for i, v in enumerate(sorted_vals))
        total = sum(sorted_vals) * n
        return max(0.0, (2.0 * cumsum / total - (n + 1) / n)) if total > 0 else 0.0

    def _passive_ratio_ru(self, text: str, sentences: list[str]) -> float:
        """Доля предложений с пассивным залогом (русский).

        Основной метод: PRTS (краткое причастие) через pymorphy3.
        Fallback: regex на «был/была + причастие».
        """
        if not sentences:
            return 0.0
        if self._morph:
            passive_count = 0
            for sent in sentences:
                tokens_s = [t for t in tokenize(sent) if re.match(r"\w", t)]
                for t in tokens_s:
                    parsed = self._morph.parse(t)
                    if parsed and parsed[0].tag.POS == "PRTS":
                        passive_count += 1
                        break  # одно PRTS на предложение достаточно
            return passive_count / len(sentences)
        else:
            # Fallback: regex на типичные пассивные конструкции
            passive_patterns = re.findall(
                r"\bбыл[аои]?\s+\w+(?:ан|ен|ован|ён|ят|ит|ут|ет)[ыао]?\b",
                text,
                flags=re.IGNORECASE,
            )
            return len(passive_patterns) / max(len(sentences), 1)

    # ─────────────────────────────────────────────────────────────────────────
    # Морфологические метрики
    # ─────────────────────────────────────────────────────────────────────────

    def _morph_stats_ru(self, tokens: list[str]) -> dict[str, int]:
        """POS-статистика через pymorphy3.

        Возвращает словарь ``{POS_tag: count}``.
        Дополнительно добавляет ключ ``"gent"`` для токенов в родительном падеже.
        """
        stats: dict[str, int] = {}
        for t in tokens:
            parsed = self._morph.parse(t)  # type: ignore[union-attr]
            if not parsed:
                continue
            p = parsed[0]
            pos = p.tag.POS or "UNKN"
            stats[pos] = stats.get(pos, 0) + 1
            if p.tag.case == "gent":
                stats["gent"] = stats.get("gent", 0) + 1
        return stats

    def _perf_verb_ratio(self, tokens: list[str]) -> float:
        """Доля глаголов совершенного вида среди всех глаголов.

        Возвращает 0.5 (нейтральное значение) если pymorphy3 недоступен
        или глаголов нет.
        """
        if not self._morph:
            return 0.5
        aspects: list[str] = []
        for t in tokens:
            parsed = self._morph.parse(t)  # type: ignore[union-attr]
            if parsed and parsed[0].tag.POS in {"VERB", "INFN"}:
                asp = parsed[0].tag.aspect
                if asp:
                    aspects.append(asp)
        if not aspects:
            return 0.5
        perf = aspects.count("perf")
        return perf / len(aspects)

    @staticmethod
    def _f_score_formality(morph_stats: dict[str, int], n: int) -> float:
        """F-score формальности (Heylighen & Dewaele, 2002).

        F = 50 * ((formal - contextual) / N + 1)
        Формальные POS: NOUN, ADJF, ADJS, PREP.
        Контекстуальные POS: NPRO, VERB, ADVB, INTJ, PRCL.
        Диапазон: 0–100; ~50 = нейтральный, >65 = академический.
        """
        if n == 0:
            return 50.0
        formal = sum(morph_stats.get(p, 0) for p in ("NOUN", "ADJF", "ADJS", "PREP"))
        contextual = sum(
            morph_stats.get(p, 0) for p in ("NPRO", "VERB", "ADVB", "INTJ", "PRCL")
        )
        return 50.0 * ((formal - contextual) / n + 1.0)

    # ─────────────────────────────────────────────────────────────────────────
    # Дискурсивные метрики
    # ─────────────────────────────────────────────────────────────────────────

    @staticmethod
    def _connector_density(text_lower: str, connectors: frozenset[str], n: int) -> float:
        """Плотность коннекторов (вхождений на токен)."""
        count = sum(text_lower.count(c) for c in connectors)
        return count / n if n > 0 else 0.0

    @staticmethod
    def _phrase_density(text_lower: str, phrases: frozenset[str], n: int) -> float:
        """Плотность многословных фраз (вхождений на токен)."""
        count = sum(text_lower.count(p) for p in phrases)
        return count / n if n > 0 else 0.0

    def _topic_coherence(self, paragraphs: list[str]) -> float:
        """Средняя тематическая когезия: Jaccard-сходство соседних абзацев.

        Значение 0.0–1.0.  Для одного абзаца возвращает 1.0.
        """
        if len(paragraphs) < 2:
            return 1.0
        scores: list[float] = []
        for i in range(len(paragraphs) - 1):
            set_a = set(tokenize(paragraphs[i].lower()))
            set_b = set(tokenize(paragraphs[i + 1].lower()))
            union = set_a | set_b
            inter = set_a & set_b
            scores.append(len(inter) / len(union) if union else 0.0)
        return statistics.mean(scores) if scores else 1.0

    # ─────────────────────────────────────────────────────────────────────────
    # Прагматические метрики
    # ─────────────────────────────────────────────────────────────────────────

    @staticmethod
    def _lexicon_density(tokens: list[str], lexicon: frozenset[str]) -> float:
        """Доля токенов, входящих в лексикон (0.0–1.0)."""
        count = sum(1 for t in tokens if t.lower() in lexicon)
        return count / len(tokens) if tokens else 0.0

    def _modal_ratios(
        self, tokens: list[str], lang: str
    ) -> tuple[float, float]:
        """Доли эпистемической и деонтической модальности.

        Для RU: точный метод через keyword-словари.
        Для KK и при отсутствии pymorphy3: возвращает 0.0, 0.0.
        """
        if lang != "ru":
            return 0.0, 0.0

        epistemic_kw = {"может", "мог", "возможно", "вероятно", "видимо", "наверное"}
        deontic_kw = {"должен", "следует", "нужно", "необходимо", "обязан", "надо"}
        modal_tokens = [
            t.lower() for t in tokens if t.lower() in epistemic_kw | deontic_kw
        ]
        if not modal_tokens:
            return 0.0, 0.0
        total = len(modal_tokens)
        ep = sum(1 for t in modal_tokens if t in epistemic_kw) / total
        de = sum(1 for t in modal_tokens if t in deontic_kw) / total
        return ep, de

    # ─────────────────────────────────────────────────────────────────────────
    # Тональные метрики
    # ─────────────────────────────────────────────────────────────────────────

    def _simple_sentiment(
        self, sentences: list[str], lang: str
    ) -> dict[str, float]:
        """Лексический сентимент (fallback без ML-модели).

        Возвращает dict с ключами: mean, variance, neutral_ratio, positive_ratio.
        Значения нормированы: mean ∈ [-1.0, 1.0], variance ∈ [0.0, 1.0].
        """
        if lang == "kk":
            positive_words = {"жақсы", "оң", "өсу", "жетістік", "дамыту"}
            negative_words = {"проблема", "қауіп", "төмендеу", "дағдарыс", "тапшылық"}
        else:
            positive_words = _RU_POSITIVE
            negative_words = _RU_NEGATIVE

        scores: list[float] = []
        for s in sentences:
            s_lower = s.lower()
            pos = sum(1 for w in positive_words if w in s_lower)
            neg = sum(1 for w in negative_words if w in s_lower)
            scores.append(float(pos - neg))

        if not scores:
            return {"mean": 0.0, "variance": 0.0, "neutral_ratio": 1.0, "positive_ratio": 0.0}

        mean_val = statistics.mean(scores)
        var_val = statistics.variance(scores) if len(scores) > 1 else 0.0
        neutral_ratio = sum(1 for s in scores if s == 0) / len(scores)
        positive_ratio = sum(1 for s in scores if s > 0) / len(scores)

        # Нормализация: делим на max_abs, затем клипаем в [-1, 1]
        max_abs = max(abs(mean_val) / 5.0, 1.0)
        normalized_mean = max(-1.0, min(1.0, mean_val / max_abs))
        normalized_var = min(1.0, var_val / 10.0)

        return {
            "mean": normalized_mean,
            "variance": normalized_var,
            "neutral_ratio": neutral_ratio,
            "positive_ratio": positive_ratio,
        }

    @staticmethod
    def _irony_markers(text: str) -> int:
        """Оценка потенциальных маркеров иронии.

        Эвристика: кавычки «…» (короткие, вероятно не цитаты)
        + восклицание после явно позитивного слова в негативном контексте.
        """
        # Кавычки-«ёлочки» длиной ≤30 символов
        quotes = len(re.findall(r"«[^»]{1,30}»", text))
        # Ложное восклицание: «Отличный/замечательный/прекрасный … !»
        fake_exclaim = len(
            re.findall(r"(?:отличн|замечательн|прекрасн)\w+\s*!", text, re.IGNORECASE)
        )
        return quotes + fake_exclaim

    # ─────────────────────────────────────────────────────────────────────────
    # KZ-специфичные метрики
    # ─────────────────────────────────────────────────────────────────────────

    @staticmethod
    def _agglutination_index(tokens: list[str], lemmas: list[str]) -> float:
        """Индекс агглютинации: среднее отношение длины токена к длине леммы.

        Значение > 1.0 указывает на суффиксы (агглютинативность).
        Для KZ ожидается 1.3–2.0.
        """
        if not tokens or not lemmas:
            return 1.0
        pairs = [
            (t, l)
            for t, l in zip(tokens, lemmas)
            if len(l) > 0 and re.match(r"\w", t)
        ]
        if not pairs:
            return 1.0
        ratios = [len(t) / max(len(l), 1) for t, l in pairs]
        return statistics.mean(ratios)

    @staticmethod
    def _kk_borrowing_ratio(tokens: list[str]) -> float:
        """Доля заимствований: слова длиннее 3 символов без KZ-специфичных букв.

        Эвристика: нативные казахские слова содержат хотя бы один символ из
        {ә, ғ, қ, ң, ө, ұ, ү, і, һ}.  Слова без них – вероятные заимствования
        (русские, английские, арабские).
        """
        total = len(tokens)
        if total == 0:
            return 0.0
        non_kk = sum(
            1
            for t in tokens
            if len(t) > 3 and not any(c in _KK_SPECIFIC_CHARS for c in t.lower())
        )
        return non_kk / total

    @staticmethod
    def _is_native_kazakh(word: str) -> bool:
        """Проверяет наличие KZ-специфичных символов в слове."""
        return any(c in _KK_SPECIFIC_CHARS for c in word.lower())

    @staticmethod
    def _vowel_harmony_violations(tokens: list[str]) -> float:
        """Доля токенов с нарушением закона сингармонизма.

        Нарушение: слово содержит одновременно переднеязычные (ä, ö, ü, i, e)
        и заднеязычные (a, o, u, y) гласные.
        Возвращает 0.0 для текстов без гласных.
        """
        violations = 0
        checked = 0
        for t in tokens:
            t_lower = t.lower()
            has_back = any(c in _KK_BACK_VOWELS for c in t_lower)
            has_front = any(c in _KK_FRONT_VOWELS for c in t_lower)
            if has_back or has_front:
                checked += 1
                if has_back and has_front:
                    violations += 1
        return violations / max(checked, 1)

    @staticmethod
    def _check_vowel_harmony_violation(word: str) -> bool:
        """Проверяет нарушение сингармонизма в одном слове."""
        front = frozenset("әеиіөүэю")
        back = frozenset("аоұуыя")
        word_lower = word.lower()
        return any(c in front for c in word_lower) and any(c in back for c in word_lower)
