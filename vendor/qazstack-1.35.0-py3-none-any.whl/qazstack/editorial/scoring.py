"""
qazstack.editorial.scoring
============================
Multi-dimensional ScoringLoop: стилометрия + LLM-as-evaluator.

Архитектура (по Ostheimer et al., 2023 – «LLM as evaluator»):
-----------------------------------------------------------------
1. **StyleAnalyzer.analyze()** – вычисляет ``StyleProfile`` (64 метрики).
2. **StyleValidator.validate()** – сравнивает ``StyleProfile`` с ``AuthorProfile.style_targets``,
   возвращает ``ScoringResult`` со score 0–1 по 7 стилометрическим категориям.
3. **LLM-evaluator** – запрашивает дешёвую модель (scoring_model) оценить черновик
   по 6 смысловым/качественным измерениям (JSON-ответ).
4. **Комбинирование** – взвешенное среднее:
   - стилометрия (вес 0.4 по умолчанию)
   - LLM-оценки (вес 0.6 по умолчанию)
5. **Hard Gates** – бинарные проверки:
   - ``factual_accuracy < 0.60`` → немедленно в HITL.
   - ``hallucination_rate > 0.15`` → немедленно в HITL.
   - ``topic_relevance < 0.60`` → немедленно в HITL.
6. **Порог публикации** – ``overall_score >= author.thresholds.overall_publish_threshold``.

Используется в Orchestrator как финальная стадия оценки черновика.
"""
from __future__ import annotations

import hashlib
import json
import logging
from typing import TYPE_CHECKING, Any

from .models import AuthorProfile, GenerationTask, ScoringResult, StyleProfile

if TYPE_CHECKING:
    from .llm_client import LLMClient
    from .style_validator import StyleValidator

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Константы
# ---------------------------------------------------------------------------

# Вес стилометрии vs LLM-оценки в итоговом combined_score
_STYLOMETRIC_WEIGHT = 0.4
_LLM_WEIGHT = 0.6

# Hard Gate пороги (не настраиваются через профиль автора – системные ограничения)
_HARD_GATE_FACTUAL_MIN = 0.60
_HARD_GATE_HALLUCINATION_MAX = 0.15
_HARD_GATE_TOPIC_MIN = 0.60

# Fallback LLM-оценки при сбое LLM (нейтральные значения, не блокируют публикацию)
_LLM_FALLBACK_SCORES: dict[str, float] = {
    "persona_consistency": 0.70,
    "factual_accuracy": 0.70,
    "hallucination_rate": 0.05,
    "coherence": 0.70,
    "topic_relevance": 0.70,
    "fluency": 0.70,
}

# Системный промпт для LLM-evaluator
_EVALUATOR_SYSTEM = (
    "Ты – строгий литературный редактор и факт-чекер. "
    "Оцениваешь материал объективно по заданным критериям. "
    "Отвечаешь ТОЛЬКО валидным JSON без каких-либо пояснений вне JSON-объекта."
)


# ---------------------------------------------------------------------------
# ScoringLoop
# ---------------------------------------------------------------------------


class ScoringLoop:
    """
    Комплексная оценка черновика: стилометрия + LLM-as-evaluator.

    Измерения:
    - ``style_accuracy``       – соответствие стилометрическому профилю (StyleValidator, вес 0.4).
    - ``persona_consistency``  – соответствие голосу автора (LLM).
    - ``factual_accuracy``     – фактологическая корректность (LLM).
    - ``coherence``            – связность и логика (LLM).
    - ``topic_relevance``      – соответствие теме задания (LLM).
    - ``fluency``              – читабельность и грамматика (LLM).

    Hard Gates (бинарные, не входят в scoring):
    - ``factual_accuracy < 0.60`` → ``passes_threshold = False``, HITL.
    - ``hallucination_rate > 0.15`` → ``passes_threshold = False``, HITL.
    - ``topic_relevance < 0.60`` → ``passes_threshold = False``, HITL.

    Пример::

        loop = ScoringLoop(validator=StyleValidator(), scoring_client=OpenAIClient(model="gpt-4o-mini"))
        result = await loop.score(
            draft="Текст черновика...",
            author=author_profile,
            task=generation_task,
            iteration=1,
            draft_id="draft_abc123",
        )
        if result.passes_threshold:
            print("Готово к публикации")
        else:
            print(result.feedback)
    """

    def __init__(
        self,
        validator: StyleValidator,
        scoring_client: LLMClient,
        stylometric_weight: float = _STYLOMETRIC_WEIGHT,
        llm_weight: float = _LLM_WEIGHT,
    ) -> None:
        """
        Args:
            validator: экземпляр ``StyleValidator`` для стилометрической оценки.
            scoring_client: LLM-клиент для оценки (рекомендуется дешёвая модель).
            stylometric_weight: вес стилометрического score в комбинированном (0–1).
            llm_weight: вес LLM-оценок в комбинированном (0–1).
        """
        if abs(stylometric_weight + llm_weight - 1.0) > 1e-6:
            raise ValueError(
                f"ScoringLoop: stylometric_weight + llm_weight должны давать 1.0, "
                f"получено {stylometric_weight} + {llm_weight} = {stylometric_weight + llm_weight}"
            )
        self._validator = validator
        self._scoring_client = scoring_client
        self._stylometric_weight = stylometric_weight
        self._llm_weight = llm_weight

    # ------------------------------------------------------------------
    # Основной публичный метод
    # ------------------------------------------------------------------

    async def score(
        self,
        draft: str,
        author: AuthorProfile,
        task: GenerationTask,
        iteration: int,
        draft_id: str = "",
        style_metrics: StyleProfile | None = None,
    ) -> ScoringResult:
        """
        Комплексная оценка черновика.

        Если ``style_metrics`` не передан – вычисляется внутри через ``StyleAnalyzer``.
        Передача готового ``StyleProfile`` позволяет переиспользовать уже вычисленные
        метрики из Orchestrator и не считать дважды.

        Args:
            draft: текст черновика.
            author: профиль автора.
            task: задание на генерацию.
            iteration: номер текущей итерации (1-based).
            draft_id: идентификатор черновика (для логов/аудита).
            style_metrics: заранее вычисленный ``StyleProfile`` (опционально).

        Returns:
            ``ScoringResult`` с общим score, детальными оценками и feedback.
        """
        if not draft_id:
            draft_id = f"draft_{hashlib.sha256(draft[:200].encode()).hexdigest()[:8]}"

        # --- Шаг 1: StyleProfile ---
        if style_metrics is None:
            style_metrics = await self._compute_style_profile(draft, task.lang)

        # --- Шаг 2: Стилометрическая оценка ---
        stylometric_result = self._validator.validate(
            draft_id=draft_id,
            iteration=iteration,
            actual=style_metrics,
            target=author.style_targets,
            thresholds=author.thresholds,
            style_category_weights=author.style_category_weights,
        )
        style_accuracy = stylometric_result.overall_score

        # --- Шаг 3: LLM-evaluator ---
        llm_scores = await self._cached_llm_evaluate(draft, author, task, iteration)
        llm_failed = llm_scores.pop("_llm_failed", False)

        # --- Шаг 4: Комбинирование score ---
        # Маппинг LLM-измерений на scoring dimensions
        combined_scores: dict[str, float] = {
            "style_accuracy": style_accuracy,
            "persona_consistency": llm_scores.get("persona_consistency", _LLM_FALLBACK_SCORES["persona_consistency"]),
            "factual_accuracy": llm_scores.get("factual_accuracy", _LLM_FALLBACK_SCORES["factual_accuracy"]),
            "coherence": llm_scores.get("coherence", _LLM_FALLBACK_SCORES["coherence"]),
            "topic_relevance": llm_scores.get("topic_relevance", _LLM_FALLBACK_SCORES["topic_relevance"]),
            "fluency": llm_scores.get("fluency", _LLM_FALLBACK_SCORES["fluency"]),
        }

        # Веса из профиля автора (scoring_dimension_weights)
        # Нормализуем: style_accuracy имеет stylometric_weight,
        # остальные 5 LLM-измерений делят между собой llm_weight.
        dimension_weights = author.scoring_dimension_weights or {}
        overall = self._compute_weighted_score(combined_scores, dimension_weights, style_accuracy, llm_scores)

        # --- Шаг 5: Hard Gates ---
        hard_gate_passed, hard_gate_reason = self._check_hard_gates(draft, task, llm_scores)

        # --- Шаг 6: Feedback ---
        feedback_parts: list[str] = []

        if not hard_gate_passed:
            feedback_parts.append(hard_gate_reason)

        if (
            stylometric_result.feedback
            and stylometric_result.feedback.strip() != "Текст соответствует профилю автора."
        ):
            feedback_parts.append(stylometric_result.feedback)

        llm_feedback = llm_scores.get("feedback", "").strip()
        if llm_feedback:
            feedback_parts.append(f"ОЦЕНКА РЕДАКТОРА: {llm_feedback}")

        if llm_failed:
            feedback_parts.append(
                "[ПРЕДУПРЕЖДЕНИЕ: LLM-оценка недоступна, использованы нейтральные значения]"
            )

        passes = not hard_gate_passed is False and (overall >= author.thresholds.overall_publish_threshold)
        if hard_gate_passed is False:
            passes = False

        final_feedback = "\n".join(filter(None, feedback_parts)) or "Текст соответствует профилю."

        result = ScoringResult(
            draft_id=draft_id,
            iteration=iteration,
            scores=combined_scores,
            overall_score=round(overall, 4),
            passes_threshold=passes,
            feedback=final_feedback,
            style_metrics=style_metrics,
        )

        logger.info(
            "ScoringLoop[%s] iter=%d: overall=%.3f passes=%s style=%.3f persona=%.3f factual=%.3f",
            draft_id, iteration, overall, passes,
            style_accuracy,
            combined_scores["persona_consistency"],
            combined_scores["factual_accuracy"],
        )

        return result

    # ------------------------------------------------------------------
    # Вычисление StyleProfile
    # ------------------------------------------------------------------

    async def _compute_style_profile(self, draft: str, lang: str = "ru") -> StyleProfile:
        """
        Вычисляет StyleProfile черновика через StyleAnalyzer.

        StyleAnalyzer – синхронный, запускается в event loop.
        При отсутствии StyleAnalyzer создаёт заглушку с нулевыми метриками.
        """
        try:
            from .style_analyzer import StyleAnalyzer  # type: ignore
            analyzer = StyleAnalyzer()
            return analyzer.analyze(draft, lang=lang)
        except ImportError:
            logger.warning("StyleAnalyzer недоступен – используется заглушка StyleProfile.")
            return _make_empty_style_profile(lang)

    # ------------------------------------------------------------------
    # LLM-evaluator
    # ------------------------------------------------------------------

    async def _llm_evaluate(
        self,
        draft: str,
        author: AuthorProfile,
        task: GenerationTask,
    ) -> dict[str, Any]:
        """
        Вызывает LLM для оценки черновика по 6 критериям.

        Returns:
            Словарь с оценками и feedback. При ошибке – fallback-значения
            с флагом ``_llm_failed = True``.
        """
        voice_excerpt = author.persona.voice_description[:300].strip()
        required_rules = "; ".join(author.style_rules.required[:4]) if author.style_rules.required else "–"
        forbidden_rules = "; ".join(author.style_rules.forbidden[:4]) if author.style_rules.forbidden else "–"

        prompt = (
            f"Оцени следующий материал по 6 критериям (каждый от 0.0 до 1.0).\n\n"
            f"[ПРОФИЛЬ АВТОРА: {author.name}]\n"
            f"Ожидаемый голос: {voice_excerpt}\n"
            f"Обязательные правила: {required_rules}\n"
            f"Запрещено: {forbidden_rules}\n\n"
            f"[ЗАДАНИЕ]\n"
            f"Тип: {task.task_type}\n"
            f"Тема: {task.brief}\n"
            f"Язык: {task.lang}\n\n"
            "[КРИТЕРИИ]\n"
            f"1. persona_consistency (0.0–1.0): насколько голос и стиль соответствуют профилю «{author.name}»?\n"
            "2. factual_accuracy (0.0–1.0): корректность фактов, чисел, дат. 1.0 = все корректны.\n"
            "3. hallucination_rate (0.0–1.0): доля выдуманных/непроверяемых утверждений. 0.0 = нет галлюцинаций.\n"
            "4. coherence (0.0–1.0): логическая связность, структура, переходы.\n"
            f"5. topic_relevance (0.0–1.0): соответствие теме «{task.brief}». 0.6– = серьёзный drift.\n"
            "6. fluency (0.0–1.0): читабельность, грамматика, стилистика.\n"
            "7. feedback: ОДНА конкретная инструкция по улучшению (пустая строка если всё хорошо).\n\n"
            "[МАТЕРИАЛ]\n"
            "---\n"
            f"{draft[:4000]}\n"
            "---\n\n"
            'Ответь ТОЛЬКО в JSON: {"persona_consistency": 0.0, "factual_accuracy": 0.0, '
            '"hallucination_rate": 0.0, "coherence": 0.0, "topic_relevance": 0.0, '
            '"fluency": 0.0, "feedback": ""}'
        )

        try:
            result = await self._scoring_client.generate_json(
                system=_EVALUATOR_SYSTEM,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.1,
                max_tokens=512,
            )
            # Нормализация: убеждаемся что все нужные ключи есть
            return {
                "persona_consistency": float(result.get("persona_consistency", _LLM_FALLBACK_SCORES["persona_consistency"])),
                "factual_accuracy": float(result.get("factual_accuracy", _LLM_FALLBACK_SCORES["factual_accuracy"])),
                "hallucination_rate": float(result.get("hallucination_rate", _LLM_FALLBACK_SCORES["hallucination_rate"])),
                "coherence": float(result.get("coherence", _LLM_FALLBACK_SCORES["coherence"])),
                "topic_relevance": float(result.get("topic_relevance", _LLM_FALLBACK_SCORES["topic_relevance"])),
                "fluency": float(result.get("fluency", _LLM_FALLBACK_SCORES["fluency"])),
                "feedback": str(result.get("feedback", "")),
            }
        except Exception as exc:
            logger.warning(
                "ScoringLoop: LLM-evaluator упал (%s), использую fallback-оценки.", exc
            )
            return {**_LLM_FALLBACK_SCORES, "feedback": "", "_llm_failed": True}

    async def _cached_llm_evaluate(
        self,
        draft: str,
        author: AuthorProfile,
        task: GenerationTask,
        iteration: int,
    ) -> dict[str, Any]:
        """
        LLM-evaluator с кэшированием по (draft_hash, author_id).

        Оптимизация v0.3.1: если diff между итерацией N и N-1 < 10%,
        переиспользуем предыдущий scoring с penalty -0.02 на каждое измерение.

        TODO Phase 2: заменить LLM-scoring на fine-tuned DistilBERT (в 50× дешевле).
        TODO: Redis-кэш по cache_key для персистенции между воркерами.
        """
        cache_key = hashlib.sha256(
            f"{draft[:500]}:{author.author_id}:{task.task_type}".encode()
        ).hexdigest()

        # Redis cache lookup placeholder:
        # cached = await redis.get(f"editorial:score:{cache_key}")
        # if cached and iteration > 1:
        #     scores = json.loads(cached)
        #     return {k: max(0.0, v - 0.02) if isinstance(v, float) else v for k, v in scores.items()}

        logger.debug("LLM-evaluator: cache_key=%s (iteration=%d)", cache_key[:16], iteration)
        return await self._llm_evaluate(draft, author, task)

    # ------------------------------------------------------------------
    # Комбинирование score
    # ------------------------------------------------------------------

    def _compute_weighted_score(
        self,
        combined_scores: dict[str, float],
        dimension_weights: dict[str, float],
        style_accuracy: float,
        llm_scores: dict[str, Any],
    ) -> float:
        """
        Вычисляет итоговый overall_score.

        Если ``dimension_weights`` задан в профиле автора – использует их (нормализуя сумму).
        Иначе применяет стандартную схему:
        - style_accuracy: ``stylometric_weight`` (0.4)
        - Пять LLM-измерений делят поровну оставшиеся ``llm_weight`` (0.6).
        """
        if dimension_weights:
            # Используем веса из профиля автора (нормализуем до суммы 1.0)
            total_w = sum(dimension_weights.values()) or 1.0
            score = sum(
                combined_scores.get(dim, 0.5) * (w / total_w)
                for dim, w in dimension_weights.items()
                if dim in combined_scores
            )
            return min(1.0, max(0.0, score))

        # Стандартная схема: 0.4 стилометрия + 0.6 LLM
        llm_dims = ["persona_consistency", "factual_accuracy", "coherence", "topic_relevance", "fluency"]
        llm_per_dim = self._llm_weight / len(llm_dims)

        score = style_accuracy * self._stylometric_weight
        for dim in llm_dims:
            score += combined_scores.get(dim, 0.5) * llm_per_dim

        return min(1.0, max(0.0, score))

    # ------------------------------------------------------------------
    # Hard Gates
    # ------------------------------------------------------------------

    def _check_hard_gates(
        self,
        draft: str,
        task: GenerationTask,
        llm_scores: dict[str, Any],
    ) -> tuple[bool, str]:
        """
        Бинарные проверки: при провале – черновик немедленно в HITL.

        Hard Gates не участвуют в scoring loop и не влияют на overall_score.
        Они только устанавливают ``passes_threshold = False`` и причину.

        Returns:
            Кортеж ``(passed: bool, reason: str)``.
        """
        factual = llm_scores.get("factual_accuracy", 1.0)
        if factual < _HARD_GATE_FACTUAL_MIN:
            return (
                False,
                f"HARD GATE: factual_accuracy={factual:.2f} < {_HARD_GATE_FACTUAL_MIN} "
                "– серьёзные фактологические ошибки. Требуется ручная проверка (HITL).",
            )

        hallucination = llm_scores.get("hallucination_rate", 0.0)
        if hallucination > _HARD_GATE_HALLUCINATION_MAX:
            return (
                False,
                f"HARD GATE: hallucination_rate={hallucination:.2f} > {_HARD_GATE_HALLUCINATION_MAX} "
                "– обнаружены галлюцинации. Требуется ручная проверка (HITL).",
            )

        relevance = llm_scores.get("topic_relevance", 1.0)
        if relevance < _HARD_GATE_TOPIC_MIN:
            return (
                False,
                f"HARD GATE: topic_relevance={relevance:.2f} < {_HARD_GATE_TOPIC_MIN} "
                f"– текст ушёл от темы «{task.brief[:80]}». Требуется ручная проверка (HITL).",
            )

        return True, ""


# ---------------------------------------------------------------------------
# Утилиты
# ---------------------------------------------------------------------------


def _make_empty_style_profile(lang: str = "ru") -> StyleProfile:
    """
    Создаёт «пустой» StyleProfile с нулевыми значениями.

    Используется как fallback когда StyleAnalyzer недоступен.
    ScoringLoop продолжит работу только через LLM-evaluator.
    """
    zeros = {
        "ttr_lemma": 0.5,
        "mtld": 50.0,
        "hapax_rate": 0.3,
        "yule_k": 100.0,
        "avg_word_length_chars": 6.0,
        "short_word_ratio": 0.3,
        "func_word_ratio": 0.5,
        "content_word_ratio": 0.5,
        "avg_sent_len_words": 18.0,
        "sd_sent_len": 6.0,
        "passive_ratio": 0.1,
        "question_ratio": 0.02,
        "exclamation_ratio": 0.0,
        "noun_ratio": 0.35,
        "verb_ratio": 0.20,
        "adj_density": 0.10,
        "adv_density": 0.05,
        "pron_ratio": 0.05,
        "f_score_formality": 60.0,
        "particip_density": 0.05,
        "gerund_density": 0.03,
        "perf_verb_ratio": 0.5,
        "case_genitiv_ratio": 0.2,
        "avg_paragraph_len_words": 80.0,
        "connector_additive_density": 0.01,
        "connector_adversative_density": 0.01,
        "connector_causal_density": 0.005,
        "topic_coherence_avg": 0.5,
        "comma_per_1k": 25.0,
        "dash_per_1k": 5.0,
        "sent_rhythm_index": 0.5,
        "hedging_density": 0.02,
        "epistemic_ratio": 0.01,
        "deontic_ratio": 0.005,
        "boosting_density": 0.01,
        "mean_sentiment": 0.0,
        "sentiment_variance": 0.1,
        "word_count": 0,
        "sentence_count": 0,
        "paragraph_count": 0,
        "lang": lang,
    }
    return StyleProfile(**zeros)
