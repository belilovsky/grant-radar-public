"""Stable, metadata-only contracts for editorial integrations.

The contracts deliberately carry references and review state, never article
bodies, raw evidence, source credentials, or delivery queues.  Those remain
owned by the CMS and ingestion systems.
"""

from __future__ import annotations

import hashlib
import hmac
import re
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Mapping

from qazstack.factcheck import EvidenceReference


_FINGERPRINT_RE = re.compile(r"^sha256:[a-f0-9]{64}$")
_PROJECT_RE = re.compile(r"^[a-z0-9._-]+$")
_EVENT_ID_RE = re.compile(r"^[a-zA-Z0-9._:-]{16,256}$")


class EditorialDecisionState(str, Enum):
    DRAFT = "draft"
    NEEDS_EVIDENCE = "needs-evidence"
    NEEDS_REVIEW = "needs-review"
    READY = "ready"
    BLOCKED = "blocked"


class AiDisclosure(str, Enum):
    NOT_USED = "not-used"
    ASSISTED_DISCLOSED = "assisted-disclosed"
    SYNTHETIC_LABELED = "synthetic-labeled"
    REVIEW_REQUIRED = "review-required"


class LanguageParity(str, Enum):
    NOT_APPLICABLE = "not-applicable"
    PENDING = "pending"
    VERIFIED = "verified"


class ContractValidationError(ValueError):
    """Raised when untrusted integration metadata violates the contract."""


@dataclass(frozen=True)
class EditorialDecision:
    """A CMS-owned decision about one immutable article revision."""

    article_id: str
    project_id: str
    policy_version: str
    content_fingerprint: str
    decision: EditorialDecisionState
    evaluated_at: datetime
    evidence: tuple[EvidenceReference, ...] = ()
    evidence_refs: tuple[str, ...] = ()
    reviewer_ids: tuple[str, ...] = ()
    ai_disclosure: AiDisclosure | None = None
    risk_level: str | None = None
    language_parity: LanguageParity | None = None
    reason_codes: tuple[str, ...] = ()

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "EditorialDecision":
        required = (
            "articleId", "projectId", "policyVersion", "contentFingerprint",
            "decision", "evaluatedAt",
        )
        missing = [name for name in required if not value.get(name)]
        if missing:
            raise ContractValidationError(f"missing decision fields: {', '.join(missing)}")
        project_id = str(value["projectId"])
        fingerprint = str(value["contentFingerprint"])
        if not _PROJECT_RE.fullmatch(project_id):
            raise ContractValidationError("projectId must use lowercase safe characters")
        if not _FINGERPRINT_RE.fullmatch(fingerprint):
            raise ContractValidationError("contentFingerprint must be sha256:<64 lowercase hex characters>")
        try:
            evaluated_at = datetime.fromisoformat(str(value["evaluatedAt"]).replace("Z", "+00:00"))
        except ValueError as exc:
            raise ContractValidationError("evaluatedAt must be ISO-8601") from exc
        return cls(
            article_id=str(value["articleId"]),
            project_id=project_id,
            policy_version=str(value["policyVersion"]),
            content_fingerprint=fingerprint,
            decision=EditorialDecisionState(str(value["decision"])),
            evaluated_at=evaluated_at,
            evidence=_evidence(value.get("evidence")),
            evidence_refs=_references(value.get("evidenceRefs"), "evidenceRefs", 200),
            reviewer_ids=_references(value.get("reviewerIds"), "reviewerIds", 50),
            ai_disclosure=_optional_enum(value.get("aiDisclosure"), AiDisclosure, "aiDisclosure"),
            risk_level=_risk_level(value.get("riskLevel")),
            language_parity=_optional_enum(value.get("languageParity"), LanguageParity, "languageParity"),
            reason_codes=_references(value.get("reasonCodes"), "reasonCodes", 50),
        )


@dataclass(frozen=True)
class EditorialEvent:
    """Transport-neutral envelope for at-least-once editorial events."""

    event_id: str
    type: str
    occurred_at: datetime
    project_id: str
    producer: str
    data: Mapping[str, Any]
    correlation_id: str | None = None

    @classmethod
    def from_dict(cls, value: Mapping[str, Any], *, allowed_types: set[str] | None = None) -> "EditorialEvent":
        required = ("eventId", "type", "occurredAt", "projectId", "producer", "data")
        missing = [name for name in required if value.get(name) is None]
        if missing:
            raise ContractValidationError(f"missing event fields: {', '.join(missing)}")
        event_id = str(value["eventId"])
        project_id = str(value["projectId"])
        event_type = str(value["type"])
        if not _EVENT_ID_RE.fullmatch(event_id):
            raise ContractValidationError("eventId must be 16-256 safe characters")
        if not _PROJECT_RE.fullmatch(project_id):
            raise ContractValidationError("projectId must use lowercase safe characters")
        if allowed_types is not None and event_type not in allowed_types:
            raise ContractValidationError(f"unsupported event type: {event_type}")
        if not isinstance(value["data"], Mapping):
            raise ContractValidationError("event data must be an object")
        try:
            occurred_at = datetime.fromisoformat(str(value["occurredAt"]).replace("Z", "+00:00"))
        except ValueError as exc:
            raise ContractValidationError("occurredAt must be ISO-8601") from exc
        return cls(
            event_id=event_id,
            type=event_type,
            occurred_at=occurred_at,
            project_id=project_id,
            producer=str(value["producer"]),
            data=value["data"],
            correlation_id=_optional_text(value.get("correlationId"), "correlationId", 256),
        )


def verify_hmac_sha256(body: bytes, secret: str | bytes, signature: str) -> bool:
    """Verify an ``sha256=<hex>`` webhook signature without parsing its body."""
    key = secret.encode("utf-8") if isinstance(secret, str) else secret
    expected = "sha256=" + hmac.new(key, body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, signature)


def _references(value: Any, field_name: str, maximum: int) -> tuple[str, ...]:
    if value is None:
        return ()
    if not isinstance(value, list) or len(value) > maximum:
        raise ContractValidationError(f"{field_name} must be an array of at most {maximum} values")
    result = tuple(str(item) for item in value)
    if any(not item or len(item) > 512 for item in result):
        raise ContractValidationError(f"{field_name} contains an invalid reference")
    return result


def _optional_datetime(value: Any, field_name: str) -> datetime | None:
    if value in (None, ""):
        return None
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError as exc:
        raise ContractValidationError(f"{field_name} must be ISO-8601") from exc
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ContractValidationError(f"{field_name} must include a timezone")
    return parsed


def _evidence(value: Any) -> tuple[EvidenceReference, ...]:
    if value is None:
        return ()
    if not isinstance(value, list) or len(value) > 200:
        raise ContractValidationError("evidence must be an array of at most 200 values")
    result: list[EvidenceReference] = []
    for index, item in enumerate(value):
        if not isinstance(item, Mapping):
            raise ContractValidationError(f"evidence[{index}] must be an object")
        claim_ids = item.get("claimIds") or []
        if not isinstance(claim_ids, list):
            raise ContractValidationError(f"evidence[{index}].claimIds must be an array")
        try:
            result.append(
                EvidenceReference(
                    evidence_id=str(item.get("evidenceId") or ""),
                    title=str(item.get("title") or ""),
                    url=str(item.get("url") or ""),
                    source_type=str(item.get("sourceType") or ""),
                    relation=str(item.get("relation") or "unknown"),
                    note=str(item.get("note") or ""),
                    captured_at=_optional_datetime(item.get("capturedAt"), f"evidence[{index}].capturedAt"),
                    digest=str(item.get("digest") or ""),
                    claim_ids=tuple(str(claim_id) for claim_id in claim_ids),
                    capture_status=str(item.get("captureStatus") or "unavailable"),
                    freshness_status=str(item.get("freshnessStatus") or "unknown"),
                    published_at=_optional_datetime(item.get("publishedAt"), f"evidence[{index}].publishedAt"),
                    archive_ref=str(item.get("archiveRef") or ""),
                    retention_class=str(item.get("retentionClass") or ""),
                    provider=str(item.get("provider") or ""),
                )
            )
        except (TypeError, ValueError) as exc:
            raise ContractValidationError(f"invalid evidence[{index}]: {exc}") from exc
    return tuple(result)


def _optional_text(value: Any, field_name: str, maximum: int) -> str | None:
    if value is None:
        return None
    text = str(value)
    if not text or len(text) > maximum:
        raise ContractValidationError(f"{field_name} is invalid")
    return text


def _optional_enum(value: Any, enum_type: type[Enum], field_name: str):
    if value is None:
        return None
    try:
        return enum_type(str(value))
    except ValueError as exc:
        raise ContractValidationError(f"{field_name} is invalid") from exc


def _risk_level(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value)
    if text not in {"P0", "P1", "P2"}:
        raise ContractValidationError("riskLevel must be P0, P1 or P2")
    return text
