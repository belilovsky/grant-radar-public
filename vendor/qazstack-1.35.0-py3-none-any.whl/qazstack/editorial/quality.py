"""Dependency-free editorial title quality and event deduplication helpers."""

from __future__ import annotations

import re

_SPACE_RE = re.compile(r"\s+")
_TOKEN_RE = re.compile(r"[a-zа-яё0-9]{3,}", re.IGNORECASE)
_CAPITALIZED_TOKEN_RE = re.compile(r"(?<![\w-])[A-ZА-ЯЁӘҒҚҢӨҰҮҺІ][a-zа-яёәғқңөұүһі]{2,}")
_SOURCE_SUFFIX_RE = re.compile(
    r"\s+(?:[-––|:]\s*)?(?:последние\s+)?новости\s+(?:на\s+)?(?:[\w.-]+\.)?[a-zа-яё-]+\.kz\s*$",
    re.IGNORECASE,
)
_DOMAIN_SUFFIX_RE = re.compile(r"\s+[-––|]\s+(?:www\.)?[\w.-]+\.(?:kz|ru|com|org|net)\s*$", re.IGNORECASE)
_STOPWORDS = {
    "без", "был", "была", "были", "будет", "для", "его", "или", "как", "над", "при",
    "про", "что", "это", "уже", "еще", "после", "перед", "через", "новости", "казахстан",
    "казахстана", "казахстане", "астана", "астане", "алматы", "алмате", "сказал", "сообщил",
}
_SUFFIXES = (
    "иями", "ями", "ами", "ого", "его", "ому", "ему", "ыми", "ими", "остью", "ения",
    "ание", "ской", "ной", "ный", "ний", "ому", "ая", "яя", "ое", "ее", "ые", "ие", "ых", "их",
    "ам", "ям", "ах", "ях", "ов", "ев", "ом", "ем", "а", "я", "ы", "и", "е", "у",
)


def clean_editorial_title(title: str | None) -> str:
    """Remove source branding accidentally appended by feed extractors."""
    cleaned = _SPACE_RE.sub(" ", (title or "").replace("\xa0", " ")).strip(" \t\r\n-|––")
    previous = None
    while cleaned and cleaned != previous:
        previous = cleaned
        cleaned = _SOURCE_SUFFIX_RE.sub("", cleaned).strip(" \t\r\n-|––")
        cleaned = _DOMAIN_SUFFIX_RE.sub("", cleaned).strip(" \t\r\n-|––")
    return cleaned


def _root(token: str) -> str:
    value = token.lower().replace("ё", "е")
    if value in _STOPWORDS or value.isdigit():
        return ""
    for suffix in _SUFFIXES:
        if value.endswith(suffix) and len(value) - len(suffix) >= 5:
            value = value[: -len(suffix)]
            break
    return value[:8]


def editorial_title_tokens(title: str | None) -> set[str]:
    """Return normalized event-bearing title tokens."""
    return {root for token in _TOKEN_RE.findall(clean_editorial_title(title)) if (root := _root(token))}


def _capitalized_title_tokens(title: str | None) -> set[str]:
    return {root for token in _CAPITALIZED_TOKEN_RE.findall(clean_editorial_title(title)) if (root := _root(token))}


def titles_describe_same_event(left: str | None, right: str | None) -> bool:
    """Conservatively identify near-duplicate headlines about one event."""
    left_clean = clean_editorial_title(left).casefold()
    right_clean = clean_editorial_title(right).casefold()
    if not left_clean or not right_clean:
        return False
    if left_clean == right_clean:
        return True
    left_tokens = editorial_title_tokens(left_clean)
    right_tokens = editorial_title_tokens(right_clean)
    if min(len(left_tokens), len(right_tokens)) < 3:
        return False
    common = len(left_tokens & right_tokens)
    containment = common / min(len(left_tokens), len(right_tokens))
    union = len(left_tokens | right_tokens)
    jaccard = common / union if union else 0.0
    named_overlap = len(_capitalized_title_tokens(left) & _capitalized_title_tokens(right))
    return (common >= 5 and containment >= 0.65 and jaccard >= 0.40) or (
        common >= 4 and containment >= 0.65 and jaccard >= 0.40 and named_overlap >= 2
    )


class TitleDuplicateIndex:
    """Small inverted index for scalable near-duplicate title lookup."""

    def __init__(self) -> None:
        self._titles: list[tuple[int | None, str]] = []
        self._postings: dict[str, set[int]] = {}

    def find(self, title: str | None) -> tuple[int | None, str] | None:
        tokens = editorial_title_tokens(title)
        if len(tokens) < 3:
            return None
        hits: dict[int, int] = {}
        for token in tokens:
            for index in self._postings.get(token, ()):
                hits[index] = hits.get(index, 0) + 1
        for index, common in sorted(hits.items(), key=lambda item: item[1], reverse=True):
            if common < 4:
                break
            row_id, existing = self._titles[index]
            if titles_describe_same_event(title, existing):
                return row_id, existing
        return None

    def add(self, title: str | None, row_id: int | None = None) -> None:
        cleaned = clean_editorial_title(title)
        if not cleaned:
            return
        index = len(self._titles)
        self._titles.append((row_id, cleaned))
        for token in editorial_title_tokens(cleaned):
            self._postings.setdefault(token, set()).add(index)
