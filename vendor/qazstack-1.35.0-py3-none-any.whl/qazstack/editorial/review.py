"""UI-neutral human review queue and feedback contracts."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from qazstack.contracts._validation import require_aware, require_identifier, require_one_of, require_text


@dataclass(frozen=True, slots=True)
class ReviewItem:
    review_id: str
    subject_ref: str
    reason: str
    priority: str
    created_at: datetime
    assigned_to: str | None = None

    def __post_init__(self) -> None:
        require_identifier(self.review_id, "review_id")
        require_text(self.subject_ref, "subject_ref")
        require_text(self.reason, "reason")
        require_one_of(self.priority, frozenset({"low", "normal", "high", "urgent"}), "priority")
        require_aware(self.created_at, "created_at")
        if self.assigned_to is not None:
            require_text(self.assigned_to, "assigned_to")


@dataclass(frozen=True, slots=True)
class ReviewDecision:
    review_id: str
    decision: str
    decided_by: str
    decided_at: datetime
    reason: str
    feedback: str | None = None

    def __post_init__(self) -> None:
        require_identifier(self.review_id, "review_id")
        require_one_of(self.decision, frozenset({"approve", "reject", "revise", "defer"}), "decision")
        require_text(self.decided_by, "decided_by")
        require_aware(self.decided_at, "decided_at")
        require_text(self.reason, "reason")
