"""Deterministic, explainable story-clustering decisions.

The module owns only comparison policy. Consumers continue to own candidate
selection, persistence, merge transactions and editorial overrides.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date, datetime
from typing import Iterable

_TOKEN_RE = re.compile(r"[0-9A-Za-zА-Яа-яЁёӘәҒғҚқҢңӨөҰұҮүҺһІі]+", re.UNICODE)
_DEFAULT_STOPWORDS = frozenset(
    {
        "был",
        "была",
        "были",
        "будет",
        "для",
        "его",
        "как",
        "который",
        "на",
        "не",
        "новости",
        "новый",
        "о",
        "об",
        "от",
        "по",
        "при",
        "с",
        "со",
        "что",
        "это",
        "және",
        "мен",
        "үшін",
    }
)
_RECURRING_TOKENS = frozenset(
    {
        "курс",
        "погода",
        "прогноз",
        "расписание",
        "результаты",
        "цены",
        "бағам",
        "ауа",
    }
)


@dataclass(frozen=True, slots=True)
class ClusterPolicy:
    """Portable thresholds for one article-to-story decision."""

    min_entity_overlap: int = 1
    min_title_overlap: int = 2
    min_title_ratio: float = 0.5
    max_gap_days: int = 7
    max_span_days: int = 14
    allow_title_only: bool = True
    require_category_match: bool = True
    stopwords: frozenset[str] = field(default_factory=lambda: _DEFAULT_STOPWORDS)
    recurring_tokens: frozenset[str] = field(default_factory=lambda: _RECURRING_TOKENS)

    def __post_init__(self) -> None:
        if self.min_entity_overlap < 0 or self.min_title_overlap < 1:
            raise ValueError("overlap thresholds must be non-negative")
        if not 0 <= self.min_title_ratio <= 1:
            raise ValueError("min_title_ratio must be between 0 and 1")
        if self.max_gap_days < 0 or self.max_span_days < 0:
            raise ValueError("time windows must be non-negative")


@dataclass(frozen=True, slots=True)
class StoryCandidate:
    """Product-neutral signals required for clustering."""

    title: str
    category: str | None = None
    entity_ids: frozenset[str] = field(default_factory=frozenset)
    first_published_at: date | datetime | str | None = None
    last_published_at: date | datetime | str | None = None
    article_count: int = 1


@dataclass(frozen=True, slots=True)
class ArticleCandidate:
    title: str
    category: str | None = None
    entity_ids: frozenset[str] = field(default_factory=frozenset)
    published_at: date | datetime | str | None = None


@dataclass(frozen=True, slots=True)
class ClusterDecision:
    accepted: bool
    score: float
    reason_codes: tuple[str, ...]
    entity_overlap: int
    title_overlap: int
    title_ratio: float
    gap_days: int | None
    combined_span_days: int | None


def _as_date(value: date | datetime | str | None) -> date | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    try:
        return date.fromisoformat(str(value)[:10])
    except ValueError:
        return None


def story_tokens(value: str | None, *, stopwords: Iterable[str] = _DEFAULT_STOPWORDS) -> frozenset[str]:
    """Return stable RU/KK/EN comparison tokens without model dependencies."""

    ignored = frozenset(stopwords)
    return frozenset(
        token
        for token in (match.group(0).casefold() for match in _TOKEN_RE.finditer(value or ""))
        if len(token) >= 3 and not token.isdigit() and token not in ignored
    )


def _temporal_metrics(story: StoryCandidate, article: ArticleCandidate) -> tuple[int | None, int | None]:
    article_day = _as_date(article.published_at)
    first_day = _as_date(story.first_published_at)
    last_day = _as_date(story.last_published_at) or first_day
    if article_day is None or (first_day is None and last_day is None):
        return None, None
    boundaries = [day for day in (first_day, last_day) if day is not None]
    gap_days = min(abs((article_day - boundary).days) for boundary in boundaries)
    all_days = [*boundaries, article_day]
    return gap_days, (max(all_days) - min(all_days)).days


def evaluate_story_attachment(
    story: StoryCandidate,
    article: ArticleCandidate,
    *,
    policy: ClusterPolicy | None = None,
) -> ClusterDecision:
    """Evaluate one candidate without mutating either input.

    ``reason_codes`` are stable machine-readable evidence for shadow-mode
    comparisons and human review.
    """

    cfg = policy or ClusterPolicy()
    story_title_tokens = story_tokens(story.title, stopwords=cfg.stopwords)
    article_title_tokens = story_tokens(article.title, stopwords=cfg.stopwords)
    shared_title = story_title_tokens & article_title_tokens
    title_overlap = len(shared_title)
    denominator = max(1, min(len(story_title_tokens), len(article_title_tokens)))
    title_ratio = title_overlap / denominator
    entity_overlap = len(story.entity_ids & article.entity_ids)
    gap_days, combined_span_days = _temporal_metrics(story, article)

    reasons: list[str] = []
    blocked = False
    if cfg.require_category_match and story.category and article.category and story.category != article.category:
        reasons.append("category_mismatch")
        blocked = True
    if gap_days is not None and gap_days > cfg.max_gap_days:
        reasons.append("temporal_gap")
        blocked = True
    if combined_span_days is not None and combined_span_days > cfg.max_span_days:
        reasons.append("span_too_wide")
        blocked = True

    entity_match = entity_overlap >= cfg.min_entity_overlap if cfg.min_entity_overlap else True
    title_match = title_overlap >= cfg.min_title_overlap and title_ratio >= cfg.min_title_ratio
    recurring = bool((story_title_tokens | article_title_tokens) & cfg.recurring_tokens)
    if recurring and entity_overlap == 0:
        reasons.append("recurring_topic_guard")
        blocked = True

    if entity_match and entity_overlap:
        reasons.append("entity_overlap")
    if title_match:
        reasons.append("title_overlap")
    if entity_overlap == 0 and title_match and cfg.allow_title_only:
        reasons.append("title_only_match")

    accepted = not blocked and (bool(entity_overlap and title_overlap >= 1) or (cfg.allow_title_only and title_match))
    if not accepted and not blocked:
        reasons.append("insufficient_signal")
    if accepted:
        reasons.append("accepted")

    entity_score = min(1.0, entity_overlap / max(1, cfg.min_entity_overlap + 1))
    title_score = min(1.0, (title_ratio + min(1.0, title_overlap / 4)) / 2)
    temporal_score = 1.0 if gap_days is None else max(0.0, 1 - gap_days / max(1, cfg.max_gap_days + 1))
    score = round((entity_score * 0.45) + (title_score * 0.4) + (temporal_score * 0.15), 4)
    if blocked:
        score = min(score, 0.49)

    return ClusterDecision(
        accepted=accepted,
        score=score,
        reason_codes=tuple(dict.fromkeys(reasons)),
        entity_overlap=entity_overlap,
        title_overlap=title_overlap,
        title_ratio=round(title_ratio, 4),
        gap_days=gap_days,
        combined_span_days=combined_span_days,
    )
