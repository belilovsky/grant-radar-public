"""Начальная схема editorial: все таблицы, индексы, тригеры, view.

Revision ID: 0001_initial
Revises:
Create Date: 2026-04-11 00:00:00 UTC
"""
from __future__ import annotations

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers
revision = "0001_initial"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    # ── Схема и расширения ───────────────────────────────────────────────────
    op.execute("CREATE SCHEMA IF NOT EXISTS editorial")
    op.execute("CREATE EXTENSION IF NOT EXISTS vector")

    # ── 1. authors ───────────────────────────────────────────────────────────
    op.create_table(
        "authors",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("author_id", sa.String(100), nullable=False, unique=True),
        sa.Column("name", sa.String(200), nullable=False),
        sa.Column("domain_scope", postgresql.JSONB, nullable=False, server_default=sa.text("'[]'::jsonb")),
        sa.Column("genre_scope", postgresql.JSONB, nullable=False, server_default=sa.text("'[]'::jsonb")),
        sa.Column("languages", postgresql.JSONB, nullable=False, server_default=sa.text("'[\"ru\"]'::jsonb")),
        sa.Column("is_active", sa.Boolean, nullable=False, server_default=sa.text("true")),
        sa.Column("profile_json", postgresql.JSONB, nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        schema="editorial",
        comment="Профили виртуальных AI-авторов",
    )
    op.create_index("idx_authors_active", "authors", ["is_active"], schema="editorial")
    op.create_index("idx_authors_domain", "authors", ["domain_scope"], schema="editorial", postgresql_using="gin")
    op.create_index("idx_authors_lang", "authors", ["languages"], schema="editorial", postgresql_using="gin")

    # vector(1024) – добавляем отдельно (не поддерживается в create_table)
    op.execute("ALTER TABLE editorial.authors ADD COLUMN style_embedding vector(1024)")
    op.execute("""
        CREATE INDEX idx_authors_embedding ON editorial.authors
        USING hnsw (style_embedding vector_cosine_ops)
        WITH (m = 16, ef_construction = 64)
    """)

    # ── 2. generation_tasks ─────────────────────────────────────────────────
    op.create_table(
        "generation_tasks",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("task_id", sa.String(100), nullable=False, unique=True),
        sa.Column("author_id", sa.String(100), nullable=False),
        sa.Column("brief", sa.Text, nullable=False),
        sa.Column("task_type", sa.String(50), nullable=False, server_default=sa.text("'analysis'")),
        sa.Column("lang", sa.String(10), nullable=False, server_default=sa.text("'ru'")),
        sa.Column("target_word_count", sa.Integer, nullable=False, server_default=sa.text("600")),
        sa.Column("research_query", sa.Text),
        sa.Column("research_date_from", sa.String(20)),
        sa.Column("research_date_to", sa.String(20)),
        sa.Column("input_data", postgresql.JSONB),
        sa.Column("parent_task_id", sa.String(100)),
        sa.Column("status", sa.String(30), nullable=False, server_default=sa.text("'pending'")),
        sa.Column("priority", sa.SmallInteger, nullable=False, server_default=sa.text("5")),
        sa.Column("current_iteration", sa.Integer, nullable=False, server_default=sa.text("0")),
        sa.Column("error_message", sa.Text),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.ForeignKeyConstraint(["author_id"], ["editorial.authors.author_id"], ondelete="RESTRICT"),
        sa.ForeignKeyConstraint(["parent_task_id"], ["editorial.generation_tasks.task_id"]),
        schema="editorial",
        comment="Задания на генерацию контента",
    )
    op.create_index("idx_tasks_author", "generation_tasks", ["author_id"], schema="editorial")
    op.create_index("idx_tasks_status", "generation_tasks", ["status"], schema="editorial")
    op.create_index("idx_tasks_created", "generation_tasks", ["created_at"], schema="editorial")
    op.create_index("idx_tasks_priority", "generation_tasks", [sa.text("priority DESC, created_at")], schema="editorial")

    # ── 3. drafts ────────────────────────────────────────────────────────────
    op.create_table(
        "drafts",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("draft_id", sa.String(150), nullable=False, unique=True),
        sa.Column("task_id", sa.String(100), nullable=False),
        sa.Column("iteration", sa.SmallInteger, nullable=False, server_default=sa.text("1")),
        sa.Column("content", sa.Text, nullable=False),
        sa.Column("word_count", sa.Integer),
        sa.Column("research_context", sa.Text),
        sa.Column("research_sources", postgresql.JSONB, server_default=sa.text("'[]'::jsonb")),
        sa.Column("style_metrics", postgresql.JSONB),
        sa.Column("scores", postgresql.JSONB),
        sa.Column("overall_score", sa.Float),
        sa.Column("passes_threshold", sa.Boolean),
        sa.Column("critic_feedback", sa.Text),
        sa.Column("provenance", postgresql.JSONB),
        sa.Column("llm_model", sa.String(100)),
        sa.Column("llm_cost_usd", sa.Float),
        sa.Column("prompt_tokens", sa.Integer),
        sa.Column("completion_tokens", sa.Integer),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.ForeignKeyConstraint(["task_id"], ["editorial.generation_tasks.task_id"], ondelete="CASCADE"),
        schema="editorial",
        comment="Версии черновиков с результатами scoring",
    )
    op.create_index("idx_drafts_task", "drafts", ["task_id"], schema="editorial")
    op.create_index("idx_drafts_score", "drafts", ["overall_score"], schema="editorial")
    op.create_index("idx_drafts_created", "drafts", ["created_at"], schema="editorial")

    # ── 4. scoring_log ───────────────────────────────────────────────────────
    op.create_table(
        "scoring_log",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("draft_id", sa.String(150), nullable=False),
        sa.Column("task_id", sa.String(100), nullable=False),
        sa.Column("iteration", sa.SmallInteger, nullable=False),
        sa.Column("scores", postgresql.JSONB, nullable=False),
        sa.Column("overall_score", sa.Float, nullable=False),
        sa.Column("passes", sa.Boolean, nullable=False),
        sa.Column("feedback", sa.Text),
        sa.Column("actual_metrics", postgresql.JSONB),
        sa.Column("evaluator", sa.String(30), server_default=sa.text("'combined'")),
        sa.Column("llm_model", sa.String(100)),
        sa.Column("prompt_tokens", sa.Integer),
        sa.Column("completion_tokens", sa.Integer),
        sa.Column("cost_usd", sa.Float),
        sa.Column("scored_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.ForeignKeyConstraint(["draft_id"], ["editorial.drafts.draft_id"], ondelete="CASCADE"),
        schema="editorial",
        comment="Полный лог всех итераций scoring loop",
    )
    op.create_index("idx_scoring_task", "scoring_log", ["task_id"], schema="editorial")
    op.create_index("idx_scoring_draft", "scoring_log", ["draft_id"], schema="editorial")

    # ── 5. hitl_queue ────────────────────────────────────────────────────────
    op.create_table(
        "hitl_queue",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("task_id", sa.String(100), nullable=False),
        sa.Column("author_id", sa.String(100), nullable=False),
        sa.Column("author_name", sa.String(200), nullable=False),
        sa.Column("title", sa.String(500)),
        sa.Column("content", sa.Text, nullable=False),
        sa.Column("lang", sa.String(10), nullable=False, server_default=sa.text("'ru'")),
        sa.Column("word_count", sa.Integer),
        sa.Column("iterations_used", sa.SmallInteger),
        sa.Column("final_scores", postgresql.JSONB),
        sa.Column("overall_score", sa.Float),
        sa.Column("research_sources", postgresql.JSONB, server_default=sa.text("'[]'::jsonb")),
        sa.Column("status", sa.String(30), nullable=False, server_default=sa.text("'pending'")),
        sa.Column("priority", sa.SmallInteger, nullable=False, server_default=sa.text("5")),
        sa.Column("hard_gate_reason", sa.Text),
        sa.Column("reviewer_id", postgresql.UUID(as_uuid=True)),
        sa.Column("reviewer_notes", sa.Text),
        sa.Column("final_content", sa.Text),
        sa.Column("reviewed_at", sa.DateTime(timezone=True)),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.ForeignKeyConstraint(["task_id"], ["editorial.generation_tasks.task_id"], ondelete="CASCADE"),
        schema="editorial",
        comment="Очередь материалов для проверки редактором",
    )
    op.create_index("idx_hitl_status", "hitl_queue", ["status", "created_at"], schema="editorial")
    op.create_index("idx_hitl_author", "hitl_queue", ["author_id"], schema="editorial")
    op.create_index("idx_hitl_score", "hitl_queue", ["overall_score"], schema="editorial")

    # ── 6. publications ──────────────────────────────────────────────────────
    op.create_table(
        "publications",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("task_id", sa.String(100), nullable=False),
        sa.Column("draft_id", sa.String(150)),
        sa.Column("author_id", sa.String(100), nullable=False),
        sa.Column("author_name", sa.String(200), nullable=False),
        sa.Column("title", sa.String(500), nullable=False),
        sa.Column("content", sa.Text, nullable=False),
        sa.Column("lang", sa.String(10), nullable=False),
        sa.Column("word_count", sa.Integer),
        sa.Column("research_sources", postgresql.JSONB, server_default=sa.text("'[]'::jsonb")),
        sa.Column("final_scores", postgresql.JSONB),
        sa.Column("overall_score", sa.Float),
        sa.Column("provenance", postgresql.JSONB),
        sa.Column("disclosure_metadata", postgresql.JSONB),
        sa.Column("cms_article_id", sa.String(200)),
        sa.Column("cms_url", sa.String(1000)),
        sa.Column("platform", sa.String(100)),
        sa.Column("published_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.ForeignKeyConstraint(["task_id"], ["editorial.generation_tasks.task_id"], ondelete="RESTRICT"),
        schema="editorial",
        comment="Архив опубликованных AI-материалов",
    )
    op.create_index("idx_pub_author", "publications", ["author_id"], schema="editorial")
    op.create_index("idx_pub_published", "publications", ["published_at"], schema="editorial")
    op.create_index("idx_pub_lang", "publications", ["lang"], schema="editorial")

    # ── 7. research_bank ────────────────────────────────────────────────────
    op.create_table(
        "research_bank",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("content", sa.Text, nullable=False),
        sa.Column("source_url", sa.Text),
        sa.Column("source_type", sa.String(50), nullable=False, server_default=sa.text("'article'")),
        sa.Column("topic_tags", postgresql.ARRAY(sa.Text), server_default=sa.text("'{}'")),
        sa.Column("lang", sa.String(10), nullable=False, server_default=sa.text("'ru'")),
        sa.Column("quality_score", sa.Float),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        schema="editorial",
        comment="Накопленная база знаний для Research Bank",
    )
    op.execute("ALTER TABLE editorial.research_bank ADD COLUMN embedding vector(1024)")
    op.execute("""
        CREATE INDEX idx_rb_tags ON editorial.research_bank USING GIN (topic_tags)
    """)
    op.execute("CREATE INDEX idx_rb_lang ON editorial.research_bank (lang)")
    op.execute("""
        CREATE INDEX idx_rb_embedding ON editorial.research_bank
        USING hnsw (embedding vector_cosine_ops)
        WITH (m = 16, ef_construction = 64)
    """)

    # ── 8. research_cache ───────────────────────────────────────────────────
    op.create_table(
        "research_cache",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("query_hash", sa.String(64), nullable=False, unique=True),
        sa.Column("query_text", sa.String(500), nullable=False),
        sa.Column("results", postgresql.JSONB, nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        schema="editorial",
    )
    op.execute("ALTER TABLE editorial.research_cache ADD COLUMN embedding vector(1024)")
    op.create_index("idx_rc_hash", "research_cache", ["query_hash"], schema="editorial", unique=True)
    op.create_index("idx_rc_expires", "research_cache", ["expires_at"], schema="editorial")

    # ── Тригеры updated_at ──────────────────────────────────────────────────
    op.execute("""
        CREATE OR REPLACE FUNCTION editorial.set_updated_at()
        RETURNS TRIGGER LANGUAGE plpgsql AS $$
        BEGIN
            NEW.updated_at = NOW();
            RETURN NEW;
        END;
        $$;
    """)
    for tbl in ("authors", "generation_tasks"):
        op.execute(f"""
            CREATE TRIGGER trg_{tbl}_updated_at
                BEFORE UPDATE ON editorial.{tbl}
                FOR EACH ROW EXECUTE FUNCTION editorial.set_updated_at();
        """)

    # ── Materialized view author_stats ──────────────────────────────────────
    op.execute("""
        CREATE MATERIALIZED VIEW editorial.author_stats AS
        SELECT
            a.author_id,
            a.name,
            COUNT(DISTINCT p.id)                     AS total_publications,
            AVG(p.overall_score)                     AS avg_score,
            AVG(p.word_count)                        AS avg_word_count,
            COUNT(DISTINCT t.id) FILTER (WHERE t.status = 'pending') AS pending_tasks,
            MAX(p.published_at)                      AS last_published_at
        FROM editorial.authors a
        LEFT JOIN editorial.publications p ON p.author_id = a.author_id
        LEFT JOIN editorial.generation_tasks t ON t.author_id = a.author_id
        GROUP BY a.author_id, a.name
        WITH DATA;
    """)
    op.execute("CREATE UNIQUE INDEX idx_author_stats_unique ON editorial.author_stats (author_id)")


def downgrade() -> None:
    op.execute("DROP MATERIALIZED VIEW IF EXISTS editorial.author_stats")
    for tbl in ["research_cache", "research_bank", "publications", "hitl_queue", "scoring_log", "drafts", "generation_tasks", "authors"]:
        op.execute(f"DROP TABLE IF EXISTS editorial.{tbl} CASCADE")
    op.execute("DROP FUNCTION IF EXISTS editorial.set_updated_at CASCADE")
    op.execute("DROP SCHEMA IF EXISTS editorial CASCADE")
