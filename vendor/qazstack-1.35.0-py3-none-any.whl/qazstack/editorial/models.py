"""
qazstack.editorial.models
=========================
Pydantic v2 модели данных для модуля AI-авторов (qazstack.editorial).

Все модели типизированы, снабжены Field-описаниями и готовы к сериализации
в JSON/PostgreSQL JSONB.  Версия схемы: 0.3.2.
"""
from __future__ import annotations

from datetime import datetime
from typing import Any, Optional

from pydantic import BaseModel, Field, ConfigDict


# ─────────────────────────────────────────────────────────────────────────────
# 1. Стилометрические целевые диапазоны
# ─────────────────────────────────────────────────────────────────────────────

class StyleTargetRange(BaseModel):
    """Целевой диапазон одного стилометрического параметра.

    Attributes:
        target:      Идеальное значение (центр диапазона).
        range:       Допустимый интервал (lo, hi).  StyleValidator штрафует
                     за выход за пределы с плавным убыванием.
        weight:      Вес метрики внутри своей категории (0.0–1.0).
        description: Человекочитаемое описание для отладки.
    """
    target: float = Field(..., description="Идеальное значение метрики")
    range: tuple[float, float] = Field(..., description="Допустимый диапазон (lo, hi)")
    weight: float = Field(default=1.0, ge=0.0, le=1.0, description="Вес метрики в категории")
    description: str = Field(default="", description="Описание метрики")


# ─────────────────────────────────────────────────────────────────────────────
# 2. Целевые профили по категориям
# ─────────────────────────────────────────────────────────────────────────────

class LexicalTargets(BaseModel):
    """Целевые диапазоны лексических метрик."""

    ttr_lemma: StyleTargetRange = Field(..., description="Type-Token Ratio по леммам")
    mtld: StyleTargetRange = Field(..., description="Measure of Textual Lexical Diversity (McCarthy & Jarvis 2010)")
    hapax_rate: StyleTargetRange = Field(..., description="Доля слов, встречающихся ровно один раз")
    yule_k: StyleTargetRange = Field(..., description="Yule's K – константа лексического богатства")
    avg_word_length_chars: StyleTargetRange = Field(..., description="Средняя длина слова в символах")
    short_word_ratio: StyleTargetRange = Field(..., description="Доля слов ≤4 символа")
    func_word_ratio: StyleTargetRange = Field(..., description="Доля служебных слов")
    content_word_ratio: StyleTargetRange = Field(..., description="Доля знаменательных слов")
    zipf_alpha: StyleTargetRange = Field(..., description="Наклон закона Ципфа (показатель частотного распределения)")
    term_density: StyleTargetRange = Field(..., description="Плотность терминологической лексики")
    borrowing_ratio: StyleTargetRange = Field(..., description="Доля заимствованной лексики (для RU)")
    number_density: StyleTargetRange = Field(..., description="Плотность числовых токенов")


class SyntacticTargets(BaseModel):
    """Целевые диапазоны синтаксических метрик."""

    avg_sent_len_words: StyleTargetRange = Field(..., description="Средняя длина предложения в словах")
    sd_sent_len: StyleTargetRange = Field(..., description="Стандартное отклонение длины предложений")
    sent_len_gini: StyleTargetRange = Field(..., description="Коэффициент Джини для длин предложений")
    subordination_index: StyleTargetRange = Field(..., description="Доля сложноподчинённых предложений")
    passive_ratio: StyleTargetRange = Field(..., description="Доля пассивных конструкций")
    complex_sent_ratio: StyleTargetRange = Field(..., description="Доля сложных предложений")
    parse_depth_avg: StyleTargetRange = Field(..., description="Средняя глубина дерева зависимостей")
    dependency_length_avg: StyleTargetRange = Field(..., description="Средняя длина дуг зависимостей")
    question_ratio: StyleTargetRange = Field(..., description="Доля вопросительных предложений")
    exclamation_ratio: StyleTargetRange = Field(..., description="Доля восклицательных предложений")


class MorphologicalTargets(BaseModel):
    """Целевые диапазоны морфологических метрик."""

    noun_ratio: StyleTargetRange = Field(..., description="Доля существительных")
    verb_ratio: StyleTargetRange = Field(..., description="Доля глаголов")
    noun_verb_ratio: StyleTargetRange = Field(..., description="Отношение существительных к глаголам")
    adj_density: StyleTargetRange = Field(..., description="Плотность прилагательных")
    adv_density: StyleTargetRange = Field(..., description="Плотность наречий")
    pron_ratio: StyleTargetRange = Field(..., description="Доля местоимений")
    conjunction_density: StyleTargetRange = Field(..., description="Плотность союзов")
    f_score_formality: StyleTargetRange = Field(
        ..., description="F-score формальности (Heylighen & Dewaele 2002)"
    )
    particip_density: StyleTargetRange = Field(..., description="Плотность причастий (PRTF+PRTS)")
    gerund_density: StyleTargetRange = Field(..., description="Плотность деепричастий (GRND)")
    perf_verb_ratio: StyleTargetRange = Field(..., description="Доля глаголов совершенного вида")
    case_genitiv_ratio: StyleTargetRange = Field(
        ..., description="Доля существительных в родительном падеже"
    )


class DiscourseTargets(BaseModel):
    """Целевые диапазоны дискурсивных метрик."""

    avg_paragraph_len_words: StyleTargetRange = Field(..., description="Средняя длина абзаца в словах")
    sd_paragraph_len: StyleTargetRange = Field(..., description="Стандартное отклонение длины абзацев")
    connector_additive_density: StyleTargetRange = Field(
        ..., description="Плотность аддитивных коннекторов (также, кроме того)"
    )
    connector_adversative_density: StyleTargetRange = Field(
        ..., description="Плотность адверсативных коннекторов (однако, тем не менее)"
    )
    connector_causal_density: StyleTargetRange = Field(
        ..., description="Плотность каузальных коннекторов (поэтому, следовательно)"
    )
    connector_conclusive_density: StyleTargetRange = Field(
        ..., description="Плотность заключительных коннекторов (итак, в конечном счёте)"
    )
    topic_coherence_avg: StyleTargetRange = Field(
        ..., description="Средняя тематическая когезия между соседними абзацами (Jaccard)"
    )
    entity_grid_density: StyleTargetRange = Field(
        ..., description="Плотность именованных сущностей в entity grid"
    )
    single_sent_paragraph_ratio: StyleTargetRange = Field(
        ..., description="Доля однопредложенных абзацев"
    )
    argument_marker_density: StyleTargetRange = Field(
        ..., description="Плотность аргументационных маркеров"
    )


class RhythmicTargets(BaseModel):
    """Целевые диапазоны ритмических/пунктуационных метрик."""

    comma_per_1k: StyleTargetRange = Field(..., description="Запятых на 1000 слов")
    dash_per_1k: StyleTargetRange = Field(..., description="Тире на 1000 слов")
    ellipsis_per_1k: StyleTargetRange = Field(..., description="Многоточий на 1000 слов")
    parenthesis_per_1k: StyleTargetRange = Field(..., description="Скобочных вставок на 1000 слов")
    sent_rhythm_index: StyleTargetRange = Field(
        ..., description="Ритмический индекс (СО длин / среднее длин предложений)"
    )
    colon_per_1k: StyleTargetRange = Field(..., description="Двоеточий на 1000 слов")


class PragmaticTargets(BaseModel):
    """Целевые диапазоны прагматических метрик."""

    hedging_density: StyleTargetRange = Field(..., description="Плотность хеджинговых маркеров")
    epistemic_ratio: StyleTargetRange = Field(..., description="Доля эпистемической модальности")
    deontic_ratio: StyleTargetRange = Field(..., description="Доля деонтической модальности")
    reader_2nd_person_ratio: StyleTargetRange = Field(
        ..., description="Доля местоимений 2-го лица (вы/вас/вам)"
    )
    inclusive_we_ratio: StyleTargetRange = Field(
        ..., description="Доля инклюзивного «мы» (нам/наш/мы)"
    )
    boosting_density: StyleTargetRange = Field(..., description="Плотность усилителей (бесспорно, явно)")
    evidential_authoritative: StyleTargetRange = Field(
        ..., description="Плотность авторитативных эвиденциалов (по данным, согласно)"
    )
    question_rhetorical_ratio: StyleTargetRange = Field(
        ..., description="Доля риторических вопросов среди вопросительных предложений"
    )


class TonalTargets(BaseModel):
    """Целевые диапазоны тональных метрик."""

    mean_sentiment: StyleTargetRange = Field(
        ..., description="Средний сентимент текста (-1.0 негатив … 1.0 позитив)"
    )
    sentiment_variance: StyleTargetRange = Field(
        ..., description="Дисперсия сентимента между предложениями"
    )
    neutral_sentence_ratio: StyleTargetRange = Field(
        ..., description="Доля нейтральных предложений"
    )
    positive_ratio: StyleTargetRange = Field(..., description="Доля позитивных предложений")
    emotion_entropy: StyleTargetRange = Field(
        ..., description="Энтропия эмоциональной окраски (разнообразие тональностей)"
    )
    dominant_emotion: dict[str, Any] = Field(
        default_factory=dict,
        description="Доминирующая эмоция и её целевой диапазон (свободная схема)",
    )
    f_score_formality: StyleTargetRange = Field(
        ...,
        description=(
            "Тональная оценка формальности (Heylighen & Dewaele 2002). "
            "Совпадает с MorphologicalTargets.f_score_formality по значению, "
            "но используется как тональный критерий."
        ),
    )
    irony_markers_density: StyleTargetRange = Field(
        ..., description="Плотность потенциальных маркеров иронии"
    )


class KazakhSpecificTargets(BaseModel):
    """Стилометрические цели для казахского языка (агглютинативная морфология).

    Используются ТОЛЬКО когда lang='kk'.  Для русского – None.
    Версия: v0.3.2 (12 полей, дублирующий вариант удалён).
    """

    agglutination_index: StyleTargetRange = Field(
        ..., description="Средний коэффициент агглютинации (длина_токена / длина_леммы)"
    )
    stem_ttr: StyleTargetRange = Field(
        ..., description="TTR по стеммированным формам (корневое разнообразие)"
    )
    borrowing_ratio_kk: StyleTargetRange = Field(
        ..., description="Доля заимствований (слова без KZ-специфичных символов)"
    )
    postposition_ratio: StyleTargetRange = Field(
        ..., description="Доля послелогов относительно всех токенов"
    )
    evidential_density: StyleTargetRange = Field(
        ..., description="Плотность эвиденциальных маркеров казахского языка"
    )
    modal_particle_density: StyleTargetRange = Field(
        ..., description="Плотность модальных частиц (ғой, шығар, қой)"
    )
    vowel_harmony_violation_rate: StyleTargetRange = Field(
        ..., description="Доля слов с нарушением закона сингармонизма"
    )
    # Опциональные расширения (v0.3.2)
    case_suffix_distribution: Optional[dict[str, StyleTargetRange]] = Field(
        default=None,
        description="Целевое распределение падежных суффиксов {падеж: диапазон}",
    )
    possessive_density: Optional[StyleTargetRange] = Field(
        default=None, description="Плотность притяжательных суффиксов"
    )
    evidential_tone_ratio: Optional[StyleTargetRange] = Field(
        default=None,
        description="Соотношение прямого и косвенного эвиденциала",
    )
    comma_after_suffix_ratio: Optional[StyleTargetRange] = Field(
        default=None,
        description="Доля запятых, следующих непосредственно за суффиксом",
    )
    converb_density: Optional[StyleTargetRange] = Field(
        default=None, description="Плотность деепричастных форм (конверб)"
    )


class StyleTargets(BaseModel):
    """Полный набор стилометрических целей для одного автора.

    Объединяет все категории метрик.  ``kazakh_specific`` заполняется
    только для авторов, пишущих на казахском языке.
    """

    lexical: LexicalTargets
    syntactic: SyntacticTargets
    morphological: MorphologicalTargets
    discourse: DiscourseTargets
    rhythmic: RhythmicTargets
    pragmatic: PragmaticTargets
    tonal: TonalTargets
    kazakh_specific: Optional[KazakhSpecificTargets] = Field(
        default=None,
        description="KZ-специфичные цели; заполняется только для lang='kk'",
    )


# ─────────────────────────────────────────────────────────────────────────────
# 3. Вспомогательные модели профиля автора
# ─────────────────────────────────────────────────────────────────────────────

class StyleRules(BaseModel):
    """Нечисловые правила стиля автора."""

    required: list[str] = Field(
        default_factory=list,
        description="Обязательные элементы (конструкции, маркеры, пунктуация)",
    )
    forbidden: list[str] = Field(
        default_factory=list,
        description="Запрещённые слова, клише или конструкции",
    )
    vocabulary_preferences: dict[str, Any] = Field(
        default_factory=dict,
        description="Предпочтения лексики: {слово: альтернатива}",
    )
    sentence_starters: list[str] = Field(
        default_factory=list,
        description="Типичные зачины предложений для этого автора",
    )


class FewShotExample(BaseModel):
    """Пример текста для few-shot промпта."""

    id: str = Field(..., description="Уникальный идентификатор примера")
    label: str = Field(..., description="Метка (например, жанр или тема)")
    text: str = Field(..., description="Полный текст примера")


class PersonaDescription(BaseModel):
    """Описание персоны AI-автора."""

    biography: str = Field(..., description="Краткая биография (для системного промпта)")
    motivation: str = Field(..., description="Мотивация и ценности автора")
    voice_description: str = Field(
        ..., description="Описание голоса: тон, стиль, характерные черты"
    )


class AntiDriftConfig(BaseModel):
    """Конфигурация защиты от стилевого дрейфа при длинных генерациях."""

    reinjection_every_n_words: int = Field(
        default=600,
        description="Инжектировать anchor-фразы каждые N слов",
    )
    anchor_phrases: list[str] = Field(
        default_factory=list,
        description="Фразы-якоря, периодически добавляемые в промпт",
    )


# ─────────────────────────────────────────────────────────────────────────────
# 4. Жанровая конфигурация
# ─────────────────────────────────────────────────────────────────────────────

class GenreStyleConfig(BaseModel):
    """Адаптивная стилометрия: каждый жанр использует свой набор метрик.

    Для коротких текстов (brief, data_to_text) метрики вроде MTLD, parse_depth,
    entity_grid будут статистически нестабильны – они исключаются из required.
    StyleValidator не штрафует за метрики, не входящие в required/optional.

    Attributes:
        min_words:                         Минимальное количество слов в жанре.
        min_words_for_required_metrics:    Если текст короче – required → optional (v0.3.1).
        max_iterations:                    Жанро-специфичный лимит итераций scoring loop.
        required_metrics:                  Метрики, обязательные для scoring (штраф за отклонение).
        optional_metrics:                  Метрики, учитываемые если текст достаточно длинный.
        disabled_metrics:                  Метрики, полностью игнорируемые для данного жанра.
        tolerance_multiplier:              Множитель для расширения диапазонов (genre-level relax).
    """

    min_words: int = Field(default=200, description="Минимальный объём текста в словах")
    min_words_for_required_metrics: int = Field(
        default=150,
        description="Порог: если слов меньше, required метрики трактуются как optional",
    )
    max_iterations: int = Field(
        default=4, description="Максимальное число итераций scoring для этого жанра"
    )
    required_metrics: list[str] = Field(
        default_factory=lambda: [
            "ttr_lemma",
            "avg_word_length_chars",
            "avg_sent_len_words",
            "noun_ratio",
            "verb_ratio",
            "f_score_formality",
            "hedging_density",
            "mean_sentiment",
        ],
        description="Метрики, обязательные для scoring (штраф за отклонение)",
    )
    optional_metrics: list[str] = Field(
        default_factory=list,
        description="Метрики, учитываемые только при достаточной длине текста",
    )
    disabled_metrics: list[str] = Field(
        default_factory=list,
        description="Метрики, полностью игнорируемые для данного жанра",
    )
    tolerance_multiplier: float = Field(
        default=1.0,
        ge=0.5,
        le=3.0,
        description="Множитель расширения диапазонов StyleTargetRange для этого жанра",
    )


# Предустановленные конфиги для стандартных жанров
GENRE_STYLE_CONFIGS: dict[str, GenreStyleConfig] = {
    "analysis": GenreStyleConfig(
        min_words=400,
        max_iterations=4,
        required_metrics=[
            "ttr_lemma",
            "mtld",
            "avg_word_length_chars",
            "avg_sent_len_words",
            "noun_ratio",
            "verb_ratio",
            "f_score_formality",
            "passive_ratio",
            "hedging_density",
            "mean_sentiment",
            "avg_paragraph_len_words",
            "connector_causal_density",
            "connector_adversative_density",
            "topic_coherence_avg",
            "particip_density",
            "gerund_density",
        ],
        optional_metrics=[
            "yule_k",
            "hapax_rate",
            "parse_depth_avg",
            "entity_grid_density",
            "sent_rhythm_index",
            "argument_marker_density",
        ],
        tolerance_multiplier=1.0,
    ),
    "news": GenreStyleConfig(
        min_words=200,
        max_iterations=3,
        required_metrics=[
            "ttr_lemma",
            "avg_sent_len_words",
            "noun_ratio",
            "verb_ratio",
            "f_score_formality",
            "mean_sentiment",
            "number_density",
        ],
        optional_metrics=["passive_ratio", "avg_paragraph_len_words"],
        disabled_metrics=["mtld", "yule_k", "parse_depth_avg", "entity_grid_density"],
        tolerance_multiplier=1.2,
    ),
    "brief": GenreStyleConfig(
        min_words=100,
        max_iterations=2,
        required_metrics=[
            "ttr_lemma",
            "avg_word_length_chars",
            "noun_ratio",
            "f_score_formality",
            "mean_sentiment",
        ],
        disabled_metrics=[
            "mtld",
            "yule_k",
            "parse_depth_avg",
            "entity_grid_density",
            "topic_coherence_avg",
            "avg_paragraph_len_words",
            "sd_paragraph_len",
            "sent_rhythm_index",
            "argument_marker_density",
        ],
        tolerance_multiplier=1.5,
    ),
    "data_to_text": GenreStyleConfig(
        min_words=100,
        max_iterations=2,
        required_metrics=[
            "ttr_lemma",
            "avg_sent_len_words",
            "noun_ratio",
            "number_density",
            "f_score_formality",
        ],
        disabled_metrics=[
            "mtld",
            "yule_k",
            "parse_depth_avg",
            "entity_grid_density",
            "topic_coherence_avg",
            "hedging_density",
            "argument_marker_density",
        ],
        tolerance_multiplier=1.4,
    ),
    "commentary": GenreStyleConfig(
        min_words=300,
        max_iterations=3,
        required_metrics=[
            "ttr_lemma",
            "avg_sent_len_words",
            "noun_ratio",
            "verb_ratio",
            "f_score_formality",
            "hedging_density",
            "mean_sentiment",
            "avg_paragraph_len_words",
            "boosting_density",
        ],
        optional_metrics=["mtld", "passive_ratio", "argument_marker_density"],
        tolerance_multiplier=1.1,
    ),
}


# ─────────────────────────────────────────────────────────────────────────────
# 5. Пороги и метаданные
# ─────────────────────────────────────────────────────────────────────────────

class ThresholdConfig(BaseModel):
    """Пороговые значения для публикации и перехода в HITL."""

    style_accuracy: float = Field(default=0.80, ge=0.0, le=1.0)
    content_preservation: float = Field(default=0.90, ge=0.0, le=1.0)
    factual_accuracy: float = Field(default=0.95, ge=0.0, le=1.0)
    persona_consistency: float = Field(default=0.78, ge=0.0, le=1.0)
    fluency: float = Field(default=0.85, ge=0.0, le=1.0)
    overall_publish_threshold: float = Field(default=0.82, ge=0.0, le=1.0)
    max_hallucination_rate: float = Field(
        default=0.05,
        ge=0.0,
        le=1.0,
        description="Максимальная допустимая доля непроверяемых утверждений",
    )


class AuthorMetadata(BaseModel):
    """Вспомогательные метаданные об авторе (не влияют на генерацию)."""

    organization: str = Field(default="", description="Организация или редакция")
    contact_email: str = Field(default="", description="Контактный email")
    tags: list[str] = Field(default_factory=list, description="Произвольные теги")
    notes: str = Field(default="", description="Примечания для операторов")


# ─────────────────────────────────────────────────────────────────────────────
# 6. Профиль автора
# ─────────────────────────────────────────────────────────────────────────────

class AuthorProfile(BaseModel):
    """Полный профиль AI-автора.

    Центральная модель модуля.  Хранится в PostgreSQL JSONB и загружается
    через AuthorManager.  Содержит все параметры, необходимые для генерации,
    scoring и anti-drift.
    """

    model_config = ConfigDict(json_encoders={datetime: str})

    # Идентификация
    author_id: str = Field(..., description="Уникальный идентификатор (slug)")
    name: str = Field(..., description="Человекочитаемое имя автора")
    version: str = Field(default="1.0", description="Версия профиля")
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    # Персона
    persona: PersonaDescription = Field(..., description="Биография и голос автора")

    # Область применения
    domain_scope: list[str] = Field(
        ..., description="Тематические домены (экономика, политика, …)"
    )
    genre_scope: list[str] = Field(
        ..., description="Жанры, которые покрывает автор"
    )
    languages: list[str] = Field(..., description="Поддерживаемые языки (ru/kk/en)")
    primary_language: str = Field(default="ru", description="Основной язык автора")
    target_audience: str = Field(
        default="general",
        description="Целевая аудитория (general / expert / official)",
    )

    # Стилометрия
    style_targets: StyleTargets = Field(..., description="Целевые стилометрические диапазоны")
    style_rules: StyleRules = Field(..., description="Нечисловые правила стиля")

    # Примеры и промпт
    few_shot_examples: list[FewShotExample] = Field(
        default_factory=list,
        description="Примеры текстов для few-shot (максимум 5)",
    )
    system_prompt_template: str = Field(
        ..., description="Jinja2-шаблон системного промпта"
    )

    # Scoring и пороги
    thresholds: ThresholdConfig = Field(
        default_factory=ThresholdConfig,
        description="Пороги публикации и HITL",
    )
    max_iterations: int = Field(
        default=4,
        description="Глобальный лимит итераций scoring loop",
    )
    anti_drift: AntiDriftConfig = Field(
        default_factory=AntiDriftConfig,
        description="Конфигурация защиты от стилевого дрейфа",
    )

    # Веса категорий
    style_category_weights: dict[str, float] = Field(
        default_factory=lambda: {
            "lexical": 0.20,
            "syntactic": 0.20,
            "morphological": 0.15,
            "discourse": 0.15,
            "rhythmic": 0.10,
            "pragmatic": 0.10,
            "tonal": 0.10,
        },
        description="Веса категорий для StyleValidator (7 категорий стилометрии)",
    )
    scoring_dimension_weights: dict[str, float] = Field(
        default_factory=lambda: {
            "style_accuracy": 0.30,
            "persona_consistency": 0.25,
            "factual_accuracy": 0.25,
            "content_preservation": 0.10,
            "fluency": 0.10,
        },
        description="Веса измерений для ScoringLoop (5 комбинированных измерений)",
    )

    # Жанровые конфиги
    genre_configs: dict[str, GenreStyleConfig] = Field(
        default_factory=lambda: GENRE_STYLE_CONFIGS,
        description="Жанро-специфичные наборы метрик; ключ = task_type",
    )

    # Embedding
    style_embedding: Optional[list[float]] = Field(
        default=None,
        description="Стилометрический эмбеддинг 1024-dim (QazCompute)",
    )

    # Состояние
    is_active: bool = Field(default=True, description="Активен ли профиль")
    metadata: AuthorMetadata = Field(
        default_factory=AuthorMetadata,
        description="Вспомогательные метаданные (не влияют на генерацию)",
    )


# ─────────────────────────────────────────────────────────────────────────────
# 7. Вычисленный стилометрический профиль текста
# ─────────────────────────────────────────────────────────────────────────────

class StyleProfile(BaseModel):
    """Вычисленные стилометрические метрики для конкретного текста.

    Все основные поля обязательны (float).  Метрики, которые не могут быть
    вычислены (короткий текст, отсутствие pymorphy3), должны получить
    семантически нейтральное значение: 0.0 для долей, 50.0 для f_score.

    KZ-специфичные поля заполняются только при lang='kk'.
    """

    # ── Лексические ──────────────────────────────────────────────────────────
    ttr_lemma: float = Field(..., description="Type-Token Ratio по леммам")
    mtld: float = Field(..., description="MTLD (McCarthy & Jarvis 2010)")
    hapax_rate: float = Field(..., description="Доля hapax legomena")
    yule_k: float = Field(..., description="Yule's K")
    avg_word_length_chars: float = Field(..., description="Средняя длина слова (симв.)")
    short_word_ratio: float = Field(..., description="Доля слов ≤4 символа")
    func_word_ratio: float = Field(..., description="Доля служебных слов")
    content_word_ratio: float = Field(..., description="Доля знаменательных слов")

    # ── Синтаксические ───────────────────────────────────────────────────────
    avg_sent_len_words: float = Field(..., description="Средняя длина предложения (слова)")
    sd_sent_len: float = Field(..., description="СО длины предложений")
    passive_ratio: float = Field(..., description="Доля пассивных конструкций")
    question_ratio: float = Field(..., description="Доля вопросительных предложений")
    exclamation_ratio: float = Field(..., description="Доля восклицательных предложений")

    # ── Морфологические ──────────────────────────────────────────────────────
    noun_ratio: float = Field(..., description="Доля существительных")
    verb_ratio: float = Field(..., description="Доля глаголов")
    adj_density: float = Field(..., description="Плотность прилагательных")
    adv_density: float = Field(..., description="Плотность наречий")
    pron_ratio: float = Field(..., description="Доля местоимений")
    f_score_formality: float = Field(
        ..., description="F-score формальности (Heylighen & Dewaele 2002)"
    )
    particip_density: float = Field(..., description="Плотность причастий")
    gerund_density: float = Field(..., description="Плотность деепричастий")
    perf_verb_ratio: float = Field(..., description="Доля глаголов совершенного вида")
    case_genitiv_ratio: float = Field(
        ..., description="Доля существительных в родительном падеже"
    )

    # ── Дискурсивные ─────────────────────────────────────────────────────────
    avg_paragraph_len_words: float = Field(..., description="Средняя длина абзаца (слова)")
    connector_additive_density: float = Field(..., description="Плотность аддитивных коннекторов")
    connector_adversative_density: float = Field(..., description="Плотность адверсативных коннекторов")
    connector_causal_density: float = Field(..., description="Плотность каузальных коннекторов")
    topic_coherence_avg: float = Field(..., description="Средняя тематическая когезия (Jaccard)")

    # ── Ритмические ──────────────────────────────────────────────────────────
    comma_per_1k: float = Field(..., description="Запятых на 1000 слов")
    dash_per_1k: float = Field(..., description="Тире на 1000 слов")
    sent_rhythm_index: float = Field(
        ..., description="Ритмический индекс (СО / среднее длин предложений)"
    )

    # ── Прагматические ───────────────────────────────────────────────────────
    hedging_density: float = Field(..., description="Плотность хеджинговых маркеров")
    epistemic_ratio: float = Field(..., description="Доля эпистемической модальности")
    deontic_ratio: float = Field(..., description="Доля деонтической модальности")
    boosting_density: float = Field(..., description="Плотность усилителей")

    # ── Тональные ────────────────────────────────────────────────────────────
    mean_sentiment: float = Field(
        ..., description="Средний сентимент (-1.0 … 1.0)"
    )
    sentiment_variance: float = Field(..., description="Дисперсия сентимента")

    # ── Метаданные ───────────────────────────────────────────────────────────
    word_count: int = Field(..., description="Количество слов в тексте")
    sentence_count: int = Field(..., description="Количество предложений")
    paragraph_count: int = Field(..., description="Количество абзацев")
    lang: str = Field(default="ru", description="Язык текста (ru/kk/en)")

    # ── KZ-специфичные (заполняются только при lang='kk') ────────────────────
    agglutination_index: Optional[float] = Field(
        default=None, description="Индекс агглютинации (KZ)"
    )
    stem_ttr: Optional[float] = Field(
        default=None, description="TTR по корням (KZ)"
    )
    borrowing_ratio_kk: Optional[float] = Field(
        default=None, description="Доля заимствований (KZ)"
    )
    postposition_ratio: Optional[float] = Field(
        default=None, description="Доля послелогов (KZ)"
    )
    evidential_density: Optional[float] = Field(
        default=None, description="Плотность эвиденциалов (KZ)"
    )
    modal_particle_density: Optional[float] = Field(
        default=None, description="Плотность модальных частиц (KZ)"
    )
    vowel_harmony_violation_rate: Optional[float] = Field(
        default=None, description="Доля нарушений сингармонизма (KZ)"
    )
    case_suffix_distribution: Optional[dict[str, float]] = Field(
        default=None, description="Распределение падежных суффиксов (KZ)"
    )
    possessive_density: Optional[float] = Field(
        default=None, description="Плотность притяжательных суффиксов (KZ)"
    )
    evidential_tone_ratio: Optional[float] = Field(
        default=None, description="Соотношение эвиденциальных тонов (KZ)"
    )
    comma_after_suffix_ratio: Optional[float] = Field(
        default=None, description="Доля запятых после суффиксов (KZ)"
    )
    converb_density: Optional[float] = Field(
        default=None, description="Плотность конвербов / деепричастий (KZ)"
    )

    computed_at: datetime = Field(default_factory=datetime.utcnow)


# ─────────────────────────────────────────────────────────────────────────────
# 8. Задание на генерацию
# ─────────────────────────────────────────────────────────────────────────────

class GenerationTask(BaseModel):
    """Задание на генерацию материала.

    Передаётся в Orchestrator.run() и хранится в БД для трассировки.
    """

    task_id: Optional[str] = Field(default=None, description="UUID задания (заполняется при сохранении)")
    author_id: str = Field(..., description="ID профиля автора")
    brief: str = Field(..., description="Редакционное задание (тема, угол, ключевые факты)")
    task_type: str = Field(
        default="analysis",
        description="Жанр: analysis | news | commentary | review | brief | data_to_text",
    )
    lang: str = Field(default="ru", description="Целевой язык материала")
    target_word_count: int = Field(
        default=600, ge=50, description="Целевой объём в словах"
    )
    research_query: Optional[str] = Field(
        default=None, description="Запрос для ResearchBank (если отличается от brief)"
    )
    research_date_from: Optional[str] = Field(
        default=None, description="Начало периода поиска (ISO date)"
    )
    research_date_to: Optional[str] = Field(
        default=None, description="Конец периода поиска (ISO date)"
    )
    input_data: Optional[dict[str, Any]] = Field(
        default=None, description="Данные для D2T пайплайна (таблицы, цифры)"
    )
    parent_task_id: Optional[str] = Field(
        default=None, description="ID родительского задания (для цепочек и revision sub-tasks)"
    )
    priority: int = Field(default=5, ge=1, le=10, description="Приоритет задания (1=высший)")
    created_at: datetime = Field(default_factory=datetime.utcnow)


# ─────────────────────────────────────────────────────────────────────────────
# 9. Результаты scoring
# ─────────────────────────────────────────────────────────────────────────────

class ScoringDimension(BaseModel):
    """Детализация одного измерения в scoring loop."""

    name: str = Field(..., description="Название измерения")
    score: float = Field(..., ge=0.0, le=1.0, description="Score 0–1")
    weight: float = Field(..., ge=0.0, le=1.0, description="Вес в итоговом score")
    details: dict[str, Any] = Field(
        default_factory=dict, description="Детализация по метрикам внутри измерения"
    )
    feedback: str = Field(default="", description="Конкретный feedback по измерению (RU)")


class ScoringResult(BaseModel):
    """Результат scoring loop для одного черновика."""

    draft_id: str = Field(..., description="ID черновика")
    iteration: int = Field(..., ge=1, description="Номер итерации")
    scores: dict[str, float] = Field(
        ..., description="Scores по измерениям (dimension → score 0.0–1.0)"
    )
    overall_score: float = Field(..., ge=0.0, le=1.0, description="Итоговый взвешенный score")
    passes_threshold: bool = Field(..., description="Прошёл ли порог публикации")
    feedback: str = Field(..., description="Конкретные инструкции для автора (RU)")
    style_metrics: Optional[StyleProfile] = Field(
        default=None, description="Вычисленный стилометрический профиль черновика"
    )
    dimension_details: dict[str, dict[str, Any]] = Field(
        default_factory=dict,
        description="Детализация по каждому измерению",
    )
    scored_at: datetime = Field(default_factory=datetime.utcnow)


# ─────────────────────────────────────────────────────────────────────────────
# 10. Провенанс и результат генерации
# ─────────────────────────────────────────────────────────────────────────────

class Evidence(BaseModel):
    """Единица доказательства (провенанс одного утверждения).

    Используется в ProvenanceBundle для трассировки фактов
    до источника.  Раздел 3.3 Blueprint.
    """

    claim: str = Field(..., description="Дословное утверждение из текста")
    source_id: str = Field(..., description="ID источника из ResearchBank")
    source_url: str = Field(default="", description="URL источника")
    source_title: str = Field(default="", description="Заголовок источника")
    excerpt: str = Field(default="", description="Цитата из источника, подтверждающая утверждение")
    confidence: float = Field(
        default=1.0, ge=0.0, le=1.0,
        description="Уверенность в корректности привязки (0–1)",
    )
    is_verified: bool = Field(
        default=False, description="Подтверждено ли утверждение редактором (HITL)"
    )


class ProvenanceBundle(BaseModel):
    """Полный пакет провенанса для одного черновика.

    Раздел 3.3: Editorial Truth & Provenance Model.
    Хранится вместе с GenerationResult для аудита.
    """

    draft_id: str = Field(..., description="ID черновика")
    evidences: list[Evidence] = Field(
        default_factory=list,
        description="Список привязок утверждений к источникам",
    )
    hallucination_rate: float = Field(
        default=0.0,
        ge=0.0,
        le=1.0,
        description="Доля утверждений без провенанса (потенциальные галлюцинации)",
    )
    total_claims: int = Field(default=0, description="Общее число утверждений в черновике")
    unverified_claims: int = Field(
        default=0, description="Число утверждений без источника"
    )
    created_at: datetime = Field(default_factory=datetime.utcnow)


class GenerationResult(BaseModel):
    """Финальный результат генерации после всех итераций scoring loop."""

    task_id: str = Field(..., description="ID исходного задания")
    author_id: str = Field(..., description="ID профиля автора")
    author_name: str = Field(..., description="Имя автора")
    title: str = Field(..., description="Заголовок материала")
    content: str = Field(..., description="Финальный текст")
    lang: str = Field(..., description="Язык материала")
    word_count: int = Field(..., description="Количество слов в финальном тексте")
    iterations_used: int = Field(..., ge=1, description="Фактически использованных итераций")
    final_scores: dict[str, float] = Field(
        ..., description="Финальные scores по всем измерениям"
    )
    overall_score: float = Field(..., ge=0.0, le=1.0, description="Итоговый score")
    research_sources: list[str] = Field(
        default_factory=list, description="URLs источников, использованных при генерации"
    )
    style_metrics: Optional[StyleProfile] = Field(
        default=None, description="Финальный стилометрический профиль"
    )
    provenance: Optional[ProvenanceBundle] = Field(
        default=None, description="Пакет провенанса (привязка фактов к источникам)"
    )
    status: str = Field(
        default="pending_review",
        description="Статус: pending_review | approved | rejected | hitl",
    )
    generated_at: datetime = Field(default_factory=datetime.utcnow)
