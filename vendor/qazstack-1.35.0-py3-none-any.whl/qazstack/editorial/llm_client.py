"""
qazstack.editorial.llm_client
================================
Единый интерфейс для LLM-провайдеров: OpenAI, Anthropic, локальные модели (vLLM/llama.cpp).

Архитектура
-----------
- ``LLMResponse``     – Pydantic-модель ответа с метаданными (токены, стоимость).
- ``LLMClient``       – абстрактный базовый класс (ABC).
- ``OpenAIClient``    – реализация для OpenAI GPT-4o / GPT-4o-mini через httpx.
- ``AnthropicClient`` – реализация для Claude через httpx.
- ``LocalVLLMClient`` – реализация для vLLM/llama.cpp (OpenAI-совместимый API).
- ``LLMRouter``       – маршрутизация: дорогие модели для генерации, дешёвые для scoring.
- ``build_router_from_env()`` – фабрика роутера из переменных окружения.

Конфигурация (env vars)
-----------------------
- ``OPENAI_API_KEY``           – ключ OpenAI (обязателен для OpenAIClient).
- ``ANTHROPIC_API_KEY``        – ключ Anthropic (обязателен для AnthropicClient).
- ``EDITORIAL_LLM_BACKEND``    – провайдер генерации: ``openai`` | ``anthropic`` | ``local`` (по умолчанию ``openai``).
- ``EDITORIAL_LLM_MODEL``      – модель для генерации (по умолчанию ``gpt-4o``).
- ``EDITORIAL_SCORING_MODEL``  – модель для scoring (по умолчанию ``gpt-4o-mini``).
- ``EDITORIAL_LOCAL_URL``      – base URL для локального vLLM (по умолчанию ``http://localhost:8000/v1``).
- ``EDITORIAL_LOCAL_MODEL``    – имя локальной модели.

Стоимость
---------
``LLMResponse.cost_usd`` рассчитывается по таблице тарифов ``_MODEL_PRICING``.
Таблица обновляется вручную при изменении цен провайдеров.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
from abc import ABC, abstractmethod
from typing import Any

import httpx
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Таблица тарифов (USD за 1 000 000 токенов, input/output)
# ---------------------------------------------------------------------------

_MODEL_PRICING: dict[str, tuple[float, float]] = {
    # OpenAI
    "gpt-4o":                  (2.50,   10.00),
    "gpt-4o-2024-11-20":       (2.50,   10.00),
    "gpt-4o-mini":             (0.15,    0.60),
    "gpt-4o-mini-2024-07-18":  (0.15,    0.60),
    "gpt-4.1":                 (2.00,    8.00),
    "gpt-4.1-mini":            (0.40,    1.60),
    "o1":                      (15.00,  60.00),
    "o1-mini":                 (3.00,   12.00),
    "o3-mini":                 (1.10,    4.40),
    # Anthropic
    "claude-3-5-sonnet-20241022": (3.00, 15.00),
    "claude-sonnet-4-20250514":   (3.00, 15.00),
    "claude-3-5-haiku-20241022":  (0.80,  4.00),
    "claude-3-haiku-20240307":    (0.25,  1.25),
    "claude-opus-4-20250514":     (15.00, 75.00),
}

_FALLBACK_PRICING = (2.50, 10.00)  # fallback для неизвестных моделей

_DEFAULT_RETRY_ATTEMPTS = 3
_BASE_RETRY_DELAY = 1.0  # секунды, удваивается при каждой попытке


# ---------------------------------------------------------------------------
# LLMResponse – модель ответа
# ---------------------------------------------------------------------------


class LLMResponse(BaseModel):
    """
    Ответ LLM с метаданными для отслеживания затрат и аудита.

    Attributes:
        content: содержимое ответа модели.
        model: идентификатор модели, которая сгенерировала ответ.
        prompt_tokens: количество токенов во входном промпте.
        completion_tokens: количество токенов в ответе.
        cost_usd: расчётная стоимость запроса в USD.
        finish_reason: причина завершения генерации (``stop``, ``length``, ``content_filter``).
    """

    content: str
    model: str
    prompt_tokens: int = 0
    completion_tokens: int = 0
    cost_usd: float = Field(default=0.0, description="Расчётная стоимость запроса в USD")
    finish_reason: str = "stop"

    @property
    def total_tokens(self) -> int:
        """Суммарное количество токенов (input + output)."""
        return self.prompt_tokens + self.completion_tokens


# ---------------------------------------------------------------------------
# LLMClient – абстрактный базовый класс
# ---------------------------------------------------------------------------


class LLMClient(ABC):
    """
    Абстрактный LLM-клиент. Все провайдеры реализуют этот интерфейс.

    Обязательные методы:
    - ``generate()``         → ``str``           (упрощённый интерфейс)
    - ``generate_tracked()`` → ``LLMResponse``   (с метаданными)
    - ``generate_json()``    → ``dict``           (JSON-режим)
    """

    @abstractmethod
    async def generate(
        self,
        system: str,
        messages: list[dict[str, str]],
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> str:
        """
        Генерирует текстовый ответ.

        Args:
            system: системный промпт.
            messages: массив сообщений ``[{"role": ..., "content": ...}]``.
            temperature: температура сэмплинга (0.0–2.0).
            max_tokens: максимальный объём ответа в токенах.

        Returns:
            Строка ответа модели.
        """
        ...

    @abstractmethod
    async def generate_tracked(
        self,
        system: str,
        messages: list[dict[str, str]],
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> LLMResponse:
        """
        Генерирует ответ с полными метаданными (токены, стоимость).

        Args:
            system: системный промпт.
            messages: массив сообщений.
            temperature: температура сэмплинга.
            max_tokens: максимальный объём ответа.

        Returns:
            ``LLMResponse`` с полными метаданными.
        """
        ...

    @abstractmethod
    async def generate_json(
        self,
        system: str,
        messages: list[dict[str, str]],
        temperature: float = 0.3,
        max_tokens: int = 1024,
    ) -> dict[str, Any]:
        """
        Генерирует JSON-ответ (режим ``json_object``).

        Args:
            system: системный промпт (должен содержать инструкцию вернуть JSON).
            messages: массив сообщений.
            temperature: температура (рекомендуется 0.1–0.3 для надёжности).
            max_tokens: максимальный объём ответа.

        Returns:
            Распарсенный словарь.

        Raises:
            ValueError: если ответ не является валидным JSON.
        """
        ...


# ---------------------------------------------------------------------------
# Вспомогательная функция: расчёт стоимости
# ---------------------------------------------------------------------------


def _calculate_cost(model: str, usage: dict[str, int]) -> float:
    """
    Рассчитывает стоимость запроса в USD на основе таблицы тарифов.

    Args:
        model: идентификатор модели.
        usage: словарь ``{prompt_tokens, completion_tokens}``.

    Returns:
        Стоимость в USD.
    """
    i_rate, o_rate = _MODEL_PRICING.get(model, _FALLBACK_PRICING)
    prompt_t = usage.get("prompt_tokens", usage.get("input_tokens", 0))
    completion_t = usage.get("completion_tokens", usage.get("output_tokens", 0))
    return (prompt_t * i_rate + completion_t * o_rate) / 1_000_000


# ---------------------------------------------------------------------------
# OpenAIClient
# ---------------------------------------------------------------------------


class OpenAIClient(LLMClient):
    """
    Клиент OpenAI GPT-4o / GPT-4o-mini через httpx (без официального SDK).

    Не использует ``openai`` Python SDK для гибкости конфигурации и
    отсутствия зависимости от его версии.

    Поддерживает:
    - Retry с экспоненциальным backoff (3 попытки по умолчанию).
    - Режим ``json_object`` через ``response_format``.
    - Отслеживание токенов и расчёт стоимости.

    Args:
        api_key: ключ OpenAI API. Если не задан – читается из ``OPENAI_API_KEY``.
        model: идентификатор модели (по умолчанию ``gpt-4o``).
        base_url: базовый URL API (для прокси/совместимых провайдеров).
        retry_attempts: количество повторных попыток при ошибках 5xx/429.
        timeout: таймаут HTTP-запроса в секундах.
    """

    def __init__(
        self,
        api_key: str | None = None,
        model: str = "gpt-4o",
        base_url: str = "https://api.openai.com/v1",
        retry_attempts: int = _DEFAULT_RETRY_ATTEMPTS,
        timeout: float = 120.0,
    ) -> None:
        self._api_key = api_key or os.environ.get("OPENAI_API_KEY", "")
        if not self._api_key:
            raise ValueError("OpenAIClient: OPENAI_API_KEY не задан.")
        self._model = model
        self._base_url = base_url.rstrip("/")
        self._retry_attempts = retry_attempts
        self._timeout = timeout

    async def generate(
        self,
        system: str,
        messages: list[dict[str, str]],
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> str:
        resp = await self.generate_tracked(system, messages, temperature=temperature, max_tokens=max_tokens)
        return resp.content

    async def generate_tracked(
        self,
        system: str,
        messages: list[dict[str, str]],
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> LLMResponse:
        return await self._call(system, messages, temperature=temperature, max_tokens=max_tokens, json_mode=False)

    async def generate_json(
        self,
        system: str,
        messages: list[dict[str, str]],
        temperature: float = 0.3,
        max_tokens: int = 1024,
    ) -> dict[str, Any]:
        resp = await self._call(system, messages, temperature=temperature, max_tokens=max_tokens, json_mode=True)
        return _parse_json_response(resp.content)

    # ------------------------------------------------------------------
    # Внутренний вызов с retry
    # ------------------------------------------------------------------

    async def _call(
        self,
        system: str,
        messages: list[dict[str, str]],
        temperature: float,
        max_tokens: int,
        json_mode: bool,
    ) -> LLMResponse:
        """Выполняет запрос к OpenAI API с retry и backoff."""
        payload: dict[str, Any] = {
            "model": self._model,
            "messages": [{"role": "system", "content": system}] + messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        if json_mode:
            payload["response_format"] = {"type": "json_object"}

        last_exc: Exception | None = None
        for attempt in range(self._retry_attempts):
            try:
                async with httpx.AsyncClient(timeout=self._timeout) as client:
                    response = await client.post(
                        f"{self._base_url}/chat/completions",
                        headers={
                            "Authorization": f"Bearer {self._api_key}",
                            "Content-Type": "application/json",
                        },
                        json=payload,
                    )
                    # 429 Too Many Requests или 5xx – retry
                    if response.status_code in (429, 500, 502, 503, 504):
                        wait = _BASE_RETRY_DELAY * (2 ** attempt)
                        logger.warning(
                            "OpenAI вернул %d (попытка %d/%d), ожидание %.1f с...",
                            response.status_code, attempt + 1, self._retry_attempts, wait,
                        )
                        await asyncio.sleep(wait)
                        continue
                    response.raise_for_status()
                    data = response.json()
                    return _parse_openai_response(data, self._model)

            except httpx.TimeoutException as exc:
                wait = _BASE_RETRY_DELAY * (2 ** attempt)
                logger.warning("OpenAI timeout (попытка %d/%d), ожидание %.1f с...", attempt + 1, self._retry_attempts, wait)
                last_exc = exc
                await asyncio.sleep(wait)
            except httpx.HTTPStatusError as exc:
                # 4xx (кроме 429) – не retry
                logger.error("OpenAI HTTP ошибка: %s", exc)
                raise
            except Exception as exc:
                last_exc = exc
                wait = _BASE_RETRY_DELAY * (2 ** attempt)
                logger.warning("OpenAI неожиданная ошибка (попытка %d): %s", attempt + 1, exc)
                await asyncio.sleep(wait)

        raise RuntimeError(
            f"OpenAI: все {self._retry_attempts} попытки исчерпаны. "
            f"Последняя ошибка: {last_exc}"
        )


def _parse_openai_response(data: dict[str, Any], model: str) -> LLMResponse:
    """Парсит сырой ответ OpenAI API в LLMResponse."""
    usage = data.get("usage", {})
    choice = data["choices"][0]
    return LLMResponse(
        content=choice["message"]["content"] or "",
        model=model,
        prompt_tokens=usage.get("prompt_tokens", 0),
        completion_tokens=usage.get("completion_tokens", 0),
        cost_usd=_calculate_cost(model, usage),
        finish_reason=choice.get("finish_reason", "stop"),
    )


# ---------------------------------------------------------------------------
# AnthropicClient
# ---------------------------------------------------------------------------


class AnthropicClient(LLMClient):
    """
    Клиент Anthropic Claude (Sonnet/Haiku) через httpx.

    Поддерживает Claude 3.x и Claude Sonnet 4 / Opus 4.
    JSON-режим эмулируется через строгие инструкции в системном промпте
    (Anthropic не поддерживает ``json_object`` формат напрямую).

    Args:
        api_key: ключ Anthropic API. Если не задан – читается из ``ANTHROPIC_API_KEY``.
        model: идентификатор модели (по умолчанию ``claude-sonnet-4-20250514``).
        retry_attempts: количество повторных попыток.
        timeout: таймаут HTTP-запроса в секундах.
    """

    def __init__(
        self,
        api_key: str | None = None,
        model: str = "claude-sonnet-4-20250514",
        retry_attempts: int = _DEFAULT_RETRY_ATTEMPTS,
        timeout: float = 120.0,
    ) -> None:
        self._api_key = api_key or os.environ.get("ANTHROPIC_API_KEY", "")
        if not self._api_key:
            raise ValueError("AnthropicClient: ANTHROPIC_API_KEY не задан.")
        self._model = model
        self._retry_attempts = retry_attempts
        self._timeout = timeout

    async def generate(
        self,
        system: str,
        messages: list[dict[str, str]],
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> str:
        resp = await self.generate_tracked(system, messages, temperature=temperature, max_tokens=max_tokens)
        return resp.content

    async def generate_tracked(
        self,
        system: str,
        messages: list[dict[str, str]],
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> LLMResponse:
        return await self._call(system, messages, temperature=temperature, max_tokens=max_tokens)

    async def generate_json(
        self,
        system: str,
        messages: list[dict[str, str]],
        temperature: float = 0.3,
        max_tokens: int = 1024,
    ) -> dict[str, Any]:
        # Anthropic не поддерживает json_object – добавляем инструкцию в системный промпт
        json_system = system + "\n\nОтвечай ТОЛЬКО валидным JSON, без каких-либо пояснений вне JSON."
        resp = await self._call(json_system, messages, temperature=temperature, max_tokens=max_tokens)
        return _parse_json_response(resp.content)

    async def _call(
        self,
        system: str,
        messages: list[dict[str, str]],
        temperature: float,
        max_tokens: int,
    ) -> LLMResponse:
        payload: dict[str, Any] = {
            "model": self._model,
            "system": system,
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
        }

        last_exc: Exception | None = None
        for attempt in range(self._retry_attempts):
            try:
                async with httpx.AsyncClient(timeout=self._timeout) as client:
                    response = await client.post(
                        "https://api.anthropic.com/v1/messages",
                        headers={
                            "x-api-key": self._api_key,
                            "anthropic-version": "2023-06-01",
                            "Content-Type": "application/json",
                        },
                        json=payload,
                    )
                    if response.status_code in (429, 500, 502, 503, 529):
                        wait = _BASE_RETRY_DELAY * (2 ** attempt)
                        logger.warning(
                            "Anthropic вернул %d (попытка %d/%d), ожидание %.1f с...",
                            response.status_code, attempt + 1, self._retry_attempts, wait,
                        )
                        await asyncio.sleep(wait)
                        continue
                    response.raise_for_status()
                    data = response.json()
                    return _parse_anthropic_response(data, self._model)

            except httpx.TimeoutException as exc:
                wait = _BASE_RETRY_DELAY * (2 ** attempt)
                logger.warning("Anthropic timeout (попытка %d/%d).", attempt + 1, self._retry_attempts)
                last_exc = exc
                await asyncio.sleep(wait)
            except httpx.HTTPStatusError as exc:
                logger.error("Anthropic HTTP ошибка: %s", exc)
                raise
            except Exception as exc:
                last_exc = exc
                wait = _BASE_RETRY_DELAY * (2 ** attempt)
                logger.warning("Anthropic ошибка (попытка %d): %s", attempt + 1, exc)
                await asyncio.sleep(wait)

        raise RuntimeError(
            f"AnthropicClient: все {self._retry_attempts} попытки исчерпаны. "
            f"Последняя ошибка: {last_exc}"
        )


def _parse_anthropic_response(data: dict[str, Any], model: str) -> LLMResponse:
    """Парсит сырой ответ Anthropic Messages API в LLMResponse."""
    usage = data.get("usage", {})
    content_blocks = data.get("content", [])
    text_content = "".join(
        block.get("text", "") for block in content_blocks if block.get("type") == "text"
    )
    prompt_tokens = usage.get("input_tokens", 0)
    completion_tokens = usage.get("output_tokens", 0)
    return LLMResponse(
        content=text_content,
        model=model,
        prompt_tokens=prompt_tokens,
        completion_tokens=completion_tokens,
        cost_usd=_calculate_cost(model, {"prompt_tokens": prompt_tokens, "completion_tokens": completion_tokens}),
        finish_reason=data.get("stop_reason", "end_turn"),
    )


# ---------------------------------------------------------------------------
# LocalVLLMClient
# ---------------------------------------------------------------------------


class LocalVLLMClient(LLMClient):
    """
    Клиент для локальной модели через vLLM / llama.cpp (OpenAI-совместимый API).

    Используется как бюджетный fallback для scoring или тестирования.
    Стоимость не считается (``cost_usd = 0.0``).

    Args:
        base_url: base URL vLLM-сервера (по умолчанию ``http://localhost:8000/v1``).
        model: имя/путь к локальной модели.
        timeout: таймаут в секундах (локальные модели медленнее).
    """

    def __init__(
        self,
        base_url: str = "http://localhost:8000/v1",
        model: str = "local",
        timeout: float = 300.0,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._model = model
        self._timeout = timeout

    async def generate(
        self,
        system: str,
        messages: list[dict[str, str]],
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> str:
        resp = await self.generate_tracked(system, messages, temperature=temperature, max_tokens=max_tokens)
        return resp.content

    async def generate_tracked(
        self,
        system: str,
        messages: list[dict[str, str]],
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> LLMResponse:
        payload = {
            "model": self._model,
            "messages": [{"role": "system", "content": system}] + messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        async with httpx.AsyncClient(timeout=self._timeout) as client:
            response = await client.post(
                f"{self._base_url}/chat/completions",
                json=payload,
            )
            response.raise_for_status()
            data = response.json()
            usage = data.get("usage", {})
            choice = data["choices"][0]
            return LLMResponse(
                content=choice["message"]["content"] or "",
                model=self._model,
                prompt_tokens=usage.get("prompt_tokens", 0),
                completion_tokens=usage.get("completion_tokens", 0),
                cost_usd=0.0,  # локальная – стоимость в электричестве
                finish_reason=choice.get("finish_reason", "stop"),
            )

    async def generate_json(
        self,
        system: str,
        messages: list[dict[str, str]],
        temperature: float = 0.3,
        max_tokens: int = 1024,
    ) -> dict[str, Any]:
        json_system = system + "\n\nОтвечай ТОЛЬКО валидным JSON."
        resp = await self.generate_tracked(json_system, messages, temperature=temperature, max_tokens=max_tokens)
        return _parse_json_response(resp.content)


# ---------------------------------------------------------------------------
# LLMRouter
# ---------------------------------------------------------------------------


class LLMRouter:
    """
    Маршрутизатор LLM-клиентов.

    Паттерн LLM Routing:
    - Генерация черновика: дорогая модель (GPT-4o / Claude Sonnet) – качество важно.
    - Scoring / оценка: дешёвая модель (GPT-4o-mini / Claude Haiku) – в 20× дешевле.
    - Локальный fallback: vLLM/llama.cpp – для сред без интернета или тестирования.

    Пример::

        router = LLMRouter(
            generation_client=OpenAIClient(model="gpt-4o"),
            scoring_client=OpenAIClient(model="gpt-4o-mini"),
        )
        client = router.get_client("generation")
        result = await client.generate(system, messages)

    Args:
        generation_client: клиент для генерации контента.
        scoring_client: клиент для scoring и оценки.
        fallback_client: резервный клиент при недоступности основных.
    """

    # Допустимые значения purpose
    PURPOSES = frozenset({"generation", "scoring", "evaluation", "rewrite", "research"})

    # Маппинг purpose → атрибут клиента
    _PURPOSE_MAP: dict[str, str] = {
        "generation": "generation",
        "rewrite": "generation",
        "research": "generation",
        "scoring": "scoring",
        "evaluation": "scoring",
    }

    def __init__(
        self,
        generation_client: LLMClient,
        scoring_client: LLMClient,
        fallback_client: LLMClient | None = None,
    ) -> None:
        self.generation = generation_client
        self.scoring = scoring_client
        self.fallback = fallback_client

    def get_client(self, purpose: str) -> LLMClient:
        """
        Возвращает подходящий LLM-клиент для указанной цели.

        Args:
            purpose: цель запроса – ``"generation"``, ``"scoring"``,
                     ``"evaluation"``, ``"rewrite"``, ``"research"``.

        Returns:
            Соответствующий ``LLMClient``.

        Raises:
            ValueError: если ``purpose`` не распознан.
        """
        role = self._PURPOSE_MAP.get(purpose)
        if role is None:
            raise ValueError(
                f"LLMRouter: неизвестная цель «{purpose}». "
                f"Допустимые значения: {sorted(self.PURPOSES)}"
            )
        return getattr(self, role)

    async def generate(
        self,
        purpose: str,
        system: str,
        messages: list[dict[str, str]],
        **kwargs: Any,
    ) -> str:
        """Удобный метод: маршрутизирует и генерирует за один вызов."""
        client = self.get_client(purpose)
        try:
            return await client.generate(system, messages, **kwargs)
        except Exception as exc:
            if self.fallback is not None:
                logger.warning("LLMRouter: основной клиент (%s) упал, использую fallback. Ошибка: %s", purpose, exc)
                return await self.fallback.generate(system, messages, **kwargs)
            raise

    async def generate_tracked(
        self,
        purpose: str,
        system: str,
        messages: list[dict[str, str]],
        **kwargs: Any,
    ) -> LLMResponse:
        """Маршрутизирует и генерирует с метаданными за один вызов."""
        client = self.get_client(purpose)
        try:
            return await client.generate_tracked(system, messages, **kwargs)
        except Exception as exc:
            if self.fallback is not None:
                logger.warning("LLMRouter: основной клиент (%s) упал, использую fallback. Ошибка: %s", purpose, exc)
                return await self.fallback.generate_tracked(system, messages, **kwargs)
            raise

    async def generate_json(
        self,
        purpose: str,
        system: str,
        messages: list[dict[str, str]],
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Маршрутизирует и генерирует JSON за один вызов."""
        client = self.get_client(purpose)
        try:
            return await client.generate_json(system, messages, **kwargs)
        except Exception as exc:
            if self.fallback is not None:
                logger.warning("LLMRouter: основной клиент (%s) упал, использую fallback. Ошибка: %s", purpose, exc)
                return await self.fallback.generate_json(system, messages, **kwargs)
            raise


# ---------------------------------------------------------------------------
# Фабрика из переменных окружения
# ---------------------------------------------------------------------------


def build_router_from_env() -> LLMRouter:
    """
    Создаёт ``LLMRouter`` из переменных окружения.

    Переменные:
    - ``EDITORIAL_LLM_BACKEND``   – ``openai`` | ``anthropic`` | ``local`` (default: ``openai``)
    - ``EDITORIAL_LLM_MODEL``     – модель для генерации (default: ``gpt-4o``)
    - ``EDITORIAL_SCORING_MODEL`` – модель для scoring (default: ``gpt-4o-mini``)
    - ``OPENAI_API_KEY``           – ключ OpenAI
    - ``ANTHROPIC_API_KEY``        – ключ Anthropic
    - ``EDITORIAL_LOCAL_URL``     – URL локального vLLM
    - ``EDITORIAL_LOCAL_MODEL``   – имя локальной модели

    Returns:
        Готовый ``LLMRouter``.

    Raises:
        ValueError: если обязательные переменные не заданы.
    """
    backend = os.environ.get("EDITORIAL_LLM_BACKEND", "openai").lower()
    gen_model = os.environ.get("EDITORIAL_LLM_MODEL", "gpt-4o")
    score_model = os.environ.get("EDITORIAL_SCORING_MODEL", "gpt-4o-mini")
    local_url = os.environ.get("EDITORIAL_LOCAL_URL", "http://localhost:8000/v1")
    local_model = os.environ.get("EDITORIAL_LOCAL_MODEL", "local")

    if backend == "openai":
        generation_client: LLMClient = OpenAIClient(model=gen_model)
        scoring_client: LLMClient = OpenAIClient(model=score_model)
    elif backend == "anthropic":
        generation_client = AnthropicClient(model=gen_model)
        scoring_client = AnthropicClient(model=score_model)
    elif backend == "local":
        generation_client = LocalVLLMClient(base_url=local_url, model=gen_model)
        scoring_client = LocalVLLMClient(base_url=local_url, model=local_model)
    else:
        raise ValueError(
            f"Неизвестный EDITORIAL_LLM_BACKEND: «{backend}». "
            "Допустимые значения: openai, anthropic, local."
        )

    # Попытка создать локальный fallback, если задан URL
    fallback: LLMClient | None = None
    if backend != "local" and local_url != "http://localhost:8000/v1":
        try:
            fallback = LocalVLLMClient(base_url=local_url, model=local_model)
        except Exception:
            pass  # fallback необязателен

    logger.info(
        "LLMRouter создан: generation=%s/%s, scoring=%s/%s, fallback=%s",
        backend, gen_model, backend, score_model, "local" if fallback else "нет",
    )

    return LLMRouter(
        generation_client=generation_client,
        scoring_client=scoring_client,
        fallback_client=fallback,
    )


# ---------------------------------------------------------------------------
# Внутренние утилиты
# ---------------------------------------------------------------------------


def _parse_json_response(content: str) -> dict[str, Any]:
    """
    Парсит JSON из строки ответа LLM.

    Обрабатывает случаи, когда модель оборачивает JSON в markdown-блок
    (````json ... ````).

    Raises:
        ValueError: если JSON не может быть распарсен.
    """
    text = content.strip()
    # Убираем markdown code block, если есть
    if text.startswith("```"):
        lines = text.split("\n")
        # Убираем первую строку (```json или ```) и последнюю (```)
        inner_lines = lines[1:-1] if lines[-1].strip() == "```" else lines[1:]
        text = "\n".join(inner_lines).strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError as exc:
        raise ValueError(
            f"Ответ LLM не является валидным JSON.\n"
            f"Ошибка: {exc}\n"
            f"Содержимое (первые 500 символов): {content[:500]}"
        ) from exc
