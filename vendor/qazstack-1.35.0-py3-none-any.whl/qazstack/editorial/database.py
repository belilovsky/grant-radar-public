"""
qazstack.editorial.database
============================
SQLAlchemy 2.0 async модели для схемы editorial.

Все таблицы размещены в отдельной PostgreSQL-схеме ``editorial``
(изолирована от основных схем платформы).

Зависимости:
  - pgvector (уже установлен в QazLake)
  - sqlalchemy[asyncio] >= 2.0
  - asyncpg

Использование:
    from qazstack.editorial.database import EditorialBase, init_db, get_session_factory

    engine = create_async_engine(settings.editorial_db_url)
    await init_db(engine)
    session_factory = get_session_factory(engine)
"""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any, Optional

from sqlalchemy import (
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    SmallInteger,
    String,
    Text,
    func,
    text,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship

from .config import settings

# ─────────────────────────────────────────────────────────────────────────────
# Base – отдельный от qazstack Base (нет конфликтов)
# ─────────────────────────────────────────────────────────────────────────────


class EditorialBase(DeclarativeBase):
    """Базовый класс для всех editorial-таблиц.

    Отдельный DeclarativeBase – не пересекается с основным Base qazstack.
    """

    pass


# ─────────────────────────────────────────────────────────────────────────────
# 1. Авторы
# ─────────────────────────────────────────────────────────────────────────────


class Author(EditorialBase):
    """Профили виртуальных AI-авторов.

    Хранит полный AuthorProfile (Pydantic) в profile_json (JSONB),
    плюс плоские поля для быстрой фильтрации.
    """

    __tablename__ = "authors"
    __table_args__ = (
        Index("idx_authors_active", "is_active"),
        Index("idx_authors_domain", "domain_scope", postgresql_using="gin"),
        Index("idx_authors_lang", "languages", postgresql_using="gin"),
        {"schema": "editorial"},
    )

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, server_default=text("gen_random_uuid()")
    )
    author_id: Mapped[str] = mapped_column(String(100), unique=True, nullable=False, comment="analyst_daurenov_01")
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    domain_scope: Mapped[dict] = mapped_column(
        JSONB, nullable=False, server_default=text("'[]'::jsonb"), comment='["politics","economics"]'
    )
    genre_scope: Mapped[dict] = mapped_column(JSONB, nullable=False, server_default=text("'[]'::jsonb"))
    languages: Mapped[dict] = mapped_column(JSONB, nullable=False, server_default=text("'[\"ru\"]'::jsonb"))
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default=text("true"))
    profile_json: Mapped[dict] = mapped_column(JSONB, nullable=False, comment="Полный AuthorProfile в JSON")
    # style_embedding: vector(1024) – добавляется миграцией после CREATE EXTENSION pgvector
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now(), onupdate=func.now()
    )

    # Relationships
    tasks: Mapped[list["GenerationTaskDB"]] = relationship(
        "GenerationTaskDB",
        back_populates="author_obj",
        foreign_keys="GenerationTaskDB.author_id_fk",
    )


# ─────────────────────────────────────────────────────────────────────────────
# 2. Задания на генерацию
# ─────────────────────────────────────────────────────────────────────────────


class GenerationTaskDB(EditorialBase):
    """Задания на генерацию контента.

    Статусы: pending | researching | drafting | scoring |
             pending_review | approved | rejected | published | error
    """

    __tablename__ = "generation_tasks"
    __table_args__ = (
        Index("idx_tasks_author", "author_id"),
        Index("idx_tasks_status", "status"),
        Index("idx_tasks_created", "created_at"),
        Index("idx_tasks_priority", "priority", postgresql_ops={"priority": "DESC"}),
        {"schema": "editorial"},
    )

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, server_default=text("gen_random_uuid()")
    )
    task_id: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)
    # FK на author_id (текстовый), а не на UUID
    author_id: Mapped[str] = mapped_column(
        String(100),
        ForeignKey("editorial.authors.author_id", ondelete="RESTRICT"),
        nullable=False,
    )
    # Для relationship – дополнительный alias
    author_id_fk: Mapped[str] = mapped_column(
        String(100), ForeignKey("editorial.authors.author_id"), use_existing_column=True
    )

    brief: Mapped[str] = mapped_column(Text, nullable=False)
    task_type: Mapped[str] = mapped_column(
        String(50),
        nullable=False,
        default="analysis",
        comment="analysis | news | commentary | review | brief | data_to_text",
    )
    lang: Mapped[str] = mapped_column(String(10), nullable=False, default="ru")
    target_word_count: Mapped[int] = mapped_column(Integer, nullable=False, default=600)
    research_query: Mapped[Optional[str]] = mapped_column(Text)
    research_date_from: Mapped[Optional[str]] = mapped_column(String(20))
    research_date_to: Mapped[Optional[str]] = mapped_column(String(20))
    input_data: Mapped[Optional[dict]] = mapped_column(JSONB, comment="Данные для D2T пайплайна")
    parent_task_id: Mapped[Optional[str]] = mapped_column(
        String(100), ForeignKey("editorial.generation_tasks.task_id"), comment="для revision sub-tasks"
    )
    status: Mapped[str] = mapped_column(String(30), nullable=False, default="pending")
    priority: Mapped[int] = mapped_column(SmallInteger, nullable=False, default=5, comment="1-10")
    current_iteration: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    error_message: Mapped[Optional[str]] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now(), onupdate=func.now()
    )

    # Relationships
    author_obj: Mapped["Author"] = relationship("Author", back_populates="tasks", foreign_keys=[author_id_fk])
    drafts: Mapped[list["Draft"]] = relationship("Draft", back_populates="task_obj")
    hitl_items: Mapped[list["HITLQueueItem"]] = relationship("HITLQueueItem", back_populates="task_obj")
    publications: Mapped[list["Publication"]] = relationship("Publication", back_populates="task_obj")


# ─────────────────────────────────────────────────────────────────────────────
# 3. Черновики
# ─────────────────────────────────────────────────────────────────────────────


class Draft(EditorialBase):
    """Версии черновиков с результатами scoring.

    draft_id формируется как ``{task_id}_v{iteration}``.
    """

    __tablename__ = "drafts"
    __table_args__ = (
        Index("idx_drafts_task", "task_id"),
        Index("idx_drafts_score", "overall_score"),
        Index("idx_drafts_created", "created_at"),
        {"schema": "editorial"},
    )

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, server_default=text("gen_random_uuid()")
    )
    draft_id: Mapped[str] = mapped_column(String(150), unique=True, nullable=False, comment="task_id + _v + iteration")
    task_id: Mapped[str] = mapped_column(
        String(100), ForeignKey("editorial.generation_tasks.task_id", ondelete="CASCADE"), nullable=False
    )
    iteration: Mapped[int] = mapped_column(SmallInteger, nullable=False, default=1)
    content: Mapped[str] = mapped_column(Text, nullable=False)
    word_count: Mapped[Optional[int]] = mapped_column(Integer)
    research_context: Mapped[Optional[str]] = mapped_column(Text, comment="Контекст при генерации")
    research_sources: Mapped[Optional[dict]] = mapped_column(JSONB, server_default=text("'[]'::jsonb"))
    style_metrics: Mapped[Optional[dict]] = mapped_column(JSONB, comment="StyleProfile JSON")
    scores: Mapped[Optional[dict]] = mapped_column(JSONB, comment="dimension → score")
    overall_score: Mapped[Optional[float]] = mapped_column(Float)
    passes_threshold: Mapped[Optional[bool]] = mapped_column(Boolean)
    critic_feedback: Mapped[Optional[str]] = mapped_column(Text, comment="Инструкции для переписки")
    provenance: Mapped[Optional[dict]] = mapped_column(JSONB, comment="ProvenanceBundle")
    llm_model: Mapped[Optional[str]] = mapped_column(String(100))
    llm_cost_usd: Mapped[Optional[float]] = mapped_column(Float)
    prompt_tokens: Mapped[Optional[int]] = mapped_column(Integer)
    completion_tokens: Mapped[Optional[int]] = mapped_column(Integer)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, server_default=func.now())

    # Relationships
    task_obj: Mapped["GenerationTaskDB"] = relationship("GenerationTaskDB", back_populates="drafts")
    scoring_logs: Mapped[list["ScoringLog"]] = relationship("ScoringLog", back_populates="draft_obj")


# ─────────────────────────────────────────────────────────────────────────────
# 4. Лог scoring loop
# ─────────────────────────────────────────────────────────────────────────────


class ScoringLog(EditorialBase):
    """Полный лог всех итераций scoring loop."""

    __tablename__ = "scoring_log"
    __table_args__ = (
        Index("idx_scoring_task", "task_id"),
        Index("idx_scoring_draft", "draft_id"),
        {"schema": "editorial"},
    )

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, server_default=text("gen_random_uuid()")
    )
    draft_id: Mapped[str] = mapped_column(
        String(150), ForeignKey("editorial.drafts.draft_id", ondelete="CASCADE"), nullable=False
    )
    task_id: Mapped[str] = mapped_column(String(100), nullable=False)
    iteration: Mapped[int] = mapped_column(SmallInteger, nullable=False)
    scores: Mapped[dict] = mapped_column(JSONB, nullable=False, comment="{style_accuracy: 0.85, ...}")
    overall_score: Mapped[float] = mapped_column(Float, nullable=False)
    passes: Mapped[bool] = mapped_column(Boolean, nullable=False)
    feedback: Mapped[Optional[str]] = mapped_column(Text)
    actual_metrics: Mapped[Optional[dict]] = mapped_column(JSONB, comment="Полный StyleProfile для дрейф-трекинга")
    evaluator: Mapped[str] = mapped_column(String(30), default="combined", server_default=text("'combined'"))
    # LLM cost tracking (дублируется с drafts для удобства аналитики)
    llm_model: Mapped[Optional[str]] = mapped_column(String(100))
    prompt_tokens: Mapped[Optional[int]] = mapped_column(Integer)
    completion_tokens: Mapped[Optional[int]] = mapped_column(Integer)
    cost_usd: Mapped[Optional[float]] = mapped_column(Float)
    scored_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, server_default=func.now())

    # Relationships
    draft_obj: Mapped["Draft"] = relationship("Draft", back_populates="scoring_logs")


# ─────────────────────────────────────────────────────────────────────────────
# 5. HITL очередь
# ─────────────────────────────────────────────────────────────────────────────


class HITLQueueItem(EditorialBase):
    """Очередь материалов для проверки редактором.

    Статусы: pending | in_review | approved | revision_requested | rejected
    """

    __tablename__ = "hitl_queue"
    __table_args__ = (
        Index("idx_hitl_status", "status", "created_at"),
        Index("idx_hitl_author", "author_id"),
        Index("idx_hitl_score", "overall_score"),
        {"schema": "editorial"},
    )

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, server_default=text("gen_random_uuid()")
    )
    task_id: Mapped[str] = mapped_column(
        String(100), ForeignKey("editorial.generation_tasks.task_id", ondelete="CASCADE"), nullable=False
    )
    author_id: Mapped[str] = mapped_column(String(100), nullable=False)
    author_name: Mapped[str] = mapped_column(String(200), nullable=False)
    title: Mapped[Optional[str]] = mapped_column(String(500))
    content: Mapped[str] = mapped_column(Text, nullable=False)
    lang: Mapped[str] = mapped_column(String(10), nullable=False, default="ru")
    word_count: Mapped[Optional[int]] = mapped_column(Integer)
    iterations_used: Mapped[Optional[int]] = mapped_column(SmallInteger)
    final_scores: Mapped[Optional[dict]] = mapped_column(JSONB)
    overall_score: Mapped[Optional[float]] = mapped_column(Float)
    research_sources: Mapped[Optional[dict]] = mapped_column(JSONB, server_default=text("'[]'::jsonb"))
    status: Mapped[str] = mapped_column(String(30), nullable=False, default="pending")
    priority: Mapped[int] = mapped_column(SmallInteger, nullable=False, default=5, comment="1=highest")
    hard_gate_reason: Mapped[Optional[str]] = mapped_column(Text, comment="Причина hard gate failure")
    reviewer_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True))
    reviewer_notes: Mapped[Optional[str]] = mapped_column(Text)
    final_content: Mapped[Optional[str]] = mapped_column(Text, comment="Финальная версия после правок")
    reviewed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, server_default=func.now())

    # Relationships
    task_obj: Mapped["GenerationTaskDB"] = relationship("GenerationTaskDB", back_populates="hitl_items")


# ─────────────────────────────────────────────────────────────────────────────
# 6. Публикации
# ─────────────────────────────────────────────────────────────────────────────


class Publication(EditorialBase):
    """Архив опубликованных AI-материалов."""

    __tablename__ = "publications"
    __table_args__ = (
        Index("idx_pub_author", "author_id"),
        Index("idx_pub_published", "published_at"),
        Index("idx_pub_lang", "lang"),
        {"schema": "editorial"},
    )

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, server_default=text("gen_random_uuid()")
    )
    task_id: Mapped[str] = mapped_column(
        String(100), ForeignKey("editorial.generation_tasks.task_id", ondelete="RESTRICT"), nullable=False
    )
    draft_id: Mapped[Optional[str]] = mapped_column(String(150))
    author_id: Mapped[str] = mapped_column(String(100), nullable=False)
    author_name: Mapped[str] = mapped_column(String(200), nullable=False)
    title: Mapped[str] = mapped_column(String(500), nullable=False)
    content: Mapped[str] = mapped_column(Text, nullable=False)
    lang: Mapped[str] = mapped_column(String(10), nullable=False)
    word_count: Mapped[Optional[int]] = mapped_column(Integer)
    research_sources: Mapped[Optional[dict]] = mapped_column(JSONB, server_default=text("'[]'::jsonb"))
    final_scores: Mapped[Optional[dict]] = mapped_column(JSONB)
    overall_score: Mapped[Optional[float]] = mapped_column(Float)
    provenance: Mapped[Optional[dict]] = mapped_column(JSONB, comment="ProvenanceBundle")
    disclosure_metadata: Mapped[Optional[dict]] = mapped_column(JSONB, comment="AI disclosure (C2PA-совместимый)")
    cms_article_id: Mapped[Optional[str]] = mapped_column(String(200), comment="ID в целевом CMS")
    cms_url: Mapped[Optional[str]] = mapped_column(String(1000), comment="URL опубликованного материала")
    platform: Mapped[Optional[str]] = mapped_column(String(100), comment="total_kz | qazpolit | ...")
    published_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, server_default=func.now())

    # Relationships
    task_obj: Mapped["GenerationTaskDB"] = relationship("GenerationTaskDB", back_populates="publications")


# ─────────────────────────────────────────────────────────────────────────────
# 7. Research Cache
# ─────────────────────────────────────────────────────────────────────────────


class ResearchCache(EditorialBase):
    """Кеш результатов поиска (FTS + vector).

    TTL задаётся через expires_at. Индекс по query_hash – уникальный.
    """

    __tablename__ = "research_cache"
    __table_args__ = (
        Index("idx_rc_hash", "query_hash", unique=True),
        Index("idx_rc_expires", "expires_at"),
        {"schema": "editorial"},
    )

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, server_default=text("gen_random_uuid()")
    )
    query_hash: Mapped[str] = mapped_column(
        String(64), nullable=False, unique=True, comment="SHA-256 хеш параметров запроса"
    )
    query_text: Mapped[str] = mapped_column(String(500), nullable=False)
    results: Mapped[dict] = mapped_column(JSONB, nullable=False)
    # embedding: vector(1024) – добавляется миграцией после CREATE EXTENSION pgvector
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, server_default=func.now())
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


# ─────────────────────────────────────────────────────────────────────────────
# Engine и session factory helpers
# ─────────────────────────────────────────────────────────────────────────────


def create_editorial_engine(db_url: str | None = None) -> AsyncEngine:
    """Создать AsyncEngine для editorial БД."""
    url = db_url or settings.editorial_db_url
    return create_async_engine(
        url,
        pool_size=10,
        max_overflow=20,
        pool_pre_ping=True,
        pool_recycle=3600,
        echo=settings.editorial_debug,
    )


def get_session_factory(engine: AsyncEngine) -> async_sessionmaker:
    """Создать фабрику сессий для editorial БД."""
    return async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)


async def init_db(engine: AsyncEngine) -> None:
    """
    Инициализация БД: создание схемы и таблиц.

    Для production используйте Alembic миграции.
    Этот метод – для dev/testing.
    """
    async with engine.begin() as conn:
        # Создаём схему editorial
        await conn.execute(text("CREATE SCHEMA IF NOT EXISTS editorial"))
        # Создаём расширение pgvector (если не установлено)
        await conn.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))
        # Создаём все таблицы
        await conn.run_sync(EditorialBase.metadata.create_all)
        # Добавляем vector-колонки (не поддерживаются через Mapped напрямую)
        await _add_vector_columns(conn)
    # Создаём тригеры и materialized view
    async with engine.begin() as conn:
        await _create_triggers_and_views(conn)


async def _add_vector_columns(conn: Any) -> None:
    """Добавить vector(1024) колонки – SQLAlchemy не поддерживает их через Mapped."""
    statements = [
        """
        DO $$
        BEGIN
            IF NOT EXISTS (
                SELECT 1 FROM information_schema.columns
                WHERE table_schema = 'editorial'
                  AND table_name = 'authors'
                  AND column_name = 'style_embedding'
            ) THEN
                ALTER TABLE editorial.authors ADD COLUMN style_embedding vector(1024);
            END IF;
        END $$;
        """,
        """
        DO $$
        BEGIN
            IF NOT EXISTS (
                SELECT 1 FROM information_schema.columns
                WHERE table_schema = 'editorial'
                  AND table_name = 'research_cache'
                  AND column_name = 'embedding'
            ) THEN
                ALTER TABLE editorial.research_cache ADD COLUMN embedding vector(1024);
            END IF;
        END $$;
        """,
        # HNSW индекс на style_embedding
        """
        DO $$
        BEGIN
            IF NOT EXISTS (
                SELECT 1 FROM pg_indexes
                WHERE schemaname = 'editorial'
                  AND tablename = 'authors'
                  AND indexname = 'idx_authors_embedding'
            ) THEN
                CREATE INDEX idx_authors_embedding ON editorial.authors
                    USING hnsw (style_embedding vector_cosine_ops)
                    WITH (m = 16, ef_construction = 64);
            END IF;
        END $$;
        """,
    ]
    for stmt in statements:
        await conn.execute(text(stmt))


async def _create_triggers_and_views(conn: Any) -> None:
    """Создать тригеры updated_at и materialized view author_stats."""
    # Функция updated_at
    await conn.execute(
        text("""
        CREATE OR REPLACE FUNCTION editorial.set_updated_at()
        RETURNS TRIGGER LANGUAGE plpgsql AS $$
        BEGIN
            NEW.updated_at = NOW();
            RETURN NEW;
        END;
        $$;
    """)
    )
    # Тригеры на таблицах с updated_at
    for table in ("authors", "generation_tasks"):
        await conn.execute(
            text(f"""
            DO $$
            BEGIN
                IF NOT EXISTS (
                    SELECT 1 FROM pg_trigger
                    WHERE tgname = 'trg_{table}_updated_at'
                ) THEN
                    CREATE TRIGGER trg_{table}_updated_at
                        BEFORE UPDATE ON editorial.{table}
                        FOR EACH ROW EXECUTE FUNCTION editorial.set_updated_at();
                END IF;
            END $$;
        """)
        )
    # Materialized view author_stats
    await conn.execute(
        text("""
        CREATE MATERIALIZED VIEW IF NOT EXISTS editorial.author_stats AS
        SELECT
            a.author_id,
            a.name,
            COUNT(DISTINCT p.id)                     AS total_publications,
            AVG(p.overall_score)                     AS avg_score,
            AVG(p.word_count)                        AS avg_word_count,
            COUNT(DISTINCT t.id) FILTER (WHERE t.status = 'pending') AS pending_tasks,
            MAX(p.published_at)                      AS last_published_at
        FROM editorial.authors a
        LEFT JOIN editorial.publications p ON p.author_id = a.author_id
        LEFT JOIN editorial.generation_tasks t ON t.author_id = a.author_id
        GROUP BY a.author_id, a.name
        WITH DATA;
    """)
    )
    # Уникальный индекс на materialized view (для REFRESH CONCURRENTLY)
    await conn.execute(
        text("""
        DO $$
        BEGIN
            IF NOT EXISTS (
                SELECT 1 FROM pg_indexes
                WHERE schemaname = 'editorial'
                  AND indexname = 'idx_author_stats_unique'
            ) THEN
                CREATE UNIQUE INDEX idx_author_stats_unique ON editorial.author_stats (author_id);
            END IF;
        END $$;
    """)
    )
