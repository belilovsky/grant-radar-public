"""
qazstack.editorial – FastAPI приложение.

Стандарт платформы Belilovsky:
  - create_app() через qazstack.core (или прямой FastAPI)
  - lifespan для инициализации БД и глобальных ресурсов
  - dependency_overrides для DB сессий (тестируемость)
  - healthcheck на /health (стандартный путь для Docker HEALTHCHECK)

Порт: 8200 (следующий свободный по реестру платформы)
"""
from __future__ import annotations

import logging
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from typing import Any, Optional

import httpx
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession, async_sessionmaker

from qazstack.editorial.api import editorial_router, get_db
from qazstack.editorial.config import settings
from qazstack.editorial.database import (
    EditorialBase,
    create_editorial_engine,
    get_session_factory,
    init_db,
)

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Глобальное состояние приложения
# ─────────────────────────────────────────────────────────────────────────────

class _AppState:
    """Singleton для хранения глобальных ресурсов приложения."""

    engine: Optional[AsyncEngine] = None
    session_factory: Optional[async_sessionmaker] = None
    compute_client: Optional[httpx.AsyncClient] = None

    # Lazy-init компоненты оркестратора
    _orchestrator: Any = None


_state = _AppState()


# ─────────────────────────────────────────────────────────────────────────────
# Lifespan
# ─────────────────────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """
    Инициализация при старте, очистка при остановке.

    Startup:
      1. Создаём AsyncEngine для editorial БД.
      2. Применяем init_db() – создаёт схему + таблицы (dev/testing).
         В production используйте `alembic upgrade head`.
      3. Создаём httpx.AsyncClient для QazCompute.
      4. Переопределяем dependency get_db → реальная сессия.

    Shutdown:
      1. Закрываем httpx client.
      2. Закрываем pool SQLAlchemy.
    """
    # ── Startup ──────────────────────────────────────────────────────────────
    logger.info("Editorial API запускается | port=%s", settings.editorial_debug and "debug" or 8200)

    # 1. Engine + session factory
    _state.engine = create_editorial_engine(settings.editorial_db_url)
    _state.session_factory = get_session_factory(_state.engine)

    # 2. Инициализация схемы (dev mode)
    if settings.editorial_debug:
        try:
            await init_db(_state.engine)
            logger.info("БД editorial инициализирована (debug mode)")
        except Exception as exc:
            logger.warning("init_db пропущен (возможно, схема уже существует): %s", exc)

    # 3. QazCompute HTTP client
    _state.compute_client = httpx.AsyncClient(
        base_url=settings.editorial_qazcompute_url,
        headers={"X-API-Key": settings.editorial_qazcompute_key},
        timeout=30.0,
    )

    # 4. Переопределяем dependency: get_db → реальная сессия
    async def real_get_db() -> AsyncGenerator[AsyncSession, None]:
        async with _state.session_factory() as session:
            yield session

    app.dependency_overrides[get_db] = real_get_db

    logger.info("Editorial API готов к работе")
    yield

    # ── Shutdown ─────────────────────────────────────────────────────────────
    logger.info("Editorial API останавливается...")
    if _state.compute_client:
        await _state.compute_client.aclose()
    if _state.engine:
        await _state.engine.dispose()
    logger.info("Editorial API остановлен")


# ─────────────────────────────────────────────────────────────────────────────
# Фабрика приложения
# ─────────────────────────────────────────────────────────────────────────────

def create_app() -> FastAPI:
    """
    Создать FastAPI приложение editorial.

    Следует паттерну qazstack.core.create_app:
      - lifespan для ресурсов
      - CORS middleware
      - editorial_router с префиксом /api/editorial
      - /health на корне для Docker HEALTHCHECK
    """
    app = FastAPI(
        title="qazstack.editorial",
        description="API модуля AI-авторов: генерация редакционных материалов с контролем стиля",
        version="0.3.2",
        lifespan=lifespan,
        # В production – отключить документацию
        docs_url="/docs" if settings.editorial_debug else None,
        redoc_url="/redoc" if settings.editorial_debug else None,
    )

    # CORS (настроить под реальные домены в production)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"] if settings.editorial_debug else ["https://total.kz", "https://qazpolit.kz"],
        allow_credentials=True,
        allow_methods=["GET", "POST", "PATCH", "DELETE", "OPTIONS"],
        allow_headers=["*"],
    )

    # Editorial роутер
    app.include_router(editorial_router)

    # Стандартный healthcheck для Docker (платформенный стандарт)
    @app.get("/health", tags=["system"], summary="Healthcheck")
    async def health_root() -> dict:
        """Healthcheck для Docker HEALTHCHECK и Nginx upstream проверок."""
        return {"status": "ok", "service": "editorial"}

    return app


# ─────────────────────────────────────────────────────────────────────────────
# Точка входа
# ─────────────────────────────────────────────────────────────────────────────

app = create_app()


# ─────────────────────────────────────────────────────────────────────────────
# Helpers для фоновых задач (используются в api.py)
# ─────────────────────────────────────────────────────────────────────────────

def get_session_factory_global() -> async_sessionmaker:
    """Получить глобальную фабрику сессий (для фоновых задач из api.py)."""
    if _state.session_factory is None:
        raise RuntimeError("App не инициализирован. session_factory = None")
    return _state.session_factory


async def get_orchestrator() -> Any:
    """
    Получить (или лениво создать) EditorialOrchestrator.

    Импорт модулей делается здесь лениво, чтобы избежать circular imports
    на уровне модуля. Orchestrator создаётся один раз и кешируется в _state.
    """
    if _state._orchestrator is not None:
        return _state._orchestrator

    if _state.session_factory is None:
        raise RuntimeError("App не инициализирован. Вызовите create_app() первым.")

    from qazstack.editorial.author_manager import AuthorManager  # type: ignore[import]
    from qazstack.editorial.orchestrator import EditorialOrchestrator
    from qazstack.editorial.prompt_builder import PromptBuilder  # type: ignore[import]
    from qazstack.editorial.research_bank import ResearchBank
    from qazstack.editorial.scoring import ScoringLoop  # type: ignore[import]

    # LLM клиент
    try:
        from qazstack.editorial.llm_client import OpenAIClient  # type: ignore[import]
        llm = OpenAIClient(
            api_key=settings.openai_api_key,
            model=settings.editorial_llm_model,
        )
    except ImportError:
        logger.warning("LLMClient не найден – используем заглушку")
        llm = _MockLLMClient()

    # QazLake session factory (для ResearchBank)
    from sqlalchemy.ext.asyncio import create_async_engine
    qazlake_engine = create_async_engine(
        settings.editorial_qazlake_db_url,
        pool_size=5,
        max_overflow=10,
        pool_pre_ping=True,
    )
    qazlake_factory = async_sessionmaker(qazlake_engine, expire_on_commit=False)

    bank = ResearchBank(
        db_session_factory=qazlake_factory,
        compute_client=_state.compute_client,
    )

    _state._orchestrator = EditorialOrchestrator(
        research_bank=bank,
        prompt_builder=PromptBuilder(),
        llm_router=llm,
        scoring_loop=ScoringLoop(),
        author_manager=AuthorManager(_state.session_factory),
        db_session_factory=_state.session_factory,
    )
    return _state._orchestrator


# ─────────────────────────────────────────────────────────────────────────────
# Mock LLM (fallback если llm_client.py не установлен)
# ─────────────────────────────────────────────────────────────────────────────

class _MockLLMClient:
    """Заглушка LLM клиента для разработки без OpenAI ключа."""

    async def generate(self, system: str, messages: list[dict]) -> str:
        last_user = next((m["content"] for m in reversed(messages) if m["role"] == "user"), "")
        return f"[MOCK DRAFT] {last_user[:100]}"

    async def generate_with_meta(self, system: str, messages: list[dict]) -> tuple[str, dict]:
        content = await self.generate(system, messages)
        return content, {"prompt_tokens": 0, "completion_tokens": 0, "cost_usd": 0.0}
