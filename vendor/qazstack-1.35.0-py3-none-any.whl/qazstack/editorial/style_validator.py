"""
qazstack.editorial.style_validator
=====================================
Сравнение вычисленных стилометрических метрик с целевым профилем автора.

Основной класс ``StyleValidator`` принимает ``StyleProfile`` (фактические
метрики черновика) и ``StyleTargets`` (целевые диапазоны автора), возвращает
``ScoringResult`` с взвешенным score 0–1, конкретным feedback на русском
и детализацией по каждой категории.

Алгоритм оценки:
  1. Для каждой категории (lexical/syntactic/morphological/discourse/rhythmic/
     pragmatic/tonal) вычисляется набор попарных сравнений (metric, target_range).
  2. Каждое сравнение даёт score 0–1 через ``_in_range()``:
       - 1.0, если значение внутри [lo, hi]
       - плавно убывает до 0.0 при удалении от границы (линейный штраф)
  3. Категориальный score = среднее по метрикам категории (равные веса внутри).
  4. Итоговый score = взвешенная сумма по категориям.
  5. Метрики со значением ``None`` пропускаются без штрафа.
  6. Если передан ``genre_config``, диапазоны расширяются на
     ``tolerance_multiplier`` для жанро-специфичного послабления.

Версия: 0.3.2 (production-ready)
"""
from __future__ import annotations

from typing import Any, Optional

from .models import (
    DiscourseTargets,
    GenreStyleConfig,
    KazakhSpecificTargets,
    LexicalTargets,
    MorphologicalTargets,
    PragmaticTargets,
    RhythmicTargets,
    ScoringResult,
    StyleProfile,
    StyleTargetRange,
    StyleTargets,
    SyntacticTargets,
    ThresholdConfig,
    TonalTargets,
)


class StyleValidator:
    """Сравнивает вычисленные метрики текста с целевым профилем автора.

    Возвращает ``ScoringResult`` со score (0–1) и feedback для переписки
    с LLM-автором.

    Пример::

        validator = StyleValidator()
        result = validator.validate(
            draft_id="draft_001",
            iteration=1,
            actual=computed_profile,
            target=author.style_targets,
            thresholds=author.thresholds,
            style_category_weights=author.style_category_weights,
            genre_config=author.genre_configs.get(task.task_type),
        )
        if not result.passes_threshold:
            print(result.feedback)

    Примечание по None-значениям:
        StyleProfile содержит обязательные float-поля.  Метрики, которые
        не могут быть вычислены для короткого текста, получают значение 0.0 –
        StyleValidator учитывает их в scoring.  KZ-специфичные поля
        (Optional[float]) пропускаются, если равны None.
    """

    # Порог для генерации feedback по категории
    _FEEDBACK_THRESHOLD: float = 0.7

    # ─────────────────────────────────────────────────────────────────────────
    # Публичный API
    # ─────────────────────────────────────────────────────────────────────────

    def validate(
        self,
        draft_id: str,
        iteration: int,
        actual: StyleProfile,
        target: StyleTargets,
        thresholds: ThresholdConfig,
        style_category_weights: Optional[dict[str, float]] = None,
        genre_config: Optional[GenreStyleConfig] = None,
    ) -> ScoringResult:
        """Полная валидация черновика против профиля автора.

        Args:
            draft_id:               Идентификатор черновика.
            iteration:              Номер текущей итерации scoring loop.
            actual:                 Вычисленный ``StyleProfile`` черновика.
            target:                 ``StyleTargets`` из ``AuthorProfile``.
            thresholds:             ``ThresholdConfig`` из ``AuthorProfile``.
            style_category_weights: Веса категорий (7 ключей).  Если None –
                                    используются стандартные веса (0.20/0.20/…).
            genre_config:           Жанровый конфиг для расширения диапазонов
                                    и учёта disabled/required метрик.

        Returns:
            Заполненный ``ScoringResult``.
        """
        weights = style_category_weights or {
            "lexical": 0.20,
            "syntactic": 0.20,
            "morphological": 0.15,
            "discourse": 0.15,
            "rhythmic": 0.10,
            "pragmatic": 0.10,
            "tonal": 0.10,
        }

        # tolerance_multiplier расширяет диапазоны StyleTargetRange
        tolerance = genre_config.tolerance_multiplier if genre_config else 1.0
        # Множество отключённых метрик для данного жанра
        disabled: set[str] = set(genre_config.disabled_metrics) if genre_config else set()

        scores: dict[str, float] = {}
        details: dict[str, dict[str, Any]] = {}
        feedback_parts: list[str] = []

        # ── Лексика ──────────────────────────────────────────────────────────
        scores["lexical"], d = self._score_lexical(actual, target.lexical, tolerance, disabled)
        details["lexical"] = d
        if scores["lexical"] < self._FEEDBACK_THRESHOLD:
            fb = self._feedback_lexical(actual, target.lexical)
            if fb:
                feedback_parts.append(fb)

        # ── Синтаксис ────────────────────────────────────────────────────────
        scores["syntactic"], d = self._score_syntactic(actual, target.syntactic, tolerance, disabled)
        details["syntactic"] = d
        if scores["syntactic"] < self._FEEDBACK_THRESHOLD:
            fb = self._feedback_syntactic(actual, target.syntactic)
            if fb:
                feedback_parts.append(fb)

        # ── Морфология ───────────────────────────────────────────────────────
        scores["morphological"], d = self._score_morphological(
            actual, target.morphological, tolerance, disabled
        )
        details["morphological"] = d
        if scores["morphological"] < self._FEEDBACK_THRESHOLD:
            fb = self._feedback_morphological(actual, target.morphological)
            if fb:
                feedback_parts.append(fb)

        # ── Дискурс ──────────────────────────────────────────────────────────
        scores["discourse"], d = self._score_discourse(actual, target.discourse, tolerance, disabled)
        details["discourse"] = d
        if scores["discourse"] < self._FEEDBACK_THRESHOLD:
            fb = self._feedback_discourse(actual, target.discourse)
            if fb:
                feedback_parts.append(fb)

        # ── Ритм ─────────────────────────────────────────────────────────────
        scores["rhythmic"], d = self._score_rhythmic(actual, target.rhythmic, tolerance, disabled)
        details["rhythmic"] = d
        if scores["rhythmic"] < self._FEEDBACK_THRESHOLD:
            fb = self._feedback_rhythmic(actual, target.rhythmic)
            if fb:
                feedback_parts.append(fb)

        # ── Прагматика ───────────────────────────────────────────────────────
        scores["pragmatic"], d = self._score_pragmatic(actual, target.pragmatic, tolerance, disabled)
        details["pragmatic"] = d
        if scores["pragmatic"] < self._FEEDBACK_THRESHOLD:
            fb = self._feedback_pragmatic(actual, target.pragmatic)
            if fb:
                feedback_parts.append(fb)

        # ── Тональность ──────────────────────────────────────────────────────
        scores["tonal"], d = self._score_tonal(actual, target.tonal, tolerance, disabled)
        details["tonal"] = d
        if scores["tonal"] < self._FEEDBACK_THRESHOLD:
            fb = self._feedback_tonal(actual, target.tonal)
            if fb:
                feedback_parts.append(fb)

        # ── Казахские метрики (только если lang='kk' и цели заданы) ──────────
        if target.kazakh_specific is not None and actual.lang == "kk":
            scores["kazakh_specific"], d = self._score_kazakh_specific(
                actual, target.kazakh_specific, tolerance
            )
            details["kazakh_specific"] = d
            if scores["kazakh_specific"] < self._FEEDBACK_THRESHOLD:
                fb = self._feedback_kazakh(actual, target.kazakh_specific)
                if fb:
                    feedback_parts.append(fb)

        # ── Итоговый взвешенный score ─────────────────────────────────────────
        # Для kazakh_specific нет явного веса в style_category_weights –
        # используем fallback 1/len(scores)
        overall = 0.0
        total_weight = 0.0
        for cat, cat_score in scores.items():
            w = weights.get(cat, 1.0 / max(len(scores), 1))
            overall += cat_score * w
            total_weight += w
        # Нормализуем если total_weight != 1 (например, добавлена kazakh_specific)
        if total_weight > 0:
            overall = overall / total_weight

        passes = overall >= thresholds.overall_publish_threshold
        feedback = (
            "\n".join(p for p in feedback_parts if p)
            if feedback_parts
            else "Текст соответствует профилю автора."
        )

        return ScoringResult(
            draft_id=draft_id,
            iteration=iteration,
            scores=scores,
            overall_score=round(overall, 4),
            passes_threshold=passes,
            feedback=feedback,
            style_metrics=actual,
            dimension_details=details,
        )

    # ─────────────────────────────────────────────────────────────────────────
    # Базовый scoring-примитив
    # ─────────────────────────────────────────────────────────────────────────

    @staticmethod
    def _in_range(
        value: float,
        target_range: StyleTargetRange,
        tolerance: float = 1.0,
    ) -> float:
        """Score 0–1 для одной метрики относительно целевого диапазона.

        Алгоритм:
          - Если value ∈ [lo, hi]: score = 1.0
          - Иначе: линейный штраф, пропорциональный расстоянию от границы.
            Убывает до 0.0 на расстоянии half_width от границы.

        Args:
            value:        Фактическое значение метрики.
            target_range: ``StyleTargetRange`` с полем ``range = (lo, hi)``.
            tolerance:    Множитель расширения диапазона (из GenreStyleConfig).
        """
        lo, hi = target_range.range
        center = (lo + hi) / 2.0
        half_width = (hi - lo) / 2.0 * tolerance

        # Расширяем диапазон с учётом tolerance
        eff_lo = center - half_width
        eff_hi = center + half_width

        if eff_lo <= value <= eff_hi:
            return 1.0

        if half_width == 0:
            return 1.0 if value == center else 0.0

        distance = abs(value - center) - half_width
        return max(0.0, 1.0 - distance / half_width)

    def _score_params(
        self,
        params: dict[str, tuple[float | None, StyleTargetRange]],
        tolerance: float,
        disabled: set[str],
    ) -> tuple[float, dict[str, float]]:
        """Вычисляет средний score по набору (значение, диапазон)-пар.

        Пропускает:
          - метрики в ``disabled`` (жанр-специфичное отключение)
          - метрики со значением ``None`` (не вычислены)

        Возвращает (mean_score, detail_dict).  Если нет метрик – (1.0, {}).
        """
        metric_scores: dict[str, float] = {}
        for key, (value, target_range) in params.items():
            if key in disabled:
                continue
            if value is None:
                continue
            metric_scores[key] = self._in_range(value, target_range, tolerance)

        if not metric_scores:
            return 1.0, {}
        mean_score = sum(metric_scores.values()) / len(metric_scores)
        return mean_score, metric_scores

    # ─────────────────────────────────────────────────────────────────────────
    # Scoring по категориям
    # ─────────────────────────────────────────────────────────────────────────

    def _score_lexical(
        self,
        a: StyleProfile,
        t: LexicalTargets,
        tolerance: float,
        disabled: set[str],
    ) -> tuple[float, dict[str, float]]:
        """Лексическая категория: TTR, MTLD, hapax, длина слова и др."""
        params: dict[str, tuple[float | None, StyleTargetRange]] = {
            "ttr_lemma": (a.ttr_lemma, t.ttr_lemma),
            "mtld": (a.mtld if a.mtld > 0 else None, t.mtld),
            "hapax_rate": (a.hapax_rate, t.hapax_rate),
            "yule_k": (a.yule_k if a.yule_k > 0 else None, t.yule_k),
            "avg_word_length_chars": (a.avg_word_length_chars, t.avg_word_length_chars),
            "short_word_ratio": (a.short_word_ratio, t.short_word_ratio),
            "func_word_ratio": (a.func_word_ratio, t.func_word_ratio),
            "content_word_ratio": (a.content_word_ratio, t.content_word_ratio),
        }
        return self._score_params(params, tolerance, disabled)

    def _score_syntactic(
        self,
        a: StyleProfile,
        t: SyntacticTargets,
        tolerance: float,
        disabled: set[str],
    ) -> tuple[float, dict[str, float]]:
        """Синтаксическая категория: длина предложений, пассив, вопросы."""
        params: dict[str, tuple[float | None, StyleTargetRange]] = {
            "avg_sent_len_words": (a.avg_sent_len_words, t.avg_sent_len_words),
            "sd_sent_len": (a.sd_sent_len, t.sd_sent_len),
            "passive_ratio": (a.passive_ratio, t.passive_ratio),
            "question_ratio": (a.question_ratio, t.question_ratio),
            "exclamation_ratio": (a.exclamation_ratio, t.exclamation_ratio),
        }
        return self._score_params(params, tolerance, disabled)

    def _score_morphological(
        self,
        a: StyleProfile,
        t: MorphologicalTargets,
        tolerance: float,
        disabled: set[str],
    ) -> tuple[float, dict[str, float]]:
        """Морфологическая категория: POS-доли, формальность, вид глаголов."""
        # При lang='kk' морфологические метрики = 0.0, что вне диапазонов →
        # пропускаем их (None-guard не работает, используем специальный флаг)
        is_kk = a.lang == "kk"
        params: dict[str, tuple[float | None, StyleTargetRange]] = {
            "noun_ratio": (None if is_kk else a.noun_ratio, t.noun_ratio),
            "verb_ratio": (None if is_kk else a.verb_ratio, t.verb_ratio),
            "adj_density": (None if is_kk else a.adj_density, t.adj_density),
            "adv_density": (None if is_kk else a.adv_density, t.adv_density),
            "pron_ratio": (None if is_kk else a.pron_ratio, t.pron_ratio),
            "f_score_formality": (None if is_kk else a.f_score_formality, t.f_score_formality),
            "particip_density": (None if is_kk else a.particip_density, t.particip_density),
            "gerund_density": (None if is_kk else a.gerund_density, t.gerund_density),
            "perf_verb_ratio": (None if is_kk else a.perf_verb_ratio, t.perf_verb_ratio),
            "case_genitiv_ratio": (None if is_kk else a.case_genitiv_ratio, t.case_genitiv_ratio),
        }
        return self._score_params(params, tolerance, disabled)

    def _score_discourse(
        self,
        a: StyleProfile,
        t: DiscourseTargets,
        tolerance: float,
        disabled: set[str],
    ) -> tuple[float, dict[str, float]]:
        """Дискурсивная категория: абзацы, коннекторы, когезия."""
        params: dict[str, tuple[float | None, StyleTargetRange]] = {
            "avg_paragraph_len_words": (a.avg_paragraph_len_words, t.avg_paragraph_len_words),
            "connector_additive_density": (a.connector_additive_density, t.connector_additive_density),
            "connector_adversative_density": (
                a.connector_adversative_density, t.connector_adversative_density
            ),
            "connector_causal_density": (a.connector_causal_density, t.connector_causal_density),
            "topic_coherence_avg": (a.topic_coherence_avg, t.topic_coherence_avg),
        }
        return self._score_params(params, tolerance, disabled)

    def _score_rhythmic(
        self,
        a: StyleProfile,
        t: RhythmicTargets,
        tolerance: float,
        disabled: set[str],
    ) -> tuple[float, dict[str, float]]:
        """Ритмическая категория: пунктуация на 1k, ритмический индекс."""
        params: dict[str, tuple[float | None, StyleTargetRange]] = {
            "comma_per_1k": (a.comma_per_1k, t.comma_per_1k),
            "dash_per_1k": (a.dash_per_1k, t.dash_per_1k),
            "sent_rhythm_index": (a.sent_rhythm_index, t.sent_rhythm_index),
        }
        return self._score_params(params, tolerance, disabled)

    def _score_pragmatic(
        self,
        a: StyleProfile,
        t: PragmaticTargets,
        tolerance: float,
        disabled: set[str],
    ) -> tuple[float, dict[str, float]]:
        """Прагматическая категория: хеджинг, модальность, усилители."""
        params: dict[str, tuple[float | None, StyleTargetRange]] = {
            "hedging_density": (a.hedging_density, t.hedging_density),
            "epistemic_ratio": (a.epistemic_ratio, t.epistemic_ratio),
            "deontic_ratio": (a.deontic_ratio, t.deontic_ratio),
            "boosting_density": (a.boosting_density, t.boosting_density),
        }
        return self._score_params(params, tolerance, disabled)

    def _score_tonal(
        self,
        a: StyleProfile,
        t: TonalTargets,
        tolerance: float,
        disabled: set[str],
    ) -> tuple[float, dict[str, float]]:
        """Тональная категория: сентимент, дисперсия, формальность тона."""
        params: dict[str, tuple[float | None, StyleTargetRange]] = {
            "mean_sentiment": (a.mean_sentiment, t.mean_sentiment),
            "sentiment_variance": (a.sentiment_variance, t.sentiment_variance),
            # f_score_formality учитываем как тональный параметр (TonalTargets.f_score_formality)
            "f_score_formality_tonal": (
                None if a.lang == "kk" else a.f_score_formality,
                t.f_score_formality,
            ),
        }
        return self._score_params(params, tolerance, disabled)

    def _score_kazakh_specific(
        self,
        a: StyleProfile,
        t: KazakhSpecificTargets,
        tolerance: float,
    ) -> tuple[float, dict[str, float]]:
        """KZ-специфичная категория (только для lang='kk')."""
        params: dict[str, tuple[float | None, StyleTargetRange]] = {
            "agglutination_index": (a.agglutination_index, t.agglutination_index),
            "stem_ttr": (a.stem_ttr, t.stem_ttr),
            "borrowing_ratio_kk": (a.borrowing_ratio_kk, t.borrowing_ratio_kk),
            "postposition_ratio": (a.postposition_ratio, t.postposition_ratio),
            "evidential_density": (a.evidential_density, t.evidential_density),
            "modal_particle_density": (a.modal_particle_density, t.modal_particle_density),
            "vowel_harmony_violation_rate": (
                a.vowel_harmony_violation_rate, t.vowel_harmony_violation_rate
            ),
        }
        # Опциональные
        if t.possessive_density is not None and a.possessive_density is not None:
            params["possessive_density"] = (a.possessive_density, t.possessive_density)
        if t.converb_density is not None and a.converb_density is not None:
            params["converb_density"] = (a.converb_density, t.converb_density)

        return self._score_params(params, tolerance, set())

    # ─────────────────────────────────────────────────────────────────────────
    # Генераторы обратной связи (на русском языке)
    # ─────────────────────────────────────────────────────────────────────────

    def _feedback_lexical(self, a: StyleProfile, t: LexicalTargets) -> str:
        """Формирует конкретный feedback по лексическим метрикам."""
        parts: list[str] = []

        lo_wl, hi_wl = t.avg_word_length_chars.range
        if a.avg_word_length_chars < lo_wl:
            parts.append(
                f"Словарь слишком простой (средняя длина слова {a.avg_word_length_chars:.1f} симв., "
                f"цель {t.avg_word_length_chars.target:.1f}): "
                "используйте больше терминов и номинальных конструкций."
            )
        elif a.avg_word_length_chars > hi_wl:
            parts.append(
                f"Слишком сложный словарь (средняя длина {a.avg_word_length_chars:.1f} симв.): "
                "упростите ряд терминологических конструкций."
            )

        if a.mtld > 0 and a.mtld < t.mtld.range[0]:
            parts.append(
                f"Лексическое разнообразие низкое (MTLD={a.mtld:.0f}, "
                f"цель ≥{t.mtld.range[0]:.0f}): избегайте повторов, варьируйте синонимы."
            )

        lo_ttr, hi_ttr = t.ttr_lemma.range
        if a.ttr_lemma < lo_ttr:
            parts.append(
                f"Высокая повторяемость лемм (TTR={a.ttr_lemma:.3f}, "
                f"цель ≥{lo_ttr:.3f}): разнообразьте словарь."
            )

        if a.func_word_ratio > t.func_word_ratio.range[1]:
            parts.append(
                f"Избыток служебных слов ({a.func_word_ratio:.1%}): "
                "сократите число союзов, частиц и предлогов."
            )

        return ("ЛЕКСИКА: " + " ".join(parts)) if parts else ""

    def _feedback_syntactic(self, a: StyleProfile, t: SyntacticTargets) -> str:
        """Формирует конкретный feedback по синтаксическим метрикам."""
        parts: list[str] = []
        lo_sl, hi_sl = t.avg_sent_len_words.range

        if a.avg_sent_len_words < lo_sl:
            parts.append(
                f"Предложения слишком короткие (среднее {a.avg_sent_len_words:.0f} слов, "
                f"цель {t.avg_sent_len_words.target:.0f}): "
                "добавьте придаточные конструкции и деепричастные обороты."
            )
        elif a.avg_sent_len_words > hi_sl:
            parts.append(
                f"Предложения слишком длинные ({a.avg_sent_len_words:.0f} слов): "
                "разбейте наиболее перегруженные на два."
            )

        if a.sd_sent_len < t.sd_sent_len.range[0]:
            parts.append(
                f"Монотонная длина предложений (СО={a.sd_sent_len:.1f}): "
                "чередуйте короткие и длинные предложения для ритма."
            )

        if a.exclamation_ratio > t.exclamation_ratio.range[1]:
            parts.append(
                f"ЗАПРЕЩЕНО: уберите все восклицательные знаки "
                f"(текущий уровень {a.exclamation_ratio:.1%})."
            )

        if a.passive_ratio < t.passive_ratio.range[0]:
            parts.append(
                f"Слишком мало пассивных конструкций ({a.passive_ratio:.1%}, "
                f"цель ≥{t.passive_ratio.range[0]:.1%}): "
                "используйте безличные обороты для академического стиля."
            )
        elif a.passive_ratio > t.passive_ratio.range[1]:
            parts.append(
                f"Избыток пассивных конструкций ({a.passive_ratio:.1%}): "
                "перейдите на активный залог в части предложений."
            )

        return ("СИНТАКСИС: " + " ".join(parts)) if parts else ""

    def _feedback_morphological(self, a: StyleProfile, t: MorphologicalTargets) -> str:
        """Формирует конкретный feedback по морфологическим метрикам."""
        if a.lang == "kk":
            return ""  # KZ-морфология через отдельный _feedback_kazakh
        parts: list[str] = []

        if a.noun_ratio < t.noun_ratio.range[0]:
            parts.append(
                f"Слишком мало существительных ({a.noun_ratio:.1%}, "
                f"цель ≥{t.noun_ratio.range[0]:.1%}): "
                "переформулируйте глагольные конструкции в номинальные."
            )
        elif a.noun_ratio > t.noun_ratio.range[1]:
            parts.append(
                f"Избыток существительных ({a.noun_ratio:.1%}): "
                "добавьте динамичные глагольные предикаты."
            )

        if a.f_score_formality < t.f_score_formality.range[0]:
            parts.append(
                f"Формальность низкая (F={a.f_score_formality:.0f}, "
                f"цель ≥{t.f_score_formality.range[0]:.0f}): "
                "замените личные местоимения и разговорные глаголы "
                "на номинальные конструкции."
            )
        elif a.f_score_formality > t.f_score_formality.range[1]:
            parts.append(
                f"Чрезмерная формальность (F={a.f_score_formality:.0f}): "
                "добавьте несколько глагольных конструкций для лёгкости."
            )

        if a.particip_density < t.particip_density.range[0]:
            parts.append(
                f"Мало причастных оборотов ({a.particip_density:.2%}, "
                f"цель ≥{t.particip_density.range[0]:.2%}): "
                "используйте причастия для плотности академического текста."
            )

        if a.gerund_density < t.gerund_density.range[0]:
            parts.append(
                f"Мало деепричастных оборотов ({a.gerund_density:.2%}, "
                f"цель ≥{t.gerund_density.range[0]:.2%}): "
                "добавьте деепричастия для выражения сопутствующих действий."
            )

        return ("МОРФОЛОГИЯ: " + " ".join(parts)) if parts else ""

    def _feedback_discourse(self, a: StyleProfile, t: DiscourseTargets) -> str:
        """Формирует конкретный feedback по дискурсивным метрикам."""
        parts: list[str] = []

        if a.avg_paragraph_len_words < t.avg_paragraph_len_words.range[0]:
            parts.append(
                f"Абзацы слишком короткие (среднее {a.avg_paragraph_len_words:.0f} слов, "
                f"цель ≥{t.avg_paragraph_len_words.range[0]:.0f}): "
                "разверните аргументацию, добавьте примеры и пояснения."
            )
        elif a.avg_paragraph_len_words > t.avg_paragraph_len_words.range[1]:
            parts.append(
                f"Абзацы перегружены ({a.avg_paragraph_len_words:.0f} слов): "
                "разбейте крупные абзацы на логические части."
            )

        if a.topic_coherence_avg < t.topic_coherence_avg.range[0]:
            parts.append(
                f"Низкая тематическая когезия между абзацами "
                f"(Jaccard={a.topic_coherence_avg:.3f}): "
                "добавьте переходные фразы и коннекторы."
            )

        if a.connector_causal_density < t.connector_causal_density.range[0]:
            parts.append(
                "Недостаточно каузальных коннекторов (поэтому, следовательно, ввиду): "
                "логические связи между абзацами недостаточно явны."
            )

        if a.connector_adversative_density < t.connector_adversative_density.range[0]:
            parts.append(
                "Нет контрастирующих коннекторов (однако, тем не менее): "
                "добавьте оговорки и противопоставления для нюансированности."
            )

        return ("ДИСКУРС: " + " ".join(parts)) if parts else ""

    def _feedback_rhythmic(self, a: StyleProfile, t: RhythmicTargets) -> str:
        """Формирует конкретный feedback по ритмическим/пунктуационным метрикам."""
        parts: list[str] = []

        lo_c, hi_c = t.comma_per_1k.range
        if a.comma_per_1k < lo_c:
            parts.append(
                f"Слишком мало запятых ({a.comma_per_1k:.0f}/1К, цель ≥{lo_c:.0f}): "
                "добавьте вводные конструкции, уточнения и придаточные предложения."
            )
        elif a.comma_per_1k > hi_c:
            parts.append(
                f"Избыток запятых ({a.comma_per_1k:.0f}/1К): "
                "упростите часть сложных предложений."
            )

        if a.dash_per_1k < t.dash_per_1k.range[0]:
            parts.append(
                f"Мало тире ({a.dash_per_1k:.1f}/1К): "
                "добавьте тире для вставных конструкций и авторских пояснений."
            )

        if a.sent_rhythm_index < t.sent_rhythm_index.range[0]:
            parts.append(
                f"Монотонный ритм предложений (RI={a.sent_rhythm_index:.2f}): "
                "увеличьте вариативность длин предложений."
            )
        elif a.sent_rhythm_index > t.sent_rhythm_index.range[1]:
            parts.append(
                f"Слишком резкие перепады длин предложений (RI={a.sent_rhythm_index:.2f}): "
                "выровняйте ритмический рисунок."
            )

        return ("РИТМ: " + " ".join(parts)) if parts else ""

    def _feedback_pragmatic(self, a: StyleProfile, t: PragmaticTargets) -> str:
        """Формирует конкретный feedback по прагматическим метрикам."""
        parts: list[str] = []

        if a.hedging_density < t.hedging_density.range[0]:
            parts.append(
                "Недостаточно хеджинга: добавьте маркеры осторожности "
                "(«следует отметить», «по имеющимся данным», «по всей видимости»)."
            )
        elif a.hedging_density > t.hedging_density.range[1]:
            parts.append(
                f"Избыток хеджинга ({a.hedging_density:.4f}): "
                "слишком много оговорок снижают уверенность автора."
            )

        if a.boosting_density > t.boosting_density.range[1]:
            parts.append(
                "Слишком много усилителей (очевидно, бесспорно): "
                "замените на обоснованные утверждения."
            )

        if a.epistemic_ratio < t.epistemic_ratio.range[0]:
            parts.append(
                "Мало эпистемической модальности: добавьте «возможно», «вероятно», «может»."
            )

        return ("ПРАГМАТИКА: " + " ".join(parts)) if parts else ""

    def _feedback_tonal(self, a: StyleProfile, t: TonalTargets) -> str:
        """Формирует конкретный feedback по тональным метрикам."""
        parts: list[str] = []
        lo_s, hi_s = t.mean_sentiment.range

        if a.mean_sentiment < lo_s:
            parts.append(
                f"Тон слишком негативный (mean_sentiment={a.mean_sentiment:.3f}, "
                f"цель [{lo_s:.2f}, {hi_s:.2f}]): "
                "сбалансируйте негативные оценки конструктивными выводами."
            )
        elif a.mean_sentiment > hi_s:
            parts.append(
                f"Тон слишком оптимистичный (mean_sentiment={a.mean_sentiment:.3f}): "
                "добавьте нейтральные или осторожные формулировки."
            )

        if a.lang != "kk":
            lo_f, hi_f = t.f_score_formality.range
            if a.f_score_formality < lo_f:
                parts.append(
                    f"Формальность тона недостаточна (F={a.f_score_formality:.0f}, "
                    f"цель ≥{lo_f:.0f}): "
                    "замените разговорные слова на официальные аналоги."
                )

        return ("ТОНАЛЬНОСТЬ: " + " ".join(parts)) if parts else ""

    def _feedback_kazakh(self, a: StyleProfile, t: KazakhSpecificTargets) -> str:
        """Формирует конкретный feedback по KZ-специфичным метрикам."""
        parts: list[str] = []

        if a.borrowing_ratio_kk is not None:
            lo_b, hi_b = t.borrowing_ratio_kk.range
            if a.borrowing_ratio_kk > hi_b:
                parts.append(
                    f"Высокая доля заимствований ({a.borrowing_ratio_kk:.1%}): "
                    "используйте казахские аналоги там, где они существуют."
                )

        if a.vowel_harmony_violation_rate is not None:
            if a.vowel_harmony_violation_rate > t.vowel_harmony_violation_rate.range[1]:
                parts.append(
                    f"Нарушения сингармонизма ({a.vowel_harmony_violation_rate:.1%}): "
                    "проверьте суффиксальное согласование гласных."
                )

        if a.evidential_density is not None:
            if a.evidential_density < t.evidential_density.range[0]:
                parts.append(
                    "Мало эвиденциальных маркеров: добавьте «екен», «деректерге сәйкес» "
                    "для выражения источника информации."
                )

        if a.agglutination_index is not None:
            lo_a, hi_a = t.agglutination_index.range
            if a.agglutination_index < lo_a:
                parts.append(
                    f"Низкий индекс агглютинации ({a.agglutination_index:.2f}): "
                    "возможна чрезмерная аналитичность конструкций."
                )

        return ("КАЗАХСКИЙ: " + " ".join(parts)) if parts else ""
