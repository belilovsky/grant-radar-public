"""Configurable, deterministic editorial quality scorecards."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Mapping

_DIMENSIONS = frozenset({"title", "body", "media", "seo", "freshness"})


@dataclass(frozen=True, slots=True)
class EditorialScorePolicy:
    weights: Mapping[str, float] = field(
        default_factory=lambda: {"title": 0.2, "body": 0.3, "media": 0.2, "seo": 0.15, "freshness": 0.15}
    )
    title_min: int = 20
    title_ideal_min: int = 30
    title_max: int = 120
    body_min: int = 100
    body_ideal_min: int = 300
    stale_after_hours: int = 48
    old_after_hours: int = 168
    clickbait_terms: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not self.weights or any(weight < 0 for weight in self.weights.values()):
            raise ValueError("weights must be non-empty and non-negative")
        unknown_dimensions = set(self.weights).difference(_DIMENSIONS)
        if unknown_dimensions:
            raise ValueError(f"unknown score dimensions: {', '.join(sorted(unknown_dimensions))}")
        if abs(sum(self.weights.values()) - 1.0) > 0.0001:
            raise ValueError("weights must sum to 1")
        if not 0 <= self.title_min <= self.title_ideal_min <= self.title_max:
            raise ValueError("title thresholds must be ordered and non-negative")
        if not 0 <= self.body_min <= self.body_ideal_min:
            raise ValueError("body thresholds must be ordered and non-negative")
        if not 0 <= self.stale_after_hours <= self.old_after_hours:
            raise ValueError("freshness thresholds must be ordered and non-negative")


@dataclass(frozen=True, slots=True)
class QualityFinding:
    dimension: str
    code: str
    severity: str
    message: str
    value: int | float | str | None = None


@dataclass(frozen=True, slots=True)
class QualityDimension:
    name: str
    score: float
    findings: tuple[QualityFinding, ...] = ()


@dataclass(frozen=True, slots=True)
class EditorialScorecard:
    score: float
    dimensions: tuple[QualityDimension, ...]
    findings: tuple[QualityFinding, ...]

    def dimension(self, name: str) -> QualityDimension:
        for item in self.dimensions:
            if item.name == name:
                return item
        raise KeyError(name)


def _finding(
    dimension: str,
    code: str,
    message: str,
    value: object = None,
    severity: str = "warning",
) -> QualityFinding:
    return QualityFinding(dimension, code, severity, message, value if isinstance(value, (int, float, str)) else None)


def _publication_age_hours(value: object, now: datetime) -> float | None:
    if not value:
        return None
    try:
        parsed = value if isinstance(value, datetime) else datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except (TypeError, ValueError):
        return -1
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)
    return max(0.0, (now - parsed.astimezone(UTC)).total_seconds() / 3600)


def score_editorial_item(
    item: Mapping[str, object],
    *,
    policy: EditorialScorePolicy | None = None,
    now: datetime | None = None,
) -> EditorialScorecard:
    """Score a content item while keeping taxonomy and publication policy outside."""

    cfg = policy or EditorialScorePolicy()
    observed_at = (now or datetime.now(UTC)).astimezone(UTC)
    dimensions: list[QualityDimension] = []

    title = str(item.get("title") or "").strip()
    title_score = 100.0
    title_findings: list[QualityFinding] = []
    if not title:
        title_score = 0
        title_findings.append(_finding("title", "missing_title", "Title is missing", severity="error"))
    else:
        length = len(title)
        if length < cfg.title_min:
            title_score -= 40
            title_findings.append(_finding("title", "title_too_short", "Title is too short", length))
        elif length < cfg.title_ideal_min:
            title_score -= 15
            title_findings.append(_finding("title", "title_short", "Title is shorter than the preferred range", length))
        elif length > cfg.title_max:
            title_score -= 20
            title_findings.append(_finding("title", "title_too_long", "Title is too long", length))
        if len(title) > 10 and title == title.upper():
            title_score -= 25
            title_findings.append(_finding("title", "all_caps", "Title uses all caps"))
        matched_clickbait = next((term for term in cfg.clickbait_terms if term.casefold() in title.casefold()), None)
        if matched_clickbait:
            title_score -= 15
            title_findings.append(
                _finding(
                    "title",
                    "clickbait_term",
                    "Title contains a configured clickbait term",
                    matched_clickbait,
                )
            )
    dimensions.append(QualityDimension("title", max(0.0, title_score), tuple(title_findings)))

    body = str(item.get("body_text") or item.get("content") or "")
    body_score = 100.0
    body_findings: list[QualityFinding] = []
    if len(body) < cfg.body_min:
        body_score -= 50
        body_findings.append(_finding("body", "body_too_short", "Body is too short", len(body), "error"))
    elif len(body) < cfg.body_ideal_min:
        body_score -= 25
        body_findings.append(_finding("body", "body_short", "Body is shorter than the preferred range", len(body)))
    paragraphs = [paragraph.strip() for paragraph in body.splitlines() if paragraph.strip()]
    if len(paragraphs) < 2 and len(body) > 200:
        body_score -= 15
        body_findings.append(_finding("body", "single_paragraph", "Body has no visible paragraph structure"))
    if body.casefold().count("фото:") > 3:
        body_score -= 10
        body_findings.append(_finding("body", "repeated_photo_credit", "Body contains repeated photo credits"))
    dimensions.append(QualityDimension("body", max(0.0, body_score), tuple(body_findings)))

    image = str(item.get("main_image") or "")
    media_score = 100.0
    media_findings: list[QualityFinding] = []
    if not image:
        media_score -= 50
        media_findings.append(_finding("media", "missing_featured_image", "Featured image is missing"))
    elif any(marker in image.casefold() for marker in ("placeholder", "default")):
        media_score -= 30
        media_findings.append(_finding("media", "placeholder_image", "Featured image is a placeholder"))
    dimensions.append(QualityDimension("media", max(0.0, media_score), tuple(media_findings)))

    slug = str(item.get("url") or item.get("slug") or "")
    seo_score = 100.0
    seo_findings: list[QualityFinding] = []
    if not item.get("excerpt") and not item.get("meta_description"):
        seo_score -= 30
        seo_findings.append(_finding("seo", "missing_description", "Meta description or excerpt is missing"))
    if not slug:
        seo_score -= 20
        seo_findings.append(_finding("seo", "missing_slug", "Canonical slug is missing"))
    elif len(slug) > 150:
        seo_score -= 10
        seo_findings.append(_finding("seo", "slug_too_long", "Canonical slug is too long", len(slug)))
    if not item.get("category") and not item.get("sub_category"):
        seo_score -= 20
        seo_findings.append(_finding("seo", "missing_category", "Category is missing"))
    dimensions.append(QualityDimension("seo", max(0.0, seo_score), tuple(seo_findings)))

    freshness_score = 100.0
    freshness_findings: list[QualityFinding] = []
    age_hours = _publication_age_hours(item.get("published_at") or item.get("pub_date"), observed_at)
    if age_hours is None:
        freshness_score = 50
        freshness_findings.append(_finding("freshness", "missing_publication_date", "Publication date is missing"))
    elif age_hours < 0:
        freshness_score -= 20
        freshness_findings.append(_finding("freshness", "invalid_publication_date", "Publication date is invalid"))
    elif age_hours > cfg.old_after_hours:
        freshness_score -= 30
        freshness_findings.append(
            _finding(
                "freshness",
                "content_old",
                "Content is older than the configured window",
                round(age_hours, 1),
            )
        )
    elif age_hours > cfg.stale_after_hours:
        freshness_score -= 10
        freshness_findings.append(
            _finding(
                "freshness",
                "content_stale",
                "Content is outside the freshness target",
                round(age_hours, 1),
            )
        )
    dimensions.append(QualityDimension("freshness", max(0.0, freshness_score), tuple(freshness_findings)))

    by_name = {dimension.name: dimension for dimension in dimensions}
    total = sum(by_name[name].score * weight for name, weight in cfg.weights.items())
    findings = tuple(finding for dimension in dimensions for finding in dimension.findings)
    return EditorialScorecard(round(total, 1), tuple(dimensions), findings)
