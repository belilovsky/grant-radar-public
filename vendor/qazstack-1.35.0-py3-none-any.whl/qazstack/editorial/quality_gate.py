"""Deterministic quality-gate evaluator for CMS integrations.

This module evaluates only metadata supplied by a CMS.  It is intentionally
not an AI fact checker and it never dereferences evidence links.
"""

from __future__ import annotations

from dataclasses import dataclass

from .contracts import AiDisclosure, EditorialDecision, EditorialDecisionState, LanguageParity


@dataclass(frozen=True)
class GateFinding:
    code: str
    state: EditorialDecisionState
    message: str


@dataclass(frozen=True)
class GateEvaluation:
    computed_state: EditorialDecisionState
    findings: tuple[GateFinding, ...]

    @property
    def is_ready(self) -> bool:
        return self.computed_state is EditorialDecisionState.READY


def evaluate_quality_gate(decision: EditorialDecision) -> GateEvaluation:
    """Calculate the safest next state from explicit editorial metadata.

    ``blocked`` and ``draft`` are deliberate operator states and are preserved;
    otherwise missing evidence precedes missing review in the resulting state.
    """
    if decision.decision is EditorialDecisionState.BLOCKED:
        return GateEvaluation(EditorialDecisionState.BLOCKED, ())
    if decision.decision is EditorialDecisionState.DRAFT:
        return GateEvaluation(EditorialDecisionState.DRAFT, ())

    findings: list[GateFinding] = []
    if not decision.evidence and not decision.evidence_refs:
        findings.append(GateFinding(
            "source-evidence-missing", EditorialDecisionState.NEEDS_EVIDENCE,
            "At least one traceable evidence reference is required.",
        ))
    if decision.evidence and not any(item.capture_status == "completed" for item in decision.evidence):
        findings.append(GateFinding(
            "evidence-capture-pending", EditorialDecisionState.NEEDS_REVIEW,
            "At least one typed evidence record should include a completed capture manifest.",
        ))
    if decision.ai_disclosure is None:
        findings.append(GateFinding(
            "ai-disclosure-missing", EditorialDecisionState.NEEDS_REVIEW,
            "AI disclosure state must be explicit.",
        ))
    elif decision.ai_disclosure is AiDisclosure.REVIEW_REQUIRED:
        findings.append(GateFinding(
            "ai-disclosure-review", EditorialDecisionState.NEEDS_REVIEW,
            "AI-assisted material still requires editorial review.",
        ))
    if decision.risk_level == "P0" and not decision.reviewer_ids:
        findings.append(GateFinding(
            "p0-review-missing", EditorialDecisionState.NEEDS_REVIEW,
            "P0 material requires a recorded senior or legal reviewer.",
        ))
    if decision.language_parity is LanguageParity.PENDING:
        findings.append(GateFinding(
            "language-parity-pending", EditorialDecisionState.NEEDS_REVIEW,
            "Paired language material requires verified parity.",
        ))

    if any(item.state is EditorialDecisionState.NEEDS_EVIDENCE for item in findings):
        state = EditorialDecisionState.NEEDS_EVIDENCE
    elif findings:
        state = EditorialDecisionState.NEEDS_REVIEW
    else:
        state = EditorialDecisionState.READY
    return GateEvaluation(state, tuple(findings))
