"""
qazstack.editorial.author_manager
===================================
CRUD для профилей авторов: создание, чтение, обновление, деактивация.
Хранение в PostgreSQL (схема ``editorial``, таблица ``authors``).
Поддерживает загрузку из JSON-файла для разработки без БД.

Схема таблицы (создаётся при первом запуске через ``ensure_table``):

    CREATE TABLE IF NOT EXISTS editorial.authors (
        author_id       TEXT        PRIMARY KEY,
        name            TEXT        NOT NULL,
        domain_scope    JSONB       NOT NULL DEFAULT '[]',
        genre_scope     JSONB       NOT NULL DEFAULT '[]',
        languages       JSONB       NOT NULL DEFAULT '[]',
        is_active       BOOLEAN     NOT NULL DEFAULT TRUE,
        profile_json    JSONB       NOT NULL,
        version         TEXT        NOT NULL DEFAULT '1.0',
        style_embedding vector(1024),          -- QazCompute embedding
        created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS editorial.author_changelog (
        id          BIGSERIAL   PRIMARY KEY,
        author_id   TEXT        NOT NULL REFERENCES editorial.authors(author_id),
        changed_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        changed_by  TEXT        NOT NULL DEFAULT 'system',
        old_version TEXT,
        new_version TEXT        NOT NULL,
        diff_json   JSONB       NOT NULL DEFAULT '{}'
    );
"""
from __future__ import annotations

import json
import logging
from collections.abc import Callable
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from .models import AuthorProfile

logger = logging.getLogger(__name__)

# SQL-константы ----------------------------------------------------------

_DDL_SCHEMA = "CREATE SCHEMA IF NOT EXISTS editorial;"

_DDL_AUTHORS = """\
CREATE TABLE IF NOT EXISTS editorial.authors (
    author_id       TEXT        PRIMARY KEY,
    name            TEXT        NOT NULL,
    domain_scope    JSONB       NOT NULL DEFAULT '[]',
    genre_scope     JSONB       NOT NULL DEFAULT '[]',
    languages       JSONB       NOT NULL DEFAULT '[]',
    is_active       BOOLEAN     NOT NULL DEFAULT TRUE,
    profile_json    JSONB       NOT NULL,
    version         TEXT        NOT NULL DEFAULT '1.0',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
"""

_DDL_CHANGELOG = """\
CREATE TABLE IF NOT EXISTS editorial.author_changelog (
    id          BIGSERIAL   PRIMARY KEY,
    author_id   TEXT        NOT NULL,
    changed_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    changed_by  TEXT        NOT NULL DEFAULT 'system',
    old_version TEXT,
    new_version TEXT        NOT NULL,
    diff_json   JSONB       NOT NULL DEFAULT '{}'
);
"""

_SQL_UPSERT = """\
INSERT INTO editorial.authors
    (author_id, name, domain_scope, genre_scope, languages, is_active, profile_json, version, updated_at)
VALUES
    (:aid, :name, :domains::jsonb, :genres::jsonb, :langs::jsonb, :active, :profile_json::jsonb, :version, NOW())
ON CONFLICT (author_id) DO UPDATE
    SET name         = EXCLUDED.name,
        domain_scope = EXCLUDED.domain_scope,
        genre_scope  = EXCLUDED.genre_scope,
        languages    = EXCLUDED.languages,
        is_active    = EXCLUDED.is_active,
        profile_json = EXCLUDED.profile_json,
        version      = EXCLUDED.version,
        updated_at   = NOW();
"""

_SQL_CHANGELOG_INSERT = """\
INSERT INTO editorial.author_changelog
    (author_id, changed_by, old_version, new_version, diff_json)
VALUES
    (:aid, :changed_by, :old_version, :new_version, :diff_json::jsonb);
"""


# -----------------------------------------------------------------------
# AuthorManager
# -----------------------------------------------------------------------


class AuthorManager:
    """
    CRUD-менеджер профилей авторов.

    Принимает фабрику сессий (``Callable[[], AsyncSession]``) или
    готовую сессию ``AsyncSession``.  Рекомендуется передавать фабрику,
    чтобы каждый запрос мог управлять своей транзакцией независимо.

    Пример::

        # Через фабрику (рекомендуется)
        manager = AuthorManager(db.session_factory)
        author = await manager.get("analyst_daurenov_01")

        # Через готовую сессию (удобно в тестах)
        async with db.get_session() as session:
            manager = AuthorManager(session)
            await manager.create(profile)
    """

    def __init__(self, session_or_factory: AsyncSession | Callable[[], AsyncSession]) -> None:
        if isinstance(session_or_factory, AsyncSession):
            self._session: AsyncSession | None = session_or_factory
            self._factory: Callable[[], AsyncSession] | None = None
        else:
            self._session = None
            self._factory = session_or_factory

    # ------------------------------------------------------------------
    # Внутренние хелперы
    # ------------------------------------------------------------------

    def _get_session(self) -> AsyncSession:
        """Возвращает сессию: либо зафиксированную, либо из фабрики."""
        if self._session is not None:
            return self._session
        if self._factory is not None:
            return self._factory()
        raise RuntimeError("AuthorManager: не задана ни сессия, ни фабрика.")

    async def _execute(self, session: AsyncSession, stmt: str, params: dict[str, Any] | None = None) -> Any:
        """Выполняет SQL-запрос с текстовым биндингом."""
        return await session.execute(text(stmt), params or {})

    # ------------------------------------------------------------------
    # Инициализация схемы БД
    # ------------------------------------------------------------------

    async def ensure_tables(self) -> None:
        """
        Создаёт схему и таблицы при первом запуске (идемпотентно).
        Вызывать в lifespan FastAPI или миграционном скрипте.
        """
        session = self._get_session()
        for ddl in (_DDL_SCHEMA, _DDL_AUTHORS, _DDL_CHANGELOG):
            await self._execute(session, ddl)
        await session.commit()
        logger.info("editorial.authors: таблицы созданы или уже существуют.")

    # ------------------------------------------------------------------
    # Основные CRUD-операции
    # ------------------------------------------------------------------

    async def create(self, profile: AuthorProfile, changed_by: str = "system") -> str:
        """
        Создаёт нового автора. Если автор с таким ``author_id`` уже существует –
        обновляет профиль (upsert).

        Args:
            profile: полный профиль ``AuthorProfile``.
            changed_by: имя пользователя/сервиса для changelog.

        Returns:
            ``author_id`` созданного/обновлённого автора.
        """
        session = self._get_session()

        # Сохраняем старую версию для changelog
        old_profile = await self.get(profile.author_id)
        old_version = old_profile.version if old_profile else None

        profile_dict = profile.model_dump(mode="json")

        await self._execute(session, _SQL_UPSERT, {
            "aid": profile.author_id,
            "name": profile.name,
            "domains": json.dumps(profile.domain_scope, ensure_ascii=False),
            "genres": json.dumps(profile.genre_scope, ensure_ascii=False),
            "langs": json.dumps(profile.languages, ensure_ascii=False),
            "active": profile.is_active,
            "profile_json": json.dumps(profile_dict, ensure_ascii=False, default=str),
            "version": profile.version,
        })

        # Changelog
        diff = _compute_diff(old_profile, profile) if old_profile else {}
        await self._execute(session, _SQL_CHANGELOG_INSERT, {
            "aid": profile.author_id,
            "changed_by": changed_by,
            "old_version": old_version,
            "new_version": profile.version,
            "diff_json": json.dumps(diff, ensure_ascii=False, default=str),
        })

        await session.commit()
        logger.info("Автор %s сохранён (версия %s).", profile.author_id, profile.version)
        return profile.author_id

    async def get(self, author_id: str) -> AuthorProfile | None:
        """
        Загружает профиль автора по ``author_id``.

        Возвращает ``None``, если автор не найден или деактивирован.

        Args:
            author_id: уникальный идентификатор автора.

        Returns:
            ``AuthorProfile`` или ``None``.
        """
        session = self._get_session()
        result = await self._execute(
            session,
            "SELECT profile_json FROM editorial.authors WHERE author_id = :aid AND is_active = TRUE",
            {"aid": author_id},
        )
        row = result.fetchone()
        if row is None:
            return None
        raw = row[0]
        # PostgreSQL может вернуть JSONB как dict или str
        if isinstance(raw, str):
            return AuthorProfile.model_validate_json(raw)
        return AuthorProfile.model_validate(raw)

    async def get_any(self, author_id: str) -> AuthorProfile | None:
        """
        Загружает профиль включая деактивированных (для changelog/аудита).

        Args:
            author_id: уникальный идентификатор автора.
        """
        session = self._get_session()
        result = await self._execute(
            session,
            "SELECT profile_json FROM editorial.authors WHERE author_id = :aid",
            {"aid": author_id},
        )
        row = result.fetchone()
        if row is None:
            return None
        raw = row[0]
        if isinstance(raw, str):
            return AuthorProfile.model_validate_json(raw)
        return AuthorProfile.model_validate(raw)

    async def list_active(
        self,
        domain: str | None = None,
        lang: str | None = None,
        genre: str | None = None,
    ) -> list[AuthorProfile]:
        """
        Возвращает список активных авторов с опциональной фильтрацией.

        Args:
            domain: фильтр по доменной области (например, ``"economics"``).
            lang: фильтр по языку (``"ru"``, ``"kk"``, ``"en"``).
            genre: фильтр по поддерживаемому жанру (``"analysis"``, ``"news"`` и т.д.).

        Returns:
            Список ``AuthorProfile``.
        """
        session = self._get_session()
        conditions = ["is_active = TRUE"]
        params: dict[str, Any] = {}

        if domain:
            conditions.append("domain_scope @> :domain::jsonb")
            params["domain"] = json.dumps([domain])

        if lang:
            conditions.append("languages @> :lang::jsonb")
            params["lang"] = json.dumps([lang])

        if genre:
            conditions.append("genre_scope @> :genre::jsonb")
            params["genre"] = json.dumps([genre])

        where = " AND ".join(conditions)
        result = await self._execute(
            session,
            f"SELECT profile_json FROM editorial.authors WHERE {where} ORDER BY name",
            params,
        )
        rows = result.fetchall()
        profiles: list[AuthorProfile] = []
        for row in rows:
            raw = row[0]
            try:
                if isinstance(raw, str):
                    profiles.append(AuthorProfile.model_validate_json(raw))
                else:
                    profiles.append(AuthorProfile.model_validate(raw))
            except Exception as exc:
                logger.warning("Не удалось десериализовать профиль: %s", exc)
        return profiles

    async def update(
        self,
        author_id: str,
        updates: dict[str, Any],
        changed_by: str = "system",
    ) -> AuthorProfile:
        """
        Применяет частичное обновление к существующему профилю.

        Допустимые ключи в ``updates``: любые поля ``AuthorProfile``.
        ``author_id`` и ``created_at`` игнорируются (защита от перезаписи).

        Args:
            author_id: идентификатор автора.
            updates: словарь обновлённых полей.
            changed_by: имя пользователя/сервиса.

        Returns:
            Обновлённый ``AuthorProfile``.

        Raises:
            ValueError: если автор не найден.
        """
        current = await self.get(author_id)
        if current is None:
            raise ValueError(f"Автор «{author_id}» не найден или деактивирован.")

        # Защита: запрещаем менять author_id и created_at напрямую
        updates.pop("author_id", None)
        updates.pop("created_at", None)

        # Применяем обновление через Pydantic model_copy
        updates["updated_at"] = datetime.now(tz=timezone.utc)
        updated = current.model_copy(update=updates)

        await self.create(updated, changed_by=changed_by)
        return updated

    async def deactivate(self, author_id: str, changed_by: str = "system") -> None:
        """
        Мягко деактивирует автора (``is_active = FALSE``).

        Автор остаётся в БД, его профиль доступен через ``get_any()``.

        Args:
            author_id: идентификатор автора.
            changed_by: имя пользователя/сервиса.

        Raises:
            ValueError: если автор не найден.
        """
        session = self._get_session()
        result = await self._execute(
            session,
            "SELECT version FROM editorial.authors WHERE author_id = :aid",
            {"aid": author_id},
        )
        row = result.fetchone()
        if row is None:
            raise ValueError(f"Автор «{author_id}» не найден.")

        await self._execute(
            session,
            "UPDATE editorial.authors SET is_active = FALSE, updated_at = NOW() WHERE author_id = :aid",
            {"aid": author_id},
        )

        await self._execute(session, _SQL_CHANGELOG_INSERT, {
            "aid": author_id,
            "changed_by": changed_by,
            "old_version": row[0],
            "new_version": row[0],
            "diff_json": json.dumps({"is_active": {"old": True, "new": False}}),
        })

        await session.commit()
        logger.info("Автор %s деактивирован пользователем %s.", author_id, changed_by)

    async def get_profile_history(self, author_id: str) -> list[dict[str, Any]]:
        """
        Возвращает историю изменений профиля из таблицы changelog.

        Args:
            author_id: идентификатор автора.

        Returns:
            Список записей ``{id, changed_at, changed_by, old_version, new_version, diff_json}``
            в обратном хронологическом порядке (новые первые).
        """
        session = self._get_session()
        result = await self._execute(
            session,
            """\
            SELECT id, changed_at, changed_by, old_version, new_version, diff_json
            FROM editorial.author_changelog
            WHERE author_id = :aid
            ORDER BY changed_at DESC
            LIMIT 100
            """,
            {"aid": author_id},
        )
        rows = result.fetchall()
        return [
            {
                "id": row[0],
                "changed_at": row[1].isoformat() if hasattr(row[1], "isoformat") else str(row[1]),
                "changed_by": row[2],
                "old_version": row[3],
                "new_version": row[4],
                "diff": row[5] if isinstance(row[5], dict) else json.loads(row[5] or "{}"),
            }
            for row in rows
        ]

    async def update_style_embedding(self, author_id: str, embedding: list[float]) -> None:
        """
        Сохраняет векторное представление стиля автора (из QazCompute).

        Args:
            author_id: идентификатор автора.
            embedding: вектор размерностью 1024.
        """
        session = self._get_session()
        # pgvector хранит float[] – передаём как строку ARRAY-literal
        emb_str = "[" + ",".join(str(x) for x in embedding) + "]"
        await self._execute(
            session,
            "UPDATE editorial.authors SET style_embedding = :emb::vector WHERE author_id = :aid",
            {"emb": emb_str, "aid": author_id},
        )
        await session.commit()
        logger.debug("Обновлён style_embedding для %s (dim=%d).", author_id, len(embedding))

    # ------------------------------------------------------------------
    # Загрузка из JSON-файла (dev-режим)
    # ------------------------------------------------------------------

    @staticmethod
    def load_from_json(path: str | Path) -> AuthorProfile:
        """
        Загружает профиль автора из JSON-файла.

        Используется в разработке/тестах без подключения к PostgreSQL.
        Формат файла: сериализованный ``AuthorProfile`` (``model_dump()``).

        Args:
            path: путь к файлу ``.json``.

        Returns:
            Десериализованный ``AuthorProfile``.

        Raises:
            FileNotFoundError: если файл не найден.
            ValueError: если JSON не соответствует схеме.
        """
        p = Path(path)
        if not p.exists():
            raise FileNotFoundError(f"Файл профиля автора не найден: {p}")
        raw = p.read_text(encoding="utf-8")
        try:
            return AuthorProfile.model_validate_json(raw)
        except Exception as exc:
            raise ValueError(f"Ошибка десериализации профиля из {p}: {exc}") from exc

    @staticmethod
    def dump_to_json(profile: AuthorProfile, path: str | Path, indent: int = 2) -> None:
        """
        Сохраняет профиль автора в JSON-файл.

        Удобно для создания/экспорта профилей в dev-режиме.

        Args:
            profile: профиль автора.
            path: путь к целевому файлу.
            indent: отступ JSON (по умолчанию 2).
        """
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(
            profile.model_dump_json(indent=indent),
            encoding="utf-8",
        )
        logger.info("Профиль %s сохранён в %s.", profile.author_id, p)


# -----------------------------------------------------------------------
# Внутренние утилиты
# -----------------------------------------------------------------------


def _compute_diff(old: AuthorProfile, new: AuthorProfile) -> dict[str, Any]:
    """
    Вычисляет поверхностный diff между двумя профилями для changelog.

    Сравниваются только скалярные поля верхнего уровня и мета-поля.
    Глубокое сравнение style_targets опущено для экономии места в БД.
    """
    diff: dict[str, Any] = {}
    top_level_keys = ("name", "version", "is_active", "domain_scope", "genre_scope", "languages", "primary_language")
    old_d = old.model_dump(include=set(top_level_keys))
    new_d = new.model_dump(include=set(top_level_keys))
    for key in top_level_keys:
        if old_d.get(key) != new_d.get(key):
            diff[key] = {"old": old_d.get(key), "new": new_d.get(key)}
    return diff
