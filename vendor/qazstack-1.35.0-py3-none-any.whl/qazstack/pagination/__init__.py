"""Pagination module: standard page-based and cursor pagination for FastAPI.

Wraps fastapi-pagination with Belilovsky Platform defaults.

Usage:
    from qazstack.pagination import Page, Params, paginate, setup_pagination

    # In main.py (once):
    setup_pagination(app)

    # In routes:
    @router.get("/articles", response_model=Page[ArticleSchema])
    async def list_articles(params: Params = Depends(), session: AsyncSession = Depends(db.get_session)):
        return await paginate(session, select(Article).order_by(Article.id.desc()), params)
"""

from qazstack.pagination.page import (
    Page,
    Params,
    paginate,
    paginate_list,
    setup_pagination,
)

__all__ = ["Page", "Params", "paginate", "paginate_list", "setup_pagination"]
