"""Sentry initialization – graceful no-op if DSN not configured or sdk not installed.

Consolidated from: qazposter/sentry_setup.py, Crisis-Monitor/app/__init__.py

Usage::

    from qazstack.observability import init_sentry

    init_sentry(dsn="https://...", environment="production")
    # Or from env:
    init_sentry()  # reads SENTRY_DSN from environment
"""

from __future__ import annotations

import logging
import os

logger = logging.getLogger("qazstack.observability")


def init_sentry(
    *,
    dsn: str = "",
    environment: str = "production",
    traces_sample_rate: float = 0.1,
    release: str = "",
    send_pii: bool = False,
) -> bool:
    """Initialize Sentry error tracking.

    Args:
        dsn: Sentry DSN. Falls back to SENTRY_DSN env var.
        environment: Deployment environment name.
        traces_sample_rate: Percentage of transactions to trace (0.0-1.0).
        release: Release identifier (e.g. "qazposter@1.0.0").
        send_pii: Whether to send personally identifiable information.

    Returns:
        True if Sentry was initialized, False otherwise.
    """
    dsn = dsn or os.environ.get("SENTRY_DSN", "")
    if not dsn:
        logger.debug("Sentry DSN not configured, skipping")
        return False

    try:
        import sentry_sdk
        from sentry_sdk.integrations.fastapi import FastApiIntegration
        from sentry_sdk.integrations.logging import LoggingIntegration
        from sentry_sdk.integrations.sqlalchemy import SqlalchemyIntegration

        sentry_sdk.init(
            dsn=dsn,
            traces_sample_rate=traces_sample_rate,
            environment=environment,
            integrations=[
                FastApiIntegration(transaction_style="endpoint"),
                SqlalchemyIntegration(),
                LoggingIntegration(level=logging.INFO, event_level=logging.ERROR),
            ],
            send_default_pii=send_pii,
            release=release or None,
        )
        logger.info("Sentry initialized (env=%s)", environment)
        return True

    except ImportError:
        logger.info("sentry-sdk not installed, skipping")
        return False
    except Exception as exc:
        logger.error("Failed to initialize Sentry: %s", exc)
        return False
