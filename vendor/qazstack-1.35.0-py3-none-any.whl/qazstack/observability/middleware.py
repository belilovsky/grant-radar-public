"""Request ID middleware + structured access logging.

Consolidated from: qazposter/middleware/logging_middleware.py, qazcompute/middleware.py

Adds X-Request-ID header to every request/response and logs structured access info.

Usage::

    from qazstack.observability import RequestIDMiddleware

    app.add_middleware(RequestIDMiddleware)

    # In routes, access request ID:
    request.state.request_id
"""

from __future__ import annotations

import logging
import time
import uuid

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request


class RequestIDMiddleware(BaseHTTPMiddleware):
    """Middleware that assigns a request ID and logs structured access data.

    - Reads X-Request-ID from incoming headers (or generates a new one).
    - Stores it on request.state.request_id.
    - Adds X-Request-ID to response headers.
    - Logs method, path, status, duration, client IP.

    Args:
        app: ASGI application.
        logger_name: Name of the logger for access logs.
    """

    def __init__(self, app, logger_name: str = "qazstack.access"):
        super().__init__(app)
        self.access_logger = logging.getLogger(logger_name)

    async def dispatch(self, request: Request, call_next):
        request_id = request.headers.get("X-Request-ID", uuid.uuid4().hex[:8])
        request.state.request_id = request_id

        start = time.perf_counter()
        response = await call_next(request)
        elapsed_ms = (time.perf_counter() - start) * 1000

        response.headers["X-Request-ID"] = request_id

        client_ip = request.client.host if request.client else "-"
        self.access_logger.info(
            "method=%s path=%s status=%d duration_ms=%.1f request_id=%s client=%s",
            request.method,
            request.url.path,
            response.status_code,
            elapsed_ms,
            request_id,
            client_ip,
        )

        return response
