"""Portable correlation envelope for logs, metrics and tracing adapters."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from qazstack.contracts._validation import require_aware, require_identifier, require_text


@dataclass(frozen=True, slots=True)
class ObservabilityEnvelope:
    service: str
    event: str
    occurred_at: datetime
    request_id: str | None = None
    run_id: str | None = None
    trace_id: str | None = None
    severity: str = "info"
    duration_ms: int | None = None
    error_code: str | None = None
    attributes: tuple[tuple[str, str], ...] = ()

    def __post_init__(self) -> None:
        require_identifier(self.service, "service")
        require_identifier(self.event, "event")
        require_aware(self.occurred_at, "occurred_at")
        if self.severity not in {"debug", "info", "warning", "error", "critical"}:
            raise ValueError("severity is unsupported")
        if not any((self.request_id, self.run_id, self.trace_id)):
            raise ValueError("at least one correlation identifier is required")
        for name in ("request_id", "run_id", "trace_id"):
            value = getattr(self, name)
            if value is not None:
                require_text(value, name)
        if self.duration_ms is not None and self.duration_ms < 0:
            raise ValueError("duration_ms must be non-negative")
        if len({key for key, _ in self.attributes}) != len(self.attributes):
            raise ValueError("attribute keys must be unique")

    def as_attributes(self) -> dict[str, str]:
        return dict(self.attributes)
