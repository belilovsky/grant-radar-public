"""Lemmatization for Russian (via pymorphy3) and Kazakh (rule-based).

Russian lemmatization uses pymorphy3 for accurate morphological analysis.
Kazakh lemmatization uses suffix-stripping rules for common inflections.
"""

from __future__ import annotations

import logging
import re
from typing import Optional

from qazstack.kznlp.lang_detect import detect_lang_token

logger = logging.getLogger(__name__)

# ── Russian lemmatizer (pymorphy3) ─────────────────────────────────

_morph = None
_morph_loaded = False


def _load_morph():
    """Lazy-load pymorphy3 analyzer."""
    global _morph, _morph_loaded
    if _morph_loaded:
        return _morph is not None
    _morph_loaded = True
    try:
        import pymorphy3
        _morph = pymorphy3.MorphAnalyzer()
        return True
    except ImportError:
        logger.info("pymorphy3 not installed. Russian lemmatization unavailable.")
        return False


def _lemmatize_ru(word: str) -> str:
    """Lemmatize a Russian word using pymorphy3."""
    if not _load_morph() or _morph is None:
        return word.lower()
    parsed = _morph.parse(word)
    if parsed:
        return parsed[0].normal_form
    return word.lower()


# ── Kazakh lemmatizer (suffix-stripping) ───────────────────────────

# Common Kazakh inflectional suffixes (ordered by length, longest first)
# Based on agglutinative morphology rules
_KK_SUFFIXES = [
    # Verb suffixes
    "лардың", "лерінің", "тардың", "терінің",
    "ларға", "лерге", "тарға", "терге",
    "лардан", "лерден", "тардан", "терден",
    "ларда", "лерде", "тарда", "терде",
    "ларды", "лерді", "тарды", "терді",
    "ларын", "лерін", "тарын", "терін",
    # Case suffixes
    "ның", "нің", "дың", "дің", "тың", "тің",
    "ға", "ге", "қа", "ке",
    "дан", "ден", "тан", "тен", "нан", "нен",
    "да", "де", "та", "те",
    "ды", "ді", "ты", "ті", "ны", "ні",
    "ын", "ін", "н",
    # Plural
    "лар", "лер", "тар", "тер", "дар", "дер",
    # Possessive
    "ым", "ім", "ың", "ің", "ы", "і",
    "мыз", "міз", "ңыз", "ңіз",
]

# Minimum stem length after stripping
_MIN_STEM_LEN = 2


def _lemmatize_kk(word: str) -> str:
    """Lemmatize a Kazakh word using suffix-stripping.

    This is a simplified approach – proper Kazakh morphological
    analysis requires a full FST or neural model. Sufficient for
    text normalization and search indexing.
    """
    lower = word.lower()
    for suffix in _KK_SUFFIXES:
        if lower.endswith(suffix) and len(lower) - len(suffix) >= _MIN_STEM_LEN:
            return lower[: -len(suffix)]
    return lower


def lemmatize(word: str, *, lang: Optional[str] = None) -> str:
    """Lemmatize a single word.

    Args:
        word: Input word.
        lang: Force language. Auto-detected from word if None.

    Returns:
        Lemmatized form (lowercase).
    """
    if not word:
        return word

    if lang is None:
        lang = detect_lang_token(word)

    if lang == "kk":
        return _lemmatize_kk(word)
    elif lang == "ru":
        return _lemmatize_ru(word)
    else:
        return word.lower()


def lemmatize_tokens(tokens: list[str], *, lang: Optional[str] = None) -> list[str]:
    """Lemmatize a list of tokens.

    Args:
        tokens: List of word tokens.
        lang: Force language for all tokens. Auto-detected per token if None.

    Returns:
        List of lemmatized tokens.
    """
    return [lemmatize(t, lang=lang) for t in tokens]
