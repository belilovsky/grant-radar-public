"""Language detection for Kazakh / Russian / English texts.

Uses character-set heuristics optimized for the bilingual KZ environment.
Fast (no ML models), suitable for per-document and per-token detection.
"""

from __future__ import annotations

import re

# Kazakh-specific Cyrillic characters absent from Russian
_KK_CHARS = set("әғқңөұүіһӘҒҚҢӨҰҮІҺ")

# Russian Cyrillic characters (shared with Kazakh Cyrillic)
_CYR_CHARS = set("абвгдежзийклмнопрстуфхцчшщъыьэюяАБВГДЕЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯёЁ")

# Latin alphabet characters
_LAT_CHARS = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")

# Combined Kazakh Cyrillic = Russian Cyrillic + Kazakh-specific
_KK_CYR_ALL = _CYR_CHARS | _KK_CHARS


def detect_lang(text: str, *, threshold_kk: float = 0.005) -> str:
    """Detect language of a text string.

    Returns one of: ``"kk"`` (Kazakh), ``"ru"`` (Russian), ``"en"`` (English),
    or ``"unknown"`` for texts with insufficient signal.

    The detection is character-based:
    - If Kazakh-specific chars (ә, ғ, қ, ң, ө, ұ, ү, і, һ) exceed
      ``threshold_kk`` fraction of text length → Kazakh.
    - If Cyrillic dominates → Russian.
    - If Latin dominates → English.

    Args:
        text: Input text.
        threshold_kk: Minimum fraction of Kazakh-specific chars to classify
            as Kazakh. Default 0.005 (0.5%).

    Returns:
        Language code string.
    """
    if not text or not text.strip():
        return "unknown"

    # Count character types
    text_len = len(text)
    kk_count = 0
    cyr_count = 0
    lat_count = 0

    for ch in text:
        if ch in _KK_CHARS:
            kk_count += 1
            cyr_count += 1  # Kazakh chars are Cyrillic
        elif ch in _CYR_CHARS:
            cyr_count += 1
        elif ch in _LAT_CHARS:
            lat_count += 1

    # Decision logic
    if kk_count / text_len > threshold_kk:
        return "kk"
    if cyr_count > lat_count and cyr_count > 0:
        return "ru"
    if lat_count > cyr_count and lat_count > 0:
        return "en"
    return "unknown"


def detect_lang_token(token: str) -> str:
    """Detect language of a single word/token.

    More aggressive Kazakh detection for short tokens:
    any Kazakh-specific character → Kazakh.
    """
    if not token:
        return "unknown"
    for ch in token:
        if ch in _KK_CHARS:
            return "kk"
    has_cyr = any(ch in _CYR_CHARS for ch in token)
    has_lat = any(ch in _LAT_CHARS for ch in token)
    if has_cyr:
        return "ru"
    if has_lat:
        return "en"
    return "unknown"


def is_kazakh(text: str) -> bool:
    """Check if text is Kazakh."""
    return detect_lang(text) == "kk"


def is_russian(text: str) -> bool:
    """Check if text is Russian."""
    return detect_lang(text) == "ru"


def script_ratio(text: str) -> dict[str, float]:
    """Get script composition of a text.

    Returns:
        Dict with keys ``"cyrillic"``, ``"latin"``, ``"kazakh_specific"``,
        ``"digits"``, ``"other"`` – each a fraction of total chars.
    """
    if not text:
        return {"cyrillic": 0.0, "latin": 0.0, "kazakh_specific": 0.0, "digits": 0.0, "other": 0.0}

    total = len(text)
    kk = sum(1 for ch in text if ch in _KK_CHARS)
    cyr = sum(1 for ch in text if ch in _CYR_CHARS)
    lat = sum(1 for ch in text if ch in _LAT_CHARS)
    dig = sum(1 for ch in text if ch.isdigit())
    other = total - kk - cyr - lat - dig

    return {
        "cyrillic": round(cyr / total, 4),
        "latin": round(lat / total, 4),
        "kazakh_specific": round(kk / total, 4),
        "digits": round(dig / total, 4),
        "other": round(other / total, 4),
    }
