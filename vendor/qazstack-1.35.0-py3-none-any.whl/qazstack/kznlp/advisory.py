"""Advisory entity parsing and optional QazShield classification veto."""

from __future__ import annotations

import os
import re
from dataclasses import dataclass
from functools import lru_cache
from typing import Any
from urllib.parse import urljoin

import httpx

_TRUTHY = frozenset({"1", "true", "yes", "on"})
_PLACEHOLDER_RE = re.compile(r"^\[([A-Z_]+)_\d+\]$")
_NON_PERSON_TYPES = frozenset({"org", "location", "gov"})


@dataclass(frozen=True, slots=True)
class AdvisoryEntity:
    name: str
    entity_type: str
    confidence: float | None = None


def normalize_entity_type(raw_type: str) -> str:
    normalized = raw_type.strip().upper()
    if normalized == "PERSON":
        return "person"
    if normalized in {"ORG", "ORGANIZATION", "ORGANISATION"}:
        return "org"
    if normalized in {"LOCATION", "GPE", "FACILITY"}:
        return "location"
    if normalized in {"GOV", "GOVERNMENT"}:
        return "gov"
    return normalized.lower()


def normalize_entity_text(value: str) -> str:
    return " ".join((value or "").strip().lower().replace("ё", "е").split())


def entities_from_anonymize_payload(payload: dict[str, Any]) -> list[AdvisoryEntity]:
    entity_map = payload.get("entity_map") or {}
    if not isinstance(entity_map, dict):
        return []
    scores = payload.get("confidence_scores") or {}
    if not isinstance(scores, dict):
        scores = {}

    entities: list[AdvisoryEntity] = []
    for placeholder, original in entity_map.items():
        if not isinstance(placeholder, str) or not isinstance(original, str):
            continue
        match = _PLACEHOLDER_RE.match(placeholder)
        if not match:
            continue
        confidence = scores.get(placeholder)
        entities.append(
            AdvisoryEntity(
                name=original,
                entity_type=normalize_entity_type(match.group(1)),
                confidence=float(confidence) if isinstance(confidence, (int, float)) else None,
            )
        )
    return entities


class QazShieldEntityAdviser:
    """Fail-open advisory classifier for ambiguous entity candidates."""

    def __init__(
        self,
        *,
        base_url: str | None = None,
        api_key: str | None = None,
        timeout: float | None = None,
        enabled: bool | None = None,
        client: httpx.Client | None = None,
        cache_size: int = 2048,
    ) -> None:
        configured = os.getenv("QAZSHIELD_ENTITY_ADVISORY_ENABLED", "false")
        self.enabled = configured.strip().lower() in _TRUTHY if enabled is None else enabled
        self.base_url = (base_url or os.getenv("QAZSHIELD_URL") or "https://shield.qdev.run").rstrip("/") + "/"
        self.api_key = api_key if api_key is not None else os.getenv("QAZSHIELD_API_KEY", "")
        try:
            configured_timeout = float(os.getenv("QAZSHIELD_ENTITY_TIMEOUT_SEC", "1.2"))
        except ValueError:
            configured_timeout = 1.2
        self.timeout = max(0.2, timeout if timeout is not None else configured_timeout)
        self.client = client
        self.cache_size = max(0, cache_size)
        self._cache: dict[str, list[AdvisoryEntity]] = {}

    def detect(self, text: str) -> list[AdvisoryEntity]:
        text = (text or "").strip()
        if not self.enabled or not text:
            return []
        cache_key = text[:512]
        if cache_key in self._cache:
            return list(self._cache[cache_key])

        headers = {"Accept": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        try:
            request = self.client.post if self.client is not None else httpx.post
            response = request(
                urljoin(self.base_url, "api/anonymize?include_original=false"),
                data={"text": text[:4000], "sensitivity": "high"},
                headers=headers,
                timeout=self.timeout,
            )
            response.raise_for_status()
            payload = response.json()
            entities = entities_from_anonymize_payload(payload if isinstance(payload, dict) else {})
        except (httpx.HTTPError, ValueError, TypeError):
            entities = []

        if self.cache_size:
            if len(self._cache) >= self.cache_size:
                self._cache.clear()
            self._cache[cache_key] = list(entities)
        return entities

    def should_reject_person_candidate(self, name: str) -> bool:
        target = normalize_entity_text(name)
        if not target:
            return True
        matching = [entity for entity in self.detect(name) if normalize_entity_text(entity.name) == target]
        if not matching or any(entity.entity_type == "person" for entity in matching):
            return False
        return any(entity.entity_type in _NON_PERSON_TYPES for entity in matching)


@lru_cache(maxsize=1)
def get_default_entity_adviser() -> QazShieldEntityAdviser:
    return QazShieldEntityAdviser()


def should_reject_person_candidate(name: str) -> bool:
    return get_default_entity_adviser().should_reject_person_candidate(name)
