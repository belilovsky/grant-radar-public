"""Multilingual sentiment analysis via HuggingFace transformers.

Model: cardiffnlp/twitter-xlm-roberta-base-sentiment-multilingual
  - 8 languages natively (en, ar, fr, de, hi, it, sp, pt)
  - zero-shot works on 100+ languages (ru, kk included via XLM-RoBERTa)
  - 3 classes: negative / neutral / positive

Usage::

    from qazstack.kznlp import classify_sentiment, SentimentResult

    result = classify_sentiment("Президент выступил с позитивным заявлением")
    # → SentimentResult(label='positive', score=0.87, tone=0.72,
    #                    scores={'negative': 0.05, 'neutral': 0.23, 'positive': 0.72})

    # Batch:
    results = classify_sentiment_batch(["Good news", "Bad news", "Neutral"])

Requires: ``pip install transformers torch`` or ``pip install qazstack[sentiment]``
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Sequence

logger = logging.getLogger("qazstack.kznlp.sentiment")

MODEL_NAME = "cardiffnlp/twitter-xlm-roberta-base-sentiment-multilingual"
MAX_LENGTH = 512

_pipeline = None


@dataclass(frozen=True)
class SentimentResult:
    """Result of sentiment analysis for a single text."""

    label: str  # "negative", "neutral", or "positive"
    score: float  # confidence of the best label [0, 1]
    tone: float  # weighted score: positive - negative [-1, +1]
    scores: dict  # {"negative": float, "neutral": float, "positive": float}


# Neutral fallback for empty/invalid input
_NEUTRAL = SentimentResult(
    label="neutral",
    score=1.0,
    tone=0.0,
    scores={"negative": 0.0, "neutral": 1.0, "positive": 0.0},
)


def _get_pipeline():
    """Lazy-load the HuggingFace sentiment pipeline (singleton)."""
    global _pipeline
    if _pipeline is not None:
        return _pipeline

    logger.info("Loading sentiment model: %s", MODEL_NAME)
    try:
        from transformers import pipeline as hf_pipeline  # noqa: F811

        _pipeline = hf_pipeline(
            "sentiment-analysis",
            model=MODEL_NAME,
            tokenizer=MODEL_NAME,
            top_k=None,
            truncation=True,
            max_length=MAX_LENGTH,
        )
        logger.info("Sentiment model loaded successfully")
        return _pipeline
    except ImportError:
        raise ImportError(
            "transformers/torch not installed. "
            "Install with: pip install qazstack[sentiment] "
            "or: pip install transformers torch"
        )


def _parse_scores(raw_output: list[dict]) -> dict:
    """Parse HuggingFace output to {negative, neutral, positive} dict."""
    scores: dict[str, float] = {}
    for item in raw_output:
        label = item["label"].lower()
        if "neg" in label:
            scores["negative"] = item["score"]
        elif "neu" in label:
            scores["neutral"] = item["score"]
        elif "pos" in label:
            scores["positive"] = item["score"]
    return scores


def classify_sentiment(text: str) -> SentimentResult:
    """Classify sentiment of a single text.

    Args:
        text: Input text (will be truncated to 512 tokens by the model).

    Returns:
        SentimentResult with label, score, tone, and per-class scores.

    Raises:
        ImportError: if transformers/torch are not installed.
    """
    if not text or not text.strip():
        return _NEUTRAL

    pipe = _get_pipeline()
    clean = text.strip()[:500]  # Pre-truncate to reduce tokenizer work

    try:
        results = pipe(clean)
        raw_scores = results[0] if results else []
        scores = _parse_scores(raw_scores)

        if not scores:
            return _NEUTRAL

        best_label = max(scores, key=scores.get)  # type: ignore[arg-type]
        best_score = scores[best_label]

        neg = scores.get("negative", 0.0)
        pos = scores.get("positive", 0.0)
        tone = round(pos - neg, 4)

        return SentimentResult(
            label=best_label,
            score=round(best_score, 4),
            tone=tone,
            scores={k: round(v, 4) for k, v in scores.items()},
        )
    except Exception as e:
        logger.warning("Sentiment classification failed: %s", e)
        return SentimentResult(
            label="neutral",
            score=0.0,
            tone=0.0,
            scores={"negative": 0.0, "neutral": 0.0, "positive": 0.0},
        )


def classify_sentiment_batch(
    texts: Sequence[str], batch_size: int = 32
) -> list[SentimentResult]:
    """Classify sentiment for a batch of texts.

    More efficient than calling classify_sentiment() in a loop
    because it uses the HuggingFace pipeline's built-in batching.

    Args:
        texts: Input texts.
        batch_size: Batch size for the pipeline.

    Returns:
        List of SentimentResult, one per input text.
    """
    if not texts:
        return []

    results: list[SentimentResult] = []

    # Filter and prepare
    clean_texts = []
    empty_indices: set[int] = set()
    for i, t in enumerate(texts):
        if not t or not t.strip():
            empty_indices.add(i)
            clean_texts.append("")
        else:
            clean_texts.append(t.strip()[:500])

    # Run pipeline on non-empty texts
    non_empty = [(i, t) for i, t in enumerate(clean_texts) if i not in empty_indices]

    if not non_empty:
        return [_NEUTRAL] * len(texts)

    pipe = _get_pipeline()

    # Batch inference
    try:
        batch_texts = [t for _, t in non_empty]
        raw_results = pipe(batch_texts, batch_size=batch_size)
    except Exception as e:
        logger.error("Batch sentiment failed: %s", e)
        return [_NEUTRAL] * len(texts)

    # Map results back
    result_map: dict[int, SentimentResult] = {}
    for (idx, _), raw in zip(non_empty, raw_results):
        scores = _parse_scores(raw)
        if not scores:
            result_map[idx] = _NEUTRAL
            continue

        best_label = max(scores, key=scores.get)  # type: ignore[arg-type]
        best_score = scores[best_label]
        neg = scores.get("negative", 0.0)
        pos = scores.get("positive", 0.0)
        tone = round(pos - neg, 4)

        result_map[idx] = SentimentResult(
            label=best_label,
            score=round(best_score, 4),
            tone=tone,
            scores={k: round(v, 4) for k, v in scores.items()},
        )

    # Build final list
    for i in range(len(texts)):
        if i in empty_indices:
            results.append(_NEUTRAL)
        else:
            results.append(result_map.get(i, _NEUTRAL))

    return results
