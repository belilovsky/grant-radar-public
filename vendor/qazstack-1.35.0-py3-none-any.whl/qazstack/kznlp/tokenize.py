"""Tokenization and sentence splitting for Kazakh and Russian texts.

Provides regex-based tokenizers that handle both Cyrillic scripts correctly,
including Kazakh-specific characters and common abbreviations.
"""

from __future__ import annotations

import re

# Token pattern: words (Cyrillic, Latin, digits, hyphens), or single punctuation
_TOKEN_RE = re.compile(
    r"""
    (?:                          # Word-like tokens:
        [а-яА-ЯёЁәғқңөұүіһӘҒҚҢӨҰҮІҺa-zA-Z0-9]  # starts with letter/digit
        [\w\-']*                 # continues with word chars, hyphens, apostrophes
    )
    |                            # OR
    (?:                          # Numbers with separators:
        \d[\d\s.,]*\d            # digits with spaces/commas/dots between
    )
    |                            # OR
    (?:                          # Single non-whitespace char (punctuation):
        \S
    )
    """,
    re.VERBOSE | re.UNICODE,
)

# Sentence-ending patterns
_SENT_END_RE = re.compile(
    r"""
    (?<=[.!?…])                  # After sentence-ending punctuation
    \s+                          # Followed by whitespace
    (?=[А-ЯЁӘҒҚҢӨҰҮІҺа-яёA-Z\d\-«"])  # Before uppercase, digit, or opening quote
    """,
    re.VERBOSE | re.UNICODE,
)

# Common abbreviations that should NOT trigger sentence split
_ABBREVS = {
    "г", "гг", "т", "д", "тг", "тыс", "млн", "млрд", "руб", "долл", "евро",
    "ул", "пр", "бул", "кв", "стр", "корп", "оф",
    "проф", "доц", "акад", "канд", "др", "рис",
    "см", "м", "км", "кг", "мг", "мм",
    "ст", "п", "пп", "ч", "гл", "разд",
    "рт",  # б.а.қ (Kazakh abbreviation)
}


def tokenize(text: str) -> list[str]:
    """Tokenize text into words and punctuation marks.

    Handles Kazakh-specific Cyrillic characters correctly.
    Does not split sentences – returns a flat list of tokens.

    Args:
        text: Input text.

    Returns:
        List of token strings.

    Example::

        >>> tokenize("Астана – столица Казахстана.")
        ['Астана', '–', 'столица', 'Казахстана', '.']
    """
    if not text:
        return []
    return _TOKEN_RE.findall(text)


def sent_tokenize(text: str) -> list[str]:
    """Split text into sentences.

    Uses regex-based heuristics with abbreviation awareness.
    Works for both Kazakh and Russian texts.

    Args:
        text: Input text.

    Returns:
        List of sentence strings.

    Example::

        >>> sent_tokenize("Ұлы дала. Жүрек сезген.")
        ['Ұлы дала.', 'Жүрек сезген.']
    """
    if not text:
        return []

    text = text.strip()
    if not text:
        return []

    # Split on paragraph breaks first
    paragraphs = re.split(r"\n\s*\n", text)
    sentences = []

    for para in paragraphs:
        para = para.strip()
        if not para:
            continue

        # Split within paragraph
        parts = _SENT_END_RE.split(para)
        for part in parts:
            part = part.strip()
            if part:
                sentences.append(part)

    return sentences if sentences else [text]


def word_tokenize(text: str) -> list[str]:
    """Tokenize and return only word tokens (skip punctuation).

    Args:
        text: Input text.

    Returns:
        List of word-only tokens (letters/digits).
    """
    return [t for t in tokenize(text) if re.match(r"[\w]", t, re.UNICODE)]


def char_ngrams(text: str, n: int = 3) -> list[str]:
    """Generate character n-grams from text.

    Useful for language identification and fuzzy matching.

    Args:
        text: Input text.
        n: N-gram size (default 3).

    Returns:
        List of n-gram strings.
    """
    if not text or len(text) < n:
        return []
    return [text[i:i + n] for i in range(len(text) - n + 1)]
