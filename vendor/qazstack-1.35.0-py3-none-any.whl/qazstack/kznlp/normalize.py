"""Text normalization for Kazakh and Russian content.

Handles common issues in Kazakh-Russian bilingual texts:
- Mixed-script homoglyph resolution (Latin 'a' vs Cyrillic 'а')
- Whitespace normalization
- HTML stripping
- Unicode normalization (NFKC)
- Kazakh-specific character fixes
"""

from __future__ import annotations

import re
import unicodedata

# Latin → Cyrillic homoglyph map (for mixed-script words)
# Only visually identical characters
_LATIN_TO_CYRILLIC: dict[str, str] = {
    "A": "А", "a": "а",
    "B": "В", "E": "Е", "e": "е",
    "K": "К", "M": "М",
    "H": "Н", "O": "О", "o": "о",
    "P": "Р", "p": "р",
    "C": "С", "c": "с",
    "T": "Т", "X": "Х", "x": "х",
    "y": "у",
}

_CYRILLIC_TO_LATIN: dict[str, str] = {v: k for k, v in _LATIN_TO_CYRILLIC.items()}

# Cyrillic character set for word detection
_CYR_RE = re.compile(r"[а-яА-ЯёЁәғқңөұүіһӘҒҚҢӨҰҮІҺ]")
_LAT_RE = re.compile(r"[a-zA-Z]")

# HTML tag pattern
_HTML_TAG_RE = re.compile(r"<[^>]+>")

# Multiple whitespace
_MULTI_SPACE_RE = re.compile(r"[ \t]+")
_MULTI_NEWLINE_RE = re.compile(r"\n{3,}")


def fix_homoglyphs(text: str, *, target: str = "cyrillic") -> str:
    """Fix mixed-script words by converting homoglyphs to target script.

    In the Kazakh-Russian web, it's common to find words like "Астанa"
    where the final 'a' is Latin. This function detects such mixed words
    and converts all characters to the dominant script.

    Args:
        text: Input text.
        target: Target script – ``"cyrillic"`` (default) or ``"latin"``.

    Returns:
        Text with homoglyphs resolved.
    """
    if not text:
        return text

    charmap = _LATIN_TO_CYRILLIC if target == "cyrillic" else _CYRILLIC_TO_LATIN

    # Process word by word
    def _fix_word(match: re.Match) -> str:
        word = match.group(0)
        cyr_count = len(_CYR_RE.findall(word))
        lat_count = len(_LAT_RE.findall(word))

        # Only fix if mixed and one script dominates
        if cyr_count == 0 or lat_count == 0:
            return word  # Pure script, no fix needed

        if target == "cyrillic" and cyr_count >= lat_count:
            return "".join(charmap.get(ch, ch) for ch in word)
        elif target == "latin" and lat_count >= cyr_count:
            return "".join(charmap.get(ch, ch) for ch in word)

        return word

    return re.sub(r"[a-zA-Zа-яА-ЯёЁәғқңөұүіһӘҒҚҢӨҰҮІҺ]+", _fix_word, text)


def collapse_whitespace(text: str) -> str:
    """Normalize whitespace: collapse multiple spaces, trim newlines.

    - Multiple spaces/tabs → single space
    - 3+ consecutive newlines → 2 newlines
    - Strip leading/trailing whitespace
    - Replace non-breaking spaces with regular spaces
    """
    if not text:
        return text
    # Replace non-breaking spaces
    text = text.replace("\u00a0", " ").replace("\u200b", "")
    text = _MULTI_SPACE_RE.sub(" ", text)
    text = _MULTI_NEWLINE_RE.sub("\n\n", text)
    return text.strip()


def strip_html_tags(text: str) -> str:
    """Remove HTML tags from text, preserving whitespace between blocks."""
    if not text:
        return text
    # Replace block-level tags with newlines
    text = re.sub(r"<(?:br|p|div|h[1-6]|li|tr)[^>]*>", "\n", text, flags=re.IGNORECASE)
    # Remove all remaining tags
    text = _HTML_TAG_RE.sub("", text)
    # Decode common entities
    text = text.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
    text = text.replace("&nbsp;", " ").replace("&quot;", '"').replace("&#39;", "'")
    return collapse_whitespace(text)


def normalize_unicode(text: str) -> str:
    """Apply NFKC Unicode normalization.

    Converts compatibility characters to their canonical forms.
    Useful for normalizing fullwidth/halfwidth characters.
    """
    return unicodedata.normalize("NFKC", text) if text else text


def normalize_text(
    text: str,
    *,
    fix_scripts: bool = True,
    strip_html: bool = False,
    normalize_ws: bool = True,
    unicode_nfkc: bool = True,
) -> str:
    """Apply a full normalization pipeline to text.

    Steps (in order):
    1. Unicode NFKC normalization (optional)
    2. HTML stripping (optional)
    3. Homoglyph resolution (optional)
    4. Whitespace normalization (optional)

    Args:
        text: Input text.
        fix_scripts: Fix mixed-script homoglyphs (default True).
        strip_html: Strip HTML tags (default False).
        normalize_ws: Normalize whitespace (default True).
        unicode_nfkc: Apply NFKC normalization (default True).

    Returns:
        Normalized text.
    """
    if not text:
        return text

    if unicode_nfkc:
        text = normalize_unicode(text)
    if strip_html:
        text = strip_html_tags(text)
    if fix_scripts:
        text = fix_homoglyphs(text)
    if normalize_ws:
        text = collapse_whitespace(text)

    return text
