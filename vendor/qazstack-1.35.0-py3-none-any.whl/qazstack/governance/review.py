"""Storage-neutral review decisions and deterministic snapshot identities."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from datetime import datetime
from enum import StrEnum
from typing import Any

from qazstack.contracts._validation import require_aware, require_text


class ReviewDecision(StrEnum):
    APPROVED = "approved"
    CHANGES_REQUESTED = "changes_requested"
    REJECTED = "rejected"
    SUPERSEDED = "superseded"


class ReviewState(StrEnum):
    PENDING = "pending"
    NEEDS_REVIEW = "needs_review"
    WAITING_EXTERNAL = "waiting_external"
    APPROVED = "approved"
    REJECTED = "rejected"
    SUPERSEDED = "superseded"


_NEXT_STATE = {
    ReviewDecision.APPROVED: ReviewState.APPROVED,
    ReviewDecision.CHANGES_REQUESTED: ReviewState.NEEDS_REVIEW,
    ReviewDecision.REJECTED: ReviewState.REJECTED,
    ReviewDecision.SUPERSEDED: ReviewState.SUPERSEDED,
}
_ALLOWED = {
    ReviewState.PENDING: frozenset(
        {ReviewDecision.APPROVED, ReviewDecision.CHANGES_REQUESTED, ReviewDecision.REJECTED}
    ),
    ReviewState.NEEDS_REVIEW: frozenset(
        {ReviewDecision.APPROVED, ReviewDecision.CHANGES_REQUESTED, ReviewDecision.REJECTED}
    ),
    ReviewState.WAITING_EXTERNAL: frozenset(
        {ReviewDecision.APPROVED, ReviewDecision.CHANGES_REQUESTED, ReviewDecision.REJECTED}
    ),
    ReviewState.APPROVED: frozenset({ReviewDecision.SUPERSEDED}),
    ReviewState.REJECTED: frozenset({ReviewDecision.SUPERSEDED}),
    ReviewState.SUPERSEDED: frozenset(),
}


class InvalidReviewTransition(ValueError):
    """Raised when an append-only decision cannot follow the current state."""


def next_review_state(current: str | ReviewState, decision: str | ReviewDecision) -> ReviewState:
    current_state = ReviewState(current)
    next_decision = ReviewDecision(decision)
    if next_decision not in _ALLOWED[current_state]:
        raise InvalidReviewTransition(f"decision {next_decision.value!r} is not allowed from {current_state.value!r}")
    return _NEXT_STATE[next_decision]


@dataclass(frozen=True, slots=True)
class ReviewDecisionRecord:
    decision_id: str
    subject_id: str
    reviewer_id: str
    decision: ReviewDecision
    note: str
    created_at: datetime
    previous_state: ReviewState

    def __post_init__(self) -> None:
        for name in ("decision_id", "subject_id", "reviewer_id", "note"):
            require_text(getattr(self, name), name)
        require_aware(self.created_at, "created_at")
        next_review_state(self.previous_state, self.decision)

    @property
    def resulting_state(self) -> ReviewState:
        return _NEXT_STATE[self.decision]


def canonical_snapshot_hash(payload: Any) -> str:
    """Hash a JSON-compatible snapshot independently of mapping key order."""

    encoded = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return f"sha256:{hashlib.sha256(encoded).hexdigest()}"
