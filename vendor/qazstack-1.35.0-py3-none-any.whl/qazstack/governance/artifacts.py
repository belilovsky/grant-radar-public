"""Deterministic generated-artifact checks and atomic JSON publication."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path
from typing import Any, Collection

DEFAULT_VOLATILE_FIELDS = frozenset({"generated_at"})


class ArtifactState(StrEnum):
    """State returned by a generated-artifact check."""

    CURRENT = "current"
    MISSING = "missing"
    INVALID = "invalid"
    STALE = "stale"


@dataclass(frozen=True)
class ArtifactCheck:
    """Result of comparing a generated JSON artifact with its expected value."""

    path: Path
    state: ArtifactState
    reason: str | None = None

    @property
    def current(self) -> bool:
        return self.state is ArtifactState.CURRENT


def semantically_equal(
    left: Any,
    right: Any,
    *,
    volatile_fields: Collection[str] = DEFAULT_VOLATILE_FIELDS,
) -> bool:
    """Compare JSON-compatible values while ignoring named mapping fields."""

    ignored = frozenset(volatile_fields)
    if isinstance(left, dict) and isinstance(right, dict):
        left_keys = set(left) - ignored
        right_keys = set(right) - ignored
        return left_keys == right_keys and all(
            semantically_equal(left[key], right[key], volatile_fields=ignored) for key in left_keys
        )
    if isinstance(left, list) and isinstance(right, list):
        return len(left) == len(right) and all(
            semantically_equal(left_item, right_item, volatile_fields=ignored)
            for left_item, right_item in zip(left, right, strict=True)
        )
    return left == right


def stabilize_artifact(
    payload: dict[str, Any],
    existing: dict[str, Any] | None,
    *,
    volatile_fields: Collection[str] = DEFAULT_VOLATILE_FIELDS,
) -> dict[str, Any]:
    """Preserve top-level volatile fields when artifact semantics are unchanged."""

    if existing is None or not semantically_equal(
        payload,
        existing,
        volatile_fields=volatile_fields,
    ):
        return dict(payload)

    stabilized = dict(payload)
    for field in volatile_fields:
        if field in existing:
            stabilized[field] = existing[field]
    return stabilized


def check_json_artifact(
    path: str | Path,
    expected: dict[str, Any],
    *,
    volatile_fields: Collection[str] = DEFAULT_VOLATILE_FIELDS,
) -> ArtifactCheck:
    """Check one JSON artifact without mutating it."""

    artifact_path = Path(path)
    if not artifact_path.exists():
        return ArtifactCheck(artifact_path, ArtifactState.MISSING, "artifact does not exist")
    try:
        actual = json.loads(artifact_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return ArtifactCheck(artifact_path, ArtifactState.INVALID, str(exc))
    if not isinstance(actual, dict):
        return ArtifactCheck(artifact_path, ArtifactState.INVALID, "artifact root must be an object")
    if not semantically_equal(actual, expected, volatile_fields=volatile_fields):
        return ArtifactCheck(artifact_path, ArtifactState.STALE, "artifact content differs")
    return ArtifactCheck(artifact_path, ArtifactState.CURRENT)


def write_text_atomic(path: str | Path, content: str) -> None:
    """Replace a UTF-8 text file atomically and durably where supported."""

    artifact_path = Path(path)
    artifact_path.parent.mkdir(parents=True, exist_ok=True)
    temporary = artifact_path.with_name(f".{artifact_path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w", encoding="utf-8") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        temporary.replace(artifact_path)
        try:
            directory_fd = os.open(artifact_path.parent, os.O_RDONLY)
        except OSError:
            return
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)
    finally:
        temporary.unlink(missing_ok=True)


def write_json_artifact(
    path: str | Path,
    payload: dict[str, Any],
    *,
    volatile_fields: Collection[str] = DEFAULT_VOLATILE_FIELDS,
) -> dict[str, Any]:
    """Atomically publish JSON and retain volatile fields when content is unchanged."""

    artifact_path = Path(path)
    existing: dict[str, Any] | None = None
    if artifact_path.exists():
        try:
            candidate = json.loads(artifact_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            candidate = None
        if isinstance(candidate, dict):
            existing = candidate

    stabilized = stabilize_artifact(
        payload,
        existing,
        volatile_fields=volatile_fields,
    )
    write_text_atomic(
        artifact_path,
        json.dumps(stabilized, ensure_ascii=False, indent=2) + "\n",
    )
    return stabilized
