"""Reusable workflow, feature policy and privacy redaction contracts."""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from datetime import datetime

from qazstack.contracts._validation import (
    require_aware,
    require_identifier,
    require_ratio,
    require_text,
)


@dataclass(frozen=True, slots=True)
class WorkflowTransition:
    workflow_id: str
    from_state: str
    to_state: str
    actor: str
    reason: str
    expected_version: int
    decided_at: datetime

    def __post_init__(self) -> None:
        require_identifier(self.workflow_id, "workflow_id")
        require_identifier(self.from_state, "from_state")
        require_identifier(self.to_state, "to_state")
        require_text(self.actor, "actor")
        require_text(self.reason, "reason")
        if self.expected_version < 0:
            raise ValueError("expected_version must be non-negative")
        require_aware(self.decided_at, "decided_at")


def validate_transition(
    transition: WorkflowTransition,
    *,
    allowed: Mapping[str, frozenset[str]],
    actual_version: int,
) -> None:
    if transition.expected_version != actual_version:
        raise ValueError("workflow version conflict")
    if transition.to_state not in allowed.get(transition.from_state, frozenset()):
        raise ValueError(f"transition from {transition.from_state} to {transition.to_state} is not allowed")


@dataclass(frozen=True, slots=True)
class PolicyReason:
    code: str
    message: str

    def __post_init__(self) -> None:
        require_identifier(self.code, "code")
        require_text(self.message, "message")


@dataclass(frozen=True, slots=True)
class FeatureDecision:
    feature_id: str
    enabled: bool
    reason: PolicyReason
    scope: str = "global"
    emergency_disabled: bool = False

    def __post_init__(self) -> None:
        require_identifier(self.feature_id, "feature_id")
        require_text(self.scope, "scope")
        if self.emergency_disabled and self.enabled:
            raise ValueError("an emergency-disabled feature cannot be enabled")


def _normalized_scopes(values: Iterable[str]) -> tuple[str, ...]:
    scopes = tuple(sorted({value.strip() for value in values if value.strip()}))
    if any(len(value) > 128 for value in scopes):
        raise ValueError("regional scopes must be at most 128 characters")
    return scopes


@dataclass(frozen=True, slots=True)
class RegionalScopeDecision:
    """Default-deny decision for products with region-scoped operator access."""

    subject_id: str
    role: str
    requested_regions: tuple[str, ...]
    granted_regions: tuple[str, ...]
    global_access: bool
    allowed: bool
    reason: PolicyReason

    def __post_init__(self) -> None:
        require_identifier(self.subject_id, "subject_id")
        require_identifier(self.role, "role")
        if self.requested_regions != _normalized_scopes(self.requested_regions):
            raise ValueError("requested_regions must be normalized and unique")
        if self.granted_regions != _normalized_scopes(self.granted_regions):
            raise ValueError("granted_regions must be normalized and unique")
        if self.allowed and not self.global_access and not self.requested_regions:
            raise ValueError("regional access requires an explicit requested region")


def decide_regional_access(
    *,
    subject_id: str,
    role: str,
    requested_regions: Iterable[str],
    granted_regions: Iterable[str],
    global_roles: Iterable[str] = ("admin", "superadmin"),
) -> RegionalScopeDecision:
    """Evaluate regional access without assuming a product identity provider."""
    requested = _normalized_scopes(requested_regions)
    granted = _normalized_scopes(granted_regions)
    normalized_role = role.strip().lower()
    global_access = normalized_role in {item.strip().lower() for item in global_roles}
    if global_access:
        return RegionalScopeDecision(
            subject_id,
            normalized_role,
            requested,
            granted,
            True,
            True,
            PolicyReason("global-role", "role grants global regional access"),
        )
    if not requested:
        reason = PolicyReason("missing-scope", "an explicit regional scope is required")
        allowed = False
    elif set(requested).issubset(granted):
        reason = PolicyReason("within-scope", "all requested regions are granted")
        allowed = True
    else:
        reason = PolicyReason("out-of-scope", "one or more requested regions are not granted")
        allowed = False
    return RegionalScopeDecision(
        subject_id,
        normalized_role,
        requested,
        granted,
        False,
        allowed,
        reason,
    )


@dataclass(frozen=True, slots=True)
class RedactionSpan:
    start: int
    end: int
    category: str
    replacement: str = "[REDACTED]"
    confidence: float = 1.0

    def __post_init__(self) -> None:
        if self.start < 0 or self.end <= self.start:
            raise ValueError("redaction span bounds are invalid")
        require_identifier(self.category, "category")
        require_text(self.replacement, "replacement")
        require_ratio(self.confidence, "confidence")


@dataclass(frozen=True, slots=True)
class RedactionPolicy:
    policy_id: str
    categories: frozenset[str]
    minimum_confidence: float = 0.8
    fail_closed: bool = True

    def __post_init__(self) -> None:
        require_identifier(self.policy_id, "policy_id")
        if not self.categories:
            raise ValueError("categories must not be empty")
        require_ratio(self.minimum_confidence, "minimum_confidence")


@dataclass(frozen=True, slots=True)
class RedactionResult:
    text: str
    applied_spans: tuple[RedactionSpan, ...]
    ignored_spans: tuple[RedactionSpan, ...]
    residual_risk: float
    policy_id: str

    def __post_init__(self) -> None:
        require_ratio(self.residual_risk, "residual_risk")
        require_identifier(self.policy_id, "policy_id")


def redact_text(text: str, spans: tuple[RedactionSpan, ...], policy: RedactionPolicy) -> RedactionResult:
    """Apply non-overlapping approved spans without retaining raw fragments."""
    selected = tuple(
        span
        for span in sorted(spans, key=lambda item: (item.start, item.end))
        if span.category in policy.categories and span.confidence >= policy.minimum_confidence
    )
    ignored = tuple(span for span in spans if span not in selected)
    cursor = 0
    parts: list[str] = []
    for span in selected:
        if span.end > len(text):
            raise ValueError("redaction span exceeds text length")
        if span.start < cursor:
            raise ValueError("redaction spans must not overlap")
        parts.extend((text[cursor : span.start], span.replacement))
        cursor = span.end
    parts.append(text[cursor:])
    residual = 1.0 if policy.fail_closed and ignored else min(1.0, len(ignored) / max(1, len(spans)))
    return RedactionResult("".join(parts), selected, ignored, residual, policy.policy_id)
