"""Project-neutral adoption and runtime health classification for consumers."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from enum import Enum
from typing import Any, Iterable


class ConsumerApplicability(str, Enum):
    """Whether a QazStack integration is expected for a product."""

    REQUIRED = "required"
    OPTIONAL = "optional"
    NOT_APPLICABLE = "not-applicable"
    OWNER_DECISION = "owner-decision"


class ConsumerHealthStatus(str, Enum):
    """Derived adoption state ordered from decision to live proof."""

    HEALTHY = "healthy"
    MISSING = "missing"
    UNTESTED = "untested"
    RUNTIME_UNPROVEN = "runtime-unproven"
    OPTIONAL_NOT_ADOPTED = "optional-not-adopted"
    NOT_APPLICABLE = "not-applicable"
    NEEDS_OWNER_DECISION = "needs-owner-decision"


@dataclass(frozen=True, slots=True)
class ConsumerHealth:
    """Evidence-backed QazStack adoption state for one product.

    ``installed``, ``tested`` and ``runtime_proven`` form a monotonic chain.
    Later evidence cannot be true when the preceding stage is false.
    """

    project_id: str
    applicability: ConsumerApplicability
    installed: bool = False
    tested: bool = False
    runtime_proven: bool = False
    owner: str | None = None
    evidence_refs: tuple[str, ...] = ()
    note: str = ""

    def __post_init__(self) -> None:
        if not self.project_id.strip():
            raise ValueError("project_id must not be blank")
        if self.runtime_proven and not self.tested:
            raise ValueError("runtime_proven requires tested evidence")
        if self.tested and not self.installed:
            raise ValueError("tested requires installed evidence")
        if any(not ref.strip() for ref in self.evidence_refs):
            raise ValueError("evidence_refs must not contain blank values")

    @property
    def status(self) -> ConsumerHealthStatus:
        if self.applicability is ConsumerApplicability.NOT_APPLICABLE:
            return ConsumerHealthStatus.NOT_APPLICABLE
        if self.applicability is ConsumerApplicability.OWNER_DECISION:
            return ConsumerHealthStatus.NEEDS_OWNER_DECISION
        if not self.installed:
            if self.applicability is ConsumerApplicability.OPTIONAL:
                return ConsumerHealthStatus.OPTIONAL_NOT_ADOPTED
            return ConsumerHealthStatus.MISSING
        if not self.tested:
            return ConsumerHealthStatus.UNTESTED
        if not self.runtime_proven:
            return ConsumerHealthStatus.RUNTIME_UNPROVEN
        return ConsumerHealthStatus.HEALTHY

    def as_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["applicability"] = self.applicability.value
        payload["status"] = self.status.value
        return payload


def summarize_consumer_health(consumers: Iterable[ConsumerHealth]) -> dict[str, Any]:
    """Return stable fleet counts without treating optional gaps as failures."""
    items = list(consumers)
    counts = {status.value: 0 for status in ConsumerHealthStatus}
    for consumer in items:
        counts[consumer.status.value] += 1
    blocking = counts[ConsumerHealthStatus.MISSING.value] + counts[ConsumerHealthStatus.UNTESTED.value]
    attention = blocking + counts[ConsumerHealthStatus.RUNTIME_UNPROVEN.value]
    return {
        "status": "error" if blocking else ("attention" if attention else "healthy"),
        "counts": {"total": len(items), **counts},
        "consumers": [consumer.as_dict() for consumer in items],
    }
