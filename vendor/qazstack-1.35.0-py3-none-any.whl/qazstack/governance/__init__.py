"""qazstack.governance – Generic governance toolkit.

A project-agnostic governance library providing:

* **RBAC** – role-based access control with a configurable permission registry
* **Audit trail** – immutable, queryable log of governance actions
* **Parameter versioning** – timestamped snapshots with rollback support
* **Calibration workflow** – structured review process for parameter changes
* **Generated artifacts** – semantic drift checks and atomic JSON publication

All modules are pure Python with zero external dependencies.  Backends use
Python Protocols so you can swap in SQLAlchemy, file-based, or remote
implementations without changing application code.

Quick start::

    import asyncio
    from qazstack.governance import (
        # RBAC
        DefaultRoles,
        RoleRegistry,
        PermissionDeniedError,
        check_permission,
        require_permission,
        # Audit
        AuditTrail,
        AuditEntry,
        AuditBackend,
        InMemoryBackend,
        # Versioning
        VersionStore,
        Version,
        build_version_id,
        # Calibration
        CalibrationBoard,
        CalibrationRequest,
    )

    # --- RBAC ---
    assert check_permission(DefaultRoles.ADMIN, "param_change")
    assert not check_permission(DefaultRoles.VIEWER, "delete")

    registry = RoleRegistry()
    registry.register_role("analyst", {"read", "report"})
    registry.require("analyst", "read")   # OK
    try:
        registry.require("analyst", "delete")
    except PermissionDeniedError as exc:
        print(exc)  # Role 'analyst' does not have permission 'delete'

    # --- Audit ---
    async def audit_demo():
        trail = AuditTrail()
        await trail.log("alice", "param_change", "threshold",
                        old_value={"v": 0.5}, new_value={"v": 0.6},
                        metadata={"version": "v1.0.1"})
        entries = await trail.query(user="alice")
        print(entries[0].action)  # "param_change"

    asyncio.run(audit_demo())

    # --- Versioning ---
    store = VersionStore()
    v1 = store.create_version({"threshold": 0.5}, "alice", "initial",
                               version_id=build_version_id(1, 0, 0))
    v2 = store.create_version({"threshold": 0.6}, "bob", "update")
    store.rollback(v1.version_id)
    assert store.get_active().version_id == v1.version_id

    # --- Calibration ---
    board = CalibrationBoard()
    req = board.create_request(
        requested_by="analyst",
        parameter_name="vol_floor",
        current_value=0.02,
        proposed_value=0.03,
        reason="Elevated volatility",
    )
    board.decide(req.request_id, approved=True,
                 decided_by="head_risk", reason="Backtest passed")
"""

from qazstack.governance.artifacts import (
    DEFAULT_VOLATILE_FIELDS,
    ArtifactCheck,
    ArtifactState,
    check_json_artifact,
    semantically_equal,
    stabilize_artifact,
    write_json_artifact,
    write_text_atomic,
)
from qazstack.governance.audit import (
    AuditBackend,
    AuditEntry,
    AuditTrail,
    InMemoryBackend,
)
from qazstack.governance.calibration import (
    CalibrationBoard,
    CalibrationError,
    CalibrationRequest,
    CalibrationStore,
    InMemoryCalibrationStore,
    InvalidStatusTransitionError,
    RequestNotFoundError,
)
from qazstack.governance.consumer_health import (
    ConsumerApplicability,
    ConsumerHealth,
    ConsumerHealthStatus,
    summarize_consumer_health,
)
from qazstack.governance.contracts import (
    FeatureDecision,
    PolicyReason,
    RedactionPolicy,
    RedactionResult,
    RedactionSpan,
    RegionalScopeDecision,
    WorkflowTransition,
    decide_regional_access,
    redact_text,
    validate_transition,
)
from qazstack.governance.review import (
    InvalidReviewTransition,
    ReviewDecision,
    ReviewDecisionRecord,
    ReviewState,
    canonical_snapshot_hash,
    next_review_state,
)
from qazstack.governance.roles import (
    DefaultRoles,
    PermissionDeniedError,
    Role,
    RoleRegistry,
    check_permission,
    get_default_registry,
    require_permission,
)
from qazstack.governance.versioning import (
    InMemoryVersionBackend,
    Version,
    VersionBackend,
    VersionStore,
    build_version_id,
)

__all__ = [
    # generated artifacts
    "DEFAULT_VOLATILE_FIELDS",
    "ArtifactCheck",
    "ArtifactState",
    "check_json_artifact",
    "semantically_equal",
    "stabilize_artifact",
    "write_json_artifact",
    "write_text_atomic",
    # roles
    "Role",
    "RoleRegistry",
    "DefaultRoles",
    "PermissionDeniedError",
    "check_permission",
    "require_permission",
    "get_default_registry",
    # audit
    "AuditEntry",
    "AuditTrail",
    "AuditBackend",
    "InMemoryBackend",
    # versioning
    "Version",
    "VersionStore",
    "VersionBackend",
    "InMemoryVersionBackend",
    "build_version_id",
    # calibration
    "CalibrationRequest",
    "CalibrationBoard",
    "CalibrationStore",
    "InMemoryCalibrationStore",
    "CalibrationError",
    "RequestNotFoundError",
    "InvalidStatusTransitionError",
    # consumer health
    "ConsumerApplicability",
    "ConsumerHealth",
    "ConsumerHealthStatus",
    "summarize_consumer_health",
    "FeatureDecision",
    "PolicyReason",
    "RegionalScopeDecision",
    "RedactionPolicy",
    "RedactionResult",
    "RedactionSpan",
    "WorkflowTransition",
    "decide_regional_access",
    "redact_text",
    "validate_transition",
    "InvalidReviewTransition",
    "ReviewDecision",
    "ReviewDecisionRecord",
    "ReviewState",
    "canonical_snapshot_hash",
    "next_review_state",
]
