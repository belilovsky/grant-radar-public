"""Parameter versioning for qazstack.governance.

Manages immutable, timestamped snapshots of parameter dictionaries with
activate/deactivate semantics and rollback support.

Pure Python – no external dependencies.

Example::

    from qazstack.governance.versioning import VersionStore, build_version_id

    store = VersionStore()
    ver = store.create_version(
        parameters={"threshold": 0.5, "window": 30},
        created_by="alice",
        reason="Initial calibration",
        version_id=build_version_id(1, 0, 0),
    )
    active = store.get_active()
    print(active.version_id)  # e.g. "v1.0.0-20260412"

    # Roll back to an earlier version
    rolled = store.rollback("v1.0.0-20260412")
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Protocol, runtime_checkable


# ---------------------------------------------------------------------------
# Version dataclass
# ---------------------------------------------------------------------------


@dataclass
class Version:
    """An immutable snapshot of a parameter set.

    Attributes:
        version_id: Human-readable identifier (e.g. ``"v1.3.1-20260412"``).
        parameters: Arbitrary parameter dictionary.
        created_by: Actor who created the version.
        created_at: UTC creation timestamp.
        is_active: Whether this version is currently the active one.
        reason: Free-text explanation for this version.
    """

    version_id: str
    parameters: dict
    created_by: str
    reason: str
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    is_active: bool = False


# ---------------------------------------------------------------------------
# Build helpers
# ---------------------------------------------------------------------------


def build_version_id(major: int, minor: int, patch: int) -> str:
    """Generate a version ID string like ``"v1.3.1-20260412"``.

    Args:
        major: Major version component.
        minor: Minor version component.
        patch: Patch version component.

    Returns:
        Version string with today's UTC date appended.

    Example::

        build_version_id(1, 0, 0)   # "v1.0.0-20260412"
        build_version_id(2, 14, 3)  # "v2.14.3-20260412"
    """
    today = datetime.now(timezone.utc).strftime("%Y%m%d")
    return f"v{major}.{minor}.{patch}-{today}"


# ---------------------------------------------------------------------------
# Backend Protocol
# ---------------------------------------------------------------------------


@runtime_checkable
class VersionBackend(Protocol):
    """Protocol for pluggable version storage backends."""

    def save(self, version: Version) -> None:
        """Persist *version* (insert or update)."""
        ...

    def get(self, version_id: str) -> Version | None:
        """Return the version with the given ID, or ``None``."""
        ...

    def list_all(self) -> list[Version]:
        """Return all versions, ordered newest-first."""
        ...

    def deactivate_all(self) -> None:
        """Set ``is_active = False`` on every stored version."""
        ...


# ---------------------------------------------------------------------------
# InMemoryVersionBackend
# ---------------------------------------------------------------------------


class InMemoryVersionBackend:
    """Thread-safe in-memory version backend (satisfies :class:`VersionBackend`)."""

    def __init__(self) -> None:
        self._store: dict[str, Version] = {}
        self._lock = threading.Lock()

    def save(self, version: Version) -> None:
        with self._lock:
            self._store[version.version_id] = version

    def get(self, version_id: str) -> Version | None:
        with self._lock:
            return self._store.get(version_id)

    def list_all(self) -> list[Version]:
        with self._lock:
            return sorted(
                self._store.values(),
                key=lambda v: v.created_at,
                reverse=True,
            )

    def deactivate_all(self) -> None:
        with self._lock:
            for v in self._store.values():
                v.is_active = False


# ---------------------------------------------------------------------------
# VersionStore
# ---------------------------------------------------------------------------


class VersionStore:
    """Manages parameter versions with activate/deactivate and rollback.

    Only one version is active at any given time.  Creating a new version
    automatically deactivates all existing ones.

    Args:
        backend: Storage backend.  Defaults to :class:`InMemoryVersionBackend`.

    Example::

        store = VersionStore()
        v1 = store.create_version({"x": 1}, "alice", "init")
        v2 = store.create_version({"x": 2}, "bob", "update")
        assert store.get_active().version_id == v2.version_id
        store.rollback(v1.version_id)
        assert store.get_active().version_id == v1.version_id
    """

    def __init__(self, backend: VersionBackend | None = None) -> None:
        self._backend: VersionBackend = backend or InMemoryVersionBackend()

    @property
    def backend(self) -> VersionBackend:
        """The underlying storage backend."""
        return self._backend

    def create_version(
        self,
        parameters: dict,
        created_by: str,
        reason: str,
        version_id: str | None = None,
    ) -> Version:
        """Create and activate a new parameter version.

        Any previously active version is deactivated.

        Args:
            parameters: Dictionary of parameter values to snapshot.
            created_by: Actor creating the version.
            reason: Human-readable explanation for the change.
            version_id: Explicit version identifier.  Auto-generated when
                omitted using :func:`build_version_id` with a patch number
                derived from current count.

        Returns:
            The newly created and activated :class:`Version`.
        """
        if version_id is None:
            existing = self._backend.list_all()
            patch = len(existing) + 1
            version_id = build_version_id(1, 0, patch)

        # Deactivate all existing active versions
        self._backend.deactivate_all()

        version = Version(
            version_id=version_id,
            parameters=parameters,
            created_by=created_by,
            reason=reason,
            is_active=True,
        )
        self._backend.save(version)
        return version

    def get_active(self) -> Version | None:
        """Return the currently active version, or ``None`` if none exists."""
        for v in self._backend.list_all():
            if v.is_active:
                return v
        return None

    def get(self, version_id: str) -> Version | None:
        """Return the version with *version_id*, or ``None``."""
        return self._backend.get(version_id)

    def list_versions(self, limit: int = 20) -> list[Version]:
        """Return up to *limit* versions, newest first.

        Args:
            limit: Maximum number of versions to return.
        """
        return self._backend.list_all()[:limit]

    def rollback(self, version_id: str) -> Version:
        """Activate an existing version, deactivating the current one.

        Args:
            version_id: Identifier of the version to roll back to.

        Returns:
            The reactivated :class:`Version`.

        Raises:
            KeyError: If *version_id* does not exist in the store.
        """
        target = self._backend.get(version_id)
        if target is None:
            raise KeyError(f"Version '{version_id}' not found")

        self._backend.deactivate_all()
        target.is_active = True
        self._backend.save(target)
        return target

    def activate(self, version_id: str) -> Version:
        """Alias for :meth:`rollback` – activate the named version.

        Args:
            version_id: Identifier of the version to activate.

        Returns:
            The activated :class:`Version`.

        Raises:
            KeyError: If *version_id* does not exist in the store.
        """
        return self.rollback(version_id)
