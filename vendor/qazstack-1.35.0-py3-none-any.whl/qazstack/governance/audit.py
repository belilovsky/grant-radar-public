"""Generic audit trail for qazstack.governance.

Provides an in-memory audit backend by default with a Protocol that allows
swap-in of database-backed or file-backed implementations.

Pure Python – no external dependencies.

Example::

    from qazstack.governance.audit import AuditTrail

    trail = AuditTrail()
    await trail.log("alice", "param_change", "threshold",
                    old_value={"v": 0.5}, new_value={"v": 0.6})

    entries = await trail.query(user="alice", limit=10)
    for e in entries:
        print(e.action, e.timestamp)
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Protocol, runtime_checkable


# ---------------------------------------------------------------------------
# AuditEntry
# ---------------------------------------------------------------------------


@dataclass
class AuditEntry:
    """A single immutable record in the audit trail.

    Attributes:
        user: Identifier of the actor (username, user-id, service name).
        action: Verb describing what happened (e.g. ``"param_change"``).
        resource: The resource that was acted on.
        old_value: Serialisable snapshot of the resource before the action.
        new_value: Serialisable snapshot after the action.
        timestamp: UTC time the entry was created.
        metadata: Arbitrary key/value pairs for application-specific context.
        entry_id: Auto-assigned monotonic counter within the process.
    """

    user: str
    action: str
    resource: str
    old_value: Any = None
    new_value: Any = None
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    metadata: dict[str, Any] = field(default_factory=dict)
    entry_id: int = field(default=0)


# ---------------------------------------------------------------------------
# Backend Protocol
# ---------------------------------------------------------------------------


@runtime_checkable
class AuditBackend(Protocol):
    """Protocol that custom audit storage backends must implement.

    Both methods are *async* to allow non-blocking I/O in FastAPI, async
    workers, or any asyncio context.  Use ``asyncio.run()`` or
    ``await`` from a coroutine.
    """

    async def write(self, entry: AuditEntry) -> None:
        """Persist *entry* to the backend store."""
        ...

    async def query(
        self,
        *,
        user: str | None = None,
        action: str | None = None,
        resource: str | None = None,
        since: datetime | None = None,
        limit: int = 100,
    ) -> list[AuditEntry]:
        """Return entries matching all supplied filters, newest first."""
        ...


# ---------------------------------------------------------------------------
# InMemoryBackend
# ---------------------------------------------------------------------------


class InMemoryBackend:
    """Thread-safe in-memory audit backend (satisfies :class:`AuditBackend`).

    All entries are stored in a simple list.  Suitable for testing and
    applications that do not need persistence across restarts.

    Args:
        max_entries: Maximum entries to keep in memory.  Oldest entries are
            discarded when the limit is exceeded.  ``0`` means unlimited.
    """

    def __init__(self, max_entries: int = 0) -> None:
        self._entries: list[AuditEntry] = []
        # The store is also created during synchronous application bootstrap.
        # A threading lock avoids binding this tiny in-memory critical section
        # to an event loop that may not exist yet.
        self._lock = threading.RLock()
        self.max_entries = max_entries

    async def write(self, entry: AuditEntry) -> None:
        """Append *entry* to in-memory storage."""
        with self._lock:
            self._entries.append(entry)
            if self.max_entries and len(self._entries) > self.max_entries:
                # Trim oldest entries
                self._entries = self._entries[-self.max_entries:]

    async def query(
        self,
        *,
        user: str | None = None,
        action: str | None = None,
        resource: str | None = None,
        since: datetime | None = None,
        limit: int = 100,
    ) -> list[AuditEntry]:
        """Return filtered entries, newest first.

        Args:
            user: Filter by exact user identifier.
            action: Filter by exact action string.
            resource: Filter by exact resource string.
            since: Return only entries at or after this UTC datetime.
            limit: Maximum number of entries to return.
        """
        with self._lock:
            results: list[AuditEntry] = []
            for entry in reversed(self._entries):
                if user is not None and entry.user != user:
                    continue
                if action is not None and entry.action != action:
                    continue
                if resource is not None and entry.resource != resource:
                    continue
                if since is not None and entry.timestamp < since:
                    continue
                results.append(entry)
                if len(results) >= limit:
                    break
            return results

    def clear(self) -> None:
        """Remove all entries (synchronous, intended for test teardown)."""
        self._entries.clear()

    @property
    def count(self) -> int:
        """Total number of entries currently stored."""
        return len(self._entries)


# ---------------------------------------------------------------------------
# AuditTrail – high-level API
# ---------------------------------------------------------------------------


class AuditTrail:
    """High-level audit trail that delegates persistence to an :class:`AuditBackend`.

    By default an :class:`InMemoryBackend` is used.

    Args:
        backend: Storage backend.  Defaults to a new :class:`InMemoryBackend`.

    Example::

        trail = AuditTrail()
        await trail.log("bob", "login", "auth_service")
        entries = await trail.query(user="bob")
    """

    def __init__(self, backend: AuditBackend | None = None) -> None:
        self._backend: AuditBackend = backend or InMemoryBackend()
        self._counter = 0

    @property
    def backend(self) -> AuditBackend:
        """The underlying backend instance."""
        return self._backend

    async def log(
        self,
        user: str,
        action: str,
        resource: str,
        *,
        old_value: Any = None,
        new_value: Any = None,
        metadata: dict[str, Any] | None = None,
    ) -> AuditEntry:
        """Create and persist a new audit entry.

        Args:
            user: Actor identifier.
            action: Action verb (e.g. ``"create"``, ``"delete"``).
            resource: Name / identifier of the affected resource.
            old_value: Resource state before the action.
            new_value: Resource state after the action.
            metadata: Extra context dictionary.

        Returns:
            The persisted :class:`AuditEntry`.
        """
        self._counter += 1
        entry = AuditEntry(
            user=user,
            action=action,
            resource=resource,
            old_value=old_value,
            new_value=new_value,
            metadata=metadata or {},
            entry_id=self._counter,
        )
        await self._backend.write(entry)
        return entry

    async def query(
        self,
        *,
        user: str | None = None,
        action: str | None = None,
        resource: str | None = None,
        since: datetime | None = None,
        limit: int = 100,
    ) -> list[AuditEntry]:
        """Query the audit trail with optional filters.

        Args:
            user: Filter by user identifier.
            action: Filter by action string.
            resource: Filter by resource string.
            since: Earliest timestamp (UTC) to include.
            limit: Maximum results to return (default 100).

        Returns:
            List of :class:`AuditEntry` objects, newest first.
        """
        return await self._backend.query(
            user=user,
            action=action,
            resource=resource,
            since=since,
            limit=limit,
        )
