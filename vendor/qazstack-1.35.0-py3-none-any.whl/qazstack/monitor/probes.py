"""Small reusable health and threshold result primitives."""

from __future__ import annotations

import time
from dataclasses import asdict, dataclass
from typing import Any

import httpx


@dataclass(frozen=True, slots=True)
class ProbeResult:
    name: str
    status: str
    elapsed_ms: float = 0.0
    detail: str = ""

    @property
    def ok(self) -> bool:
        return self.status == "ok"

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def threshold_probe(
    name: str,
    value: float,
    *,
    warning: float | None = None,
    critical: float | None = None,
    lower_is_better: bool = True,
) -> ProbeResult:
    """Classify one metric against warning and critical boundaries."""

    def crossed(boundary: float | None) -> bool:
        if boundary is None:
            return False
        return value > boundary if lower_is_better else value < boundary

    status = "error" if crossed(critical) else ("warning" if crossed(warning) else "ok")
    return ProbeResult(name=name, status=status, detail=str(value))


def http_probe(
    name: str,
    url: str,
    *,
    expected_status: int = 200,
    timeout: float = 10.0,
    client: httpx.Client | None = None,
) -> ProbeResult:
    started = time.monotonic()
    owned = client is None
    active = client or httpx.Client(timeout=timeout, follow_redirects=False)
    try:
        response = active.get(url)
        status = "ok" if response.status_code == expected_status else "error"
        detail = f"HTTP {response.status_code}"
    except httpx.HTTPError as exc:
        status = "error"
        detail = exc.__class__.__name__
    finally:
        if owned:
            active.close()
    return ProbeResult(name, status, round((time.monotonic() - started) * 1000, 1), detail)


def summarize_probes(results: list[ProbeResult]) -> dict[str, Any]:
    errors = sum(result.status == "error" for result in results)
    warnings = sum(result.status == "warning" for result in results)
    return {
        "status": "error" if errors else ("warning" if warnings else "ok"),
        "counts": {"total": len(results), "errors": errors, "warnings": warnings},
        "checks": [result.as_dict() for result in results],
    }
