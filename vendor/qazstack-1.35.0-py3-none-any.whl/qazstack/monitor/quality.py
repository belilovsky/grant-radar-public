"""Comparable freshness and completeness observations for operator systems."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from qazstack.contracts._validation import require_aware, require_identifier, require_positive, require_ratio


@dataclass(frozen=True, slots=True)
class DataQualityObservation:
    source_id: str
    observed_at: datetime
    source_updated_at: datetime | None
    stale_after_seconds: int
    completeness: float
    reasons: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        require_identifier(self.source_id, "source_id")
        require_aware(self.observed_at, "observed_at")
        if self.source_updated_at is not None:
            require_aware(self.source_updated_at, "source_updated_at")
            if self.source_updated_at > self.observed_at:
                raise ValueError("source_updated_at cannot be after observed_at")
        require_positive(self.stale_after_seconds, "stale_after_seconds")
        require_ratio(self.completeness, "completeness")
        if any(not reason.strip() for reason in self.reasons):
            raise ValueError("reasons must contain non-empty values")

    @property
    def age_seconds(self) -> float | None:
        if self.source_updated_at is None:
            return None
        return (self.observed_at - self.source_updated_at).total_seconds()

    @property
    def status(self) -> str:
        if self.source_updated_at is None:
            return "unknown"
        if self.age_seconds is not None and self.age_seconds > self.stale_after_seconds:
            return "stale"
        if self.completeness < 1.0 or self.reasons:
            return "degraded"
        return "fresh"
