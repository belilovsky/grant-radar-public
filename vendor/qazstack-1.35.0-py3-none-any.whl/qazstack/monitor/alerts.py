"""Alert manager – create, deduplicate, and dispatch alerts.

Supports multiple notification channels (Telegram, webhook) with
per-subject cooldown to prevent alert storms.

Uses ``qazstack.telegram.TelegramAlert`` under the hood for Telegram
delivery, keeping a single Telegram implementation in the codebase.

Usage::

    from qazstack.monitor.alerts import AlertManager, TelegramChannel, WebhookChannel

    mgr = AlertManager(
        channels=[
            TelegramChannel(bot_token="123:ABC", chat_id="-100123"),
            WebhookChannel(url="https://hooks.example.com/alerts"),
        ],
        cooldown_seconds=900,  # 15 min
    )

    alert = await mgr.fire(
        alert_type="state_change",
        severity="critical",
        subject="echo-sounder:health",
        message="Health endpoint returned 500",
    )
"""

from __future__ import annotations

import logging
import time
from typing import Any, Protocol

import httpx

logger = logging.getLogger("qazstack.monitor.alerts")

_SEVERITY_EMOJI = {
    "info": "\u2139\ufe0f",
    "warning": "\u26a0\ufe0f",
    "critical": "\U0001f534",
}


class AlertChannel(Protocol):
    """Protocol for alert delivery channels."""

    async def send(self, severity: str, subject: str, message: str, **kwargs: Any) -> bool:
        """Send an alert. Returns True on success."""
        ...  # pragma: no cover


class TelegramChannel:
    """Send alerts via Telegram Bot API (uses httpx directly)."""

    API_URL = "https://api.telegram.org/bot{token}/sendMessage"

    def __init__(self, bot_token: str, chat_id: str | int, *, timeout: float = 10.0):
        self.bot_token = bot_token
        self.chat_id = str(chat_id)
        self.timeout = timeout
        self._url = self.API_URL.format(token=bot_token)

    async def send(self, severity: str, subject: str, message: str, **kwargs: Any) -> bool:
        """Format and send alert to Telegram."""
        emoji = _SEVERITY_EMOJI.get(severity, "\u2753")
        text = f"{emoji} <b>{subject}</b>\n\n{message}"
        payload = {
            "chat_id": self.chat_id,
            "text": text,
            "parse_mode": "HTML",
        }
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.post(self._url, json=payload)
                if resp.status_code == 200:
                    return True
                logger.warning("Telegram API error %s: %s", resp.status_code, resp.text)
                return False
        except Exception as e:
            logger.error("Failed to send Telegram alert: %s", e)
            return False


class WebhookChannel:
    """Send alerts via HTTP POST webhook."""

    def __init__(self, url: str, *, headers: dict[str, str] | None = None, timeout: float = 10.0):
        self.url = url
        self.headers = headers or {}
        self.timeout = timeout

    async def send(self, severity: str, subject: str, message: str, **kwargs: Any) -> bool:
        """POST alert payload as JSON to the webhook URL."""
        payload = {
            "severity": severity,
            "subject": subject,
            "message": message,
            **kwargs,
        }
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.post(self.url, json=payload, headers=self.headers)
                return 200 <= resp.status_code < 300
        except Exception as e:
            logger.error("Failed to send webhook alert to %s: %s", self.url, e)
            return False


class AlertManager:
    """Manages alert creation, deduplication, and dispatch.

    Alerts with the same ``cooldown_key`` are suppressed for
    ``cooldown_seconds`` after the first fire.

    Args:
        channels: List of AlertChannel implementations to dispatch to.
        cooldown_seconds: Minimum seconds between alerts with same cooldown_key.
    """

    def __init__(self, channels: list[AlertChannel] | None = None, *, cooldown_seconds: int = 900):
        self.channels: list[AlertChannel] = channels or []
        self.cooldown_seconds = cooldown_seconds
        self._cooldowns: dict[str, float] = {}  # cooldown_key → monotonic timestamp

    def _is_cooled_down(self, cooldown_key: str) -> bool:
        """Check if an alert with this key is still in cooldown."""
        last = self._cooldowns.get(cooldown_key)
        if last is None:
            return False
        return (time.monotonic() - last) < self.cooldown_seconds

    def _set_cooldown(self, cooldown_key: str) -> None:
        """Set cooldown for a key."""
        self._cooldowns[cooldown_key] = time.monotonic()

    async def fire(
        self,
        alert_type: str,
        severity: str,
        subject: str,
        message: str,
        *,
        cooldown_key: str | None = None,
        details: dict | None = None,
    ) -> dict | None:
        """Create and dispatch an alert if not in cooldown.

        Args:
            alert_type: Category (state_change, anomaly, threshold, escalation).
            severity: Level (info, warning, critical).
            subject: What triggered it (e.g. "echo-sounder:health").
            message: Human-readable description.
            cooldown_key: Dedup key. Defaults to ``subject`` if not given.
            details: Extra context dict.

        Returns:
            Alert dict if dispatched, None if suppressed by cooldown.
        """
        key = cooldown_key or subject

        if self._is_cooled_down(key):
            logger.debug("Alert suppressed by cooldown: %s", key)
            return None

        self._set_cooldown(key)

        channels_notified: list[str] = []
        for channel in self.channels:
            try:
                ok = await channel.send(severity=severity, subject=subject, message=message)
                if ok:
                    channels_notified.append(type(channel).__name__)
            except Exception as e:
                logger.error("Channel %s failed: %s", type(channel).__name__, e)

        return {
            "alert_type": alert_type,
            "severity": severity,
            "subject": subject,
            "message": message,
            "details": details or {},
            "channels_notified": channels_notified,
            "cooldown_key": key,
        }

    def clear_cooldown(self, cooldown_key: str) -> None:
        """Clear cooldown for a specific key (e.g. on recovery)."""
        self._cooldowns.pop(cooldown_key, None)

    def clear_all_cooldowns(self) -> None:
        """Reset all cooldowns."""
        self._cooldowns.clear()
