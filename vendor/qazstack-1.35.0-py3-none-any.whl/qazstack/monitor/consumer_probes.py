"""Registry-driven HTTP smoke checks for QazStack service consumers."""

from __future__ import annotations

import json
import time
from dataclasses import dataclass
from typing import Any, Iterable, Literal, Mapping

import httpx

from .probes import ProbeResult, summarize_probes

ResponseKind = Literal["json-dict", "json-list", "html", "javascript", "text"]


@dataclass(frozen=True, slots=True)
class ConsumerProbe:
    """One public or operator-only endpoint check from a consumer registry."""

    name: str
    url: str
    response_kind: ResponseKind = "json-dict"
    method: str = "GET"
    expected_status: int = 200
    scope: str = "public"
    json_body: Any | None = None
    expect_contains: tuple[str, ...] = ()
    timeout: float = 10.0
    expect_absent: tuple[str, ...] = ()
    require_headers: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not self.name.strip() or not self.url.strip():
            raise ValueError("probe name and url must not be blank")
        if self.method.upper() not in {"GET", "HEAD", "POST", "PUT", "PATCH", "DELETE"}:
            raise ValueError(f"unsupported HTTP method: {self.method}")
        if not 100 <= self.expected_status <= 599:
            raise ValueError("expected_status must be a valid HTTP status")
        if any(not header.strip() for header in self.require_headers):
            raise ValueError("required header names must not be blank")
        if self.timeout <= 0:
            raise ValueError("timeout must be positive")

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> ConsumerProbe:
        return cls(
            name=str(value["name"]),
            url=str(value["url"]),
            response_kind=value.get("response_kind", value.get("expect_kind", "json-dict")),
            method=str(value.get("method", "GET")),
            expected_status=int(value.get("expected_status", 200)),
            scope=str(value.get("scope", "public")),
            json_body=value.get("json_body"),
            expect_contains=tuple(str(item) for item in value.get("expect_contains", ())),
            expect_absent=tuple(str(item) for item in value.get("expect_absent", ())),
            require_headers=tuple(str(item).lower() for item in value.get("require_headers", ())),
            timeout=float(value.get("timeout", 10.0)),
        )


def probes_from_registry(
    registry: Mapping[str, Any],
    *,
    include_private: bool = False,
    host: str | None = None,
) -> list[ConsumerProbe]:
    """Read verified smoke endpoints from a QazStack-style consumer registry."""
    probes: list[ConsumerProbe] = []
    for consumer in registry.get("consumers", ()):
        if host and consumer.get("host") != host:
            continue
        verification = consumer.get("verification") or {}
        if verification.get("status") != "verified":
            continue
        for raw_probe in verification.get("smoke_endpoints", ()):
            probe = ConsumerProbe.from_mapping(raw_probe)
            if probe.scope != "public" and not include_private:
                continue
            probes.append(probe)
    return probes


def validate_probe_response(probe: ConsumerProbe, response: httpx.Response) -> tuple[bool, str]:
    """Validate status, response shape and optional stable body markers."""
    if response.status_code != probe.expected_status:
        return False, f"HTTP {response.status_code}, expected {probe.expected_status}"

    missing_headers = [header for header in probe.require_headers if not response.headers.get(header)]
    if missing_headers:
        return False, f"missing headers: {', '.join(missing_headers)}"

    content_type = response.headers.get("content-type", "").lower()
    body = response.text
    if probe.response_kind in {"json-dict", "json-list"}:
        try:
            payload = response.json()
        except (json.JSONDecodeError, ValueError):
            return False, f"invalid JSON ({content_type or 'content type missing'})"
        expected_type = dict if probe.response_kind == "json-dict" else list
        if not isinstance(payload, expected_type) or not payload:
            return False, f"expected non-empty {expected_type.__name__}"
    elif probe.response_kind == "html":
        if "text/html" not in content_type or "<html" not in body.lower():
            return False, f"invalid HTML ({content_type or 'content type missing'})"
    elif probe.response_kind == "javascript":
        valid_type = any(kind in content_type for kind in ("javascript", "ecmascript", "text/plain"))
        if not valid_type or not body.strip():
            return False, f"invalid JavaScript ({content_type or 'content type missing'})"
    elif probe.response_kind == "text":
        if not body.strip():
            return False, "empty text response"
    else:
        return False, f"unknown response kind: {probe.response_kind}"

    missing = [marker for marker in probe.expect_contains if marker not in body]
    if missing:
        return False, f"missing markers: {', '.join(missing)}"
    unexpected = [marker for marker in probe.expect_absent if marker in body]
    if unexpected:
        return False, f"unexpected markers: {', '.join(unexpected)}"
    return True, probe.response_kind


def run_consumer_probe(probe: ConsumerProbe, *, client: httpx.Client | None = None) -> ProbeResult:
    """Execute one smoke check while keeping credentials outside the registry."""
    started = time.monotonic()
    owned = client is None
    active = client or httpx.Client(timeout=probe.timeout, follow_redirects=True)
    try:
        response = active.request(probe.method.upper(), probe.url, json=probe.json_body)
        ok, detail = validate_probe_response(probe, response)
        status = "ok" if ok else "error"
    except httpx.HTTPError as exc:
        status = "error"
        detail = exc.__class__.__name__
    finally:
        if owned:
            active.close()
    elapsed_ms = round((time.monotonic() - started) * 1000, 1)
    return ProbeResult(probe.name, status, elapsed_ms, detail)


def run_consumer_probes(
    probes: Iterable[ConsumerProbe],
    *,
    client: httpx.Client | None = None,
) -> dict[str, Any]:
    """Execute a probe matrix and return the standard QazStack summary."""
    return summarize_probes([run_consumer_probe(probe, client=client) for probe in probes])
