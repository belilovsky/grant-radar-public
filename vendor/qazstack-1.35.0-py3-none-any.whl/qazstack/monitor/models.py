"""SQLAlchemy 2.0 models for the unified monitoring module.

Provides five core tables:
- ``Source`` – data source definitions (Telegram channel, RSS feed, website, etc.)
- ``Message`` – unified content collected from any source
- ``AnalysisResult`` – NLP/analysis output per message
- ``Alert`` – alert/notification records with cooldown support
- ``CheckResult`` – health/status check results (platform-monitor pattern)

Uses a separate ``MonitorBase`` so the monitor tables can target a dedicated DB.

Usage::

    from qazstack.monitor.models import MonitorBase, Source, Message, AnalysisResult, Alert, CheckResult
    from sqlalchemy.ext.asyncio import create_async_engine

    engine = create_async_engine("postgresql+asyncpg://...")
    async with engine.begin() as conn:
        await conn.run_sync(MonitorBase.metadata.create_all)
"""

from __future__ import annotations

import hashlib
from datetime import datetime
from typing import Any

from sqlalchemy import (
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    JSON,
    MetaData,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

# Naming convention matching qazstack.core.database
convention = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}


class MonitorBase(DeclarativeBase):
    """Separate declarative base for monitor tables.

    Can target a different database from the main app if needed.
    """

    metadata = MetaData(naming_convention=convention)


class Source(MonitorBase):
    """A data source: Telegram channel, RSS feed, website, etc."""

    __tablename__ = "monitor_sources"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    source_type: Mapped[str] = mapped_column(String(50), nullable=False)  # telegram, rss, http, smi, youtube
    project: Mapped[str] = mapped_column(String(100), nullable=False)  # owning project
    config: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)  # source-specific (url, channel_id, etc.)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    check_interval_s: Mapped[int] = mapped_column(Integer, default=300)
    last_checked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        Index("ix_monitor_sources_type", "source_type"),
        Index("ix_monitor_sources_project", "project"),
    )


class Message(MonitorBase):
    """Unified message/content from any source."""

    __tablename__ = "monitor_messages"

    id: Mapped[int] = mapped_column(primary_key=True)
    source_id: Mapped[int] = mapped_column(ForeignKey("monitor_sources.id"), index=True)
    external_id: Mapped[str | None] = mapped_column(String(500), nullable=True)
    title: Mapped[str | None] = mapped_column(Text, nullable=True)
    text: Mapped[str] = mapped_column(Text, nullable=False)
    url: Mapped[str | None] = mapped_column(Text, nullable=True)
    author: Mapped[str | None] = mapped_column(String(200), nullable=True)
    published_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    collected_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    metadata_: Mapped[dict[str, Any]] = mapped_column("metadata", JSON, default=dict)
    content_hash: Mapped[str] = mapped_column(String(64), index=True)

    __table_args__ = (
        Index("ix_msg_source_published", "source_id", "published_at"),
        UniqueConstraint("source_id", "external_id", name="uq_msg_source_external"),
    )

    @staticmethod
    def compute_hash(text: str) -> str:
        """SHA-256 hash of text for deduplication."""
        return hashlib.sha256(text.encode("utf-8")).hexdigest()


class AnalysisResult(MonitorBase):
    """NLP/analysis output for a message."""

    __tablename__ = "monitor_analysis"

    id: Mapped[int] = mapped_column(primary_key=True)
    message_id: Mapped[int] = mapped_column(ForeignKey("monitor_messages.id"), index=True)
    analysis_type: Mapped[str] = mapped_column(String(50), nullable=False)  # sentiment, ner, embedding, lang_detect
    model_name: Mapped[str] = mapped_column(String(200), nullable=False)
    result: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False)
    status: Mapped[str] = mapped_column(String(20), default="success")  # success, error, skipped
    duration_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)
    processed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        UniqueConstraint("message_id", "analysis_type", name="uq_analysis_msg_type"),
    )


class Alert(MonitorBase):
    """Unified alert/notification record."""

    __tablename__ = "monitor_alerts"

    id: Mapped[int] = mapped_column(primary_key=True)
    source_id: Mapped[int | None] = mapped_column(ForeignKey("monitor_sources.id"), nullable=True)
    alert_type: Mapped[str] = mapped_column(String(50), nullable=False)  # state_change, anomaly, threshold, escalation
    severity: Mapped[str] = mapped_column(String(20), nullable=False)  # info, warning, critical
    subject: Mapped[str] = mapped_column(String(200), nullable=False)
    message: Mapped[str] = mapped_column(Text, nullable=False)
    details: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    channels_notified: Mapped[list[str]] = mapped_column(JSON, default=list)
    cooldown_key: Mapped[str | None] = mapped_column(String(200), nullable=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    __table_args__ = (
        Index("ix_monitor_alerts_type_sev", "alert_type", "severity"),
    )


class CheckResult(MonitorBase):
    """Health/status check result (from platform-monitor pattern)."""

    __tablename__ = "monitor_checks"

    id: Mapped[int] = mapped_column(primary_key=True)
    source_id: Mapped[int] = mapped_column(ForeignKey("monitor_sources.id"), index=True)
    checker: Mapped[str] = mapped_column(String(50), nullable=False)  # health, docker, ssl, seo, etc.
    status: Mapped[str] = mapped_column(String(20), nullable=False)  # ok, warn, error, unknown
    message: Mapped[str] = mapped_column(Text, default="")
    details: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    response_ms: Mapped[float | None] = mapped_column(Float, nullable=True)
    checked_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
