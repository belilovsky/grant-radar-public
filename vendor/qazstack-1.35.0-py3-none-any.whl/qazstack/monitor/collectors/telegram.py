"""Telegram channel collector adapter.

Thin wrapper that converts Telethon ``NewMessage`` events into
``CollectorResult`` objects. The actual Telethon client is managed
by the calling project – this module only provides the adapter layer.

Requires ``telethon``: this is NOT included in qazstack[monitor]
because Telethon needs API credentials and a running event loop.
Projects that use Telegram collection install Telethon themselves.

Usage::

    from telethon import TelegramClient, events
    from qazstack.monitor.collectors.telegram import TelegramAdapter

    adapter = TelegramAdapter()
    client = TelegramClient(...)

    @client.on(events.NewMessage(chats=channels))
    async def handler(event):
        result = adapter.from_event(event)
        if result:
            await store.add_message(session, source_id=src.id, result=result)
"""

from __future__ import annotations

import logging
from datetime import timezone
from typing import Any, AsyncIterator

from qazstack.monitor.collectors.base import CollectorResult

logger = logging.getLogger("qazstack.monitor.collectors.telegram")


class TelegramAdapter:
    """Adapt Telethon events to CollectorResult."""

    source_type: str = "telegram"

    def from_event(self, event: Any) -> CollectorResult | None:
        """Convert a Telethon NewMessage event to CollectorResult.

        Args:
            event: Telethon ``events.NewMessage.Event`` instance.

        Returns:
            CollectorResult if the event has text, None otherwise.
        """
        message = getattr(event, "message", event)
        text = getattr(message, "text", "") or getattr(message, "raw_text", "") or ""
        if not text:
            return None

        date = getattr(message, "date", None)
        if date and date.tzinfo is None:
            date = date.replace(tzinfo=timezone.utc)

        chat = getattr(message, "chat", None)
        chat_title = getattr(chat, "title", "") or getattr(chat, "username", "") or ""

        sender = getattr(message, "sender", None)
        author = None
        if sender:
            first = getattr(sender, "first_name", "") or ""
            last = getattr(sender, "last_name", "") or ""
            author = f"{first} {last}".strip() or getattr(sender, "username", None)

        return CollectorResult(
            text=text,
            title=None,
            url=None,
            author=author,
            published_at=date,
            external_id=str(getattr(message, "id", "")),
            metadata={
                "chat_title": chat_title,
                "chat_id": getattr(chat, "id", None),
                "message_id": getattr(message, "id", None),
                "views": getattr(message, "views", None),
                "forwards": getattr(message, "forwards", None),
            },
        )

    async def collect(self, source_config: dict) -> AsyncIterator[CollectorResult]:
        """Not used – Telegram collection is event-driven via from_event().

        This is a no-op to satisfy the BaseCollector protocol.
        """
        return
        yield  # pragma: no cover – makes this a proper async generator

    async def health_check(self, source_config: dict) -> bool:
        """Always returns True – actual Telethon connectivity is managed externally."""
        return True
