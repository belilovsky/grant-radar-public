"""Collectors – fetch data from external sources.

Provides a base protocol and concrete collectors for RSS feeds,
HTTP endpoints, and Telegram channels.

Usage::

    from qazstack.monitor.collectors import RSSCollector, HTTPChecker, CollectorResult

    rss = RSSCollector()
    async for item in rss.collect({"url": "https://example.com/rss"}):
        print(item.title, item.text[:80])

    http = HTTPChecker()
    async for check in http.collect({"url": "https://example.com/health"}):
        print(check.title, check.metadata)
"""

from qazstack.monitor.collectors.base import BaseCollector, CollectorResult

try:
    from qazstack.monitor.collectors.rss import RSSCollector
except ImportError:
    RSSCollector = None  # type: ignore[assignment,misc]

from qazstack.monitor.collectors.http import HTTPChecker

try:
    from qazstack.monitor.collectors.telegram import TelegramAdapter
except ImportError:
    TelegramAdapter = None  # type: ignore[assignment,misc]

__all__ = [
    "BaseCollector",
    "CollectorResult",
    "RSSCollector",
    "HTTPChecker",
    "TelegramAdapter",
]
