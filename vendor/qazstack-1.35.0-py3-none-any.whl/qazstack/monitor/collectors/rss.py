"""RSS/Atom feed collector.

Requires ``feedparser``: ``pip install qazstack[monitor]``

Usage::

    from qazstack.monitor.collectors import RSSCollector

    rss = RSSCollector()
    async for item in rss.collect({"url": "https://example.com/rss"}):
        print(item.title, item.published_at)
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from time import mktime
from typing import AsyncIterator

import feedparser

from qazstack.monitor.collectors.base import CollectorResult

logger = logging.getLogger("qazstack.monitor.collectors.rss")


class RSSCollector:
    """Collect entries from RSS/Atom feeds."""

    source_type: str = "rss"

    async def collect(self, source_config: dict) -> AsyncIterator[CollectorResult]:
        """Parse an RSS/Atom feed and yield entries.

        Config keys:
            url (str): Feed URL (required).
            max_items (int): Maximum entries to return (default 50).
        """
        url = source_config.get("url", "")
        if not url:
            logger.warning("RSS collector: no url in config")
            return

        max_items = source_config.get("max_items", 50)

        try:
            feed = feedparser.parse(url)
        except Exception as e:
            logger.error("Failed to parse RSS feed %s: %s", url, e)
            return

        for entry in feed.entries[:max_items]:
            published_at = None
            if hasattr(entry, "published_parsed") and entry.published_parsed:
                try:
                    published_at = datetime.fromtimestamp(mktime(entry.published_parsed), tz=timezone.utc)
                except (OverflowError, OSError, ValueError):
                    pass

            text = ""
            if hasattr(entry, "summary"):
                text = entry.summary
            elif hasattr(entry, "description"):
                text = entry.description
            elif hasattr(entry, "content") and entry.content:
                text = entry.content[0].get("value", "")

            if not text:
                text = getattr(entry, "title", "")

            yield CollectorResult(
                title=getattr(entry, "title", None),
                text=text,
                url=getattr(entry, "link", None),
                author=getattr(entry, "author", None),
                published_at=published_at,
                external_id=getattr(entry, "id", getattr(entry, "link", None)),
                metadata={
                    "feed_title": getattr(feed.feed, "title", ""),
                    "tags": [t.get("term", "") for t in getattr(entry, "tags", [])],
                },
            )

    async def health_check(self, source_config: dict) -> bool:
        """Check if the feed URL is parseable."""
        url = source_config.get("url", "")
        if not url:
            return False
        try:
            feed = feedparser.parse(url)
            return feed.bozo == 0 or len(feed.entries) > 0
        except Exception:
            return False
