"""HTTP health/content checker.

Uses httpx (core qazstack dependency) to check HTTP endpoints.

Usage::

    from qazstack.monitor.collectors import HTTPChecker

    http = HTTPChecker()
    async for result in http.collect({"url": "https://example.com/health"}):
        print(result.metadata["status_code"], result.metadata["response_ms"])
"""

from __future__ import annotations

import logging
import time
from typing import AsyncIterator

import httpx

import os as _proxy_os


def _get_proxy_kwargs():
    """Return proxy kwargs for httpx.AsyncClient from ROTA_PROXY_URL env."""
    _url = _proxy_os.environ.get("ROTA_PROXY_URL", "")
    return {"proxy": _url} if _url else {}


from qazstack.monitor.collectors.base import CollectorResult

logger = logging.getLogger("qazstack.monitor.collectors.http")


class HTTPChecker:
    """Check HTTP endpoints for health/availability."""

    source_type: str = "http"

    def __init__(self, *, timeout: float = 10.0, follow_redirects: bool = True):
        self.timeout = timeout
        self.follow_redirects = follow_redirects

    async def collect(self, source_config: dict) -> AsyncIterator[CollectorResult]:
        """Check an HTTP endpoint and yield a single result.

        Config keys:
            url (str): URL to check (required).
            method (str): HTTP method, default "GET".
            expected_status (int): Expected status code, default 200.
            expect_json (bool): Whether to validate JSON response, default False.
        """
        url = source_config.get("url", "")
        if not url:
            logger.warning("HTTP checker: no url in config")
            return

        method = source_config.get("method", "GET").upper()
        expected_status = source_config.get("expected_status", 200)
        expect_json = source_config.get("expect_json", False)

        status = "error"
        message = ""
        status_code = 0
        response_ms = 0.0
        body_preview = ""

        try:
            async with httpx.AsyncClient(
                timeout=self.timeout,
                follow_redirects=self.follow_redirects,
                **_get_proxy_kwargs(),
            ) as client:
                start = time.monotonic()
                resp = await client.request(method, url)
                response_ms = round((time.monotonic() - start) * 1000, 1)
                status_code = resp.status_code

                if status_code == expected_status:
                    status = "ok"
                    message = f"{method} {url} → {status_code} ({response_ms}ms)"
                else:
                    status = "error"
                    message = f"{method} {url} → {status_code} (expected {expected_status})"

                if expect_json:
                    try:
                        resp.json()
                    except Exception:
                        status = "error"
                        message += " – invalid JSON response"

                body_preview = resp.text[:500] if resp.text else ""

        except httpx.TimeoutException:
            status = "error"
            message = f"{method} {url} – timeout after {self.timeout}s"
        except httpx.ConnectError as e:
            status = "error"
            message = f"{method} {url} – connection error: {e}"
        except Exception as e:
            status = "error"
            message = f"{method} {url} – {type(e).__name__}: {e}"

        yield CollectorResult(
            title=f"HTTP check: {url}",
            text=message,
            url=url,
            external_id=url,
            metadata={
                "status": status,
                "status_code": status_code,
                "response_ms": response_ms,
                "body_preview": body_preview,
                "checker": "http",
            },
        )

    async def health_check(self, source_config: dict) -> bool:
        """Check if the URL is reachable with any status code."""
        url = source_config.get("url", "")
        if not url:
            return False
        try:
            async with httpx.AsyncClient(timeout=self.timeout, **_get_proxy_kwargs()) as client:
                resp = await client.head(url, follow_redirects=True)
                return resp.status_code < 500
        except Exception:
            return False
