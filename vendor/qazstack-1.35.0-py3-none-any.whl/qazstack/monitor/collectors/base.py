"""Base collector protocol and result dataclass.

All collectors implement ``BaseCollector`` and yield ``CollectorResult``
objects. The store layer converts these into ``Message`` model instances.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import AsyncIterator, Protocol, runtime_checkable


@dataclass
class CollectorResult:
    """One collected item from any source."""

    text: str
    title: str | None = None
    url: str | None = None
    author: str | None = None
    published_at: datetime | None = None
    external_id: str | None = None
    metadata: dict = field(default_factory=dict)


@runtime_checkable
class BaseCollector(Protocol):
    """Protocol for all collectors.

    Implementations must define ``source_type`` and implement
    ``collect()`` and ``health_check()``.
    """

    source_type: str

    async def collect(self, source_config: dict) -> AsyncIterator[CollectorResult]:
        """Yield collected items from the source.

        Args:
            source_config: Source-specific configuration dict
                (e.g. ``{"url": "...", "max_items": 50}``).
        """
        ...  # pragma: no cover

    async def health_check(self, source_config: dict) -> bool:
        """Check if the source is reachable.

        Returns:
            True if the source responds, False otherwise.
        """
        ...  # pragma: no cover
