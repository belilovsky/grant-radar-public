"""Circuit breaker pattern for external service calls.

Prevents cascading failures by stopping calls to a failing service
and periodically testing recovery.

States:
    CLOSED → normal operation, requests pass through
    OPEN → service failing, requests are rejected immediately
    HALF_OPEN → testing recovery, one request allowed through

Consolidated from: qazposter/adapters/resilience.py, qazstack/compute/client.py
"""

from __future__ import annotations

import logging
import time

logger = logging.getLogger("qazstack.resilience")

# States
CLOSED = "closed"
OPEN = "open"
HALF_OPEN = "half_open"


class CircuitOpenError(Exception):
    """Raised when circuit breaker is open and request is rejected."""

    def __init__(self, name: str, recovery_in: float):
        self.name = name
        self.recovery_in = recovery_in
        super().__init__(f"Circuit '{name}' is OPEN, recovery in {recovery_in:.0f}s")


class CircuitBreaker:
    """Async-safe circuit breaker.

    Args:
        failure_threshold: Number of failures before opening circuit.
        recovery_timeout: Seconds to wait before testing recovery.
        name: Identifier for logging.
        success_threshold: Successes in HALF_OPEN before closing.

    Example::

        breaker = CircuitBreaker(name="telegram-api")

        if not breaker.allow_request:
            raise CircuitOpenError(breaker.name, breaker.time_until_recovery)

        try:
            result = await call_api()
            breaker.record_success()
        except Exception:
            breaker.record_failure()
            raise
    """

    def __init__(
        self,
        *,
        failure_threshold: int = 5,
        recovery_timeout: float = 60.0,
        name: str = "",
        success_threshold: int = 1,
    ):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.name = name
        self.success_threshold = success_threshold
        self._state = CLOSED
        self._failure_count = 0
        self._success_count = 0
        self._last_failure_time: float = 0
        self._total_failures = 0
        self._total_successes = 0

    @property
    def state(self) -> str:
        if self._state == OPEN:
            if time.monotonic() - self._last_failure_time >= self.recovery_timeout:
                self._state = HALF_OPEN
                self._success_count = 0
        return self._state

    @property
    def allow_request(self) -> bool:
        return self.state in (CLOSED, HALF_OPEN)

    @property
    def time_until_recovery(self) -> float:
        if self._state != OPEN:
            return 0.0
        elapsed = time.monotonic() - self._last_failure_time
        return max(0.0, self.recovery_timeout - elapsed)

    def record_success(self) -> None:
        self._total_successes += 1
        if self._state == HALF_OPEN:
            self._success_count += 1
            if self._success_count >= self.success_threshold:
                self._state = CLOSED
                self._failure_count = 0
                logger.info("Circuit '%s' CLOSED (recovered)", self.name)
        else:
            self._failure_count = 0
            self._state = CLOSED

    def record_failure(self) -> None:
        self._failure_count += 1
        self._total_failures += 1
        self._last_failure_time = time.monotonic()
        if self._state == HALF_OPEN:
            self._state = OPEN
            logger.warning("Circuit '%s' OPEN again (recovery failed)", self.name)
        elif self._failure_count >= self.failure_threshold:
            self._state = OPEN
            logger.warning(
                "Circuit '%s' OPEN after %d consecutive failures",
                self.name,
                self._failure_count,
            )

    def reset(self) -> None:
        """Manually reset circuit to CLOSED."""
        self._state = CLOSED
        self._failure_count = 0
        self._success_count = 0

    @property
    def stats(self) -> dict:
        return {
            "name": self.name,
            "state": self.state,
            "failure_count": self._failure_count,
            "total_failures": self._total_failures,
            "total_successes": self._total_successes,
        }


# --- Global registry ---

_breakers: dict[str, CircuitBreaker] = {}


def get_breaker(
    name: str,
    *,
    failure_threshold: int = 5,
    recovery_timeout: float = 60.0,
) -> CircuitBreaker:
    """Get or create a named circuit breaker (singleton per name)."""
    if name not in _breakers:
        _breakers[name] = CircuitBreaker(
            failure_threshold=failure_threshold,
            recovery_timeout=recovery_timeout,
            name=name,
        )
    return _breakers[name]


def reset_all_breakers() -> None:
    """Reset all breakers (for testing)."""
    _breakers.clear()
