"""Resilience utilities: circuit breaker, retry with backoff, timeout wrapper.

Usage::

    from qazstack.resilience import CircuitBreaker, retry_with_backoff, get_breaker

    # Circuit breaker per service:
    breaker = get_breaker("telegram")
    if breaker.allow_request:
        try:
            result = await call_api()
            breaker.record_success()
        except Exception:
            breaker.record_failure()

    # Retry with exponential backoff:
    result = await retry_with_backoff(fetch_data, url, max_retries=3)
"""

from qazstack.resilience.breaker import CircuitBreaker, CircuitOpenError, get_breaker, reset_all_breakers
from qazstack.resilience.contracts import IdempotencyKey, RetryPolicy, content_fingerprint
from qazstack.resilience.http import resilient_get, resilient_json_request, resilient_post, with_breaker
from qazstack.resilience.retry import retry_with_backoff

__all__ = [
    "CircuitBreaker",
    "CircuitOpenError",
    "get_breaker",
    "reset_all_breakers",
    "retry_with_backoff",
    "resilient_get",
    "resilient_json_request",
    "resilient_post",
    "with_breaker",
    "IdempotencyKey",
    "RetryPolicy",
    "content_fingerprint",
]
