"""Resilient JSON HTTP helpers built on the shared retry and breaker APIs."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

import httpx

from qazstack.resilience.breaker import CircuitBreaker, CircuitOpenError, get_breaker
from qazstack.resilience.retry import retry_with_backoff


async def with_breaker(
    breaker: CircuitBreaker | str,
    func: Callable,
    *args: Any,
    on_open: Callable[[CircuitBreaker], None] | None = None,
    **kwargs: Any,
) -> Any:
    """Execute a callable and update a named or explicit breaker."""
    active = get_breaker(breaker) if isinstance(breaker, str) else breaker
    if not active.allow_request:
        raise CircuitOpenError(active.name, active.time_until_recovery)
    try:
        result = await func(*args, **kwargs)
    except Exception:
        active.record_failure()
        if not active.allow_request and on_open is not None:
            on_open(active)
        raise
    active.record_success()
    return result


async def resilient_json_request(
    method: str,
    url: str,
    *,
    breaker: CircuitBreaker | str | None = None,
    max_retries: int = 3,
    base_delay: float = 1.0,
    max_delay: float = 30.0,
    timeout: float = 15.0,
    headers: dict[str, str] | None = None,
    client_factory=httpx.AsyncClient,
    **request_kwargs: Any,
) -> Any:
    """Request JSON with one shared client, retry, and optional breaker."""
    active = get_breaker(breaker) if isinstance(breaker, str) else breaker
    async with client_factory(timeout=timeout, headers=headers or {}) as client:

        async def _request() -> Any:
            response = await client.request(method, url, **request_kwargs)
            response.raise_for_status()
            return response.json()

        return await retry_with_backoff(
            _request,
            max_retries=max_retries,
            base_delay=base_delay,
            max_delay=max_delay,
            circuit_breaker=active,
        )


async def resilient_get(
    url: str,
    *,
    breaker: CircuitBreaker | str | None = None,
    **kwargs: Any,
) -> Any:
    return await resilient_json_request("GET", url, breaker=breaker, **kwargs)


async def resilient_post(
    url: str,
    json: Any = None,
    *,
    breaker: CircuitBreaker | str | None = None,
    **kwargs: Any,
) -> Any:
    return await resilient_json_request("POST", url, breaker=breaker, json=json, **kwargs)
