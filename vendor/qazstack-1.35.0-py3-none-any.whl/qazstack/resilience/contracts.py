"""Explicit retry and idempotency contracts without hidden transport behavior."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from typing import Any, Mapping

from qazstack.contracts._validation import require_identifier, require_one_of, require_positive


@dataclass(frozen=True, slots=True)
class RetryPolicy:
    max_attempts: int = 3
    timeout_seconds: float = 10.0
    base_delay_seconds: float = 0.5
    max_delay_seconds: float = 10.0
    jitter_ratio: float = 0.2
    retryable_statuses: tuple[int, ...] = (408, 429, 500, 502, 503, 504)

    def __post_init__(self) -> None:
        require_positive(self.max_attempts, "max_attempts")
        require_positive(self.timeout_seconds, "timeout_seconds")
        require_positive(self.base_delay_seconds, "base_delay_seconds", allow_zero=True)
        require_positive(self.max_delay_seconds, "max_delay_seconds")
        if self.max_delay_seconds < self.base_delay_seconds:
            raise ValueError("max_delay_seconds cannot be below base_delay_seconds")
        if not 0 <= self.jitter_ratio <= 1:
            raise ValueError("jitter_ratio must be between 0 and 1")
        if any(status < 400 or status > 599 for status in self.retryable_statuses):
            raise ValueError("retryable_statuses must contain HTTP error statuses")

    def delay_for_attempt(self, attempt: int) -> float:
        require_positive(attempt, "attempt")
        return min(self.max_delay_seconds, self.base_delay_seconds * (2 ** (attempt - 1)))


@dataclass(frozen=True, slots=True)
class IdempotencyKey:
    namespace: str
    value: str
    ttl_seconds: int
    scope: str = "transport"

    def __post_init__(self) -> None:
        require_identifier(self.namespace, "namespace")
        if not self.value.strip():
            raise ValueError("value must be non-empty")
        require_positive(self.ttl_seconds, "ttl_seconds")
        require_one_of(self.scope, frozenset({"transport", "content", "domain"}), "scope")

    @property
    def storage_key(self) -> str:
        return f"{self.namespace}:{self.scope}:{self.value}"


def content_fingerprint(payload: Mapping[str, Any], *, fields: tuple[str, ...]) -> str:
    """Hash selected normalized fields; domain merging remains consumer-owned."""
    if not fields:
        raise ValueError("fields must not be empty")
    normalized = {field: payload.get(field) for field in fields}
    encoded = json.dumps(normalized, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()
