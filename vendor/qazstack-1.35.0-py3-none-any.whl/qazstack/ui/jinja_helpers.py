"""Jinja2 template helpers – globals, filters, static hashing.

Usage:
    from qazstack.ui import setup_jinja

    templates = Jinja2Templates(directory="templates")
    setup_jinja(templates, settings=settings, static_dir="static")

Then in templates:
    <link rel="stylesheet" href="{{ static('css/style.css') }}">
    <p>{{ now().year }}</p>
    <p>{{ settings.app_name }}</p>
    <p>{{ 1234|format_number }}</p>
    <p>{{ article.created_at|time_ago }}</p>
    <p>{{ 5|pluralize("статья", "статьи", "статей") }}</p>
"""

from __future__ import annotations

import hashlib
from datetime import datetime, timezone
from functools import lru_cache
from pathlib import Path
from typing import Any

from fastapi.templating import Jinja2Templates


@lru_cache(maxsize=256)
def static_hash(filepath: str, static_dir: str = "static") -> str:
    """Generate cache-busting URL for a static file.

    Returns: /static/css/style.css?v=a1b2c3
    """
    full_path = Path(static_dir) / filepath
    if full_path.exists():
        content_hash = hashlib.md5(full_path.read_bytes()).hexdigest()[:8]
        return f"/static/{filepath}?v={content_hash}"
    return f"/static/{filepath}"


def _now() -> datetime:
    return datetime.now(timezone.utc)


def setup_jinja(
    templates: Jinja2Templates,
    *,
    settings: Any = None,
    static_dir: str | Path = "static",
    extra_globals: dict[str, Any] | None = None,
) -> Jinja2Templates:
    """Configure Jinja2 templates with standard globals and filters.

    Adds globals:
        - settings: app settings object
        - static(path): cache-busting static URL
        - now(): current UTC datetime
        - year: current year

    Adds filters:
        - truncate_words: truncate text to N words
        - format_date: format datetime
        - nl2br: convert newlines to <br>
        - format_number: thousands separator (1234 → 1 234)
        - time_ago: human-readable relative time in Russian
        - pluralize: Russian pluralization
    """
    env = templates.env

    # Globals
    if settings:
        env.globals["settings"] = settings
    env.globals["static"] = lambda path: static_hash(path, str(static_dir))
    env.globals["now"] = _now
    env.globals["year"] = _now().year

    if extra_globals:
        env.globals.update(extra_globals)

    # Filters
    env.filters["truncate_words"] = _truncate_words
    env.filters["format_date"] = _format_date
    env.filters["nl2br"] = _nl2br
    env.filters["format_number"] = _format_number
    env.filters["time_ago"] = _time_ago
    env.filters["pluralize"] = _pluralize

    return templates


# ─── Filter implementations ───


def _truncate_words(text: str, count: int = 30, end: str = "...") -> str:
    """Truncate text to N words."""
    words = text.split()
    if len(words) <= count:
        return text
    return " ".join(words[:count]) + end


def _format_date(dt: datetime | str, fmt: str = "%d.%m.%Y") -> str:
    """Format a datetime or ISO string."""
    if isinstance(dt, str):
        try:
            dt = datetime.fromisoformat(dt)
        except (ValueError, TypeError):
            return str(dt)
    return dt.strftime(fmt)


def _nl2br(text: str) -> str:
    """Convert newlines to <br> tags."""
    return text.replace("\n", "<br>\n")


def _format_number(value: int | float, separator: str = " ") -> str:
    """Format number with thousands separator: 1234 → 1 234."""
    if isinstance(value, float):
        parts = f"{value:,.2f}".split(".")
        return parts[0].replace(",", separator) + "." + parts[1]
    return f"{value:,}".replace(",", separator)


def _time_ago(dt: datetime | str) -> str:
    """Human-readable time ago: 5 минут назад, 2 часа назад."""
    if isinstance(dt, str):
        try:
            dt = datetime.fromisoformat(dt)
        except (ValueError, TypeError):
            return str(dt)
    now = datetime.now(timezone.utc)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    diff = now - dt
    seconds = int(diff.total_seconds())
    if seconds < 60:
        return "только что"
    minutes = seconds // 60
    if minutes < 60:
        if minutes % 10 == 1 and minutes != 11:
            return f"{minutes} минуту назад"
        elif minutes % 10 in (2, 3, 4) and minutes not in (12, 13, 14):
            return f"{minutes} минуты назад"
        return f"{minutes} минут назад"
    hours = minutes // 60
    if hours < 24:
        if hours % 10 == 1 and hours != 11:
            return f"{hours} час назад"
        elif hours % 10 in (2, 3, 4) and hours not in (12, 13, 14):
            return f"{hours} часа назад"
        return f"{hours} часов назад"
    days = hours // 24
    if days < 30:
        if days % 10 == 1 and days != 11:
            return f"{days} день назад"
        elif days % 10 in (2, 3, 4) and days not in (12, 13, 14):
            return f"{days} дня назад"
        return f"{days} дней назад"
    return dt.strftime("%d.%m.%Y")


def _pluralize(count: int, form1: str, form2: str, form5: str) -> str:
    """Russian pluralization: _pluralize(5, "статья", "статьи", "статей") → "5 статей"."""
    n = abs(count) % 100
    n1 = n % 10
    if 10 < n < 20:
        return f"{count} {form5}"
    if n1 == 1:
        return f"{count} {form1}"
    if 2 <= n1 <= 4:
        return f"{count} {form2}"
    return f"{count} {form5}"
