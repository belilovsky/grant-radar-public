"""QazStack UI – CMS-like frontend components for FastAPI + Jinja2.

Provides:
- setup_ui() – single-call FastAPI integration
- setup_jinja() – standalone Jinja2 setup (no FastAPI mount)
- Jinja2 macro components:
    Base:     card, badge, nav, search, pagination, grid, button, form, modal
    Extended: alert, tabs, avatar, tag/chip, skeleton, tooltip, dropdown
    Data:     sortable table, progress bar/ring
- CSS design tokens v2 (warm palette, light + dark)
- Vanilla JS utilities:
    Core:   theme toggle, mobile nav, search, back-to-top, accordion, image lazy-load
    UI:     tabs, dropdown, table sort, scroll-to-top, copy-to-clipboard, toast, modal
- Layout templates (base, public, dashboard)
- Python template filters: format_number, time_ago, pluralize, format_date, nl2br, truncate_words

Quick start:
    from qazstack.ui import setup_ui

    app = FastAPI()
    templates = setup_ui(app, settings=settings)

    @app.get("/")
    async def home(request: Request):
        return templates.TemplateResponse(request, "index.html")
"""

from qazstack.ui.helpers import setup_ui
from qazstack.ui.jinja_helpers import setup_jinja, static_hash
from qazstack.ui.theme import ThemeToggle

__all__ = [
    "setup_ui",
    "setup_jinja",
    "static_hash",
    "ThemeToggle",
]
