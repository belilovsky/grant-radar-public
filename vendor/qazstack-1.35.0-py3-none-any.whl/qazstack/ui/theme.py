"""Theme toggle helper – light (default) / dark theme support.

Light theme is the default across all projects.
Dark theme is secondary/optional.

Usage:
    In base.html:
        <button onclick="toggleTheme()" class="theme-toggle">🌓</button>

    {{ theme_script() | safe }}
"""

from __future__ import annotations

# JavaScript for theme toggle (injected into templates)
THEME_TOGGLE_JS = """
<script>
(function() {
    const STORAGE_KEY = 'theme';
    const root = document.documentElement;

    function getPreferred() {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) return stored;
        return 'light';  // Light is default
    }

    function applyTheme(theme) {
        root.setAttribute('data-theme', theme);
        localStorage.setItem(STORAGE_KEY, theme);
    }

    // Apply on load
    applyTheme(getPreferred());

    // Global toggle function
    window.toggleTheme = function() {
        const current = root.getAttribute('data-theme') || 'light';
        applyTheme(current === 'dark' ? 'light' : 'dark');
    };
})();
</script>
"""

# CSS variables for light/dark themes
THEME_CSS = """
/* Light theme (default) */
:root {
    --bg: #F7F6F2;
    --surface: #FFFFFF;
    --text: #28251D;
    --text-secondary: #5C5A52;
    --text-muted: #7A7974;
    --border: #D4D1CA;
    --border-light: #E8E6E1;
    --shadow-sm: 0 1px 3px rgba(0,0,0,0.06);
    --shadow-md: 0 4px 12px rgba(0,0,0,0.08);
    --shadow-lg: 0 8px 30px rgba(0,0,0,0.12);
    --radius-sm: 6px;
    --radius: 10px;
    --radius-lg: 14px;
    --transition: 0.2s ease;
    --success: #38a169;
    --warning: #d69e2e;
    --danger: #e53e3e;
}

/* Dark theme (secondary) */
[data-theme="dark"] {
    --bg: #171614;
    --surface: #201F1D;
    --text: #CDCCCA;
    --text-secondary: #9A9995;
    --text-muted: #797876;
    --border: #393836;
    --border-light: #2F2E2C;
    --shadow-sm: 0 1px 2px rgba(0,0,0,0.3);
    --shadow-md: 0 4px 12px rgba(0,0,0,0.4);
    --shadow-lg: 0 8px 30px rgba(0,0,0,0.5);
    --success: #48bb78;
    --warning: #ecc94b;
    --danger: #fc8181;
}
"""


class ThemeToggle:
    """Theme toggle helper for Jinja2 templates."""

    @staticmethod
    def js() -> str:
        """Return theme toggle JavaScript."""
        return THEME_TOGGLE_JS

    @staticmethod
    def css() -> str:
        """Return theme CSS variables."""
        return THEME_CSS

    @staticmethod
    def jinja_globals() -> dict:
        """Globals to inject into Jinja2 env."""
        return {
            "theme_script": lambda: THEME_TOGGLE_JS,
            "theme_css": lambda: THEME_CSS,
        }
