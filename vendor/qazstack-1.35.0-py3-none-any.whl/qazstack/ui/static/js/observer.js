/**
 * QazStack IntersectionObserver Utility
 * Adds 'visible' class when elements enter viewport.
 * Usage: Add [data-observe] to elements, optionally [data-observe-once] to observe only once.
 */
(function () {
    'use strict';

    document.addEventListener('DOMContentLoaded', function () {
        if (!('IntersectionObserver' in window)) return;

        var observer = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                    if (entry.target.hasAttribute('data-observe-once')) {
                        observer.unobserve(entry.target);
                    }
                } else if (!entry.target.hasAttribute('data-observe-once')) {
                    entry.target.classList.remove('visible');
                }
            });
        }, {
            threshold: parseFloat(document.body.getAttribute('data-observe-threshold') || '0.1'),
            rootMargin: document.body.getAttribute('data-observe-margin') || '0px'
        });

        document.querySelectorAll('[data-observe]').forEach(function (el) {
            observer.observe(el);
        });

        // Expose for dynamic content
        window.qsObserve = function (el) {
            observer.observe(el);
        };
    });
})();
