/**
 * QazStack Dropdown
 * Click-to-toggle dropdown menus with outside-click close.
 */
(function () {
    'use strict';

    // Toggle dropdown on trigger click
    document.addEventListener('click', function (e) {
        var trigger = e.target.closest('[data-qs-dropdown]');

        // Close all other dropdowns first
        document.querySelectorAll('.qs-dropdown.open').forEach(function (dd) {
            if (trigger && dd.contains(trigger)) return;
            dd.classList.remove('open');
        });

        if (!trigger) return;

        e.preventDefault();
        e.stopPropagation();
        var dropdown = trigger.closest('.qs-dropdown');
        if (dropdown) {
            dropdown.classList.toggle('open');
        }
    });

    // Close on Escape
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            document.querySelectorAll('.qs-dropdown.open').forEach(function (dd) {
                dd.classList.remove('open');
            });
        }
    });
})();
