/**
 * @file infinite-scroll.js
 * @description QazStack Infinite Scroll – prefetch-based infinite scroll for content pages.
 * @version 2.0.0
 *
 * Features:
 *  - Prefetches next page at 50% scroll of the current content body
 *  - Renders instantly when the bottom sentinel enters the viewport
 *  - Generic card rendering via a user-supplied `renderItem` callback or a
 *    built-in default renderer (expects items with { id, url, title, image?,
 *    excerpt?, category?, date? })
 *  - Configurable API endpoint, selectors, and limits
 *  - IntersectionObserver-based (no scroll event listeners)
 *  - Deduplicates loaded items by id
 *  - Self-injects minimal CSS
 *  - Zero dependencies, vanilla JS
 *
 * Usage (auto-init via data attributes):
 *
 *   <div id="qs-scroll-wrap" data-item-id="42" data-item-date="2024-01-15">
 *     <!-- initial content -->
 *   </div>
 *   <div id="qs-scroll-body"><!-- midpoint marker inserted here --></div>
 *   <script src="infinite-scroll.js"
 *     data-api="/api/items"
 *     data-limit="3"
 *     data-wrap="#qs-scroll-wrap"
 *     data-body="#qs-scroll-body">
 *   </script>
 *
 * Usage (programmatic):
 *
 *   QS.InfiniteScroll.init({
 *     api:        '/api/items',        // required – endpoint returning JSON array
 *     wrap:       '#qs-scroll-wrap',   // container that receives new cards
 *     body:       '#qs-scroll-body',   // element used for 50% midpoint detection
 *     limit:      3,                   // items per page (default 3)
 *     idParam:    'after_id',          // query param name for cursor id
 *     dateParam:  'after_date',        // query param name for cursor date
 *     limitParam: 'limit',             // query param name for limit
 *     renderItem: function(item) { return domNode; },  // optional custom renderer
 *     onLoad:     function(items) {},  // optional callback after each batch
 *   });
 */

(function (global) {
  'use strict';

  /* -------------------------------------------------------------------------
   * CSS – injected once into <head>
   * ---------------------------------------------------------------------- */
  var STYLES = [
    '.qs-scroll-spinner {',
    '  display: none;',
    '  justify-content: center;',
    '  align-items: center;',
    '  padding: 24px 0;',
    '}',
    '.qs-scroll-spinner.qs-active { display: flex; }',
    '.qs-spinner-dots {',
    '  display: flex;',
    '  gap: 6px;',
    '  align-items: center;',
    '}',
    '.qs-spinner-dots span {',
    '  display: block;',
    '  width: 8px;',
    '  height: 8px;',
    '  border-radius: 50%;',
    '  background: var(--accent, #2563eb);',
    '  opacity: 0.4;',
    '  animation: qs-bounce 1.2s ease-in-out infinite;',
    '}',
    '.qs-spinner-dots span:nth-child(2) { animation-delay: 0.2s; }',
    '.qs-spinner-dots span:nth-child(3) { animation-delay: 0.4s; }',
    '@keyframes qs-bounce {',
    '  0%, 80%, 100% { opacity: 0.4; transform: scale(1); }',
    '  40% { opacity: 1; transform: scale(1.2); }',
    '}',
    '.qs-scroll-card {',
    '  opacity: 0;',
    '  transform: translateY(12px);',
    '  transition: opacity var(--transition-slow, 0.3s ease),',
    '              transform var(--transition-slow, 0.3s ease);',
    '}',
    '.qs-scroll-card.qs-visible {',
    '  opacity: 1;',
    '  transform: none;',
    '}',
    '.qs-card-link {',
    '  display: flex;',
    '  gap: 16px;',
    '  padding: 16px 0;',
    '  border-bottom: 1px solid var(--border, #e2e8f0);',
    '  text-decoration: none;',
    '  color: inherit;',
    '}',
    '.qs-card-img {',
    '  flex: 0 0 120px;',
    '  height: 80px;',
    '  overflow: hidden;',
    '  border-radius: var(--radius-sm, 6px);',
    '  background: var(--bg-secondary, #e8eaed);',
    '}',
    '.qs-card-img img {',
    '  width: 100%;',
    '  height: 100%;',
    '  object-fit: cover;',
    '}',
    '.qs-card-body {',
    '  flex: 1;',
    '  min-width: 0;',
    '}',
    '.qs-card-meta {',
    '  display: flex;',
    '  align-items: center;',
    '  gap: 6px;',
    '  font-size: var(--font-size-xs, 0.75rem);',
    '  color: var(--text-muted, #718096);',
    '  margin-bottom: 6px;',
    '}',
    '.qs-cat-badge {',
    '  display: inline-flex;',
    '  align-items: center;',
    '  gap: 4px;',
    '  font-weight: var(--font-semibold, 600);',
    '  color: var(--accent, #2563eb);',
    '}',
    '.qs-card-title {',
    '  margin: 0 0 6px;',
    '  font-size: var(--font-size-base, 1rem);',
    '  font-weight: var(--font-semibold, 600);',
    '  line-height: var(--line-height-tight, 1.3);',
    '  color: var(--text, #1a1a2e);',
    '}',
    '.qs-card-excerpt {',
    '  margin: 0;',
    '  font-size: var(--font-size-sm, 0.875rem);',
    '  color: var(--text-secondary, #4a5568);',
    '  display: -webkit-box;',
    '  -webkit-line-clamp: 2;',
    '  -webkit-box-orient: vertical;',
    '  overflow: hidden;',
    '}',
    '@media (max-width: 480px) {',
    '  .qs-card-img { flex: 0 0 80px; height: 60px; }',
    '}',
  ].join('\n');

  /**
   * Inject the component stylesheet once.
   * @returns {void}
   */
  function injectStyles() {
    if (document.getElementById('qs-infinite-scroll-styles')) return;
    var style = document.createElement('style');
    style.id = 'qs-infinite-scroll-styles';
    style.textContent = STYLES;
    document.head.appendChild(style);
  }

  /* -------------------------------------------------------------------------
   * Default card renderer
   * ---------------------------------------------------------------------- */

  /**
   * Build a default article/item card from a data object.
   * Projects can replace this entirely with `options.renderItem`.
   *
   * @param {Object} item
   * @param {number|string} item.id
   * @param {string} item.url
   * @param {string} item.title
   * @param {string} [item.image]
   * @param {string} [item.excerpt]
   * @param {string} [item.category]
   * @param {string} [item.category_slug]
   * @param {string} [item.date]
   * @returns {HTMLElement}
   */
  function defaultRenderItem(item) {
    var card = document.createElement('article');
    card.className = 'qs-scroll-card';
    card.dataset.itemId = item.id;

    var link = document.createElement('a');
    link.href = item.url || '#';
    link.className = 'qs-card-link';

    // Optional thumbnail
    if (item.image) {
      var imgWrap = document.createElement('div');
      imgWrap.className = 'qs-card-img';
      var img = document.createElement('img');
      img.src = item.image;
      img.alt = '';
      img.loading = 'lazy';
      imgWrap.appendChild(img);
      link.appendChild(imgWrap);
    }

    // Text body
    var body = document.createElement('div');
    body.className = 'qs-card-body';

    // Meta row: category + date
    if (item.category || item.date) {
      var meta = document.createElement('div');
      meta.className = 'qs-card-meta';
      if (item.category) {
        var badge = document.createElement('span');
        badge.className = 'qs-cat-badge';
        badge.textContent = item.category;
        meta.appendChild(badge);
        if (item.date) {
          var sep = document.createElement('span');
          sep.textContent = '\u00B7';
          meta.appendChild(sep);
        }
      }
      if (item.date) {
        var dateSpan = document.createElement('span');
        dateSpan.textContent = item.date;
        meta.appendChild(dateSpan);
      }
      body.appendChild(meta);
    }

    // Title
    var h2 = document.createElement('h2');
    h2.className = 'qs-card-title';
    h2.textContent = item.title || '';
    body.appendChild(h2);

    // Excerpt
    if (item.excerpt) {
      var excerpt = document.createElement('p');
      excerpt.className = 'qs-card-excerpt';
      excerpt.textContent = item.excerpt;
      body.appendChild(excerpt);
    }

    link.appendChild(body);
    card.appendChild(link);
    return card;
  }

  /* -------------------------------------------------------------------------
   * Core init
   * ---------------------------------------------------------------------- */

  /**
   * Initialise the infinite scroll for a given content wrapper.
   *
   * @param {Object} options
   * @param {string}   options.api            - API endpoint (required)
   * @param {string}  [options.wrap]          - Selector for the scroll container (default '#qs-scroll-wrap')
   * @param {string}  [options.body]          - Selector for the content body used for midpoint (default '#qs-scroll-body')
   * @param {number}  [options.limit]         - Items per request (default 3)
   * @param {string}  [options.idParam]       - Query param name for cursor ID (default 'after_id')
   * @param {string}  [options.dateParam]     - Query param name for cursor date (default 'after_date')
   * @param {string}  [options.limitParam]    - Query param name for limit (default 'limit')
   * @param {Function}[options.renderItem]    - Custom item renderer: (item) => HTMLElement
   * @param {Function}[options.onLoad]        - Called after each batch: (items) => void
   * @returns {void}
   */
  function init(options) {
    options = options || {};

    var api        = options.api;
    var wrapSel    = options.wrap       || '#qs-scroll-wrap';
    var bodySel    = options.body       || '#qs-scroll-body';
    var limit      = options.limit      || 3;
    var idParam    = options.idParam    || 'after_id';
    var dateParam  = options.dateParam  || 'after_date';
    var limitParam = options.limitParam || 'limit';
    var renderer   = options.renderItem || defaultRenderItem;
    var onLoad     = options.onLoad     || null;

    if (!api) {
      console.warn('[QS.InfiniteScroll] options.api is required.');
      return;
    }

    var wrap = document.querySelector(wrapSel);
    if (!wrap) {
      console.warn('[QS.InfiniteScroll] wrap element not found:', wrapSel);
      return;
    }

    // Read initial cursor from first item in the wrap
    var firstItem = wrap.querySelector('[data-item-id]');
    if (!firstItem) {
      console.warn('[QS.InfiniteScroll] No [data-item-id] element found inside wrap.');
      return;
    }

    injectStyles();

    var loadedIds   = new Set();
    var lastId      = parseInt(firstItem.dataset.itemId, 10);
    var lastDate    = firstItem.dataset.itemDate || '';
    var noMore      = false;

    // Prefetch cache state
    var prefetchCache     = null;
    var prefetchPromise   = null;
    var prefetchedForId   = null;
    var renderPending     = false;

    // Track all initial items
    wrap.querySelectorAll('[data-item-id]').forEach(function (el) {
      var id = parseInt(el.dataset.itemId, 10);
      if (!isNaN(id)) loadedIds.add(id);
    });

    // ── Sentinel (bottom trigger) ──
    var sentinel = document.createElement('div');
    sentinel.className = 'qs-scroll-sentinel';
    sentinel.style.cssText = 'height:1px;pointer-events:none;';
    wrap.parentNode.insertBefore(sentinel, wrap.nextSibling);

    // ── Spinner (shown while waiting for prefetch) ──
    var spinner = document.createElement('div');
    spinner.className = 'qs-scroll-spinner';
    spinner.innerHTML = '<div class="qs-spinner-dots"><span></span><span></span><span></span></div>';
    sentinel.parentNode.insertBefore(spinner, sentinel);

    /**
     * Build the API URL for the next batch.
     * @returns {string}
     */
    function buildApiUrl() {
      return api +
        '?' + encodeURIComponent(idParam) + '=' + lastId +
        '&' + encodeURIComponent(dateParam) + '=' + encodeURIComponent(lastDate) +
        '&' + encodeURIComponent(limitParam) + '=' + limit;
    }

    /**
     * Fire a prefetch request and store the result in `prefetchCache`.
     * If render was already requested before the data arrived, renders immediately.
     * @returns {void}
     */
    function prefetchNext() {
      if (noMore || prefetchedForId === lastId) return;
      prefetchedForId = lastId;
      prefetchCache   = null;

      prefetchPromise = fetch(buildApiUrl())
        .then(function (r) { return r.json(); })
        .then(function (items) {
          prefetchCache = items;
          // Pre-warm image decode
          if (items && items.length) {
            items.forEach(function (item) {
              if (item.image) {
                var preImg = new Image();
                preImg.src = item.image;
              }
            });
          }
          if (renderPending) {
            renderPending = false;
            renderItems();
          }
          return items;
        })
        .catch(function () {
          prefetchCache = [];
          if (renderPending) {
            renderPending = false;
            renderItems();
          }
        });
    }

    /**
     * Take items from `prefetchCache` and append cards to the wrap.
     * If the cache is not ready, shows the spinner and sets `renderPending`.
     * @returns {void}
     */
    function renderItems() {
      if (prefetchCache === null) {
        spinner.classList.add('qs-active');
        renderPending = true;
        if (!prefetchPromise) prefetchNext();
        return;
      }

      spinner.classList.remove('qs-active');
      var items = prefetchCache;
      prefetchCache   = null;
      prefetchPromise = null;

      if (!items || !items.length) {
        noMore = true;
        return;
      }

      items.forEach(function (item) {
        if (loadedIds.has(item.id)) return;
        loadedIds.add(item.id);

        var card = renderer(item);
        if (!card) return;

        wrap.appendChild(card);
        // Trigger enter animation on next paint
        requestAnimationFrame(function () {
          card.classList.add('qs-visible');
        });

        // Advance cursor
        lastId   = item.id;
        lastDate = item.pub_date || item.date || lastDate;
      });

      // Reset so next page can be prefetched
      prefetchedForId = null;

      if (onLoad) {
        try { onLoad(items); } catch (e) { /* ignore callback errors */ }
      }
    }

    // ── Midpoint observer: fires prefetch at ~50% scroll ──
    var contentBody = document.querySelector(bodySel);
    if (contentBody && 'IntersectionObserver' in window) {
      var midMarker = document.createElement('div');
      midMarker.className = 'qs-mid-marker';
      midMarker.style.cssText = 'height:1px;pointer-events:none;';

      var children  = contentBody.children;
      var midIndex  = Math.floor(children.length / 2);
      if (midIndex > 0 && children[midIndex]) {
        contentBody.insertBefore(midMarker, children[midIndex]);
      } else {
        contentBody.appendChild(midMarker);
      }

      var prefetchObserver = new IntersectionObserver(function (entries) {
        if (entries[0].isIntersecting) {
          prefetchNext();
          prefetchObserver.disconnect();
        }
      }, { rootMargin: '200px' });

      prefetchObserver.observe(midMarker);
    }

    // ── Bottom sentinel observer: renders prefetched items ──
    if ('IntersectionObserver' in window) {
      var loadObserver = new IntersectionObserver(function (entries) {
        if (entries[0].isIntersecting && !noMore) {
          renderItems();
        }
      }, { rootMargin: '400px' });

      loadObserver.observe(sentinel);
    }
  }

  /* -------------------------------------------------------------------------
   * Auto-init from <script> data attributes
   *
   * Looks for: <script src="infinite-scroll.js"
   *              data-api="/api/items"
   *              data-wrap="#my-wrap"
   *              data-body="#my-body"
   *              data-limit="5">
   * ---------------------------------------------------------------------- */
  function autoInit() {
    var scripts = document.querySelectorAll('script[data-api]');
    for (var i = 0; i < scripts.length; i++) {
      var s = scripts[i];
      // Only process scripts that look like this component
      if (s.src && s.src.indexOf('infinite-scroll') === -1) continue;
      init({
        api:       s.getAttribute('data-api'),
        wrap:      s.getAttribute('data-wrap')   || '#qs-scroll-wrap',
        body:      s.getAttribute('data-body')   || '#qs-scroll-body',
        limit:     parseInt(s.getAttribute('data-limit') || '3', 10),
        idParam:   s.getAttribute('data-id-param')    || 'after_id',
        dateParam: s.getAttribute('data-date-param')  || 'after_date',
      });
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', autoInit);
  } else {
    autoInit();
  }

  /* -------------------------------------------------------------------------
   * Public API
   * ---------------------------------------------------------------------- */
  global.QS = global.QS || {};

  /**
   * @namespace QS.InfiniteScroll
   */
  global.QS.InfiniteScroll = {
    /**
     * Initialise a new infinite scroll instance.
     * @type {Function}
     * @see init
     */
    init: init,
  };

})(typeof window !== 'undefined' ? window : this);
