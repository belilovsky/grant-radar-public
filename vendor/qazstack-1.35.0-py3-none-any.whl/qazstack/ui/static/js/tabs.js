/**
 * QazStack Tabs
 * Accessible tab switching with keyboard navigation.
 */
(function () {
    'use strict';

    window.qsTabSwitch = function (btn) {
        var tablist = btn.closest('.qs-tabs');
        if (!tablist) return;

        // Deactivate all tabs
        tablist.querySelectorAll('.qs-tabs__item').forEach(function (tab) {
            tab.classList.remove('active');
            tab.setAttribute('aria-selected', 'false');
        });

        // Activate clicked tab
        btn.classList.add('active');
        btn.setAttribute('aria-selected', 'true');

        // Switch panels
        var tabId = btn.getAttribute('data-tab');
        var container = tablist.parentElement;
        container.querySelectorAll('.qs-tab-panel').forEach(function (panel) {
            panel.classList.toggle('active', panel.id === 'panel-' + tabId);
        });
    };

    // Keyboard navigation: Arrow Left/Right between tabs
    document.addEventListener('keydown', function (e) {
        var tab = document.activeElement;
        if (!tab || !tab.classList.contains('qs-tabs__item')) return;
        if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') return;

        var tabs = Array.from(tab.closest('.qs-tabs').querySelectorAll('.qs-tabs__item'));
        var idx = tabs.indexOf(tab);
        if (idx < 0) return;

        e.preventDefault();
        var next;
        if (e.key === 'ArrowRight') {
            next = tabs[(idx + 1) % tabs.length];
        } else {
            next = tabs[(idx - 1 + tabs.length) % tabs.length];
        }
        next.focus();
        next.click();
    });
})();
