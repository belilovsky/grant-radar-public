/**
 * QazStack Theme Toggle
 * Light (default) / Dark theme with localStorage persistence.
 * Usage: Add button with id="qsThemeToggle" or call window.qsToggleTheme()
 */
(function () {
    'use strict';

    const STORAGE_KEY = 'qs-theme';
    const root = document.documentElement;

    function getPreferred() {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored === 'dark' || stored === 'light') return stored;
        return 'light'; // Light is default
    }

    function applyTheme(theme) {
        root.setAttribute('data-theme', theme);
        localStorage.setItem(STORAGE_KEY, theme);
        // Update toggle button icon
        document.querySelectorAll('[data-theme-icon]').forEach(function (el) {
            el.textContent = theme === 'dark' ? '☀️' : '🌙';
        });
    }

    // Apply on load (before paint)
    applyTheme(getPreferred());

    // Global toggle
    window.qsToggleTheme = function () {
        var current = root.getAttribute('data-theme') || 'light';
        applyTheme(current === 'dark' ? 'light' : 'dark');
    };

    // Auto-bind toggle buttons
    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('#qsThemeToggle, [data-theme-toggle]').forEach(function (btn) {
            btn.addEventListener('click', window.qsToggleTheme);
        });
    });
})();
