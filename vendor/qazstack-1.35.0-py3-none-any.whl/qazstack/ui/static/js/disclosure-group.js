/**
 * QazStack disclosure group.
 *
 * Adds accessible, compact disclosure controls to long page sections and
 * expands a collapsed section when an in-page navigation link targets it.
 */
(function (global) {
    'use strict';

    global.QS = global.QS || {};
    var instances = new Map();

    function titleFor(section, heading) {
        var explicit = section.getAttribute('data-qs-disclosure-label');
        if (explicit) return explicit;
        var title = heading && heading.querySelector('h2, h3, h4');
        return title ? title.textContent.trim() : 'подробности';
    }

    function targetFor(section) {
        var selector = section.getAttribute('data-qs-disclosure-target');
        if (selector) return section.querySelector(selector);
        return section.querySelector('[data-qs-disclosure-content], .detail-grid');
    }

    function setup(section, index) {
        if (section.getAttribute('data-qs-disclosure-ready') === 'true') {
            return instances.get(section.id) || null;
        }

        var target = targetFor(section);
        var heading = section.querySelector('.section-heading, [data-qs-disclosure-heading]');
        if (!target || !heading) return null;

        if (!section.id) section.id = 'qs-disclosure-' + index;
        if (!target.id) target.id = section.id + '-content';

        var label = titleFor(section, heading);
        var toggle = heading.querySelector('[data-qs-disclosure-toggle]');
        if (!toggle) {
            toggle = document.createElement('button');
            toggle.type = 'button';
            toggle.className = section.getAttribute('data-qs-disclosure-button-class') || 'qs-disclosure-toggle';
            toggle.setAttribute('data-qs-disclosure-toggle', '');
            heading.append(toggle);
        }

        toggle.setAttribute('aria-controls', target.id);

        function apply(expanded) {
            target.hidden = !expanded;
            toggle.setAttribute('aria-expanded', String(expanded));
            toggle.textContent = expanded ? 'Скрыть: ' + label : 'Показать: ' + label;
        }

        var initiallyExpanded = section.getAttribute('data-qs-disclosure-open') === 'true';
        apply(initiallyExpanded);
        toggle.addEventListener('click', function () { apply(target.hidden); });
        section.setAttribute('data-qs-disclosure-ready', 'true');

        var instance = {
            collapse: function () { apply(false); },
            expand: function () { apply(true); },
            section: section,
            target: target,
            toggle: toggle
        };
        instances.set(section.id, instance);
        return instance;
    }

    function bindAnchors(root) {
        root.querySelectorAll('a[href^="#"]').forEach(function (link) {
            if (link.getAttribute('data-qs-disclosure-anchor-ready') === 'true') return;
            link.addEventListener('click', function () {
                var id = link.getAttribute('href').slice(1);
                var instance = instances.get(id);
                if (instance) instance.expand();
            });
            link.setAttribute('data-qs-disclosure-anchor-ready', 'true');
        });
    }

    function init(suppliedOptions) {
        var options = suppliedOptions || {};
        var root = options.root || document;
        var selector = options.selector || '[data-qs-disclosure]';
        var initialized = [];
        root.querySelectorAll(selector).forEach(function (section, index) {
            var instance = setup(section, index);
            if (instance) initialized.push(instance);
        });
        bindAnchors(root);
        return initialized;
    }

    global.QS.DisclosureGroup = {
        get: function (id) { return instances.get(id) || null; },
        init: init
    };
})(typeof window !== 'undefined' ? window : globalThis);
