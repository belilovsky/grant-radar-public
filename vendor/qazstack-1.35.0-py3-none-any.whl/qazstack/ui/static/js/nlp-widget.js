/**
 * @file nlp-widget.js
 * @description QazStack NLP Analysis Widget – renders sentiment badge, entity tags,
 *              topics, and geo region from an NLP API response.
 * @version 2.0.0
 *
 * Features:
 *  - Sentiment badge with score percentage
 *  - Entity tags coloured by type (person, org, geo/loc)
 *  - Topic tags
 *  - Geo / region line
 *  - CSS uses qazstack.ui design tokens (var(--bg), var(--surface), var(--text) …)
 *  - Configurable API endpoint and target container
 *  - Auto-init via <script data-article-id="…"> attributes
 *  - Silent on 404 (no NLP data yet)
 *  - XSS-safe (all user data escaped)
 *  - Self-injects its CSS once
 *  - Zero dependencies, vanilla JS
 *
 * Usage (auto-init via script attributes):
 *
 *   <script src="nlp-widget.js"
 *     data-article-id="12345"
 *     data-api-base=""
 *     data-target="#nlp-widget-container">
 *   </script>
 *
 * Usage (programmatic):
 *
 *   QS.NLPWidget.init({
 *     articleId: 12345,
 *     apiBase:   '',
 *     apiPath:   '/api/nlp/article/',   // appended with articleId
 *     target:    '#nlp-widget-container',
 *     label:     'NLP Analysis',        // header label text
 *   });
 */

(function (global) {
  'use strict';

  /* -------------------------------------------------------------------------
   * Injected CSS – uses qazstack.ui design tokens
   * ---------------------------------------------------------------------- */
  var STYLES = [
    '.qs-nlp-widget {',
    '  font-family: var(--font-family, system-ui, sans-serif);',
    '  font-size: var(--font-size-sm, 0.875rem);',
    '  line-height: var(--line-height, 1.6);',
    '  color: var(--text, #1a1a2e);',
    '  background: var(--surface, #ffffff);',
    '  border: 1px solid var(--border, #e2e8f0);',
    '  border-radius: var(--radius, 10px);',
    '  padding: 12px 16px;',
    '  margin: 16px 0;',
    '  max-width: 700px;',
    '}',
    /* Header */
    '.qs-nlp-header {',
    '  display: flex;',
    '  align-items: center;',
    '  gap: 10px;',
    '  margin-bottom: 10px;',
    '}',
    '.qs-nlp-label {',
    '  font-size: var(--font-size-xs, 0.75rem);',
    '  font-weight: var(--font-semibold, 600);',
    '  letter-spacing: 0.06em;',
    '  text-transform: uppercase;',
    '  color: var(--text-muted, #718096);',
    '}',
    /* Sentiment badge */
    '.qs-nlp-sentiment {',
    '  display: inline-flex;',
    '  align-items: center;',
    '  gap: 5px;',
    '  padding: 3px 10px;',
    '  border-radius: var(--radius-full, 9999px);',
    '  font-size: var(--font-size-xs, 0.75rem);',
    '  font-weight: var(--font-semibold, 600);',
    '  letter-spacing: 0.03em;',
    '}',
    '.qs-nlp-sentiment--positive {',
    '  background: var(--success-light, #c6f6d5);',
    '  color: var(--success, #38a169);',
    '  border: 1px solid var(--success, #38a169);',
    '}',
    '.qs-nlp-sentiment--negative {',
    '  background: var(--danger-light, #fed7d7);',
    '  color: var(--danger, #e53e3e);',
    '  border: 1px solid var(--danger, #e53e3e);',
    '}',
    '.qs-nlp-sentiment--neutral {',
    '  background: var(--bg-secondary, #e8eaed);',
    '  color: var(--text-muted, #718096);',
    '  border: 1px solid var(--border, #e2e8f0);',
    '}',
    '.qs-nlp-sentiment--mixed {',
    '  background: var(--warning-light, #fefcbf);',
    '  color: var(--warning, #d69e2e);',
    '  border: 1px solid var(--warning, #d69e2e);',
    '}',
    '.qs-nlp-score {',
    '  font-size: 10px;',
    '  opacity: 0.75;',
    '}',
    /* Divider */
    '.qs-nlp-divider {',
    '  border: none;',
    '  border-top: 1px solid var(--border-light, #edf2f7);',
    '  margin: 8px 0;',
    '}',
    /* Section */
    '.qs-nlp-section {',
    '  margin-top: 8px;',
    '}',
    '.qs-nlp-section-title {',
    '  font-size: var(--font-size-xs, 0.75rem);',
    '  font-weight: var(--font-semibold, 600);',
    '  text-transform: uppercase;',
    '  letter-spacing: 0.06em;',
    '  color: var(--text-muted, #718096);',
    '  margin-bottom: 5px;',
    '}',
    /* Tag group */
    '.qs-nlp-tags {',
    '  display: flex;',
    '  flex-wrap: wrap;',
    '  gap: 5px;',
    '}',
    '.qs-nlp-tag {',
    '  display: inline-block;',
    '  padding: 2px 8px;',
    '  border-radius: var(--radius-sm, 6px);',
    '  font-size: var(--font-size-xs, 0.75rem);',
    '  cursor: default;',
    '  white-space: nowrap;',
    '}',
    '.qs-nlp-tag--person {',
    '  background: var(--info-light, #bee3f8);',
    '  color: var(--info, #3182ce);',
    '  border: 1px solid var(--info, #3182ce);',
    '}',
    '.qs-nlp-tag--org {',
    '  background: var(--accent-light, #dbeafe);',
    '  color: var(--accent, #2563eb);',
    '  border: 1px solid var(--accent, #2563eb);',
    '}',
    '.qs-nlp-tag--geo {',
    '  background: var(--success-light, #c6f6d5);',
    '  color: var(--success, #38a169);',
    '  border: 1px solid var(--success, #38a169);',
    '}',
    '.qs-nlp-tag--default {',
    '  background: var(--bg-secondary, #e8eaed);',
    '  color: var(--text-secondary, #4a5568);',
    '  border: 1px solid var(--border, #e2e8f0);',
    '}',
    '.qs-nlp-tag--topic {',
    '  background: var(--warning-light, #fefcbf);',
    '  color: var(--warning, #d69e2e);',
    '  border: 1px solid var(--warning, #d69e2e);',
    '}',
    '.qs-nlp-tag[title] { cursor: help; }',
    /* Geo */
    '.qs-nlp-geo {',
    '  font-size: var(--font-size-xs, 0.75rem);',
    '  color: var(--text-muted, #718096);',
    '  margin-top: 6px;',
    '}',
    '.qs-nlp-geo__icon { margin-right: 4px; }',
    /* Loading / error states */
    '.qs-nlp-widget--loading .qs-nlp-body { opacity: 0.4; }',
    '.qs-nlp-error {',
    '  font-size: var(--font-size-xs, 0.75rem);',
    '  color: var(--danger, #e53e3e);',
    '}',
  ].join('\n');

  /* -------------------------------------------------------------------------
   * Utility helpers
   * ---------------------------------------------------------------------- */

  /**
   * Inject the widget stylesheet once into <head>.
   * @returns {void}
   */
  function injectStyles() {
    if (document.getElementById('qs-nlp-widget-styles')) return;
    var style = document.createElement('style');
    style.id = 'qs-nlp-widget-styles';
    style.textContent = STYLES;
    document.head.appendChild(style);
  }

  /**
   * Escape a string for safe HTML insertion.
   * @param {*} val
   * @returns {string}
   */
  function esc(val) {
    return String(val)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  /**
   * Resolve the CSS modifier class for a sentiment string.
   * Accepts English and Russian labels, as well as short codes.
   * @param {string} sentiment
   * @returns {string}
   */
  function sentimentModifier(sentiment) {
    if (!sentiment) return 'qs-nlp-sentiment--neutral';
    var s = sentiment.toLowerCase();
    if (s === 'positive' || s === 'pos' || s === '\u043f\u043e\u0437\u0438\u0442\u0438\u0432\u043d\u044b\u0439')
      return 'qs-nlp-sentiment--positive';
    if (s === 'negative' || s === 'neg' || s === '\u043d\u0435\u0433\u0430\u0442\u0438\u0432\u043d\u044b\u0439')
      return 'qs-nlp-sentiment--negative';
    if (s === 'mixed' || s === '\u0441\u043c\u0435\u0448\u0430\u043d\u043d\u044b\u0439')
      return 'qs-nlp-sentiment--mixed';
    return 'qs-nlp-sentiment--neutral';
  }

  /**
   * Resolve the CSS modifier class for an entity type string.
   * @param {string} type  - e.g. 'PER', 'PERSON', 'ORG', 'LOC', 'GEO', 'GPE'
   * @returns {string}
   */
  function entityModifier(type) {
    if (!type) return 'qs-nlp-tag--default';
    var t = type.toUpperCase();
    if (t === 'PER' || t === 'PERSON')                    return 'qs-nlp-tag--person';
    if (t === 'ORG' || t === 'COMPANY')                   return 'qs-nlp-tag--org';
    if (t === 'LOC' || t === 'GEO' || t === 'GPE')        return 'qs-nlp-tag--geo';
    return 'qs-nlp-tag--default';
  }

  /* -------------------------------------------------------------------------
   * Rendering helpers
   * ---------------------------------------------------------------------- */

  /**
   * Render the full widget into `container` using NLP `data`.
   * @param {HTMLElement} container
   * @param {Object}      data      - API response object
   * @param {string}      label     - Header label text
   * @returns {void}
   */
  function renderWidget(container, data, label) {
    var html = [];

    html.push('<div class="qs-nlp-widget" id="qs-nlp-widget-inner">');

    // ── Header: label + sentiment badge ──
    html.push('<div class="qs-nlp-header">');
    html.push('<span class="qs-nlp-label">' + esc(label) + '</span>');

    if (data.sentiment) {
      var mod   = sentimentModifier(data.sentiment);
      var score = data.sentiment_score != null
        ? '<span class="qs-nlp-score">' + Math.round(data.sentiment_score * 100) + '%</span>'
        : '';
      html.push(
        '<span class="qs-nlp-sentiment ' + mod + '">' +
          esc(data.sentiment) + score +
        '</span>'
      );
    }

    html.push('</div>'); // header

    html.push('<hr class="qs-nlp-divider">');
    html.push('<div class="qs-nlp-body">');

    // ── Entities ──
    var entities = (data.entities || []).slice(0, 20);
    if (entities.length) {
      html.push('<div class="qs-nlp-section">');
      html.push('<div class="qs-nlp-section-title">Entities</div>');
      html.push('<div class="qs-nlp-tags">');
      entities.forEach(function (e) {
        var mod     = entityModifier(e.entity_type || e.type);
        var display = e.canonical_name || e.name || '';
        var title   = (e.canonical_name && e.canonical_name !== e.name)
          ? ' title="' + esc(e.name) + '"'
          : '';
        html.push(
          '<span class="qs-nlp-tag ' + mod + '"' + title + '>' +
            esc(display) +
          '</span>'
        );
      });
      html.push('</div>'); // tags
      html.push('</div>'); // section
    }

    // ── Topics ──
    var topics = (data.topics || []).slice(0, 15);
    if (topics.length) {
      html.push('<div class="qs-nlp-section">');
      html.push('<div class="qs-nlp-section-title">Topics</div>');
      html.push('<div class="qs-nlp-tags">');
      topics.forEach(function (t) {
        var name = typeof t === 'string' ? t : (t.name || '');
        html.push(
          '<span class="qs-nlp-tag qs-nlp-tag--topic">' +
            esc(name) +
          '</span>'
        );
      });
      html.push('</div>');
      html.push('</div>');
    }

    // ── Geo ──
    var geo = data.geo_region_name || data.geo_focus || data.geo;
    if (geo) {
      html.push(
        '<div class="qs-nlp-geo">' +
          '<span class="qs-nlp-geo__icon" aria-hidden="true">\uD83D\uDCCD</span>' +
          esc(geo) +
        '</div>'
      );
    }

    html.push('</div>'); // body
    html.push('</div>'); // widget

    container.innerHTML = html.join('');
  }

  /**
   * Render a loading skeleton into `container`.
   * @param {HTMLElement} container
   * @param {string}      label
   * @returns {void}
   */
  function renderLoading(container, label) {
    container.innerHTML =
      '<div class="qs-nlp-widget qs-nlp-widget--loading">' +
        '<div class="qs-nlp-header">' +
          '<span class="qs-nlp-label">' + esc(label) + '</span>' +
          '<span style="color:var(--text-muted,#718096);font-size:0.75rem">Loading\u2026</span>' +
        '</div>' +
      '</div>';
  }

  /**
   * Render an error message into `container`.
   * @param {HTMLElement} container
   * @param {string}      msg
   * @returns {void}
   */
  function renderError(container, msg) {
    container.innerHTML =
      '<div class="qs-nlp-widget">' +
        '<span class="qs-nlp-error">NLP: ' + esc(msg) + '</span>' +
      '</div>';
  }

  /* -------------------------------------------------------------------------
   * Fetch
   * ---------------------------------------------------------------------- */

  /**
   * Fetch NLP data for an article from the API.
   * @param {string}   apiBase    - URL prefix (may be empty string)
   * @param {string}   apiPath    - Path template, articleId appended
   * @param {number}   articleId
   * @param {Function} callback   - (err: string|null, data: Object|null) => void
   * @returns {void}
   */
  function fetchNLP(apiBase, apiPath, articleId, callback) {
    var url = (apiBase || '') + apiPath + encodeURIComponent(articleId);
    var xhr = new XMLHttpRequest();
    xhr.open('GET', url, true);
    xhr.setRequestHeader('Accept', 'application/json');
    xhr.onreadystatechange = function () {
      if (xhr.readyState !== 4) return;
      if (xhr.status === 200) {
        try {
          callback(null, JSON.parse(xhr.responseText));
        } catch (e) {
          callback('JSON parse error');
        }
      } else if (xhr.status === 404) {
        callback('no_data');
      } else {
        callback('HTTP ' + xhr.status);
      }
    };
    xhr.onerror = function () { callback('Network error'); };
    xhr.send();
  }

  /* -------------------------------------------------------------------------
   * Public init
   * ---------------------------------------------------------------------- */

  /**
   * Initialise an NLP widget instance.
   *
   * @param {Object}  opts
   * @param {number|string} opts.articleId   - Article identifier (required)
   * @param {string} [opts.apiBase]          - URL prefix, e.g. 'https://api.example.com' (default '')
   * @param {string} [opts.apiPath]          - API path, articleId appended (default '/api/nlp/article/')
   * @param {string} [opts.target]           - CSS selector for mount point (default '#qs-nlp-widget-container')
   * @param {string} [opts.label]            - Header label text (default 'NLP Analysis')
   * @returns {void}
   */
  function init(opts) {
    opts = opts || {};
    var articleId = opts.articleId;
    var apiBase   = opts.apiBase  != null ? opts.apiBase  : '';
    var apiPath   = opts.apiPath  || '/api/nlp/article/';
    var targetSel = opts.target   || '#qs-nlp-widget-container';
    var label     = opts.label    || 'NLP Analysis';

    if (!articleId) {
      console.warn('[QS.NLPWidget] opts.articleId is required.');
      return;
    }

    injectStyles();

    // Find or create the mount container
    var container = document.querySelector(targetSel);
    if (!container) {
      container = document.createElement('div');
      container.id = 'qs-nlp-widget-container';
      // Try to insert at a sensible place near article content
      var anchor =
        document.querySelector('article .article-body') ||
        document.querySelector('[data-article-body]')   ||
        document.querySelector('.article-content')       ||
        document.querySelector('article')                ||
        document.body;
      anchor.insertBefore(container, anchor.firstChild);
    }

    renderLoading(container, label);

    fetchNLP(apiBase, apiPath, articleId, function (err, data) {
      if (err === 'no_data') {
        container.innerHTML = ''; // silent – no NLP data yet
        return;
      }
      if (err) {
        renderError(container, 'Failed to load data');
        console.warn('[QS.NLPWidget] Error:', err);
        return;
      }
      renderWidget(container, data, label);
    });
  }

  /* -------------------------------------------------------------------------
   * Auto-init from <script data-article-id="…"> attributes
   * ---------------------------------------------------------------------- */

  /**
   * Scan all <script data-article-id> tags and call init() for each.
   * @returns {void}
   */
  function autoInit() {
    var scripts = document.querySelectorAll('script[data-article-id]');
    for (var i = 0; i < scripts.length; i++) {
      var s  = scripts[i];
      var id = parseInt(s.getAttribute('data-article-id'), 10);
      if (!isNaN(id)) {
        init({
          articleId: id,
          apiBase:   s.getAttribute('data-api-base') || '',
          apiPath:   s.getAttribute('data-api-path') || '/api/nlp/article/',
          target:    s.getAttribute('data-target')   || '#qs-nlp-widget-container',
          label:     s.getAttribute('data-label')    || 'NLP Analysis',
        });
      }
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', autoInit);
  } else {
    autoInit();
  }

  /* -------------------------------------------------------------------------
   * Public API
   * ---------------------------------------------------------------------- */
  global.QS = global.QS || {};

  /**
   * @namespace QS.NLPWidget
   */
  global.QS.NLPWidget = {
    /**
     * Initialise a new NLP widget instance.
     * @type {Function}
     * @see init
     */
    init: init,
  };

})(typeof window !== 'undefined' ? window : this);
