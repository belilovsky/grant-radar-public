/**
 * QazStack ranked search.
 *
 * Dependency-free relevance ranking for static indexes and browser catalogs.
 * Keeps direct title/category matches ahead of secondary keywords so a locality
 * mentioned inside another record does not outrank the locality's own page.
 */
(function (global) {
    'use strict';

    global.QS = global.QS || {};

    function normalize(value, locale) {
        return String(value || '')
            .normalize('NFKC')
            .trim()
            .toLocaleLowerCase(locale || 'ru-RU')
            .replace(/\s+/g, ' ');
    }

    function terms(item, field) {
        return Array.isArray(item && item[field]) ? item[field] : [];
    }

    function kindWeight(item, options) {
        var weights = options.kindWeights || {
            published: 3,
            detail: 2,
            collection: 1,
            index: 0
        };
        return weights[(item && item.kind) || 'index'] || 0;
    }

    function pageWeight(item, options) {
        var weights = options.pageWeights || {};
        var page = (item && item.page) || '';
        return Object.prototype.hasOwnProperty.call(weights, page) ? weights[page] : 999;
    }

    function matchTier(item, normalizedQuery, tokens, options) {
        var locale = options.locale;
        var title = normalize(item.title, locale);
        var excerpt = normalize(item.excerpt, locale);
        var page = normalize(item.page, locale);
        var category = normalize(item.category, locale);
        var primary = normalize(terms(item, 'primary_terms').concat([title]).join(' '), locale);
        var secondary = normalize(
            terms(item, 'secondary_terms').concat(terms(item, 'keywords')).join(' '),
            locale
        );

        if ([title, excerpt, page, category].some(function (value) {
            return value.indexOf(normalizedQuery) !== -1;
        })) return 3;
        if (tokens.every(function (token) { return primary.indexOf(token) !== -1; })) return 2;
        if (tokens.every(function (token) { return secondary.indexOf(token) !== -1; })) return 1;
        return 0;
    }

    function scoreItem(item, normalizedQuery, tokens, tier, options) {
        if (!normalizedQuery) return 1;

        var locale = options.locale;
        var title = normalize(item.title, locale);
        var excerpt = normalize(item.excerpt, locale);
        var page = normalize(item.page, locale);
        var category = normalize(item.category, locale);
        var searchText = normalize(item.search_text, locale);
        var matchedTokens = tokens.filter(function (token) {
            return searchText.indexOf(token) !== -1;
        });

        if (matchedTokens.length === 0) return 0;

        var score = matchedTokens.length * 12 + tier * 30;
        if (title === normalizedQuery) score += 140;
        if (title.indexOf(normalizedQuery) === 0) score += 80;
        if (title.indexOf(normalizedQuery) !== -1) score += 60;
        if (page === normalizedQuery) score += 120;
        if (page.indexOf(normalizedQuery) !== -1 || category.indexOf(normalizedQuery) !== -1) score += 25;
        if (excerpt.indexOf(normalizedQuery) !== -1) score += 18;
        if (searchText.indexOf(normalizedQuery) !== -1) score += 12;
        score += kindWeight(item, options) * 6;

        matchedTokens.forEach(function (token) {
            if (title.indexOf(token) !== -1) score += 14;
            else if (page.indexOf(token) !== -1 || category.indexOf(token) !== -1) score += 8;
            else if (excerpt.indexOf(token) !== -1) score += 5;
            else score += 3;
        });

        if (matchedTokens.length === tokens.length && tokens.length > 1) score += 20;
        return score;
    }

    function compareItems(left, right, options) {
        if (right.score !== left.score) return right.score - left.score;
        var kindDifference = kindWeight(right, options) - kindWeight(left, options);
        if (kindDifference !== 0) return kindDifference;
        var pageDifference = pageWeight(left, options) - pageWeight(right, options);
        if (pageDifference !== 0) return pageDifference;
        return String(left.title || '').localeCompare(String(right.title || ''), options.locale || 'ru');
    }

    function search(items, query, suppliedOptions) {
        var options = suppliedOptions || {};
        var normalizedQuery = normalize(query, options.locale);
        var source = Array.isArray(items) ? items : [];

        if (!normalizedQuery) {
            return source.map(function (item) {
                return Object.assign({}, item, { score: 1, tier: 0 });
            }).sort(function (left, right) { return compareItems(left, right, options); });
        }

        var minimumTokenLength = Number.isInteger(options.minimumTokenLength)
            ? options.minimumTokenLength
            : 1;
        var tokens = normalizedQuery.split(' ').filter(function (token) {
            return token.length >= minimumTokenLength;
        });
        var ranked = source.map(function (item) {
            var tier = matchTier(item, normalizedQuery, tokens, options);
            return Object.assign({}, item, {
                tier: tier,
                score: scoreItem(item, normalizedQuery, tokens, tier, options)
            });
        }).filter(function (item) {
            return item.score > 0 && item.tier > 0;
        });
        var highestTier = ranked.reduce(function (highest, item) {
            return Math.max(highest, item.tier);
        }, 0);

        return ranked.filter(function (item) {
            return highestTier < 2 || item.tier >= 2;
        }).sort(function (left, right) {
            return compareItems(left, right, options);
        });
    }

    global.QS.RankedSearch = {
        normalize: normalize,
        matchTier: matchTier,
        scoreItem: scoreItem,
        search: search
    };
})(typeof window !== 'undefined' ? window : globalThis);
