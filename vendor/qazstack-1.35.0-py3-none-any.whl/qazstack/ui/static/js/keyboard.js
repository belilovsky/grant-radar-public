/**
 * QazStack Keyboard Shortcuts
 * Universal shortcuts that work across all projects.
 *
 * Built-in:
 *   Escape  – close any open modal/dropdown with .qs-modal.open or [data-qs-closable].open
 *   /       – focus search input (first .qs-search__input or [data-qs-search-focus])
 *   ?       – toggle shortcuts help modal (#qs-shortcuts-modal)
 *
 * Custom shortcuts via data attributes:
 *   <button data-qs-hotkey="ctrl+s" onclick="save()">Save</button>
 *
 * All shortcuts are suppressed when focus is inside input/textarea/select/contenteditable.
 */
(function () {
    'use strict';

    function isInput(el) {
        return el.matches('input, textarea, select, [contenteditable="true"]');
    }

    function closeOpenModals() {
        var closed = false;
        // Close .qs-modal.open
        document.querySelectorAll('.qs-modal.open').forEach(function (m) {
            m.classList.remove('open');
            closed = true;
        });
        // Close [data-qs-closable].open
        document.querySelectorAll('[data-qs-closable].open').forEach(function (m) {
            m.classList.remove('open');
            closed = true;
        });
        // Close .qs-toast-container toasts (dismiss all)
        return closed;
    }

    function focusSearch() {
        var input = document.querySelector('[data-qs-search-focus]') ||
                    document.querySelector('.qs-search__input') ||
                    document.querySelector('.search-box input') ||
                    document.querySelector('input[type="search"]');
        if (input) {
            input.focus();
            return true;
        }
        return false;
    }

    function toggleShortcutsHelp() {
        var modal = document.getElementById('qs-shortcuts-modal');
        if (modal) {
            modal.classList.toggle('open');
            return true;
        }
        return false;
    }

    document.addEventListener('keydown', function (e) {
        var inInput = isInput(e.target);

        // Escape – always works (even in inputs)
        if (e.key === 'Escape') {
            closeOpenModals();
            return;
        }

        // Skip the rest if we're in an input field
        if (inInput) return;

        // / – focus search
        if (e.key === '/') {
            if (focusSearch()) e.preventDefault();
            return;
        }

        // ? – shortcuts help
        if (e.key === '?') {
            if (toggleShortcutsHelp()) e.preventDefault();
            return;
        }

        // Custom hotkeys via data-qs-hotkey
        var combo = '';
        if (e.ctrlKey || e.metaKey) combo += 'ctrl+';
        if (e.shiftKey) combo += 'shift+';
        if (e.altKey) combo += 'alt+';
        combo += e.key.toLowerCase();

        var hotkeyEl = document.querySelector('[data-qs-hotkey="' + combo + '"]');
        if (hotkeyEl) {
            e.preventDefault();
            hotkeyEl.click();
        }
    });
})();
