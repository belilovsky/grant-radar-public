/**
 * QazStack Client-Side Search/Filter
 * Filters elements with [data-searchable] by text content.
 * Usage: Add input with data-qs-search="<container-selector>"
 */
(function () {
    'use strict';

    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('[data-qs-search]').forEach(function (input) {
            var containerSel = input.getAttribute('data-qs-search');
            var container = document.querySelector(containerSel);
            if (!container) return;

            var clearBtn = input.parentElement && input.parentElement.querySelector('.qs-search__clear');
            var items = container.querySelectorAll('[data-searchable]');
            var emptyEl = container.querySelector('[data-search-empty]');

            function filterItems() {
                var query = input.value.toLowerCase().trim();
                var visible = 0;

                items.forEach(function (el) {
                    var text = (el.getAttribute('data-searchable') || el.textContent).toLowerCase();
                    var match = !query || text.indexOf(query) !== -1;
                    el.style.display = match ? '' : 'none';
                    if (match) visible++;
                });

                if (emptyEl) {
                    emptyEl.style.display = (visible === 0 && query) ? '' : 'none';
                }

                if (clearBtn) {
                    clearBtn.classList.toggle('visible', query.length > 0);
                }
            }

            input.addEventListener('input', filterItems);

            if (clearBtn) {
                clearBtn.addEventListener('click', function () {
                    input.value = '';
                    filterItems();
                    input.focus();
                });
            }
        });
    });
})();
