/**
 * QazStack Back-to-Top Button
 * Shows after scrolling 400px, smooth scrolls to top.
 */
(function () {
    'use strict';

    document.addEventListener('DOMContentLoaded', function () {
        var btn = document.getElementById('qsBackToTop');
        if (!btn) return;

        var threshold = parseInt(btn.getAttribute('data-threshold') || '400', 10);
        var ticking = false;

        function checkScroll() {
            btn.classList.toggle('visible', window.scrollY > threshold);
            ticking = false;
        }

        window.addEventListener('scroll', function () {
            if (!ticking) {
                requestAnimationFrame(checkScroll);
                ticking = true;
            }
        }, { passive: true });

        btn.addEventListener('click', function () {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    });
})();
