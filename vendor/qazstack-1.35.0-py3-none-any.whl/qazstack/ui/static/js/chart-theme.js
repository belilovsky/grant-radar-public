/**
 * QazStack Chart.js Dark Mode Integration
 * Automatically syncs Chart.js defaults and existing instances with data-theme.
 *
 * Include AFTER chart.js and AFTER the theme is set on <html>.
 * Works with any Chart.js v3+/v4 chart (bar, line, doughnut, pie, etc.).
 *
 * Helpers exposed:
 *   chartScaleDefaults()  → { ticks, grid, border } for custom scale config
 *   chartDonutBorder()    → border color matching current theme
 */
(function () {
    'use strict';

    function isDark() {
        return document.documentElement.getAttribute('data-theme') === 'dark';
    }

    function themeColors() {
        var dark = isDark();
        return {
            text:   dark ? '#c9d1d9' : '#4a5568',
            grid:   dark ? 'rgba(139,148,158,0.18)' : 'rgba(0,0,0,0.06)',
            border: dark ? '#30363d' : '#e2e8ef',
            tooltip_bg:    dark ? '#2a2d36' : '#1a1d26',
            tooltip_text:  dark ? '#e8eaed' : '#ffffff'
        };
    }

    function applyDefaults() {
        if (typeof Chart === 'undefined') return;
        var c = themeColors();
        Chart.defaults.color = c.text;
        Chart.defaults.borderColor = c.border;
        if (Chart.defaults.scale && Chart.defaults.scale.grid) {
            Chart.defaults.scale.grid.color = c.grid;
        }
    }

    /** Returns object suitable for options.scales.x / .y */
    window.chartScaleDefaults = function () {
        var c = themeColors();
        return {
            ticks:  { color: c.text },
            grid:   { color: c.grid },
            border: { color: c.border }
        };
    };

    /** Returns donut/pie borderColor matching current theme */
    window.chartDonutBorder = function () {
        return isDark() ? '#1c2128' : '#ffffff';
    };

    /** Re-apply defaults AND update every existing chart instance */
    function refreshAllCharts() {
        applyDefaults();
        if (typeof Chart === 'undefined') return;

        var instances = Chart.instances || {};
        var keys = Object.keys(instances);
        for (var i = 0; i < keys.length; i++) {
            var chart = instances[keys[i]];
            if (!chart) continue;
            var c = themeColors();

            // Update scale colours
            if (chart.options.scales) {
                ['x', 'y', 'r'].forEach(function (axis) {
                    var s = chart.options.scales[axis];
                    if (s) {
                        if (s.ticks)  s.ticks.color  = c.text;
                        if (s.grid)   s.grid.color   = c.grid;
                        if (s.border) s.border.color  = c.border;
                    }
                });
            }

            // Tooltip colours
            if (chart.options.plugins && chart.options.plugins.tooltip) {
                chart.options.plugins.tooltip.backgroundColor = c.tooltip_bg;
                chart.options.plugins.tooltip.titleColor = c.tooltip_text;
                chart.options.plugins.tooltip.bodyColor = c.tooltip_text;
            }

            // Donut/pie: update borderColor on datasets
            if (chart.config.type === 'doughnut' || chart.config.type === 'pie') {
                chart.data.datasets.forEach(function (ds) {
                    ds.borderColor = chartDonutBorder();
                });
            }

            // Legend label colour
            if (chart.options.plugins && chart.options.plugins.legend &&
                chart.options.plugins.legend.labels) {
                chart.options.plugins.legend.labels.color = c.text;
            }

            chart.update('none');
        }
    }

    // Apply on load
    applyDefaults();

    // Watch for theme toggle via MutationObserver
    var obs = new MutationObserver(function (mutations) {
        for (var i = 0; i < mutations.length; i++) {
            if (mutations[i].attributeName === 'data-theme') {
                refreshAllCharts();
                break;
            }
        }
    });
    obs.observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
})();
