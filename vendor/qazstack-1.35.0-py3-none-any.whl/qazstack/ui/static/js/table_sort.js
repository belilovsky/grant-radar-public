/**
 * QazStack Sortable Table
 * Click column headers to sort. Supports text, number, date.
 *
 * Usage:
 *   <table class="qs-table" data-qs-sortable>
 *     <thead><tr>
 *       <th data-sort="text">Name</th>
 *       <th data-sort="number">Count</th>
 *       <th data-sort="date">Date</th>
 *       <th>Actions</th>  <!-- no data-sort = not sortable -->
 *     </tr></thead>
 *     <tbody>...</tbody>
 *   </table>
 */
(function () {
    'use strict';

    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('table[data-qs-sortable]').forEach(initTable);
    });

    function initTable(table) {
        var headers = table.querySelectorAll('th[data-sort]');
        headers.forEach(function (th, colIdx) {
            th.classList.add('qs-table__sortable');
            th.setAttribute('role', 'columnheader');
            th.setAttribute('aria-sort', 'none');
            th.style.cursor = 'pointer';
            th.setAttribute('tabindex', '0');

            // Add sort indicator
            var indicator = document.createElement('span');
            indicator.className = 'qs-table__sort-icon';
            indicator.setAttribute('aria-hidden', 'true');
            indicator.textContent = ' ↕';
            th.appendChild(indicator);

            th.addEventListener('click', function () {
                sortColumn(table, th, colIdx);
            });
            th.addEventListener('keydown', function (e) {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    sortColumn(table, th, colIdx);
                }
            });
        });
    }

    function sortColumn(table, th, colIdx) {
        var tbody = table.querySelector('tbody');
        if (!tbody) return;

        var rows = Array.from(tbody.querySelectorAll('tr'));
        var type = th.getAttribute('data-sort');
        var currentDir = th.getAttribute('aria-sort');
        var dir = currentDir === 'ascending' ? 'descending' : 'ascending';

        // Reset all headers
        table.querySelectorAll('th[data-sort]').forEach(function (h) {
            h.setAttribute('aria-sort', 'none');
            var icon = h.querySelector('.qs-table__sort-icon');
            if (icon) icon.textContent = ' ↕';
        });

        // Set current
        th.setAttribute('aria-sort', dir);
        var icon = th.querySelector('.qs-table__sort-icon');
        if (icon) icon.textContent = dir === 'ascending' ? ' ↑' : ' ↓';

        var mult = dir === 'ascending' ? 1 : -1;

        rows.sort(function (a, b) {
            var cellA = a.cells[colIdx];
            var cellB = b.cells[colIdx];
            if (!cellA || !cellB) return 0;

            var valA = (cellA.getAttribute('data-sort-value') || cellA.textContent).trim();
            var valB = (cellB.getAttribute('data-sort-value') || cellB.textContent).trim();

            if (type === 'number') {
                var numA = parseFloat(valA.replace(/[^\d.\-]/g, '')) || 0;
                var numB = parseFloat(valB.replace(/[^\d.\-]/g, '')) || 0;
                return (numA - numB) * mult;
            }

            if (type === 'date') {
                var dateA = new Date(valA).getTime() || 0;
                var dateB = new Date(valB).getTime() || 0;
                return (dateA - dateB) * mult;
            }

            // text
            return valA.localeCompare(valB, undefined, { sensitivity: 'base' }) * mult;
        });

        // Re-append sorted rows
        rows.forEach(function (row) {
            tbody.appendChild(row);
        });
    }
})();
