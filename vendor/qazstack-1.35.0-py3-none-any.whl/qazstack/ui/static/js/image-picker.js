/**
 * @file image-picker.js
 * @description QazStack Image Picker – a grid-based image selection component with
 *              lazy loading and a preview modal.
 * @version 1.0.0
 *
 * Features:
 *  - Responsive grid of selectable images
 *  - Single or multi-select modes
 *  - Selected images show a visual indicator (border + checkmark overlay)
 *  - Lazy loading via IntersectionObserver (images load as they scroll into view)
 *  - Click any image to open a full-size preview modal
 *  - `onSelect` callback receives the selected image object(s)
 *  - Images supplied as an array of objects or loaded from a [data-src] grid in the DOM
 *  - CSS uses qazstack.ui design tokens
 *  - Accessible: keyboard navigable, ARIA labels, Escape closes modal
 *  - Self-injects its CSS once
 *  - Zero dependencies, vanilla JS
 *
 * Usage:
 *
 *   QS.ImagePicker.init({
 *     container: '#my-picker',         // mount point selector or HTMLElement (required)
 *     images: [                        // array of image objects (required unless using DOM)
 *       { id: 1, src: '/img/1.jpg', alt: 'Photo 1', thumb: '/img/1-thumb.jpg' },
 *       { id: 2, src: '/img/2.jpg', alt: 'Photo 2' },
 *     ],
 *     mode:     'single',              // 'single' (default) or 'multi'
 *     onSelect: function(selected) {   // called with the selected item (single) or array (multi)
 *       // handle selection – e.g. populate a hidden input
 *       document.getElementById('selected-id').value = selected ? selected.id : '';
 *     },
 *     columns:  4,                     // grid columns on desktop (default 4)
 *     gap:      '12px',                // grid gap (default '12px')
 *   });
 */

(function (global) {
  'use strict';

  /* -------------------------------------------------------------------------
   * Injected CSS – uses qazstack.ui design tokens
   * ---------------------------------------------------------------------- */
  var STYLES = [
    /* Container */
    '.qs-picker {',
    '  font-family: var(--font-family, system-ui, sans-serif);',
    '  position: relative;',
    '}',
    /* Grid */
    '.qs-picker-grid {',
    '  display: grid;',
    '  grid-template-columns: repeat(var(--qs-picker-cols, 4), 1fr);',
    '  gap: var(--qs-picker-gap, 12px);',
    '}',
    '@media (max-width: 768px) {',
    '  .qs-picker-grid { grid-template-columns: repeat(2, 1fr); }',
    '}',
    '@media (max-width: 480px) {',
    '  .qs-picker-grid { grid-template-columns: repeat(2, 1fr); }',
    '}',
    /* Individual item wrapper */
    '.qs-picker-item {',
    '  position: relative;',
    '  border-radius: var(--radius-sm, 6px);',
    '  overflow: hidden;',
    '  cursor: pointer;',
    '  aspect-ratio: 1 / 1;',
    '  background: var(--bg-secondary, #e8eaed);',
    '  border: 2px solid transparent;',
    '  transition: border-color var(--transition-fast, 0.15s ease),',
    '              box-shadow var(--transition-fast, 0.15s ease),',
    '              transform var(--transition-fast, 0.15s ease);',
    '  outline: none;',
    '}',
    '.qs-picker-item:hover {',
    '  box-shadow: var(--shadow-md, 0 4px 12px rgba(0,0,0,0.08));',
    '  transform: translateY(-1px);',
    '}',
    '.qs-picker-item:focus-visible {',
    '  border-color: var(--accent, #2563eb);',
    '  box-shadow: 0 0 0 3px var(--accent-light, #dbeafe);',
    '}',
    /* Selected state */
    '.qs-picker-item.qs-selected {',
    '  border-color: var(--accent, #2563eb);',
    '  box-shadow: 0 0 0 3px var(--accent-light, #dbeafe);',
    '}',
    /* Checkmark overlay – hidden by default */
    '.qs-picker-check {',
    '  position: absolute;',
    '  top: 6px;',
    '  right: 6px;',
    '  width: 22px;',
    '  height: 22px;',
    '  border-radius: 50%;',
    '  background: var(--accent, #2563eb);',
    '  display: flex;',
    '  align-items: center;',
    '  justify-content: center;',
    '  opacity: 0;',
    '  transform: scale(0.6);',
    '  transition: opacity var(--transition-fast, 0.15s ease),',
    '              transform var(--transition-fast, 0.15s ease);',
    '  pointer-events: none;',
    '}',
    '.qs-picker-item.qs-selected .qs-picker-check {',
    '  opacity: 1;',
    '  transform: scale(1);',
    '}',
    '.qs-picker-check svg {',
    '  width: 13px;',
    '  height: 13px;',
    '  stroke: #fff;',
    '  stroke-width: 2.5;',
    '  fill: none;',
    '}',
    /* Lazy image */
    '.qs-picker-img {',
    '  width: 100%;',
    '  height: 100%;',
    '  object-fit: cover;',
    '  display: block;',
    '  transition: opacity var(--transition, 0.2s ease);',
    '}',
    '.qs-picker-img[data-lazy-src] { opacity: 0; }',
    '.qs-picker-img.qs-loaded { opacity: 1; }',
    /* Preview button overlay */
    '.qs-picker-preview-btn {',
    '  position: absolute;',
    '  bottom: 6px;',
    '  left: 6px;',
    '  width: 26px;',
    '  height: 26px;',
    '  border-radius: var(--radius-sm, 6px);',
    '  background: rgba(0,0,0,0.5);',
    '  border: none;',
    '  cursor: pointer;',
    '  display: flex;',
    '  align-items: center;',
    '  justify-content: center;',
    '  opacity: 0;',
    '  transition: opacity var(--transition-fast, 0.15s ease);',
    '  padding: 0;',
    '}',
    '.qs-picker-preview-btn svg {',
    '  width: 14px;',
    '  height: 14px;',
    '  stroke: #fff;',
    '  stroke-width: 2;',
    '  fill: none;',
    '}',
    '.qs-picker-item:hover .qs-picker-preview-btn { opacity: 1; }',
    /* Modal overlay */
    '.qs-picker-modal {',
    '  position: fixed;',
    '  inset: 0;',
    '  z-index: var(--z-modal, 400);',
    '  background: rgba(0,0,0,0.8);',
    '  display: flex;',
    '  align-items: center;',
    '  justify-content: center;',
    '  opacity: 0;',
    '  pointer-events: none;',
    '  transition: opacity var(--transition, 0.2s ease);',
    '}',
    '.qs-picker-modal.qs-open {',
    '  opacity: 1;',
    '  pointer-events: all;',
    '}',
    '.qs-picker-modal-inner {',
    '  position: relative;',
    '  max-width: min(90vw, 900px);',
    '  max-height: 90vh;',
    '  border-radius: var(--radius, 10px);',
    '  overflow: hidden;',
    '  background: var(--surface, #fff);',
    '  box-shadow: var(--shadow-lg, 0 8px 30px rgba(0,0,0,0.12));',
    '  transform: scale(0.95);',
    '  transition: transform var(--transition, 0.2s ease);',
    '}',
    '.qs-picker-modal.qs-open .qs-picker-modal-inner {',
    '  transform: scale(1);',
    '}',
    '.qs-picker-modal-img {',
    '  display: block;',
    '  max-width: 100%;',
    '  max-height: 85vh;',
    '  width: auto;',
    '  height: auto;',
    '}',
    '.qs-picker-modal-footer {',
    '  padding: 10px 16px;',
    '  background: var(--surface, #fff);',
    '  display: flex;',
    '  align-items: center;',
    '  justify-content: space-between;',
    '  gap: 12px;',
    '}',
    '.qs-picker-modal-alt {',
    '  font-size: var(--font-size-sm, 0.875rem);',
    '  color: var(--text-secondary, #4a5568);',
    '  overflow: hidden;',
    '  white-space: nowrap;',
    '  text-overflow: ellipsis;',
    '}',
    '.qs-picker-modal-close {',
    '  position: absolute;',
    '  top: 10px;',
    '  right: 10px;',
    '  width: 32px;',
    '  height: 32px;',
    '  border-radius: 50%;',
    '  background: rgba(0,0,0,0.5);',
    '  border: none;',
    '  cursor: pointer;',
    '  display: flex;',
    '  align-items: center;',
    '  justify-content: center;',
    '  color: #fff;',
    '  font-size: 18px;',
    '  line-height: 1;',
    '  padding: 0;',
    '  transition: background var(--transition-fast, 0.15s ease);',
    '}',
    '.qs-picker-modal-close:hover { background: rgba(0,0,0,0.7); }',
    '.qs-picker-modal-select {',
    '  flex-shrink: 0;',
    '  padding: 6px 16px;',
    '  border-radius: var(--radius-full, 9999px);',
    '  background: var(--accent, #2563eb);',
    '  color: var(--accent-text, #fff);',
    '  border: none;',
    '  cursor: pointer;',
    '  font-size: var(--font-size-sm, 0.875rem);',
    '  font-weight: var(--font-semibold, 600);',
    '  transition: background var(--transition-fast, 0.15s ease);',
    '}',
    '.qs-picker-modal-select:hover { background: var(--accent-hover, #1d4ed8); }',
    '.qs-picker-modal-select.qs-selected-btn {',
    '  background: var(--success, #38a169);',
    '}',
  ].join('\n');

  /**
   * Inject the component stylesheet once.
   * @returns {void}
   */
  function injectStyles() {
    if (document.getElementById('qs-image-picker-styles')) return;
    var style = document.createElement('style');
    style.id = 'qs-image-picker-styles';
    style.textContent = STYLES;
    document.head.appendChild(style);
  }

  /* -------------------------------------------------------------------------
   * SVG icons (inline, no external dependency)
   * ---------------------------------------------------------------------- */
  var CHECK_SVG =
    '<svg viewBox="0 0 16 16" aria-hidden="true">' +
      '<polyline points="2 8 6 12 14 4"/>' +
    '</svg>';

  var EXPAND_SVG =
    '<svg viewBox="0 0 16 16" aria-hidden="true">' +
      '<polyline points="10 2 14 2 14 6"/>' +
      '<line x1="9" y1="7" x2="14" y2="2"/>' +
      '<polyline points="6 14 2 14 2 10"/>' +
      '<line x1="7" y1="9" x2="2" y2="14"/>' +
    '</svg>';

  /* -------------------------------------------------------------------------
   * Core init
   * ---------------------------------------------------------------------- */

  /**
   * Initialise an ImagePicker instance.
   *
   * @param {Object}       opts
   * @param {string|HTMLElement} opts.container  - Mount point (required)
   * @param {Array<Object>}     opts.images      - Array of image descriptors (required)
   *   Each image: { id, src, alt?, thumb? }
   * @param {string}      [opts.mode]            - 'single' (default) or 'multi'
   * @param {Function}    [opts.onSelect]        - Called with selected item (single) or array (multi)
   * @param {number}      [opts.columns]         - Grid columns on desktop (default 4)
   * @param {string}      [opts.gap]             - Grid gap CSS value (default '12px')
   * @returns {{ getSelected: Function, clearSelection: Function, destroy: Function }}
   */
  function init(opts) {
    opts = opts || {};

    // Resolve container
    var container = opts.container;
    if (typeof container === 'string') {
      container = document.querySelector(container);
    }
    if (!container) {
      console.warn('[QS.ImagePicker] container not found:', opts.container);
      return null;
    }

    var images   = opts.images   || [];
    var mode     = opts.mode     === 'multi' ? 'multi' : 'single';
    var onSelect = typeof opts.onSelect === 'function' ? opts.onSelect : null;
    var columns  = opts.columns  || 4;
    var gap      = opts.gap      || '12px';

    injectStyles();

    // Selection state: Set of image ids
    var selected = new Set();

    // ── Build wrapper ──
    var root = document.createElement('div');
    root.className = 'qs-picker';

    // ── Build grid ──
    var grid = document.createElement('div');
    grid.className = 'qs-picker-grid';
    grid.style.setProperty('--qs-picker-cols', String(columns));
    grid.style.setProperty('--qs-picker-gap', gap);
    grid.setAttribute('role', 'list');
    grid.setAttribute('aria-label', mode === 'multi' ? 'Select images' : 'Select an image');

    root.appendChild(grid);

    // ── Build modal ──
    var modal      = buildModal();
    var modalImg   = modal.querySelector('.qs-picker-modal-img');
    var modalAlt   = modal.querySelector('.qs-picker-modal-alt');
    var modalBtn   = modal.querySelector('.qs-picker-modal-select');
    var modalClose = modal.querySelector('.qs-picker-modal-close');
    var currentModalId = null;

    root.appendChild(modal);
    container.appendChild(root);

    // ── Lazy image observer ──
    var lazyObserver = null;
    if ('IntersectionObserver' in window) {
      lazyObserver = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            var img = entry.target;
            var lazySrc = img.getAttribute('data-lazy-src');
            if (lazySrc) {
              img.src = lazySrc;
              img.removeAttribute('data-lazy-src');
              img.addEventListener('load', function () {
                img.classList.add('qs-loaded');
              });
              img.addEventListener('error', function () {
                img.classList.add('qs-loaded'); // reveal anyway
              });
            }
            lazyObserver.unobserve(img);
          }
        });
      }, { rootMargin: '200px' });
    }

    // ── Render image items ──
    images.forEach(function (image, index) {
      var item = buildItem(image, index);
      grid.appendChild(item);
    });

    // ── Modal helpers ──

    /**
     * Build the modal DOM element.
     * @returns {HTMLElement}
     */
    function buildModal() {
      var overlay = document.createElement('div');
      overlay.className = 'qs-picker-modal';
      overlay.setAttribute('role', 'dialog');
      overlay.setAttribute('aria-modal', 'true');
      overlay.setAttribute('aria-label', 'Image preview');

      overlay.innerHTML =
        '<div class="qs-picker-modal-inner">' +
          '<img class="qs-picker-modal-img" src="" alt="" loading="lazy">' +
          '<button class="qs-picker-modal-close" aria-label="Close preview">\u00D7</button>' +
          '<div class="qs-picker-modal-footer">' +
            '<span class="qs-picker-modal-alt"></span>' +
            '<button class="qs-picker-modal-select">Select</button>' +
          '</div>' +
        '</div>';

      // Close on backdrop click
      overlay.addEventListener('click', function (e) {
        if (e.target === overlay) closeModal();
      });

      return overlay;
    }

    /**
     * Open the preview modal for a given image.
     * @param {Object} image
     * @returns {void}
     */
    function openModal(image) {
      currentModalId = image.id;
      modalImg.src    = image.src;
      modalImg.alt    = image.alt || '';
      modalAlt.textContent = image.alt || image.src;
      updateModalBtn(image.id);
      modal.classList.add('qs-open');
      modal.focus();
    }

    /**
     * Close the preview modal.
     * @returns {void}
     */
    function closeModal() {
      modal.classList.remove('qs-open');
      currentModalId = null;
    }

    /**
     * Update the modal Select/Selected button state.
     * @param {*} id
     * @returns {void}
     */
    function updateModalBtn(id) {
      var isSelected = selected.has(id);
      modalBtn.textContent = isSelected ? 'Selected \u2713' : 'Select';
      modalBtn.classList.toggle('qs-selected-btn', isSelected);
    }

    // Modal close button
    modalClose.addEventListener('click', closeModal);

    // Modal select button
    modalBtn.addEventListener('click', function () {
      if (currentModalId == null) return;
      var image = images.find(function (img) { return img.id === currentModalId; });
      if (image) toggleSelect(image);
      updateModalBtn(currentModalId);
    });

    // Keyboard: Escape closes modal
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && modal.classList.contains('qs-open')) {
        closeModal();
      }
    });

    // ── Build a single grid item ──

    /**
     * Build a picker grid item element for a single image.
     * @param {Object} image
     * @param {number} index
     * @returns {HTMLElement}
     */
    function buildItem(image, index) {
      var item = document.createElement('div');
      item.className = 'qs-picker-item';
      item.setAttribute('role', 'listitem');
      item.setAttribute('tabindex', '0');
      item.setAttribute('aria-label', (image.alt || 'Image ' + (index + 1)) + '. Click to select.');
      item.dataset.id = image.id;

      // Lazy image
      var img = document.createElement('img');
      img.className = 'qs-picker-img';
      img.alt = image.alt || '';

      var thumbSrc = image.thumb || image.src;
      if (lazyObserver) {
        img.setAttribute('data-lazy-src', thumbSrc);
        img.src = ''; // placeholder
      } else {
        img.src = thumbSrc;
        img.classList.add('qs-loaded');
      }
      item.appendChild(img);

      // Register lazy loading
      if (lazyObserver) {
        lazyObserver.observe(img);
      }

      // Checkmark overlay
      var check = document.createElement('span');
      check.className = 'qs-picker-check';
      check.setAttribute('aria-hidden', 'true');
      check.innerHTML = CHECK_SVG;
      item.appendChild(check);

      // Preview expand button
      var previewBtn = document.createElement('button');
      previewBtn.className = 'qs-picker-preview-btn';
      previewBtn.setAttribute('aria-label', 'Preview ' + (image.alt || 'image'));
      previewBtn.innerHTML = EXPAND_SVG;
      previewBtn.addEventListener('click', function (e) {
        e.stopPropagation(); // don't also trigger select
        openModal(image);
      });
      item.appendChild(previewBtn);

      // Click = toggle selection
      item.addEventListener('click', function () {
        toggleSelect(image);
        updateItemState(item, image.id);
      });

      // Keyboard: Enter or Space = toggle selection
      item.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          toggleSelect(image);
          updateItemState(item, image.id);
        }
      });

      return item;
    }

    /**
     * Toggle the selected state of an image.
     * In 'single' mode, deselects any currently selected item first.
     * @param {Object} image
     * @returns {void}
     */
    function toggleSelect(image) {
      var id = image.id;

      if (mode === 'single') {
        var prevId = selected.size ? selected.values().next().value : null;
        selected.clear();

        // Update DOM for previous selection
        if (prevId != null && prevId !== id) {
          var prevEl = grid.querySelector('[data-id="' + prevId + '"]');
          if (prevEl) prevEl.classList.remove('qs-selected');
        }

        if (prevId === id) {
          // Deselect if clicking the same item
          if (onSelect) onSelect(null);
          return;
        }
        selected.add(id);
      } else {
        // multi mode
        if (selected.has(id)) {
          selected.delete(id);
        } else {
          selected.add(id);
        }
      }

      // Fire callback
      if (onSelect) {
        if (mode === 'single') {
          onSelect(selected.has(id) ? image : null);
        } else {
          var sel = images.filter(function (img) { return selected.has(img.id); });
          onSelect(sel);
        }
      }
    }

    /**
     * Sync the CSS selected class on a grid item.
     * @param {HTMLElement} item
     * @param {*}           id
     * @returns {void}
     */
    function updateItemState(item, id) {
      item.classList.toggle('qs-selected', selected.has(id));
      item.setAttribute('aria-pressed', String(selected.has(id)));
    }

    /* -------------------------------------------------------------------------
     * Public instance API
     * ---------------------------------------------------------------------- */

    /**
     * Return currently selected images (always an array).
     * @returns {Array<Object>}
     */
    function getSelected() {
      return images.filter(function (img) { return selected.has(img.id); });
    }

    /**
     * Clear all selections.
     * @returns {void}
     */
    function clearSelection() {
      selected.clear();
      grid.querySelectorAll('.qs-selected').forEach(function (el) {
        el.classList.remove('qs-selected');
        el.removeAttribute('aria-pressed');
      });
    }

    /**
     * Remove the picker from the DOM and clean up observers.
     * @returns {void}
     */
    function destroy() {
      if (lazyObserver) lazyObserver.disconnect();
      if (root.parentNode) root.parentNode.removeChild(root);
    }

    return {
      getSelected: getSelected,
      clearSelection: clearSelection,
      destroy: destroy,
    };
  }

  /* -------------------------------------------------------------------------
   * Public API
   * ---------------------------------------------------------------------- */
  global.QS = global.QS || {};

  /**
   * @namespace QS.ImagePicker
   */
  global.QS.ImagePicker = {
    /**
     * Initialise a new ImagePicker instance.
     * @type {Function}
     * @see init
     */
    init: init,
  };

})(typeof window !== 'undefined' ? window : this);
