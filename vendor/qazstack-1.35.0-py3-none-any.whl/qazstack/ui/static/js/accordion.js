/**
 * QazStack Accordion
 * Toggle collapsible sections.
 */
(function () {
    'use strict';

    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('.qs-accordion__toggle').forEach(function (toggle) {
            toggle.addEventListener('click', function () {
                var item = toggle.closest('.qs-accordion__item');
                if (!item) return;

                var content = item.querySelector('.qs-accordion__content');
                if (!content) return;

                var isOpen = item.classList.toggle('open');
                toggle.setAttribute('aria-expanded', String(isOpen));

                if (isOpen) {
                    content.style.maxHeight = content.scrollHeight + 'px';
                } else {
                    content.style.maxHeight = '0';
                }
            });
        });
    });
})();
