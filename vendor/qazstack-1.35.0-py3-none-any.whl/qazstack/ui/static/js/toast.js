/**
 * QazStack Toast Notification System
 * Multi-toast with auto-dismiss, type detection, SVG icons, dark mode.
 *
 * Usage:
 *   showToast('Saved successfully');           // auto-detect → success
 *   showToast('Something failed', 'error');    // explicit type
 *   showToast('FYI: updated', 'info');         // info toast
 *
 * Container <div id="qs-toast-container"></div> is auto-created if missing.
 */
(function () {
    'use strict';

    var CONTAINER_ID = 'qs-toast-container';
    var MAX_VISIBLE = 5;

    var ICONS = {
        success: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" class="qs-toast__icon"><polyline points="20 6 9 17 4 12"/></svg>',
        error:   '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" class="qs-toast__icon"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>',
        info:    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" class="qs-toast__icon"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/></svg>',
        warning: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" class="qs-toast__icon"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>'
    };

    var DURATIONS = { success: 3000, info: 5000, warning: 5000, error: 8000 };

    function detectType(msg) {
        var lower = msg.toLowerCase();
        if (lower.indexOf('ошибка') !== -1 || lower.indexOf('error') !== -1 || lower.indexOf('fail') !== -1) return 'error';
        if (lower.indexOf('warning') !== -1 || lower.indexOf('внимание') !== -1) return 'warning';
        if (lower.indexOf('инфо') !== -1 || lower.indexOf('info') !== -1) return 'info';
        return 'success';
    }

    function getContainer() {
        var c = document.getElementById(CONTAINER_ID);
        if (!c) {
            c = document.createElement('div');
            c.id = CONTAINER_ID;
            c.className = 'qs-toast-container';
            document.body.appendChild(c);
        }
        return c;
    }

    window.showToast = function (msg, type) {
        if (!msg) return;
        if (!type) type = detectType(msg);

        var container = getContainer();
        var el = document.createElement('div');
        el.className = 'qs-toast qs-toast--' + type;
        el.innerHTML =
            (ICONS[type] || ICONS.info) +
            '<span class=qs-toast__msg>' + msg + '</span>' +
            '<span class=qs-toast__close aria-label=Close>&times;</span>';

        container.appendChild(el);

        // Trigger enter animation
        requestAnimationFrame(function () {
            el.classList.add('qs-toast--visible');
        });

        // Auto-dismiss
        var duration = DURATIONS[type] || 3000;
        var timer = setTimeout(function () { dismiss(el); }, duration);

        // Click anywhere to dismiss
        el.addEventListener('click', function () {
            clearTimeout(timer);
            dismiss(el);
        });

        // Limit visible toasts
        var items = container.querySelectorAll('.qs-toast');
        if (items.length > MAX_VISIBLE) items[0].remove();
    };

    function dismiss(el) {
        el.classList.remove('qs-toast--visible');
        el.classList.add('qs-toast--hiding');
        setTimeout(function () {
            if (el.parentNode) el.remove();
        }, 350);
    }
})();
