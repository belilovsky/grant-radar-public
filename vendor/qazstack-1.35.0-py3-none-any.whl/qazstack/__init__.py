"""QazStack – modular Python toolkit for FastAPI web projects.

Submodules
----------
qazstack.translate
    Unified ru/kz/en translation via OpenAI or DeepSeek.
    Usage::

        from qazstack.translate import translate, translate_sync
"""

__version__ = "1.35.0"
