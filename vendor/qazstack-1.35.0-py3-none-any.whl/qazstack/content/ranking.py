"""Normalized search signals with consumer-owned weighting."""

from __future__ import annotations

from collections.abc import Callable, Hashable, Iterable, Mapping
from dataclasses import dataclass
from typing import TypeVar

from qazstack.contracts._validation import require_identifier, require_ratio

T = TypeVar("T")


@dataclass(frozen=True, slots=True)
class SearchSignal:
    name: str
    value: float
    evidence: str | None = None

    def __post_init__(self) -> None:
        require_identifier(self.name, "name")
        require_ratio(self.value, "value")


def weighted_search_score(signals: tuple[SearchSignal, ...], weights: Mapping[str, float]) -> float:
    """Return a normalized score while leaving domain weights to consumers."""
    if not signals:
        raise ValueError("signals must not be empty")
    if len({signal.name for signal in signals}) != len(signals):
        raise ValueError("signal names must be unique")
    active = [(signal.value, weights.get(signal.name, 0.0)) for signal in signals]
    if any(weight < 0 for _, weight in active):
        raise ValueError("weights must be non-negative")
    total_weight = sum(weight for _, weight in active)
    if total_weight <= 0:
        raise ValueError("at least one signal needs a positive weight")
    return round(sum(value * weight for value, weight in active) / total_weight, 6)


def diversify_ranked_items(
    items: Iterable[T],
    *,
    key: Callable[[T], Hashable],
    max_per_key: int = 1,
    limit: int | None = None,
) -> list[T]:
    """Keep ranked order while applying a bounded cap per consumer-owned key."""
    if max_per_key < 1:
        raise ValueError("max_per_key must be positive")
    if limit is not None and limit < 1:
        raise ValueError("limit must be positive when provided")

    selected: list[T] = []
    counts: dict[Hashable, int] = {}
    for item in items:
        item_key = key(item)
        if counts.get(item_key, 0) >= max_per_key:
            continue
        selected.append(item)
        counts[item_key] = counts.get(item_key, 0) + 1
        if limit is not None and len(selected) >= limit:
            break
    return selected
