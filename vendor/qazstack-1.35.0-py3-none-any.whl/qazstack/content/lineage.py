"""Deterministic, storage-neutral text lineage fingerprints."""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass
from typing import Iterable

TOKEN_RE = re.compile(r"[^\W_]+", re.UNICODE)


@dataclass(frozen=True, slots=True)
class TextFingerprint:
    """Compact signals used for near-duplicate candidate generation."""

    simhash: int
    signature: tuple[int, ...]


def normalized_tokens(text: str, *, limit: int = 20_000) -> list[str]:
    """Return bounded, case-folded Unicode tokens."""
    if limit < 1:
        raise ValueError("limit must be positive")
    return TOKEN_RE.findall((text or "").casefold())[:limit]


def _token_hash(token: str) -> int:
    digest = hashlib.blake2b(token.encode("utf-8", errors="replace"), digest_size=8).digest()
    return int.from_bytes(digest, "big")


def simhash64(text: str, *, token_limit: int = 20_000) -> int:
    """Return a stable 64-bit SimHash for candidate bucketing."""
    tokens = normalized_tokens(text, limit=token_limit)
    if not tokens:
        return 0
    weights = [0] * 64
    for token in tokens:
        value = _token_hash(token)
        for bit in range(64):
            weights[bit] += 1 if value & (1 << bit) else -1
    result = 0
    for bit, weight in enumerate(weights):
        if weight >= 0:
            result |= 1 << bit
    return result


def bottom_k_signature(text: str, *, k: int = 64, token_limit: int = 2_048) -> tuple[int, ...]:
    """Return a bottom-k token-set signature for second-pass similarity."""
    if k < 1:
        raise ValueError("k must be positive")
    values = {_token_hash(token) for token in normalized_tokens(text, limit=token_limit)}
    return tuple(sorted(values)[:k])


def fingerprint_text(
    text: str,
    *,
    simhash_token_limit: int = 20_000,
    signature_token_limit: int = 2_048,
    signature_size: int = 64,
) -> TextFingerprint:
    """Build both lineage signals in one consumer-facing call."""
    return TextFingerprint(
        simhash=simhash64(text, token_limit=simhash_token_limit),
        signature=bottom_k_signature(text, k=signature_size, token_limit=signature_token_limit),
    )


def signature_similarity(left: tuple[int, ...], right: tuple[int, ...]) -> float:
    """Estimate token-set similarity from two bottom-k signatures."""
    if not left or not right:
        return 0.0
    return len(set(left).intersection(right)) / float(min(len(left), len(right)))


def hamming_similarity(left: int, right: int) -> float:
    """Convert a 64-bit Hamming distance into a score from zero to one."""
    if left < 0 or right < 0 or left >= 1 << 64 or right >= 1 << 64:
        raise ValueError("simhash values must be unsigned 64-bit integers")
    return 1.0 - ((left ^ right).bit_count() / 64.0)


def simhash_buckets(value: int, bands: int = 4) -> Iterable[tuple[int, int]]:
    """Yield deterministic LSH buckets for a 64-bit fingerprint."""
    if value < 0 or value >= 1 << 64:
        raise ValueError("simhash value must be an unsigned 64-bit integer")
    if bands < 1 or 64 % bands:
        raise ValueError("bands must be a positive divisor of 64")
    width = 64 // bands
    mask = (1 << width) - 1
    for band in range(bands):
        yield band, (value >> (band * width)) & mask


__all__ = [
    "TextFingerprint",
    "bottom_k_signature",
    "fingerprint_text",
    "hamming_similarity",
    "normalized_tokens",
    "signature_similarity",
    "simhash64",
    "simhash_buckets",
]
