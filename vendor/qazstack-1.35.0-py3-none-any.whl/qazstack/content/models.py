"""Pydantic models for content: articles, entities, tags."""

from __future__ import annotations

import json
from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field, field_validator, model_validator


class Entity(BaseModel):
    """Named entity (person, org, event, location)."""

    id: int | None = None
    name: str
    short_name: str | None = None
    entity_type: str  # 'person', 'org', 'event', 'location'
    normalized: str | None = None
    mention_count: int = 0

    @field_validator("entity_type")
    @classmethod
    def validate_entity_type(cls, v: str) -> str:
        allowed = {"person", "org", "event", "location"}
        if v not in allowed:
            raise ValueError(f"entity_type must be one of {allowed}, got '{v}'")
        return v


class Article(BaseModel):
    """Universal article model – works with JSONL archives, SQLite, and PostgreSQL."""

    id: int | None = None
    url: str
    pub_date: datetime | None = None
    sub_category: str | None = None
    category_label: str | None = None
    title: str | None = None
    author: str | None = None
    excerpt: str | None = None
    body_text: str | None = None
    body_html: str | None = None
    main_image: str | None = None
    image_credit: str | None = None
    thumbnail: str | None = None
    tags: list[str] = Field(default_factory=list)
    inline_images: list[str] = Field(default_factory=list)
    entities: list[Entity] = Field(default_factory=list)
    imported_at: datetime | None = None

    # Extra fields from source (date_text, etc.) kept in extras
    extras: dict[str, Any] = Field(default_factory=dict)

    @field_validator("tags", "inline_images", mode="before")
    @classmethod
    def parse_json_list(cls, v: Any) -> list[str]:
        """Accept JSON strings, lists, or None."""
        if v is None:
            return []
        if isinstance(v, str):
            try:
                parsed = json.loads(v)
                return parsed if isinstance(parsed, list) else []
            except (json.JSONDecodeError, TypeError):
                return []
        if isinstance(v, list):
            return v
        return []

    @field_validator("pub_date", mode="before")
    @classmethod
    def parse_pub_date(cls, v: Any) -> datetime | None:
        if v is None or v == "":
            return None
        if isinstance(v, datetime):
            return v
        if isinstance(v, str):
            # Try ISO format first
            for fmt in (
                "%Y-%m-%dT%H:%M:%S",
                "%Y-%m-%dT%H:%M",
                "%Y-%m-%d %H:%M:%S",
                "%Y-%m-%d",
            ):
                try:
                    return datetime.strptime(v, fmt)
                except ValueError:
                    continue
            return None
        return None

    @model_validator(mode="before")
    @classmethod
    def capture_extras(cls, data: Any) -> Any:
        """Capture unknown fields into extras dict."""
        if not isinstance(data, dict):
            return data
        known = set(cls.model_fields.keys())
        extras = data.get("extras", {})
        for key in list(data.keys()):
            if key not in known:
                extras[key] = data.pop(key)
        data["extras"] = extras
        return data

    @property
    def slug(self) -> str:
        """Extract slug from URL (last path segment before query)."""
        from .utils import slug_from_url

        return slug_from_url(self.url)

    @property
    def category_from_url(self) -> str | None:
        """Extract category from URL path (e.g., /ru/news/bezopasnost/...)."""
        from .utils import category_from_url

        return category_from_url(self.url)

    def truncated_excerpt(self, max_length: int = 200) -> str:
        """Get excerpt, falling back to truncated body_text."""
        from .utils import truncate_text

        if self.excerpt:
            return truncate_text(self.excerpt, max_length)
        if self.body_text:
            return truncate_text(self.body_text, max_length)
        return ""


class ArticlePage(BaseModel):
    """Paginated list of articles."""

    articles: list[Article]
    total: int
    page: int = 1
    per_page: int = 20
    pages: int = 1

    @model_validator(mode="before")
    @classmethod
    def calc_pages(cls, data: Any) -> Any:
        if isinstance(data, dict):
            total = data.get("total", 0)
            per_page = data.get("per_page", 20)
            if "pages" not in data or data["pages"] is None:
                data["pages"] = max(1, (total + per_page - 1) // per_page)
        return data
