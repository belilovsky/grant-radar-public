"""Small validation primitives for public source and claim registries."""

from __future__ import annotations

from datetime import date
from typing import Any, Iterable
from urllib.parse import urlparse


class ProvenanceValidationError(ValueError):
    """Raised when public provenance metadata is incomplete or unsafe."""


def require_https_url(value: Any, *, context: str) -> str:
    url = str(value or "").strip()
    parsed = urlparse(url)
    if parsed.scheme != "https" or not parsed.netloc:
        raise ProvenanceValidationError(f"{context}: URL must be absolute HTTPS")
    return url


def require_iso_date(value: Any, *, context: str) -> str:
    normalized = str(value or "").strip()
    try:
        date.fromisoformat(normalized)
    except ValueError as exc:
        raise ProvenanceValidationError(f"{context}: date must use YYYY-MM-DD") from exc
    return normalized


def require_localized_labels(value: Any, *, languages: Iterable[str], context: str) -> dict[str, str]:
    if not isinstance(value, dict):
        raise ProvenanceValidationError(f"{context}: localized labels must be an object")
    labels: dict[str, str] = {}
    for language in languages:
        label = str(value.get(language) or "").strip()
        if not label:
            raise ProvenanceValidationError(f"{context}: label for '{language}' is required")
        labels[language] = label
    return labels


def require_known_ids(values: Any, *, allowed: Iterable[str], context: str) -> list[str]:
    if not isinstance(values, list) or not values:
        raise ProvenanceValidationError(f"{context}: a non-empty list is required")
    allowed_ids = set(allowed)
    normalized: list[str] = []
    for value in values:
        item = str(value or "").strip()
        if not item or item not in allowed_ids:
            raise ProvenanceValidationError(f"{context}: unknown reference '{item}'")
        if item not in normalized:
            normalized.append(item)
    return normalized
