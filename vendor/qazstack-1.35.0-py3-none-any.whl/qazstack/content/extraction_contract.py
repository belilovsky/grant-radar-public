"""Content extraction result contract with provenance and quality warnings."""

from __future__ import annotations

from dataclasses import dataclass

from qazstack.contracts._validation import require_http_url, require_identifier, require_text


@dataclass(frozen=True, slots=True)
class SourceMapSpan:
    output_start: int
    output_end: int
    source_ref: str

    def __post_init__(self) -> None:
        if self.output_start < 0 or self.output_end <= self.output_start:
            raise ValueError("source map bounds are invalid")
        require_text(self.source_ref, "source_ref")


@dataclass(frozen=True, slots=True)
class ExtractionWarning:
    code: str
    message: str

    def __post_init__(self) -> None:
        require_identifier(self.code, "code")
        require_text(self.message, "message")


@dataclass(frozen=True, slots=True)
class ContentExtractionResult:
    source_url: str
    media_type: str
    text: str
    title: str | None
    source_map: tuple[SourceMapSpan, ...]
    warnings: tuple[ExtractionWarning, ...] = ()

    def __post_init__(self) -> None:
        require_http_url(self.source_url, "source_url")
        require_text(self.media_type, "media_type")
        require_text(self.text, "text")
        previous_end = 0
        for span in sorted(self.source_map, key=lambda item: item.output_start):
            if span.output_start < previous_end or span.output_end > len(self.text):
                raise ValueError("source map spans overlap or exceed extracted text")
            previous_end = span.output_end

    @property
    def text_length(self) -> int:
        return len(self.text)
