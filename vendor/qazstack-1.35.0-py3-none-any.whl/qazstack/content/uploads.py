"""Project-neutral upload policy, signature validation and scan boundary."""

from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass

DEFAULT_IMAGE_MIME_TYPES = {
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".gif": "image/gif",
    ".webp": "image/webp",
    ".svg": "image/svg+xml",
}


@dataclass(frozen=True, slots=True)
class UploadPolicy:
    allowed_mime_types: Mapping[str, str] | None = None
    max_size: int = 10 * 1024 * 1024
    require_antivirus_scan: bool = False

    @property
    def mime_types(self) -> Mapping[str, str]:
        return self.allowed_mime_types or DEFAULT_IMAGE_MIME_TYPES

    @property
    def allowed_extensions(self) -> frozenset[str]:
        return frozenset(self.mime_types)


@dataclass(frozen=True, slots=True)
class UploadValidation:
    ok: bool
    reason: str
    extension: str
    mime_type: str
    scan_status: str = "not_required"


DEFAULT_UPLOAD_POLICY = UploadPolicy()

_CONFLICTING_SIGNATURES = (
    b"%PDF",
    b"PK\x03\x04",
    b"MZ",
    b"<html",
    b"<!doctype html",
)


def normalize_extension(filename: str) -> str:
    dot = filename.rfind(".")
    return filename[dot:].lower() if dot >= 0 else ""


def has_safe_filename(filename: str) -> bool:
    return bool(filename) and "\x00" not in filename and "/" not in filename and "\\" not in filename


def has_conflicting_signature(content: bytes) -> bool:
    """Reject obvious polyglots with a second format marker near the start."""
    prefix = content[:128].lower()
    return any(prefix.find(signature.lower(), 1) >= 0 for signature in _CONFLICTING_SIGNATURES)


def detect_image_mime(content: bytes) -> str:
    if len(content) >= 12 and content[:4] == b"RIFF" and content[8:12] == b"WEBP":
        return "image/webp"
    if content.startswith(b"\xff\xd8\xff"):
        return "image/jpeg"
    if content.startswith(b"\x89PNG"):
        return "image/png"
    if content.startswith((b"GIF87a", b"GIF89a")):
        return "image/gif"
    return ""


def has_allowed_magic_bytes(
    content: bytes,
    extension: str,
    *,
    policy: UploadPolicy = DEFAULT_UPLOAD_POLICY,
    detector: Callable[[bytes], str] = detect_image_mime,
) -> bool:
    extension = extension.lower()
    expected = policy.mime_types.get(extension, "")
    if expected == "image/svg+xml":
        return content[:200].lstrip().lower().startswith((b"<svg", b"<?xml"))
    return bool(expected) and detector(content) == expected


def validate_upload(
    filename: str,
    content: bytes,
    *,
    policy: UploadPolicy = DEFAULT_UPLOAD_POLICY,
    detector: Callable[[bytes], str] = detect_image_mime,
    antivirus_scanner: Callable[[bytes], bool] | None = None,
) -> UploadValidation:
    if not has_safe_filename(filename):
        return UploadValidation(False, "unsafe_filename", "", "application/octet-stream")
    extension = normalize_extension(filename)
    mime_type = policy.mime_types.get(extension, "application/octet-stream")
    if extension not in policy.allowed_extensions:
        return UploadValidation(False, "unsupported_extension", extension, mime_type)
    if len(content) > policy.max_size:
        return UploadValidation(False, "file_too_large", extension, mime_type)
    if not has_allowed_magic_bytes(content, extension, policy=policy, detector=detector):
        return UploadValidation(False, "signature_mismatch", extension, mime_type)
    if has_conflicting_signature(content):
        return UploadValidation(False, "conflicting_signature", extension, mime_type)
    if policy.require_antivirus_scan and antivirus_scanner is None:
        return UploadValidation(False, "antivirus_scan_required", extension, mime_type, "missing")
    if antivirus_scanner is not None and not antivirus_scanner(content):
        return UploadValidation(False, "antivirus_rejected", extension, mime_type, "rejected")
    scan_status = "passed" if antivirus_scanner is not None else "not_required"
    return UploadValidation(True, "", extension, mime_type, scan_status)
