"""Pure scoring helpers for article-body extraction adapters."""

from __future__ import annotations

import html
import re
from dataclasses import dataclass
from typing import Iterable

_TAG_RE = re.compile(r"<[^>]+>")
_SCRIPT_RE = re.compile(r"<(script|style)\b[^>]*>.*?</\1>", re.IGNORECASE | re.DOTALL)
_SPACE_RE = re.compile(r"\s+")
_TEXT_KEY_RE = re.compile(r"[\W_]+", re.UNICODE)
_LETTER_RE = re.compile(r"[A-Za-zА-Яа-яЁёӘәІіҢңҒғҮүҰұҚқӨөҺһ]")


@dataclass(frozen=True, slots=True)
class ArticleExtractionPolicy:
    min_block_chars: int = 35
    min_block_letters: int = 20
    min_candidate_chars: int = 220
    min_candidate_score: int = 360
    block_bonus: int = 80
    replacement_min_chars: int = 260
    replacement_min_growth_chars: int = 160
    replacement_growth_ratio: float = 1.35
    boilerplate_patterns: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        integer_limits = (
            self.min_block_chars,
            self.min_block_letters,
            self.min_candidate_chars,
            self.min_candidate_score,
            self.block_bonus,
            self.replacement_min_chars,
            self.replacement_min_growth_chars,
        )
        if any(value < 0 for value in integer_limits):
            raise ValueError("article extraction thresholds must be non-negative")
        if self.replacement_growth_ratio < 1:
            raise ValueError("replacement_growth_ratio must be at least 1")
        for pattern in self.boilerplate_patterns:
            re.compile(pattern)


@dataclass(frozen=True, slots=True)
class ArticleTextBlock:
    tag: str
    text: str


@dataclass(frozen=True, slots=True)
class ArticleTextCandidate:
    body_html: str
    body_text: str
    score: int
    block_count: int


def html_to_plain_text(value: str | None) -> str:
    if not value:
        return ""
    without_scripts = _SCRIPT_RE.sub(" ", str(value))
    return _SPACE_RE.sub(" ", html.unescape(_TAG_RE.sub(" ", without_scripts))).strip()


def article_text_key(value: str) -> str:
    return _TEXT_KEY_RE.sub("", value.casefold())


def is_useful_article_block(text: str, *, policy: ArticleExtractionPolicy | None = None) -> bool:
    cfg = policy or ArticleExtractionPolicy()
    normalized = _SPACE_RE.sub(" ", text).strip()
    if len(normalized) < cfg.min_block_chars:
        return False
    if len(_LETTER_RE.findall(normalized)) < cfg.min_block_letters:
        return False
    return not any(re.search(pattern, normalized, re.IGNORECASE) for pattern in cfg.boilerplate_patterns)


def build_article_candidate(
    blocks: Iterable[ArticleTextBlock],
    *,
    policy: ArticleExtractionPolicy | None = None,
) -> ArticleTextCandidate | None:
    cfg = policy or ArticleExtractionPolicy()
    unique: list[ArticleTextBlock] = []
    seen: set[str] = set()
    for block in blocks:
        text = _SPACE_RE.sub(" ", block.text).strip()
        if not is_useful_article_block(text, policy=cfg):
            continue
        key = article_text_key(text)
        if not key or key in seen:
            continue
        seen.add(key)
        unique.append(ArticleTextBlock(block.tag.casefold(), text))
    if not unique:
        return None
    body_text = "\n\n".join(block.text for block in unique)
    body_html = "\n".join(_render_block(block) for block in unique)
    score = len(body_text) + len(unique) * cfg.block_bonus
    if len(body_text) < cfg.min_candidate_chars or score < cfg.min_candidate_score:
        return None
    return ArticleTextCandidate(body_html=body_html, body_text=body_text, score=score, block_count=len(unique))


def should_replace_article_text(
    new_text: str | None,
    current_text: str | None,
    *,
    policy: ArticleExtractionPolicy | None = None,
) -> bool:
    cfg = policy or ArticleExtractionPolicy()
    new_length = len(html_to_plain_text(new_text))
    current_length = len(html_to_plain_text(current_text))
    if new_length < cfg.replacement_min_chars:
        return False
    if current_length < 120:
        return True
    return new_length >= current_length + cfg.replacement_min_growth_chars and new_length >= int(
        current_length * cfg.replacement_growth_ratio
    )


def _render_block(block: ArticleTextBlock) -> str:
    safe = html.escape(block.text)
    if block.tag in {"h2", "h3", "h4"}:
        return f"<h2>{safe}</h2>"
    if block.tag == "blockquote":
        return f"<blockquote><p>{safe}</p></blockquote>"
    return f"<p>{safe}</p>"
