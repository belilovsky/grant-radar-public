"""Content utilities: date parsing, slug extraction, text processing."""

from __future__ import annotations

import html
import re
from datetime import datetime
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

# ── Russian month names ──────────────────────────────────────────

_RU_MONTHS: dict[str, str] = {
    "января": "01",
    "февраля": "02",
    "марта": "03",
    "апреля": "04",
    "мая": "05",
    "июня": "06",
    "июля": "07",
    "августа": "08",
    "сентября": "09",
    "октября": "10",
    "ноября": "11",
    "декабря": "12",
}

_RU_DATE_RE = re.compile(
    r"(\d{1,2})\s+(\S+)\s+(\d{4})(?:,\s*(\d{1,2}):(\d{2}))?",
)

_HTML_TAG_RE = re.compile(r"<[^>]+>")
_MULTI_SPACE_RE = re.compile(r"\s+")
_TRACKING_QUERY_KEYS = frozenset({"fbclid", "gclid", "yclid", "mc_cid", "mc_eid"})


def parse_ru_date(text: str | None) -> datetime | None:
    """Parse Russian date string like '13 апреля 2016, 11:38' into datetime.

    Returns None if text is empty or unparseable.
    """
    if not text:
        return None
    m = _RU_DATE_RE.search(text)
    if not m:
        return None
    day = int(m.group(1))
    month_str = m.group(2).lower()
    month = _RU_MONTHS.get(month_str)
    if not month:
        return None
    year = int(m.group(3))
    hour = int(m.group(4) or 0)
    minute = int(m.group(5) or 0)
    try:
        return datetime(year, int(month), day, hour, minute)
    except ValueError:
        return None


# ── URL utilities ────────────────────────────────────────────────


def canonicalize_url(url: str | None) -> str:
    """Normalize a public HTTP URL for stable ingestion identity.

    The function preserves meaningful query parameters and their order while
    removing fragments, common campaign parameters, a trailing host dot, and
    default ports. It deliberately does not collapse ``www`` hosts or rewrite
    paths because those transformations can change publisher routing.
    """
    value = (url or "").strip()
    if not value:
        return ""

    try:
        parsed = urlsplit(value)
        port = parsed.port
    except ValueError:
        return value
    if parsed.scheme.lower() not in {"http", "https"} or not parsed.hostname:
        return value

    hostname = parsed.hostname.lower().rstrip(".")
    if not hostname:
        return value
    netloc = hostname if port in {None, 80 if parsed.scheme.lower() == "http" else 443} else f"{hostname}:{port}"
    query = [
        (key, item)
        for key, item in parse_qsl(parsed.query, keep_blank_values=True)
        if not key.lower().startswith("utm_") and key.lower() not in _TRACKING_QUERY_KEYS
    ]
    return urlunsplit((parsed.scheme.lower(), netloc, parsed.path or "/", urlencode(query, doseq=True), ""))


def slug_from_url(url: str) -> str:
    """Extract the last meaningful path segment as slug.

    Example:
        'https://total.kz/ru/news/bezopasnost/article_slug_date_2026_03_17'
        → 'article_slug_date_2026_03_17'
    """
    path = urlsplit(url).path.rstrip("/")
    return path.rsplit("/", 1)[-1] if path else ""


def category_from_url(url: str) -> str | None:
    """Extract category from a total.kz-style URL path.

    Expects: /ru/news/<category>/slug or /<lang>/news/<category>/slug
    Returns the category segment, or None if pattern doesn't match.
    """
    path = urlsplit(url).path.strip("/")
    parts = path.split("/")
    # Pattern: lang/news/category/slug
    if len(parts) >= 3 and parts[1] == "news":
        return parts[2]
    # Pattern: news/category/slug
    if len(parts) >= 2 and parts[0] == "news":
        return parts[1]
    return None


# ── Text utilities ───────────────────────────────────────────────


def strip_html(text: str) -> str:
    """Remove HTML tags and decode entities."""
    clean = _HTML_TAG_RE.sub(" ", text)
    clean = html.unescape(clean)
    return _MULTI_SPACE_RE.sub(" ", clean).strip()


def truncate_text(text: str, max_length: int = 200, suffix: str = "…") -> str:
    """Truncate text to max_length characters, breaking at word boundary."""
    if not text or len(text) <= max_length:
        return text or ""
    truncated = text[:max_length].rsplit(" ", 1)[0]
    return truncated + suffix


def reading_time_minutes(text: str, wpm: int = 200) -> int:
    """Estimate reading time in minutes (minimum 1)."""
    if not text:
        return 1
    words = len(text.split())
    return max(1, round(words / wpm))
