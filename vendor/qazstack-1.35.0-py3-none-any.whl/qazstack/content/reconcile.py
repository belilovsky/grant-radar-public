"""Small idempotency primitives for content-package imports.

These helpers deliberately do not know about a database or transport.  An
importer owns persistence; this module only resolves the stable record key used
to decide whether a package entry is new or a verified date correction.
"""

from __future__ import annotations

from collections.abc import MutableSet, Set
from typing import Any, Mapping


def record_key(record: Mapping[str, Any], *, date_field: str = "date", name_field: str = "name") -> str:
    """Build the canonical key for a dated named record.

    Raises ``ValueError`` when either identity part is missing.  Silent keys
    such as ``"None|None"`` make imports non-idempotent and are never useful.
    """
    date_value = str(record.get(date_field) or "").strip()
    name_value = str(record.get(name_field) or "").strip()
    if not date_value or not name_value:
        raise ValueError(f"record requires non-empty {date_field!r} and {name_field!r}")
    return f"{date_value}|{name_value}"


def find_existing_record_key(
    record: Mapping[str, Any],
    existing_keys: Set[str],
    *,
    previous_date_field: str = "previous_date",
    date_field: str = "date",
    name_field: str = "name",
) -> str | None:
    """Resolve the current key first, then a verified one-time previous date."""
    current_key = record_key(record, date_field=date_field, name_field=name_field)
    if current_key in existing_keys:
        return current_key
    previous_date = str(record.get(previous_date_field) or "").strip()
    if not previous_date:
        return None
    previous_key = f"{previous_date}|{str(record.get(name_field) or '').strip()}"
    return previous_key if previous_key in existing_keys else None


def replace_existing_record_key(
    existing_keys: MutableSet[str],
    previous_key: str,
    record: Mapping[str, Any],
    *,
    date_field: str = "date",
    name_field: str = "name",
) -> str:
    """Atomically replace a legacy key after a successful record date update."""
    current_key = record_key(record, date_field=date_field, name_field=name_field)
    existing_keys.discard(previous_key)
    existing_keys.add(current_key)
    return current_key
