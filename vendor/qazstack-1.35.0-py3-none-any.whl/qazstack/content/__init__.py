"""qazstack.content – content loading, article models, text utilities, headless API.

Usage:
    from qazstack.content import Article, ArticlePage, Entity
    from qazstack.content import iter_jsonl, load_jsonl, ArchiveReader
    from qazstack.content import parse_ru_date, slug_from_url, strip_html, truncate_text

    # Full-text extraction:
    from qazstack.content import extract_fulltext, EnrichResult, should_skip_domain

    # Headless API (sub-module):
    from qazstack.content.api import content_router, SQLiteContentProvider
"""

from .article_extraction import (
    ArticleExtractionPolicy,
    ArticleTextBlock,
    ArticleTextCandidate,
    article_text_key,
    build_article_candidate,
    html_to_plain_text,
    is_useful_article_block,
    should_replace_article_text,
)
from .chunking import chunk_text, normalize_text
from .extraction_contract import ContentExtractionResult, ExtractionWarning, SourceMapSpan
from .lineage import (
    TextFingerprint,
    bottom_k_signature,
    fingerprint_text,
    hamming_similarity,
    normalized_tokens,
    signature_similarity,
    simhash64,
    simhash_buckets,
)
from .loaders import ArchiveReader, iter_jsonl, load_jsonl
from .models import Article, ArticlePage, Entity
from .provenance import (
    ProvenanceValidationError,
    require_https_url,
    require_iso_date,
    require_known_ids,
    require_localized_labels,
)
from .public_safety import RUSSIAN_REDACTION_LABELS, PublicRedactionLabels, escape_public_html, sanitize_public_text
from .ranking import SearchSignal, diversify_ranked_items, weighted_search_score
from .reconcile import find_existing_record_key, record_key, replace_existing_record_key
from .uploads import (
    DEFAULT_IMAGE_MIME_TYPES,
    DEFAULT_UPLOAD_POLICY,
    UploadPolicy,
    UploadValidation,
    detect_image_mime,
    has_allowed_magic_bytes,
    has_conflicting_signature,
    has_safe_filename,
    normalize_extension,
    validate_upload,
)
from .utils import (
    canonicalize_url,
    category_from_url,
    parse_ru_date,
    reading_time_minutes,
    slug_from_url,
    strip_html,
    truncate_text,
)

# Enricher – optional dependency (newspaper4k)
try:
    from .enricher import (
        SKIP_DOMAINS,
        EnrichResult,
        extract_fulltext,
        should_skip_domain,
    )
except ImportError:
    extract_fulltext = None  # type: ignore[assignment]
    should_skip_domain = None  # type: ignore[assignment]
    EnrichResult = None  # type: ignore[assignment,misc]
    SKIP_DOMAINS = frozenset()  # type: ignore[assignment]

__all__ = [
    # Models
    "Article",
    "ArticlePage",
    "Entity",
    # Loaders
    "ArchiveReader",
    "iter_jsonl",
    "load_jsonl",
    "TextFingerprint",
    "bottom_k_signature",
    "fingerprint_text",
    "hamming_similarity",
    "normalized_tokens",
    "signature_similarity",
    "simhash64",
    "simhash_buckets",
    # Utilities
    "canonicalize_url",
    "category_from_url",
    "parse_ru_date",
    "reading_time_minutes",
    "slug_from_url",
    "strip_html",
    "truncate_text",
    "chunk_text",
    "normalize_text",
    "record_key",
    "find_existing_record_key",
    "replace_existing_record_key",
    "ProvenanceValidationError",
    "require_https_url",
    "require_iso_date",
    "require_known_ids",
    "require_localized_labels",
    "PublicRedactionLabels",
    "RUSSIAN_REDACTION_LABELS",
    "escape_public_html",
    "sanitize_public_text",
    "DEFAULT_IMAGE_MIME_TYPES",
    "DEFAULT_UPLOAD_POLICY",
    "UploadPolicy",
    "UploadValidation",
    "detect_image_mime",
    "has_allowed_magic_bytes",
    "normalize_extension",
    "validate_upload",
    "has_safe_filename",
    "has_conflicting_signature",
    "ContentExtractionResult",
    "ExtractionWarning",
    "SourceMapSpan",
    "SearchSignal",
    "diversify_ranked_items",
    "weighted_search_score",
    "ArticleExtractionPolicy",
    "ArticleTextBlock",
    "ArticleTextCandidate",
    "article_text_key",
    "build_article_candidate",
    "html_to_plain_text",
    "is_useful_article_block",
    "should_replace_article_text",
    # Enricher
    "extract_fulltext",
    "should_skip_domain",
    "EnrichResult",
    "SKIP_DOMAINS",
]
