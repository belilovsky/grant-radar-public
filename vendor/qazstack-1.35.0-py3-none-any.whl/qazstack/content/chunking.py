"""Paragraph-aware text chunking for retrieval and enrichment pipelines."""

from __future__ import annotations

import re

_WHITESPACE_RE = re.compile(r"\s+", re.UNICODE)
_PARAGRAPH_RE = re.compile(r"\n\s*\n+", re.UNICODE)


def normalize_text(value: str) -> str:
    return _WHITESPACE_RE.sub(" ", value or "").strip()


def _paragraph_units(body: str, size: int) -> list[str]:
    parts = [normalize_text(part) for part in _PARAGRAPH_RE.split(body or "")]
    parts = [part for part in parts if part]
    if not parts:
        normalized = normalize_text(body)
        return [normalized] if normalized else []

    units: list[str] = []
    for part in parts:
        words = part.split()
        if len(words) <= size:
            units.append(part)
        else:
            units.extend(" ".join(words[start : start + size]) for start in range(0, len(words), size))
    return units


def chunk_text(
    body: str,
    *,
    size: int = 220,
    overlap: int = 40,
    min_words: int = 40,
    max_chunks: int = 64,
) -> list[str]:
    """Split text into bounded, overlapping, paragraph-aware word windows."""
    if size < 1:
        raise ValueError("size must be positive")
    if min_words < 1:
        raise ValueError("min_words must be positive")
    if max_chunks < 1:
        return []

    units = _paragraph_units(body, size)
    if not units:
        return []
    if len(units) == 1 and len(units[0].split()) < min_words:
        return units

    overlap = max(0, min(overlap, size // 2))
    carry: list[str] = []
    current: list[str] = []
    chunks: list[str] = []

    def flush() -> None:
        nonlocal carry, current
        if len(current) < min_words and chunks:
            return
        if current:
            value = " ".join(current).strip()
            if value and (not chunks or value != chunks[-1]):
                chunks.append(value)
                carry = current[-overlap:] if overlap else []
        current = list(carry)

    for unit in units:
        words = unit.split()
        if current and len(current) + len(words) > size:
            flush()
        current.extend(words)
        if len(current) >= size:
            flush()
        if len(chunks) >= max_chunks:
            break

    if len(chunks) < max_chunks and len(current) >= min_words:
        flush()
    return chunks[:max_chunks]
