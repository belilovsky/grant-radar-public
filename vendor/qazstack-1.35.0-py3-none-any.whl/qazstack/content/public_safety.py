"""Public-facing text helpers for redaction-safe HTML and API surfaces."""

from __future__ import annotations

import html
import re
from dataclasses import dataclass
from typing import Final


@dataclass(frozen=True, slots=True)
class PublicRedactionLabels:
    """Localized replacements used by :func:`sanitize_public_text`."""

    email: str = "[email hidden]"
    phone: str = "[phone hidden]"
    iin: str = "IIN [hidden]"
    bin: str = "BIN [hidden]"
    identifier: str = "[identifier hidden]"
    address: str = "[address hidden]"
    person: str = "[name hidden]"
    organization: str = "[organization hidden]"
    location: str = "[location hidden]"
    date: str = "[date hidden]"
    author: str = "[author hidden]"


RUSSIAN_REDACTION_LABELS: Final = PublicRedactionLabels(
    email="[email скрыт]",
    phone="[телефон скрыт]",
    iin="ИИН [скрыт]",
    bin="BIN [скрыт]",
    identifier="[идентификатор скрыт]",
    address="[адрес скрыт]",
    person="[имя скрыто]",
    organization="[организация скрыта]",
    location="[место скрыто]",
    date="[дата скрыта]",
    author="[автор скрыт]",
)

_RAW_PII_PATTERNS: Final = (
    (re.compile(r"(?i)\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b"), "email"),
    (re.compile(r"(?<!\d)(?:\+?7|8)[\s(.-]*\d{3}[\s).-]*\d{3}[\s.-]*\d{2}[\s.-]*\d{2}(?!\d)"), "phone"),
    (re.compile(r"(?i)\b(?:ИИН|IIN)\s*[:№#-]?\s*\d{12}\b"), "iin"),
    (re.compile(r"(?i)\b(?:БИН|BIN)\s*[:№#-]?\s*\d{12}\b"), "bin"),
)
_PLACEHOLDER_PATTERNS: Final = (
    (re.compile(r"\[(?:RESIDUAL_)?PHONE(?:_\d+)?\]", re.IGNORECASE), "phone"),
    (re.compile(r"\[(?:RESIDUAL_)?EMAIL(?:_\d+)?\]", re.IGNORECASE), "email"),
    (re.compile(r"\[(?:RESIDUAL_)?(?:IIN|BIN|ID|ID_NUM)(?:_\d+)?\]", re.IGNORECASE), "identifier"),
    (re.compile(r"\[(?:RESIDUAL_)?ADDRESS(?:_\d+)?\]", re.IGNORECASE), "address"),
    (re.compile(r"\[PERSON(?:_\d+)?\]", re.IGNORECASE), "person"),
    (re.compile(r"\[ORG(?:_\d+)?\]", re.IGNORECASE), "organization"),
    (re.compile(r"\[LOCATION(?:_\d+)?\]", re.IGNORECASE), "location"),
    (re.compile(r"\[DATE(?:_\d+)?\]", re.IGNORECASE), "date"),
    (re.compile(r"\[USERNAME(?:_\d+)?\]", re.IGNORECASE), "author"),
)


def sanitize_public_text(value: str | None, *, labels: PublicRedactionLabels = PublicRedactionLabels()) -> str:
    """Replace Kazakhstan PII and QazShield placeholders with safe public copy."""
    text = "" if value is None else str(value)
    for pattern, label_name in _RAW_PII_PATTERNS + _PLACEHOLDER_PATTERNS:
        text = pattern.sub(getattr(labels, label_name), text)
    return text


def escape_public_html(value: object | None) -> str:
    """Escape untrusted text before inserting it into server-rendered HTML."""
    return html.escape("" if value is None else str(value), quote=True)
