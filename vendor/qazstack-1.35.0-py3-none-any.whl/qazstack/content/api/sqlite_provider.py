"""SQLiteContentProvider – ContentProvider backed by a SQLite database.

Designed to work with the total-kz schema (articles, entities, article_entities,
article_tags tables). Usable as a reference for building other providers.
"""

from __future__ import annotations

import json
import sqlite3
from pathlib import Path

from ..utils import reading_time_minutes, slug_from_url
from .schemas import (
    ArticleDetail,
    ArticleListResponse,
    ArticleSummary,
    CategoryCount,
    EntityBrief,
    EntityDetail,
    EntityListResponse,
    TagCount,
)


class SQLiteContentProvider:
    """Content provider backed by a SQLite database.

    Args:
        db_path: Path to the SQLite database file.

    The database must contain:
        - ``articles`` table (id, url, pub_date, sub_category, category_label,
          title, author, excerpt, body_text, body_html, main_image, image_credit,
          thumbnail, tags, inline_images, imported_at)
        - ``entities`` table (id, name, short_name, entity_type, normalized)
        - ``article_entities`` join table (article_id, entity_id, mention_count)
        - ``article_tags`` join table (article_id, tag) – optional

    Example::

        provider = SQLiteContentProvider("/data/total.db")
        articles = provider.list_articles(page=1, per_page=10)
    """

    def __init__(self, db_path: str | Path) -> None:
        self.db_path = str(db_path)

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        return conn

    # ── Helpers ───────────────────────────────────

    def _row_to_summary(self, row: sqlite3.Row) -> ArticleSummary:
        d = dict(row)
        url = d.get("url", "")
        body_text = d.get("body_text")
        return ArticleSummary(
            id=d["id"],
            url=url,
            slug=slug_from_url(url),
            pub_date=d.get("pub_date"),
            category=d.get("sub_category"),
            category_label=d.get("category_label"),
            title=d.get("title"),
            author=d.get("author"),
            excerpt=d.get("excerpt"),
            thumbnail=d.get("thumbnail"),
            main_image=d.get("main_image"),
            reading_time=reading_time_minutes(body_text) if body_text else None,
        )

    def _row_to_detail(self, row: sqlite3.Row, conn: sqlite3.Connection) -> ArticleDetail:
        d = dict(row)
        url = d.get("url", "")
        tags_raw = d.get("tags") or "[]"
        images_raw = d.get("inline_images") or "[]"
        try:
            tags = json.loads(tags_raw) if isinstance(tags_raw, str) else tags_raw
        except (json.JSONDecodeError, TypeError):
            tags = []
        try:
            inline_images = json.loads(images_raw) if isinstance(images_raw, str) else images_raw
        except (json.JSONDecodeError, TypeError):
            inline_images = []

        # Load entities for this article
        entities_rows = conn.execute(
            """
            SELECT e.id, e.name, e.short_name, e.entity_type, ae.mention_count
            FROM entities e
            JOIN article_entities ae ON ae.entity_id = e.id
            WHERE ae.article_id = ?
            ORDER BY ae.mention_count DESC
            """,
            (d["id"],),
        ).fetchall()
        entities = [
            EntityBrief(
                id=e["id"],
                name=e["name"],
                short_name=e["short_name"],
                entity_type=e["entity_type"],
                mention_count=e["mention_count"] or 0,
            )
            for e in entities_rows
        ]

        body_text = d.get("body_text")
        return ArticleDetail(
            id=d["id"],
            url=url,
            slug=slug_from_url(url),
            pub_date=d.get("pub_date"),
            category=d.get("sub_category"),
            category_label=d.get("category_label"),
            title=d.get("title"),
            author=d.get("author"),
            excerpt=d.get("excerpt"),
            body_text=body_text,
            body_html=d.get("body_html"),
            main_image=d.get("main_image"),
            image_credit=d.get("image_credit"),
            thumbnail=d.get("thumbnail"),
            tags=tags if isinstance(tags, list) else [],
            inline_images=inline_images if isinstance(inline_images, list) else [],
            entities=entities,
            reading_time=reading_time_minutes(body_text) if body_text else None,
            imported_at=d.get("imported_at"),
        )

    # ── Protocol implementation ──────────────────

    def list_articles(
        self,
        *,
        page: int = 1,
        per_page: int = 20,
        category: str = "",
        author: str = "",
        tag: str = "",
        entity_id: int = 0,
        date_from: str = "",
        date_to: str = "",
    ) -> ArticleListResponse:
        conn = self._connect()
        try:
            conditions: list[str] = []
            params: list = []
            joins: list[str] = []

            if category:
                conditions.append("a.sub_category = ?")
                params.append(category)
            if author:
                conditions.append("a.author = ?")
                params.append(author)
            if date_from:
                conditions.append("a.pub_date >= ?")
                params.append(date_from)
            if date_to:
                conditions.append("a.pub_date <= ?")
                # Support both ISO (T) and space-separated timestamps
                params.append(date_to + "T23:59:59" if len(date_to) == 10 else date_to)
            if tag:
                joins.append("JOIN article_tags at2 ON at2.article_id = a.id")
                conditions.append("at2.tag = ?")
                params.append(tag)
            if entity_id:
                joins.append("JOIN article_entities ae ON ae.article_id = a.id")
                conditions.append("ae.entity_id = ?")
                params.append(entity_id)

            join_sql = " ".join(joins)
            where = "WHERE " + " AND ".join(conditions) if conditions else ""

            total = conn.execute(
                f"SELECT COUNT(DISTINCT a.id) FROM articles a {join_sql} {where}",
                params,
            ).fetchone()[0]

            offset = (page - 1) * per_page
            rows = conn.execute(
                f"""
                SELECT DISTINCT a.id, a.url, a.pub_date, a.sub_category, a.category_label,
                       a.title, a.author, a.excerpt, a.thumbnail, a.main_image
                FROM articles a {join_sql} {where}
                ORDER BY a.pub_date DESC
                LIMIT ? OFFSET ?
                """,
                params + [per_page, offset],
            ).fetchall()

            articles = [self._row_to_summary(r) for r in rows]
            pages = max(1, (total + per_page - 1) // per_page)

            return ArticleListResponse(
                articles=articles,
                total=total,
                page=page,
                per_page=per_page,
                pages=pages,
            )
        finally:
            conn.close()

    def search_articles(
        self,
        *,
        query: str,
        page: int = 1,
        per_page: int = 20,
    ) -> ArticleListResponse:
        conn = self._connect()
        try:
            pattern = f"%{query}%"
            total = conn.execute(
                "SELECT COUNT(*) FROM articles WHERE title LIKE ? OR body_text LIKE ?",
                (pattern, pattern),
            ).fetchone()[0]

            offset = (page - 1) * per_page
            rows = conn.execute(
                """
                SELECT id, url, pub_date, sub_category, category_label,
                       title, author, excerpt, thumbnail, main_image
                FROM articles
                WHERE title LIKE ? OR body_text LIKE ?
                ORDER BY pub_date DESC
                LIMIT ? OFFSET ?
                """,
                (pattern, pattern, per_page, offset),
            ).fetchall()

            articles = [self._row_to_summary(r) for r in rows]
            pages = max(1, (total + per_page - 1) // per_page)

            return ArticleListResponse(
                articles=articles,
                total=total,
                page=page,
                per_page=per_page,
                pages=pages,
            )
        finally:
            conn.close()

    def get_article(self, article_id: int) -> ArticleDetail | None:
        conn = self._connect()
        try:
            row = conn.execute("SELECT * FROM articles WHERE id = ?", (article_id,)).fetchone()
            if row is None:
                return None
            return self._row_to_detail(row, conn)
        finally:
            conn.close()

    def get_article_by_slug(self, category: str, slug: str) -> ArticleDetail | None:
        conn = self._connect()
        try:
            url_pattern = f"%/ru/news/{category}/{slug}"
            row = conn.execute(
                "SELECT * FROM articles WHERE url LIKE ? LIMIT 1",
                (url_pattern,),
            ).fetchone()
            if row is None:
                return None
            return self._row_to_detail(row, conn)
        finally:
            conn.close()

    def list_categories(self) -> list[CategoryCount]:
        conn = self._connect()
        try:
            rows = conn.execute(
                """
                SELECT sub_category, COUNT(*) as cnt
                FROM articles
                GROUP BY sub_category
                ORDER BY cnt DESC
                """
            ).fetchall()
            return [
                CategoryCount(
                    slug=r["sub_category"] or "",
                    label=r["sub_category"],
                    count=r["cnt"],
                )
                for r in rows
            ]
        finally:
            conn.close()

    def list_tags(self, *, limit: int = 100) -> list[TagCount]:
        conn = self._connect()
        try:
            rows = conn.execute(
                """
                SELECT tag, COUNT(*) as cnt
                FROM article_tags
                GROUP BY tag
                ORDER BY cnt DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
            return [TagCount(tag=r["tag"], count=r["cnt"]) for r in rows]
        finally:
            conn.close()

    def list_entities(
        self,
        *,
        entity_type: str = "",
        limit: int = 50,
    ) -> EntityListResponse:
        conn = self._connect()
        try:
            where = "WHERE e.entity_type = ?" if entity_type else ""
            params: list = [entity_type] if entity_type else []
            rows = conn.execute(
                f"""
                SELECT e.id, e.name, e.short_name, e.entity_type, e.normalized,
                       COUNT(ae.article_id) as article_count
                FROM entities e
                JOIN article_entities ae ON ae.entity_id = e.id
                {where}
                GROUP BY e.id
                ORDER BY article_count DESC
                LIMIT ?
                """,
                params + [limit],
            ).fetchall()
            entities = [
                EntityDetail(
                    id=r["id"],
                    name=r["name"],
                    short_name=r["short_name"],
                    entity_type=r["entity_type"],
                    normalized=r["normalized"],
                    article_count=r["article_count"],
                )
                for r in rows
            ]
            return EntityListResponse(entities=entities, total=len(entities))
        finally:
            conn.close()

    def get_entity(self, entity_id: int) -> EntityDetail | None:
        conn = self._connect()
        try:
            row = conn.execute(
                """
                SELECT e.id, e.name, e.short_name, e.entity_type, e.normalized,
                       COUNT(ae.article_id) as article_count
                FROM entities e
                LEFT JOIN article_entities ae ON ae.entity_id = e.id
                WHERE e.id = ?
                GROUP BY e.id
                """,
                (entity_id,),
            ).fetchone()
            if row is None:
                return None
            return EntityDetail(
                id=row["id"],
                name=row["name"],
                short_name=row["short_name"],
                entity_type=row["entity_type"],
                normalized=row["normalized"],
                article_count=row["article_count"],
            )
        finally:
            conn.close()
