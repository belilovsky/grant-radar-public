"""qazstack.content.api – headless REST API for content (articles, entities, tags).

Provides a reusable FastAPI APIRouter that works with any backend implementing
the ContentProvider protocol. Ships with SQLiteContentProvider for immediate use.

Usage:
    from qazstack.content.api import content_router, ContentProvider, SQLiteContentProvider

    # Option 1: SQLite (like total-kz)
    provider = SQLiteContentProvider("/path/to/data.db")
    app.include_router(content_router(provider), prefix="/api/content")

    # Option 2: Custom backend
    class MyProvider(ContentProvider):
        async def list_articles(...): ...
        ...
    app.include_router(content_router(MyProvider()), prefix="/api/content")
"""

from .provider import ContentProvider
from .router import content_router
from .schemas import (
    ArticleDetail,
    ArticleListResponse,
    ArticleSummary,
    CategoryCount,
    EntityDetail,
    EntityListResponse,
    TagCount,
)
from .sqlite_provider import SQLiteContentProvider

__all__ = [
    # Core
    "content_router",
    "ContentProvider",
    # Providers
    "SQLiteContentProvider",
    # Schemas
    "ArticleDetail",
    "ArticleListResponse",
    "ArticleSummary",
    "CategoryCount",
    "EntityDetail",
    "EntityListResponse",
    "TagCount",
]
