"""FastAPI router factory for the headless content API.

Accepts a ContentProvider and returns a ready-to-mount APIRouter.
All responses are JSON – no templates, no HTML.
"""

from __future__ import annotations

import asyncio
from functools import partial
from typing import TYPE_CHECKING

from fastapi import APIRouter, HTTPException, Query

from .schemas import (
    ArticleDetail,
    ArticleListResponse,
    CategoryCount,
    EntityDetail,
    EntityListResponse,
    TagCount,
)

if TYPE_CHECKING:
    from .provider import ContentProvider


def content_router(
    provider: ContentProvider,
    *,
    prefix: str = "",
    tags: list[str] | None = None,
) -> APIRouter:
    """Create a headless content API router wired to the given provider.

    Args:
        provider: Any object implementing the ContentProvider protocol.
        prefix: Optional path prefix (e.g., "/api/content"). Can also
                be set when calling ``app.include_router()``.
        tags: OpenAPI tags for the router.

    Returns:
        A FastAPI APIRouter ready to be included in an app.

    Example::

        from qazstack.content.api import content_router, SQLiteContentProvider

        provider = SQLiteContentProvider("/data/total.db")
        app.include_router(content_router(provider), prefix="/api/content")
    """
    router = APIRouter(prefix=prefix, tags=tags or ["content"])

    async def _run(fn, *args, **kwargs):
        """Run a sync provider method in a thread pool."""
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, partial(fn, *args, **kwargs))

    # ── Articles ─────────────────────────────────

    @router.get("/articles", response_model=ArticleListResponse)
    async def list_articles(
        page: int = Query(1, ge=1),
        per_page: int = Query(20, ge=1, le=100),
        category: str = "",
        author: str = "",
        tag: str = "",
        entity_id: int = 0,
        date_from: str = "",
        date_to: str = "",
    ):
        """List articles with optional filters and pagination."""
        return await _run(
            provider.list_articles,
            page=page,
            per_page=per_page,
            category=category,
            author=author,
            tag=tag,
            entity_id=entity_id,
            date_from=date_from,
            date_to=date_to,
        )

    @router.get("/articles/search", response_model=ArticleListResponse)
    async def search_articles(
        q: str = Query("", min_length=0),
        page: int = Query(1, ge=1),
        per_page: int = Query(20, ge=1, le=100),
    ):
        """Full-text search across articles."""
        if not q:
            return ArticleListResponse(articles=[], total=0, page=1, per_page=per_page, pages=1)
        return await _run(
            provider.search_articles,
            query=q,
            page=page,
            per_page=per_page,
        )

    @router.get("/articles/{article_id}", response_model=ArticleDetail)
    async def get_article(article_id: int):
        """Get full article by ID."""
        result = await _run(provider.get_article, article_id)
        if result is None:
            raise HTTPException(status_code=404, detail="Article not found")
        return result

    @router.get("/articles/by-slug/{category}/{slug}", response_model=ArticleDetail)
    async def get_article_by_slug(category: str, slug: str):
        """Get article by category and URL slug."""
        result = await _run(provider.get_article_by_slug, category, slug)
        if result is None:
            raise HTTPException(status_code=404, detail="Article not found")
        return result

    # ── Categories ───────────────────────────────

    @router.get("/categories", response_model=list[CategoryCount])
    async def list_categories():
        """Get all categories with article counts."""
        return await _run(provider.list_categories)

    # ── Tags ─────────────────────────────────────

    @router.get("/tags", response_model=list[TagCount])
    async def list_tags(
        limit: int = Query(100, ge=1, le=1000),
    ):
        """Get tags sorted by usage count."""
        return await _run(provider.list_tags, limit=limit)

    # ── Entities ─────────────────────────────────

    @router.get("/entities", response_model=EntityListResponse)
    async def list_entities(
        entity_type: str = "",
        limit: int = Query(50, ge=1, le=500),
    ):
        """Get entities sorted by mention count."""
        return await _run(
            provider.list_entities,
            entity_type=entity_type,
            limit=limit,
        )

    @router.get("/entities/{entity_id}", response_model=EntityDetail)
    async def get_entity(entity_id: int):
        """Get entity by ID."""
        result = await _run(provider.get_entity, entity_id)
        if result is None:
            raise HTTPException(status_code=404, detail="Entity not found")
        return result

    return router
