"""ContentProvider – abstract protocol for content backends.

Any backend (SQLite, PostgreSQL, JSONL) can implement this protocol
to plug into the headless content API router.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from .schemas import (
    ArticleDetail,
    ArticleListResponse,
    CategoryCount,
    EntityDetail,
    EntityListResponse,
    TagCount,
)


@runtime_checkable
class ContentProvider(Protocol):
    """Protocol for content data access.

    All methods are sync – the router wraps them in run_in_executor
    when needed. This keeps providers simple (no async required).
    """

    def list_articles(
        self,
        *,
        page: int = 1,
        per_page: int = 20,
        category: str = "",
        author: str = "",
        tag: str = "",
        entity_id: int = 0,
        date_from: str = "",
        date_to: str = "",
    ) -> ArticleListResponse:
        """List articles with filtering and pagination."""
        ...

    def search_articles(
        self,
        *,
        query: str,
        page: int = 1,
        per_page: int = 20,
    ) -> ArticleListResponse:
        """Full-text search across articles."""
        ...

    def get_article(self, article_id: int) -> ArticleDetail | None:
        """Get a single article by ID with full details (body, entities)."""
        ...

    def get_article_by_slug(self, category: str, slug: str) -> ArticleDetail | None:
        """Get article by category + URL slug."""
        ...

    def list_categories(self) -> list[CategoryCount]:
        """Get all categories with article counts, sorted by count desc."""
        ...

    def list_tags(self, *, limit: int = 100) -> list[TagCount]:
        """Get tags sorted by usage count."""
        ...

    def list_entities(
        self,
        *,
        entity_type: str = "",
        limit: int = 50,
    ) -> EntityListResponse:
        """Get entities sorted by mention count."""
        ...

    def get_entity(self, entity_id: int) -> EntityDetail | None:
        """Get entity by ID with article count."""
        ...
