"""Validated deterministic serializer for curated ``llms.txt`` documents."""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass

from qazstack.seo.discovery import validate_public_https_url


def _single_line(value: str, field: str) -> str:
    normalized = " ".join(value.split())
    if not normalized:
        raise ValueError(f"{field} must be non-empty")
    return normalized


@dataclass(frozen=True, slots=True)
class LlmsEntry:
    title: str
    url: str
    description: str | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "title", _single_line(self.title, "entry.title"))
        object.__setattr__(self, "url", validate_public_https_url(self.url, field="entry.url"))
        if self.description is not None:
            object.__setattr__(self, "description", _single_line(self.description, "entry.description"))


@dataclass(frozen=True, slots=True)
class LlmsSection:
    title: str
    entries: tuple[LlmsEntry, ...]

    def __post_init__(self) -> None:
        object.__setattr__(self, "title", _single_line(self.title, "section.title"))
        if not self.entries:
            raise ValueError("section.entries must not be empty")


def render_llms_txt(
    *,
    title: str,
    summary: str,
    sections: Iterable[LlmsSection],
    metadata: Iterable[tuple[str, str]] = (),
) -> str:
    """Render consumer-owned copy and links into stable Markdown."""
    document_title = _single_line(title, "title")
    document_summary = _single_line(summary, "summary")
    section_items = tuple(sections)
    if not section_items:
        raise ValueError("sections must not be empty")

    lines = [f"# {document_title}", "", document_summary]
    for label, value in metadata:
        lines.extend(["", f"{_single_line(label, 'metadata.label')}: {_single_line(value, 'metadata.value')}"])

    for section in section_items:
        lines.extend(["", f"## {section.title}", ""])
        for entry in section.entries:
            line = f"- [{entry.title}]({entry.url})"
            if entry.description:
                line += f": {entry.description}"
            lines.append(line)
    return "\n".join(lines) + "\n"


__all__ = ["LlmsEntry", "LlmsSection", "render_llms_txt"]
