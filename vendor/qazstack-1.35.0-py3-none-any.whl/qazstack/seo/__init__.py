"""SEO module: meta tags, sitemap, robots.txt, JSON-LD."""

from qazstack.seo.discovery import (
    PublicDiscoveryValidationError,
    ai_surface_map_xml,
    validate_ai_surface_payload,
    validate_public_https_url,
)
from qazstack.seo.jsonld import jsonld_article, jsonld_organization, jsonld_website
from qazstack.seo.llms import LlmsEntry, LlmsSection, render_llms_txt
from qazstack.seo.meta import Meta, meta_tags
from qazstack.seo.sitemap import render_sitemap_xml, sitemap_router

__all__ = [
    "LlmsEntry",
    "LlmsSection",
    "Meta",
    "PublicDiscoveryValidationError",
    "jsonld_article",
    "jsonld_organization",
    "jsonld_website",
    "meta_tags",
    "render_sitemap_xml",
    "sitemap_router",
    "ai_surface_map_xml",
    "render_llms_txt",
    "validate_ai_surface_payload",
    "validate_public_https_url",
]
