"""JSON-LD structured data generators.

Usage in Jinja2:
    <script type="application/ld+json">
    {{ jsonld_website(name="Total.kz", url="https://total.kz") | tojson | safe }}
    </script>
"""

from __future__ import annotations

from typing import Any


def jsonld_website(
    name: str,
    url: str,
    description: str = "",
    search_url: str = "",
) -> dict[str, Any]:
    """Generate WebSite JSON-LD."""
    data: dict[str, Any] = {
        "@context": "https://schema.org",
        "@type": "WebSite",
        "name": name,
        "url": url,
    }
    if description:
        data["description"] = description
    if search_url:
        data["potentialAction"] = {
            "@type": "SearchAction",
            "target": {"@type": "EntryPoint", "urlTemplate": search_url},
            "query-input": "required name=search_term_string",
        }
    return data


def jsonld_article(
    title: str,
    url: str,
    *,
    description: str = "",
    author: str = "",
    date_published: str = "",
    date_modified: str = "",
    image: str = "",
    publisher_name: str = "",
    publisher_logo: str = "",
) -> dict[str, Any]:
    """Generate Article JSON-LD."""
    data: dict[str, Any] = {
        "@context": "https://schema.org",
        "@type": "Article",
        "headline": title,
        "url": url,
    }
    if description:
        data["description"] = description
    if author:
        data["author"] = {"@type": "Person", "name": author}
    if date_published:
        data["datePublished"] = date_published
    if date_modified:
        data["dateModified"] = date_modified
    if image:
        data["image"] = image
    if publisher_name:
        publisher: dict[str, Any] = {"@type": "Organization", "name": publisher_name}
        if publisher_logo:
            publisher["logo"] = {"@type": "ImageObject", "url": publisher_logo}
        data["publisher"] = publisher
    return data


def jsonld_organization(
    name: str,
    url: str,
    *,
    logo: str = "",
    description: str = "",
    same_as: list[str] | None = None,
) -> dict[str, Any]:
    """Generate Organization JSON-LD."""
    data: dict[str, Any] = {
        "@context": "https://schema.org",
        "@type": "Organization",
        "name": name,
        "url": url,
    }
    if logo:
        data["logo"] = logo
    if description:
        data["description"] = description
    if same_as:
        data["sameAs"] = same_as
    return data
