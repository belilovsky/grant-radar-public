"""Machine-readable public discovery surface serializers."""

from __future__ import annotations

import ipaddress
from datetime import date, datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from html import escape
from typing import Any, Mapping
from urllib.parse import urljoin, urlsplit


class PublicDiscoveryValidationError(ValueError):
    """Raised when an AI discovery map is unsafe or internally inconsistent."""


def _aware_datetime(value: Any, *, field: str) -> datetime:
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError as exc:
        raise PublicDiscoveryValidationError(f"{field} must be an ISO 8601 datetime") from exc
    if parsed.tzinfo is None:
        raise PublicDiscoveryValidationError(f"{field} must include a timezone")
    return parsed.astimezone(timezone.utc)


def _public_https_url(value: Any, *, field: str) -> str:
    raw = str(value)
    parsed = urlsplit(raw)
    if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password or parsed.fragment:
        raise PublicDiscoveryValidationError(f"{field} must be a canonical public HTTPS URL")
    host = parsed.hostname.lower().rstrip(".")
    if host == "localhost" or host.endswith(".localhost"):
        raise PublicDiscoveryValidationError(f"{field} must not use localhost")
    try:
        address = ipaddress.ip_address(host)
    except ValueError:
        address = None
    if address and not address.is_global:
        raise PublicDiscoveryValidationError(f"{field} must not use a private or reserved address")
    return raw


def validate_public_https_url(value: Any, *, field: str = "url") -> str:
    """Return a canonical public HTTPS URL or raise a validation error."""
    return _public_https_url(value, field=field)


def validate_ai_surface_payload(
    payload: Mapping[str, Any],
    *,
    now: datetime | None = None,
) -> Mapping[str, Any]:
    """Validate public discovery URLs, canonical paths and freshness metadata."""

    observed_at = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    generated_at = _aware_datetime(payload.get("generated_at"), field="generated_at")
    if generated_at > observed_at + timedelta(minutes=5):
        raise PublicDiscoveryValidationError("generated_at must not be in the future")

    try:
        site = payload["site"]
        base_url = _public_https_url(site["base_url"], field="site.base_url")
        modified_date = date.fromisoformat(str(site["last_modified_date"]))
        modified_http = parsedate_to_datetime(str(site["last_modified_http"]))
    except (KeyError, TypeError, ValueError) as exc:
        raise PublicDiscoveryValidationError("site freshness fields are missing or invalid") from exc
    if modified_http.tzinfo is None:
        raise PublicDiscoveryValidationError("site.last_modified_http must include a timezone")
    if modified_date > observed_at.date() or modified_http.astimezone(timezone.utc) > observed_at + timedelta(
        minutes=5
    ):
        raise PublicDiscoveryValidationError("site modification dates must not be in the future")

    base = base_url.rstrip("/") + "/"
    for group in ("pages", "topic_packs", "discovery_resources"):
        for index, item in enumerate(payload.get(group, [])):
            field = f"{group}[{index}]"
            path = str(item.get("path", ""))
            if not path.startswith("/") or path.startswith("//"):
                raise PublicDiscoveryValidationError(f"{field}.path must be an absolute site path")
            url = _public_https_url(item.get("url"), field=f"{field}.url")
            expected = urljoin(base, path.lstrip("/"))
            if url.rstrip("/") != expected.rstrip("/"):
                raise PublicDiscoveryValidationError(f"{field}.url must match site.base_url and path")
    return payload


def ai_surface_map_xml(payload: Mapping[str, Any]) -> str:
    """Serialize a consumer-owned AI surface payload without changing its data model."""
    validate_ai_surface_payload(payload)
    site = payload["site"]
    counts = payload["counts"]
    language = str(site["requested_language"])
    root_attributes = {
        "version": payload["schema_version"],
        "generated-at": payload["generated_at"],
        "requested-language": language,
    }
    site_attributes = {
        "name": site["name"],
        "base-url": site["base_url"],
        "primary-language": site["primary_language"],
        "last-modified-http": site["last_modified_http"],
        "last-modified-date": site["last_modified_date"],
    }

    def attributes(values: Mapping[str, Any]) -> str:
        return " ".join(f'{key}="{escape(str(value))}"' for key, value in values.items())

    lines = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        f"<ai-surface-map {attributes(root_attributes)}>",
        f"  <site {attributes(site_attributes)} />",
        "  <counts " + attributes({key.replace("_", "-"): value for key, value in counts.items()}) + " />",
        "  <pages>",
    ]
    for page in payload.get("pages", []):
        page_attributes = {key: page[key] for key in ("id", "group", "path", "url")}
        lines.extend(
            [
                f"    <page {attributes(page_attributes)}>",
                f"      <title>{escape(str(page['title']))}</title>",
                f"      <description>{escape(str(page['description']))}</description>",
                f"      <languages>{escape(' '.join(page.get('languages', [])))}</languages>",
                "    </page>",
            ]
        )
    lines.append("  </pages>")
    lines.append("  <topic-packs>")
    for pack in payload.get("topic_packs", []):
        pack_attributes = {key: pack[key] for key in ("id", "path", "url")}
        lines.extend(
            [
                f"    <topic-pack {attributes(pack_attributes)}>",
                f"      <title>{escape(str(pack['title']))}</title>",
                f"      <description>{escape(str(pack['description']))}</description>",
                "    </topic-pack>",
            ]
        )
    lines.append("  </topic-packs>")
    lines.append("  <discovery-resources>")
    for resource in payload.get("discovery_resources", []):
        resource_attributes = {
            "id": resource["id"],
            "path": resource["path"],
            "url": resource["url"],
            "media-type": resource["media_type"],
        }
        lines.append(
            f"    <resource {attributes(resource_attributes)}>{escape(str(resource['description']))}</resource>"
        )
    lines.append("  </discovery-resources>")
    lines.append("  <topic-sections>")
    for section in payload.get("topic_sections", []):
        lines.append(
            f'    <section title="{escape(str(section["title"]))}" item-count="{escape(str(section["item_count"]))}">'
        )
        for sample_url in section.get("sample_urls", []):
            lines.append(f"      <sample-url>{escape(str(sample_url))}</sample-url>")
        lines.append("    </section>")
    lines.extend(["  </topic-sections>", "</ai-surface-map>"])
    return "\n".join(lines) + "\n"
