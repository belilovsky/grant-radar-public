"""Exact, reviewable identifier aliases for product-owned entity records."""

from __future__ import annotations

import unicodedata
from dataclasses import dataclass
from enum import StrEnum
from typing import Iterable

from qazstack.contracts._validation import require_text


class IdentifierAliasStatus(StrEnum):
    VERIFIED = "verified"
    REVIEWED = "reviewed"
    CANDIDATE = "candidate"


def normalize_identifier(value: str) -> str:
    """Return a Unicode-safe exact comparison key without punctuation or spacing."""

    normalized = unicodedata.normalize("NFKC", value).casefold()
    return "".join(character for character in normalized if character.isalnum())


@dataclass(frozen=True, slots=True)
class IdentifierAlias:
    scheme: str
    value: str
    normalized: str
    status: IdentifierAliasStatus = IdentifierAliasStatus.CANDIDATE
    source: str = ""

    def __post_init__(self) -> None:
        require_text(self.scheme, "scheme")
        require_text(self.value, "value")
        if self.normalized != normalize_identifier(self.value):
            raise ValueError("normalized identifier does not match value")
        if not self.normalized:
            raise ValueError("identifier must contain at least one alphanumeric character")

    @classmethod
    def create(
        cls,
        scheme: str,
        value: str,
        *,
        status: IdentifierAliasStatus = IdentifierAliasStatus.CANDIDATE,
        source: str = "",
    ) -> "IdentifierAlias":
        return cls(scheme=scheme, value=value, normalized=normalize_identifier(value), status=status, source=source)


@dataclass(frozen=True, slots=True)
class IdentifierMatch:
    entity_id: str
    alias: IdentifierAlias


class AmbiguousIdentifierError(ValueError):
    """Raised when one normalized identifier points to multiple entities."""


def resolve_identifier(
    query: str,
    aliases: Iterable[tuple[str, IdentifierAlias]],
) -> IdentifierMatch | None:
    normalized_query = normalize_identifier(query)
    if not normalized_query:
        return None
    matches = [(entity_id, alias) for entity_id, alias in aliases if alias.normalized == normalized_query]
    entity_ids = {entity_id for entity_id, _alias in matches}
    if len(entity_ids) > 1:
        raise AmbiguousIdentifierError(f"identifier resolves to multiple entities: {sorted(entity_ids)}")
    if not matches:
        return None
    matches.sort(key=lambda item: list(IdentifierAliasStatus).index(item[1].status))
    entity_id, alias = matches[0]
    return IdentifierMatch(entity_id=entity_id, alias=alias)
