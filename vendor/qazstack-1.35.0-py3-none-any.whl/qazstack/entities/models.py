"""SQLAlchemy 2.0 models for the shared Entity Store.

Five tables on a separate ``EntityBase``:

- ``Entity`` – canonical entity (person, org, location, event)
- ``EntityAlias`` – alternative names / spellings for the same entity
- ``EntityMention`` – each time an entity appears in a source (article, message, etc.)
- ``EntityRelation`` – directed relation between two entities

Naming convention matches qazstack.core and qazstack.monitor.

Compatible entity types (superset of kznlp.Entity labels + total-kz schema):
    PER – person
    ORG – organization
    LOC – location
    EVENT – event
    MISC – other
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from sqlalchemy import (
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    JSON,
    MetaData,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

convention = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}

ENTITY_TYPES = {"PER", "ORG", "LOC", "EVENT", "MISC"}


class EntityBase(DeclarativeBase):
    """Separate declarative base for entity tables.

    Can target a shared database across projects or live per-project.
    """

    metadata = MetaData(naming_convention=convention)


class Entity(EntityBase):
    """Canonical named entity.

    Represents a unique real-world entity.  Multiple surface forms
    (aliases) and cross-project mentions link back here.
    """

    __tablename__ = "entities"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(500), nullable=False)
    normalized: Mapped[str] = mapped_column(String(500), nullable=False, index=True)
    entity_type: Mapped[str] = mapped_column(String(20), nullable=False)  # PER, ORG, LOC, EVENT, MISC
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    metadata_: Mapped[dict[str, Any]] = mapped_column("metadata", JSON, default=dict)
    # Who created: project name or "manual"
    created_by: Mapped[str] = mapped_column(String(100), default="unknown")
    mention_count: Mapped[int] = mapped_column(Integer, default=0)
    first_seen_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    # If merged into another entity, points to the canonical ID
    merged_into_id: Mapped[int | None] = mapped_column(ForeignKey("entities.id"), nullable=True)

    __table_args__ = (
        UniqueConstraint("normalized", "entity_type", name="uq_entities_norm_type"),
        Index("ix_entities_type", "entity_type"),
        Index("ix_entities_mention_count", "mention_count"),
    )


class EntityAlias(EntityBase):
    """Alternative name/spelling for an entity.

    Example: Entity "Касым-Жомарт Токаев" may have aliases
    "Токаев", "Tokayev", "K.-J. Tokayev", "Тоқаев".
    """

    __tablename__ = "entity_aliases"

    id: Mapped[int] = mapped_column(primary_key=True)
    entity_id: Mapped[int] = mapped_column(ForeignKey("entities.id", ondelete="CASCADE"), index=True)
    alias: Mapped[str] = mapped_column(String(500), nullable=False)
    normalized: Mapped[str] = mapped_column(String(500), nullable=False)
    lang: Mapped[str | None] = mapped_column(String(5), nullable=True)  # ru, kk, en
    source: Mapped[str] = mapped_column(String(100), default="auto")  # auto, manual, ner

    __table_args__ = (
        UniqueConstraint("entity_id", "normalized", name="uq_alias_entity_norm"),
        Index("ix_alias_normalized", "normalized"),
    )


class EntityMention(EntityBase):
    """A single occurrence of an entity in a source document/message.

    Links an entity to a specific record in any project's table.
    This is the cross-project glue: Echo Sounder NER, total-kz articles,
    kz-media-monitor enricher, manual Qazpolit entries all write here.
    """

    __tablename__ = "entity_mentions"

    id: Mapped[int] = mapped_column(primary_key=True)
    entity_id: Mapped[int] = mapped_column(ForeignKey("entities.id", ondelete="CASCADE"), index=True)
    source_project: Mapped[str] = mapped_column(String(100), nullable=False)  # echo-sounder, total-kz, ...
    source_table: Mapped[str] = mapped_column(String(100), nullable=False)  # nlp_entities, articles, ...
    source_id: Mapped[int] = mapped_column(Integer, nullable=False)  # PK in the source table
    context: Mapped[str | None] = mapped_column(Text, nullable=True)  # surrounding text snippet
    confidence: Mapped[float] = mapped_column(Float, default=1.0)
    mentioned_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        Index("ix_mention_entity", "entity_id"),
        Index("ix_mention_source", "source_project", "source_table", "source_id"),
        UniqueConstraint(
            "entity_id", "source_project", "source_table", "source_id",
            name="uq_mention_unique",
        ),
    )


class EntityRelation(EntityBase):
    """Directed relation between two entities.

    Examples: (Токаев, "president_of", Казахстан),
              (KazMunayGas, "subsidiary_of", Самрук-Казына).
    """

    __tablename__ = "entity_relations"

    id: Mapped[int] = mapped_column(primary_key=True)
    from_entity_id: Mapped[int] = mapped_column(ForeignKey("entities.id", ondelete="CASCADE"), index=True)
    to_entity_id: Mapped[int] = mapped_column(ForeignKey("entities.id", ondelete="CASCADE"), index=True)
    relation_type: Mapped[str] = mapped_column(String(100), nullable=False)  # works_at, president_of, located_in, etc.
    metadata_: Mapped[dict[str, Any]] = mapped_column("metadata", JSON, default=dict)
    source: Mapped[str] = mapped_column(String(100), default="auto")  # auto, manual
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        UniqueConstraint(
            "from_entity_id", "to_entity_id", "relation_type",
            name="uq_relation_pair_type",
        ),
    )
