"""Dependency-free identity primitives for entity-producing projects.

The entity store is optional for consumers. These helpers let a project keep
its own persistence model while producing stable identifiers compatible with
the shared QazStack entity contract.
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass

_ENTITY_TYPE_ALIASES = {
    "PER": "PER",
    "PERSON": "PER",
    "ORG": "ORG",
    "ORGANIZATION": "ORG",
    "LOC": "LOC",
    "LOCATION": "LOC",
    "EVENT": "EVENT",
    "MISC": "MISC",
}


def normalize_entity_name(name: str) -> str:
    """Return the stable comparison form used for entity deduplication."""
    text = unicodedata.normalize("NFKC", name.strip()).lower()
    return re.sub(r"\s+", " ", text)


def canonical_entity_type(entity_type: str) -> str:
    """Map common entity labels to the QazStack entity type vocabulary."""
    normalized_type = entity_type.strip().upper()
    try:
        return _ENTITY_TYPE_ALIASES[normalized_type]
    except KeyError as exc:
        supported = ", ".join(sorted(_ENTITY_TYPE_ALIASES))
        raise ValueError(f"unsupported entity type '{entity_type}'; expected one of {supported}") from exc


@dataclass(frozen=True)
class EntitySourceReference:
    """Stable reference to the source record that produced an entity mention."""

    project_id: str
    table: str
    record_id: int

    def __post_init__(self) -> None:
        if not self.project_id.strip() or not self.table.strip():
            raise ValueError("project_id and table must be non-empty")
        if self.record_id <= 0:
            raise ValueError("record_id must be positive")
