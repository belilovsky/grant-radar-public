"""QazStack Entity Store – shared entity database across projects.

Provides a unified store for named entities (Person, Organization, Location,
Event) discovered by NER, manual input, or external sources. Supports
deduplication, merging, cross-project linking, and mention tracking.

Tables use ``EntityBase`` (separate DeclarativeBase) so they can live in a
shared database or per-project database.

Quick start::

    from qazstack.entities import EntityBase, EntityStore, Entity, EntityMention
    from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker

    engine = create_async_engine("postgresql+asyncpg://...")
    async with engine.begin() as conn:
        await conn.run_sync(EntityBase.metadata.create_all)

    store = EntityStore()
    async with async_sessionmaker(engine)() as session:
        person = await store.add_entity(session, name="Токаев", entity_type="PER",
                                        project="echo-sounder")
        await store.add_mention(session, entity_id=person.id,
                                source_project="echo-sounder",
                                source_table="nlp_entities", source_id=42,
                                context="Президент Токаев выступил...")
"""

from __future__ import annotations

from importlib import import_module
from typing import TYPE_CHECKING

from .contracts import (
    GraphEdge,
    GraphNode,
    ResolutionCandidate,
    ResolutionDecision,
    TimelineEvent,
    order_timeline,
)
from .identifiers import (
    AmbiguousIdentifierError,
    IdentifierAlias,
    IdentifierAliasStatus,
    IdentifierMatch,
    normalize_identifier,
    resolve_identifier,
)
from .identity import EntitySourceReference, canonical_entity_type, normalize_entity_name

if TYPE_CHECKING:
    from .aliases import AliasCandidate, suggest_alias_candidates, transliterate_cyrillic
    from .models import Entity, EntityAlias, EntityBase, EntityMention, EntityRelation
    from .router import entity_router
    from .store import EntityStore


_LAZY_EXPORTS = {
    "EntityBase": (".models", "EntityBase"),
    "Entity": (".models", "Entity"),
    "EntityAlias": (".models", "EntityAlias"),
    "EntityMention": (".models", "EntityMention"),
    "EntityRelation": (".models", "EntityRelation"),
    "EntityStore": (".store", "EntityStore"),
    "entity_router": (".router", "entity_router"),
    "AliasCandidate": (".aliases", "AliasCandidate"),
    "suggest_alias_candidates": (".aliases", "suggest_alias_candidates"),
    "transliterate_cyrillic": (".aliases", "transliterate_cyrillic"),
}


def __getattr__(name: str):
    """Load database-backed exports only when a consumer requests them."""
    try:
        module_name, export_name = _LAZY_EXPORTS[name]
    except KeyError as exc:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}") from exc
    value = getattr(import_module(module_name, __name__), export_name)
    globals()[name] = value
    return value


def __dir__() -> list[str]:
    return sorted(set(globals()) | set(_LAZY_EXPORTS))


__all__ = [
    "EntityBase",
    "Entity",
    "EntityAlias",
    "EntityMention",
    "EntityRelation",
    "EntityStore",
    "entity_router",
    "AliasCandidate",
    "suggest_alias_candidates",
    "transliterate_cyrillic",
    "EntitySourceReference",
    "canonical_entity_type",
    "normalize_entity_name",
    "GraphEdge",
    "GraphNode",
    "ResolutionCandidate",
    "ResolutionDecision",
    "TimelineEvent",
    "order_timeline",
    "AmbiguousIdentifierError",
    "IdentifierAlias",
    "IdentifierAliasStatus",
    "IdentifierMatch",
    "normalize_identifier",
    "resolve_identifier",
]
