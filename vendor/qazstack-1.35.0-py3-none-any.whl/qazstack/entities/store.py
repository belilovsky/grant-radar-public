"""Async CRUD store for the Entity database.

Handles deduplication, alias resolution, merge, and cross-project search.

Usage::

    store = EntityStore()
    async with session_maker() as session:
        entity = await store.add_entity(session, name="Токаев", entity_type="PER",
                                        project="echo-sounder")
        await store.add_mention(session, entity_id=entity.id, ...)
        results = await store.search(session, query="Токаев")
"""

from __future__ import annotations

import re
import unicodedata
from typing import Sequence

from sqlalchemy import func, or_, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from .models import ENTITY_TYPES, Entity, EntityAlias, EntityMention, EntityRelation


def normalize_name(name: str) -> str:
    """Normalize entity name for dedup: lowercase, strip, collapse whitespace.

    Also applies Unicode NFKC normalization and strips accents.
    """
    text = unicodedata.normalize("NFKC", name.strip())
    text = text.lower()
    text = re.sub(r"\s+", " ", text)
    return text


class EntityStore:
    """Async CRUD operations for the entity store."""

    # ------------------------------------------------------------------
    # Core CRUD
    # ------------------------------------------------------------------

    async def add_entity(
        self,
        session: AsyncSession,
        *,
        name: str,
        entity_type: str,
        project: str = "unknown",
        description: str | None = None,
        metadata: dict | None = None,
    ) -> Entity:
        """Add a new entity or return existing if duplicate (name+type).

        Deduplication is by (normalized, entity_type).
        """
        if entity_type not in ENTITY_TYPES:
            raise ValueError(f"entity_type must be one of {ENTITY_TYPES}, got '{entity_type}'")

        normalized = normalize_name(name)

        # Check existing
        stmt = select(Entity).where(
            Entity.normalized == normalized,
            Entity.entity_type == entity_type,
            Entity.merged_into_id.is_(None),
        )
        result = await session.execute(stmt)
        existing = result.scalar_one_or_none()
        if existing:
            return existing

        entity = Entity(
            name=name,
            normalized=normalized,
            entity_type=entity_type,
            description=description,
            metadata_=metadata or {},
            created_by=project,
        )
        session.add(entity)
        await session.flush()
        return entity

    async def get_entity(self, session: AsyncSession, entity_id: int) -> Entity | None:
        """Get entity by ID, following merge chain."""
        result = await session.execute(select(Entity).where(Entity.id == entity_id))
        entity = result.scalar_one_or_none()
        if entity and entity.merged_into_id:
            return await self.get_entity(session, entity.merged_into_id)
        return entity

    async def resolve_by_name(
        self,
        session: AsyncSession,
        name: str,
        entity_type: str | None = None,
    ) -> Entity | None:
        """Find entity by name or alias. Returns canonical (non-merged) entity."""
        normalized = normalize_name(name)

        # Direct match
        stmt = select(Entity).where(
            Entity.normalized == normalized,
            Entity.merged_into_id.is_(None),
        )
        if entity_type:
            stmt = stmt.where(Entity.entity_type == entity_type)
        result = await session.execute(stmt)
        entity = result.scalar_one_or_none()
        if entity:
            return entity

        # Alias match
        alias_stmt = (
            select(Entity)
            .join(EntityAlias, EntityAlias.entity_id == Entity.id)
            .where(EntityAlias.normalized == normalized, Entity.merged_into_id.is_(None))
        )
        if entity_type:
            alias_stmt = alias_stmt.where(Entity.entity_type == entity_type)
        result = await session.execute(alias_stmt)
        return result.scalar_one_or_none()

    # ------------------------------------------------------------------
    # Aliases
    # ------------------------------------------------------------------

    async def add_alias(
        self,
        session: AsyncSession,
        *,
        entity_id: int,
        alias: str,
        lang: str | None = None,
        source: str = "auto",
    ) -> EntityAlias:
        """Add an alternative name for an entity. Idempotent."""
        normalized = normalize_name(alias)

        stmt = select(EntityAlias).where(
            EntityAlias.entity_id == entity_id,
            EntityAlias.normalized == normalized,
        )
        result = await session.execute(stmt)
        existing = result.scalar_one_or_none()
        if existing:
            return existing

        obj = EntityAlias(
            entity_id=entity_id,
            alias=alias,
            normalized=normalized,
            lang=lang,
            source=source,
        )
        session.add(obj)
        await session.flush()
        return obj

    async def get_aliases(self, session: AsyncSession, entity_id: int) -> Sequence[EntityAlias]:
        """Get all aliases for an entity."""
        result = await session.execute(
            select(EntityAlias).where(EntityAlias.entity_id == entity_id)
        )
        return result.scalars().all()

    # ------------------------------------------------------------------
    # Mentions
    # ------------------------------------------------------------------

    async def add_mention(
        self,
        session: AsyncSession,
        *,
        entity_id: int,
        source_project: str,
        source_table: str,
        source_id: int,
        context: str | None = None,
        confidence: float = 1.0,
    ) -> EntityMention:
        """Record a mention of an entity from a specific source. Idempotent.

        Increments mention_count on the entity.
        """
        stmt = select(EntityMention).where(
            EntityMention.entity_id == entity_id,
            EntityMention.source_project == source_project,
            EntityMention.source_table == source_table,
            EntityMention.source_id == source_id,
        )
        result = await session.execute(stmt)
        existing = result.scalar_one_or_none()
        if existing:
            return existing

        mention = EntityMention(
            entity_id=entity_id,
            source_project=source_project,
            source_table=source_table,
            source_id=source_id,
            context=context,
            confidence=confidence,
        )
        session.add(mention)

        # Increment mention count
        await session.execute(
            update(Entity)
            .where(Entity.id == entity_id)
            .values(mention_count=Entity.mention_count + 1)
        )
        await session.flush()
        return mention

    async def get_mentions(
        self,
        session: AsyncSession,
        entity_id: int,
        *,
        project: str | None = None,
        limit: int = 50,
    ) -> Sequence[EntityMention]:
        """Get mentions for an entity, optionally filtered by project."""
        stmt = (
            select(EntityMention)
            .where(EntityMention.entity_id == entity_id)
            .order_by(EntityMention.mentioned_at.desc())
            .limit(limit)
        )
        if project:
            stmt = stmt.where(EntityMention.source_project == project)
        result = await session.execute(stmt)
        return result.scalars().all()

    # ------------------------------------------------------------------
    # Merge
    # ------------------------------------------------------------------

    async def merge_entities(
        self,
        session: AsyncSession,
        *,
        keep_id: int,
        merge_id: int,
    ) -> Entity:
        """Merge merge_id into keep_id. All mentions/aliases transfer.

        The merged entity is marked with merged_into_id and kept for
        redirect lookups.
        """
        if keep_id == merge_id:
            raise ValueError("Cannot merge entity into itself")

        keep = await session.get(Entity, keep_id)
        merge = await session.get(Entity, merge_id)
        if not keep or not merge:
            raise ValueError("Entity not found")

        # Transfer mentions
        await session.execute(
            update(EntityMention)
            .where(EntityMention.entity_id == merge_id)
            .values(entity_id=keep_id)
        )

        # Transfer aliases (add merged entity's name as alias)
        await self.add_alias(session, entity_id=keep_id, alias=merge.name, source="merge")
        await session.execute(
            update(EntityAlias)
            .where(EntityAlias.entity_id == merge_id)
            .values(entity_id=keep_id)
        )

        # Transfer relations
        await session.execute(
            update(EntityRelation)
            .where(EntityRelation.from_entity_id == merge_id)
            .values(from_entity_id=keep_id)
        )
        await session.execute(
            update(EntityRelation)
            .where(EntityRelation.to_entity_id == merge_id)
            .values(to_entity_id=keep_id)
        )

        # Update mention count
        keep.mention_count = keep.mention_count + merge.mention_count

        # Mark as merged
        merge.merged_into_id = keep_id
        merge.mention_count = 0

        await session.flush()
        return keep

    # ------------------------------------------------------------------
    # Relations
    # ------------------------------------------------------------------

    async def add_relation(
        self,
        session: AsyncSession,
        *,
        from_id: int,
        to_id: int,
        relation_type: str,
        metadata: dict | None = None,
        source: str = "auto",
    ) -> EntityRelation:
        """Add a directed relation between two entities. Idempotent."""
        stmt = select(EntityRelation).where(
            EntityRelation.from_entity_id == from_id,
            EntityRelation.to_entity_id == to_id,
            EntityRelation.relation_type == relation_type,
        )
        result = await session.execute(stmt)
        existing = result.scalar_one_or_none()
        if existing:
            return existing

        rel = EntityRelation(
            from_entity_id=from_id,
            to_entity_id=to_id,
            relation_type=relation_type,
            metadata_=metadata or {},
            source=source,
        )
        session.add(rel)
        await session.flush()
        return rel

    async def get_relations(
        self,
        session: AsyncSession,
        entity_id: int,
    ) -> Sequence[EntityRelation]:
        """Get all relations involving an entity (from or to)."""
        stmt = select(EntityRelation).where(
            or_(
                EntityRelation.from_entity_id == entity_id,
                EntityRelation.to_entity_id == entity_id,
            )
        )
        result = await session.execute(stmt)
        return result.scalars().all()

    # ------------------------------------------------------------------
    # Search
    # ------------------------------------------------------------------

    async def search(
        self,
        session: AsyncSession,
        query: str,
        *,
        entity_type: str | None = None,
        limit: int = 20,
    ) -> Sequence[Entity]:
        """Search entities by name/alias (prefix match on normalized form).

        Returns non-merged entities, ordered by mention_count desc.
        """
        normalized = normalize_name(query)
        pattern = f"%{normalized}%"

        # Search both entity names and aliases
        entity_ids_from_alias = (
            select(EntityAlias.entity_id)
            .where(EntityAlias.normalized.like(pattern))
            .scalar_subquery()
        )

        stmt = (
            select(Entity)
            .where(
                Entity.merged_into_id.is_(None),
                or_(
                    Entity.normalized.like(pattern),
                    Entity.id.in_(entity_ids_from_alias),
                ),
            )
            .order_by(Entity.mention_count.desc())
            .limit(limit)
        )
        if entity_type:
            stmt = stmt.where(Entity.entity_type == entity_type)

        result = await session.execute(stmt)
        return result.scalars().all()

    async def top_entities(
        self,
        session: AsyncSession,
        *,
        entity_type: str | None = None,
        project: str | None = None,
        limit: int = 50,
    ) -> Sequence[Entity]:
        """Get top entities by mention count."""
        stmt = (
            select(Entity)
            .where(Entity.merged_into_id.is_(None))
            .order_by(Entity.mention_count.desc())
            .limit(limit)
        )
        if entity_type:
            stmt = stmt.where(Entity.entity_type == entity_type)
        if project:
            # Filter to entities that have at least one mention from this project
            has_mention = (
                select(EntityMention.entity_id)
                .where(EntityMention.source_project == project)
                .distinct()
                .scalar_subquery()
            )
            stmt = stmt.where(Entity.id.in_(has_mention))
        result = await session.execute(stmt)
        return result.scalars().all()

    async def stats(self, session: AsyncSession) -> dict:
        """Return summary statistics."""
        total = await session.scalar(
            select(func.count(Entity.id)).where(Entity.merged_into_id.is_(None))
        )
        by_type = {}
        for etype in ENTITY_TYPES:
            count = await session.scalar(
                select(func.count(Entity.id)).where(
                    Entity.entity_type == etype,
                    Entity.merged_into_id.is_(None),
                )
            )
            by_type[etype] = count or 0

        mention_count = await session.scalar(select(func.count(EntityMention.id)))
        alias_count = await session.scalar(select(func.count(EntityAlias.id)))
        relation_count = await session.scalar(select(func.count(EntityRelation.id)))

        # Mentions by project
        from sqlalchemy import distinct
        projects_stmt = select(
            EntityMention.source_project,
            func.count(EntityMention.id),
        ).group_by(EntityMention.source_project)
        result = await session.execute(projects_stmt)
        by_project = {row[0]: row[1] for row in result.all()}

        return {
            "total_entities": total or 0,
            "by_type": by_type,
            "total_mentions": mention_count or 0,
            "total_aliases": alias_count or 0,
            "total_relations": relation_count or 0,
            "mentions_by_project": by_project,
        }
