"""Entity resolution, graph and timeline result contracts."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from qazstack.contracts._validation import (
    require_aware,
    require_identifier,
    require_one_of,
    require_ratio,
    require_text,
)


@dataclass(frozen=True, slots=True)
class ResolutionCandidate:
    canonical_id: str
    canonical_name: str
    aliases: tuple[str, ...]
    confidence: float
    evidence_refs: tuple[str, ...]

    def __post_init__(self) -> None:
        require_identifier(self.canonical_id, "canonical_id")
        require_text(self.canonical_name, "canonical_name")
        require_ratio(self.confidence, "confidence")
        if not self.evidence_refs:
            raise ValueError("resolution candidates require evidence")


@dataclass(frozen=True, slots=True)
class ResolutionDecision:
    status: str
    candidates: tuple[ResolutionCandidate, ...]
    chosen_id: str | None = None
    reason: str = ""

    def __post_init__(self) -> None:
        require_one_of(self.status, frozenset({"matched", "ambiguous", "unmatched"}), "status")
        if self.status == "matched" and not self.chosen_id:
            raise ValueError("matched decisions require chosen_id")
        if self.status == "matched" and self.chosen_id not in {item.canonical_id for item in self.candidates}:
            raise ValueError("chosen_id must reference a candidate")
        if self.status == "ambiguous" and len(self.candidates) < 2:
            raise ValueError("ambiguous decisions require at least two candidates")
        if self.status == "unmatched" and self.candidates:
            raise ValueError("unmatched decisions cannot contain candidates")


@dataclass(frozen=True, slots=True)
class GraphNode:
    node_id: str
    node_type: str
    label: str
    source_refs: tuple[str, ...]

    def __post_init__(self) -> None:
        require_identifier(self.node_id, "node_id")
        require_identifier(self.node_type, "node_type")
        require_text(self.label, "label")
        if not self.source_refs:
            raise ValueError("graph nodes require provenance")


@dataclass(frozen=True, slots=True)
class GraphEdge:
    edge_id: str
    source_id: str
    target_id: str
    relation: str
    valid_from: datetime | None
    valid_to: datetime | None
    source_refs: tuple[str, ...]

    def __post_init__(self) -> None:
        require_identifier(self.edge_id, "edge_id")
        require_identifier(self.source_id, "source_id")
        require_identifier(self.target_id, "target_id")
        require_identifier(self.relation, "relation")
        if self.source_id == self.target_id:
            raise ValueError("self edges must be modeled explicitly by the consumer")
        for name in ("valid_from", "valid_to"):
            value = getattr(self, name)
            if value is not None:
                require_aware(value, name)
        if self.valid_from and self.valid_to and self.valid_to < self.valid_from:
            raise ValueError("valid_to cannot precede valid_from")
        if not self.source_refs:
            raise ValueError("graph edges require provenance")


@dataclass(frozen=True, slots=True)
class TimelineEvent:
    event_id: str
    title: str
    starts_at: datetime
    ends_at: datetime | None
    entity_ids: tuple[str, ...]
    source_refs: tuple[str, ...]

    def __post_init__(self) -> None:
        require_identifier(self.event_id, "event_id")
        require_text(self.title, "title")
        require_aware(self.starts_at, "starts_at")
        if self.ends_at is not None:
            require_aware(self.ends_at, "ends_at")
            if self.ends_at < self.starts_at:
                raise ValueError("ends_at cannot precede starts_at")
        if not self.entity_ids or not self.source_refs:
            raise ValueError("timeline events require entities and provenance")


def order_timeline(events: tuple[TimelineEvent, ...]) -> tuple[TimelineEvent, ...]:
    return tuple(sorted(events, key=lambda item: (item.starts_at, item.event_id)))
