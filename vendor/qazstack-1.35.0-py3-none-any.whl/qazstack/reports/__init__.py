"""qazstack.reports – Reusable PDF and HTML report generation infrastructure.

This module provides a domain-agnostic toolkit for producing styled PDF and
HTML reports.  ReportLab and Jinja2 are optional dependencies; import errors
are deferred until the relevant classes are actually used.

Public API
----------
ReportBuilder
    Fluent interface for building PDF reports section-by-section.
PDFReport
    Low-level PDF builder that accepts a list of ``ReportSection`` objects.
ReportSection
    Dataclass holding a section title and its ReportLab flowable elements.
ReportStyle
    Dataclass configuring fonts, colors, and page margins.
MetricCard
    Dataclass representing a single KPI metric card.
TrafficLight
    Namespace of traffic-light zone constants (GREEN, YELLOW, ORANGE, RED, GRAY).
ZoneClassifier
    Generic threshold-based zone classifier.
HTMLReport
    Jinja2-based HTML report renderer.

Examples
--------
Quick PDF
~~~~~~~~~
::

    from qazstack.reports import ReportBuilder, ReportStyle
    from qazstack.reports.components import report_header, metrics_table, MetricCard, TrafficLight

    builder = ReportBuilder()
    ctx = builder.ctx
    builder.add_section("header", report_header(ctx, "Monthly KPI Report", "January 2025"))
    builder.add_section(
        "metrics",
        metrics_table(ctx, [
            MetricCard("Revenue", "$1.2M", "Total revenue", "On track", TrafficLight.GREEN),
            MetricCard("Churn",   "4.2%",  "Monthly churn", "Watch",    TrafficLight.YELLOW),
        ]),
    )
    pdf_bytes = builder.build()

Quick HTML
~~~~~~~~~~
::

    from qazstack.reports import HTMLReport

    report = HTMLReport()
    html = report.render("base_report.html", {
        "title": "Monthly KPI Report",
        "subtitle": "January 2025",
    })
"""

from __future__ import annotations

from qazstack.reports.components import MetricCard, TrafficLight, ZoneClassifier
from qazstack.reports.documents import DocumentInput, ExportArtifact, ParseWarning
from qazstack.reports.html import HTMLReport
from qazstack.reports.pdf import PDFReport, ReportBuilder, ReportSection, ReportStyle

__all__ = [
    "ReportBuilder",
    "PDFReport",
    "MetricCard",
    "TrafficLight",
    "ZoneClassifier",
    "ReportSection",
    "ReportStyle",
    "HTMLReport",
    "DocumentInput",
    "ExportArtifact",
    "ParseWarning",
]
