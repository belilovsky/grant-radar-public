"""Core PDF report engine.

Provides ``PDFReport`` for building PDF documents from ``ReportSection``
objects, along with ``ReportStyle`` for configuring fonts and colors.
ReportLab is imported lazily so the module can be imported without it
installed.
"""

from __future__ import annotations

import io
import os
from dataclasses import dataclass, field
from typing import Any


# ===================== STYLE =====================


@dataclass
class ReportStyle:
    """Configuration for PDF report appearance.

    Attributes
    ----------
    font_family:
        Primary font family name to use for text. If not found at
        *font_paths*, the engine falls back through *fallback_paths*
        and finally to Helvetica.
    font_paths:
        Directories to search for the primary font TTF files.
    fallback_paths:
        Directories to search for DejaVu Sans as a fallback font.
    accent_color:
        Hex color used for headings and accents.
    surface_color:
        Hex color used for alternating table row backgrounds.
    text_color:
        Hex color used for body text.
    muted_color:
        Hex color used for secondary/small text.
    header_color:
        Hex color used for table header backgrounds.
    page_top_margin:
        Top page margin in millimetres.
    page_bottom_margin:
        Bottom page margin in millimetres.
    page_left_margin:
        Left page margin in millimetres.
    page_right_margin:
        Right page margin in millimetres.
    """

    font_family: str = "Inter"
    font_paths: list[str] = field(default_factory=list)
    fallback_paths: list[str] = field(
        default_factory=lambda: [
            "/usr/share/fonts/truetype/dejavu",
            "/usr/share/fonts/truetype/DejaVu",
            "/usr/share/fonts/dejavu",
        ]
    )
    accent_color: str = "#1e3a5f"
    surface_color: str = "#f8fafc"
    text_color: str = "#0f172a"
    muted_color: str = "#64748b"
    header_color: str = "#1e293b"
    page_top_margin: float = 18.0
    page_bottom_margin: float = 15.0
    page_left_margin: float = 16.0
    page_right_margin: float = 16.0


# ===================== REPORT SECTION =====================


@dataclass
class ReportSection:
    """A named section of a PDF report containing ReportLab flowables.

    Attributes
    ----------
    title:
        Section title (informational; not automatically rendered).
    elements:
        List of ReportLab flowable objects making up this section.
    """

    title: str
    elements: list[Any] = field(default_factory=list)


# ===================== FONT REGISTRATION =====================

_FONT_CACHE: dict[str, tuple[str, str, str, str]] = {}


def _register_fonts(style: ReportStyle) -> tuple[str, str, str, str]:
    """Register TTF fonts with ReportLab based on *style*.

    Attempts to register the primary font family (Inter → Rubik) from
    *style.font_paths*, then falls back to DejaVu Sans, and finally to
    built-in Helvetica.

    Returns a tuple ``(regular, bold, semibold, medium)`` of registered
    font names.
    """
    cache_key = style.font_family + "|".join(style.font_paths)
    if cache_key in _FONT_CACHE:
        return _FONT_CACHE[cache_key]

    try:
        from reportlab.pdfbase import pdfmetrics
        from reportlab.pdfbase.ttfonts import TTFont
        from reportlab.pdfbase.pdfmetrics import registerFontFamily
    except ImportError:
        result = ("Helvetica", "Helvetica-Bold", "Helvetica-Bold", "Helvetica")
        _FONT_CACHE[cache_key] = result
        return result

    family = style.font_family

    # Common font file name patterns (primary font family first, then Rubik)
    candidate_families = [
        (family, f"{family}-Regular.ttf", f"{family}-Bold.ttf", f"{family}-SemiBold.ttf", f"{family}-Medium.ttf"),
        ("Rubik", "Rubik-Regular.ttf", "Rubik-Bold.ttf", "Rubik-SemiBold.ttf", "Rubik-Medium.ttf"),
    ]

    search_dirs = list(style.font_paths) + [
        "/usr/share/fonts/truetype/rubik",
        "/usr/share/fonts/truetype/inter",
        os.path.join(os.path.dirname(__file__), "..", "..", "fonts"),
    ]

    for fam_name, reg_file, bold_file, sb_file, md_file in candidate_families:
        for d in search_dirs:
            reg_path = os.path.join(d, reg_file)
            if not os.path.isfile(reg_path):
                continue
            bold_path = os.path.join(d, bold_file)
            sb_path = os.path.join(d, sb_file)
            md_path = os.path.join(d, md_file)

            reg_name = f"{family}"
            bold_name = f"{family}-Bold"
            sb_name = f"{family}-SemiBold"
            md_name = f"{family}-Medium"

            pdfmetrics.registerFont(TTFont(reg_name, reg_path))
            pdfmetrics.registerFont(
                TTFont(bold_name, bold_path if os.path.isfile(bold_path) else reg_path)
            )
            pdfmetrics.registerFont(
                TTFont(
                    sb_name,
                    sb_path if os.path.isfile(sb_path) else (bold_path if os.path.isfile(bold_path) else reg_path),
                )
            )
            pdfmetrics.registerFont(
                TTFont(md_name, md_path if os.path.isfile(md_path) else reg_path)
            )
            registerFontFamily(reg_name, normal=reg_name, bold=bold_name)
            result = (reg_name, bold_name, sb_name, md_name)
            _FONT_CACHE[cache_key] = result
            return result

    # Fallback: DejaVu Sans
    for d in style.fallback_paths:
        reg_path = os.path.join(d, "DejaVuSans.ttf")
        if not os.path.isfile(reg_path):
            continue
        bold_path = os.path.join(d, "DejaVuSans-Bold.ttf")

        fam = family
        pdfmetrics.registerFont(TTFont(fam, reg_path))
        pdfmetrics.registerFont(
            TTFont(f"{fam}-Bold", bold_path if os.path.isfile(bold_path) else reg_path)
        )
        pdfmetrics.registerFont(
            TTFont(f"{fam}-SemiBold", bold_path if os.path.isfile(bold_path) else reg_path)
        )
        pdfmetrics.registerFont(TTFont(f"{fam}-Medium", reg_path))
        registerFontFamily(fam, normal=fam, bold=f"{fam}-Bold")
        result = (fam, f"{fam}-Bold", f"{fam}-SemiBold", f"{fam}-Medium")
        _FONT_CACHE[cache_key] = result
        return result

    # Last resort: Helvetica (no extended Unicode support)
    result = ("Helvetica", "Helvetica-Bold", "Helvetica-Bold", "Helvetica")
    _FONT_CACHE[cache_key] = result
    return result


# ===================== MINIMAL PDF FALLBACK =====================


def _minimal_pdf() -> bytes:
    """Return a minimal valid PDF when ReportLab is not available."""
    return (
        b"%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n"
        b"2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj\n"
        b"3 0 obj<</Type/Page/MediaBox[0 0 595 842]/Parent 2 0 R/Resources<<>>>>endobj\n"
        b"xref\n0 4\n0000000000 65535 f \n0000000009 00000 n \n"
        b"0000000058 00000 n \n0000000115 00000 n \n"
        b"trailer<</Size 4/Root 1 0 R>>\nstartxref\n219\n%%EOF"
    )


# ===================== PDF REPORT =====================


class PDFReport:
    """Builds a PDF document from a list of ``ReportSection`` objects.

    Parameters
    ----------
    style:
        Visual configuration. Uses ``ReportStyle()`` defaults when ``None``.

    Examples
    --------
    >>> from qazstack.reports.pdf import PDFReport, ReportSection, ReportStyle
    >>> from qazstack.reports.components import report_header, report_footer
    >>> report = PDFReport()
    >>> # ctx is available after calling build(); build sections using component helpers
    """

    def __init__(self, style: ReportStyle | None = None) -> None:
        self._style = style or ReportStyle()

    @property
    def style(self) -> ReportStyle:
        """The active ``ReportStyle`` configuration."""
        return self._style

    def _build_ctx(
        self,
        font: str,
        font_bd: str,
        font_sb: str,
        font_md: str,
        styles: Any,
    ) -> dict[str, Any]:
        """Build the context dict passed to component builder functions."""
        try:
            from reportlab.lib.pagesizes import A4
            from reportlab.lib.units import mm
            from reportlab.lib.colors import HexColor, white, black
            from reportlab.platypus import Paragraph, Spacer, Table, TableStyle, HRFlowable
            from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
        except ImportError:
            return {}

        return {
            "styles": styles,
            "A4": A4,
            "mm": mm,
            "HexColor": HexColor,
            "white": white,
            "black": black,
            "Table": Table,
            "TableStyle": TableStyle,
            "Paragraph": Paragraph,
            "Spacer": Spacer,
            "HRFlowable": HRFlowable,
            "TA_CENTER": TA_CENTER,
            "TA_LEFT": TA_LEFT,
            "TA_RIGHT": TA_RIGHT,
            "font": font,
            "font_bd": font_bd,
            "font_sb": font_sb,
            "font_md": font_md,
            # Aliases for backwards-compat with SWSB patterns
            "cyr_font": font,
            "cyr_font_bd": font_bd,
            "cyr_font_sb": font_sb,
            "cyr_font_md": font_md,
        }

    def _build_styles(self, font: str, font_bd: str, font_sb: str, font_md: str) -> Any:
        """Create and register all named ``ParagraphStyle`` objects."""
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.colors import HexColor
        from reportlab.lib.enums import TA_CENTER, TA_LEFT

        st = self._style
        styles = getSampleStyleSheet()

        defs = [
            dict(
                name="ReportTitle",
                parent="Heading1",
                fontName=font_bd,
                fontSize=22,
                textColor=HexColor(st.text_color),
                spaceAfter=2,
                alignment=TA_CENTER,
            ),
            dict(
                name="ReportSubtitle",
                parent="Normal",
                fontName=font_md,
                fontSize=10,
                textColor=HexColor("#475569"),
                spaceAfter=6,
                alignment=TA_CENTER,
            ),
            dict(
                name="ReportSection",
                parent="Heading2",
                fontName=font_sb,
                fontSize=12,
                textColor=HexColor(st.accent_color),
                spaceBefore=7,
                spaceAfter=3,
            ),
            dict(
                name="ReportBody",
                parent="Normal",
                fontName=font,
                fontSize=9.5,
                leading=15,
            ),
            dict(
                name="ReportBodyBold",
                parent="Normal",
                fontName=font_sb,
                fontSize=9.5,
                leading=15,
            ),
            dict(
                name="ReportSmall",
                parent="Normal",
                fontName=font,
                fontSize=8,
                leading=11,
                textColor=HexColor(st.muted_color),
            ),
            dict(
                name="ReportSummary",
                parent="Normal",
                fontName=font_md,
                fontSize=10,
                leading=15,
                spaceBefore=3,
                spaceAfter=4,
                backColor=HexColor("#f1f5f9"),
                borderPadding=(10, 12, 10, 12),
                borderColor=HexColor("#cbd5e1"),
                borderWidth=0.5,
            ),
            dict(
                name="ReportFooter",
                parent="Normal",
                fontName=font,
                fontSize=7.5,
                leading=10,
                textColor=HexColor("#94a3b8"),
                alignment=TA_CENTER,
            ),
        ]

        for d in defs:
            parent_name = d.pop("parent")
            name = d["name"]
            styles.add(ParagraphStyle(name, parent=styles[parent_name], **{k: v for k, v in d.items() if k != "name"}))

        return styles

    def build(self, sections: list[ReportSection]) -> bytes:
        """Build a PDF document and return it as bytes.

        Parameters
        ----------
        sections:
            Ordered list of ``ReportSection`` objects whose ``elements``
            are concatenated into the document flowable list.

        Returns
        -------
        bytes
            Raw PDF bytes starting with ``%PDF``. Returns a minimal
            valid PDF if ReportLab is not installed.
        """
        try:
            from reportlab.lib.pagesizes import A4
            from reportlab.lib.units import mm
            from reportlab.platypus import SimpleDocTemplate
        except ImportError:
            return _minimal_pdf()

        font, font_bd, font_sb, font_md = _register_fonts(self._style)
        styles = self._build_styles(font, font_bd, font_sb, font_md)
        ctx = self._build_ctx(font, font_bd, font_sb, font_md, styles)

        st = self._style
        buf = io.BytesIO()
        doc = SimpleDocTemplate(
            buf,
            pagesize=A4,
            topMargin=st.page_top_margin * mm,
            bottomMargin=st.page_bottom_margin * mm,
            leftMargin=st.page_left_margin * mm,
            rightMargin=st.page_right_margin * mm,
        )

        elements: list[Any] = []
        for section in sections:
            elements.extend(section.elements)

        if not elements:
            # Build a blank page when no content is provided
            from reportlab.platypus import Spacer
            elements = [Spacer(1, 1)]

        doc.build(elements)
        return buf.getvalue()

    def build_ctx(self) -> dict[str, Any]:
        """Build and return the context dict without producing a PDF.

        Useful for constructing sections with component helper functions
        before calling ``build()``.

        Returns an empty dict if ReportLab is not installed.
        """
        try:
            from reportlab.lib.pagesizes import A4  # noqa: F401
        except ImportError:
            return {}

        font, font_bd, font_sb, font_md = _register_fonts(self._style)
        styles = self._build_styles(font, font_bd, font_sb, font_md)
        return self._build_ctx(font, font_bd, font_sb, font_md, styles)


# ===================== CONVENIENCE BUILDER =====================


class ReportBuilder:
    """Fluent interface for constructing PDF reports section by section.

    Examples
    --------
    >>> builder = ReportBuilder(style=ReportStyle())
    >>> ctx = builder.ctx
    >>> builder.add_section("Header", report_header(ctx, "My Report", "Subtitle"))
    >>> pdf_bytes = builder.build()
    """

    def __init__(self, style: ReportStyle | None = None) -> None:
        self._report = PDFReport(style=style)
        self._sections: list[ReportSection] = []
        self._ctx: dict[str, Any] | None = None

    @property
    def ctx(self) -> dict[str, Any]:
        """ReportLab context dict for use with component helpers."""
        if self._ctx is None:
            self._ctx = self._report.build_ctx()
        return self._ctx

    def add_section(self, title: str, elements: list[Any]) -> ReportBuilder:
        """Append a section and return *self* for chaining.

        Parameters
        ----------
        title:
            Descriptive section name (not rendered into the PDF).
        elements:
            ReportLab flowable elements for this section.
        """
        self._sections.append(ReportSection(title=title, elements=elements))
        return self

    def build(self) -> bytes:
        """Finalise and return the PDF as bytes."""
        return self._report.build(self._sections)
