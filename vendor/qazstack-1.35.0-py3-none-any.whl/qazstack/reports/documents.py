"""Format-neutral document import warnings and export artifact models."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from qazstack.contracts._validation import (
    require_aware,
    require_identifier,
    require_positive,
    require_sha256,
    require_text,
)


@dataclass(frozen=True, slots=True)
class DocumentInput:
    document_id: str
    filename: str
    media_type: str
    size_bytes: int
    digest: str

    def __post_init__(self) -> None:
        require_identifier(self.document_id, "document_id")
        require_text(self.filename, "filename")
        if "/" in self.filename or "\\" in self.filename or "\x00" in self.filename:
            raise ValueError("filename must not contain path components")
        require_text(self.media_type, "media_type")
        require_positive(self.size_bytes, "size_bytes")
        object.__setattr__(self, "digest", require_sha256(self.digest))


@dataclass(frozen=True, slots=True)
class ParseWarning:
    code: str
    message: str
    location: str | None = None

    def __post_init__(self) -> None:
        require_identifier(self.code, "code")
        require_text(self.message, "message")


@dataclass(frozen=True, slots=True)
class ExportArtifact:
    artifact_id: str
    filename: str
    media_type: str
    size_bytes: int
    digest: str
    created_at: datetime
    warnings: tuple[ParseWarning, ...] = ()

    def __post_init__(self) -> None:
        require_identifier(self.artifact_id, "artifact_id")
        require_text(self.filename, "filename")
        require_text(self.media_type, "media_type")
        require_positive(self.size_bytes, "size_bytes")
        object.__setattr__(self, "digest", require_sha256(self.digest))
        require_aware(self.created_at, "created_at")
