"""Format-neutral provenance sidecar for generated exports."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from qazstack.contracts._validation import (
    require_aware,
    require_identifier,
    require_sha256,
    require_text,
)

EXPORT_PROVENANCE_SCHEMA_VERSION = "qazstack-export-provenance-v1"


@dataclass(frozen=True, slots=True)
class ExportProvenance:
    """Describe an export snapshot without coupling provenance to its renderer."""

    source_snapshot_id: str
    generated_at: datetime
    field_schema: tuple[str, ...]
    checksum: str
    evidence_refs: tuple[str, ...]
    schema_version: str = EXPORT_PROVENANCE_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.schema_version != EXPORT_PROVENANCE_SCHEMA_VERSION:
            raise ValueError(f"schema_version must be {EXPORT_PROVENANCE_SCHEMA_VERSION!r}")
        object.__setattr__(
            self,
            "source_snapshot_id",
            require_identifier(self.source_snapshot_id, "source_snapshot_id"),
        )
        require_aware(self.generated_at, "generated_at")
        if not self.field_schema:
            raise ValueError("field_schema must not be empty")
        fields = tuple(require_text(field, "field_schema item") for field in self.field_schema)
        if len(set(fields)) != len(fields):
            raise ValueError("field_schema must not contain duplicates")
        object.__setattr__(self, "field_schema", fields)
        object.__setattr__(self, "checksum", require_sha256(self.checksum, "checksum"))
        if not self.evidence_refs:
            raise ValueError("evidence_refs must not be empty")
        refs = tuple(require_text(ref, "evidence_refs item") for ref in self.evidence_refs)
        if len(set(refs)) != len(refs):
            raise ValueError("evidence_refs must not contain duplicates")
        object.__setattr__(self, "evidence_refs", refs)

    def as_dict(self) -> dict[str, Any]:
        generated_at = self.generated_at.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")
        return {
            "schema_version": self.schema_version,
            "source_snapshot_id": self.source_snapshot_id,
            "generated_at": generated_at,
            "field_schema": list(self.field_schema),
            "checksum": self.checksum,
            "evidence_refs": list(self.evidence_refs),
        }
