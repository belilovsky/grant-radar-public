"""CSV export helper.

Usage:
    from qazstack.export import csv_response

    @app.get("/api/export/csv")
    async def export_csv():
        headers = ["Name", "Score", "Date"]
        rows = [["Alice", "95", "2026-01-01"], ["Bob", "87", "2026-01-02"]]
        return csv_response(headers, rows, filename="report.csv")
"""

from __future__ import annotations

import csv
import io

from starlette.responses import StreamingResponse


def csv_response(
    headers: list[str],
    rows: list[list[str]],
    *,
    filename: str = "export.csv",
    encoding: str = "utf-8-sig",  # BOM for Excel compatibility
) -> StreamingResponse:
    """Generate a CSV file as a streaming download response."""
    buffer = io.StringIO()
    writer = csv.writer(buffer)
    writer.writerow(headers)
    writer.writerows(rows)

    content = buffer.getvalue().encode(encoding)
    return StreamingResponse(
        iter([content]),
        media_type="text/csv",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )
