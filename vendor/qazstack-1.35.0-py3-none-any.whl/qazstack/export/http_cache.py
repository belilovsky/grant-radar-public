"""HTTP cache helpers for machine-readable public exports.

The helpers keep ETag, Last-Modified and 304 handling consistent for JSON,
NDJSON and text feeds without taking ownership of a product's data model.
"""

from __future__ import annotations

import hashlib
import json
from datetime import date, datetime, time, timezone
from email.utils import format_datetime
from typing import Any, Iterable, Mapping

from fastapi import Request
from fastapi.responses import Response


def _as_http_datetime(value: Any) -> datetime | None:
    if isinstance(value, datetime):
        return value.astimezone(timezone.utc) if value.tzinfo else value.replace(tzinfo=timezone.utc)
    if isinstance(value, date):
        return datetime.combine(value, time.min, tzinfo=timezone.utc)
    return None


def cached_body_response(
    request: Request,
    *,
    body: str,
    media_type: str,
    last_modified: datetime | date | None = None,
    prefix: str = "qazstack-export",
    filename: str | None = None,
    version: str | None = None,
    cache_control: str = "public, max-age=300",
    version_header: str = "X-QazStack-Version",
) -> Response:
    """Return a body response or a matching ``304 Not Modified`` response."""
    digest = version or hashlib.sha1(body.encode("utf-8")).hexdigest()[:16]
    headers = {
        "ETag": f'W/"{prefix}-{digest}"',
        "Cache-Control": cache_control,
        version_header: digest,
    }
    normalized = _as_http_datetime(last_modified)
    if normalized is not None:
        headers["Last-Modified"] = format_datetime(normalized, usegmt=True)
    if filename:
        headers["Content-Disposition"] = f'inline; filename="{filename}"'
    if request.headers.get("if-none-match") == headers["ETag"]:
        return Response(status_code=304, media_type=media_type, headers=headers)
    return Response(content=body, media_type=media_type, headers=headers)


def ndjson_response(
    request: Request,
    rows: Iterable[Mapping[str, Any]],
    *,
    filename: str = "export.ndjson",
    last_modified: datetime | date | None = None,
    prefix: str = "qazstack-ndjson",
    version: str | None = None,
) -> Response:
    """Build a cache-aware NDJSON response from serializable mapping rows."""
    body = "".join(
        json.dumps(dict(row), ensure_ascii=False, separators=(",", ":"), default=str) + "\n"
        for row in rows
    )
    return cached_body_response(
        request,
        body=body,
        media_type="application/x-ndjson; charset=utf-8",
        last_modified=last_modified,
        prefix=prefix,
        filename=filename,
        version=version,
    )
