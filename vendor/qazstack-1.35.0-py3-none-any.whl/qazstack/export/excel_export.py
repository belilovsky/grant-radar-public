"""Excel export helper using openpyxl.

Usage:
    from qazstack.export import excel_response

    @app.get("/api/export/xlsx")
    async def export_excel():
        headers = ["Name", "Score"]
        rows = [["Alice", 95], ["Bob", 87]]
        return excel_response(headers, rows, filename="report.xlsx")
"""

from __future__ import annotations

import io

from starlette.responses import StreamingResponse


def excel_response(
    headers: list[str],
    rows: list[list],
    *,
    filename: str = "export.xlsx",
    sheet_name: str = "Data",
) -> StreamingResponse:
    """Generate an Excel file as a streaming download response.

    Requires openpyxl: pip install qazstack[export]
    """
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font
    except ImportError:
        raise ImportError("openpyxl is required for Excel export. Install with: pip install qazstack[export]")

    wb = Workbook()
    ws = wb.active
    ws.title = sheet_name

    # Header row (bold)
    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.font = Font(bold=True)

    # Data rows
    for row_idx, row_data in enumerate(rows, 2):
        for col_idx, value in enumerate(row_data, 1):
            ws.cell(row=row_idx, column=col_idx, value=value)

    # Auto-width columns
    for col in ws.columns:
        max_length = max(len(str(cell.value or "")) for cell in col)
        ws.column_dimensions[col[0].column_letter].width = min(max_length + 3, 50)

    buffer = io.BytesIO()
    wb.save(buffer)
    buffer.seek(0)

    return StreamingResponse(
        buffer,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )
