"""SQLAlchemy model for persistent event log.

Uses a separate DeclarativeBase (``EventLogBase``) to avoid
conflicts with project models. Stores events for audit, replay,
and cross-project debugging.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Optional

from sqlalchemy import (
    Column, DateTime, Float, Integer, String, Text, JSON,
    Index,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class EventLogBase(DeclarativeBase):
    """Separate declarative base for event log tables."""
    pass


class EventLogEntry(EventLogBase):
    """Persisted event from the Data Bus.

    Used for auditing, replay, and debugging cross-project flows.
    """

    __tablename__ = "event_log"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    event_id: Mapped[str] = mapped_column(String(32), nullable=False, unique=True)
    topic: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    source: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    priority: Mapped[str] = mapped_column(String(16), nullable=False, default="normal")
    payload: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)
    entity_id: Mapped[Optional[int]] = mapped_column(Integer, nullable=True, index=True)
    correlation_id: Mapped[Optional[str]] = mapped_column(String(64), nullable=True, index=True)
    handlers_invoked: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=lambda: datetime.now(timezone.utc),
    )

    __table_args__ = (
        Index("ix_event_log_topic_source", "topic", "source"),
        Index("ix_event_log_created", "created_at"),
    )

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "event_id": self.event_id,
            "topic": self.topic,
            "source": self.source,
            "priority": self.priority,
            "payload": self.payload,
            "entity_id": self.entity_id,
            "correlation_id": self.correlation_id,
            "handlers_invoked": self.handlers_invoked,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }
