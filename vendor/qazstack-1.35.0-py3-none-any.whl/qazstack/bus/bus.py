"""EventBus – in-process publish/subscribe with topic filtering.

Lightweight, async-first event bus. No external dependencies.
Supports:
- Topic-based subscriptions (exact match and wildcards)
- Decorator and method-based subscription
- Async and sync handlers (sync wrapped in executor)
- Event history (configurable ring buffer)
- Subscriber fault isolation (one handler failing doesn't break others)
- Middleware (pre/post processing)
"""

from __future__ import annotations

import asyncio
import inspect
import logging
from collections import defaultdict
from datetime import datetime, timezone
from typing import Any, Awaitable, Callable, Optional

from .event import Event

logger = logging.getLogger(__name__)

Handler = Callable[[Event], Any]


class EventBus:
    """In-process async event bus with topic filtering.

    Usage::

        bus = EventBus()

        # Decorator subscription
        @bus.on("entity.created")
        async def handler(event: Event):
            print(event.payload)

        # Method subscription
        bus.subscribe("entity.*", my_handler)

        # Publish
        await bus.emit(Event(topic="entity.created", source="echo-sounder"))
    """

    def __init__(self, history_size: int = 200) -> None:
        self._handlers: dict[str, list[Handler]] = defaultdict(list)
        self._history: list[Event] = []
        self._history_size = history_size
        self._middleware: list[Callable[[Event], Optional[Event]]] = []
        self._stats: dict[str, int] = defaultdict(int)

    # ── Subscribe ─────────────────────────────────────────────────

    def subscribe(self, pattern: str, handler: Handler) -> None:
        """Subscribe a handler to a topic pattern."""
        self._handlers[pattern].append(handler)
        logger.debug("Subscribed to '%s': %s", pattern, handler.__name__)

    def unsubscribe(self, pattern: str, handler: Handler) -> None:
        """Remove a handler from a topic pattern."""
        if pattern in self._handlers:
            self._handlers[pattern] = [
                h for h in self._handlers[pattern] if h is not handler
            ]

    def on(self, pattern: str) -> Callable:
        """Decorator for subscribing a handler."""
        def decorator(func: Handler) -> Handler:
            self.subscribe(pattern, func)
            return func
        return decorator

    # ── Middleware ─────────────────────────────────────────────────

    def use(self, middleware: Callable[[Event], Optional[Event]]) -> None:
        """Add middleware. Returns Event to continue, None to drop."""
        self._middleware.append(middleware)

    # ── Publish ───────────────────────────────────────────────────

    async def emit(self, event: Event) -> int:
        """Publish an event. Returns number of handlers invoked.

        Handlers are called concurrently. One failing handler
        doesn't prevent others from running.
        """
        # Run middleware
        for mw in self._middleware:
            result = mw(event)
            if result is None:
                logger.debug("Event %s dropped by middleware", event.event_id)
                return 0
            event = result

        # Find matching handlers
        handlers = self._find_handlers(event)

        if not handlers:
            logger.debug("No handlers for '%s'", event.topic)

        # Execute all handlers with fault isolation
        errors = 0
        for handler in handlers:
            try:
                if inspect.iscoroutinefunction(handler):
                    await handler(event)
                else:
                    handler(event)
            except Exception as e:
                errors += 1
                logger.error(
                    "Handler %s failed for event %s: %s",
                    handler.__name__, event.event_id, e,
                )

        # Record
        self._record(event)
        self._stats[event.topic] += 1

        count = len(handlers)
        if count > 0:
            logger.debug(
                "Event %s (%s): %d handlers, %d errors",
                event.event_id, event.topic, count, errors,
            )

        return count

    async def emit_many(self, events: list[Event]) -> int:
        """Emit multiple events. Returns total handlers invoked."""
        total = 0
        for event in events:
            total += await self.emit(event)
        return total

    # ── Query ─────────────────────────────────────────────────────

    def history(
        self,
        topic: Optional[str] = None,
        source: Optional[str] = None,
        limit: int = 50,
    ) -> list[Event]:
        """Query event history."""
        results = self._history
        if topic:
            results = [e for e in results if e.matches(topic)]
        if source:
            results = [e for e in results if e.source == source]
        return results[-limit:]

    @property
    def topics(self) -> list[str]:
        """All topics that have been emitted."""
        return sorted(self._stats.keys())

    @property
    def subscriber_count(self) -> int:
        """Total registered handlers."""
        return sum(len(hs) for hs in self._handlers.values())

    def stats(self) -> dict[str, Any]:
        """Bus statistics."""
        return {
            "subscriber_patterns": len(self._handlers),
            "total_handlers": self.subscriber_count,
            "topics_seen": len(self._stats),
            "event_counts": dict(self._stats),
            "history_size": len(self._history),
        }

    # ── Internal ──────────────────────────────────────────────────

    def _find_handlers(self, event: Event) -> list[Handler]:
        """Find all handlers matching an event's topic."""
        matched = []
        for pattern, handlers in self._handlers.items():
            if event.matches(pattern):
                matched.extend(handlers)
        return matched

    def _record(self, event: Event) -> None:
        """Add to history ring buffer."""
        self._history.append(event)
        if len(self._history) > self._history_size:
            self._history = self._history[-self._history_size:]
