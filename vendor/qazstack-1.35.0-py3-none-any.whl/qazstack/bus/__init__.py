"""QazStack Data Bus – event-driven communication between projects.

Provides a lightweight publish/subscribe event system for cross-project
data flow. Projects publish events when data changes; subscribers react
to events from other projects.

Components:

- **Event** – typed event with topic, payload, source project
- **EventBus** – in-process pub/sub with topic filtering
- **EventLog** – persistent event history (SQLAlchemy)
- **EventRouter** – FastAPI endpoints for HTTP-based event publishing

Event topics follow a convention::

    entity.created      – new entity in Entity Store
    entity.merged       – entities merged
    entity.mention      – new mention added
    collector.complete   – collector finished a run
    analysis.complete    – analytics pipeline finished
    analysis.alert       – analytics engine triggered alert
    monitor.alert        – monitoring alert fired

Quick start::

    from qazstack.bus import EventBus, Event

    bus = EventBus()

    # Subscribe
    @bus.on("entity.created")
    async def on_entity(event: Event):
        print(f"New entity: {event.payload['name']}")

    # Publish
    await bus.emit(Event(
        topic="entity.created",
        source="echo-sounder",
        payload={"name": "Токаев", "type": "PER", "entity_id": 42}
    ))
"""

from .event import Event, EventPriority
from .bus import EventBus
from .models import EventLogBase, EventLogEntry
from .router import bus_router

__all__ = [
    "Event",
    "EventPriority",
    "EventBus",
    "EventLogBase",
    "EventLogEntry",
    "bus_router",
]
