"""QazStack Cross-Project Dashboard – unified view across all projects.

Aggregates data from Entity Store, Analytics Pipeline, Data Bus, and
Monitor into a single dashboard API.

Components:

- **DashboardService** – aggregation logic
- **dashboard_router** – FastAPI endpoints for the dashboard UI

Quick start::

    from qazstack.dashboard import DashboardService, dashboard_router
    from qazstack.entities import EntityStore
    from qazstack.analytics import EngineRegistry
    from qazstack.bus import EventBus

    svc = DashboardService(
        entity_store=EntityStore(),
        engine_registry=registry,
        bus=bus,
    )
    app.include_router(dashboard_router(svc))
"""

from .service import DashboardService, DashboardSnapshot, ProjectSummary
from .router import dashboard_router

__all__ = [
    "DashboardService",
    "DashboardSnapshot",
    "ProjectSummary",
    "dashboard_router",
]
