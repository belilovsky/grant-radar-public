"""FastAPI router for the Cross-Project Dashboard.

Provides REST API endpoints for reading aggregated platform data.
"""

from typing import Any, Optional

from pydantic import BaseModel, Field

from .service import DashboardService


# --- Response models (module-level for FastAPI) ---

class EntitySummary(BaseModel):
    id: int
    name: str
    type: str
    mentions: int = 0


class ProjectInfo(BaseModel):
    name: str
    entity_count: int = 0
    mention_count: int = 0
    top_entities: list[dict[str, Any]] = Field(default_factory=list)


class EngineInfo(BaseModel):
    name: str
    version: str = ""
    description: str = ""
    category: str = ""


class SnapshotResponse(BaseModel):
    total_entities: int = 0
    total_mentions: int = 0
    total_relations: int = 0
    entities_by_type: dict[str, int] = Field(default_factory=dict)
    top_entities: list[EntitySummary] = Field(default_factory=list)
    projects: list[ProjectInfo] = Field(default_factory=list)
    registered_engines: list[EngineInfo] = Field(default_factory=list)
    engine_count: int = 0
    bus_topics: list[str] = Field(default_factory=list)
    bus_event_count: int = 0
    bus_subscriber_count: int = 0
    recent_events: list[dict[str, Any]] = Field(default_factory=list)


def dashboard_router(
    service: DashboardService,
    get_session=None,
    prefix: str = "/api/dashboard",
):
    """Create a FastAPI APIRouter for the Cross-Project Dashboard.

    Args:
        service: DashboardService instance
        get_session: Optional async dependency that yields an AsyncSession.
                     If None, entity data is omitted.
        prefix: URL prefix
    """
    from fastapi import APIRouter, Depends

    router = APIRouter(prefix=prefix, tags=["dashboard"])

    async def _get_session_dep():
        """No-op session if no session factory provided."""
        yield None

    session_dep = get_session or _get_session_dep

    @router.get("/snapshot", response_model=SnapshotResponse)
    async def get_snapshot(
        top: int = 10,
        events: int = 20,
        session=Depends(session_dep),
    ):
        """Full dashboard snapshot: entities, analytics, bus."""
        snap = await service.snapshot(
            session, top_limit=top, event_limit=events
        )
        return snap.to_dict()

    @router.get("/entities/top", response_model=list[EntitySummary])
    async def top_entities(
        limit: int = 20,
        entity_type: Optional[str] = None,
        session=Depends(session_dep),
    ):
        """Top entities by mention count."""
        if not service.entity_store or session is None:
            return []
        entities = await service.entity_store.top_entities(
            session, entity_type=entity_type, limit=limit
        )
        return [
            EntitySummary(
                id=e.id, name=e.name, type=e.entity_type,
                mentions=e.mention_count,
            )
            for e in entities
        ]

    @router.get("/entities/stats")
    async def entity_stats(session=Depends(session_dep)):
        """Entity store aggregate stats."""
        if not service.entity_store or session is None:
            return {}
        return await service.entity_store.stats(session)

    @router.get("/engines", response_model=list[EngineInfo])
    async def list_engines():
        """List registered analytics engines."""
        if not service.engine_registry:
            return []
        return [
            EngineInfo(
                name=e.name,
                version=getattr(e, "version", ""),
                description=getattr(e, "description", ""),
                category=getattr(e, "category", ""),
            )
            for e in service.engine_registry.all_engines
        ]

    @router.get("/bus/status")
    async def bus_status():
        """Data Bus status."""
        if not service.bus:
            return {}
        return service.bus.stats()

    @router.get("/bus/recent")
    async def bus_recent(limit: int = 20):
        """Recent bus events."""
        if not service.bus:
            return []
        events = service.bus.history(limit=limit)
        return [e.to_dict() for e in events]

    @router.get("/health")
    async def dashboard_health():
        """Quick health check: which subsystems are connected."""
        return {
            "entity_store": service.entity_store is not None,
            "analytics": service.engine_registry is not None,
            "bus": service.bus is not None,
        }

    return router
