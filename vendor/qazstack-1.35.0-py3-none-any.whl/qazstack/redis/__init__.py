"""Redis utilities with graceful degradation.

App never crashes if Redis is unavailable – all operations return None/False on failure.

Consolidated from: qazposter/redis_client.py, qazposter/services/cache.py

Usage::

    from qazstack.redis import GracefulRedis

    redis = GracefulRedis("redis://redis:6379")

    await redis.set("key", "value", ex=300)
    value = await redis.get("key")
    print(redis.available)  # True/False
"""

from qazstack.redis.client import GracefulRedis

__all__ = ["GracefulRedis"]
