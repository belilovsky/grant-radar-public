"""CLI module: project scaffolding and health checks."""
