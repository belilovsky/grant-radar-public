"""QazStack CLI – project scaffolding, audit, and platform checks.

Usage:
    qazstack new my-project          # Scaffold a new project
    qazstack check                   # Check current project compliance
    qazstack audit                   # Full platform audit (plugin-based)
    qazstack audit --category code   # Audit only code checks
    qazstack audit --fix             # Auto-fix where possible
    qazstack audit --json            # JSON output
    qazstack version                 # Show version
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from qazstack import __version__

SCAFFOLD_DIR = Path(__file__).parent.parent.parent.parent / "templates" / "scaffold"


def cli():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="qazstack",
        description="QazStack – modular toolkit for FastAPI projects",
    )
    parser.add_argument("--version", action="version", version=f"qazstack {__version__}")

    sub = parser.add_subparsers(dest="command")

    # qazstack new
    new_parser = sub.add_parser("new", help="Create a new project from template")
    new_parser.add_argument("name", help="Project name (lowercase, hyphens)")
    new_parser.add_argument("--port", type=int, default=8000, help="App port")
    new_parser.add_argument("--db", choices=["postgres", "sqlite", "none"], default="postgres")
    new_parser.add_argument("--accent", default="#1a365d", help="Brand accent color")

    # qazstack check
    sub.add_parser("check", help="Check project compliance with platform standard")

    # qazstack audit
    audit_parser = sub.add_parser("audit", help="Full platform audit (plugin-based)")
    audit_parser.add_argument("--category", "-c", help="Run only this category (code, infra, deps, ui_seo)")
    audit_parser.add_argument("--fix", action="store_true", help="Auto-fix issues where possible")
    audit_parser.add_argument("--json", action="store_true", dest="json_output", help="Output as JSON")
    audit_parser.add_argument("path", nargs="?", default=".", help="Project path (default: current dir)")

    # qazstack contract
    contract_parser = sub.add_parser("contract", help="Manage QazStack consumer contracts")
    contract_sub = contract_parser.add_subparsers(dest="contract_command", required=True)

    contract_init = contract_sub.add_parser("init", help="Create a consumer contract template")
    contract_init.add_argument("path", nargs="?", default="qazstack-consumer.json")
    contract_init.add_argument("--project-id", required=True)
    contract_init.add_argument("--product-name", required=True)
    contract_init.add_argument("--owner", required=True)
    contract_init.add_argument(
        "--lifecycle", choices=["planned", "pilot", "beta", "production", "archived"], default="production"
    )
    contract_init.add_argument(
        "--integration-mode",
        choices=[
            "python-package",
            "http-contract",
            "typescript-contract",
            "vendored-temporary",
            "vendored-release",
            "documented-only",
        ],
        default="http-contract",
    )
    contract_init.add_argument("--force", action="store_true")

    contract_validate = contract_sub.add_parser("validate", help="Validate a consumer contract")
    contract_validate.add_argument("path")
    contract_validate.add_argument("--strict", action="store_true", help="Require production runtime evidence")

    contract_diff = contract_sub.add_parser("diff", help="Compare a contract with this QazStack release")
    contract_diff.add_argument("path")

    contract_fetch = contract_sub.add_parser("fetch", help="Fetch and validate a public consumer contract")
    contract_fetch.add_argument("url")
    contract_fetch.add_argument("--strict", action="store_true")
    contract_fetch.add_argument("--timeout", type=float, default=10.0)

    contract_publish = contract_sub.add_parser("publish", help="Prepare an immutable publication bundle")
    contract_publish.add_argument("path")
    contract_publish.add_argument("--output", required=True)

    args = parser.parse_args()

    if args.command == "new":
        cmd_new(args)
    elif args.command == "check":
        cmd_check()
    elif args.command == "audit":
        cmd_audit(args)
    elif args.command == "contract":
        cmd_contract(args)
    else:
        parser.print_help()


def cmd_new(args):
    """Scaffold a new project."""
    project_dir = Path.cwd() / args.name
    if project_dir.exists():
        print(f"Error: directory '{args.name}' already exists")
        sys.exit(1)

    print(f"Creating project: {args.name}")

    # Create directory structure
    dirs = [
        "app/routers",
        "app/services",
        "static/css",
        "static/js",
        "static/img",
        "templates",
        "scripts",
        "nginx",
        "tests",
    ]
    for d in dirs:
        (project_dir / d).mkdir(parents=True, exist_ok=True)

    # Generate files
    _write(project_dir / "app" / "__init__.py", "")
    _write(project_dir / "app" / "routers" / "__init__.py", "")
    _write(project_dir / "app" / "services" / "__init__.py", "")

    _write(project_dir / "app" / "config.py", _config_py(args))
    _write(project_dir / "app" / "main.py", _main_py(args))
    _write(project_dir / "app" / "database.py", _database_py(args))
    _write(project_dir / "app" / "routers" / "pages.py", _pages_py(args))
    _write(project_dir / "app" / "routers" / "api.py", _api_py(args))

    _write(project_dir / "templates" / "base.html", _base_html(args))
    _write(project_dir / "templates" / "index.html", _index_html(args))
    _write(project_dir / "static" / "css" / "style.css", _style_css(args))

    _write(project_dir / "Dockerfile", _dockerfile(args))
    _write(project_dir / "docker-compose.yml", _docker_compose(args))
    _write(project_dir / "nginx" / "default.conf", _nginx_conf())
    _write(project_dir / ".env.example", _env_example(args))
    _write(project_dir / ".gitignore", _gitignore())
    _write(project_dir / "pyproject.toml", _pyproject(args))
    _write(project_dir / "README.md", f"# {args.name}\n\nBuilt with QazStack.\n")

    print(f"Project created at ./{args.name}")
    print(f"  cd {args.name}")
    print("  cp .env.example .env  # edit settings")
    print("  docker compose up --build")


def cmd_check():
    """Check current project for platform compliance."""
    cwd = Path.cwd()
    checks = {
        "pyproject.toml": (cwd / "pyproject.toml").exists(),
        "Dockerfile": (cwd / "Dockerfile").exists(),
        "docker-compose.yml": (cwd / "docker-compose.yml").exists(),
        ".env.example": (cwd / ".env.example").exists(),
        ".gitignore": (cwd / ".gitignore").exists(),
        "health endpoint": _check_health_endpoint(cwd),
        "HEALTHCHECK in Dockerfile": _check_dockerfile_health(cwd),
    }

    all_pass = True
    for name, passed in checks.items():
        icon = "✅" if passed else "❌"
        print(f"  {icon} {name}")
        if not passed:
            all_pass = False

    if all_pass:
        print("\nAll checks passed!")
    else:
        print("\nSome checks failed. Fix the issues above.")
        sys.exit(1)


def cmd_audit(args):
    """Run full platform audit."""
    from qazstack.audit import AuditRunner, CheckerRegistry

    project_path = Path(args.path).resolve()
    if not project_path.is_dir():
        print(f"Error: {args.path} is not a directory")
        sys.exit(1)

    registry = CheckerRegistry()
    registry.auto_discover()
    runner = AuditRunner(registry)

    categories = [args.category] if args.category else None

    # Run auto-fix first if requested
    if args.fix:
        fixes = runner.run_fix(project_path, categories=categories)
        if fixes:
            print("Auto-fixes applied:")
            for fix in fixes:
                print(f"  \u2714 {fix}")
            print()

    report = runner.run(project_path, categories=categories)

    if args.json_output:
        print(AuditRunner.format_json(report))
    else:
        print(AuditRunner.format_text(report))

    # Exit with error code if any errors found
    if report.errors:
        sys.exit(1)


def cmd_contract(args):
    """Manage consumer contracts without changing a remote registry."""
    from qazstack.contracts import (
        ConsumerContractClient,
        ConsumerContractError,
        compatibility_status,
        contract_template,
        load_consumer_contract,
        publication_bundle,
    )

    try:
        if args.contract_command == "init":
            path = Path(args.path).resolve()
            if path.exists() and not args.force:
                raise ConsumerContractError(f"refusing to overwrite existing file: {path}")
            payload = contract_template(
                args.project_id,
                args.product_name,
                owner=args.owner,
                qazstack_version=__version__,
                lifecycle=args.lifecycle,
                integration_mode=args.integration_mode,
            )
            _write_json(path, payload)
            print(f"created: {path}")
        elif args.contract_command == "validate":
            contract = load_consumer_contract(args.path, strict=args.strict)
            print(f"valid: {args.path} ({contract.project_id})")
        elif args.contract_command == "diff":
            contract = load_consumer_contract(args.path)
            status = compatibility_status(contract.qazstack_version, __version__)
            print(
                f"project={contract.project_id} contract={contract.qazstack_version} "
                f"current={__version__} status={status}"
            )
            if status in {"missing", "legacy", "incompatible"}:
                raise SystemExit(1)
        elif args.contract_command == "fetch":
            contract = ConsumerContractClient(timeout=args.timeout).fetch(args.url, strict=args.strict)
            print(json.dumps(contract.to_dict(), ensure_ascii=False, indent=2))
        elif args.contract_command == "publish":
            contract = load_consumer_contract(args.path, strict=True)
            output = Path(args.output).resolve()
            _write_json(output, publication_bundle(contract))
            print(f"prepared: {output}")
    except (OSError, json.JSONDecodeError, ConsumerContractError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc


def _write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def _check_health_endpoint(cwd: Path) -> bool:
    """Check if any Python file contains /health endpoint."""
    for py_file in cwd.rglob("*.py"):
        try:
            content = py_file.read_text()
            if "/health" in content:
                return True
        except Exception:
            pass
    return False


def _check_dockerfile_health(cwd: Path) -> bool:
    """Check if Dockerfile contains HEALTHCHECK."""
    dockerfile = cwd / "Dockerfile"
    if not dockerfile.exists():
        return False
    return "HEALTHCHECK" in dockerfile.read_text()


def _write(path: Path, content: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


# --- Template generators ---


def _config_py(args) -> str:
    name_title = args.name.replace("-", " ").title()
    database_url = (
        "postgresql+asyncpg://user:pass@db:5432/" + args.name.replace("-", "_") if args.db == "postgres" else ""
    )
    return f'''"""Application settings."""

from qazstack.core import BaseConfig


class Settings(BaseConfig):
    app_name: str = "{name_title}"
    version: str = "1.0.0"
    database_url: str = "{database_url}"

settings = Settings()
'''


def _main_py(args) -> str:
    return f'''"""{args.name} – FastAPI application."""

from pathlib import Path
from qazstack.core import create_app, Database
from app.config import settings

BASE = Path(__file__).parent.parent

db = Database(settings.database_url) if settings.database_url else None

app = create_app(
    settings,
    static_dir=BASE / "static",
    templates_dir=BASE / "templates",
    database=db,
)

from app.routers import pages, api  # noqa: E402
app.include_router(pages.router)
app.include_router(api.router)
'''


def _database_py(args) -> str:
    return '''"""Database models."""

from qazstack.core.database import Base
from sqlalchemy import Column, Integer, String, DateTime, func


# Define your models here:
# class MyModel(Base):
#     __tablename__ = "my_table"
#     id = Column(Integer, primary_key=True)
#     name = Column(String, nullable=False)
#     created_at = Column(DateTime, server_default=func.now())
'''


def _pages_py(args) -> str:
    return '''"""SSR page routes."""

from fastapi import APIRouter, Request

router = APIRouter(tags=["pages"])


@router.get("/")
async def index(request: Request):
    templates = request.app.state.templates
    return templates.TemplateResponse(request, "index.html")
'''


def _api_py(args) -> str:
    return '''"""API routes."""

from fastapi import APIRouter

router = APIRouter(prefix="/api", tags=["api"])


@router.get("/info")
async def info():
    from app.config import settings
    return {"name": settings.app_name, "version": settings.version}
'''


def _base_html(args) -> str:
    name_title = args.name.replace("-", " ").title()
    return f"""<!DOCTYPE html>
<html lang="ru" data-theme="light">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{% block title %}}{name_title}{{% endblock %}}</title>
    <meta name="description" content="{{% block meta_description %}}{{% endblock %}}">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/static/css/style.css">
    {{% block head %}}{{% endblock %}}
</head>
<body>
    <header class="site-header">
        <div class="container header-inner">
            <a href="/" class="logo">{name_title}</a>
            <nav class="main-nav">
                {{% block nav %}}{{% endblock %}}
            </nav>
        </div>
    </header>

    <main>
        <div class="container">
            {{% block content %}}{{% endblock %}}
        </div>
    </main>

    <footer class="site-footer">
        <div class="container footer-inner">
            <p>&copy; {{{{ year }}}} {name_title}</p>
        </div>
    </footer>
    {{% block scripts %}}{{% endblock %}}
</body>
</html>
"""


def _index_html(args) -> str:
    name_title = args.name.replace("-", " ").title()
    return f"""{{% extends "base.html" %}}
{{% block title %}}{name_title}{{% endblock %}}
{{% block content %}}
<h1>{name_title}</h1>
<p>Built with QazStack.</p>
{{% endblock %}}
"""


def _style_css(args) -> str:
    return f"""/* {args.name} – styles */
:root {{
    --bg: #f0f2f5;
    --surface: #ffffff;
    --text: #1a1a2e;
    --text-secondary: #4a5568;
    --text-muted: #718096;
    --accent: {args.accent};
    --accent-hover: color-mix(in srgb, {args.accent} 80%, black);
    --border: #e2e8f0;
    --border-light: #edf2f7;
    --shadow-sm: 0 1px 3px rgba(0,0,0,0.06);
    --shadow-md: 0 4px 12px rgba(0,0,0,0.08);
    --shadow-lg: 0 8px 30px rgba(0,0,0,0.12);
    --radius-sm: 6px;
    --radius: 10px;
    --radius-lg: 14px;
    --transition: 0.2s ease;
    --success: #38a169;
    --warning: #d69e2e;
    --danger: #e53e3e;
}}

[data-theme="dark"] {{
    --bg: #0f1117;
    --surface: #1a1d27;
    --text: #e4e5e7;
    --text-secondary: #a1a3a8;
    --text-muted: #6c6f77;
    --border: #2a2d37;
    --shadow-sm: 0 1px 2px rgba(0,0,0,0.3);
    --shadow-md: 0 4px 12px rgba(0,0,0,0.4);
    --shadow-lg: 0 8px 30px rgba(0,0,0,0.5);
}}

*, *::before, *::after {{ box-sizing: border-box; }}
body {{
    margin: 0;
    font-family: "Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    background: var(--bg);
    color: var(--text);
    line-height: 1.6;
}}

.container {{
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 24px;
}}

.site-header {{
    background: var(--surface);
    border-bottom: 1px solid var(--border);
    padding: 0 0;
    position: sticky;
    top: 0;
    z-index: 100;
}}

.header-inner {{
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 60px;
}}

.logo {{
    font-weight: 700;
    font-size: 1.2rem;
    color: var(--accent);
    text-decoration: none;
}}

.site-footer {{
    background: var(--surface);
    border-top: 1px solid var(--border);
    padding: 24px 0;
    margin-top: 60px;
    color: var(--text-muted);
    font-size: 0.875rem;
}}
"""


def _dockerfile(args) -> str:
    return """FROM python:3.12-slim

WORKDIR /app

RUN apt-get update && apt-get install -y --no-install-recommends \\
    libpq5 curl && \\
    rm -rf /var/lib/apt/lists/*

COPY pyproject.toml .
COPY app/ app/
RUN pip install --no-cache-dir .

COPY . .

EXPOSE 8000

HEALTHCHECK --interval=30s --timeout=10s --start-period=15s --retries=3 \\
    CMD curl -f http://localhost:8000/health || exit 1

CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000", "--workers", "2"]
"""


def _docker_compose(args) -> str:
    project = args.name.replace("-", "_")
    compose = f"""services:
  app:
    build: .
    container_name: {project}_app
    restart: unless-stopped
    env_file: .env
    ports:
      - "${{APP_PORT:-8000}}:8000"
"""
    if args.db == "postgres":
        compose += f"""    depends_on:
      db:
        condition: service_healthy
    networks:
      - app_net

  db:
    image: pgvector/pgvector:pg16
    container_name: {project}_db
    restart: unless-stopped
    environment:
      POSTGRES_DB: ${{DB_NAME:-{project}}}
      POSTGRES_USER: ${{DB_USER:-{project}}}
      POSTGRES_PASSWORD: ${{DB_PASSWORD:?DB_PASSWORD required}}
    ports:
      - "127.0.0.1:${{DB_PORT:-5432}}:5432"
    volumes:
      - pgdata:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U ${{DB_USER:-{project}}}"]
      interval: 10s
      timeout: 5s
      retries: 5
    networks:
      - app_net

volumes:
  pgdata:
    name: {project}_pgdata

networks:
  app_net:
    name: {project}_net
    driver: bridge
"""
    else:
        compose += f"""    networks:
      - app_net

networks:
  app_net:
    name: {project}_net
    driver: bridge
"""
    return compose


def _nginx_conf() -> str:
    return """server {
    listen 80;
    server_name _;
    client_max_body_size 10M;

    location /static/ {
        alias /usr/share/nginx/static/;
        expires 7d;
        add_header Cache-Control "public, immutable";
    }

    location / {
        proxy_pass http://app:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location /nginx-health {
        return 200 "ok";
        add_header Content-Type text/plain;
    }
}
"""


def _env_example(args) -> str:
    project = args.name.replace("-", "_")
    env = f"""# === Application ===
APP_NAME={args.name.replace("-", " ").title()}
APP_PORT=8000
DEBUG=false
SECRET_KEY=change-me-in-production
"""
    if args.db == "postgres":
        env += f"""
# === Database ===
DB_NAME={project}
DB_USER={project}
DB_PASSWORD=
DB_PORT=5432
DATABASE_URL=postgresql+asyncpg://{project}:{project}@db:5432/{project}
"""
    return env


def _gitignore() -> str:
    return """__pycache__/
*.pyc
.env
*.egg-info/
dist/
build/
.venv/
venv/
node_modules/
.DS_Store
*.db
*.sqlite3
"""


def _pyproject(args) -> str:
    return f'''[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "{args.name}"
version = "1.0.0"
requires-python = ">=3.11"
dependencies = [
    "qazstack>=0.1.0",
]

[tool.hatch.build.targets.wheel]
packages = ["app"]

[tool.ruff]
line-length = 120
target-version = "py312"
'''
