"""CRUD module: generic async CRUD operations for SQLAlchemy models.

Inspired by fastcrud (benavlabs/fastcrud). Provides a reusable base class
for standard Create/Read/Update/Delete + List with filtering and pagination.

Usage:
    from qazstack.crud import CRUDBase

    class ArticleCRUD(CRUDBase[Article, ArticleCreate, ArticleUpdate]):
        pass

    articles = ArticleCRUD(Article)

    # In routes:
    item = await articles.get(session, id=1)
    items = await articles.get_multi(session, page=1, per_page=20)
    new = await articles.create(session, obj_in=ArticleCreate(...))
    updated = await articles.update(session, id=1, obj_in=ArticleUpdate(...))
    await articles.delete(session, id=1)
"""

from qazstack.crud.base import CRUDBase

__all__ = ["CRUDBase"]
