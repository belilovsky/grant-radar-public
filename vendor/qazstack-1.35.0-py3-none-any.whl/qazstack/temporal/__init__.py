"""Shared temporal contracts and deterministic release helpers."""

from qazstack.temporal.contracts import (
    TEMPORAL_EVENT_BATCH_CONTRACT,
    TEMPORAL_SERIES_CONTRACT,
    TEMPORAL_SNAPSHOT_DIFF_CONTRACT,
    EventBatchQuality,
    MetricDefinition,
    SeriesPoint,
    SeriesSummary,
    SnapshotValueChange,
    TemporalEvent,
    TemporalEventBatch,
    TemporalQuality,
    TemporalSeries,
    TemporalSnapshotDiff,
)
from qazstack.temporal.events import (
    build_event_batch,
    deduplicate_events,
    event_content_hash,
    event_identity,
    normalize_event_title,
    normalize_event_url,
    titles_are_near_duplicates,
)
from qazstack.temporal.series import diff_snapshots, normalize_series_points, summarize_series

__all__ = [
    "TEMPORAL_EVENT_BATCH_CONTRACT",
    "TEMPORAL_SERIES_CONTRACT",
    "TEMPORAL_SNAPSHOT_DIFF_CONTRACT",
    "EventBatchQuality",
    "MetricDefinition",
    "SeriesPoint",
    "SeriesSummary",
    "SnapshotValueChange",
    "TemporalEvent",
    "TemporalEventBatch",
    "TemporalQuality",
    "TemporalSeries",
    "TemporalSnapshotDiff",
    "build_event_batch",
    "deduplicate_events",
    "diff_snapshots",
    "event_content_hash",
    "event_identity",
    "normalize_event_title",
    "normalize_event_url",
    "normalize_series_points",
    "summarize_series",
    "titles_are_near_duplicates",
]
