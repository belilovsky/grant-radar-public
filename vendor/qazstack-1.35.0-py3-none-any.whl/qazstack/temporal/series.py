"""Deterministic helpers for time-series and snapshot comparisons."""

from __future__ import annotations

from datetime import date
from math import isfinite
from typing import Mapping, Sequence

from qazstack.temporal.contracts import (
    SeriesPoint,
    SeriesSummary,
    SnapshotValueChange,
    TemporalSnapshotDiff,
)


def _round(value: float | None, precision: int) -> float | None:
    if value is None:
        return None
    rounded = round(value, precision)
    return 0.0 if rounded == 0 else rounded


def _direction(delta: float | None, *, flat_tolerance: float) -> str:
    if delta is None:
        return "unknown"
    if abs(delta) <= flat_tolerance:
        return "flat"
    return "up" if delta > 0 else "down"


def normalize_series_points(points: Sequence[SeriesPoint | Mapping[str, object]]) -> list[SeriesPoint]:
    """Validate, sort and reject duplicate or non-finite observations."""
    normalized = [point if isinstance(point, SeriesPoint) else SeriesPoint.model_validate(point) for point in points]
    normalized.sort(key=lambda point: point.date)
    dates = [point.date for point in normalized]
    if len(dates) != len(set(dates)):
        raise ValueError("series points must not contain duplicate dates")
    if any(not isfinite(point.value) for point in normalized):
        raise ValueError("series values must be finite")
    return normalized


def summarize_series(
    points: Sequence[SeriesPoint | Mapping[str, object]],
    *,
    precision: int = 4,
    flat_tolerance: float = 0.0,
) -> SeriesSummary:
    """Derive a stable first-to-latest summary without forecasting."""
    normalized = normalize_series_points(points)
    if not normalized:
        return SeriesSummary(points=0)
    values = [point.value for point in normalized]
    first = values[0]
    latest = values[-1]
    delta = latest - first
    delta_pct = None if first == 0 else delta / abs(first) * 100
    return SeriesSummary(
        points=len(values),
        first=_round(first, precision),
        latest=_round(latest, precision),
        minimum=_round(min(values), precision),
        maximum=_round(max(values), precision),
        delta=_round(delta, precision),
        delta_pct=_round(delta_pct, precision),
        direction=_direction(delta, flat_tolerance=flat_tolerance),
    )


def diff_snapshots(
    previous: Mapping[str, int | float | None],
    current: Mapping[str, int | float | None],
    *,
    previous_date: date,
    current_date: date,
    precision: int = 4,
    flat_tolerance: float = 0.0,
) -> TemporalSnapshotDiff:
    """Compare scalar snapshots in stable key order."""
    changes: list[SnapshotValueChange] = []
    for key in sorted(set(previous) | set(current)):
        previous_value = previous.get(key)
        current_value = current.get(key)
        if previous_value is not None and not isfinite(float(previous_value)):
            raise ValueError(f"previous snapshot contains a non-finite value for {key}")
        if current_value is not None and not isfinite(float(current_value)):
            raise ValueError(f"current snapshot contains a non-finite value for {key}")
        previous_float = float(previous_value) if previous_value is not None else None
        current_float = float(current_value) if current_value is not None else None
        delta = None if previous_float is None or current_float is None else current_float - previous_float
        delta_pct = None
        if delta is not None and previous_float != 0:
            delta_pct = delta / abs(previous_float) * 100
        changes.append(
            SnapshotValueChange(
                key=key,
                previous=_round(previous_float, precision),
                current=_round(current_float, precision),
                delta=_round(delta, precision),
                delta_pct=_round(delta_pct, precision),
                direction=_direction(delta, flat_tolerance=flat_tolerance),
            )
        )
    return TemporalSnapshotDiff(
        previous_date=previous_date,
        current_date=current_date,
        changes=changes,
    )
