"""Versioned contracts for public temporal data and event releases."""

from __future__ import annotations

from datetime import date, datetime, timezone
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

TEMPORAL_SERIES_CONTRACT = "qazstack-temporal-series-v1"
TEMPORAL_EVENT_BATCH_CONTRACT = "qazstack-temporal-event-batch-v1"
TEMPORAL_SNAPSHOT_DIFF_CONTRACT = "qazstack-temporal-snapshot-diff-v1"

Granularity = Literal["hour", "day", "week", "month", "quarter", "year", "irregular"]
Direction = Literal["up", "down", "flat", "unknown"]
QualityTier = Literal["authoritative", "verified", "estimated", "degraded", "unknown"]
QualityStatus = Literal["healthy", "warning", "critical", "unknown"]
GeographyStatus = Literal["exact", "inferred", "country", "unknown"]
Severity = Literal["low", "medium", "high", "critical", "unknown"]


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


class TemporalQuality(BaseModel):
    """Bounded quality and provenance metadata for a public temporal artifact."""

    model_config = ConfigDict(extra="forbid")

    status: QualityStatus = "unknown"
    quality_tier: QualityTier = "unknown"
    measured_at: datetime = Field(default_factory=utc_now)
    checks: dict[str, bool] = Field(default_factory=dict)
    notes: list[str] = Field(default_factory=list, max_length=20)


class MetricDefinition(BaseModel):
    """Stable identity and display metadata for one temporal metric."""

    model_config = ConfigDict(extra="forbid")

    metric_id: str = Field(min_length=1, max_length=128, pattern=r"^[a-z0-9][a-z0-9._-]*$")
    label: str = Field(min_length=1, max_length=240)
    unit: str = Field(min_length=1, max_length=64)
    source_id: str = Field(min_length=1, max_length=128)
    source_url: str | None = Field(default=None, max_length=2048)
    public: bool = True
    dimensions: dict[str, str] = Field(default_factory=dict)


class SeriesPoint(BaseModel):
    """One dated numeric observation."""

    model_config = ConfigDict(extra="forbid")

    date: date
    value: float
    quality_tier: QualityTier | None = None
    attributes: dict[str, str | int | float | bool | None] = Field(default_factory=dict)


class SeriesSummary(BaseModel):
    """Deterministic summary derived from ordered series points."""

    model_config = ConfigDict(extra="forbid")

    points: int = Field(ge=0)
    first: float | None = None
    latest: float | None = None
    minimum: float | None = None
    maximum: float | None = None
    delta: float | None = None
    delta_pct: float | None = None
    direction: Direction = "unknown"


class TemporalSeries(BaseModel):
    """Portable public series contract shared by products and QazCompute."""

    model_config = ConfigDict(extra="forbid")

    schema_version: Literal["qazstack-temporal-series-v1"] = TEMPORAL_SERIES_CONTRACT
    metric: MetricDefinition
    granularity: Granularity
    effective_date: date
    source_revision: str = Field(min_length=1, max_length=256)
    points: list[SeriesPoint]
    summary: SeriesSummary
    quality: TemporalQuality = Field(default_factory=TemporalQuality)

    @model_validator(mode="after")
    def validate_points(self) -> TemporalSeries:
        dates = [point.date for point in self.points]
        if dates != sorted(dates):
            raise ValueError("series points must be sorted by date")
        if len(dates) != len(set(dates)):
            raise ValueError("series points must not contain duplicate dates")
        if self.summary.points != len(self.points):
            raise ValueError("summary.points must match the number of series points")
        if self.points and self.effective_date < self.points[-1].date:
            raise ValueError("effective_date must not precede the latest series point")
        return self


class TemporalEvent(BaseModel):
    """Public event with explicit source, geography and enrichment provenance."""

    model_config = ConfigDict(extra="forbid")

    event_id: str = Field(min_length=1, max_length=256)
    title: str = Field(min_length=1, max_length=1000)
    event_type: str = Field(default="event", min_length=1, max_length=128)
    event_date: datetime
    source: str = Field(min_length=1, max_length=256)
    source_url: str | None = Field(default=None, max_length=2048)
    country_code: str = Field(default="KZ", min_length=2, max_length=3)
    severity: Severity = "unknown"
    relevance_score: float | None = Field(default=None, ge=0.0, le=1.0)
    geography_status: GeographyStatus = "unknown"
    region_code: str | None = Field(default=None, max_length=32)
    region_label: str | None = Field(default=None, max_length=256)
    latitude: float | None = Field(default=None, ge=-90.0, le=90.0)
    longitude: float | None = Field(default=None, ge=-180.0, le=180.0)
    language: str | None = Field(default=None, min_length=2, max_length=16)
    content_hash: str | None = Field(default=None, pattern=r"^sha256:[a-f0-9]{64}$")
    entities: list[str] = Field(default_factory=list)
    attributes: dict[str, str | int | float | bool | None] = Field(default_factory=dict)

    @field_validator("country_code")
    @classmethod
    def normalize_country_code(cls, value: str) -> str:
        return value.upper()

    @model_validator(mode="after")
    def validate_geography(self) -> TemporalEvent:
        has_latitude = self.latitude is not None
        has_longitude = self.longitude is not None
        if has_latitude != has_longitude:
            raise ValueError("latitude and longitude must be provided together")
        if self.geography_status in {"exact", "inferred"} and not has_latitude:
            raise ValueError(f"{self.geography_status} geography requires coordinates")
        if self.geography_status == "country" and has_latitude:
            raise ValueError("country-level events must not use a synthetic centroid")
        return self


class EventBatchQuality(BaseModel):
    """Counts produced by deterministic filtering and deduplication."""

    model_config = ConfigDict(extra="forbid")

    raw: int = Field(ge=0)
    kept: int = Field(ge=0)
    duplicates: int = Field(default=0, ge=0)
    rejected: int = Field(default=0, ge=0)

    @model_validator(mode="after")
    def validate_counts(self) -> EventBatchQuality:
        if self.kept + self.duplicates + self.rejected != self.raw:
            raise ValueError("event quality counts must add up to raw")
        return self


class TemporalEventBatch(BaseModel):
    """Versioned release envelope for curated public events."""

    model_config = ConfigDict(extra="forbid")

    schema_version: Literal["qazstack-temporal-event-batch-v1"] = TEMPORAL_EVENT_BATCH_CONTRACT
    effective_date: date
    source_revision: str = Field(min_length=1, max_length=256)
    events: list[TemporalEvent]
    quality: EventBatchQuality
    generated_at: datetime = Field(default_factory=utc_now)

    @model_validator(mode="after")
    def validate_batch(self) -> TemporalEventBatch:
        if self.quality.kept != len(self.events):
            raise ValueError("quality.kept must match the number of events")
        event_ids = [event.event_id for event in self.events]
        if len(event_ids) != len(set(event_ids)):
            raise ValueError("event ids must be unique within a release")
        return self


class SnapshotValueChange(BaseModel):
    """One comparable scalar change between two snapshots."""

    model_config = ConfigDict(extra="forbid")

    key: str = Field(min_length=1, max_length=256)
    previous: float | None = None
    current: float | None = None
    delta: float | None = None
    delta_pct: float | None = None
    direction: Direction = "unknown"


class TemporalSnapshotDiff(BaseModel):
    """Stable, deterministic change feed between two dated snapshots."""

    model_config = ConfigDict(extra="forbid")

    schema_version: Literal["qazstack-temporal-snapshot-diff-v1"] = TEMPORAL_SNAPSHOT_DIFF_CONTRACT
    previous_date: date
    current_date: date
    changes: list[SnapshotValueChange]
    generated_at: datetime = Field(default_factory=utc_now)

    @model_validator(mode="after")
    def validate_dates(self) -> TemporalSnapshotDiff:
        if self.current_date < self.previous_date:
            raise ValueError("current_date must not precede previous_date")
        return self
