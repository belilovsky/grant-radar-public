"""Backend-neutral request limiting policy and decision models."""

from __future__ import annotations

from dataclasses import dataclass

from qazstack.contracts._validation import require_identifier, require_one_of, require_positive


@dataclass(frozen=True, slots=True)
class RateLimitPolicy:
    policy_id: str
    requests: int
    window_seconds: int
    key_scope: str = "ip"
    trust_forwarded_headers: bool = False
    fail_mode: str = "closed"

    def __post_init__(self) -> None:
        require_identifier(self.policy_id, "policy_id")
        require_positive(self.requests, "requests")
        require_positive(self.window_seconds, "window_seconds")
        require_one_of(self.key_scope, frozenset({"ip", "user", "session", "api_key"}), "key_scope")
        require_one_of(self.fail_mode, frozenset({"open", "closed"}), "fail_mode")


@dataclass(frozen=True, slots=True)
class RateLimitDecision:
    allowed: bool
    limit: int
    remaining: int
    reset_after_seconds: int
    retry_after_seconds: int | None = None

    def __post_init__(self) -> None:
        require_positive(self.limit, "limit")
        require_positive(self.remaining, "remaining", allow_zero=True)
        require_positive(self.reset_after_seconds, "reset_after_seconds", allow_zero=True)
        if self.remaining > self.limit:
            raise ValueError("remaining cannot exceed limit")
        if self.allowed and self.retry_after_seconds is not None:
            raise ValueError("allowed decisions cannot include Retry-After")
        if not self.allowed:
            if self.retry_after_seconds is None:
                raise ValueError("denied decisions require Retry-After")
            require_positive(self.retry_after_seconds, "retry_after_seconds")

    def headers(self) -> dict[str, str]:
        headers = {
            "RateLimit-Limit": str(self.limit),
            "RateLimit-Remaining": str(self.remaining),
            "RateLimit-Reset": str(self.reset_after_seconds),
        }
        if self.retry_after_seconds is not None:
            headers["Retry-After"] = str(self.retry_after_seconds)
        return headers
