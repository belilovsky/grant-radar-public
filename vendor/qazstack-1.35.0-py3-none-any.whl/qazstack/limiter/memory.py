"""In-memory rate limiter for FastAPI.

Uses a simple sliding-window counter per IP address.
Suitable for single-worker deployments.
For multi-worker production, use Redis-backed fastapi-limiter.

Inspired by AliYmn/fastapi-throttle and long2ice/fastapi-limiter.
"""

import ipaddress
import time
from collections import defaultdict
from typing import Any, Iterable

from fastapi import FastAPI, HTTPException, Request, status
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response


class RateLimiter:
    """Per-IP rate limiter as a FastAPI dependency.

    Usage:
        limiter = RateLimiter(times=5, seconds=60)  # 5 requests per minute

        @router.get("/endpoint", dependencies=[Depends(limiter)])
        async def endpoint():
            ...
    """

    def __init__(
        self,
        times: int = 10,
        seconds: int = 60,
        *,
        add_headers: bool = True,
        trusted_proxies: Iterable[str] | None = None,
    ):
        self.times = times
        self.seconds = seconds
        self.add_headers = add_headers
        self._requests: dict[str, list[float]] = defaultdict(list)
        self._trusted_proxies = tuple(
            ipaddress.ip_network(proxy.strip()) for proxy in (trusted_proxies or ("127.0.0.1", "::1")) if proxy.strip()
        )

    @staticmethod
    def _valid_ip(value: str | None) -> str | None:
        if not value:
            return None
        try:
            return str(ipaddress.ip_address(value.strip()))
        except ValueError:
            return None

    def _peer_ip(self, request: Request) -> str:
        return self._valid_ip(request.client.host if request.client else None) or "unknown"

    def _is_trusted_proxy(self, peer: str) -> bool:
        try:
            peer_ip = ipaddress.ip_address(peer)
        except ValueError:
            return False
        return any(peer_ip in network for network in self._trusted_proxies)

    def _client_ip(self, request: Request) -> str:
        """Extract a client IP without trusting headers from direct clients."""
        peer = self._peer_ip(request)
        if not self._is_trusted_proxy(peer):
            return peer

        real_ip = self._valid_ip(request.headers.get("X-Real-IP"))
        if real_ip:
            return real_ip

        forwarded = request.headers.get("X-Forwarded-For")
        if forwarded:
            for candidate in reversed(forwarded.split(",")):
                client_ip = self._valid_ip(candidate)
                if client_ip:
                    return client_ip
        return peer

    def _cleanup(self, now: float) -> None:
        """Remove expired entries for every tracked client."""
        cutoff = now - self.seconds
        for key in list(self._requests):
            active = [timestamp for timestamp in self._requests[key] if timestamp > cutoff]
            if active:
                self._requests[key] = active
            else:
                del self._requests[key]

    async def __call__(self, request: Request) -> None:
        """FastAPI dependency – check rate limit."""
        now = time.time()
        key = self._client_ip(request)
        self._cleanup(now)

        if len(self._requests[key]) >= self.times:
            retry_after = int(self.seconds - (now - self._requests[key][0]))
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail=f"Rate limit exceeded. Retry after {max(1, retry_after)} seconds.",
                headers={"Retry-After": str(max(1, retry_after))},
            )

        self._requests[key].append(now)


class _RateLimitMiddleware(BaseHTTPMiddleware):
    """Global rate limiting middleware."""

    def __init__(
        self,
        app: Any,
        times: int = 30,
        seconds: int = 60,
        trusted_proxies: Iterable[str] | None = None,
    ):
        super().__init__(app)
        self._limiter = RateLimiter(
            times=times,
            seconds=seconds,
            trusted_proxies=trusted_proxies,
        )

    async def dispatch(self, request: Request, call_next) -> Response:
        # Skip health checks and static
        path = request.url.path
        if path in ("/health", "/favicon.ico") or path.startswith("/static/"):
            return await call_next(request)

        try:
            await self._limiter(request)
        except HTTPException as e:
            return Response(
                content=e.detail,
                status_code=e.status_code,
                headers=e.headers or {},
            )

        return await call_next(request)


def setup_limiter(
    app: FastAPI,
    *,
    times: int = 30,
    seconds: int = 60,
    trusted_proxies: Iterable[str] | None = None,
) -> None:
    """Add global rate limiting middleware to the app.

    Args:
        app: FastAPI application.
        times: Max requests per window.
        seconds: Window duration in seconds.
        trusted_proxies: Proxy IPs or CIDRs allowed to provide forwarding headers.

    Example:
        setup_limiter(app, times=30, seconds=60)  # 30 req/min globally
    """
    app.add_middleware(
        _RateLimitMiddleware,
        times=times,
        seconds=seconds,
        trusted_proxies=trusted_proxies,
    )
