"""Rate limiting module for FastAPI.

In-memory rate limiter (no Redis required). For production with multiple
workers, use Redis-backed fastapi-limiter instead.

Usage:
    from qazstack.limiter import RateLimiter, setup_limiter

    limiter = RateLimiter(times=10, seconds=60)  # 10 req/min

    @router.get("/api/search", dependencies=[Depends(limiter)])
    async def search():
        ...

    # Or global middleware:
    setup_limiter(app, times=30, seconds=60)
"""

from qazstack.limiter.memory import RateLimiter, setup_limiter
from qazstack.limiter.policy import RateLimitDecision, RateLimitPolicy

__all__ = ["RateLimitDecision", "RateLimitPolicy", "RateLimiter", "setup_limiter"]
