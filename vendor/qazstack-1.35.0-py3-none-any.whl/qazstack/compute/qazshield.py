"""Async authenticated client for the QazShield anonymization service.

The client keeps a process-local JWT cache, serializes token refreshes and
retries one anonymization request after a 401. It deliberately never logs API
keys, JWTs or source text.
"""

from __future__ import annotations

import asyncio
import os
import time
from collections.abc import Mapping
from typing import Any

import httpx


class QazShieldError(RuntimeError):
    """Base error raised by the QazShield client."""


class QazShieldUnavailable(QazShieldError):
    """QazShield could not issue a token or answer the request safely."""


class QazShieldClient:
    """Async QazShield adapter with bounded authentication recovery.

    ``anonymize`` raises :class:`QazShieldUnavailable` for network and token
    failures. ``try_anonymize`` is available for products that explicitly
    choose a fail-closed ``None`` fallback.
    """

    def __init__(
        self,
        *,
        base_url: str | None = None,
        api_key: str | None = None,
        role: str = "analyst",
        timeout: float = 20.0,
        token_refresh_margin_seconds: float = 60.0,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        self.base_url = (base_url or os.getenv("QAZSHIELD_URL", "http://qazshield:8000")).rstrip("/")
        self.api_key = api_key if api_key is not None else os.getenv("QAZSHIELD_KEY", "")
        self.role = role.strip() or "analyst"
        self.timeout = max(0.1, float(timeout))
        self.token_refresh_margin_seconds = max(0.0, float(token_refresh_margin_seconds))
        self._client = client
        self._owns_client = client is None
        self._token: str | None = None
        self._token_expires_at = 0.0
        self._refresh_lock = asyncio.Lock()

    async def __aenter__(self) -> QazShieldClient:
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.close()

    async def close(self) -> None:
        """Close only the HTTP client created by this instance."""
        if self._owns_client and self._client is not None and not self._client.is_closed:
            await self._client.aclose()
        self._client = None

    async def anonymize(self, text: str, *, sensitivity: str = "standard") -> dict[str, Any]:
        """Anonymize one text and retry exactly once after an expired JWT."""
        if not isinstance(text, str) or not text.strip():
            raise ValueError("text must be a non-empty string")
        if not self.api_key:
            raise QazShieldUnavailable("QazShield API key is not configured")

        token = await self._get_token()
        response = await self._post_anonymize(token, text, sensitivity)
        if response.status_code == 401:
            token = await self._get_token(rejected_token=token)
            response = await self._post_anonymize(token, text, sensitivity)
            if response.status_code == 401:
                await self._invalidate_if_current(token)
                raise QazShieldUnavailable("QazShield rejected refreshed credentials")

        if response.status_code >= 500:
            raise QazShieldUnavailable("QazShield anonymization service failed")
        response.raise_for_status()
        try:
            payload = response.json()
        except ValueError as exc:
            raise QazShieldUnavailable("QazShield anonymization response is invalid") from exc
        if not isinstance(payload, dict):
            raise QazShieldError("QazShield returned a non-object response")
        return payload

    async def try_anonymize(self, text: str, *, sensitivity: str = "standard") -> dict[str, Any] | None:
        """Return ``None`` for service/auth failures without masking 4xx input errors."""
        try:
            return await self.anonymize(text, sensitivity=sensitivity)
        except (QazShieldError, httpx.RequestError):
            return None

    async def _post_anonymize(self, token: str, text: str, sensitivity: str) -> httpx.Response:
        try:
            client = await self._http_client()
            return await client.post(
                f"{self.base_url}/api/anonymize",
                headers={"Authorization": f"Bearer {token}"},
                data={"text": text, "sensitivity": sensitivity},
                timeout=self.timeout,
            )
        except httpx.RequestError as exc:
            raise QazShieldUnavailable("QazShield anonymization request failed") from exc

    async def _get_token(self, *, rejected_token: str | None = None) -> str:
        if self._token_is_valid() and self._token != rejected_token:
            return self._token  # type: ignore[return-value]

        async with self._refresh_lock:
            if self._token_is_valid() and self._token != rejected_token:
                return self._token  # type: ignore[return-value]
            self._token = None
            self._token_expires_at = 0.0
            return await self._refresh_token()

    async def _invalidate_if_current(self, token: str) -> None:
        async with self._refresh_lock:
            if self._token == token:
                self._token = None
                self._token_expires_at = 0.0

    def _token_is_valid(self) -> bool:
        return bool(self._token) and self._token_expires_at > time.monotonic() + self.token_refresh_margin_seconds

    async def _refresh_token(self) -> str:
        try:
            client = await self._http_client()
            response = await client.post(
                f"{self.base_url}/api/token",
                json={"api_key": self.api_key, "role": self.role},
                timeout=min(self.timeout, 10.0),
            )
            response.raise_for_status()
            payload = response.json()
        except (httpx.HTTPError, ValueError) as exc:
            raise QazShieldUnavailable("QazShield token request failed") from exc

        if (
            not isinstance(payload, Mapping)
            or not isinstance(payload.get("token"), str)
            or not payload["token"].strip()
        ):
            raise QazShieldUnavailable("QazShield token response is invalid")
        try:
            configured_lifetime = float(payload.get("expires_in_hours", 1)) * 3600.0
            lifetime_seconds = max(configured_lifetime, self.token_refresh_margin_seconds + 1.0)
        except (TypeError, ValueError):
            lifetime_seconds = 3600.0
        self._token = payload["token"].strip()
        self._token_expires_at = time.monotonic() + lifetime_seconds
        return self._token

    async def _http_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(timeout=self.timeout)
            self._owns_client = True
        return self._client
