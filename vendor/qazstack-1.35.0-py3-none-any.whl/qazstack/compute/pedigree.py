"""Versioned transport contracts for deterministic pedigree analytics."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

PEDIGREE_ANALYTICS_CONTRACT = "pedigree-analytics-v1"


@dataclass(frozen=True, slots=True)
class PedigreeNode:
    node_id: str
    sire_id: str | None = None
    dam_id: str | None = None

    def __post_init__(self) -> None:
        if not self.node_id.strip():
            raise ValueError("node_id must be non-empty")
        if self.sire_id == self.node_id or self.dam_id == self.node_id:
            raise ValueError("a pedigree node cannot be its own parent")
        if self.sire_id and self.sire_id == self.dam_id:
            raise ValueError("sire_id and dam_id must be different")

    def to_dict(self) -> dict[str, str | None]:
        return {"id": self.node_id, "sire_id": self.sire_id, "dam_id": self.dam_id}


@dataclass(frozen=True, slots=True)
class PedigreeAnalyticsRequest:
    nodes: tuple[PedigreeNode, ...]
    source_revision: str
    subject_ids: tuple[str, ...] = ()
    generations: int = 4

    def __post_init__(self) -> None:
        if not self.nodes:
            raise ValueError("nodes must be non-empty")
        if not self.source_revision.strip():
            raise ValueError("source_revision must be non-empty")
        if not 1 <= self.generations <= 12:
            raise ValueError("generations must be between 1 and 12")
        node_ids = [node.node_id for node in self.nodes]
        if len(node_ids) != len(set(node_ids)):
            raise ValueError("node ids must be unique")
        missing_subjects = set(self.subject_ids) - set(node_ids)
        if missing_subjects:
            raise ValueError(f"unknown subject ids: {sorted(missing_subjects)}")

    def to_payload(self) -> dict[str, Any]:
        return {
            "contract": PEDIGREE_ANALYTICS_CONTRACT,
            "nodes": [node.to_dict() for node in self.nodes],
            "source_revision": self.source_revision,
            "subject_ids": list(self.subject_ids),
            "generations": self.generations,
        }
