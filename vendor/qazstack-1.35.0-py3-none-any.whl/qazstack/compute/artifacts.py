"""Versioned vector-artifact manifests and integrity checks."""

from __future__ import annotations

import hashlib
import json
import re
from collections.abc import Mapping, Sequence
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")


class ArtifactValidationError(ValueError):
    """Raised when an artifact cannot be trusted by a consumer."""


@dataclass(frozen=True, slots=True)
class ArtifactFile:
    name: str
    size_bytes: int
    sha256: str

    def __post_init__(self) -> None:
        if not self.name or Path(self.name).name != self.name:
            raise ValueError("artifact file name must be a plain basename")
        if self.size_bytes < 0:
            raise ValueError("artifact file size must not be negative")
        if not _SHA256_RE.fullmatch(self.sha256):
            raise ValueError("artifact file sha256 must be a lowercase hex digest")


@dataclass(frozen=True, slots=True)
class VectorArtifactManifest:
    format_version: int
    data_revision: str
    embedding_model: str
    embedding_dim: int
    embedded_total: int
    compatible_total: int
    max_chunk_id: int
    files: tuple[ArtifactFile, ...] = ()

    def __post_init__(self) -> None:
        if self.format_version < 1:
            raise ValueError("format_version must be positive")
        if not self.data_revision.strip() or not self.embedding_model.strip():
            raise ValueError("data_revision and embedding_model are required")
        if self.embedding_dim < 1 or self.embedded_total < 0 or self.compatible_total < 0:
            raise ValueError("artifact dimensions and counts are invalid")
        if self.compatible_total > self.embedded_total:
            raise ValueError("compatible_total cannot exceed embedded_total")
        if self.max_chunk_id < 0:
            raise ValueError("max_chunk_id must not be negative")
        names = [item.name for item in self.files]
        if len(names) != len(set(names)):
            raise ValueError("artifact file names must be unique")

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> "VectorArtifactManifest":
        try:
            raw_files = value.get("files") or ()
            if not isinstance(raw_files, Sequence) or isinstance(raw_files, (str, bytes)):
                raise TypeError("files must be an array")
            files = tuple(ArtifactFile(**dict(item)) for item in raw_files)
            return cls(
                format_version=int(value["format_version"]),
                data_revision=str(value["data_revision"]),
                embedding_model=str(value["embedding_model"]),
                embedding_dim=int(value["embedding_dim"]),
                embedded_total=int(value["embedded_total"]),
                compatible_total=int(value["compatible_total"]),
                max_chunk_id=int(value["max_chunk_id"]),
                files=files,
            )
        except (KeyError, TypeError, ValueError) as exc:
            raise ArtifactValidationError(f"invalid vector artifact manifest: {exc}") from exc

    def as_dict(self) -> dict[str, object]:
        payload = asdict(self)
        payload["files"] = [asdict(item) for item in self.files]
        return payload


def file_sha256(path: Path, *, block_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(block_size), b""):
            digest.update(block)
    return digest.hexdigest()


def describe_artifact_file(path: Path) -> ArtifactFile:
    return ArtifactFile(path.name, path.stat().st_size, file_sha256(path))


def load_vector_artifact_manifest(path: Path) -> VectorArtifactManifest:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ArtifactValidationError(f"cannot read vector artifact manifest: {exc}") from exc
    if not isinstance(payload, dict):
        raise ArtifactValidationError("vector artifact manifest must be an object")
    return VectorArtifactManifest.from_mapping(payload)


def validate_vector_artifact(
    manifest: VectorArtifactManifest,
    *,
    data_revision: str,
    embedding_model: str,
    embedding_dim: int,
    embedded_total: int,
    compatible_total: int,
) -> None:
    expected = {
        "data_revision": str(data_revision),
        "embedding_model": str(embedding_model),
        "embedding_dim": int(embedding_dim),
        "embedded_total": int(embedded_total),
        "compatible_total": int(compatible_total),
    }
    mismatches = [name for name, value in expected.items() if getattr(manifest, name) != value]
    if mismatches:
        raise ArtifactValidationError("vector artifact mismatch: " + ", ".join(mismatches))


def verify_artifact_files(root: Path, manifest: VectorArtifactManifest) -> None:
    for item in manifest.files:
        path = root / item.name
        try:
            actual_size = path.stat().st_size
        except OSError as exc:
            raise ArtifactValidationError(f"artifact file is unavailable: {item.name}") from exc
        if actual_size != item.size_bytes:
            raise ArtifactValidationError(f"artifact file size mismatch: {item.name}")
        if file_sha256(path) != item.sha256:
            raise ArtifactValidationError(f"artifact file checksum mismatch: {item.name}")


__all__ = [
    "ArtifactFile",
    "ArtifactValidationError",
    "VectorArtifactManifest",
    "describe_artifact_file",
    "file_sha256",
    "load_vector_artifact_manifest",
    "validate_vector_artifact",
    "verify_artifact_files",
]
