"""Provider-neutral LLM request routing and usage contracts."""

from __future__ import annotations

from dataclasses import dataclass

from qazstack.contracts._validation import require_identifier, require_positive, require_text


@dataclass(frozen=True, slots=True)
class LLMRouteRequest:
    task: str
    required_capabilities: tuple[str, ...]
    max_output_tokens: int
    timeout_seconds: float
    allow_fallback: bool = True

    def __post_init__(self) -> None:
        require_identifier(self.task, "task")
        require_positive(self.max_output_tokens, "max_output_tokens")
        require_positive(self.timeout_seconds, "timeout_seconds")
        if any(not item.strip() for item in self.required_capabilities):
            raise ValueError("required_capabilities must contain non-empty values")


@dataclass(frozen=True, slots=True)
class LLMRoute:
    provider: str
    model: str
    fallback_rank: int
    timeout_seconds: float

    def __post_init__(self) -> None:
        require_text(self.provider, "provider")
        require_text(self.model, "model")
        require_positive(self.fallback_rank, "fallback_rank", allow_zero=True)
        require_positive(self.timeout_seconds, "timeout_seconds")


@dataclass(frozen=True, slots=True)
class LLMUsage:
    input_tokens: int
    output_tokens: int

    def __post_init__(self) -> None:
        require_positive(self.input_tokens, "input_tokens", allow_zero=True)
        require_positive(self.output_tokens, "output_tokens", allow_zero=True)

    @property
    def total_tokens(self) -> int:
        return self.input_tokens + self.output_tokens


@dataclass(frozen=True, slots=True)
class LLMRouteResult:
    provider: str
    model: str
    finish_reason: str
    usage: LLMUsage
    latency_ms: int
    fallback_used: bool = False

    def __post_init__(self) -> None:
        require_text(self.provider, "provider")
        require_text(self.model, "model")
        require_text(self.finish_reason, "finish_reason")
        require_positive(self.latency_ms, "latency_ms", allow_zero=True)


@dataclass(frozen=True, slots=True)
class LLMRouteError:
    code: str
    retryable: bool
    provider: str | None = None
    status_code: int | None = None

    def __post_init__(self) -> None:
        require_identifier(self.code, "code")
        if self.provider is not None:
            require_text(self.provider, "provider")
        if self.status_code is not None and not 400 <= self.status_code <= 599:
            raise ValueError("status_code must be an HTTP error status")
