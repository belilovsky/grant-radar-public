"""Async HTTP client for QazCompute NLP/ML inference service.

Reads configuration from environment variables:
    QAZCOMPUTE_URL      – base URL (default: http://qazcompute_app:8000)
    QAZCOMPUTE_API_KEY  – X-API-Key for authentication
    QAZCOMPUTE_CALLER   – stable consumer identity (default: qazstack)

Features:
    - Automatic retry with exponential backoff (3 attempts)
    - Circuit breaker: after N consecutive failures, fast-fail for cooldown period
    - Request ID propagation (X-Request-ID header)
    - Configurable timeouts per operation type

All methods return parsed JSON dicts/lists. Raise ``httpx.HTTPStatusError``
on 4xx/5xx or ``ComputeError`` on connection failures.
"""

from __future__ import annotations

import asyncio
import logging
import os
import time
import uuid
from datetime import UTC, datetime
from math import sqrt
from typing import Any

import httpx

from qazstack.compute.contracts import ComputeCapabilitiesSnapshot

logger = logging.getLogger(__name__)

_DEFAULT_URL = "http://qazcompute_app:8000"


class ComputeError(Exception):
    """Raised when QazCompute is unreachable or returns an unexpected response."""


class CircuitOpenError(ComputeError):
    """Raised when the circuit breaker is open (service assumed down)."""


def _event_text(event: dict[str, Any]) -> str:
    for key in ("text", "title", "summary", "excerpt"):
        value = event.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    raise ValueError("each event requires non-empty text, title, summary or excerpt")


def _cosine_similarity(left: list[float], right: list[float]) -> float:
    if len(left) != len(right):
        raise ComputeError("QazCompute returned embeddings with inconsistent dimensions")
    magnitude = sqrt(sum(value * value for value in left) * sum(value * value for value in right))
    if not magnitude:
        return 0.0
    return sum(left_value * right_value for left_value, right_value in zip(left, right, strict=True)) / magnitude


class _CircuitBreaker:
    """Simple circuit breaker: after `threshold` consecutive failures,
    reject requests for `cooldown` seconds before allowing a probe."""

    def __init__(self, threshold: int = 5, cooldown: float = 30.0):
        self.threshold = threshold
        self.cooldown = cooldown
        self._failures = 0
        self._last_failure: float = 0.0
        self._state = "closed"  # closed | open | half-open

    @property
    def is_open(self) -> bool:
        if self._state == "open":
            if time.monotonic() - self._last_failure > self.cooldown:
                self._state = "half-open"
                return False
            return True
        return False

    def record_success(self) -> None:
        self._failures = 0
        self._state = "closed"

    def record_failure(self) -> None:
        self._failures += 1
        self._last_failure = time.monotonic()
        if self._failures >= self.threshold:
            self._state = "open"
            logger.warning(
                "Circuit breaker OPEN: %d consecutive failures, cooldown %ds",
                self._failures,
                self.cooldown,
            )


class ComputeClient:
    """Async HTTP client for QazCompute with retry and circuit breaker.

    Args:
        base_url: Override the QazCompute URL.
        api_key: Override the API key.
        timeout: HTTP request timeout in seconds.
        max_retries: Number of retry attempts on transient failures.
        circuit_threshold: Consecutive failures before circuit opens.
        circuit_cooldown: Seconds to wait before retrying after circuit opens.
    """

    def __init__(
        self,
        base_url: str | None = None,
        api_key: str | None = None,
        caller: str | None = None,
        timeout: float = 60.0,
        max_retries: int = 3,
        circuit_threshold: int = 5,
        circuit_cooldown: float = 30.0,
    ) -> None:
        self.base_url = (base_url or os.getenv("QAZCOMPUTE_URL", _DEFAULT_URL)).rstrip("/")
        self.api_key = api_key or os.getenv("QAZCOMPUTE_API_KEY", "")
        self.caller = caller or os.getenv("QAZCOMPUTE_CALLER", "qazstack")
        self.timeout = timeout
        self.max_retries = max_retries
        self._client: httpx.AsyncClient | None = None
        self._circuit = _CircuitBreaker(threshold=circuit_threshold, cooldown=circuit_cooldown)

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                headers=self._headers(),
                timeout=httpx.Timeout(self.timeout),
            )
        return self._client

    def _headers(self) -> dict[str, str]:
        headers = {"X-Caller": self.caller}
        if self.api_key:
            headers["X-API-Key"] = self.api_key
        return headers

    async def close(self) -> None:
        if self._client and not self._client.is_closed:
            await self._client.aclose()
            self._client = None

    async def _request_with_retry(self, method: str, path: str, **kwargs: Any) -> Any:
        """Execute HTTP request with retry + circuit breaker."""
        if self._circuit.is_open:
            raise CircuitOpenError(
                f"Circuit breaker is open for QazCompute at {self.base_url}. "
                f"Service assumed unavailable. Will retry after cooldown."
            )

        client = await self._get_client()
        req_id = str(uuid.uuid4())[:12]
        last_exc: Exception | None = None
        request_headers = dict(kwargs.pop("headers", {}) or {})
        request_headers["X-Request-ID"] = req_id

        for attempt in range(1, self.max_retries + 1):
            try:
                if method == "POST":
                    resp = await client.post(path, headers=request_headers, **kwargs)
                else:
                    resp = await client.get(path, headers=request_headers, **kwargs)

                # 429 Too Many Requests – respect Retry-After
                if resp.status_code == 429:
                    retry_after = int(resp.headers.get("Retry-After", "5"))
                    if attempt < self.max_retries:
                        logger.warning(
                            "QazCompute rate limited (429), retry in %ds (attempt %d/%d) req_id=%s",
                            retry_after,
                            attempt,
                            self.max_retries,
                            req_id,
                        )
                        await asyncio.sleep(min(retry_after, 30))
                        continue
                    resp.raise_for_status()

                # 5xx – retryable server errors
                if resp.status_code >= 500:
                    if attempt < self.max_retries:
                        backoff = min(2 ** (attempt - 1), 16)
                        logger.warning(
                            "QazCompute %s returned %d, retry in %ds (attempt %d/%d) req_id=%s",
                            path,
                            resp.status_code,
                            backoff,
                            attempt,
                            self.max_retries,
                            req_id,
                        )
                        await asyncio.sleep(backoff)
                        continue
                    resp.raise_for_status()

                # 4xx – client errors, don't retry
                resp.raise_for_status()

                self._circuit.record_success()
                return resp.json()

            except httpx.ConnectError as exc:
                last_exc = exc
                self._circuit.record_failure()
                if attempt < self.max_retries:
                    backoff = min(2 ** (attempt - 1), 16)
                    logger.warning(
                        "QazCompute connection failed, retry in %ds (attempt %d/%d) req_id=%s: %s",
                        backoff,
                        attempt,
                        self.max_retries,
                        req_id,
                        exc,
                    )
                    await asyncio.sleep(backoff)
                    continue

            except httpx.TimeoutException as exc:
                last_exc = exc
                self._circuit.record_failure()
                if attempt < self.max_retries:
                    backoff = min(2 ** (attempt - 1), 16)
                    logger.warning(
                        "QazCompute timeout, retry in %ds (attempt %d/%d) req_id=%s: %s",
                        backoff,
                        attempt,
                        self.max_retries,
                        req_id,
                        exc,
                    )
                    await asyncio.sleep(backoff)
                    continue

            except httpx.HTTPStatusError as exc:
                self._circuit.record_failure()
                logger.error(
                    "QazCompute %s returned %s: %s req_id=%s",
                    path,
                    exc.response.status_code,
                    exc.response.text[:500],
                    req_id,
                )
                raise

        # All retries exhausted
        raise ComputeError(
            f"Cannot connect to QazCompute at {self.base_url} after {self.max_retries} attempts: {last_exc}"
        )

    async def _post(
        self,
        path: str,
        json: dict[str, Any],
        *,
        headers: dict[str, str] | None = None,
    ) -> Any:
        """Send POST request with retry and circuit breaker."""
        return await self._request_with_retry("POST", f"/api/v1{path}", json=json, headers=headers)

    async def _get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        """Send GET request with retry and circuit breaker."""
        return await self._request_with_retry("GET", f"/api/v1{path}", params=params)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def sentiment(self, texts: list[str]) -> list[dict]:
        """Batch sentiment analysis. Returns list of {text, label, score}."""
        return await self._post("/sentiment", {"texts": texts})

    async def ner(self, texts: list[str], lang: str | None = None) -> list[dict]:
        """Batch NER. Returns list of {text, lang, entities: [{text, label, start, end}]}."""
        path = "/ner"
        if lang:
            path = f"/ner?lang={lang}"
        return await self._post(path, {"texts": texts})

    async def embeddings(
        self,
        texts: list[str],
        prefix: str = "query",
        normalize: bool = True,
    ) -> dict:
        """Batch embeddings (multilingual-e5-large, 1024d).

        Returns: {vectors, dimension, count, normalized, prefix_used}
        """
        return await self._post(
            "/embeddings",
            {"texts": texts, "prefix": prefix, "normalize": normalize},
        )

    async def capabilities_snapshot(self) -> ComputeCapabilitiesSnapshot:
        """Return the validated effective provider and quality snapshot."""
        result = await self._get("/capabilities")
        if not isinstance(result, dict):
            raise ComputeError("QazCompute returned an invalid capabilities contract")
        try:
            return ComputeCapabilitiesSnapshot.from_mapping(result)
        except ValueError as exc:
            raise ComputeError(f"QazCompute returned an invalid capabilities contract: {exc}") from exc

    async def rerank(
        self,
        query: str,
        documents: list[str],
        top_k: int | None = None,
        *,
        caller: str | None = None,
        internal_batch: bool = False,
    ) -> dict:
        """Rerank documents against a query using their original indexes.

        Returns: {results: [{index, score}], model, backend, count}
        """
        payload: dict[str, Any] = {"query": query, "documents": documents}
        if top_k is not None:
            payload["top_k"] = top_k
        headers: dict[str, str] = {}
        if caller:
            headers["X-Caller"] = caller
        if internal_batch:
            headers["X-Internal-Batch"] = "true"
        return await self._post("/rerank", payload, headers=headers)

    async def corpus_similarity(
        self,
        items: list[dict[str, Any]],
        *,
        min_score: float = 0.85,
        max_pairs: int = 100,
    ) -> dict[str, Any]:
        """Return review candidates from an equal-dimensional vector corpus.

        QazCompute performs the bounded cosine calculation. The consuming
        product remains responsible for duplicate decisions and record merges.
        """
        result = await self._post(
            "/similarity/corpus",
            {
                "items": items,
                "min_score": min_score,
                "max_pairs": max_pairs,
            },
        )
        if not isinstance(result, dict) or result.get("schema_version") != "qazcompute-corpus-similarity-v1":
            raise ComputeError("QazCompute returned an unsupported corpus-similarity contract")
        return result

    async def detect_language(self, texts: list[str]) -> list[dict]:
        """Batch language detection. Returns list of {text, lang, confidence}."""
        return await self._post("/detect-language", {"texts": texts})

    async def translate(
        self,
        texts: list[str],
        src_lang: str,
        tgt_lang: str,
    ) -> dict:
        """Batch translation via Tilmash (NLLB).

        Language codes: kaz_Cyrl, rus_Cyrl, eng_Latn, tur_Latn.
        Returns: {translations: [{original, translated, src_lang, tgt_lang}], count}
        """
        return await self._post(
            "/translate",
            {"texts": texts, "src_lang": src_lang, "tgt_lang": tgt_lang},
        )

    async def morphology(self, texts: list[str], mode: str = "morph") -> dict:
        """Morphological analysis (slovnet).

        mode='morph': POS + features. mode='syntax': dependency parse.
        Returns: {results: [{text, tokens}], mode, count}
        """
        return await self._post("/morphology", {"texts": texts, "mode": mode})

    async def kazbert_embeddings(self, texts: list[str]) -> dict:
        """Kazakh-specific embeddings via KazBERT.

        Returns: {vectors, dimension, count, model}
        """
        return await self._post("/kazbert/embeddings", {"texts": texts})

    async def process(
        self,
        texts: list[str],
        tasks: list[str] | None = None,
        src_lang: str | None = None,
        tgt_lang: str | None = None,
        max_source_tokens: int | None = None,
        num_beams: int | None = None,
    ) -> dict:
        """Multi-task pipeline. Run multiple NLP tasks in one request.

        tasks: ['sentiment', 'ner', 'embeddings', 'language', 'translation', 'morphology', 'summary']
        Returns the backward-compatible task fields plus v2 provenance when supported by the service.
        """
        payload: dict[str, Any] = {"texts": texts}
        if tasks:
            payload["tasks"] = tasks
        if src_lang:
            payload["src_lang"] = src_lang
        if tgt_lang:
            payload["tgt_lang"] = tgt_lang
        if max_source_tokens is not None:
            payload["max_source_tokens"] = max_source_tokens
        if num_beams is not None:
            payload["num_beams"] = num_beams
        return await self._post("/process", payload)

    async def timeseries_analyze(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Build a temporal contract from QazStack's pure helpers.

        Temporal summaries are deterministic transformations rather than model
        inference, so they must not depend on an undeclared QazCompute route.
        """
        from qazstack.temporal import (
            TEMPORAL_SERIES_CONTRACT,
            TemporalSeries,
            normalize_series_points,
            summarize_series,
        )

        result = dict(payload)
        points = normalize_series_points(result.get("points", []))
        result["schema_version"] = TEMPORAL_SERIES_CONTRACT
        result["points"] = [point.model_dump(mode="json") for point in points]
        result["summary"] = summarize_series(points).model_dump(mode="json")
        return TemporalSeries.model_validate(result).model_dump(mode="json")

    async def event_enrichment(
        self,
        events: list[dict[str, Any]],
        *,
        effective_date: str,
        source_revision: str,
        include_sentiment: bool = True,
        include_entities: bool = True,
    ) -> dict[str, Any]:
        """Enrich event candidates through supported QazCompute inference APIs."""
        texts = [_event_text(event) for event in events]
        entity_rows: list[dict[str, Any]] | None = None
        sentiment_rows: list[dict[str, Any]] | None = None
        pending: list[tuple[str, Any]] = []
        if include_entities:
            pending.append(("entities", self.ner(texts)))
        if include_sentiment:
            pending.append(("sentiment", self.sentiment(texts)))
        if pending:
            resolved = await asyncio.gather(*(coroutine for _, coroutine in pending))
            for (name, _), value in zip(pending, resolved, strict=True):
                if name == "entities":
                    entity_rows = value
                else:
                    sentiment_rows = value

        enriched: list[dict[str, Any]] = []
        for index, event in enumerate(events):
            record = dict(event)
            if entity_rows is not None:
                record["entity_candidates"] = entity_rows[index].get("entities", [])
            if sentiment_rows is not None:
                record["sentiment_signal"] = {
                    key: sentiment_rows[index].get(key) for key in ("label", "score") if key in sentiment_rows[index]
                }
            enriched.append(record)

        return {
            "schema_version": "qazcompute-event-enrichment-v1",
            "profile": "event_enrichment.v1",
            "effective_date": effective_date,
            "source_revision": source_revision,
            "events": enriched,
            "capabilities": [
                name for name, enabled in (("ner", include_entities), ("sentiment", include_sentiment)) if enabled
            ],
            "generated_at": datetime.now(UTC).isoformat(),
        }

    async def event_cluster(
        self,
        events: list[dict[str, Any]],
        *,
        similarity_threshold: float = 0.82,
    ) -> dict[str, Any]:
        """Cluster event candidates using QazCompute vectors and deterministic unioning."""
        if not 0 < similarity_threshold <= 1:
            raise ValueError("similarity_threshold must be within (0, 1]")
        texts = [_event_text(event) for event in events]
        embedding_result = await self.embeddings(texts, prefix="passage", normalize=True)
        vectors = embedding_result.get("vectors", [])
        if len(vectors) != len(events):
            raise ComputeError("QazCompute returned a vector count that does not match the event input")

        parent = list(range(len(events)))

        def find(index: int) -> int:
            while parent[index] != index:
                parent[index] = parent[parent[index]]
                index = parent[index]
            return index

        def union(left: int, right: int) -> None:
            left_root, right_root = find(left), find(right)
            if left_root != right_root:
                parent[right_root] = left_root

        for left in range(len(vectors)):
            for right in range(left + 1, len(vectors)):
                if _cosine_similarity(vectors[left], vectors[right]) >= similarity_threshold:
                    union(left, right)

        groups: dict[int, list[str]] = {}
        for index, event in enumerate(events):
            event_id = str(event.get("event_id") or event.get("id") or index)
            groups.setdefault(find(index), []).append(event_id)
        clusters = [
            {"cluster_id": f"event-cluster:{member_ids[0]}", "event_ids": member_ids}
            for member_ids in sorted(groups.values(), key=lambda values: values[0])
        ]
        return {
            "schema_version": "qazcompute-event-cluster-v1",
            "profile": "event_cluster.v1",
            "clusters": clusters,
            "capability": {
                "capability": "embeddings",
                "provider": embedding_result.get("provider"),
                "model": embedding_result.get("model"),
                "quality_tier": embedding_result.get("quality_tier"),
            },
        }

    async def pedigree_analyze(
        self,
        nodes: list[dict[str, str | None]],
        *,
        source_revision: str,
        subject_ids: list[str] | None = None,
        generations: int = 4,
    ) -> dict[str, Any]:
        """Run the versioned deterministic ``pedigree-analytics-v1`` task."""

        return await self._post(
            "/tasks/pedigree-analytics",
            {
                "contract": "pedigree-analytics-v1",
                "nodes": nodes,
                "source_revision": source_revision,
                "subject_ids": subject_ids or [],
                "generations": generations,
            },
        )

    async def models_status(self) -> dict:
        """Get status of all registered ML models."""
        return await self._get("/models")

    async def capabilities(self) -> dict:
        """Return the provider and quality contract for available capabilities."""
        return await self._get("/capabilities")

    async def submit_job(
        self,
        *,
        task: str,
        texts: list[str],
        options: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
    ) -> dict:
        """Submit a resumable, versioned QazCompute batch job."""
        payload: dict[str, Any] = {"task": task, "texts": texts, "options": options or {}}
        if idempotency_key:
            payload["idempotency_key"] = idempotency_key
        return await self._post("/jobs", payload)

    async def job_status(self, job_id: str) -> dict:
        """Read current state and result for a resumable batch job."""
        if not job_id.strip():
            raise ValueError("job_id must not be empty")
        return await self._get(f"/jobs/{job_id}")

    async def get_job(self, job_id: str) -> dict:
        """Backward-compatible alias for :meth:`job_status`."""
        return await self.job_status(job_id)

    async def health(self) -> dict:
        """Check QazCompute health."""
        return await self._request_with_retry("GET", "/health")

    # ------------------------------------------------------------------
    # Speech-to-Text (STT)
    # ------------------------------------------------------------------

    async def transcribe(
        self,
        audio_b64: str,
        language: str | None = None,
        task: str = "transcribe",
    ) -> dict:
        """Speech-to-text using Whisper large-v3-turbo.

        Args:
            audio_b64: Base64-encoded audio (WAV, MP3, OGG, etc.).
            language: Force language (e.g., ru, kk, en). Auto-detect if None.
            task: transcribe (default) or translate (translate to English).

        Returns:
            {text, language, duration, segments: [{start, end, text}]}
        """
        payload: dict[str, Any] = {"audio_b64": audio_b64, "task": task}
        if language:
            payload["language"] = language
        return await self._post("/transcribe", payload)

    # ------------------------------------------------------------------
    # Text-to-Speech (TTS) – Silero (Russian + English)
    # ------------------------------------------------------------------

    async def synthesize(
        self,
        texts: list[str],
        language: str = "ru",
        speaker: str = "xenia",
        sample_rate: int = 48000,
    ) -> list[dict]:
        """Text-to-speech using Silero TTS.

        Args:
            texts: List of texts to synthesize (max ~1000 chars each).
            language: ru or en.
            speaker: Voice name.
                Russian: aidar, baya, kseniya, xenia, eugene.
                English: en_0 .. en_117.
            sample_rate: 8000, 24000, or 48000 Hz.

        Returns:
            [{audio_b64, sample_rate, duration}]
        """
        return await self._post(
            "/synthesize",
            {"texts": texts, "language": language, "speaker": speaker, "sample_rate": sample_rate},
        )

    # ------------------------------------------------------------------
    # Image Generation (SDXL Turbo)
    # ------------------------------------------------------------------

    async def generate_image(
        self,
        prompt: str,
        num_steps: int = 1,
        width: int = 512,
        height: int = 512,
        seed: int | None = None,
    ) -> dict:
        """Generate image from text prompt using SDXL Turbo.

        Args:
            prompt: Text description of desired image.
            num_steps: Inference steps (1-4, default 1 for fastest).
            width: Image width (256-1024, default 512).
            height: Image height (256-1024, default 512).
            seed: Random seed for reproducibility.

        Returns:
            {image_b64, width, height, format}
        """
        payload: dict[str, Any] = {
            "prompt": prompt,
            "num_steps": num_steps,
            "width": width,
            "height": height,
        }
        if seed is not None:
            payload["seed"] = seed
        return await self._post("/generate-image", payload)

    # ------------------------------------------------------------------
    # High-quality TTS (Kokoro – multilingual)
    # ------------------------------------------------------------------

    async def kokoro_tts(
        self,
        texts: list[str],
        voice: str = "af_heart",
        lang_code: str = "a",
        speed: float = 1.0,
    ) -> list[dict]:
        """High-quality TTS using Kokoro (multilingual).

        Args:
            texts: List of texts to synthesize.
            voice: Voice name (e.g., af_heart, af_bella, am_adam, bf_emma).
            lang_code: Language code.
                a = American English, b = British English,
                e = Spanish, f = French, h = Hindi,
                i = Italian, j = Japanese, p = Portuguese, z = Chinese.
            speed: Speech speed (0.5-2.0, default 1.0).

        Returns:
            [{audio_b64, sample_rate, duration}]
        """
        return await self._post(
            "/kokoro-tts",
            {"texts": texts, "voice": voice, "lang_code": lang_code, "speed": speed},
        )

    # ------------------------------------------------------------------
    # Vision endpoints
    # ------------------------------------------------------------------

    async def embed_images(
        self,
        images: list[str],
        normalize: bool = True,
    ) -> dict:
        """Compute SigLIP 2 image embeddings (768-dim).

        Args:
            images: List of base64-encoded images.
            normalize: L2-normalize vectors (default True).

        Returns:
            {vectors, dimension, count, normalized}
        """
        return await self._post(
            "/vision/embed-images",
            {"images": images, "normalize": normalize},
        )

    async def embed_texts_visual(
        self,
        texts: list[str],
        normalize: bool = True,
    ) -> dict:
        """Compute SigLIP 2 text embeddings for cross-modal image search.

        Args:
            texts: List of search queries.
            normalize: L2-normalize vectors (default True).

        Returns:
            {vectors, dimension, count, normalized}
        """
        return await self._post(
            "/vision/embed-text",
            {"texts": texts, "normalize": normalize},
        )

    async def ocr(
        self,
        images: list[str],
        languages: list[str] | None = None,
    ) -> list[dict]:
        """OCR – extract text from images.

        Args:
            images: List of base64-encoded images.
            languages: OCR languages (default [ru, en]).

        Returns:
            [{text, confidence, boxes}]
        """
        payload: dict[str, Any] = {"images": images}
        if languages:
            payload["languages"] = languages
        return await self._post("/vision/ocr", payload)

    async def detect_faces(
        self,
        images: list[str],
        return_embeddings: bool = False,
    ) -> list[dict]:
        """Detect faces and compute ArcFace embeddings (512-dim).

        Args:
            images: List of base64-encoded images.
            return_embeddings: Include face embeddings in response.

        Returns:
            [{faces: [{bbox, confidence, embedding?}]}]
        """
        return await self._post(
            "/vision/detect-faces",
            {"images": images, "return_embeddings": return_embeddings},
        )

    async def stance(
        self,
        pairs: list[dict],
        threshold: float = 0.0,
    ) -> list[dict]:
        """Stance detection (entailment/neutral/contradiction).

        Args:
            pairs: List of {text, hypothesis} dicts.
            threshold: Minimum confidence for a non-neutral stance.

        Returns:
            [{text, hypothesis, stance, confidence, nli_scores}]
        """
        return await self._post("/stance", {"pairs": pairs, "threshold": threshold})

    async def summarize(
        self,
        texts: list[str],
        max_source_tokens: int = 1024,
        num_beams: int = 5,
    ) -> list[dict]:
        """Summarize texts using ruT5-base.

        Args:
            texts: List of texts to summarize.
            max_source_tokens: Maximum source token budget.
            num_beams: Beam-search width.

        Returns:
            [{original_length, summary, summary_length}]
        """
        return await self._post(
            "/summarize",
            {"texts": texts, "max_source_tokens": max_source_tokens, "num_beams": num_beams},
        )

    # ------------------------------------------------------------------
    # Evidence analysis (signals only; products retain editorial policy)
    # ------------------------------------------------------------------

    async def claim_match(
        self,
        query: str,
        candidate: str,
        *,
        query_entities: list[str] | None = None,
        candidate_entities: list[str] | None = None,
        embedding_similarity: float | None = None,
    ) -> dict:
        """Return explainable claim-similarity signals without a truth verdict."""
        payload: dict[str, Any] = {
            "query": query,
            "candidate": candidate,
            "query_entities": query_entities or [],
            "candidate_entities": candidate_entities or [],
        }
        if embedding_similarity is not None:
            payload["embedding_similarity"] = embedding_similarity
        return await self._post("/analysis/claim-match", payload)

    async def inspect_media(self, artifacts: list[dict[str, str]]) -> dict:
        """Return bounded metadata, fingerprints and provenance for image bytes."""
        return await self._post("/analysis/media-inspect", {"artifacts": artifacts})

    async def analysis_rerank(
        self,
        query: str,
        documents: list[str],
        *,
        top_k: int | None = None,
    ) -> dict:
        """Call the optional analysis-scoped cross-encoder capability."""
        payload: dict[str, Any] = {"query": query, "documents": documents}
        if top_k is not None:
            payload["top_k"] = top_k
        return await self._post("/analysis/rerank", payload)

    # ------------------------------------------------------------------
    # LLM Gateway (Gemini proxy via QazCompute)
    # ------------------------------------------------------------------

    async def llm_generate(
        self,
        prompt: str,
        *,
        model: str = "gemini-2.5-flash",
        system: str = "",
        temperature: float = 0.7,
        max_tokens: int = 4096,
        history: list[dict] | None = None,
        caller: str = "",
    ) -> dict:
        """Generate text via LLM Gateway (Gemini).

        Args:
            prompt: User prompt.
            model: Gemini model ID (gemini-2.5-flash, gemini-2.5-flash-lite).
            system: Optional system instruction.
            temperature: Sampling temperature (0.0 – 2.0).
            max_tokens: Max output tokens.
            history: Optional conversation history.
            caller: Project name for per-caller cost tracking.

        Returns:
            {text, model, tokens_in, tokens_out, cached, estimated_cost}
        """
        payload: dict[str, Any] = {
            "prompt": prompt,
            "model": model,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        if system:
            payload["system"] = system
        if history:
            payload["history"] = history

        headers = {"X-Caller": caller} if caller else {}
        return await self._post("/llm/generate", payload, headers=headers)

    async def llm_embed(
        self,
        texts: list[str],
        *,
        model: str = "gemini-embedding-001",
        caller: str = "",
    ) -> dict:
        """Get Gemini embeddings via LLM Gateway.

        Args:
            texts: List of texts to embed.
            model: Embedding model ID.
            caller: Project name for per-caller cost tracking.

        Returns:
            {embeddings, dimensions, model}
        """
        headers = {"X-Caller": caller} if caller else {}
        return await self._post(
            "/llm/embed",
            {"texts": texts, "model": model},
            headers=headers,
        )

    async def llm_stats(self) -> dict:
        """Get LLM Gateway usage & cost statistics.

        Returns:
            {today: {requests, tokens_in, tokens_out, cost, cache_hits},
             month: {requests, cost, budget, budget_remaining},
             by_caller: {name: {requests, cost}}}
        """
        return await self._get("/llm/stats")

    # ------------------------------------------------------------------
    # Video Generation (Wan 2.2 via Wan Studio)
    # ------------------------------------------------------------------

    async def generate_video(
        self,
        prompt: str,
        *,
        negative_prompt: str = "",
        mode: str = "t2v",
        model: str = "wan2.2_t2v_high_noise_14B_fp8_scaled",
        width: int = 480,
        height: int = 480,
        frames: int = 33,
        steps: int = 20,
        cfg: float = 6.0,
        use_lora: bool = False,
        caller: str = "",
    ) -> dict:
        """Submit video generation via Wan 2.2 on RunPod GPU.

        Args:
            prompt: Text description of desired video.
            negative_prompt: What to avoid in generation.
            mode: "t2v" (text-to-video) or "i2v" (image-to-video).
            model: Wan 2.2 model variant.
            width: Video width (256–1920).
            height: Video height (256–1920).
            frames: Number of frames – 17 (~1s), 33 (~2s), 65 (~4s).
            steps: Denoising steps (1–50). Ignored when use_lora=True (forced to 4).
            cfg: CFG scale (1.0–20.0).
            use_lora: Use 4-step LightX2V LoRA acceleration (6× faster).
            caller: Project name for per-caller GPU cost tracking.

        Returns:
            {id, promptId, status, prompt, mode}
        """
        payload = {
            "mode": mode,
            "prompt": prompt,
            "negativePrompt": negative_prompt,
            "model": model,
            "width": width,
            "height": height,
            "frames": frames,
            "steps": 4 if use_lora else steps,
            "cfg": cfg,
            "useLora": use_lora,
        }
        return await self._post("/video/generate", payload)

    async def video_status(self, generation_id: int) -> dict:
        """Check video generation status.

        Args:
            generation_id: Generation ID returned by generate_video().

        Returns:
            {id, promptId, status, prompt, outputFilename, errorMessage, ...}
        """
        return await self._get(f"/video/status/{generation_id}")

    async def video_download(self, generation_id: int) -> bytes:
        """Download completed video as raw MP4 bytes.

        Args:
            generation_id: Generation ID of completed generation.

        Returns:
            Raw MP4 video bytes.
        """
        client = await self._get_client()
        req_id = str(uuid.uuid4())[:12]
        resp = await client.get(
            f"{self.base_url}/api/v1/video/download/{generation_id}",
            headers={"X-Request-ID": req_id},
            timeout=httpx.Timeout(120.0),
        )
        resp.raise_for_status()
        return resp.content

    async def video_generate_and_wait(
        self,
        prompt: str,
        *,
        timeout: float = 300.0,
        poll_interval: float = 5.0,
        **kwargs: Any,
    ) -> bytes:
        """Generate video and wait until completion. Returns MP4 bytes.

        Args:
            prompt: Text prompt for video.
            timeout: Max seconds to wait (default 300 = 5 min).
            poll_interval: Seconds between status polls.
            **kwargs: Additional args passed to generate_video().

        Returns:
            Raw MP4 video bytes.

        Raises:
            ComputeError: If generation fails or times out.
        """
        result = await self.generate_video(prompt, **kwargs)
        gen_id = result["id"]
        deadline = time.monotonic() + timeout

        while time.monotonic() < deadline:
            status = await self.video_status(gen_id)
            if status["status"] == "completed":
                return await self.video_download(gen_id)
            if status["status"] == "failed":
                raise ComputeError(f"Video generation {gen_id} failed: {status.get('errorMessage', 'unknown error')}")
            await asyncio.sleep(poll_interval)

        raise ComputeError(f"Video generation {gen_id} timed out after {timeout}s (status: {status['status']})")

    async def video_list(self) -> list[dict]:
        """List all video generations.

        Returns:
            List of generation objects (without videoData).
        """
        return await self._get("/video/list")

    async def video_gpu_status(self) -> dict:
        """Get video GPU status (VRAM, queue, online/offline).

        Returns:
            {online, gpu_name, vram_total_gb, vram_used_gb, vram_free_gb,
             queue_running, queue_pending}
        """
        return await self._get("/video/gpu-status")

    async def video_presets(self) -> list[dict]:
        """List video prompt presets.

        Returns:
            List of {id, name, prompt, negativePrompt} presets.
        """
        return await self._get("/video/presets")


class SyncComputeClient:
    """Synchronous QazCompute client for SSR routes and command-line workers."""

    def __init__(
        self,
        base_url: str | None = None,
        api_key: str | None = None,
        caller: str | None = None,
        timeout: float = 60.0,
        max_retries: int = 3,
        circuit_threshold: int = 5,
        circuit_cooldown: float = 30.0,
    ) -> None:
        self.base_url = (base_url or os.getenv("QAZCOMPUTE_URL", _DEFAULT_URL)).rstrip("/")
        self.api_key = api_key or os.getenv("QAZCOMPUTE_API_KEY", "")
        self.caller = caller or os.getenv("QAZCOMPUTE_CALLER", "qazstack")
        self.timeout = timeout
        self.max_retries = max_retries
        self._client: httpx.Client | None = None
        self._circuit = _CircuitBreaker(threshold=circuit_threshold, cooldown=circuit_cooldown)

    def _headers(self) -> dict[str, str]:
        headers = {"X-Caller": self.caller}
        if self.api_key:
            headers["X-API-Key"] = self.api_key
        return headers

    def _get_client(self) -> httpx.Client:
        if self._client is None or self._client.is_closed:
            self._client = httpx.Client(
                base_url=self.base_url,
                headers=self._headers(),
                timeout=httpx.Timeout(self.timeout),
            )
        return self._client

    def close(self) -> None:
        if self._client and not self._client.is_closed:
            self._client.close()
            self._client = None

    def __enter__(self) -> SyncComputeClient:
        return self

    def __exit__(self, exc_type: object, exc: object, traceback: object) -> None:
        self.close()

    def _request_with_retry(self, method: str, path: str, **kwargs: Any) -> Any:
        if self._circuit.is_open:
            raise CircuitOpenError(f"Circuit breaker is open for QazCompute at {self.base_url}")

        client = self._get_client()
        request_id = str(uuid.uuid4())[:12]
        last_exc: Exception | None = None
        request_headers = dict(kwargs.pop("headers", {}) or {})
        request_headers["X-Request-ID"] = request_id
        for attempt in range(1, self.max_retries + 1):
            try:
                response = client.request(method, path, headers=request_headers, **kwargs)
                if response.status_code == 429 and attempt < self.max_retries:
                    time.sleep(min(int(response.headers.get("Retry-After", "5")), 30))
                    continue
                if response.status_code >= 500 and attempt < self.max_retries:
                    time.sleep(min(2 ** (attempt - 1), 16))
                    continue
                response.raise_for_status()
                self._circuit.record_success()
                return response.json()
            except (httpx.ConnectError, httpx.TimeoutException) as exc:
                last_exc = exc
                self._circuit.record_failure()
                if attempt < self.max_retries:
                    time.sleep(min(2 ** (attempt - 1), 16))
                    continue
            except httpx.HTTPStatusError:
                self._circuit.record_failure()
                raise

        raise ComputeError(
            f"Cannot connect to QazCompute at {self.base_url} after {self.max_retries} attempts: {last_exc}"
        )

    def _post(
        self,
        path: str,
        payload: dict[str, Any],
        *,
        headers: dict[str, str] | None = None,
    ) -> Any:
        return self._request_with_retry("POST", f"/api/v1{path}", json=payload, headers=headers)

    def _get(self, path: str) -> Any:
        return self._request_with_retry("GET", f"/api/v1{path}")

    def embeddings(self, texts: list[str], *, prefix: str = "query", normalize: bool = True) -> dict:
        return self._post("/embeddings", {"texts": texts, "prefix": prefix, "normalize": normalize})

    def sentiment(self, texts: list[str]) -> list[dict]:
        return self._post("/sentiment", {"texts": texts})

    def ner(self, texts: list[str], *, lang: str | None = None) -> list[dict]:
        path = f"/ner?lang={lang}" if lang else "/ner"
        return self._post(path, {"texts": texts})

    def detect_language(self, texts: list[str]) -> list[dict]:
        return self._post("/detect-language", {"texts": texts})

    def translate(self, texts: list[str], *, src_lang: str, tgt_lang: str) -> dict:
        return self._post("/translate", {"texts": texts, "src_lang": src_lang, "tgt_lang": tgt_lang})

    def process(
        self,
        texts: list[str],
        *,
        tasks: list[str] | None = None,
        src_lang: str | None = None,
        tgt_lang: str | None = None,
        max_source_tokens: int | None = None,
        num_beams: int | None = None,
    ) -> dict:
        """Run the versioned multi-task pipeline from a CLI or cron worker."""
        payload: dict[str, Any] = {"texts": texts}
        if tasks:
            payload["tasks"] = tasks
        if src_lang:
            payload["src_lang"] = src_lang
        if tgt_lang:
            payload["tgt_lang"] = tgt_lang
        if max_source_tokens is not None:
            payload["max_source_tokens"] = max_source_tokens
        if num_beams is not None:
            payload["num_beams"] = num_beams
        return self._post("/process", payload)

    def llm_generate(
        self,
        prompt: str,
        *,
        model: str = "gemini-2.5-flash",
        system: str = "",
        temperature: float = 0.7,
        max_tokens: int = 4096,
        history: list[dict] | None = None,
        caller: str = "",
    ) -> dict:
        """Generate text through the shared LLM gateway from sync workers."""
        payload: dict[str, Any] = {
            "prompt": prompt,
            "model": model,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        if system:
            payload["system"] = system
        if history:
            payload["history"] = history
        headers = {"X-Caller": caller} if caller else None
        return self._post("/llm/generate", payload, headers=headers)

    def models_status(self) -> dict:
        return self._get("/models")

    def capabilities(self) -> dict:
        return self._get("/capabilities")

    def capabilities_snapshot(self) -> ComputeCapabilitiesSnapshot:
        """Return the typed capability snapshot without changing the raw API."""
        try:
            return ComputeCapabilitiesSnapshot.from_mapping(self.capabilities())
        except ValueError as exc:
            raise ComputeError(f"QazCompute returned an invalid capabilities contract: {exc}") from exc

    def health(self) -> dict:
        return self._request_with_retry("GET", "/health")

    def submit_job(
        self,
        *,
        task: str,
        texts: list[str],
        options: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
    ) -> dict:
        payload: dict[str, Any] = {"task": task, "texts": texts, "options": options or {}}
        if idempotency_key:
            payload["idempotency_key"] = idempotency_key
        return self._post("/jobs", payload)

    def job_status(self, job_id: str) -> dict:
        if not job_id.strip():
            raise ValueError("job_id must not be empty")
        return self._get(f"/jobs/{job_id}")

    def get_job(self, job_id: str) -> dict:
        """Backward-compatible alias for :meth:`job_status`."""
        return self.job_status(job_id)
