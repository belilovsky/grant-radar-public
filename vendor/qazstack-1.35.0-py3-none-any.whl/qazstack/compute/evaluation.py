"""Provider-neutral retrieval evaluation primitives."""

from __future__ import annotations

from collections.abc import Callable, Iterable, Sequence
from dataclasses import dataclass
from typing import TypeVar

T = TypeVar("T")


@dataclass(frozen=True, slots=True)
class RetrievalMetrics:
    total: int
    found: int
    mean_reciprocal_rank: float
    hit_rate_at: tuple[tuple[int, float], ...]

    @property
    def hit_rate(self) -> float:
        return self.found / self.total if self.total else 0.0

    def as_dict(self) -> dict[str, object]:
        return {
            "total": self.total,
            "found": self.found,
            "hit_rate": round(self.hit_rate, 4),
            "mrr": round(self.mean_reciprocal_rank, 4),
            "hit_rate_at": {str(k): round(value, 4) for k, value in self.hit_rate_at},
        }


def first_relevant_rank(items: Iterable[T], is_relevant: Callable[[T], bool]) -> int | None:
    """Return the one-based rank of the first relevant item."""
    for rank, item in enumerate(items, 1):
        if is_relevant(item):
            return rank
    return None


def retrieval_metrics(
    ranks: Sequence[int | None],
    *,
    cutoffs: Sequence[int] = (1, 3, 5),
) -> RetrievalMetrics:
    """Aggregate MRR and Hit@K from one-based relevant ranks."""
    if any(rank is not None and rank < 1 for rank in ranks):
        raise ValueError("ranks must be positive or None")
    normalized_cutoffs = tuple(dict.fromkeys(cutoffs))
    if any(cutoff < 1 for cutoff in normalized_cutoffs):
        raise ValueError("cutoffs must be positive")
    total = len(ranks)
    found = sum(rank is not None for rank in ranks)
    mrr = sum(1.0 / rank for rank in ranks if rank is not None) / total if total else 0.0
    hit_rate_at = tuple(
        (
            cutoff,
            sum(rank is not None and rank <= cutoff for rank in ranks) / total if total else 0.0,
        )
        for cutoff in normalized_cutoffs
    )
    return RetrievalMetrics(total, found, mrr, hit_rate_at)


def percentile(values: Sequence[float], fraction: float) -> float:
    """Return the nearest-rank value used by lightweight latency gates."""
    if not 0 <= fraction <= 1:
        raise ValueError("fraction must be between zero and one")
    if not values:
        return 0.0
    ordered = sorted(values)
    index = min(len(ordered) - 1, max(0, round((len(ordered) - 1) * fraction)))
    return ordered[index]


__all__ = ["RetrievalMetrics", "first_relevant_rank", "percentile", "retrieval_metrics"]
