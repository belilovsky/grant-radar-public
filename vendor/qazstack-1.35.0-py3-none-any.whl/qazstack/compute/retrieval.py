"""Comparable vector retrieval query and ranked hit contracts."""

from __future__ import annotations

from dataclasses import dataclass, replace

from qazstack.contracts._validation import require_positive, require_text


@dataclass(frozen=True, slots=True)
class RetrievalQuery:
    text: str
    limit: int = 10
    filters: tuple[tuple[str, str], ...] = ()

    def __post_init__(self) -> None:
        require_text(self.text, "text")
        require_positive(self.limit, "limit")
        if len({key for key, _ in self.filters}) != len(self.filters):
            raise ValueError("filter keys must be unique")


@dataclass(frozen=True, slots=True)
class RetrievalHit:
    item_id: str
    score: float
    source_ref: str
    rank: int = 0

    def __post_init__(self) -> None:
        require_text(self.item_id, "item_id")
        require_text(self.source_ref, "source_ref")
        if not 0 <= self.score <= 1:
            raise ValueError("score must be between 0 and 1")
        require_positive(self.rank, "rank", allow_zero=True)


def rank_retrieval_hits(hits: tuple[RetrievalHit, ...], *, limit: int | None = None) -> tuple[RetrievalHit, ...]:
    """Assign deterministic one-based ranks using item_id as the tie-breaker."""
    if limit is not None:
        require_positive(limit, "limit")
    ordered = sorted(hits, key=lambda item: (-item.score, item.item_id))
    if limit is not None:
        ordered = ordered[:limit]
    return tuple(replace(item, rank=index) for index, item in enumerate(ordered, start=1))
