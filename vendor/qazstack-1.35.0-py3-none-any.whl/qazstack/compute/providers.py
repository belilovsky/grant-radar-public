"""OpenAI-compatible text LLM provider resolution.

The helpers are intentionally transport-agnostic: they only normalize
environment configuration and return ordered provider candidates. Consumer
projects remain responsible for request payloads and response parsing.
"""

from __future__ import annotations

import os
from collections.abc import Mapping
from dataclasses import dataclass

DEFAULT_DEEPSEEK_CHAT_COMPLETIONS_URL = "https://api.deepseek.com/v1/chat/completions"
DEFAULT_OPENAI_CHAT_COMPLETIONS_URL = "https://api.openai.com/v1/chat/completions"
_TRUTHY = frozenset({"1", "true", "yes", "on"})


@dataclass(frozen=True, slots=True)
class TextLLMProvider:
    """Resolved OpenAI-compatible text generation provider."""

    name: str
    api_key: str
    api_url: str
    model: str


def _environment(env: Mapping[str, str] | None) -> Mapping[str, str]:
    return os.environ if env is None else env


def normalize_chat_url(raw: str | None, default: str) -> str:
    """Normalize a provider base URL into a chat-completions endpoint."""
    value = (raw or default).strip()
    if not value:
        return default
    normalized = value.rstrip("/")
    if normalized.endswith(("/chat/completions", "/responses")):
        return normalized
    if normalized.endswith("/v1"):
        return f"{normalized}/chat/completions"
    if normalized in {"https://api.deepseek.com", "https://api.openai.com"}:
        return f"{normalized}/v1/chat/completions"
    return normalized


def resolve_text_llm_api_key(*, env: Mapping[str, str] | None = None) -> str:
    values = _environment(env)
    return (values.get("DEEPSEEK_API_KEY") or values.get("OPENAI_API_KEY") or "").strip()


def resolve_llm_api_url(
    default: str | None = None,
    *,
    env: Mapping[str, str] | None = None,
) -> str:
    values = _environment(env)
    if default is None:
        default = (
            DEFAULT_DEEPSEEK_CHAT_COMPLETIONS_URL
            if values.get("DEEPSEEK_API_KEY")
            else DEFAULT_OPENAI_CHAT_COMPLETIONS_URL
        )
    return normalize_chat_url(values.get("LLM_API_URL"), default)


def resolve_openai_base_url(
    default: str | None = None,
    *,
    env: Mapping[str, str] | None = None,
) -> str:
    chat_url = resolve_llm_api_url(default, env=env)
    for suffix in ("/chat/completions", "/responses"):
        if chat_url.endswith(suffix):
            return chat_url[: -len(suffix)]
    return chat_url


def resolve_llm_model(default: str, *, env: Mapping[str, str] | None = None) -> str:
    values = _environment(env)
    configured = (values.get("ENRICHMENT_MODEL") or "").strip()
    if configured:
        return configured
    if values.get("DEEPSEEK_API_KEY") and default.startswith("gpt-"):
        return "deepseek-chat"
    return default


def detect_text_llm_provider(*, env: Mapping[str, str] | None = None) -> str:
    values = _environment(env)
    if values.get("DEEPSEEK_API_KEY"):
        return "DeepSeek"
    if values.get("OPENAI_API_KEY"):
        return "OpenAI"
    return "LLM"


def text_llm_fallback_enabled(*, env: Mapping[str, str] | None = None) -> bool:
    values = _environment(env)
    return values.get("TEXT_LLM_ENABLE_FALLBACK", "true").strip().lower() in _TRUTHY


def resolve_text_llm_candidates(
    default_model: str,
    *,
    env: Mapping[str, str] | None = None,
) -> list[TextLLMProvider]:
    """Return ordered DeepSeek/OpenAI candidates from environment settings."""
    values = _environment(env)
    candidates: list[TextLLMProvider] = []
    deepseek_key = (values.get("DEEPSEEK_API_KEY") or "").strip()
    openai_key = (values.get("OPENAI_API_KEY") or "").strip()

    if deepseek_key:
        candidates.append(
            TextLLMProvider(
                name="DeepSeek",
                api_key=deepseek_key,
                api_url=normalize_chat_url(
                    values.get("LLM_API_URL"),
                    DEFAULT_DEEPSEEK_CHAT_COMPLETIONS_URL,
                ),
                model=resolve_llm_model(default_model, env=values),
            )
        )

    if openai_key and openai_key != deepseek_key and (not candidates or text_llm_fallback_enabled(env=values)):
        candidates.append(
            TextLLMProvider(
                name="OpenAI",
                api_key=openai_key,
                api_url=normalize_chat_url(
                    values.get("OPENAI_LLM_API_URL"),
                    DEFAULT_OPENAI_CHAT_COMPLETIONS_URL,
                ),
                model=(values.get("OPENAI_FALLBACK_MODEL") or default_model).strip(),
            )
        )

    return candidates
