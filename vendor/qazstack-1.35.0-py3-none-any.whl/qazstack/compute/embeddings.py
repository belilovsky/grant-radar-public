"""Cached batching client for sidecar and OpenAI-compatible embeddings."""

from __future__ import annotations

import asyncio
import hashlib
import os
import threading
import time
from collections import OrderedDict
from collections.abc import Sequence

import httpx

EMBEDDINGS_BACKEND = os.environ.get("EMBEDDINGS_BACKEND", "sidecar")
EMBEDDINGS_SIDECAR_URL = os.environ.get("EMBEDDINGS_SIDECAR_URL", "http://embeddings:8100")
SIDECAR_TIMEOUT = float(os.environ.get("EMBEDDINGS_SIDECAR_TIMEOUT", "8.0"))
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "")
OPENAI_EMBEDDINGS_MODEL = os.environ.get("OPENAI_EMBEDDINGS_MODEL", "text-embedding-3-small")
OPENAI_EMBEDDINGS_URL = os.environ.get("OPENAI_EMBEDDINGS_URL", "https://api.openai.com/v1/embeddings")
MAX_BATCH = int(os.environ.get("EMBEDDINGS_MAX_BATCH", "32"))
CACHE_SIZE = int(os.environ.get("EMBEDDINGS_CACHE_SIZE", "10000"))
RETRY_DELAYS = (1.0, 3.0, 8.0)


def _cache_key(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


class LRUVectorCache:
    """Thread-safe bounded in-process vector cache."""

    def __init__(self, maxsize: int) -> None:
        self._maxsize = max(0, maxsize)
        self._data: OrderedDict[str, list[float]] = OrderedDict()
        self._lock = threading.Lock()

    def get(self, text: str) -> list[float] | None:
        key = _cache_key(text)
        with self._lock:
            vector = self._data.get(key)
            if vector is not None:
                self._data.move_to_end(key)
            return vector

    def put(self, text: str, vector: list[float]) -> None:
        if not self._maxsize:
            return
        key = _cache_key(text)
        with self._lock:
            self._data[key] = vector
            self._data.move_to_end(key)
            while len(self._data) > self._maxsize:
                self._data.popitem(last=False)

    def clear(self) -> None:
        with self._lock:
            self._data.clear()

    @property
    def size(self) -> int:
        with self._lock:
            return len(self._data)


class EmbeddingsClient:
    """Synchronous core with an asynchronous thread-offload wrapper."""

    def __init__(
        self,
        *,
        backend: str = EMBEDDINGS_BACKEND,
        sidecar_url: str = EMBEDDINGS_SIDECAR_URL,
        sidecar_timeout: float = SIDECAR_TIMEOUT,
        openai_api_key: str = OPENAI_API_KEY,
        openai_model: str = OPENAI_EMBEDDINGS_MODEL,
        openai_url: str = OPENAI_EMBEDDINGS_URL,
        max_batch: int = MAX_BATCH,
        cache_size: int = CACHE_SIZE,
        retry_delays: Sequence[float] = RETRY_DELAYS,
        client_factory=httpx.Client,
        sleep=time.sleep,
    ) -> None:
        self.backend = backend.strip().lower()
        self.sidecar_url = sidecar_url.rstrip("/")
        self.sidecar_timeout = sidecar_timeout
        self.openai_api_key = openai_api_key
        self.openai_model = openai_model
        self.openai_url = openai_url
        self.max_batch = max(1, max_batch)
        self.retry_delays = tuple(retry_delays)
        self.cache = LRUVectorCache(cache_size)
        self._client_factory = client_factory
        self._sleep = sleep
        self._clients: dict[str, httpx.Client] = {}
        self._client_lock = threading.Lock()

    @classmethod
    def from_env(cls) -> "EmbeddingsClient":
        return cls(
            backend=os.environ.get("EMBEDDINGS_BACKEND", "sidecar"),
            sidecar_url=os.environ.get("EMBEDDINGS_SIDECAR_URL", "http://embeddings:8100"),
            sidecar_timeout=float(os.environ.get("EMBEDDINGS_SIDECAR_TIMEOUT", "8.0")),
            openai_api_key=os.environ.get("OPENAI_API_KEY", ""),
            openai_model=os.environ.get("OPENAI_EMBEDDINGS_MODEL", "text-embedding-3-small"),
            openai_url=os.environ.get("OPENAI_EMBEDDINGS_URL", "https://api.openai.com/v1/embeddings"),
            max_batch=int(os.environ.get("EMBEDDINGS_MAX_BATCH", "32")),
            cache_size=int(os.environ.get("EMBEDDINGS_CACHE_SIZE", "10000")),
        )

    def close(self) -> None:
        with self._client_lock:
            clients = list(self._clients.values())
            self._clients.clear()
        for client in clients:
            client.close()

    def _client(self, backend: str) -> httpx.Client:
        with self._client_lock:
            client = self._clients.get(backend)
            if client is None:
                timeout = self.sidecar_timeout if backend == "sidecar" else 30.0
                client = self._client_factory(timeout=timeout)
                self._clients[backend] = client
            return client

    @staticmethod
    def _validate_vectors(vectors: object, expected: int, source: str) -> list[list[float]]:
        if not isinstance(vectors, list) or len(vectors) != expected:
            actual = len(vectors) if isinstance(vectors, list) else 0
            raise ValueError(f"{source} returned {actual} vectors for {expected} texts")
        return [[float(value) for value in vector] for vector in vectors]

    def _embed_sidecar(self, texts: list[str]) -> list[list[float]]:
        response = self._client("sidecar").post(
            f"{self.sidecar_url}/embed",
            json={"texts": texts, "normalize": True},
        )
        try:
            response.raise_for_status()
        except httpx.HTTPStatusError:
            if response.status_code == 413 and len(texts) > 1:
                split_at = max(1, len(texts) // 2)
                return [
                    *self._embed_sidecar(texts[:split_at]),
                    *self._embed_sidecar(texts[split_at:]),
                ]
            raise
        payload = response.json()
        vectors = payload.get("vectors") if isinstance(payload, dict) else None
        return self._validate_vectors(vectors, len(texts), "sidecar")

    def _embed_openai(self, texts: list[str]) -> list[list[float]]:
        if not self.openai_api_key:
            raise RuntimeError("OPENAI_API_KEY is not set but EMBEDDINGS_BACKEND=openai")
        last_error: Exception | None = None
        for delay in (0.0, *self.retry_delays):
            if delay:
                self._sleep(delay)
            try:
                response = self._client("openai").post(
                    self.openai_url,
                    headers={"Authorization": f"Bearer {self.openai_api_key}"},
                    json={"input": texts, "model": self.openai_model},
                )
                response.raise_for_status()
                payload = response.json()
                items = payload.get("data") if isinstance(payload, dict) else None
                if not isinstance(items, list):
                    raise ValueError("OpenAI embeddings response has no data list")
                items = sorted(items, key=lambda item: item["index"])
                return self._validate_vectors(
                    [item["embedding"] for item in items],
                    len(texts),
                    "OpenAI",
                )
            except httpx.HTTPStatusError as exc:
                last_error = exc
                if exc.response.status_code not in {429, 500, 502, 503, 504}:
                    raise
            except httpx.HTTPError as exc:
                last_error = exc
        raise RuntimeError(f"OpenAI embeddings failed after retries: {last_error}") from last_error

    def _backend(self):
        if self.backend == "sidecar":
            return self._embed_sidecar
        if self.backend == "openai":
            return self._embed_openai
        raise ValueError("Unknown embeddings backend. Expected 'sidecar' or 'openai'")

    def embed_sync(self, texts: Sequence[str]) -> list[list[float]]:
        if not texts:
            return []
        values = list(texts)
        results: list[list[float] | None] = [None] * len(values)
        missing: list[int] = []
        for index, text in enumerate(values):
            cached = self.cache.get(text)
            if cached is None:
                missing.append(index)
            else:
                results[index] = cached

        backend = self._backend()
        missing_texts = [values[index] for index in missing]
        vectors: list[list[float]] = []
        for start in range(0, len(missing_texts), self.max_batch):
            vectors.extend(backend(missing_texts[start : start + self.max_batch]))
        if len(vectors) != len(missing):
            raise ValueError(f"embeddings backend returned {len(vectors)} vectors for {len(missing)} texts")

        for vector, index in zip(vectors, missing, strict=True):
            results[index] = vector
            self.cache.put(values[index], vector)
        return [vector for vector in results if vector is not None]

    async def embed(self, texts: Sequence[str]) -> list[list[float]]:
        return await asyncio.to_thread(self.embed_sync, texts)


_default_client: EmbeddingsClient | None = None
_default_lock = threading.Lock()


def get_default_embeddings_client() -> EmbeddingsClient:
    global _default_client
    with _default_lock:
        if _default_client is None:
            _default_client = EmbeddingsClient.from_env()
        return _default_client


def reset_default_embeddings_client() -> None:
    global _default_client
    with _default_lock:
        client = _default_client
        _default_client = None
    if client is not None:
        client.close()


def embed_sync(texts: Sequence[str]) -> list[list[float]]:
    return get_default_embeddings_client().embed_sync(texts)


async def embed(texts: Sequence[str]) -> list[list[float]]:
    return await get_default_embeddings_client().embed(texts)
