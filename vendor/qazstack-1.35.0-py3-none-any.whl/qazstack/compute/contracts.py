"""Portable provenance and truthful capability contracts for QazCompute."""

from __future__ import annotations

import hashlib
from collections.abc import Mapping, Sequence
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from typing import Any

from qazstack.contracts._validation import (
    require_aware,
    require_identifier,
    require_one_of,
    require_positive,
    require_semver,
    require_sha256,
    require_text,
)

PROCESS_SCHEMA_VERSION = "qazcompute-process-v2"
TASK_STATUSES = frozenset({"succeeded", "failed"})
QUALITY_TIERS = frozenset({"verified", "estimated", "degraded", "unknown"})
CAPABILITY_STATUSES = frozenset({"available", "degraded", "unavailable"})
CAPABILITY_QUALITY_TIERS = frozenset({"verified", "estimated", "degraded", "unavailable"})
SNAPSHOT_STATUSES = frozenset({"ok", "degraded", "unavailable"})
CAPABILITIES_SCHEMA_VERSION = "qazcompute-capabilities-v1"
JOBS_SCHEMA_VERSION = "qazcompute-job-v1"


@dataclass(frozen=True, slots=True)
class ComputeTaskExecution:
    """One multi-task execution outcome without retaining source content."""

    task: str
    status: str
    provider: str
    model: str | None = None
    quality_tier: str = "unknown"
    error: str | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "task", require_identifier(self.task, "task"))
        if self.status not in TASK_STATUSES:
            raise ValueError(f"status must be one of: {', '.join(sorted(TASK_STATUSES))}")
        object.__setattr__(self, "provider", require_identifier(self.provider, "provider"))
        if self.model is not None:
            object.__setattr__(self, "model", require_text(self.model, "model"))
        if self.quality_tier not in QUALITY_TIERS:
            raise ValueError(f"quality_tier must be one of: {', '.join(sorted(QUALITY_TIERS))}")
        if self.status == "failed" and not self.error:
            raise ValueError("failed task executions require an error")
        if self.status == "succeeded" and self.error is not None:
            raise ValueError("successful task executions must not include an error")

    def as_dict(self) -> dict[str, object]:
        """Serialize the execution contract."""
        return asdict(self)


def input_text_digest(text: str) -> str:
    """Return a content-safe identity without echoing source text into provenance."""
    if not isinstance(text, str) or not text.strip():
        raise ValueError("text must be a non-empty string")
    return f"sha256:{hashlib.sha256(text.encode('utf-8')).hexdigest()}"


def process_provenance(
    *,
    service_version: str,
    texts: Sequence[str],
    tasks: Sequence[ComputeTaskExecution],
    generated_at: datetime | None = None,
) -> dict[str, object]:
    """Build the stable provenance portion of a multi-task response."""
    version = require_semver(service_version, "service_version")
    task_names = [item.task for item in tasks]
    if len(task_names) != len(set(task_names)):
        raise ValueError("task executions must be unique")
    observed_at = generated_at or datetime.now(timezone.utc)
    if observed_at.tzinfo is None or observed_at.utcoffset() is None:
        raise ValueError("generated_at must be timezone-aware")
    return {
        "schema_version": PROCESS_SCHEMA_VERSION,
        "service_version": version,
        "generated_at": observed_at.astimezone(timezone.utc).isoformat().replace("+00:00", "Z"),
        "input_digests": [input_text_digest(text) for text in texts],
        "task_status": [item.as_dict() for item in tasks],
    }


def validate_process_provenance(payload: Mapping[str, Any], *, text_count: int | None = None) -> None:
    """Validate portable multi-task provenance while leaving task payloads opaque."""
    if payload.get("schema_version") != PROCESS_SCHEMA_VERSION:
        raise ValueError(f"schema_version must be {PROCESS_SCHEMA_VERSION}")
    require_semver(str(payload.get("service_version", "")), "service_version")
    try:
        generated_at = datetime.fromisoformat(str(payload["generated_at"]).replace("Z", "+00:00"))
    except (KeyError, ValueError) as exc:
        raise ValueError("generated_at must be an ISO-8601 datetime") from exc
    if generated_at.tzinfo is None or generated_at.utcoffset() is None:
        raise ValueError("generated_at must be timezone-aware")

    input_digests = payload.get("input_digests")
    if not isinstance(input_digests, Sequence) or isinstance(input_digests, (str, bytes)):
        raise ValueError("input_digests must be an array")
    for digest in input_digests:
        require_sha256(str(digest), "input_digest")
    if text_count is not None and len(input_digests) != text_count:
        raise ValueError("input_digests must match the input text count")

    raw_tasks = payload.get("task_status")
    if not isinstance(raw_tasks, Sequence) or isinstance(raw_tasks, (str, bytes)):
        raise ValueError("task_status must be an array")
    executions = tuple(ComputeTaskExecution(**dict(item)) for item in raw_tasks)
    names = [item.task for item in executions]
    if len(names) != len(set(names)):
        raise ValueError("task executions must be unique")


def _datetime(value: object, field_name: str) -> datetime:
    if isinstance(value, datetime):
        parsed = value
    elif isinstance(value, str):
        try:
            parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError as exc:
            raise ValueError(f"{field_name} must be an ISO-8601 timestamp") from exc
    else:
        raise ValueError(f"{field_name} must be an ISO-8601 timestamp")
    require_aware(parsed, field_name)
    return parsed


def _optional_datetime(value: object, field_name: str) -> datetime | None:
    return None if value is None else _datetime(value, field_name)


@dataclass(frozen=True, slots=True)
class ComputeCapabilityHealth:
    """Truthful status and effective provider for one compute capability."""

    name: str
    status: str
    provider: str
    model: str
    quality_tier: str
    checked_at: datetime
    version: str | None = None
    last_success_at: datetime | None = None
    detail: str = ""

    def __post_init__(self) -> None:
        require_identifier(self.name, "name")
        require_one_of(self.status, CAPABILITY_STATUSES, "status")
        require_text(self.provider, "provider")
        require_text(self.model, "model")
        require_one_of(self.quality_tier, CAPABILITY_QUALITY_TIERS, "quality_tier")
        require_aware(self.checked_at, "checked_at")
        if self.version is not None:
            require_text(self.version, "version")
        if self.last_success_at is not None:
            require_aware(self.last_success_at, "last_success_at")
        require_text(self.detail, "detail")
        expected_tier = {"degraded": "degraded", "unavailable": "unavailable"}.get(self.status)
        if expected_tier is not None and self.quality_tier != expected_tier:
            raise ValueError(f"{self.status} capabilities require quality_tier={expected_tier}")
        if self.status == "available" and self.quality_tier not in {"verified", "estimated"}:
            raise ValueError("available capabilities require verified or estimated quality")

    @property
    def usable(self) -> bool:
        """Return whether a caller can invoke the capability at its stated tier."""
        return self.status != "unavailable"

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> ComputeCapabilityHealth:
        """Parse and validate one QazCompute capability payload."""
        return cls(
            name=str(value.get("name") or ""),
            status=str(value.get("status") or ""),
            provider=str(value.get("provider") or ""),
            model=str(value.get("model") or ""),
            quality_tier=str(value.get("quality_tier") or ""),
            checked_at=_datetime(value.get("checked_at"), "checked_at"),
            version=str(value["version"]) if value.get("version") is not None else None,
            last_success_at=_optional_datetime(value.get("last_success_at"), "last_success_at"),
            detail=str(value.get("detail") or ""),
        )


@dataclass(frozen=True, slots=True)
class ComputeJobCapabilities:
    """Advertised bounds and profiles for the existing resumable job runtime."""

    enabled: bool
    max_texts: int
    tasks: tuple[str, ...]
    schema_version: str = JOBS_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.schema_version != JOBS_SCHEMA_VERSION:
            raise ValueError(f"schema_version must be {JOBS_SCHEMA_VERSION}")
        if not isinstance(self.enabled, bool):
            raise ValueError("enabled must be a boolean")
        require_positive(self.max_texts, "max_texts")
        if not self.tasks or len(self.tasks) != len(set(self.tasks)):
            raise ValueError("job tasks must be non-empty and unique")
        for task in self.tasks:
            require_identifier(task, "task")

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> ComputeJobCapabilities:
        """Parse job capability metadata without creating a second queue contract."""
        raw_tasks = value.get("tasks")
        enabled = value.get("enabled")
        max_texts = value.get("max_texts")
        if not isinstance(raw_tasks, Sequence) or isinstance(raw_tasks, (str, bytes)):
            raise ValueError("jobs.tasks must be an array")
        if not isinstance(enabled, bool):
            raise ValueError("jobs.enabled must be a boolean")
        if not isinstance(max_texts, int) or isinstance(max_texts, bool):
            raise ValueError("jobs.max_texts must be an integer")
        return cls(
            enabled=enabled,
            max_texts=max_texts,
            tasks=tuple(str(task) for task in raw_tasks),
            schema_version=str(value.get("schema_version") or ""),
        )


@dataclass(frozen=True, slots=True)
class ComputeCapabilitiesSnapshot:
    """Point-in-time set of effective QazCompute capabilities."""

    schema_version: str
    status: str
    checked_at: datetime
    capabilities: tuple[ComputeCapabilityHealth, ...]
    jobs: ComputeJobCapabilities

    def __post_init__(self) -> None:
        if self.schema_version != CAPABILITIES_SCHEMA_VERSION:
            raise ValueError(f"schema_version must be {CAPABILITIES_SCHEMA_VERSION}")
        require_one_of(self.status, SNAPSHOT_STATUSES, "status")
        require_aware(self.checked_at, "checked_at")
        names = [item.name for item in self.capabilities]
        if len(names) != len(set(names)):
            raise ValueError("capability names must be unique")
        if any(item.checked_at != self.checked_at for item in self.capabilities):
            raise ValueError("capability checked_at must match snapshot checked_at")

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> ComputeCapabilitiesSnapshot:
        """Parse and validate the protected QazCompute capability endpoint."""
        raw_capabilities = value.get("capabilities")
        raw_jobs = value.get("jobs")
        if not isinstance(raw_capabilities, Sequence) or isinstance(raw_capabilities, (str, bytes)):
            raise ValueError("capabilities must be an array")
        if not isinstance(raw_jobs, Mapping):
            raise ValueError("jobs must be an object")
        capabilities = tuple(
            ComputeCapabilityHealth.from_mapping(item) for item in raw_capabilities if isinstance(item, Mapping)
        )
        if len(capabilities) != len(raw_capabilities):
            raise ValueError("each capability must be an object")
        return cls(
            schema_version=str(value.get("schema_version") or ""),
            status=str(value.get("status") or ""),
            checked_at=_datetime(value.get("checked_at"), "checked_at"),
            capabilities=capabilities,
            jobs=ComputeJobCapabilities.from_mapping(raw_jobs),
        )


__all__ = [
    "CAPABILITIES_SCHEMA_VERSION",
    "JOBS_SCHEMA_VERSION",
    "PROCESS_SCHEMA_VERSION",
    "ComputeCapabilitiesSnapshot",
    "ComputeCapabilityHealth",
    "ComputeJobCapabilities",
    "ComputeTaskExecution",
    "input_text_digest",
    "process_provenance",
    "validate_process_provenance",
]
