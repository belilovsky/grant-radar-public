"""Small async boundary for synchronous CPU-heavy fallback work."""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from concurrent.futures import Executor
from functools import partial
from typing import Any, TypeVar

ResultT = TypeVar("ResultT")


async def run_cpu_bound(
    function: Callable[..., ResultT],
    /,
    *args: Any,
    executor: Executor | None = None,
    **kwargs: Any,
) -> ResultT:
    """Run synchronous fallback work without blocking the event loop.

    The default path uses ``asyncio.to_thread`` and preserves context variables.
    Consumers may supply a thread or process executor when they own its lifecycle.
    Cancelling the await does not forcibly stop work already running in an executor.
    """

    call = partial(function, *args, **kwargs)
    if executor is None:
        return await asyncio.to_thread(call)
    return await asyncio.get_running_loop().run_in_executor(executor, call)
