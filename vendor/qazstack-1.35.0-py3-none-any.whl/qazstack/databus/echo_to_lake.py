"""Echo Sounder → QazLake article sync pipeline.

Syncs articles, NLP sentiment, and NER entities from Echo Sounder DB
into the unified QazLake data lake.

Usage:
    from qazstack.databus import EchoToLakeSync

    sync = EchoToLakeSync(
        echo_dsn="postgresql+asyncpg://echo:pass@echo_sounder_db:5432/echo_sounder",
        lake_dsn="postgresql+asyncpg://qazlake:pass@qazlake_db:5432/qazlake",
    )
    result = await sync.run(batch_size=1000, since_hours=6)
"""

from __future__ import annotations

import logging
import json as _json
from datetime import datetime, timedelta, timezone

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine

from qazstack.databus.sync import SyncPipeline, SyncResult

logger = logging.getLogger(__name__)

# Echo Sounder source_api → QazLake source_type mapping
# Echo Sounder stores full language names, QazLake uses ISO codes
LANG_MAP = {
    "russian": "ru",
    "kazakh": "kk",
    "english": "en",
    "ukrainian": "uk",
    "turkish": "tr",
    "french": "fr",
    "german": "de",
    "spanish": "es",
    "arabic": "ar",
    "chinese": "zh",
    "korean": "ko",
    "japanese": "ja",
    "portuguese": "pt",
    "italian": "it",
    "persian": "fa",
    "uzbek": "uz",
    "kyrgyz": "ky",
    "tajik": "tg",
    "belarusian": "be",
    "lithuanian": "lt",
    "latvian": "lv",
    "estonian": "et",
    "georgian": "ka",
    "azerbaijani": "az",
    "armenian": "hy",
    "mongolian": "mn",
    "hindi": "hi",
    "dutch": "nl",
    "polish": "pl",
    "czech": "cs",
    "romanian": "ro",
    "bulgarian": "bg",
    "hungarian": "hu",
    "swedish": "sv",
    "finnish": "fi",
    "danish": "da",
    "norwegian": "no",
    "hebrew": "he",
    "thai": "th",
    "vietnamese": "vi",
    "indonesian": "id",
    "malay": "ms",
    "filipino": "tl",
    "serbian": "sr",
    "croatian": "hr",
    "slovak": "sk",
    "slovenian": "sl",
    "greek": "el",
    "albanian": "sq",
    "macedonian": "mk",
    "bosnian": "bs",
    "swahili": "sw",
    "urdu": "ur",
    "bengali": "bn",
    "tamil": "ta",
    "nepali": "ne",
    "pashto": "ps",
    "kurdish": "ku",
    "somali": "so",
    "amharic": "am",
    "ru": "ru",
    "kk": "kk",
    "en": "en",
}


def _norm_lang(raw: str | None) -> str:
    """Normalize language to 2-letter ISO code (max 8 chars for DB)."""
    if not raw:
        return "ru"
    lower = raw.strip().lower()
    code = LANG_MAP.get(lower)
    if code:
        return code
    # If already a short code, use it; otherwise default to 'xx'
    if len(lower) <= 3:
        return lower
    return "xx"


SOURCE_TYPE_MAP = {
    "kz_sitemap": "sitemap",
    "kz_rss": "rss",
    "qazlake_rss": "rss",
    "total_kz": "sitemap",
    "npa": "npa",
    "ortcom": "scraper",
    "telegraph": "social",
    "youtube": "social",
    "gdelt": "aggregator",
    "gdelt_backfill": "aggregator",
    "gdelt_doc": "aggregator",
    "sitemap_backfill": "sitemap",
    "newsdata": "aggregator",
    "worldnews": "aggregator",
    "gnews": "aggregator",
    "rss": "rss",
    "thenewsapi": "aggregator",
    "kz_archive": "archive",
    "wayback": "archive",
    "livejournal": "social",
}


class EchoToLakeSync(SyncPipeline):
    """Sync articles from Echo Sounder to QazLake."""

    name = "echo-to-lake"

    def __init__(self, echo_dsn: str, lake_dsn: str):
        self._echo_engine = create_async_engine(echo_dsn, pool_size=5, pool_pre_ping=True)
        self._lake_engine = create_async_engine(lake_dsn, pool_size=5, pool_pre_ping=True)

    async def run(
        self,
        *,
        batch_size: int = 1000,
        since_hours: int = 6,
        full_sync: bool = False,
    ) -> SyncResult:
        """Run the sync pipeline.

        Args:
            batch_size: Number of articles per batch.
            since_hours: Only sync articles from the last N hours (ignored if full_sync).
            full_sync: If True, sync ALL articles (expensive, use for initial load).
        """
        result = SyncResult(pipeline=self.name)

        try:
            # Step 1: Ensure raw_sources exist in QazLake
            result.sources_created = await self._sync_sources()

            # Step 2: Sync articles
            result.articles_synced = await self._sync_articles(
                batch_size=batch_size,
                since_hours=since_hours,
                full_sync=full_sync,
            )

            # Step 3: Sync NLP sentiment for new articles
            result.nlp_synced = await self._sync_nlp_sentiment()

            # Step 4: Sync NLP entities for new articles
            result.entities_synced = await self._sync_entities()

        except Exception as e:
            logger.exception("Sync pipeline failed")
            result.errors.append(str(e))

        return result.finish()

    async def _sync_sources(self) -> int:
        """Create raw_sources entries in QazLake for each Echo Sounder domain."""
        created = 0

        async with self._echo_engine.begin() as echo_conn:
            rows = await echo_conn.execute(
                text("""
                    SELECT DISTINCT domain, source_api
                    FROM article
                    WHERE domain IS NOT NULL AND domain != ''
                      AND domain ~ '^[a-zA-Z0-9._-]+$'
                      AND length(domain) <= 50
                """)
            )
            echo_domains = rows.fetchall()

        async with self._lake_engine.begin() as lake_conn:
            existing = await lake_conn.execute(text("SELECT slug FROM raw_sources"))
            existing_slugs = {r[0] for r in existing.fetchall()}

            for domain, source_api in echo_domains:
                slug = f"echo_{domain}"[:64]
                if slug in existing_slugs:
                    continue
                source_type = SOURCE_TYPE_MAP.get(source_api or "", "web")
                name = f"Echo: {domain}"[:255]
                await lake_conn.execute(
                    text("""
                        INSERT INTO raw_sources (slug, name, base_url, source_type, config)
                        VALUES (:slug, :name, :base_url, :source_type, :config)
                        ON CONFLICT (slug) DO NOTHING
                    """),
                    {
                        "slug": slug,
                        "name": name,
                        "base_url": f"https://{domain}" if "." in domain else "",
                        "source_type": source_type,
                        "config": '{"origin": "echo-sounder"}',
                    },
                )
                existing_slugs.add(slug)
                created += 1

        if created:
            logger.info("Created %d new raw_sources in QazLake", created)
        return created

    async def _sync_articles(
        self, *, batch_size: int, since_hours: int, full_sync: bool
    ) -> int:
        """Sync articles from Echo Sounder to QazLake.

        Handles two UNIQUE constraints in QazLake articles:
          1. articles_source_id_external_id_key (source_id, external_id)
          2. articles_url_key (url)

        Strategy: upsert on (source_id, external_id) as the natural key.
        For URL conflicts, catch the exception and skip the row (the URL
        already exists from a different source – not our article to update).
        """
        synced = 0
        skipped = 0

        # Build source_id lookup: echo domain → lake raw_sources.id
        source_map = await self._build_source_map()

        cutoff = None if full_sync else datetime.now(timezone.utc) - timedelta(hours=since_hours)

        offset = 0
        while True:
            # Fetch batch from Echo Sounder
            async with self._echo_engine.begin() as echo_conn:
                params: dict = {"limit": batch_size, "offset": offset}
                where = "WHERE domain IS NOT NULL AND domain != '' AND domain ~ '^[a-zA-Z0-9._-]+$'"
                if cutoff:
                    where += " AND collected_at >= :cutoff"
                    params["cutoff"] = cutoff

                rows = await echo_conn.execute(
                    text(f"""
                        SELECT id, domain, title, date, text, url, language,
                               source_api, country_source, collected_at, raw_json,
                               tone_normalized
                        FROM article
                        {where}
                        ORDER BY id
                        LIMIT :limit OFFSET :offset
                    """),
                    params,
                )
                articles = rows.fetchall()

            if not articles:
                break

            # Upsert into QazLake
            batch_synced = 0
            async with self._lake_engine.begin() as lake_conn:
                # Pre-fetch existing URLs in this batch to avoid url_key conflicts
                batch_urls = [art[5] for art in articles if art[5]]
                if batch_urls:
                    existing_url_rows = await lake_conn.execute(
                        text("SELECT url FROM articles WHERE url = ANY(:urls)"),
                        {"urls": batch_urls},
                    )
                    existing_urls = {r[0] for r in existing_url_rows.fetchall()}
                else:
                    existing_urls = set()

                # Also pre-fetch existing (source_id, external_id) pairs
                batch_ext_ids = []
                batch_src_ids = []
                for art in articles:
                    domain = art[1]
                    sid = source_map.get(f"echo_{domain}"[:64])
                    if sid and art[5]:
                        batch_src_ids.append(sid)
                        batch_ext_ids.append(str(art[0]))
                if batch_ext_ids:
                    existing_pair_rows = await lake_conn.execute(
                        text(
                            "SELECT source_id, external_id FROM articles "
                            "WHERE external_id = ANY(:eids) "
                            "AND source_id = ANY(:sids)"
                        ),
                        {"eids": batch_ext_ids, "sids": list(set(batch_src_ids))},
                    )
                    existing_pairs = {(r[0], r[1]) for r in existing_pair_rows.fetchall()}
                else:
                    existing_pairs = set()

                for art in articles:
                    (
                        echo_id, domain, title, date, body, url, lang,
                        source_api, country, collected_at, raw_json, tone,
                    ) = art

                    source_id = source_map.get(f"echo_{domain}"[:64])
                    if not source_id:
                        continue

                    if not url:
                        continue

                    ext_id = str(echo_id)
                    pair = (source_id, ext_id)

                    if pair in existing_pairs:
                        # Already synced – skip (idempotent)
                        skipped += 1
                        continue

                    if url in existing_urls:
                        # URL owned by a different source – skip
                        skipped += 1
                        continue

                    upsert_ok = False
                    try:
                        async with lake_conn.begin_nested():
                            await lake_conn.execute(
                                text("""
                                    INSERT INTO articles (
                                        source_id, external_id, url, title, body_text,
                                        pub_date, imported_at, lang, source_name,
                                        metadata, status
                                    ) VALUES (
                                        :source_id, :external_id, :url, :title, :body_text,
                                        :pub_date, :imported_at, :lang, :source_name,
                                        :metadata, 'published'
                                    )
                                    ON CONFLICT ON CONSTRAINT articles_source_id_external_id_key
                                    DO UPDATE SET
                                        title = EXCLUDED.title,
                                        body_text = COALESCE(EXCLUDED.body_text, articles.body_text),
                                        url = EXCLUDED.url,
                                        updated_at = NOW()
                                    WHERE articles.body_text IS NULL
                                       OR LENGTH(COALESCE(EXCLUDED.body_text, '')) > LENGTH(COALESCE(articles.body_text, ''))
                                """),
                                {
                                    "source_id": source_id,
                                    "external_id": ext_id,
                                    "url": url,
                                    "title": title or "",
                                    "body_text": body,
                                    "pub_date": date,
                                    "imported_at": collected_at or datetime.now(timezone.utc),
                                    "lang": _norm_lang(lang),
                                    "source_name": domain,
                                    "metadata": _json.dumps(
                                        {"echo_id": echo_id, "tone": tone, "country": country or ""}
                                    ),
                                },
                            )
                        upsert_ok = True
                    except Exception as e:
                        err_str = str(e)
                        if "articles_url_key" in err_str or "UniqueViolation" in err_str:
                            skipped += 1
                            if skipped % 1000 == 1:
                                logger.warning(
                                    "URL conflict echo_id=%s url=%s – skipping",
                                    echo_id, url[:100],
                                )
                        else:
                            raise

                    if upsert_ok:
                        existing_urls.add(url)
                        existing_pairs.add(pair)
                        batch_synced += 1

            synced += batch_synced
            offset += batch_size
            logger.info(
                "Synced batch: %d articles (total: %d, skipped: %d)",
                batch_synced, synced, skipped,
            )

            if len(articles) < batch_size:
                break

        if skipped:
            logger.info("Total skipped due to URL conflicts: %d", skipped)
        return synced

    async def _sync_nlp_sentiment(self) -> int:
        """Sync NLP sentiment for articles that exist in QazLake but lack article_nlp."""
        synced = 0

        async with self._lake_engine.begin() as lake_conn:
            # Find QazLake articles from echo that don't have NLP yet
            missing = await lake_conn.execute(
                text("""
                    SELECT a.id, a.external_id
                    FROM articles a
                    JOIN raw_sources rs ON a.source_id = rs.id
                    LEFT JOIN article_nlp nlp ON nlp.article_id = a.id
                    WHERE rs.config::text LIKE '%echo-sounder%'
                      AND nlp.article_id IS NULL
                      AND a.external_id IS NOT NULL
                    LIMIT 5000
                """)
            )
            articles_needing_nlp = missing.fetchall()

        if not articles_needing_nlp:
            return 0

        # Build echo_id → lake_id map
        echo_to_lake = {int(row[1]): row[0] for row in articles_needing_nlp}
        echo_ids = list(echo_to_lake.keys())

        # Fetch sentiment from Echo Sounder
        async with self._echo_engine.begin() as echo_conn:
            rows = await echo_conn.execute(
                text("""
                    SELECT source_id, label, score
                    FROM nlp_sentiment
                    WHERE source_table = 'article'
                      AND source_id = ANY(:ids)
                """),
                {"ids": echo_ids},
            )
            sentiments = rows.fetchall()

        if not sentiments:
            return 0

        # Insert into QazLake article_nlp
        async with self._lake_engine.begin() as lake_conn:
            for echo_id, label, score in sentiments:
                lake_id = echo_to_lake.get(echo_id)
                if not lake_id:
                    continue
                await lake_conn.execute(
                    text("""
                        INSERT INTO article_nlp (article_id, sentiment, sentiment_score, model, processed_at)
                        VALUES (:article_id, :sentiment, :score, 'echo-sounder-sync', NOW())
                        ON CONFLICT (article_id) DO NOTHING
                    """),
                    {"article_id": lake_id, "sentiment": label, "score": score},
                )
                synced += 1

        logger.info("Synced %d NLP sentiment records", synced)
        return synced

    async def _sync_entities(self) -> int:
        """Sync NLP entities for new articles."""
        synced = 0

        async with self._lake_engine.begin() as lake_conn:
            # Find articles from echo without entities
            missing = await lake_conn.execute(
                text("""
                    SELECT a.id, a.external_id
                    FROM articles a
                    JOIN raw_sources rs ON a.source_id = rs.id
                    LEFT JOIN article_entities ae ON ae.article_id = a.id
                    WHERE rs.config::text LIKE '%echo-sounder%'
                      AND ae.article_id IS NULL
                      AND a.external_id IS NOT NULL
                    LIMIT 5000
                """)
            )
            articles_needing_entities = missing.fetchall()

        if not articles_needing_entities:
            return 0

        echo_to_lake = {int(row[1]): row[0] for row in articles_needing_entities}
        echo_ids = list(echo_to_lake.keys())

        # Fetch entities from Echo Sounder
        async with self._echo_engine.begin() as echo_conn:
            rows = await echo_conn.execute(
                text("""
                    SELECT source_id, entity_text, entity_label, confidence
                    FROM nlp_entities
                    WHERE source_table = 'article'
                      AND source_id = ANY(:ids)
                """),
                {"ids": echo_ids},
            )
            entities = rows.fetchall()

        if not entities:
            return 0

        # First ensure canonical_entities exist
        entity_id_cache: dict[str, int] = {}

        async with self._lake_engine.begin() as lake_conn:
            for echo_id, entity_text, entity_label, confidence in entities:
                lake_article_id = echo_to_lake.get(echo_id)
                if not lake_article_id:
                    continue

                # Upsert canonical entity
                cache_key = f"{entity_label}:{entity_text}"
                if cache_key not in entity_id_cache:
                    row = await lake_conn.execute(
                        text("""
                            INSERT INTO canonical_entities (
                                source_project, slug, entity_type, name_ru, created_at
                            ) VALUES (
                                'echo-sounder',
                                :slug,
                                :entity_type,
                                :name,
                                NOW()
                            )
                            ON CONFLICT (slug) DO UPDATE SET updated_at = NOW()
                            RETURNING id
                        """),
                        {
                            "slug": f"{entity_label.lower()}_{entity_text.lower().replace(' ', '_')[:60]}",
                            "entity_type": entity_label,
                            "name": entity_text,
                        },
                    )
                    entity_id_cache[cache_key] = row.scalar_one()

                entity_id = entity_id_cache[cache_key]

                # Link article ↔ entity
                await lake_conn.execute(
                    text("""
                        INSERT INTO article_entities (article_id, entity_id, relevance)
                        VALUES (:article_id, :entity_id, :relevance)
                        ON CONFLICT DO NOTHING
                    """),
                    {
                        "article_id": lake_article_id,
                        "entity_id": entity_id,
                        "relevance": confidence or 0.5,
                    },
                )
                synced += 1

        logger.info("Synced %d entity links", synced)
        return synced

    async def _build_source_map(self) -> dict[str, int]:
        """Build slug → id map from QazLake raw_sources."""
        async with self._lake_engine.begin() as conn:
            rows = await conn.execute(text("SELECT slug, id FROM raw_sources"))
            return {r[0]: r[1] for r in rows.fetchall()}

    async def close(self):
        """Close database connections."""
        await self._echo_engine.dispose()
        await self._lake_engine.dispose()
