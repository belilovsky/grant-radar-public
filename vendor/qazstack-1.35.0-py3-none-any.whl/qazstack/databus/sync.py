"""Base sync pipeline framework."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone

logger = logging.getLogger(__name__)


@dataclass
class SyncResult:
    """Result of a sync operation."""

    pipeline: str
    started_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    finished_at: datetime | None = None
    articles_synced: int = 0
    entities_synced: int = 0
    nlp_synced: int = 0
    sources_created: int = 0
    errors: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return len(self.errors) == 0

    @property
    def duration_seconds(self) -> float | None:
        if self.finished_at is None:
            return None
        return (self.finished_at - self.started_at).total_seconds()

    def finish(self) -> SyncResult:
        self.finished_at = datetime.now(timezone.utc)
        return self

    def to_dict(self) -> dict:
        return {
            "pipeline": self.pipeline,
            "ok": self.ok,
            "started_at": self.started_at.isoformat(),
            "finished_at": self.finished_at.isoformat() if self.finished_at else None,
            "duration_seconds": self.duration_seconds,
            "articles_synced": self.articles_synced,
            "entities_synced": self.entities_synced,
            "nlp_synced": self.nlp_synced,
            "sources_created": self.sources_created,
            "errors": self.errors,
        }


class SyncPipeline:
    """Base class for sync pipelines."""

    name: str = "base"

    async def run(self, **kwargs) -> SyncResult:
        raise NotImplementedError

    def __repr__(self) -> str:
        return f"<SyncPipeline:{self.name}>"
