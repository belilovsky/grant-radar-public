"""Shared DataBus contracts for QazLake-backed product integrations."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

RunStatus = Literal["started", "success", "partial", "failed", "cancelled"]
WatermarkKind = Literal["id", "timestamp", "cursor", "offset", "custom"]
QualityStatus = Literal["healthy", "warning", "critical", "unknown"]
EvidenceKind = Literal["article", "document", "dataset", "media", "entity", "report", "other"]
ReviewDecision = Literal["approved", "rejected", "needs_review", "merged", "superseded"]
EvidenceMetric = int | float | bool | None
EvidenceAttribute = str | int | float | bool | None

_PRIVATE_EVIDENCE_KEYS = {
    "body",
    "content",
    "document",
    "full_text",
    "payload",
    "prompt",
    "raw",
    "raw_text",
    "source_text",
    "transcript",
}


def utc_now() -> datetime:
    """Return a timezone-aware UTC timestamp."""
    return datetime.now(timezone.utc)


class SourceWatermark(BaseModel):
    """Committed cursor for a source-specific ingestion or sync stream."""

    model_config = ConfigDict(extra="forbid")

    source_id: str = Field(min_length=1)
    stream: str = Field(default="default", min_length=1)
    kind: WatermarkKind
    value: str = Field(min_length=1)
    committed_at: datetime = Field(default_factory=utc_now)
    run_id: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class DataRunLedgerEntry(BaseModel):
    """Durable record of one collector, sync, or enrichment execution."""

    model_config = ConfigDict(extra="forbid")

    run_id: str = Field(min_length=1)
    pipeline: str = Field(min_length=1)
    source_id: str = Field(min_length=1)
    status: RunStatus = "started"
    started_at: datetime = Field(default_factory=utc_now)
    finished_at: datetime | None = None
    input_count: int = Field(default=0, ge=0)
    output_count: int = Field(default=0, ge=0)
    skipped_count: int = Field(default=0, ge=0)
    duplicate_count: int = Field(default=0, ge=0)
    error_count: int = Field(default=0, ge=0)
    error_sample: list[str] = Field(default_factory=list, max_length=10)
    previous_watermark: SourceWatermark | None = None
    committed_watermark: SourceWatermark | None = None
    code_version: str | None = None
    config_version: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def validate_finished_status(self) -> DataRunLedgerEntry:
        if self.status != "started" and self.finished_at is None:
            self.finished_at = utc_now()
        if self.status == "failed" and self.error_count == 0 and self.error_sample:
            self.error_count = len(self.error_sample)
        return self


class QualityScorecard(BaseModel):
    """Per-source quality signal suitable for Platform Monitor ingestion."""

    model_config = ConfigDict(extra="forbid")

    source_id: str = Field(min_length=1)
    pipeline: str = Field(min_length=1)
    run_id: str | None = None
    measured_at: datetime = Field(default_factory=utc_now)
    status: QualityStatus = "unknown"
    volume_count: int = Field(default=0, ge=0)
    expected_min_volume: int | None = Field(default=None, ge=0)
    freshness_seconds: int | None = Field(default=None, ge=0)
    expected_max_freshness_seconds: int | None = Field(default=None, ge=0)
    required_field_completeness: float = Field(default=1.0, ge=0.0, le=1.0)
    duplicate_rate: float = Field(default=0.0, ge=0.0, le=1.0)
    error_rate: float = Field(default=0.0, ge=0.0, le=1.0)
    language_coverage: dict[str, int] = Field(default_factory=dict)
    checks: dict[str, QualityStatus] = Field(default_factory=dict)
    notes: list[str] = Field(default_factory=list, max_length=20)
    metadata: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def infer_status(self) -> QualityScorecard:
        if self.status != "unknown":
            return self

        critical = (
            self.error_rate >= 0.25
            or self.required_field_completeness < 0.80
            or (
                self.expected_max_freshness_seconds is not None
                and self.freshness_seconds is not None
                and self.freshness_seconds > self.expected_max_freshness_seconds * 2
            )
        )
        warning = (
            self.error_rate > 0
            or self.duplicate_rate > 0.20
            or self.required_field_completeness < 0.95
            or (self.expected_min_volume is not None and self.volume_count < self.expected_min_volume)
            or (
                self.expected_max_freshness_seconds is not None
                and self.freshness_seconds is not None
                and self.freshness_seconds > self.expected_max_freshness_seconds
            )
        )

        self.status = "critical" if critical else "warning" if warning else "healthy"
        return self


class EvidenceRecord(BaseModel):
    """Versioned evidence reference exposed to product consumers."""

    model_config = ConfigDict(extra="forbid")

    evidence_id: str = Field(min_length=1)
    kind: EvidenceKind
    title: str = Field(min_length=1)
    source_id: str = Field(min_length=1)
    source_url: str | None = None
    published_at: datetime | None = None
    captured_at: datetime = Field(default_factory=utc_now)
    language: str | None = Field(default=None, max_length=16)
    reliability_score: float | None = Field(default=None, ge=0.0, le=1.0)
    extraction_version: str | None = None
    entity_ids: list[str] = Field(default_factory=list)
    content_hash: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)

    @field_validator("entity_ids")
    @classmethod
    def reject_empty_entity_ids(cls, value: list[str]) -> list[str]:
        if any(not entity_id.strip() for entity_id in value):
            raise ValueError("entity_ids must not contain blank values")
        return value


class PrivacySafeEvidenceEnvelope(BaseModel):
    """Public evidence proof containing hashes and bounded scalar metrics only.

    This contract is intentionally separate from :class:`EvidenceRecord`, which
    is an internal citation model and may carry product-owned metadata.
    """

    model_config = ConfigDict(extra="forbid")

    schema_version: Literal["qazstack-evidence-public-v1"] = "qazstack-evidence-public-v1"
    evidence_id: str = Field(min_length=1, max_length=256)
    content_hash: str = Field(pattern=r"^sha256:[a-f0-9]{64}$")
    captured_at: datetime = Field(default_factory=utc_now)
    source_ref: str | None = Field(default=None, max_length=512)
    metrics: dict[str, EvidenceMetric] = Field(default_factory=dict, max_length=100)
    attributes: dict[str, EvidenceAttribute] = Field(default_factory=dict, max_length=50)

    @field_validator("metrics", "attributes")
    @classmethod
    def reject_private_or_unbounded_fields(cls, value: dict[str, Any]) -> dict[str, Any]:
        for key, item in value.items():
            normalized_key = key.strip().lower().replace("-", "_")
            if not normalized_key or normalized_key in _PRIVATE_EVIDENCE_KEYS:
                raise ValueError(f"unsafe public evidence field: {key}")
            if isinstance(item, str) and len(item) > 512:
                raise ValueError(f"public evidence attribute is too long: {key}")
        return value


class EntityReviewRecord(BaseModel):
    """Human-review event for canonical entity or knowledge graph changes."""

    model_config = ConfigDict(extra="forbid")

    review_id: str = Field(min_length=1)
    entity_id: str = Field(min_length=1)
    decision: ReviewDecision
    reviewer_id: str = Field(min_length=1)
    reviewed_at: datetime = Field(default_factory=utc_now)
    policy_version: str = Field(min_length=1)
    evidence_ids: list[str] = Field(default_factory=list)
    reason: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)
