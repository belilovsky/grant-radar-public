"""Normalized, read-only source health records for QazPipe/QazLake consumers."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Literal

SourceHealthStatus = Literal["healthy", "warning", "critical", "unknown", "disabled"]


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _as_bool(value: object) -> bool:
    if isinstance(value, str):
        return value.strip().lower() not in {"", "0", "false", "no", "off"}
    return bool(value)


@dataclass(frozen=True, slots=True)
class SourceHealthRecord:
    """Portable health view of one registered ingestion source.

    The record intentionally does not query a database. Product-specific
    QazPipe adapters map their source registry rows into this stable shape.
    """

    source_id: str
    name: str = ""
    source_type: str = ""
    enabled: bool = True
    last_collected_at: datetime | None = None
    expected_interval_seconds: int | None = None
    consecutive_failures: int = 0

    def __post_init__(self) -> None:
        if not self.source_id.strip():
            raise ValueError("source_id is required")
        if self.expected_interval_seconds is not None and self.expected_interval_seconds <= 0:
            raise ValueError("expected_interval_seconds must be positive")
        if self.consecutive_failures < 0:
            raise ValueError("consecutive_failures must not be negative")
        if self.last_collected_at is not None and self.last_collected_at.tzinfo is None:
            raise ValueError("last_collected_at must be timezone-aware")

    def age_seconds(self, *, now: datetime | None = None) -> int | None:
        if self.last_collected_at is None:
            return None
        current = now or _utc_now()
        if current.tzinfo is None:
            raise ValueError("now must be timezone-aware")
        return max(0, int((current - self.last_collected_at).total_seconds()))

    def status(self, *, now: datetime | None = None) -> SourceHealthStatus:
        if not self.enabled:
            return "disabled"
        if self.consecutive_failures >= 3:
            return "critical"
        age = self.age_seconds(now=now)
        if age is None or self.expected_interval_seconds is None:
            return "unknown"
        if age > self.expected_interval_seconds * 2:
            return "critical"
        if self.consecutive_failures > 0 or age > self.expected_interval_seconds:
            return "warning"
        return "healthy"

    def as_dict(self, *, now: datetime | None = None) -> dict[str, object]:
        """Render the JSON-safe response shared by API and dashboard adapters."""
        return {
            "source_id": self.source_id,
            "name": self.name or self.source_id,
            "source_type": self.source_type or None,
            "enabled": self.enabled,
            "last_collected_at": self.last_collected_at.isoformat() if self.last_collected_at else None,
            "expected_interval_seconds": self.expected_interval_seconds,
            "age_seconds": self.age_seconds(now=now),
            "consecutive_failures": self.consecutive_failures,
            "health_status": self.status(now=now),
        }


def source_health_from_registry_row(row: Mapping[str, object]) -> SourceHealthRecord:
    """Map common QazPipe registry column names without requiring a DB driver."""
    collected_at = row.get("last_collected_at") or row.get("last_success_at")
    if isinstance(collected_at, str):
        collected_at = datetime.fromisoformat(collected_at.replace("Z", "+00:00"))
    if collected_at is not None and not isinstance(collected_at, datetime):
        raise ValueError("last_collected_at must be datetime, ISO-8601 string or null")

    interval_minutes = row.get("expected_interval_min")
    interval_seconds = row.get("expected_interval_seconds")
    if interval_seconds is None and interval_minutes is not None:
        interval_seconds = int(interval_minutes) * 60
    return SourceHealthRecord(
        source_id=str(row.get("source_id") or "").strip(),
        name=str(row.get("name") or "").strip(),
        source_type=str(row.get("source_type") or "").strip(),
        enabled=_as_bool(row.get("enabled", True)),
        last_collected_at=collected_at,
        expected_interval_seconds=int(interval_seconds) if interval_seconds is not None else None,
        consecutive_failures=int(row.get("consecutive_failures") or 0),
    )
