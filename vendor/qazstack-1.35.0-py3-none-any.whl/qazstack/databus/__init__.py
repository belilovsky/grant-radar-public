"""qazstack.databus – Cross-project data synchronization.

Provides sync pipelines between project databases:
- Echo Sounder → QazLake (articles, NLP, entities)
- QazLake → PSSR (signals feed)
- QazLake → Editorial (research bank)
- Entity Enricher: links entities across all projects to canonical_entities
"""

from qazstack.databus.contracts import (
    DataRunLedgerEntry,
    EntityReviewRecord,
    EvidenceRecord,
    PrivacySafeEvidenceEnvelope,
    QualityScorecard,
    SourceWatermark,
)
from qazstack.databus.echo_to_lake import EchoToLakeSync
from qazstack.databus.entity_enricher import EntityEnricher
from qazstack.databus.lake_to_editorial import LakeToEditorialSync
from qazstack.databus.source_health import SourceHealthRecord, source_health_from_registry_row
from qazstack.databus.sync import SyncPipeline, SyncResult
from qazstack.databus.webhooks import (
    InMemoryReplayStore,
    ReplayStore,
    WebhookVerification,
    sign_webhook,
    verify_webhook,
)

__all__ = [
    "SyncPipeline",
    "SyncResult",
    "DataRunLedgerEntry",
    "EntityReviewRecord",
    "EvidenceRecord",
    "PrivacySafeEvidenceEnvelope",
    "QualityScorecard",
    "SourceWatermark",
    "EchoToLakeSync",
    "LakeToEditorialSync",
    "EntityEnricher",
    "SourceHealthRecord",
    "source_health_from_registry_row",
    "InMemoryReplayStore",
    "ReplayStore",
    "WebhookVerification",
    "sign_webhook",
    "verify_webhook",
]

# Optional: QazLakeSource requires pssr-regime-engine context
