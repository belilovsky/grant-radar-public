"""HMAC webhook signature contract with clock-skew and replay protection."""

from __future__ import annotations

import hashlib
import hmac
import threading
import time
from dataclasses import dataclass
from typing import Protocol

from qazstack.contracts._validation import require_positive, require_text


class ReplayStore(Protocol):
    def claim(self, key: str, ttl_seconds: int) -> bool: ...


class InMemoryReplayStore:
    """Small process-local replay store; shared deployments should use Redis."""

    def __init__(self) -> None:
        self._expires: dict[str, float] = {}
        self._lock = threading.Lock()

    def claim(self, key: str, ttl_seconds: int) -> bool:
        """Atomically return true only for the first live claim."""
        now = time.time()
        with self._lock:
            self._expires = {item: expires for item, expires in self._expires.items() if expires > now}
            if key in self._expires:
                return False
            self._expires[key] = time.time() + ttl_seconds
            return True


@dataclass(frozen=True, slots=True)
class WebhookVerification:
    valid: bool
    reason: str
    key_index: int | None = None


def sign_webhook(payload: bytes, *, timestamp: int, secret: str) -> str:
    require_positive(timestamp, "timestamp")
    secret = require_text(secret, "secret")
    canonical = str(timestamp).encode("ascii") + b"." + payload
    return "v1=" + hmac.new(secret.encode("utf-8"), canonical, hashlib.sha256).hexdigest()


def verify_webhook(
    payload: bytes,
    *,
    timestamp: int,
    signature: str,
    secrets: tuple[str, ...],
    tolerance_seconds: int = 300,
    now: int | None = None,
    replay_store: ReplayStore | None = None,
) -> WebhookVerification:
    """Verify canonical bytes against rotated keys and reject replayed payloads."""
    require_positive(tolerance_seconds, "tolerance_seconds")
    if not secrets:
        raise ValueError("secrets must not be empty")
    current = int(time.time()) if now is None else now
    if abs(current - timestamp) > tolerance_seconds:
        return WebhookVerification(False, "timestamp_outside_tolerance")
    if not signature.startswith("v1="):
        return WebhookVerification(False, "unsupported_signature_version")
    replay_key = hashlib.sha256(f"{timestamp}.".encode("ascii") + payload).hexdigest()
    for index, secret in enumerate(secrets):
        expected = sign_webhook(payload, timestamp=timestamp, secret=secret)
        if hmac.compare_digest(signature, expected):
            if replay_store is not None and not replay_store.claim(replay_key, tolerance_seconds):
                return WebhookVerification(False, "replay_detected")
            return WebhookVerification(True, "verified", index)
    return WebhookVerification(False, "signature_mismatch")
