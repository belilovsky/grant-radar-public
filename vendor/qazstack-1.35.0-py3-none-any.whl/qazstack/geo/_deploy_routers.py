"""Connect geo_integration routers in project main.py files."""
import os

PROJECTS = [
    {
        "dir": "/opt/echo-sounder",
        "main": "app/main.py",
        "import": "from app.geo_integration import geo_router  # qazstack.geo",
        "include": "app.include_router(geo_router)  # qazstack.geo",
        "check": "geo_integration",
    },
    {
        "dir": "/opt/total-kz",
        "main": "app/main.py",
        "import": "from app.geo_integration import geo_router  # qazstack.geo",
        "include": "app.include_router(geo_router)  # qazstack.geo",
        "check": "geo_integration",
    },
    {
        "dir": "/opt/shelter-kz",
        "main": "app/main.py",
        "import": "from app.geo_enhancement import shelter_geo_router  # qazstack.geo",
        "include": "app.include_router(shelter_geo_router)  # qazstack.geo",
        "check": "geo_enhancement",
    },
    {
        "dir": "/opt/ortcom-kz",
        "main": "app/main.py",
        "import": "from app.geo_integration import geo_router  # qazstack.geo",
        "include": "app.include_router(geo_router)  # qazstack.geo",
        "check": "geo_integration",
    },
]


def connect_router(project):
    main_path = os.path.join(project["dir"], project["main"])
    name = os.path.basename(project["dir"])

    if not os.path.exists(main_path):
        print(f"  {name}: {project['main']} not found")
        return

    with open(main_path) as f:
        content = f.read()

    if project["check"] in content:
        print(f"  {name}: already connected")
        return

    lines = content.split("\n")

    # Find last import line
    last_import = 0
    for i, line in enumerate(lines):
        if line.startswith("from ") or line.startswith("import "):
            last_import = i

    # Insert import
    lines.insert(last_import + 1, project["import"])

    # Find last include_router
    last_include = 0
    for i, line in enumerate(lines):
        if "include_router" in line:
            last_include = i

    if last_include > 0:
        # Detect indentation
        indent = ""
        ref_line = lines[last_include]
        for ch in ref_line:
            if ch == " ":
                indent += " "
            else:
                break
        lines.insert(last_include + 1, f"{indent}{project['include']}")
    else:
        print(f"  {name}: no include_router found, adding at end")
        lines.append(project["include"])

    with open(main_path, "w") as f:
        f.write("\n".join(lines))

    print(f"  {name}: router connected")


# Also handle pssr-regime-engine
def connect_pssr():
    base = "/opt/pssr-regime-engine"
    main_candidates = ["src/main.py", "src/app.py", "main.py", "app.py"]
    main_path = None
    for candidate in main_candidates:
        full = os.path.join(base, candidate)
        if os.path.exists(full):
            main_path = full
            break

    if not main_path:
        print("  pssr: no main.py found")
        return

    with open(main_path) as f:
        content = f.read()

    if "geo_integration" in content:
        print("  pssr: already connected")
        return

    lines = content.split("\n")
    last_import = 0
    for i, line in enumerate(lines):
        if line.startswith("from ") or line.startswith("import "):
            last_import = i

    lines.insert(last_import + 1, "from src.geo_integration import geo_router  # qazstack.geo")

    last_include = 0
    for i, line in enumerate(lines):
        if "include_router" in line:
            last_include = i

    if last_include > 0:
        indent = ""
        for ch in lines[last_include]:
            if ch == " ":
                indent += " "
            else:
                break
        lines.insert(last_include + 1, f"{indent}app.include_router(geo_router)  # qazstack.geo")

    with open(main_path, "w") as f:
        f.write("\n".join(lines))

    print(f"  pssr: router connected in {main_path}")


if __name__ == "__main__":
    for project in PROJECTS:
        connect_router(project)
    connect_pssr()
