"""FastAPI dependencies for QazGeo integration.

Drop-in dependencies that any FastAPI project can use to get a configured
GeoClient instance via dependency injection.

Usage in a consumer project::

    from fastapi import Depends, FastAPI
    from qazstack.geo.middleware import get_geo, lifespan

    app = FastAPI(lifespan=lifespan)

    @app.get("/my-endpoint")
    async def my_endpoint(geo = Depends(get_geo)):
        result = await geo.geocode("Алматы")
        return result

Or manually without lifespan::

    from qazstack.geo.middleware import init_geo, close_geo, get_geo

    @app.on_event("startup")
    async def startup():
        init_geo()

    @app.on_event("shutdown")
    async def shutdown():
        await close_geo()
"""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from typing import Any, AsyncGenerator

from qazstack.geo.client import GeoClient

logger = logging.getLogger(__name__)

# Module-level singleton
_geo_client: GeoClient | None = None


def init_geo(
    base_url: str | None = None,
    api_key: str | None = None,
    cache_ttl: float = 300.0,
    **kwargs: Any,
) -> GeoClient:
    """Initialize the module-level GeoClient singleton.

    Called once at app startup.  Safe to call multiple times
    (returns existing instance if already initialized).
    """
    global _geo_client
    if _geo_client is None:
        _geo_client = GeoClient(
            base_url=base_url,
            api_key=api_key,
            cache_ttl=cache_ttl,
            **kwargs,
        )
        logger.info("GeoClient initialized: %s", _geo_client.base_url)
    return _geo_client


async def close_geo() -> None:
    """Close the module-level GeoClient.  Called at app shutdown."""
    global _geo_client
    if _geo_client is not None:
        await _geo_client.close()
        _geo_client = None
        logger.info("GeoClient closed")


def get_geo() -> GeoClient:
    """FastAPI dependency – returns the singleton GeoClient.

    Usage::

        @app.get("/endpoint")
        async def handler(geo: GeoClient = Depends(get_geo)):
            ...

    Raises:
        RuntimeError: If :func:`init_geo` was not called.
    """
    if _geo_client is None:
        # Auto-init with defaults (reads from env)
        return init_geo()
    return _geo_client


@asynccontextmanager
async def lifespan(app: Any) -> AsyncGenerator[None, None]:
    """FastAPI lifespan context manager that manages GeoClient lifecycle.

    Usage::

        from qazstack.geo.middleware import lifespan

        app = FastAPI(lifespan=lifespan)
    """
    init_geo()
    try:
        yield
    finally:
        await close_geo()
