"""Dependency-free geometry helpers for compact server-rendered SVG maps."""

from __future__ import annotations

import math
from collections.abc import Callable, Sequence

Point = tuple[float, float]


def point_line_distance(point: Point, start: Point, end: Point) -> float:
    if start == end:
        return math.dist(point, start)
    dx = end[0] - start[0]
    dy = end[1] - start[1]
    projection = ((point[0] - start[0]) * dx + (point[1] - start[1]) * dy) / (dx * dx + dy * dy)
    projection = max(0.0, min(1.0, projection))
    nearest = (start[0] + projection * dx, start[1] + projection * dy)
    return math.dist(point, nearest)


def simplify_polyline(points: Sequence[Point], *, tolerance: float = 1.0) -> list[Point]:
    """Douglas-Peucker simplification preserving closed polygon rings."""
    if len(points) <= 4:
        return list(points)
    closed = points[0] == points[-1]
    working = list(points[:-1] if closed else points)
    if len(working) <= 3:
        return list(points)

    def simplify(segment: list[Point]) -> list[Point]:
        if len(segment) <= 2:
            return segment
        start, end = segment[0], segment[-1]
        distances = [point_line_distance(point, start, end) for point in segment[1:-1]]
        if not distances or max(distances) <= tolerance:
            return [start, end]
        split = distances.index(max(distances)) + 1
        return simplify(segment[: split + 1])[:-1] + simplify(segment[split:])

    simplified = simplify(working)
    if closed and simplified[0] != simplified[-1]:
        simplified.append(simplified[0])
    minimum = 4 if closed else 2
    return simplified if len(simplified) >= minimum else list(points)


def svg_path(points: Sequence[Point], project: Callable[[float, float], Point], *, tolerance: float = 1.0) -> str:
    """Project a geographic ring and return a compact SVG path string."""
    simplified = simplify_polyline([project(lon, lat) for lon, lat in points], tolerance=tolerance)
    commands = [f"{'M' if index == 0 else 'L'}{x:.2f},{y:.2f}" for index, (x, y) in enumerate(simplified)]
    return " ".join([*commands, "Z"])
