"""QazStack Geo – centralized GIS module for the Belilovsky Platform.

Provides a shared client, utilities, and typed models for interacting with
QazGeo (PostGIS-backed GIS microservice for Kazakhstan).

Quick start (async)::

    from qazstack.geo import GeoClient

    async with GeoClient() as geo:
        regions = await geo.regions()
        result = await geo.geocode("Алматы")
        texts  = await geo.locate_texts(["Событие в Караганде", "Встреча в Астане"])

Quick start (sync – scripts, cron)::

    from qazstack.geo import GeoClient

    geo = GeoClient()
    regions = geo.sync.regions()
    geo.sync.close()

FastAPI integration::

    from fastapi import Depends, FastAPI
    from qazstack.geo import GeoClient
    from qazstack.geo.middleware import get_geo, lifespan

    app = FastAPI(lifespan=lifespan)

    @app.get("/regions")
    async def handler(geo: GeoClient = Depends(get_geo)):
        return await geo.regions()

Utilities (no network, no dependencies)::

    from qazstack.geo import (
        haversine, bounding_box, KZ_BBOX, KZ_CENTER,
        normalize_location, KZ_ALIASES, region_code_to_name,
        feature, feature_collection, merge_metric,
    )
"""

# ── Distance & geometry (pure math) ──────────────────────────────────────────
# ── Location normalization & aliases ──────────────────────────────────────────
from qazstack.geo.aliases import (
    KZ_ALIASES,
    REGION_CODES,
    get_aliases,
    is_known_location,
    normalize_location,
    region_code_to_name,
    region_name_to_code,
    search_locations,
)

# ── HTTP Client for QazGeo service ────────────────────────────────────────────
from qazstack.geo.client import (
    CircuitOpenError,
    GeoClient,
    GeoError,
)
from qazstack.geo.coverage import RegionCoverage, aggregate_region_coverage
from qazstack.geo.distance import (
    KZ_BBOX,
    KZ_CENTER,
    BBox,
    bounding_box,
    haversine,
    haversine_batch,
)

# ── GeoJSON helpers (no DB, no network) ───────────────────────────────────────
from qazstack.geo.geojson import (
    compute_stats,
    feature,
    feature_collection,
    merge_metric,
    point_feature,
    points_collection,
)
from qazstack.geo.svg import point_line_distance, simplify_polyline, svg_path

__all__ = [
    # Distance
    "haversine",
    "haversine_batch",
    "bounding_box",
    "BBox",
    "KZ_BBOX",
    "KZ_CENTER",
    # Aliases
    "normalize_location",
    "KZ_ALIASES",
    "REGION_CODES",
    "region_code_to_name",
    "region_name_to_code",
    "get_aliases",
    "is_known_location",
    "search_locations",
    # GeoJSON
    "feature",
    "feature_collection",
    "merge_metric",
    "compute_stats",
    "point_feature",
    "points_collection",
    "point_line_distance",
    "simplify_polyline",
    "svg_path",
    # Client
    "GeoClient",
    "GeoError",
    "CircuitOpenError",
    "RegionCoverage",
    "aggregate_region_coverage",
]
