"""Async HTTP client for QazGeo – centralized GIS service for Kazakhstan.

Reads configuration from environment variables:
    QAZGEO_URL      – base URL (default: http://qazgeo_app:8000)
    QAZGEO_API_KEY  – X-API-Key for authentication

Features:
    - Automatic retry with exponential backoff (3 attempts)
    - Circuit breaker: after N consecutive failures, fast-fail for cooldown period
    - Request ID propagation (X-Request-ID header)
    - In-memory TTL cache for immutable data (regions, cities, aliases)
    - Sync wrapper for non-async contexts (scripts, cron jobs)

All async methods return parsed JSON dicts (or typed Pydantic models when
``typed=True`` is passed to the constructor).
Raise ``httpx.HTTPStatusError`` on 4xx/5xx or ``GeoError`` on connection failures.

Usage::

    from qazstack.geo import GeoClient

    # Async
    async with GeoClient() as geo:
        regions = await geo.regions()
        result = await geo.geocode("Алматы")

    # Sync (scripts, cron)
    geo = GeoClient()
    regions = geo.sync.regions()
"""

from __future__ import annotations

import asyncio
import functools
import logging
import os
import time
import uuid
import warnings
from typing import Any, Callable, TypeVar

import httpx

logger = logging.getLogger(__name__)

_DEFAULT_URL = "http://qazgeo_app:8000"
T = TypeVar("T")


# ── Exceptions ────────────────────────────────────────────────────────────────


class GeoError(Exception):
    """Raised when QazGeo is unreachable or returns an unexpected response."""


class CircuitOpenError(GeoError):
    """Raised when the circuit breaker is open (service assumed down)."""


# ── Circuit Breaker ───────────────────────────────────────────────────────────


class _CircuitBreaker:
    """Simple circuit breaker: after `threshold` consecutive failures,
    reject requests for `cooldown` seconds before allowing a probe."""

    __slots__ = ("threshold", "cooldown", "_failures", "_last_failure", "_state")

    def __init__(self, threshold: int = 5, cooldown: float = 30.0):
        self.threshold = threshold
        self.cooldown = cooldown
        self._failures = 0
        self._last_failure: float = 0.0
        self._state = "closed"  # closed | open | half-open

    @property
    def is_open(self) -> bool:
        if self._state == "open":
            if time.monotonic() - self._last_failure > self.cooldown:
                self._state = "half-open"
                return False
            return True
        return False

    def record_success(self) -> None:
        self._failures = 0
        self._state = "closed"

    def record_failure(self) -> None:
        self._failures += 1
        self._last_failure = time.monotonic()
        if self._failures >= self.threshold:
            self._state = "open"
            logger.warning(
                "Circuit breaker OPEN for QazGeo: %d consecutive failures, cooldown %ds",
                self._failures,
                self.cooldown,
            )


# ── TTL Cache ─────────────────────────────────────────────────────────────────


class _TTLCache:
    """Simple in-memory TTL cache for immutable geo data (regions, cities, aliases)."""

    __slots__ = ("_store", "_default_ttl")

    def __init__(self, default_ttl: float = 300.0):
        self._store: dict[str, tuple[float, Any]] = {}
        self._default_ttl = default_ttl

    def get(self, key: str) -> Any | None:
        entry = self._store.get(key)
        if entry is None:
            return None
        expires, value = entry
        if time.monotonic() > expires:
            del self._store[key]
            return None
        return value

    def set(self, key: str, value: Any, ttl: float | None = None) -> None:
        self._store[key] = (time.monotonic() + (ttl or self._default_ttl), value)

    def invalidate(self, key: str | None = None) -> None:
        """Drop a single key or flush the entire cache."""
        if key is None:
            self._store.clear()
        else:
            self._store.pop(key, None)


# ── Sync wrapper ──────────────────────────────────────────────────────────────


class _SyncProxy:
    """Synchronous wrapper around GeoClient async methods.

    Automatically creates and manages an event loop for non-async contexts.
    Used via ``client.sync.regions()`` etc.
    """

    def __init__(self, client: "GeoClient"):
        self._client = client
        self._loop: asyncio.AbstractEventLoop | None = None

    def _get_loop(self) -> asyncio.AbstractEventLoop:
        if self._loop is None or self._loop.is_closed():
            self._loop = asyncio.new_event_loop()
        return self._loop

    def __getattr__(self, name: str) -> Callable[..., Any]:
        method = getattr(self._client, name)
        if not asyncio.iscoroutinefunction(method):
            return method

        @functools.wraps(method)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            try:
                asyncio.get_running_loop()
                # Already in async context – can't nest, raise helpful error
                raise RuntimeError(
                    f"Cannot call geo.sync.{name}() from within an async context. Use 'await geo.{name}()' instead."
                )
            except RuntimeError as exc:
                if "no current event loop" not in str(exc) and "no running event loop" not in str(exc):
                    raise
            return self._get_loop().run_until_complete(method(*args, **kwargs))

        return wrapper

    def close(self) -> None:
        if self._loop and not self._loop.is_closed():
            self._loop.run_until_complete(self._client.close())
            self._loop.close()
            self._loop = None


# ── Main client ───────────────────────────────────────────────────────────────


class GeoClient:
    """Async HTTP client for QazGeo with retry, circuit breaker, and caching.

    Args:
        base_url: Override the QazGeo URL (env: ``QAZGEO_URL``).
        api_key: Override the API key (env: ``QAZGEO_API_KEY``).
        timeout: HTTP request timeout in seconds.
        max_retries: Number of retry attempts on transient failures.
        circuit_threshold: Consecutive failures before circuit opens.
        circuit_cooldown: Seconds to wait before retrying after circuit opens.
        cache_ttl: Default TTL for cached responses (seconds). Set to 0 to disable.

    Examples::

        # Async context manager (recommended)
        async with GeoClient() as geo:
            fc = await geo.regions()

        # Manual lifecycle
        geo = GeoClient()
        try:
            result = await geo.geocode("Астана")
        finally:
            await geo.close()

        # Sync (scripts, cron jobs)
        geo = GeoClient()
        regions = geo.sync.regions()
        geo.sync.close()
    """

    def __init__(
        self,
        base_url: str | None = None,
        api_key: str | None = None,
        timeout: float = 30.0,
        max_retries: int = 3,
        circuit_threshold: int = 5,
        circuit_cooldown: float = 30.0,
        cache_ttl: float = 300.0,
    ) -> None:
        self.base_url = (base_url or os.getenv("QAZGEO_URL", _DEFAULT_URL)).rstrip("/")
        self.api_key = api_key or os.getenv("QAZGEO_API_KEY", "")
        self.timeout = timeout
        self.max_retries = max_retries
        self._client: httpx.AsyncClient | None = None
        self._circuit = _CircuitBreaker(threshold=circuit_threshold, cooldown=circuit_cooldown)
        self._cache = _TTLCache(default_ttl=cache_ttl) if cache_ttl > 0 else None
        self._sync: _SyncProxy | None = None

    @classmethod
    def from_env(cls, **kwargs: Any) -> "GeoClient":
        """Create a client from ``QAZGEO_*`` environment variables.

        This keeps downstream apps on a stable factory surface while allowing
        callers to override timeout/retry options.
        """
        return cls(**kwargs)

    @property
    def sync(self) -> _SyncProxy:
        """Synchronous proxy – use from scripts/cron: ``geo.sync.regions()``."""
        if self._sync is None:
            self._sync = _SyncProxy(self)
        return self._sync

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    async def __aenter__(self) -> "GeoClient":
        return self

    async def __aexit__(self, *exc: Any) -> None:
        await self.close()

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                headers={"X-API-Key": self.api_key},
                timeout=httpx.Timeout(self.timeout),
            )
        return self._client

    async def close(self) -> None:
        """Close the underlying HTTP client and flush cache."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()
            self._client = None
        if self._cache:
            self._cache.invalidate()

    def invalidate_cache(self, key: str | None = None) -> None:
        """Drop a cached key, or flush entire cache if key is None."""
        if self._cache:
            self._cache.invalidate(key)

    # ── HTTP transport ────────────────────────────────────────────────────────

    async def _request_with_retry(self, method: str, path: str, **kwargs: Any) -> Any:
        """Execute HTTP request with retry + circuit breaker."""
        if self._circuit.is_open:
            raise CircuitOpenError(
                f"Circuit breaker is open for QazGeo at {self.base_url}. "
                f"Service assumed unavailable. Will retry after cooldown."
            )

        client = await self._get_client()
        req_id = str(uuid.uuid4())[:12]
        last_exc: Exception | None = None

        for attempt in range(1, self.max_retries + 1):
            try:
                if method == "POST":
                    resp = await client.post(path, headers={"X-Request-ID": req_id}, **kwargs)
                else:
                    resp = await client.get(path, headers={"X-Request-ID": req_id}, **kwargs)

                # 429 – respect Retry-After
                if resp.status_code == 429:
                    retry_after = int(resp.headers.get("Retry-After", "5"))
                    if attempt < self.max_retries:
                        logger.warning(
                            "QazGeo rate limited (429), retry in %ds (attempt %d/%d) req_id=%s",
                            retry_after,
                            attempt,
                            self.max_retries,
                            req_id,
                        )
                        await asyncio.sleep(min(retry_after, 30))
                        continue
                    resp.raise_for_status()

                # 5xx – retryable
                if resp.status_code >= 500:
                    if attempt < self.max_retries:
                        backoff = min(2 ** (attempt - 1), 16)
                        logger.warning(
                            "QazGeo %s returned %d, retry in %ds (attempt %d/%d) req_id=%s",
                            path,
                            resp.status_code,
                            backoff,
                            attempt,
                            self.max_retries,
                            req_id,
                        )
                        await asyncio.sleep(backoff)
                        continue
                    resp.raise_for_status()

                # 4xx – don't retry
                resp.raise_for_status()

                self._circuit.record_success()
                return resp.json()

            except httpx.ConnectError as exc:
                last_exc = exc
                self._circuit.record_failure()
                if attempt < self.max_retries:
                    backoff = min(2 ** (attempt - 1), 16)
                    logger.warning(
                        "QazGeo connection failed, retry in %ds (attempt %d/%d) req_id=%s: %s",
                        backoff,
                        attempt,
                        self.max_retries,
                        req_id,
                        exc,
                    )
                    await asyncio.sleep(backoff)
                    continue

            except httpx.TimeoutException as exc:
                last_exc = exc
                self._circuit.record_failure()
                if attempt < self.max_retries:
                    backoff = min(2 ** (attempt - 1), 16)
                    logger.warning(
                        "QazGeo timeout, retry in %ds (attempt %d/%d) req_id=%s: %s",
                        backoff,
                        attempt,
                        self.max_retries,
                        req_id,
                        exc,
                    )
                    await asyncio.sleep(backoff)
                    continue

            except httpx.HTTPStatusError as exc:
                self._circuit.record_failure()
                logger.error(
                    "QazGeo %s returned %s: %s req_id=%s",
                    path,
                    exc.response.status_code,
                    exc.response.text[:500],
                    req_id,
                )
                raise

        raise GeoError(f"Cannot connect to QazGeo at {self.base_url} after {self.max_retries} attempts: {last_exc}")

    async def _get(
        self,
        path: str,
        params: dict[str, Any] | None = None,
        *,
        cache_key: str | None = None,
        cache_ttl: float | None = None,
    ) -> Any:
        if cache_key and self._cache:
            cached = self._cache.get(cache_key)
            if cached is not None:
                return cached
        result = await self._request_with_retry("GET", f"/api/v1{path}", params=params)
        if cache_key and self._cache:
            self._cache.set(cache_key, result, cache_ttl)
        return result

    async def _post(self, path: str, json: dict[str, Any]) -> Any:
        return await self._request_with_retry("POST", f"/api/v1{path}", json=json)

    # ══════════════════════════════════════════════════════════════════════════
    # Regions
    # ══════════════════════════════════════════════════════════════════════════

    async def regions(self, with_geometry: bool = True) -> dict:
        """All 20 regions as GeoJSON FeatureCollection.

        Cached for 5 minutes (boundaries rarely change).
        """
        return await self._get(
            "/regions",
            {"with_geometry": with_geometry},
            cache_key=f"regions:{with_geometry}",
            cache_ttl=300,
        )

    async def public_regions_geojson(self) -> dict:
        """Public MapRegion boundaries as the exact QazGeo GeoJSON contract."""
        return await self._get(
            "/mapregion/public/regions-geojson",
            cache_key="mapregion:public:regions-geojson",
            cache_ttl=300,
        )

    async def region(self, code: str) -> dict:
        """Single region by code (e.g. KZ-AST) as GeoJSON Feature."""
        code = code.upper()
        return await self._get(
            f"/regions/{code}",
            cache_key=f"region:{code}",
            cache_ttl=300,
        )

    async def region_cities(self, code: str) -> dict:
        """All cities in a specific region."""
        code = code.upper()
        return await self._get(
            f"/regions/{code}/cities",
            cache_key=f"region_cities:{code}",
            cache_ttl=300,
        )

    # ══════════════════════════════════════════════════════════════════════════
    # Cities
    # ══════════════════════════════════════════════════════════════════════════

    async def cities(
        self,
        region: str | None = None,
        city_type: str | None = None,
    ) -> dict:
        """List cities with optional filters."""
        params: dict[str, Any] = {}
        if region:
            params["region"] = region
        if city_type:
            params["city_type"] = city_type
        cache_key = f"cities:{region}:{city_type}"
        return await self._get("/cities", params or None, cache_key=cache_key, cache_ttl=300)

    async def city(self, city_id: int) -> dict:
        """Single city by ID."""
        return await self._get(
            f"/cities/{city_id}",
            cache_key=f"city:{city_id}",
            cache_ttl=300,
        )

    # ══════════════════════════════════════════════════════════════════════════
    # Geocoding
    # ══════════════════════════════════════════════════════════════════════════

    async def geocode(self, query: str) -> dict:
        """Forward geocoding – text → coordinates + region_code."""
        return await self._get("/geocode", {"q": query})

    async def reverse(self, lat: float, lon: float) -> dict:
        """Reverse geocoding – coordinates → region + nearest city."""
        return await self._get("/reverse", {"lat": lat, "lon": lon})

    async def locate_texts(self, texts: list[str]) -> dict:
        """Batch: extract location mentions from texts → region_codes.

        Max 100 texts per request.
        """
        return await self._post("/locate-texts", {"texts": texts})

    # ══════════════════════════════════════════════════════════════════════════
    # Choropleth
    # ══════════════════════════════════════════════════════════════════════════

    async def choropleth(self, metric: str) -> dict:
        """GeoJSON FeatureCollection with built-in metric for choropleth maps."""
        return await self._get("/choropleth", {"metric": metric})

    async def choropleth_custom(self, metric: str, data: dict[str, float]) -> dict:
        """Merge custom per-region metric values into GeoJSON for choropleth."""
        return await self._post("/choropleth", {"metric": metric, "data": data})

    # ══════════════════════════════════════════════════════════════════════════
    # Photon geocoder sidecar
    # ══════════════════════════════════════════════════════════════════════════

    async def photon_health(self) -> dict:
        """Check the optional Photon sidecar exposed by QazGeo."""
        return await self._get("/photon/health")

    async def photon_search(
        self,
        query: str,
        *,
        limit: int = 5,
        lang: str = "default",
        lat: float | None = None,
        lon: float | None = None,
        bbox: str | None = None,
        osm_tag: str | None = None,
    ) -> dict:
        """Autocomplete search via QazGeo Photon endpoint.

        QazGeo may return a local Kazakhstan-first fallback when Photon has no
        useful match for Cyrillic or local place names.
        """
        params: dict[str, Any] = {"q": query, "limit": limit, "lang": lang}
        if lat is not None:
            params["lat"] = lat
        if lon is not None:
            params["lon"] = lon
        if bbox:
            params["bbox"] = bbox
        if osm_tag:
            params["osm_tag"] = osm_tag
        return await self._get("/photon/search", params)

    async def photon_reverse(
        self,
        *,
        lat: float,
        lon: float,
        limit: int = 1,
    ) -> dict:
        """Reverse geocode through QazGeo Photon endpoint."""
        return await self._get("/photon/reverse", {"lat": lat, "lon": lon, "limit": limit})

    # ══════════════════════════════════════════════════════════════════════════
    # Tiles, layers, OGC, H3
    # ══════════════════════════════════════════════════════════════════════════

    async def layers(self) -> dict:
        """QazGeo layer registry for safe MapLibre/OGC consumers."""
        return await self._get("/layers", cache_key="layers", cache_ttl=300)

    async def layer(self, layer_id: str) -> dict:
        """Single QazGeo layer definition by registry id."""
        return await self._get(
            f"/layers/{layer_id}",
            cache_key=f"layer:{layer_id}",
            cache_ttl=300,
        )

    async def shadow_events(
        self,
        *,
        scope: str = "kazakhstan",
        layers: list[str] | None = None,
        limit: int = 200,
    ) -> dict:
        """Vetted public environmental/context events from QazLake Shadow.

        QazGeo applies the allowlist and freshness policy. This method never
        requests movement tracks, raw snapshots or internal entity data.
        """

        params: dict[str, Any] = {"scope": scope, "limit": limit}
        if layers:
            params["layer"] = layers
        cache_key = f"shadow_events:{scope}:{','.join(layers or [])}:{limit}"
        return await self._get(
            "/external-layers/shadow-events",
            params,
            cache_key=cache_key,
            cache_ttl=60,
        )

    async def shadow_coverage(
        self,
        *,
        scope: str = "kazakhstan",
        layers: list[str] | None = None,
    ) -> dict:
        """Freshness and source coverage for the vetted QazLake Shadow layer."""

        params: dict[str, Any] = {"scope": scope}
        if layers:
            params["layer"] = layers
        cache_key = f"shadow_coverage:{scope}:{','.join(layers or [])}"
        return await self._get(
            "/external-layers/shadow-coverage",
            params,
            cache_key=cache_key,
            cache_ttl=60,
        )

    async def satellite_products(self) -> dict:
        """Vetted satellite product metadata without imagery or storage paths."""

        return await self._get(
            "/external-layers/satellite-products",
            cache_key="satellite_products",
            cache_ttl=3600,
        )

    async def sar_scenes(self, *, limit: int = 200) -> dict:
        """Recent public Sentinel-1 scene centres over Kazakhstan."""

        return await self._get(
            "/external-layers/sar-scenes",
            {"limit": limit},
            cache_key=f"sar_scenes:{limit}",
            cache_ttl=3600,
        )

    async def viirs_true_color(self, *, observation_date: str | None = None) -> dict:
        """NASA VIIRS true-color TileJSON for an optional ISO observation date."""

        params: dict[str, Any] = {}
        if observation_date:
            params["date"] = observation_date
        return await self._get(
            "/external-layers/nasa-viirs-true-color",
            params,
            cache_key=f"viirs_true_color:{observation_date}",
            cache_ttl=3600,
        )

    async def hydro_stations(
        self,
        *,
        bbox: str | None = None,
        limit: int = 500,
    ) -> dict:
        """Active Kazakhstan hydrology stations within the requested viewport."""

        params: dict[str, Any] = {"limit": limit}
        if bbox:
            params["bbox"] = bbox
        return await self._get(
            "/external-layers/hydro-stations",
            params,
            cache_key=f"hydro_stations:{bbox}:{limit}",
            cache_ttl=3600,
        )

    async def water_objects(
        self,
        *,
        bbox: str | None = None,
        limit: int = 500,
    ) -> dict:
        """Normalized public Kazakhstan water-object catalogue for a viewport."""

        params: dict[str, Any] = {"limit": limit}
        if bbox:
            params["bbox"] = bbox
        return await self._get(
            "/external-layers/water-objects",
            params,
            cache_key=f"water_objects:{bbox}:{limit}",
            cache_ttl=3600,
        )

    async def tile_sources(self) -> dict:
        """Vector tile source registry with public TileJSON links."""
        return await self._get("/tiles/sources", cache_key="tile_sources", cache_ttl=300)

    async def ogc_landing(self) -> dict:
        """OGC API landing document."""
        client = await self._get_client()
        resp = await client.get("/ogc/")
        resp.raise_for_status()
        return resp.json()

    async def ogc_collections(self) -> dict:
        """OGC API collections list."""
        client = await self._get_client()
        resp = await client.get("/ogc/collections")
        resp.raise_for_status()
        return resp.json()

    async def ogc_collection(self, collection_id: str) -> dict:
        """Metadata for a single OGC API collection."""
        client = await self._get_client()
        resp = await client.get(f"/ogc/collections/{collection_id}")
        resp.raise_for_status()
        return resp.json()

    async def ogc_items(
        self,
        collection_id: str,
        *,
        limit: int = 100,
        offset: int = 0,
        bbox: str | None = None,
    ) -> dict:
        """Features from an OGC API collection as GeoJSON."""
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if bbox:
            params["bbox"] = bbox
        client = await self._get_client()
        resp = await client.get(f"/ogc/collections/{collection_id}/items", params=params)
        resp.raise_for_status()
        return resp.json()

    async def h3_index(
        self,
        *,
        lat: float,
        lon: float,
        resolution: int = 7,
    ) -> dict:
        """Return H3 cell metadata for a point."""
        return await self._get("/h3/cell", {"lat": lat, "lon": lon, "resolution": resolution})

    async def h3_hexbin(
        self,
        *,
        resolution: int = 7,
        region_id: int | None = None,
        poi_type: str | None = None,
    ) -> dict:
        """H3 hexbin aggregation for regions/POIs."""
        params: dict[str, Any] = {"resolution": resolution}
        if region_id is not None:
            params["region_id"] = region_id
        if poi_type:
            params["poi_type"] = poi_type
        return await self._get("/h3/hexbin", params)

    # ══════════════════════════════════════════════════════════════════════════
    # Stats
    # ══════════════════════════════════════════════════════════════════════════

    async def region_stats(
        self,
        region: str | None = None,
        year: int | None = None,
    ) -> dict:
        """Regional demographic + economic statistics."""
        params: dict[str, Any] = {}
        if region:
            params["region"] = region
        if year is not None:
            params["year"] = year
        return await self._get("/stats/regions", params or None)

    async def region_stats_detail(self, code: str) -> dict:
        """All yearly stats for a single region."""
        return await self._get(f"/stats/regions/{code.upper()}")

    # ══════════════════════════════════════════════════════════════════════════
    # Demographics (новые эндпоинты)
    # ══════════════════════════════════════════════════════════════════════════

    async def demographics_age_sex(self, region_name: str | None = None) -> dict:
        """Age-sex structure for all regions or a specific region."""
        if region_name:
            return await self._get(f"/mapregion/demographics/age-sex/{region_name}")
        return await self._get("/mapregion/demographics/age-sex")

    async def demographics_ethnicity(self, region_name: str | None = None) -> dict:
        """Ethnic composition for all regions or a specific region."""
        if region_name:
            return await self._get(f"/mapregion/demographics/ethnicity/{region_name}")
        return await self._get("/mapregion/demographics/ethnicity")

    # ══════════════════════════════════════════════════════════════════════════
    # Economic
    # ══════════════════════════════════════════════════════════════════════════

    async def economic_inflation(self, region_name: str | None = None) -> dict:
        """Inflation data for all regions or a specific region."""
        if region_name:
            return await self._get(f"/mapregion/economic/inflation/{region_name}")
        return await self._get("/mapregion/economic/inflation")

    async def economic_internet(self, region_name: str | None = None) -> dict:
        """Internet penetration for all regions or a specific region."""
        if region_name:
            return await self._get(f"/mapregion/economic/internet/{region_name}")
        return await self._get("/mapregion/economic/internet")

    # ══════════════════════════════════════════════════════════════════════════
    # Infrastructure & Water
    # ══════════════════════════════════════════════════════════════════════════

    async def infrastructure(
        self,
        infra_type: str | None = None,
        region: str | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> dict:
        """Infrastructure objects (roads, railways, pipelines)."""
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if infra_type:
            params["infra_type"] = infra_type
        if region:
            params["region"] = region
        return await self._get("/infrastructure", params)

    async def water_bodies(
        self,
        water_type: str | None = None,
        region: str | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> dict:
        """Water bodies (lakes, reservoirs, seas)."""
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if water_type:
            params["water_type"] = water_type
        if region:
            params["region"] = region
        return await self._get("/water-bodies", params)

    async def road_sections(
        self,
        section_id: int | None = None,
        region_name: str | None = None,
    ) -> dict:
        """Road sections – all, by ID, or by region."""
        if section_id is not None:
            return await self._get(f"/mapregion/road-sections/{section_id}")
        if region_name:
            return await self._get(f"/mapregion/regions/{region_name}/roads")
        return await self._get("/mapregion/road-sections")

    # ══════════════════════════════════════════════════════════════════════════
    # Strata (коммуникационная стратификация)
    # ══════════════════════════════════════════════════════════════════════════

    async def strata(
        self,
        region_name: str | None = None,
        group: str | None = None,
    ) -> dict:
        """Return the unfiltered strata catalogue.

        ``region_name`` and ``group`` are legacy arguments. QazGeo does not
        support those filters on the catalogue endpoint, so callers should use
        :meth:`region_strata_summary`, :meth:`regions_by_group` or
        :meth:`strata_catalog` instead.
        """
        if region_name is not None or group is not None:
            warnings.warn(
                "GeoClient.strata(region_name=..., group=...) does not filter "
                "the QazGeo catalogue; use region_strata_summary(), "
                "regions_by_group() or strata_catalog().",
                DeprecationWarning,
                stacklevel=2,
            )
        return await self._get("/mapregion/strata")

    async def strata_catalog(
        self,
        *,
        page: int = 1,
        page_size: int = 20,
        code: str | None = None,
        age_group: str | None = None,
        media_type: str | None = None,
        settlement: str | None = None,
    ) -> dict:
        """Filter the QazGeo strata catalogue using its supported contract."""
        params: dict[str, Any] = {"page": page, "page_size": page_size}
        for key, value in {
            "code": code,
            "age_group": age_group,
            "media_type": media_type,
            "settlement": settlement,
        }.items():
            if value is not None:
                params[key] = value
        return await self._get("/mapregion/strata", params)

    async def region_strata_summary(self, region_name: str) -> dict:
        """Return the aggregate strata summary for one MapRegion region."""
        return await self._get(f"/mapregion/regions/{region_name}/strata/summary")

    async def strata_matrix(self, region_name: str | None = None) -> dict:
        """Strata matrix – all regions or a specific region."""
        if region_name:
            return await self._get(f"/mapregion/strata/matrix/{region_name}")
        return await self._get("/mapregion/strata/matrix")

    async def strata_by_code(self, code: str) -> dict:
        """Single stratum by code."""
        return await self._get(f"/mapregion/strata/{code}")

    async def regions_by_group(self, group: str) -> dict:
        """Regions filtered by ABC group."""
        return await self._get(f"/mapregion/regions/by-group/{group}")

    async def strata_heatmap(
        self,
        metric: str | None = None,
        group: str | None = None,
    ) -> dict:
        """Heatmap data for strata visualization."""
        if metric is None:
            raise ValueError("QazGeo requires a metric for strata_heatmap().")
        if group is not None:
            warnings.warn(
                "GeoClient.strata_heatmap(group=...) is not a QazGeo filter "
                "and is ignored; filter the returned data in the consumer.",
                DeprecationWarning,
                stacklevel=2,
            )
        return await self._get("/mapregion/map/heatmap", {"metric": metric})

    # ══════════════════════════════════════════════════════════════════════════
    # Analytics
    # ══════════════════════════════════════════════════════════════════════════

    async def dead_loop(self) -> dict:
        """Dead Loop analysis for communication effectiveness."""
        return await self._get("/mapregion/analytics/dead-loop")

    async def saturation(self, region_name: str | None = None) -> dict:
        """Saturation curves for communication coverage."""
        params: dict[str, Any] = {}
        if region_name:
            params["region"] = region_name
        return await self._get("/mapregion/analytics/saturation", params or None)

    # ══════════════════════════════════════════════════════════════════════════
    # Reports
    # ══════════════════════════════════════════════════════════════════════════

    async def region_passport(self, region_name: str) -> bytes:
        """Download region passport PDF as raw bytes."""
        if self._circuit.is_open:
            raise CircuitOpenError("Circuit breaker is open for QazGeo.")
        client = await self._get_client()
        req_id = str(uuid.uuid4())[:12]
        resp = await client.get(
            f"/api/v1/mapregion/reports/passport/{region_name}",
            headers={"X-Request-ID": req_id},
        )
        resp.raise_for_status()
        self._circuit.record_success()
        return resp.content

    async def region_summary(self, region_name: str) -> dict:
        """Analytical summary for a region."""
        return await self._get(f"/mapregion/reports/summary/{region_name}")

    # ══════════════════════════════════════════════════════════════════════════
    # ROL (Республиканская оперативная лента)
    # ══════════════════════════════════════════════════════════════════════════

    async def rol_documents(self) -> dict:
        """List all ROL documents."""
        return await self._get("/mapregion/rol")

    async def rol_document(self, stratum_code: str) -> dict:
        """ROL document for a specific stratum."""
        return await self._get(f"/mapregion/rol/{stratum_code}")

    # ══════════════════════════════════════════════════════════════════════════
    # Health
    # ══════════════════════════════════════════════════════════════════════════

    async def health(self) -> dict:
        """Check QazGeo health status."""
        client = await self._get_client()
        resp = await client.get("/health")
        resp.raise_for_status()
        return resp.json()
