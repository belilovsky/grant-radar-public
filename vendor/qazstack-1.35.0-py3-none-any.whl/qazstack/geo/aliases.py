"""Kazakhstan location name normalization, aliases, and region codes.

Maps historical, alternative, transliterated, and Kazakh-language names
to canonical forms.  Useful for geocoding, NLP entity resolution, data
deduplication, and cross-project location matching.

Features:
    - 80+ city aliases (historical, English, Kazakh)
    - 20 region short-forms → full names
    - ISO 3166-2:KZ code ↔ name bidirectional lookup
    - Fuzzy-friendly normalization (removes suffixes, diacritics)
    - Reverse lookup: canonical → all known aliases
"""

from __future__ import annotations

import re

# ══════════════════════════════════════════════════════════════════════════════
# ISO 3166-2:KZ region codes
# ══════════════════════════════════════════════════════════════════════════════

#: Mapping of ISO code → canonical Russian name for all 20 regions.
REGION_CODES: dict[str, str] = {
    "KZ-ALA": "Алматы",
    "KZ-AST": "Астана",
    "KZ-SHY": "Шымкент",
    "KZ-AKM": "Акмолинская область",
    "KZ-AKT": "Актюбинская область",
    "KZ-ALM": "Алматинская область",
    "KZ-ATY": "Атырауская область",
    "KZ-VOS": "Восточно-Казахстанская область",
    "KZ-ZHA": "Жамбылская область",
    "KZ-ZAP": "Западно-Казахстанская область",
    "KZ-KAR": "Карагандинская область",
    "KZ-KUS": "Костанайская область",
    "KZ-KYZ": "Кызылординская область",
    "KZ-MAN": "Мангистауская область",
    "KZ-PAV": "Павлодарская область",
    "KZ-SEV": "Северо-Казахстанская область",
    "KZ-TUR": "Туркестанская область",
    "KZ-ABY": "Область Абай",
    "KZ-ZHT": "Область Жетісу",
    "KZ-ULY": "Область Ұлытау",
}

#: Reverse: canonical name (lower) → ISO code
_NAME_TO_CODE: dict[str, str] = {v.lower(): k for k, v in REGION_CODES.items()}


def region_code_to_name(code: str) -> str | None:
    """ISO code → canonical Russian name. Returns None if unknown."""
    return REGION_CODES.get(code.upper())


def region_name_to_code(name: str) -> str | None:
    """Canonical Russian name → ISO code. Handles common variations."""
    q = name.strip().lower()
    # Direct match
    if q in _NAME_TO_CODE:
        return _NAME_TO_CODE[q]
    # Try normalize first
    normalized = normalize_location(q)
    if normalized in _NAME_TO_CODE:
        return _NAME_TO_CODE[normalized]
    # Partial match (e.g. "Алматинская" → "Алматинская область")
    for full_name, code in _NAME_TO_CODE.items():
        if q in full_name or full_name.startswith(q):
            return code
    return None


# ══════════════════════════════════════════════════════════════════════════════
# City and region aliases
# ══════════════════════════════════════════════════════════════════════════════

#: Canonical name aliases: alternative → canonical (lowercase).
#: The canonical form is the modern Russian name (or Kazakh where standard).
KZ_ALIASES: dict[str, str] = {
    # ── Cities ────────────────────────────────────────────────────────────────
    # Astana
    "нур-султан": "астана",
    "нурсултан": "астана",
    "nur-sultan": "астана",
    "nursultan": "астана",
    "акмола": "астана",
    "акмолинск": "астана",
    "целиноград": "астана",
    "astana": "астана",
    "ақмола": "астана",
    "нұр-сұлтан": "астана",
    # Almaty
    "алма-ата": "алматы",
    "alma-ata": "алматы",
    "almaty": "алматы",
    "верный": "алматы",
    "алмата": "алматы",
    # Shymkent
    "чимкент": "шымкент",
    "chimkent": "шымкент",
    "shymkent": "шымкент",
    "шiмкент": "шымкент",
    # Semey
    "семипалатинск": "семей",
    "semipalatinsk": "семей",
    "semey": "семей",
    "семіпалатинск": "семей",
    # Ust-Kamenogorsk / Oskemen
    "усть-каменогорск": "өскемен",
    "ust-kamenogorsk": "өскемен",
    "oskemen": "өскемен",
    "өскемен": "өскемен",
    "ускаман": "өскемен",
    # Taraz
    "джамбул": "тараз",
    "жамбыл": "тараз",
    "taraz": "тараз",
    "тараз": "тараз",
    "dzhambul": "тараз",
    # Petropavl
    "петропавловск": "петропавл",
    "petropavl": "петропавл",
    "petropavlovsk": "петропавл",
    "петропавловск-казахстанский": "петропавл",
    # Oral / Uralsk
    "уральск": "орал",
    "oral": "орал",
    "орал": "орал",
    "uralsk": "орал",
    # Atyrau
    "гурьев": "атырау",
    "atyrau": "атырау",
    "guryev": "атырау",
    # Aktobe
    "актюбинск": "актобе",
    "aktobe": "актобе",
    "aktyubinsk": "актобе",
    "ақтөбе": "актобе",
    # Pavlodar
    "pavlodar": "павлодар",
    "павлодар": "павлодар",
    # Kyzylorda
    "кзыл-орда": "кызылорда",
    "kyzylorda": "кызылорда",
    "кызыл-орда": "кызылорда",
    "қызылорда": "кызылорда",
    # Kostanay
    "кустанай": "костанай",
    "kostanay": "костанай",
    "kustanay": "костанай",
    "қостанай": "костанай",
    # Aktau
    "шевченко": "актау",
    "aktau": "актау",
    "ақтау": "актау",
    # Turkestan
    "turkestan": "туркестан",
    "түркістан": "туркестан",
    # Kokshetau
    "кокчетав": "кокшетау",
    "kokshetau": "кокшетау",
    "көкшетау": "кокшетау",
    # Konaev (ex-Kapshagay)
    "капшагай": "конаев",
    "қонаев": "конаев",
    "kapshagay": "конаев",
    "capchagay": "конаев",
    "конаев": "конаев",
    # Taldykorgan
    "taldykorgan": "талдыкорган",
    "талдықорған": "талдыкорган",
    # Ekibastuz
    "ekibastuz": "экибастуз",
    "екібастұз": "экибастуз",
    # Rudny
    "rudny": "рудный",
    # Temirtau
    "temirtau": "темиртау",
    "теміртау": "темиртау",
    # Zhezkazgan
    "джезказган": "жезказган",
    "zhezkazgan": "жезказган",
    "жезқазған": "жезказган",
    # Karaganda
    "караганда": "қарағанды",
    "karaganda": "қарағанды",
    "karagandy": "қарағанды",
    "карагандa": "қарағанды",
    # Saran
    "сарань": "саран",
    "saran": "саран",
    # Balkhash
    "balkhash": "балхаш",
    "балқаш": "балхаш",
    # Zhanaozen
    "жанаозен": "жаңаөзен",
    "zhanaozen": "жаңаөзен",
    "новый узень": "жаңаөзен",
    # Satpaev
    "сатпаев": "сатпаев",
    "satpayev": "сатпаев",
    "никольский": "сатпаев",
    # Arkalyk
    "аркалык": "аркалык",
    "arkalyk": "аркалык",
    "арқалық": "аркалык",
    # Shakhtinsk
    "шахтинск": "шахтинск",
    "shakhtinsk": "шахтинск",
    # Saryagash
    "сарыагаш": "сарыагаш",
    "saryagash": "сарыагаш",
    # Kentau
    "kentau": "кентау",
    # Ridder
    "лениногорск": "риддер",
    "ridder": "риддер",
    # Stepnogorsk
    "степногорск": "степногорск",
    "stepnogorsk": "степногорск",
    # Lisakovsk
    "лисаковск": "лисаковск",
    "lisakovsk": "лисаковск",
    # Karatau
    "каратау": "каратау",
    "karatau": "каратау",
    # ── Regions (oblast shorthand → full name) ────────────────────────────────
    "карагандинская": "карагандинская область",
    "акмолинская": "акмолинская область",
    "алматинская": "алматинская область",
    "актюбинская": "актюбинская область",
    "атырауская": "атырауская область",
    "жамбылская": "жамбылская область",
    "жетiсу": "область жетісу",
    "жетысу": "область жетісу",
    "жетісу": "область жетісу",
    "улытау": "область ұлытау",
    "ұлытау": "область ұлытау",
    # Common English region labels used by public registries.
    "almaty region": "алматинская область",
    "turkistan region": "туркестанская область",
    "aktobe region": "актюбинская область",
    "karaganda region": "карагандинская область",
    "mangystau region": "мангистауская область",
    "абай": "область абай",
    "абай облысы": "область абай",
    "восточный казахстан": "восточно-казахстанская область",
    "вко": "восточно-казахстанская область",
    "западный казахстан": "западно-казахстанская область",
    "зко": "западно-казахстанская область",
    "северный казахстан": "северо-казахстанская область",
    "ско": "северо-казахстанская область",
    "туркестанская": "туркестанская область",
    "южный казахстан": "туркестанская область",
    "юко": "туркестанская область",
    "кызылординская": "кызылординская область",
    "костанайская": "костанайская область",
    "мангыстауская": "мангистауская область",
    "мангистауская": "мангистауская область",
    "павлодарская": "павлодарская область",
}


# ══════════════════════════════════════════════════════════════════════════════
# Normalization
# ══════════════════════════════════════════════════════════════════════════════

_SUFFIX_RE = re.compile(
    r"\s+(область|облысы|обл\.?|город|г\.?|қаласы|қ\.?|ауданы|р-н\.?|район)$",
    re.IGNORECASE,
)


def normalize_location(name: str) -> str:
    """Normalize a Kazakhstan location name to its canonical form.

    Handles historical names, transliterations, Kazakh originals,
    and common abbreviations.  Returns the canonical Russian name,
    or the original (lowercased, trimmed) if no alias found.

    Examples::

        >>> normalize_location("Нур-Султан")
        'астана'
        >>> normalize_location("Alma-Ata")
        'алматы'
        >>> normalize_location("Семипалатинск")
        'семей'
        >>> normalize_location("ВКО")
        'восточно-казахстанская область'
        >>> normalize_location("Unknown City")
        'unknown city'
    """
    q = name.strip().lower()
    # Remove common suffixes
    q_clean = _SUFFIX_RE.sub("", q)
    # Try cleaned version first, then original
    return KZ_ALIASES.get(q_clean, KZ_ALIASES.get(q, q))


# ══════════════════════════════════════════════════════════════════════════════
# Reverse lookup
# ══════════════════════════════════════════════════════════════════════════════

# Build reverse index: canonical → [alias1, alias2, ...]
_REVERSE_ALIASES: dict[str, list[str]] | None = None


def _build_reverse() -> dict[str, list[str]]:
    global _REVERSE_ALIASES
    if _REVERSE_ALIASES is None:
        rev: dict[str, list[str]] = {}
        for alias, canonical in KZ_ALIASES.items():
            rev.setdefault(canonical, []).append(alias)
        _REVERSE_ALIASES = rev
    return _REVERSE_ALIASES


def get_aliases(canonical_name: str) -> list[str]:
    """Return all known aliases for a canonical location name.

    Examples::

        >>> get_aliases("астана")
        ['нур-султан', 'нурсултан', 'nur-sultan', 'nursultan', 'акмола',
         'акмолинск', 'целиноград', 'astana', 'ақмола', 'нұр-сұлтан']
    """
    rev = _build_reverse()
    return rev.get(canonical_name.strip().lower(), [])


def is_known_location(name: str) -> bool:
    """Check if a name is a known Kazakhstan location (alias or canonical).

    Examples::

        >>> is_known_location("Нур-Султан")
        True
        >>> is_known_location("Москва")
        False
    """
    q = name.strip().lower()
    q_clean = _SUFFIX_RE.sub("", q)
    if q_clean in KZ_ALIASES or q in KZ_ALIASES:
        return True
    # Also check if it's a canonical name
    rev = _build_reverse()
    return q_clean in rev or q in rev


def search_locations(query: str) -> list[str]:
    """Fuzzy search across all known location names.

    Returns canonical names whose aliases or own name contain the query substring.

    Examples::

        >>> search_locations("караг")
        ['қарағанды', 'карагандинская область']
    """
    q = query.strip().lower()
    if not q:
        return []

    results: set[str] = set()
    for alias, canonical in KZ_ALIASES.items():
        if q in alias:
            results.add(canonical)
    # Also check canonical names themselves
    rev = _build_reverse()
    for canonical in rev:
        if q in canonical:
            results.add(canonical)
    return sorted(results)
