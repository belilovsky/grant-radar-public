"""Deterministic regional coverage aggregation independent of map rendering."""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Callable, Iterable
from dataclasses import dataclass
from typing import TypeVar

from qazstack.geo.aliases import normalize_location, region_name_to_code

T = TypeVar("T")


@dataclass(frozen=True, slots=True)
class RegionCoverage:
    region_code: str
    total: int
    published: int

    def __post_init__(self) -> None:
        if not self.region_code.strip():
            raise ValueError("region_code must be non-empty")
        if self.total < 0 or self.published < 0 or self.published > self.total:
            raise ValueError("coverage counts must satisfy 0 <= published <= total")

    @property
    def state(self) -> str:
        if self.published == 0:
            return "collecting"
        if self.published < self.total:
            return "partial"
        return "published"


def aggregate_region_coverage(
    records: Iterable[T],
    *,
    region_of: Callable[[T], str | None],
    is_published: Callable[[T], bool],
) -> list[RegionCoverage]:
    """Count total and public records by canonical Kazakhstan region code."""

    totals: dict[str, int] = defaultdict(int)
    published: dict[str, int] = defaultdict(int)
    for record in records:
        raw_region = region_of(record)
        if not raw_region:
            continue
        canonical_name = normalize_location(raw_region)
        region_code = region_name_to_code(canonical_name) or raw_region.strip().lower()
        totals[region_code] += 1
        if is_published(record):
            published[region_code] += 1
    return [RegionCoverage(region_code=code, total=totals[code], published=published[code]) for code in sorted(totals)]
