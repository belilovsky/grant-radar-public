"""Pydantic models for QazGeo API responses.

Typed response objects so consumers don't work with raw dicts.
All models are optional-field-friendly – missing API fields won't crash.

Usage::

    from qazstack.geo import GeoClient
    from qazstack.geo.models import RegionFeature, City, GeocodingResult

    client = GeoClient()
    result = await client.geocode("Алматы")
    parsed = GeocodingResult.model_validate(result)
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


# ── Enums ─────────────────────────────────────────────────────────────────────


class RegionType(str, Enum):
    oblast = "oblast"
    city = "city"


class GroupABC(str, Enum):
    A = "A"
    B = "B"
    C = "C"


class CityType(str, Enum):
    city = "city"
    town = "town"
    village = "village"


class POIType(str, Enum):
    shelter = "shelter"
    media = "media"
    gov = "gov"
    other = "other"
    hospital = "hospital"
    school = "school"
    university = "university"
    bank = "bank"
    police = "police"
    fire_station = "fire_station"
    pharmacy = "pharmacy"
    post_office = "post_office"
    mosque = "mosque"
    church = "church"
    airport = "airport"
    railway_station = "railway_station"
    bus_station = "bus_station"
    fuel = "fuel"
    market = "market"
    restaurant = "restaurant"


class InfraType(str, Enum):
    highway = "highway"
    primary_road = "primary_road"
    secondary_road = "secondary_road"
    railway = "railway"
    pipeline_oil = "pipeline_oil"
    pipeline_gas = "pipeline_gas"
    waterway_river = "waterway_river"
    waterway_canal = "waterway_canal"


class WaterBodyType(str, Enum):
    lake = "lake"
    reservoir = "reservoir"
    sea = "sea"


# ── GeoJSON primitives ───────────────────────────────────────────────────────


class Geometry(BaseModel):
    """GeoJSON geometry object."""

    type: str
    coordinates: Any


class GeoJSONProperties(BaseModel, extra="allow"):
    """Region properties embedded in GeoJSON features."""

    code: str | None = None
    name_ru: str | None = None
    name_kz: str | None = None
    name_en: str | None = None
    region_type: str | None = None
    group: str | None = None
    capital: str | None = None
    population: int | None = None
    area_km2: float | None = None


class GeoJSONFeature(BaseModel, extra="allow"):
    """A single GeoJSON Feature."""

    type: str = "Feature"
    id: str | None = None
    geometry: Geometry | None = None
    properties: dict[str, Any] = Field(default_factory=dict)


class FeatureCollection(BaseModel, extra="allow"):
    """GeoJSON FeatureCollection."""

    type: str = "FeatureCollection"
    features: list[GeoJSONFeature] = Field(default_factory=list)
    metadata: dict[str, Any] | None = None


# ── Domain models ─────────────────────────────────────────────────────────────


class Region(BaseModel, extra="allow"):
    """A Kazakhstan region (oblast or city of republican significance)."""

    id: int | None = None
    code: str
    name_ru: str
    name_kz: str | None = None
    name_en: str | None = None
    region_type: RegionType | None = None
    group: GroupABC | None = None
    capital: str | None = None
    population: int | None = None
    area_km2: float | None = None


class City(BaseModel, extra="allow"):
    """A city or settlement."""

    id: int | None = None
    name_ru: str
    name_kz: str | None = None
    name_en: str | None = None
    city_type: CityType | None = None
    region_id: int | None = None
    region_code: str | None = None
    lat: float | None = None
    lon: float | None = None
    population: int | None = None


class RegionStats(BaseModel, extra="allow"):
    """Demographic and economic statistics for a region."""

    region_code: str | None = None
    region_name: str | None = None
    year: int | None = None
    population: int | None = None
    urban_pct: float | None = None
    avg_salary: float | None = None
    unemployment_pct: float | None = None
    grp_bln_tenge: float | None = None


# ── Geocoding response models ────────────────────────────────────────────────


class GeocodingResult(BaseModel, extra="allow"):
    """Response from /geocode endpoint."""

    query: str | None = None
    lat: float | None = None
    lon: float | None = None
    region_code: str | None = None
    region_name: str | None = None
    city: str | None = None
    confidence: float | None = None
    source: str | None = None


class ReverseGeocodingResult(BaseModel, extra="allow"):
    """Response from /reverse endpoint."""

    lat: float | None = None
    lon: float | None = None
    region_code: str | None = None
    region_name: str | None = None
    nearest_city: str | None = None
    distance_km: float | None = None


class LocateTextResult(BaseModel, extra="allow"):
    """Single text location detection result."""

    text: str | None = None
    region_code: str | None = None
    region_name: str | None = None
    confidence: float | None = None
    matched_term: str | None = None


class LocateTextsResponse(BaseModel, extra="allow"):
    """Response from /locate-texts endpoint."""

    results: list[LocateTextResult] = Field(default_factory=list)
    total: int | None = None
    matched: int | None = None


# ── Infrastructure & Water ────────────────────────────────────────────────────


class InfrastructureObject(BaseModel, extra="allow"):
    """Road, railway, or pipeline."""

    id: int | None = None
    name: str | None = None
    infra_type: InfraType | None = None
    region_code: str | None = None
    length_km: float | None = None


class WaterBody(BaseModel, extra="allow"):
    """Lake, reservoir, or sea."""

    id: int | None = None
    name: str | None = None
    water_type: WaterBodyType | None = None
    region_code: str | None = None
    area_km2: float | None = None


# ── Strata ────────────────────────────────────────────────────────────────────


class Stratum(BaseModel, extra="allow"):
    """Communication stratum for a region."""

    code: str | None = None
    region_code: str | None = None
    region_name: str | None = None
    group: GroupABC | None = None
    description: str | None = None


# ── Analytics ─────────────────────────────────────────────────────────────────


class DeadLoopResult(BaseModel, extra="allow"):
    """Dead Loop analysis result."""

    regions: list[dict[str, Any]] = Field(default_factory=list)
    summary: dict[str, Any] = Field(default_factory=dict)


class SaturationResult(BaseModel, extra="allow"):
    """Saturation curve analysis result."""

    curves: list[dict[str, Any]] = Field(default_factory=list)
    summary: dict[str, Any] = Field(default_factory=dict)


# ── Health ────────────────────────────────────────────────────────────────────


class HealthResponse(BaseModel, extra="allow"):
    """QazGeo health check response."""

    status: str = "ok"
    version: str | None = None
    regions_count: int | None = None
    cities_count: int | None = None
    poi_count: int | None = None
    uptime_seconds: float | None = None
