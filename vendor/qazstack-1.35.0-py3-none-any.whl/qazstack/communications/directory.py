"""HTTP client and cache records for public communications directories."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone

import httpx

from qazstack.communications.models import CommunicationDirectory


class DirectoryFetchError(ValueError):
    """Raised when a public directory cannot be retrieved or validated."""


@dataclass(frozen=True, slots=True)
class DirectoryCacheEntry:
    """Validated directory response that a consumer may retain using its ETag."""

    directory: CommunicationDirectory
    etag: str | None
    fetched_at: datetime


@dataclass(frozen=True, slots=True)
class DirectoryFetchResult:
    """Directory response and whether an existing validated cache was reused."""

    cache: DirectoryCacheEntry
    not_modified: bool = False


class CommunicationDirectoryClient:
    """Fetch and validate a public directory without delivery credentials."""

    def __init__(self, *, timeout: float = 10.0, user_agent: str = "qazstack-communications/1") -> None:
        if timeout <= 0:
            raise ValueError("timeout must be positive")
        self.timeout = timeout
        self.user_agent = user_agent

    def fetch(
        self,
        url: str,
        *,
        cached: DirectoryCacheEntry | None = None,
        client: httpx.Client | None = None,
    ) -> DirectoryFetchResult:
        """Fetch an HTTPS directory and honor a previously validated ETag."""
        headers = {"Accept": "application/json", "User-Agent": self.user_agent}
        if cached and cached.etag:
            headers["If-None-Match"] = cached.etag
        owned = client is None
        active = client or httpx.Client(timeout=self.timeout, follow_redirects=True)
        try:
            response = active.get(url, headers=headers)
        except httpx.HTTPError as exc:
            raise DirectoryFetchError(f"communications directory request failed: {exc.__class__.__name__}") from exc
        finally:
            if owned:
                active.close()
        if response.status_code == 304:
            if cached is None:
                raise DirectoryFetchError("communications directory returned 304 without a validated cache")
            return DirectoryFetchResult(cached, not_modified=True)
        if response.status_code != 200:
            raise DirectoryFetchError(f"communications directory returned HTTP {response.status_code}")
        content_type = response.headers.get("content-type", "").lower()
        if "application/json" not in content_type:
            raise DirectoryFetchError("communications directory must return application/json")
        try:
            directory = CommunicationDirectory.model_validate(response.json())
        except (ValueError, TypeError) as exc:
            raise DirectoryFetchError(f"communications directory is invalid: {exc}") from exc
        return DirectoryFetchResult(
            DirectoryCacheEntry(
                directory=directory,
                etag=response.headers.get("etag"),
                fetched_at=datetime.now(timezone.utc),
            )
        )
