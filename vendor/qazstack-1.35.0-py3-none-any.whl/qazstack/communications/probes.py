"""Public smoke checks for communication directories and contact surfaces."""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Iterable

import httpx

from qazstack.communications.directory import CommunicationDirectoryClient, DirectoryFetchError


@dataclass(frozen=True, slots=True)
class CommunicationProbeResult:
    """One public communications check with no access to an operator queue."""

    name: str
    status: str
    elapsed_ms: float
    detail: str

    @property
    def ok(self) -> bool:
        return self.status == "ok"


def probe_communications_directory(
    url: str,
    *,
    required_domains: Iterable[str] = (),
    client: httpx.Client | None = None,
) -> CommunicationProbeResult:
    """Verify response type, schema and the public routes a product depends on."""
    started = time.monotonic()
    try:
        result = CommunicationDirectoryClient().fetch(url, client=client)
        domains = {route.domain for route in result.cache.directory.routes}
        missing = sorted({domain.strip().lower().rstrip(".") for domain in required_domains} - domains)
        if missing:
            status, detail = "error", f"missing domains: {', '.join(missing)}"
        else:
            status, detail = "ok", f"{len(domains)} routes"
    except DirectoryFetchError as exc:
        status, detail = "error", str(exc)
    return CommunicationProbeResult(
        "communications-directory",
        status,
        round((time.monotonic() - started) * 1000, 1),
        detail,
    )


def probe_contact_surface(
    url: str,
    *,
    contact_email: str,
    client: httpx.Client | None = None,
    timeout: float = 10.0,
) -> CommunicationProbeResult:
    """Check that a public page exposes the expected canonical contact route."""
    if timeout <= 0:
        raise ValueError("timeout must be positive")
    started = time.monotonic()
    owned = client is None
    active = client or httpx.Client(timeout=timeout, follow_redirects=True)
    try:
        response = active.get(url)
        if response.status_code != 200:
            status, detail = "error", f"HTTP {response.status_code}"
        elif contact_email.lower() not in response.text.lower():
            status, detail = "error", "canonical contact address is not published"
        else:
            status, detail = "ok", "canonical contact address published"
    except httpx.HTTPError as exc:
        status, detail = "error", exc.__class__.__name__
    finally:
        if owned:
            active.close()
    return CommunicationProbeResult(
        "communications-contact-surface",
        status,
        round((time.monotonic() - started) * 1000, 1),
        detail,
    )
