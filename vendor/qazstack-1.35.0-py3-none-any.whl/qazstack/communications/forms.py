"""Public feedback-form specification and privacy-safe submission receipts."""

from __future__ import annotations

import re
from datetime import datetime, timezone
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

from qazstack.communications.models import _OPAQUE_REF_RE, _ROUTE_ID_RE

FormField = Literal["name", "email", "message"]

_FIELD_NAME_RE = re.compile(r"^[a-z][a-z0-9_]{1,63}$")


def utc_now() -> datetime:
    """Return a timezone-aware UTC timestamp."""
    return datetime.now(timezone.utc)


class FeedbackFormSpec(BaseModel):
    """Browser-safe form contract; it never contains a submitted message."""

    model_config = ConfigDict(extra="forbid")

    schema_version: Literal["qazstack-communications-form-v1"] = "qazstack-communications-form-v1"
    route_id: str = Field(min_length=1, max_length=128)
    endpoint_path: str = Field(pattern=r"^/[A-Za-z0-9._~!$&'()*+,;=:@/%-]*$")
    locales: list[Literal["kk", "ru", "en"]] = Field(min_length=1, max_length=3)
    fields: list[FormField] = Field(default_factory=lambda: ["name", "email", "message"], min_length=1, max_length=3)
    consent_required: bool = True
    honeypot_field: str = "website"
    rate_limit_window_seconds: int = Field(default=3600, ge=60, le=86_400)
    rate_limit_max_submissions: int = Field(default=5, ge=1, le=100)

    @field_validator("route_id")
    @classmethod
    def validate_route_id(cls, value: str) -> str:
        normalized = value.strip().lower()
        if not _ROUTE_ID_RE.fullmatch(normalized):
            raise ValueError("route_id must use lowercase letters, digits and hyphens")
        return normalized

    @field_validator("locales", "fields")
    @classmethod
    def reject_duplicates(cls, value: list[str]) -> list[str]:
        if len(set(value)) != len(value):
            raise ValueError("form values must not contain duplicates")
        return value

    @field_validator("honeypot_field")
    @classmethod
    def validate_honeypot_field(cls, value: str) -> str:
        normalized = value.strip().lower()
        if not _FIELD_NAME_RE.fullmatch(normalized):
            raise ValueError("honeypot_field must be a stable field identifier")
        return normalized


class FeedbackSubmissionReceipt(BaseModel):
    """Public outcome after a product-owned backend accepts a feedback form."""

    model_config = ConfigDict(extra="forbid")

    schema_version: Literal["qazstack-communications-receipt-v1"] = "qazstack-communications-receipt-v1"
    route_id: str = Field(min_length=1, max_length=128)
    submission_ref: str = Field(pattern=r"^sha256:[a-f0-9]{64}$")
    accepted_at: datetime = Field(default_factory=utc_now)
    status: Literal["accepted", "rate_limited", "rejected"]

    @field_validator("route_id")
    @classmethod
    def validate_route_id(cls, value: str) -> str:
        normalized = value.strip().lower()
        if not _ROUTE_ID_RE.fullmatch(normalized):
            raise ValueError("route_id must use lowercase letters, digits and hyphens")
        return normalized

    @field_validator("submission_ref")
    @classmethod
    def validate_submission_reference(cls, value: str) -> str:
        if not _OPAQUE_REF_RE.fullmatch(value):
            raise ValueError("submission_ref must be a sha256 opaque reference")
        return value
