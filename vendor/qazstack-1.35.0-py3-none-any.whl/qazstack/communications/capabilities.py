"""Typed public capability record for a communications service boundary."""

from __future__ import annotations

from typing import Literal

import httpx
from pydantic import BaseModel, ConfigDict, Field, HttpUrl, model_validator

CapabilityStatus = Literal["available", "contract_only"]
CAPABILITIES_SCHEMA_VERSION = "qazstack-communications-capabilities-v1"


class CommunicationCapability(BaseModel):
    """One contract advertised by a communications service."""

    model_config = ConfigDict(extra="forbid")

    status: CapabilityStatus
    schema_version: str = Field(min_length=1, max_length=128)
    boundary: str | None = Field(default=None, max_length=128)


class CommunicationsCapabilities(BaseModel):
    """Public record that distinguishes a live endpoint from contract-only support."""

    model_config = ConfigDict(extra="forbid")

    schema_version: Literal["qazstack-communications-capabilities-v1"] = CAPABILITIES_SCHEMA_VERSION
    directory_url: HttpUrl
    consumer_contract_url: HttpUrl
    route_count: int = Field(ge=1, le=500)
    capabilities: dict[str, CommunicationCapability]

    @model_validator(mode="after")
    def validate_capability_boundary(self) -> CommunicationsCapabilities:
        expected = {"directory", "feedback_forms", "signed_webhooks", "response_operations"}
        if set(self.capabilities) != expected:
            raise ValueError("capabilities must contain the standard communications capability keys")
        if self.capabilities["directory"].status != "available":
            raise ValueError("directory capability must be available")
        for key in expected - {"directory"}:
            if self.capabilities[key].status == "available":
                raise ValueError(f"{key} must remain contract_only until a product activates it")
        return self


class CommunicationsCapabilitiesClient:
    """Fetch a capability record without gaining mailbox or queue access."""

    def __init__(self, *, timeout: float = 10.0, user_agent: str = "qazstack-communications/1") -> None:
        if timeout <= 0:
            raise ValueError("timeout must be positive")
        self.timeout = timeout
        self.user_agent = user_agent

    def fetch(self, url: str, *, client: httpx.Client | None = None) -> CommunicationsCapabilities:
        """Fetch and validate a public JSON capability record."""
        owned = client is None
        active = client or httpx.Client(timeout=self.timeout, follow_redirects=True)
        try:
            response = active.get(url, headers={"Accept": "application/json", "User-Agent": self.user_agent})
        except httpx.HTTPError as exc:
            raise ValueError(f"communications capabilities request failed: {exc.__class__.__name__}") from exc
        finally:
            if owned:
                active.close()
        if response.status_code != 200:
            raise ValueError(f"communications capabilities returned HTTP {response.status_code}")
        if "application/json" not in response.headers.get("content-type", "").lower():
            raise ValueError("communications capabilities must return application/json")
        try:
            return CommunicationsCapabilities.model_validate(response.json())
        except (TypeError, ValueError) as exc:
            raise ValueError(f"communications capabilities are invalid: {exc}") from exc
