"""Response-time policy and aggregate operational status for communications."""

from __future__ import annotations

from datetime import datetime, timedelta
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

from qazstack.communications.ledger import CommunicationState
from qazstack.communications.models import _OPAQUE_REF_RE, _ROUTE_ID_RE

SlaStatus = Literal["pending", "met", "breached", "not_applicable"]


class ResponsePolicy(BaseModel):
    """Route-level response targets without operator names or message content."""

    model_config = ConfigDict(extra="forbid")

    route_id: str = Field(min_length=1, max_length=128)
    first_response_minutes: int = Field(ge=1, le=43_200)
    resolution_minutes: int = Field(ge=1, le=129_600)
    escalation_after_minutes: int | None = Field(default=None, ge=1, le=129_600)

    @field_validator("route_id")
    @classmethod
    def validate_route_id(cls, value: str) -> str:
        normalized = value.strip().lower()
        if not _ROUTE_ID_RE.fullmatch(normalized):
            raise ValueError("route_id must use lowercase letters, digits and hyphens")
        return normalized

    @field_validator("escalation_after_minutes")
    @classmethod
    def validate_escalation(cls, value: int | None, info) -> int | None:
        if value is not None and "resolution_minutes" in info.data and value > info.data["resolution_minutes"]:
            raise ValueError("escalation_after_minutes must not exceed resolution_minutes")
        return value


class CommunicationSlaEvaluation(BaseModel):
    """Computed SLA outcome for one opaque conversation reference."""

    model_config = ConfigDict(extra="forbid")

    route_id: str
    conversation_ref: str = Field(pattern=r"^sha256:[a-f0-9]{64}$")
    state: CommunicationState
    first_response_status: SlaStatus
    resolution_status: SlaStatus
    first_response_due_at: datetime
    resolution_due_at: datetime
    escalation_due_at: datetime | None = None


class CommunicationOperationsSnapshot(BaseModel):
    """Aggregate counts intended for dashboards, never a queue export."""

    model_config = ConfigDict(extra="forbid")

    schema_version: Literal["qazstack-communications-operations-v1"] = "qazstack-communications-operations-v1"
    route_id: str
    measured_at: datetime
    open_count: int = Field(ge=0)
    overdue_first_response_count: int = Field(ge=0)
    overdue_resolution_count: int = Field(ge=0)
    delivery_retry_count: int = Field(ge=0)


def evaluate_response_policy(
    policy: ResponsePolicy,
    *,
    conversation_ref: str,
    received_at: datetime,
    state: CommunicationState,
    evaluated_at: datetime,
    first_response_at: datetime | None = None,
    closed_at: datetime | None = None,
) -> CommunicationSlaEvaluation:
    """Evaluate one opaque lifecycle against a product-owned response policy."""
    if not _OPAQUE_REF_RE.fullmatch(conversation_ref):
        raise ValueError("conversation_ref must be a sha256 opaque reference")
    if any(value.tzinfo is None or value.utcoffset() is None for value in (received_at, evaluated_at)):
        raise ValueError("received_at and evaluated_at must be timezone-aware")
    first_due = received_at + timedelta(minutes=policy.first_response_minutes)
    resolution_due = received_at + timedelta(minutes=policy.resolution_minutes)
    first_status: SlaStatus
    if first_response_at is not None:
        first_status = "met" if first_response_at <= first_due else "breached"
    elif state == "closed":
        first_status = "not_applicable"
    else:
        first_status = "breached" if evaluated_at > first_due else "pending"
    if closed_at is not None:
        resolution_status: SlaStatus = "met" if closed_at <= resolution_due else "breached"
    elif state == "closed":
        resolution_status = "not_applicable"
    else:
        resolution_status = "breached" if evaluated_at > resolution_due else "pending"
    return CommunicationSlaEvaluation(
        route_id=policy.route_id,
        conversation_ref=conversation_ref,
        state=state,
        first_response_status=first_status,
        resolution_status=resolution_status,
        first_response_due_at=first_due,
        resolution_due_at=resolution_due,
        escalation_due_at=(
            received_at + timedelta(minutes=policy.escalation_after_minutes)
            if policy.escalation_after_minutes is not None
            else None
        ),
    )
