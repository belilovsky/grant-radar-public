"""Metadata-only lifecycle records for product-owned durable stores."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from qazstack.communications.models import _OPAQUE_REF_RE, _ROUTE_ID_RE

CommunicationState = Literal["received", "assigned", "replied", "closed", "delivery_failed"]
DeliveryOutcome = Literal["not_applicable", "accepted", "retry", "rejected"]

_ALLOWED_TRANSITIONS: dict[CommunicationState | None, frozenset[CommunicationState]] = {
    None: frozenset({"received"}),
    "received": frozenset({"assigned", "replied", "closed", "delivery_failed"}),
    "assigned": frozenset({"replied", "closed", "delivery_failed"}),
    "replied": frozenset({"replied", "closed"}),
    "closed": frozenset(),
    "delivery_failed": frozenset({"received", "closed"}),
}


def utc_now() -> datetime:
    """Return a timezone-aware UTC timestamp."""
    return datetime.now(timezone.utc)


def validate_transition(previous: CommunicationState | None, current: CommunicationState) -> None:
    """Validate a lifecycle transition without providing a persistence layer."""
    if current not in _ALLOWED_TRANSITIONS[previous]:
        raise ValueError(f"invalid communication transition: {previous or 'start'} -> {current}")


class CommunicationLedgerEntry(BaseModel):
    """One append-only delivery or workflow record without message content."""

    model_config = ConfigDict(extra="forbid")

    schema_version: Literal["qazstack-communications-ledger-v1"] = "qazstack-communications-ledger-v1"
    entry_id: str = Field(pattern=r"^[a-z0-9][a-z0-9:_-]{1,127}$")
    route_id: str = Field(min_length=1, max_length=128)
    conversation_ref: str = Field(pattern=r"^sha256:[a-f0-9]{64}$")
    previous_state: CommunicationState | None = None
    state: CommunicationState
    occurred_at: datetime = Field(default_factory=utc_now)
    delivery_attempt: int = Field(default=0, ge=0, le=100)
    delivery_outcome: DeliveryOutcome = "not_applicable"
    reason_code: str | None = Field(default=None, pattern=r"^[a-z][a-z0-9_]{1,63}$")

    @field_validator("route_id")
    @classmethod
    def validate_route_id(cls, value: str) -> str:
        normalized = value.strip().lower()
        if not _ROUTE_ID_RE.fullmatch(normalized):
            raise ValueError("route_id must use lowercase letters, digits and hyphens")
        return normalized

    @field_validator("conversation_ref")
    @classmethod
    def validate_conversation_reference(cls, value: str) -> str:
        if not _OPAQUE_REF_RE.fullmatch(value):
            raise ValueError("conversation_ref must be a sha256 opaque reference")
        return value

    @model_validator(mode="after")
    def validate_lifecycle_record(self) -> CommunicationLedgerEntry:
        validate_transition(self.previous_state, self.state)
        if self.delivery_outcome != "not_applicable" and self.delivery_attempt == 0:
            raise ValueError("delivery_attempt must be positive when delivery_outcome is set")
        if self.state == "delivery_failed" and self.delivery_outcome not in {"retry", "rejected"}:
            raise ValueError("delivery_failed requires retry or rejected delivery_outcome")
        return self
