"""Small dependency-free validators shared by public contract models."""

from __future__ import annotations

import re
from datetime import datetime
from urllib.parse import urlparse

_IDENTIFIER_RE = re.compile(r"^[a-z0-9][a-z0-9._:-]{1,127}$")
_SEMVER_RE = re.compile(r"^[0-9]+\.[0-9]+\.[0-9]+(?:[-+][0-9A-Za-z.-]+)?$")
_SHA256_RE = re.compile(r"^(?:sha256:)?[a-f0-9]{64}$")


def require_text(value: str, field_name: str) -> str:
    value = value.strip()
    if not value:
        raise ValueError(f"{field_name} must be non-empty")
    return value


def require_identifier(value: str, field_name: str) -> str:
    value = require_text(value, field_name)
    if not _IDENTIFIER_RE.fullmatch(value):
        raise ValueError(f"{field_name} must be a stable lowercase identifier")
    return value


def require_one_of(value: str, allowed: frozenset[str], field_name: str) -> str:
    if value not in allowed:
        choices = ", ".join(sorted(allowed))
        raise ValueError(f"{field_name} must be one of: {choices}")
    return value


def require_positive(value: int | float, field_name: str, *, allow_zero: bool = False) -> None:
    if value < 0 or (not allow_zero and value == 0):
        qualifier = "non-negative" if allow_zero else "positive"
        raise ValueError(f"{field_name} must be {qualifier}")


def require_ratio(value: float, field_name: str) -> None:
    if not 0.0 <= value <= 1.0:
        raise ValueError(f"{field_name} must be between 0 and 1")


def require_aware(value: datetime, field_name: str) -> None:
    if value.tzinfo is None or value.utcoffset() is None:
        raise ValueError(f"{field_name} must be timezone-aware")


def require_semver(value: str, field_name: str = "version") -> str:
    value = require_text(value, field_name)
    if not _SEMVER_RE.fullmatch(value):
        raise ValueError(f"{field_name} must use SemVer")
    return value


def require_sha256(value: str, field_name: str = "digest") -> str:
    value = require_text(value, field_name).lower()
    if not _SHA256_RE.fullmatch(value):
        raise ValueError(f"{field_name} must be a SHA-256 digest")
    return value if value.startswith("sha256:") else f"sha256:{value}"


def require_http_url(value: str, field_name: str) -> str:
    value = require_text(value, field_name)
    parsed = urlparse(value)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise ValueError(f"{field_name} must be an HTTP(S) URL")
    return value
