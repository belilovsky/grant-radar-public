"""Consumer contract model, validation, compatibility and HTTP loading.

The module intentionally uses only the Python standard library. Consumers can
validate a contract before importing heavier QazStack runtime modules.
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse
from urllib.request import Request, urlopen

SCHEMA_VERSION = "qazstack-consumer-v1"
LIFECYCLES = frozenset({"planned", "pilot", "beta", "production", "archived"})
INTEGRATION_MODES = frozenset(
    {
        "python-package",
        "http-contract",
        "typescript-contract",
        "vendored-temporary",
        "vendored-release",
        "documented-only",
    }
)
REVISION_MODES = frozenset({"python-package", "vendored-temporary", "vendored-release"})
ENVIRONMENTS = frozenset({"local", "staging", "production", "private-runtime"})
ID_RE = re.compile(r"^[a-z0-9][a-z0-9-]{1,63}$")
VERSION_RE = re.compile(r"^(contract-only|[0-9]+\.[0-9]+\.[0-9]+)$")
DIGEST_RE = re.compile(r"^sha256:[a-f0-9]{64}$")
CONTRACT_KEYS = frozenset(
    {
        "schema_version",
        "project_id",
        "product_name",
        "lifecycle",
        "integration_mode",
        "qazstack_version",
        "source_revision",
        "primitives",
        "evidence",
        "owner",
        "notes",
    }
)
EVIDENCE_KEYS = frozenset(
    {
        "source_files",
        "test_commands",
        "runtime_urls",
        "verified_at",
        "environment",
        "source_revision",
        "schema_digest",
        "checked_by",
    }
)


class ConsumerContractError(ValueError):
    """Raised when a consumer contract violates the public contract."""


def _require_string(record: Mapping[str, Any], key: str) -> str:
    value = record.get(key)
    if not isinstance(value, str) or not value.strip():
        raise ConsumerContractError(f"{key} must be a non-empty string")
    return value


def _require_unique_strings(value: Any, key: str) -> tuple[str, ...]:
    if not isinstance(value, list) or any(not isinstance(item, str) or not item for item in value):
        raise ConsumerContractError(f"{key} must be an array of non-empty strings")
    if len(value) != len(set(value)):
        raise ConsumerContractError(f"{key} must not contain duplicates")
    return tuple(value)


def _parse_datetime(value: Any, key: str) -> datetime:
    if not isinstance(value, str):
        raise ConsumerContractError(f"{key} must be an ISO-8601 string")
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ConsumerContractError(f"{key} must be ISO-8601: {exc}") from exc


def validate_consumer_contract(record: Any, *, strict: bool = False) -> None:
    """Validate a consumer contract, with optional production readiness rules."""
    if not isinstance(record, Mapping):
        raise ConsumerContractError("contract root must be an object")
    required = {
        "schema_version",
        "project_id",
        "product_name",
        "lifecycle",
        "integration_mode",
        "qazstack_version",
        "primitives",
        "evidence",
    }
    missing = sorted(required - record.keys())
    if missing:
        raise ConsumerContractError(f"missing required fields: {', '.join(missing)}")
    unknown = sorted(record.keys() - CONTRACT_KEYS)
    if unknown:
        raise ConsumerContractError(f"unknown fields: {', '.join(unknown)}")
    if record["schema_version"] != SCHEMA_VERSION:
        raise ConsumerContractError(f"schema_version must be {SCHEMA_VERSION}")
    project_id = _require_string(record, "project_id")
    if not ID_RE.fullmatch(project_id):
        raise ConsumerContractError("project_id must be lowercase kebab-case, 2-64 characters")
    _require_string(record, "product_name")
    lifecycle = _require_string(record, "lifecycle")
    if lifecycle not in LIFECYCLES:
        raise ConsumerContractError(f"lifecycle must be one of: {', '.join(sorted(LIFECYCLES))}")
    mode = _require_string(record, "integration_mode")
    if mode not in INTEGRATION_MODES:
        raise ConsumerContractError(f"integration_mode must be one of: {', '.join(sorted(INTEGRATION_MODES))}")
    version = _require_string(record, "qazstack_version")
    if not VERSION_RE.fullmatch(version):
        raise ConsumerContractError("qazstack_version must be SemVer or contract-only")
    if mode in REVISION_MODES:
        _require_string(record, "source_revision")
    if "source_revision" in record and len(_require_string(record, "source_revision")) < 7:
        raise ConsumerContractError("source_revision must be a stable revision")
    if mode == "vendored-release" and version == "contract-only":
        raise ConsumerContractError("vendored-release consumers must declare a published SemVer version")
    primitives = _require_unique_strings(record["primitives"], "primitives")
    if any(not ID_RE.fullmatch(item) for item in primitives):
        raise ConsumerContractError("primitive ids must be lowercase kebab-case")

    evidence = record["evidence"]
    if not isinstance(evidence, Mapping):
        raise ConsumerContractError("evidence must be an object")
    unknown_evidence = sorted(evidence.keys() - EVIDENCE_KEYS)
    if unknown_evidence:
        raise ConsumerContractError(f"unknown evidence fields: {', '.join(unknown_evidence)}")
    _require_unique_strings(evidence.get("source_files"), "evidence.source_files")
    test_commands = _require_unique_strings(evidence.get("test_commands"), "evidence.test_commands")
    runtime_urls = _require_unique_strings(evidence.get("runtime_urls"), "evidence.runtime_urls")
    for url in runtime_urls:
        parsed = urlparse(url)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            raise ConsumerContractError(f"evidence.runtime_urls contains an invalid URL: {url}")
    if "verified_at" in evidence:
        _parse_datetime(evidence["verified_at"], "evidence.verified_at")
    if "environment" in evidence and evidence["environment"] not in ENVIRONMENTS:
        raise ConsumerContractError(f"evidence.environment must be one of: {', '.join(sorted(ENVIRONMENTS))}")
    for key in ("source_revision", "checked_by"):
        if key in evidence:
            _require_string(evidence, key)
    if "source_revision" in evidence and len(evidence["source_revision"]) < 7:
        raise ConsumerContractError("evidence.source_revision must be a stable revision")
    if "schema_digest" in evidence and (
        not isinstance(evidence["schema_digest"], str) or not DIGEST_RE.fullmatch(evidence["schema_digest"])
    ):
        raise ConsumerContractError("evidence.schema_digest must be a sha256: digest")
    for optional_key in ("owner", "notes"):
        if optional_key in record:
            _require_string(record, optional_key)
    if lifecycle in {"pilot", "beta", "production"} and not test_commands:
        raise ConsumerContractError("active consumers must provide at least one test command")
    if strict and not primitives:
        raise ConsumerContractError("strict validation requires at least one approved primitive")
    if strict and lifecycle == "production":
        if not runtime_urls:
            raise ConsumerContractError("production contracts require at least one runtime URL")
        if "verified_at" not in evidence:
            raise ConsumerContractError("production contracts require a verification timestamp")
        _require_string(record, "owner")


@dataclass(frozen=True, slots=True)
class ConsumerEvidence:
    source_files: tuple[str, ...]
    test_commands: tuple[str, ...]
    runtime_urls: tuple[str, ...]
    verified_at: str | None = None
    environment: str | None = None
    source_revision: str | None = None
    schema_digest: str | None = None
    checked_by: str | None = None


@dataclass(frozen=True, slots=True)
class ConsumerContract:
    project_id: str
    product_name: str
    lifecycle: str
    integration_mode: str
    qazstack_version: str
    primitives: tuple[str, ...]
    evidence: ConsumerEvidence
    source_revision: str | None = None
    owner: str | None = None
    notes: str | None = None
    schema_version: str = SCHEMA_VERSION

    @classmethod
    def from_mapping(cls, record: Mapping[str, Any], *, strict: bool = False) -> ConsumerContract:
        validate_consumer_contract(record, strict=strict)
        evidence = ConsumerEvidence(
            source_files=tuple(record["evidence"]["source_files"]),
            test_commands=tuple(record["evidence"]["test_commands"]),
            runtime_urls=tuple(record["evidence"]["runtime_urls"]),
            verified_at=record["evidence"].get("verified_at"),
            environment=record["evidence"].get("environment"),
            source_revision=record["evidence"].get("source_revision"),
            schema_digest=record["evidence"].get("schema_digest"),
            checked_by=record["evidence"].get("checked_by"),
        )
        return cls(
            schema_version=record["schema_version"],
            project_id=record["project_id"],
            product_name=record["product_name"],
            lifecycle=record["lifecycle"],
            integration_mode=record["integration_mode"],
            qazstack_version=record["qazstack_version"],
            source_revision=record.get("source_revision"),
            primitives=tuple(record["primitives"]),
            evidence=evidence,
            owner=record.get("owner"),
            notes=record.get("notes"),
        )

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["primitives"] = list(self.primitives)
        payload["evidence"] = asdict(self.evidence)
        payload["evidence"]["source_files"] = list(self.evidence.source_files)
        payload["evidence"]["test_commands"] = list(self.evidence.test_commands)
        payload["evidence"]["runtime_urls"] = list(self.evidence.runtime_urls)
        return _drop_none(payload)


def _drop_none(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: _drop_none(item) for key, item in value.items() if item is not None}
    return value


def load_consumer_contract(path: str | Path, *, strict: bool = False) -> ConsumerContract:
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    return ConsumerContract.from_mapping(payload, strict=strict)


def compatibility_status(contract_version: str, current_version: str) -> str:
    """Return current, supported, documented, legacy, incompatible or missing."""
    if not contract_version:
        return "missing"
    if contract_version == "contract-only":
        return "documented"
    try:
        contract = tuple(int(part) for part in contract_version.split("."))
        current = tuple(int(part) for part in current_version.split("."))
    except ValueError:
        return "incompatible"
    if len(contract) != 3 or len(current) != 3 or contract[0] != current[0]:
        return "incompatible"
    if contract == current:
        return "current"
    return "supported" if contract >= (1, 6, 0) and contract <= current else "legacy"


def contract_digest(contract: ConsumerContract | Mapping[str, Any]) -> str:
    payload = contract.to_dict() if isinstance(contract, ConsumerContract) else dict(contract)
    validate_consumer_contract(payload)
    canonical = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
    return f"sha256:{hashlib.sha256(canonical).hexdigest()}"


def publication_bundle(contract: ConsumerContract | Mapping[str, Any]) -> dict[str, Any]:
    payload = contract.to_dict() if isinstance(contract, ConsumerContract) else dict(contract)
    validate_consumer_contract(payload, strict=True)
    return {
        "schema_version": "qazstack-contract-publication-v1",
        "prepared_at": datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z"),
        "contract_digest": contract_digest(payload),
        "contract": payload,
    }


def contract_template(
    project_id: str,
    product_name: str,
    *,
    owner: str,
    qazstack_version: str,
    lifecycle: str = "production",
    integration_mode: str = "http-contract",
) -> dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION,
        "project_id": project_id,
        "product_name": product_name,
        "lifecycle": lifecycle,
        "integration_mode": integration_mode,
        "qazstack_version": qazstack_version,
        "primitives": [],
        "evidence": {
            "source_files": [],
            "test_commands": [],
            "runtime_urls": [],
            "verified_at": datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z"),
        },
        "owner": owner,
        "notes": "Complete primitives and evidence before publication.",
    }


class ConsumerContractClient:
    """Small dependency-free client for public consumer contract endpoints."""

    def __init__(self, *, timeout: float = 10.0, user_agent: str = "qazstack-contract-client/1") -> None:
        if timeout <= 0:
            raise ValueError("timeout must be positive")
        self.timeout = timeout
        self.user_agent = user_agent

    def fetch(self, url: str, *, strict: bool = False) -> ConsumerContract:
        parsed = urlparse(url)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            raise ConsumerContractError("contract URL must use http or https")
        request = Request(url, headers={"Accept": "application/json", "User-Agent": self.user_agent})
        try:
            with urlopen(request, timeout=self.timeout) as response:
                payload = json.loads(response.read().decode("utf-8"))
        except (HTTPError, URLError, TimeoutError, json.JSONDecodeError) as exc:
            raise ConsumerContractError(f"failed to fetch consumer contract: {exc}") from exc
        return ConsumerContract.from_mapping(payload, strict=strict)
