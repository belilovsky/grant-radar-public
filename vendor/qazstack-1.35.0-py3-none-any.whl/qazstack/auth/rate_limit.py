"""In-memory login rate limiter.

Tracks failed login attempts per IP to prevent brute-force attacks.
Per-process (not shared across workers). For multi-worker setups,
use a Redis-backed limiter.

Usage:
    from qazstack.auth import LoginRateLimiter

    login_limiter = LoginRateLimiter(max_attempts=5, window_seconds=300)

    @router.post("/login")
    async def login(request: Request):
        ip = request.client.host if request.client else "unknown"
        if login_limiter.is_blocked(ip):
            raise HTTPException(429, "Too many login attempts. Try again later.")

        user = authenticate(username, password)
        if not user:
            login_limiter.record_failure(ip)
            ...
        else:
            login_limiter.clear(ip)
            ...
"""

from __future__ import annotations

import time
from collections import defaultdict


class LoginRateLimiter:
    """In-memory rate limiter for login endpoints.

    Tracks failed attempts per key (typically IP address).
    Thread-safe for single-worker async apps.

    Args:
        max_attempts: Maximum failed attempts before blocking.
        window_seconds: Time window for attempt tracking (default: 300s = 5 min).
        max_tracked_keys: Soft cap on tracked IPs to prevent memory exhaustion.
    """

    def __init__(
        self,
        max_attempts: int = 5,
        window_seconds: int = 300,
        max_tracked_keys: int = 10_000,
    ):
        self.max_attempts = max_attempts
        self.window_seconds = window_seconds
        self.max_tracked_keys = max_tracked_keys
        self._attempts: dict[str, list[float]] = defaultdict(list)

    def is_blocked(self, key: str) -> bool:
        """Check if a key (IP) is rate-limited."""
        now = time.time()
        attempts = self._attempts.get(key)
        if not attempts:
            return False
        # Clean expired entries
        fresh = [t for t in attempts if now - t < self.window_seconds]
        if fresh:
            self._attempts[key] = fresh
        else:
            self._attempts.pop(key, None)
            return False
        return len(fresh) >= self.max_attempts

    def record_failure(self, key: str) -> None:
        """Record a failed login attempt.

        Evicts stale entries when the tracker exceeds max_tracked_keys.
        """
        if len(self._attempts) > self.max_tracked_keys:
            self._evict_stale()
        self._attempts[key].append(time.time())

    def clear(self, key: str) -> None:
        """Clear tracking for a key after successful login."""
        self._attempts.pop(key, None)

    def remaining_attempts(self, key: str) -> int:
        """Number of attempts left before blocking."""
        now = time.time()
        attempts = self._attempts.get(key, [])
        fresh = [t for t in attempts if now - t < self.window_seconds]
        return max(0, self.max_attempts - len(fresh))

    def _evict_stale(self) -> None:
        """Remove entries older than the window to prevent unbounded growth."""
        now = time.time()
        stale_keys = [
            k for k, v in self._attempts.items()
            if not v or now - v[-1] > self.window_seconds
        ]
        for k in stale_keys:
            self._attempts.pop(k, None)
