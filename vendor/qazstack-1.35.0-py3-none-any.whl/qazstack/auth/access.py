"""State-based access helpers for server-rendered FastAPI applications."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

from fastapi import HTTPException, Request, status


def normalize_role(role: Any) -> str:
    return str(role or "").strip().lower()


def role_of(user: Any, *, role_field: str = "role") -> str:
    if isinstance(user, Mapping):
        return normalize_role(user.get(role_field))
    return normalize_role(getattr(user, role_field, ""))


def current_user(request: Request, *, state_attribute: str = "current_user") -> Any | None:
    return getattr(request.state, state_attribute, None)


def has_role(user: Any, *roles: str, role_field: str = "role") -> bool:
    if not user:
        return False
    allowed = {normalize_role(role) for role in roles if role}
    return bool(allowed) and role_of(user, role_field=role_field) in allowed


def require_user(
    request: Request,
    *,
    state_attribute: str = "current_user",
    detail: str = "Authentication required",
) -> Any:
    user = current_user(request, state_attribute=state_attribute)
    if not user:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, detail)
    return user


def require_roles(
    request: Request,
    *roles: str,
    state_attribute: str = "current_user",
    role_field: str = "role",
    detail: str = "Insufficient role",
) -> Any:
    user = require_user(request, state_attribute=state_attribute)
    if roles and not has_role(user, *roles, role_field=role_field):
        raise HTTPException(status.HTTP_403_FORBIDDEN, detail)
    return user


def role_dependency(
    roles: Sequence[str],
    *,
    state_attribute: str = "current_user",
    role_field: str = "role",
):
    """Create a FastAPI dependency for state-based authentication."""

    async def _check(request: Request) -> Any:
        return require_roles(
            request,
            *roles,
            state_attribute=state_attribute,
            role_field=role_field,
        )

    return _check
