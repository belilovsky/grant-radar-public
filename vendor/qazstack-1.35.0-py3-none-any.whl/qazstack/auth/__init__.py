"""Auth module: session auth, JWT tokens, passwords, role-based access, rate limiting.

Session auth (Profile A – server-rendered):
    from qazstack.auth import SessionAuth, hash_password, verify_password

JWT auth (API clients):
    from qazstack.auth import JWTAuth

Role-based access:
    from qazstack.auth import require_role, require_any_role

Login rate limiting:
    from qazstack.auth import LoginRateLimiter

Utilities:
    from qazstack.auth import is_safe_redirect, get_client_ip
"""

from qazstack.auth.access import (
    current_user,
    has_role,
    normalize_role,
    require_roles,
    require_user,
    role_dependency,
    role_of,
)
from qazstack.auth.csrf import (
    DEFAULT_CSRF_COOKIE_NAME,
    DEFAULT_CSRF_HEADER_NAME,
    MAX_MULTIPART_CSRF_SCAN_BYTES,
    STATE_CHANGING_METHODS,
    CSRFMiddleware,
    csrf_context,
    get_csrf_token,
)
from qazstack.auth.origin import is_same_origin_request, parse_allowed_origins
from qazstack.auth.passwords import hash_password, verify_password
from qazstack.auth.policy import AccessDecision, SecurityResponsePolicy, SessionClaims, decide_access
from qazstack.auth.rate_limit import LoginRateLimiter
from qazstack.auth.roles import require_any_role, require_role
from qazstack.auth.session import SessionAuth
from qazstack.auth.utils import get_client_ip, is_safe_redirect

# JWTAuth requires PyJWT – lazy import
try:
    from qazstack.auth.jwt import JWTAuth
except ImportError:
    JWTAuth = None  # type: ignore

__all__ = [
    "hash_password",
    "verify_password",
    "SessionAuth",
    "JWTAuth",
    "require_role",
    "require_any_role",
    "LoginRateLimiter",
    "is_safe_redirect",
    "get_client_ip",
    "current_user",
    "has_role",
    "normalize_role",
    "require_roles",
    "require_user",
    "role_dependency",
    "role_of",
    "CSRFMiddleware",
    "DEFAULT_CSRF_COOKIE_NAME",
    "DEFAULT_CSRF_HEADER_NAME",
    "MAX_MULTIPART_CSRF_SCAN_BYTES",
    "STATE_CHANGING_METHODS",
    "csrf_context",
    "get_csrf_token",
    "is_same_origin_request",
    "parse_allowed_origins",
    "AccessDecision",
    "SecurityResponsePolicy",
    "SessionClaims",
    "decide_access",
]
