"""Role-based access control (RBAC) for FastAPI routes.

Simple role checking as FastAPI dependencies.
Works with both SessionAuth (role in session) and JWTAuth (role in token claims).

Usage:
    from qazstack.auth.roles import require_role, require_any_role

    @router.get("/admin/dashboard", dependencies=[Depends(require_role("admin"))])
    async def admin_dashboard():
        ...

    @router.get("/editor", dependencies=[Depends(require_any_role("admin", "editor"))])
    async def editor_page():
        ...
"""

from __future__ import annotations

from typing import Any, Callable

from fastapi import HTTPException, Request, status


def require_role(role: str, *, session_key: str = "user", role_field: str = "role") -> Callable:
    """FastAPI dependency: require user to have a specific role.

    Checks request.session[session_key][role_field] for session auth,
    or request.state.jwt_payload[role_field] for JWT auth.

    Args:
        role: Required role name.
        session_key: Key in session dict (default: "user").
        role_field: Field name containing the role (default: "role").
    """

    async def _check(request: Request) -> dict[str, Any]:
        user_data = _get_user_data(request, session_key, role_field)
        user_role = user_data.get(role_field)

        if user_role != role:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Role '{role}' required",
            )
        return user_data

    return _check


def require_any_role(*roles: str, session_key: str = "user", role_field: str = "role") -> Callable:
    """FastAPI dependency: require user to have any of the specified roles.

    Args:
        roles: Allowed role names.
        session_key: Key in session dict.
        role_field: Field name containing the role.
    """

    async def _check(request: Request) -> dict[str, Any]:
        user_data = _get_user_data(request, session_key, role_field)
        user_role = user_data.get(role_field)

        if user_role not in roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"One of roles {roles} required",
            )
        return user_data

    return _check


def _get_user_data(request: Request, session_key: str, role_field: str) -> dict[str, Any]:
    """Extract user data from session or JWT payload."""
    # Try session first
    if hasattr(request, "session"):
        user = request.session.get(session_key)
        if user and isinstance(user, dict):
            return user

    # Try JWT payload stored on request.state
    if hasattr(request.state, "jwt_payload"):
        payload = request.state.jwt_payload
        if payload and isinstance(payload, dict):
            return payload

    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Not authenticated",
    )
