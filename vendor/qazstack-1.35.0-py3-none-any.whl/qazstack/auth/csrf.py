"""Shared CSRF names and template-context helpers."""

from __future__ import annotations

import secrets
from collections import deque
from urllib.parse import parse_qs

from fastapi import Request
from starlette.responses import Response
from starlette.types import ASGIApp, Message, Receive, Scope, Send

DEFAULT_CSRF_COOKIE_NAME = "csrf_token"
DEFAULT_CSRF_HEADER_NAME = "X-CSRF-Token"
STATE_CHANGING_METHODS = frozenset({"POST", "PUT", "PATCH", "DELETE"})
MAX_MULTIPART_CSRF_SCAN_BYTES = 128 * 1024


def get_csrf_token(request: Request, *, cookie_name: str = DEFAULT_CSRF_COOKIE_NAME) -> str:
    return request.cookies.get(cookie_name, "")


def csrf_context(
    request: Request,
    *,
    cookie_name: str = DEFAULT_CSRF_COOKIE_NAME,
    header_name: str = DEFAULT_CSRF_HEADER_NAME,
) -> dict[str, str]:
    return {
        "csrf_token": get_csrf_token(request, cookie_name=cookie_name),
        "csrf_cookie_name": cookie_name,
        "csrf_header_name": header_name,
    }


class CSRFMiddleware:
    """Double-submit cookie CSRF protection for FastAPI/Starlette apps.

    The middleware accepts the token in ``X-CSRF-Token`` first, then falls back
    to a ``csrf_token`` form field for regular HTML forms. It is implemented as
    pure ASGI middleware so downstream handlers can still read request bodies.
    """

    def __init__(
        self,
        app: ASGIApp,
        secret_key: str = "",
        *,
        cookie_name: str = DEFAULT_CSRF_COOKIE_NAME,
        header_name: str = DEFAULT_CSRF_HEADER_NAME,
        form_field_name: str = DEFAULT_CSRF_COOKIE_NAME,
        cookie_max_age: int = 86400,
        cookie_path: str = "/",
        cookie_same_site: str = "Lax",
        cookie_secure: bool = True,
        max_multipart_scan_bytes: int = MAX_MULTIPART_CSRF_SCAN_BYTES,
    ) -> None:
        self.app = app
        self.secret_key = secret_key
        self.cookie_name = cookie_name
        self.header_name = header_name
        self.form_field_name = form_field_name
        self.cookie_max_age = cookie_max_age
        self.cookie_path = cookie_path
        self.cookie_same_site = cookie_same_site
        self.cookie_secure = cookie_secure
        self.max_multipart_scan_bytes = max_multipart_scan_bytes

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        request = Request(scope, receive)
        csrf_token = request.cookies.get(self.cookie_name)
        if not csrf_token:
            csrf_token = secrets.token_urlsafe(32)

        scope.setdefault("state", {})
        scope["state"]["csrf_token"] = csrf_token

        if request.method.upper() in STATE_CHANGING_METHODS:
            content_type = request.headers.get("content-type", "")
            is_urlencoded_form = "application/x-www-form-urlencoded" in content_type
            is_multipart_form = "multipart/form-data" in content_type

            header_token = request.headers.get(self.header_name, "")
            if header_token:
                if header_token != csrf_token:
                    response = Response("CSRF token mismatch", status_code=403)
                    await response(scope, receive, send)
                    return
            elif is_urlencoded_form:
                receive = await self._validate_urlencoded(scope, receive, send, csrf_token)
                if receive is None:
                    return
            elif is_multipart_form:
                receive = await self._validate_multipart(scope, receive, send, csrf_token)
                if receive is None:
                    return
            else:
                response = Response("CSRF token missing", status_code=403)
                await response(scope, receive, send)
                return

        async def send_with_cookie(message: Message) -> None:
            if message["type"] == "http.response.start":
                headers = list(message.get("headers", []))
                secure = "; Secure" if self.cookie_secure else ""
                cookie_val = (
                    f"{self.cookie_name}={csrf_token}; Max-Age={self.cookie_max_age}; "
                    f"Path={self.cookie_path}; SameSite={self.cookie_same_site}{secure}"
                )
                headers.append((b"set-cookie", cookie_val.encode()))
                message = {**message, "headers": headers}
            await send(message)

        await self.app(scope, receive, send_with_cookie)

    async def _validate_urlencoded(
        self,
        scope: Scope,
        receive: Receive,
        send: Send,
        csrf_token: str,
    ) -> Receive | None:
        body_chunks: list[bytes] = []
        while True:
            message = await receive()
            body_chunks.append(message.get("body", b""))
            if not message.get("more_body", False):
                break
        full_body = b"".join(body_chunks)
        parsed = parse_qs(full_body.decode("utf-8", errors="replace"))
        form_token = parsed.get(self.form_field_name, [""])[0]

        if form_token != csrf_token:
            response = Response("CSRF token mismatch", status_code=403)
            await response(scope, receive, send)
            return None

        body_sent = False

        async def replay_receive() -> Message:
            nonlocal body_sent
            if not body_sent:
                body_sent = True
                return {"type": "http.request", "body": full_body, "more_body": False}
            return {"type": "http.disconnect"}

        return replay_receive

    async def _validate_multipart(
        self,
        scope: Scope,
        receive: Receive,
        send: Send,
        csrf_token: str,
    ) -> Receive | None:
        original_receive = receive
        buffered_messages: deque[Message] = deque()
        scanned = b""
        bytes_seen = 0
        field_marker = f'name="{self.form_field_name}"'.encode()

        while bytes_seen <= self.max_multipart_scan_bytes:
            message = await original_receive()
            buffered_messages.append(message)
            body = message.get("body", b"")
            bytes_seen += len(body)
            scanned += body
            if field_marker in scanned and csrf_token.encode() in scanned:
                break
            if not message.get("more_body", False):
                break

        if not (field_marker in scanned and csrf_token.encode() in scanned):
            response = Response("CSRF token missing", status_code=403)
            await response(scope, receive, send)
            return None

        async def replay_receive() -> Message:
            if buffered_messages:
                return buffered_messages.popleft()
            return await original_receive()

        return replay_receive
