"""Password hashing utilities.

Uses bcrypt directly (preferred) or passlib as fallback.
Falls back to SHA-256 if neither is available.

Usage:
    from qazstack.auth import hash_password, verify_password

    hashed = hash_password("my-secret")
    assert verify_password("my-secret", hashed)
"""

from __future__ import annotations


def hash_password(password: str) -> str:
    """Hash a password using bcrypt."""
    return _hash(password)


def verify_password(plain: str, hashed: str) -> bool:
    """Verify a password against its hash."""
    return _verify(plain, hashed)


# --- Backend selection ---
try:
    import bcrypt

    def _hash(password: str) -> str:
        return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")

    def _verify(plain: str, hashed: str) -> bool:
        try:
            return bcrypt.checkpw(plain.encode("utf-8"), hashed.encode("utf-8"))
        except Exception:
            return False

except ImportError:
    import hashlib
    import secrets

    def _hash(password: str) -> str:  # type: ignore[misc]
        """Fallback SHA-256 hashing (install bcrypt for production)."""
        salt = secrets.token_hex(16)
        h = hashlib.sha256(f"{salt}:{password}".encode()).hexdigest()
        return f"sha256:{salt}:{h}"

    def _verify(plain: str, hashed: str) -> bool:  # type: ignore[misc]
        if not hashed.startswith("sha256:"):
            return False
        _, salt, expected = hashed.split(":", 2)
        h = hashlib.sha256(f"{salt}:{plain}".encode()).hexdigest()
        return h == expected
