"""Origin checks for state-changing browser requests."""

from __future__ import annotations

from collections.abc import Iterable
from urllib.parse import urlparse

from fastapi import Request


def is_same_origin_request(request: Request) -> bool:
    """Reject explicit cross-site browser requests while allowing non-browser clients.

    Token verification remains the caller's responsibility. This helper only
    establishes whether Origin/Referer and Sec-Fetch-Site agree with the host.
    """
    if request.headers.get("sec-fetch-site", "").lower() == "cross-site":
        return False
    origin_value = request.headers.get("origin") or request.headers.get("referer")
    if not origin_value:
        return True
    origin = urlparse(origin_value)
    return not origin.netloc or origin.netloc == request.url.netloc


def parse_allowed_origins(raw: str | Iterable[str] | None) -> tuple[str, ...]:
    """Normalize explicit HTTP(S) origins and discard wildcard entries.

    The result is suitable for authenticated CORS middleware. Invalid values
    are rejected rather than silently widening access.
    """
    values = raw.split(",") if isinstance(raw, str) else (raw or ())
    origins: list[str] = []
    for value in values:
        candidate = str(value or "").strip()
        if not candidate or candidate == "*":
            continue
        parsed = urlparse(candidate)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            raise ValueError("allowed origins must be absolute HTTP(S) origins")
        if parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.path not in {"", "/"}:
            raise ValueError("allowed origins must not include credentials, path, query or fragment")
        normalized = f"{parsed.scheme.lower()}://{parsed.netloc.lower()}"
        if normalized not in origins:
            origins.append(normalized)
    return tuple(origins)
