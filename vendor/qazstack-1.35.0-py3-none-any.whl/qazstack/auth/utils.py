"""Auth utility functions.

Helpers for common auth patterns: safe redirects, client IP extraction.

Usage:
    from qazstack.auth import is_safe_redirect, get_client_ip

    if is_safe_redirect(next_url, request):
        return RedirectResponse(next_url)

    ip = get_client_ip(request)
"""

from __future__ import annotations

from urllib.parse import urlparse

from starlette.requests import Request


def is_safe_redirect(url: str | None, request: Request) -> bool:
    """Check if a redirect URL is safe (same-host, no open redirect).

    Returns True only for:
    - Relative paths starting with / (but not //)
    - Same-host absolute URLs

    Args:
        url: The URL to validate.
        request: Current request (for hostname comparison).
    """
    if not url:
        return False
    try:
        parsed = urlparse(url)
    except ValueError:
        return False
    # Reject non-http schemes
    if parsed.scheme and parsed.scheme not in {"http", "https"}:
        return False
    # Reject external hosts
    if parsed.netloc:
        return parsed.netloc == request.url.hostname
    # Must start with / but not // (protocol-relative)
    return url.startswith("/") and not url.startswith("//")


def get_client_ip(request: Request) -> str:
    """Extract client IP from request, respecting X-Forwarded-For.

    Uses X-Real-IP or first IP in X-Forwarded-For chain,
    falling back to request.client.host.
    """
    # X-Real-IP (set by Nginx)
    real_ip = request.headers.get("x-real-ip")
    if real_ip:
        return real_ip.strip()

    # X-Forwarded-For (first IP = original client)
    forwarded = request.headers.get("x-forwarded-for")
    if forwarded:
        return forwarded.split(",")[0].strip()

    # Direct connection
    if request.client:
        return request.client.host

    return "unknown"
