"""Cookie-based session auth for FastAPI.

Uses Starlette SessionMiddleware under the hood.
Works with Profile A (server-rendered) projects.

Usage:
    from qazstack.auth import SessionAuth

    auth = SessionAuth(secret_key=settings.secret_key)
    auth.setup(app)

    # In routes
    @app.post("/login")
    async def login(request: Request):
        user = authenticate(username, password)
        auth.login(request, user_id=user.id, extra={"role": "admin"})
        return RedirectResponse("/dashboard")

    @app.get("/dashboard")
    async def dashboard(request: Request):
        user_data = auth.require(request)  # raises 403 if not logged in
"""

from __future__ import annotations

from typing import Any

from fastapi import HTTPException, status
from starlette.requests import Request


class SessionAuth:
    """Simple cookie-based session authentication."""

    SESSION_KEY = "user"

    def __init__(
        self,
        secret_key: str,
        *,
        session_cookie: str = "session",
        max_age: int = 14 * 24 * 3600,  # 14 days
        https_only: bool = False,
    ):
        self.secret_key = secret_key
        self.session_cookie = session_cookie
        self.max_age = max_age
        self.https_only = https_only

    def setup(self, app) -> None:
        """Add SessionMiddleware to the FastAPI app."""
        try:
            from starlette.middleware.sessions import SessionMiddleware
        except ImportError as exc:
            raise ImportError("SessionAuth.setup() requires the 'auth' extra: pip install qazstack[auth]") from exc

        app.add_middleware(
            SessionMiddleware,
            secret_key=self.secret_key,
            session_cookie=self.session_cookie,
            max_age=self.max_age,
            https_only=self.https_only,
        )

    def login(self, request: Request, user_id: int | str, extra: dict[str, Any] | None = None) -> None:
        """Set session data after successful authentication."""
        data = {"id": user_id}
        if extra:
            data.update(extra)
        request.session[self.SESSION_KEY] = data

    def logout(self, request: Request) -> None:
        """Clear session data."""
        request.session.pop(self.SESSION_KEY, None)

    def get_user(self, request: Request) -> dict[str, Any] | None:
        """Get current user data from session, or None if not logged in."""
        return request.session.get(self.SESSION_KEY)

    def require(self, request: Request) -> dict[str, Any]:
        """Get current user or raise 403."""
        user = self.get_user(request)
        if not user:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not authenticated")
        return user

    def is_authenticated(self, request: Request) -> bool:
        """Check if user is logged in."""
        return self.get_user(request) is not None
