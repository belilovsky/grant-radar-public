"""Identity-provider-neutral access and defensive HTTP response policies."""

from __future__ import annotations

from dataclasses import dataclass

from qazstack.contracts._validation import require_one_of, require_text


@dataclass(frozen=True, slots=True)
class SessionClaims:
    subject: str
    roles: tuple[str, ...]
    session_id: str
    auth_time: int
    expires_at: int
    email_verified: bool = False

    def __post_init__(self) -> None:
        require_text(self.subject, "subject")
        require_text(self.session_id, "session_id")
        if self.auth_time <= 0 or self.expires_at <= self.auth_time:
            raise ValueError("session timestamps are invalid")
        if not self.roles or any(not role.strip() for role in self.roles):
            raise ValueError("roles must contain non-empty values")
        if len(set(self.roles)) != len(self.roles):
            raise ValueError("roles must not contain duplicates")

    def has_any_role(self, *required: str) -> bool:
        return bool(set(self.roles).intersection(required))


@dataclass(frozen=True, slots=True)
class AccessDecision:
    allowed: bool
    reason: str
    required_roles: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        require_text(self.reason, "reason")
        if not self.allowed and not self.required_roles:
            raise ValueError("denied decisions must identify required roles")


def decide_access(claims: SessionClaims | None, required_roles: tuple[str, ...]) -> AccessDecision:
    if not required_roles:
        return AccessDecision(True, "public")
    if claims is None:
        return AccessDecision(False, "authentication_required", required_roles)
    if claims.has_any_role(*required_roles):
        return AccessDecision(True, "role_granted", required_roles)
    return AccessDecision(False, "role_missing", required_roles)


@dataclass(frozen=True, slots=True)
class SecurityResponsePolicy:
    content_security_policy: str
    allowed_origins: tuple[str, ...]
    cookie_secure: bool = True
    cookie_http_only: bool = True
    cookie_same_site: str = "lax"
    frame_options: str = "DENY"
    referrer_policy: str = "strict-origin-when-cross-origin"
    csrf_required: bool = True

    def __post_init__(self) -> None:
        require_text(self.content_security_policy, "content_security_policy")
        require_one_of(self.cookie_same_site, frozenset({"lax", "strict", "none"}), "cookie_same_site")
        require_one_of(self.frame_options, frozenset({"DENY", "SAMEORIGIN"}), "frame_options")
        if self.cookie_same_site == "none" and not self.cookie_secure:
            raise ValueError("SameSite=None cookies must be secure")
        if "*" in self.allowed_origins:
            raise ValueError("credentialed security policy cannot allow wildcard origins")

    def headers(self) -> dict[str, str]:
        return {
            "Content-Security-Policy": self.content_security_policy,
            "Referrer-Policy": self.referrer_policy,
            "X-Content-Type-Options": "nosniff",
            "X-Frame-Options": self.frame_options,
        }
